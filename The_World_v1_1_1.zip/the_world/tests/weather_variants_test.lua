-- Standalone contracts for the 300 core persistent weather variants.
local scriptPath = (arg and arg[0]) or "tests/weather_variants_test.lua"
local ROOT = scriptPath:match("^(.*)[/\\]tests[/\\][^/\\]*$") or "."
local loader = loadstring or load
local function chunk(rel, arg_)
  local f = assert(io.open(ROOT .. "/" .. rel, "rb")); local src = f:read("*a"); f:close()
  return assert(loader(src, "@" .. rel))(arg_)
end

local passed, failed = 0, 0
local function check(value, label)
  if value then passed = passed + 1 else failed = failed + 1; io.write("FAIL ", label, "\n") end
end

local Data = chunk("lib/WeatherVariantsData.lua")
local pokemon = { data = {} }
function pokemon:get(id) return self.data[id] end
function pokemon:register(id, def) self.data[id] = def end
for _, row in ipairs(Data) do pokemon.data[row.base] = pokemon.data[row.base] or {
  id=row.base, index=row.n, dex=row.n, name=row.baseName, types={"NORMAL"},
  level1Moves={}, learnset={}, evolutions={}
} end
pokemon.data.CHARMANDER.evolutions = { { species="CHARMELEON", level=16 } }
pokemon.data.CHARMELEON.evolutions = { { species="CHARIZARD", level=36 } }

local cfg = { weatherVariants={ enabled=true, encounterChance=.03, rareChance=.03,
  veryRareChance=.01, legendaryChance=.001 } }
local variantsOn = true
local Scene = { now={ mapId="CINNABAR_ISLAND" } }
local mods = {
  Config={ get=function() return cfg end },
  Settings={ weatherVariantsOn=function() return variantsOn end },
  Scene=Scene, WeatherState={}, WeatherVariantsData=Data,
}
local V = {
  mod={ content={ pokemon=pokemon, type_chart={ get=function() return {} end } },
    log={ info=function() end, warn=function() end } },
}
function V.require(name)
  if mods[name] then return mods[name] end
  mods[name] = chunk("lib/" .. name .. ".lua", V)
  return mods[name]
end
local Variants = V.require("WeatherVariants")

check(#Data == 300, "database has 300 rows")
check(Variants.install(), "species install")
check(Variants.describe() == "300/300 registered", "all variants registered")
check(Variants.kantoReforged == false, "Kanto-only catalog stays dormant without Kanto Reforged")

local rolls, at = { 0, 0 }, 0
local function hit() at = at + 1; return rolls[at] end
local normal = { species="CHARMANDER", level=12 }
local ash = Variants.tryEncounter(normal, { rng=hit }, { id="ASHFALL" })
check(ash.species == "WX_004_CHARMANDER_CINDER", "Ashfall gates Cinder Charmander")
check(ash.weatherVariant == true and ash.rare == true, "rare encounter flags")
check(normal.species == "CHARMANDER", "normal record was not mutated")

at = 0
local rain = Variants.tryEncounter(normal, { rng=hit }, { id="RAIN_LIGHT" })
check(rain == normal, "Rain rejects Cinder Charmander")
local fog = Variants.tryEncounter(normal, { rng=hit }, { id="FOG" })
check(fog == normal, "Fog rejects Cinder Charmander")

rolls, at = { 0, .9 }, 0
local miss = Variants.tryEncounter(normal, { rng=hit }, { id="ASHFALL" })
check(miss == normal, "variant roll is not guaranteed")

variantsOn = false
rolls, at = { 0, 0 }, 0
local disabled = Variants.tryEncounter(normal, { rng=hit }, { id="ASHFALL" })
check(disabled == normal, "WX POKEMON OFF preserves the vanilla encounter")
Variants.forceNext("CHARMANDER")
local forcedDisabled = Variants.tryEncounter(normal, { rng=hit }, { id="ASHFALL" })
check(forcedDisabled == normal, "WX POKEMON OFF also blocks forced variants")
check(Variants.forced == nil, "disabled forced variant is discarded")
variantsOn = true

local caught = ash.species
local weatherNow = { id="RAIN_LIGHT" }
check(caught == "WX_004_CHARMANDER_CINDER" and weatherNow.id == "RAIN_LIGHT",
  "caught variant persists after weather change")

local cinder = pokemon.data.WX_004_CHARMANDER_CINDER
local cinder2 = pokemon.data.WX_005_CHARMELEON_CINDER
check(cinder.evolutions[1].species == "WX_005_CHARMELEON_CINDER", "Cinder Charmander evolution")
check(cinder2.evolutions[1].species == "WX_006_CHARIZARD_INFERNO", "Cinder Charmeleon evolution")
check(pokemon.data.CHARMANDER.evolutions[1].species == "CHARMELEON", "vanilla evolution untouched")
check(cinder.index == nil, "variant does not duplicate ROM species index")
check(cinder.dexEntry and cinder.dexEntry.text:match("^_WX_"), "variant has registered Pokédex text key")
check(cinder.displayName == nil and cinder.weatherVariant == nil,
  "variant record contains only schema-safe inherited fields")

io.write(("weather variants: %d passed, %d failed\n"):format(passed, failed))
if failed > 0 then os.exit(1) end
return true
