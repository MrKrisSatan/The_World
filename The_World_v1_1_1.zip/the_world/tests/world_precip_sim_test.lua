-- WorldPrecip simulation test.
--
-- These assertions are written against BEHAVIOUR, not shape. AGENTS.md's
-- warning applies directly here: this module's previous test
-- (tools/test_world_precip.py) only grepped the source for the string
-- "WorldPrecip.update", so it passed green for every release in which the
-- module was a hard compile error and loaded on no host at all.
--
-- Everything below either loads and runs the real file or fails.
--
--   lua tests/world_precip_sim_test.lua        (run from the mod root)

local ROOT = (arg and arg[0] or ""):match("^(.*)tests[/\\][^/\\]*$") or "./"

local failures, checks = 0, 0
local function check(ok, msg)
  checks = checks + 1
  if not ok then
    failures = failures + 1
    io.write("FAIL: ", msg, "\n")
  end
end

-- ---------------------------------------------------------------------------
-- Mock love: enough of the graphics API for the draw path, and a counter so the
-- test can prove the vertex buffer stops allocating meshes once warm.
-- ---------------------------------------------------------------------------
local meshesCreated = 0
local lastDrawnCount = 0

local function newMockMesh(fmt, capOrVerts)
  local cap = type(capOrVerts) == "number" and capOrVerts or #capOrVerts
  meshesCreated = meshesCreated + 1
  local m = { cap = cap, uploaded = 0 }
  function m:setVertices(verts, startv, count)
    if count then
      if count > self.cap then error("upload past mesh capacity") end
      -- verify the prefix is well formed
      for i = startv, startv + count - 1 do
        local v = verts[i]
        if type(v) ~= "table" or #v ~= 7 then error("malformed vertex at " .. i) end
        for k = 1, 7 do
          if type(v[k]) ~= "number" or v[k] ~= v[k] then
            error("non-finite vertex component at " .. i .. "," .. k)
          end
        end
      end
      self.uploaded = count
    else
      self.uploaded = #verts
    end
  end
  function m:setDrawRange(s, n) lastDrawnCount = n end
  return m
end

love = {
  graphics = {
    newMesh = function(fmt, a, b, c) return newMockMesh(fmt, a) end,
    newShader = function(src) return { send = function() end } end,
    setBlendMode = function() end,
    setDepthMode = function() end,
    setShader = function() end,
    setColor = function() end,
    draw = function() end,
  },
}

-- ---------------------------------------------------------------------------
-- Mock namespace. Quality reports a potato budget so the test also proves the
-- cap actually scales -- the thing that silently did nothing before the
-- DramalessAtmos require chain was fixed.
-- ---------------------------------------------------------------------------
local firstPersonFlag = true
local V = {}
function V.require(name)
  if name == "Quality" then
    return { budget = function() return { worldPrecip = 1.0 } end }
  elseif name == "Settings" then
    return { isFirstPerson = function() return firstPersonFlag end }
  end
  error("no module " .. name, 0)
end

local chunk = assert(loadfile(ROOT .. "lib/voxel_atmos/WorldPrecip.lua"))
local WP = chunk(V)
check(type(WP) == "table", "module returns a table")
check(type(WP.update) == "function", "WP.update exists")
check(type(WP.draw) == "function", "WP.draw exists")

-- ---------------------------------------------------------------------------
-- 1. The module compiles and runs on a 5.1-compatible dialect.
-- ---------------------------------------------------------------------------
-- The dead `hash()` helper used Lua 5.3 bitwise operators, which made the whole
-- file a compile error under LuaJIT. Its replacement must be callable and must
-- stay in the unit interval.
check(type(WP.hash) == "function", "float hash replaces the 5.3-bitwise one")
if type(WP.hash) == "function" then
  local inRange = true
  for i = 1, 500 do
    local h = WP.hash(i, 7)
    if not (h >= 0 and h < 1) then inRange = false end
  end
  check(inRange, "hash stays in [0,1)")
end

-- ---------------------------------------------------------------------------
-- 2. Snowy weather ids all resolve to falling snow.
-- ---------------------------------------------------------------------------
-- FROST*, ICEBOUND and WHITEOUT used to fall through the classifier entirely
-- and produce zero flakes.
local SNOWY = { "SNOW", "SNOW_LIGHT", "BLIZZARD", "THUNDERSNOW", "HAIL", "SLEET",
                "WHITEOUT", "ICEBOUND", "FROSTBOG", "FROSTWAVE", "SNOWSHREW",
                "TSNOW", "DRAGONSTORM" }
for _, id in ipairs(SNOWY) do
  check(WP.snowyTarget(id) > 0, id .. " is classified as snowy")
end
for _, id in ipairs({ "CLEAR", "RAIN", "SANDSTORM", "FOG", "" }) do
  check(WP.snowyTarget(id) == 0, id .. " is not snowy")
end

-- ---------------------------------------------------------------------------
-- 3. A snow weather actually simulates: run a minute of frames.
-- ---------------------------------------------------------------------------
local focus = { 100, 0, 100 }
local weather = { wxId = "SNOW", snowIntensity = 0, snowWind = 0.65 }
local Voxel3D = { vp = {}, eye = { 100, 10, 100 }, focus = focus }

local ok, err = pcall(function()
  for _ = 1, 60 do
    WP.update(1 / 60, focus, weather)
    WP.draw(Voxel3D, { weather = weather })
  end
end)
check(ok, "one second of snow runs without error: " .. tostring(err))

local d = WP.describe()
local activeSnow = tonumber(d:match("snow=(%d+)")) or 0
check(activeSnow > 0, "snow particles are active (got: " .. d .. ")")
check(WP.drawingSnow(), "snow geometry was emitted, so 2D can be suppressed")
-- ...and the negative case, which is the one that matters. handlesSnow() turns
-- the 2D snow layer OFF based on this, so a drawingSnow() that reports intent
-- rather than fact would blank snow entirely in clear weather -- which is the
-- exact class of bug that made an earlier version hardcode `return false`.
do
  local clear = { wxId = "CLEAR" }
  for _ = 1, 5 do
    WP.update(1 / 60, focus, clear)
    WP.draw(Voxel3D, { weather = clear })
  end
  check(not WP.drawingSnow(), "drawingSnow() is false in clear weather")
  -- restore the snow state the later checks rely on
  for _ = 1, 60 do
    WP.update(1 / 60, focus, weather)
    WP.draw(Voxel3D, { weather = weather })
  end
end

-- ---------------------------------------------------------------------------
-- 4. Flakes occupy the near field -- you can walk through them.
-- ---------------------------------------------------------------------------
-- The old 720-unit uniform volume put almost nothing within reach of the
-- player. This is the assertion that fails if the radial bias is removed.
local samples = WP.sample(12)
check(#samples > 0, "sample() returns particles")

-- Warm up to a steady state first: a young field is still top-heavy with the
-- flakes it spawned high up, so measuring too early reads high and unstably.
for _ = 1, 1200 do
  WP.update(1 / 60, focus, weather)
  WP.draw(Voxel3D, { weather = weather })
end

-- IS IT SNOWING OVER THE WORLD, OR ONLY ON THE PLAYER?
--
-- This replaces a near-field-share assertion that 4.28.69 used to guard a
-- deliberately near-biased distribution. That bias was wrong -- on screen it
-- read as a snow globe following the player across an otherwise clear map --
-- so the property to pin is the opposite one: constant flakes per unit AREA at
-- every distance. A field that clumps around the focus fails here, and so does
-- one that hollows out the near field.
local R = WP.snowCoverage()
local dIn  = WP.snowAreaDensity(focus[1], focus[3], 0,          R * 0.33)
local dMid = WP.snowAreaDensity(focus[1], focus[3], R * 0.33,   R * 0.66)
local dOut = WP.snowAreaDensity(focus[1], focus[3], R * 0.66,   R)
io.write(string.format("       [density /1000u^2  inner %.2f  mid %.2f  outer %.2f  (R=%.0f)]\n",
  dIn, dMid, dOut, R))
check(dIn > 0 and dMid > 0 and dOut > 0, "every annulus has snow in it")
if dIn > 0 and dOut > 0 then
  local spread = math.max(dIn, dMid, dOut) / math.min(dIn, dMid, dOut)
  io.write(string.format("       [density spread: %.2fx]\n", spread))
  -- Uniform sampling plus a single deck height should hold this near 1. 1.6
  -- allows for wind drift and sampling noise while still failing hard on a
  -- near-biased distribution, which spreads by well over an order of magnitude.
  check(spread < 1.6,
    string.format("snow density is even across the rendered disk (%.2fx spread)", spread))
end

-- ...and it should cover a real amount of ground, not a courtyard.
local radius, perTile = WP.snowCoverage()
io.write(string.format("       [coverage: r=%.0f (%.0f tiles wide), %.2f flakes/tile]\n",
  radius, 2 * radius / 16, perTile))
check(radius >= 160, string.format("the snow disk spans the rendered world (r=%.0f)", radius))
check(perTile > 0.5, string.format("density is high enough to read as weather (%.2f/tile)", perTile))

-- ---------------------------------------------------------------------------
-- 5. Flakes reach the ground instead of evaporating mid-air.
-- ---------------------------------------------------------------------------
-- NOTE: `gsnow > 0` is NOT the assertion to make here, even though it looks
-- like it should be. Ground drifts are also seeded by ambient scatter while it
-- snows, so gsnow is nonzero whether or not a single flake ever completes its
-- fall -- it passed green against a deliberately reintroduced flat-lifetime
-- regression. The real question is what fraction of flakes end on the ground
-- rather than expiring in mid air, which is what snowFate() reports.
local gs = tonumber(WP.describe():match("gsnow=(%d+)")) or 0
check(gs > 0, "ground snow accumulated (got: " .. WP.describe() .. ")")

-- Flakes must fall a full tile deeper than the focus plane.
--
-- The brief was literal: "the snow particles need to fall 1 more tile". A tile
-- is 16 world units, and the old ground plane sat 1.5 units under the focus, so
-- flakes settled almost a whole tile above where the world's floor reads.
--
-- Asserting on the GROUND_DROP constant would prove nothing -- the constant and
-- the simulation are different claims, and setting GROUND_EXTRA_TILES back to 0
-- changed no test result at all before this check existed. So this measures how
-- deep a flake actually descended.
do
  local deepest, groundDrop, tile = WP.snowDepth()
  io.write(string.format("       [flakes reach %.1f units below focus (%.2f tiles); ground plane %.1f]\n",
    deepest, deepest / tile, groundDrop))
  check(groundDrop >= tile,
    string.format("ground plane is at least a full tile below focus (%.1f of %d)", groundDrop, tile))
  check(deepest >= tile,
    string.format("flakes actually descend a full tile below focus (%.1f of %d)", deepest, tile))
  -- ...and that they stop at the plane rather than falling through the world.
  check(deepest <= groundDrop + tile,
    string.format("flakes stop near the ground plane (%.1f vs plane %.1f)", deepest, groundDrop))
end

local landed, expiredAir = WP.snowFate()
check(landed + expiredAir > 0, "flakes completed their lives")
if landed + expiredAir > 0 then
  local share = landed / (landed + expiredAir)
  -- Measured over 60 simulated seconds at SNOW:
  --   this build                            100.0% land
  --   this volume + the old flat lifetime     71.3%
  --   the shipped 4.28.68 tuning              26.6%   <- three flakes in four
  --                                                      evaporated in mid air
  -- 0.95 is set to sit above the 71.3% case, so reverting the derived lifetime
  -- fails here rather than passing on a loose bound.
  check(share > 0.95,
    string.format("flakes land instead of vanishing mid-air (%.1f%% of %d)",
      100 * share, landed + expiredAir))
end

-- ---------------------------------------------------------------------------
-- 6. Flakes land on your face in first person -- and only in first person.
-- ---------------------------------------------------------------------------
-- Contact is now a rare-ish event by design: a uniform field puts far fewer
-- flakes within reach than the old near-biased one, so this needs a real window
-- rather than the second or two the earlier version got away with. Measured
-- rate at default density is about one hit every 10 simulated seconds.
for _ = 1, 60 * 45 do
  WP.update(1 / 60, focus, weather)
  WP.draw(Voxel3D, { weather = weather })
end
local faceHits = tonumber(WP.describe():match("face=%d+/(%d+)")) or 0
io.write(string.format("       [face contact: %d hits in 45s]\n", faceHits))
check(faceHits > 0, "flakes struck the eye sphere (got: " .. WP.describe() .. ")")

-- ---------------------------------------------------------------------------
-- 7. Rain still works, and its wet marks still deposit.
-- ---------------------------------------------------------------------------
-- `far()` was a nil global called on every rain particle every frame, which
-- aborted the shared pcall before draw ever ran. This is the regression guard.
WP.invalidate()
local rainWeather = { wxId = "RAIN", rainIntensity = 1.0, rainWind = 1.0 }
local okR, errR = pcall(function()
  for _ = 1, 120 do
    WP.update(1 / 60, focus, rainWeather)
    WP.draw(Voxel3D, { weather = rainWeather })
  end
end)
check(okR, "rain runs without error: " .. tostring(errR))
local rainActive = tonumber(WP.describe():match("rain=(%d+)")) or 0
check(rainActive > 0, "rain particles are active (got: " .. WP.describe() .. ")")

-- ---------------------------------------------------------------------------
-- 8. Grains run: sand, ash and debris each spawn.
-- ---------------------------------------------------------------------------
-- spawnGrainAt was a nil global, so this whole family was dead.
for _, w in ipairs({
  { wxId = "SANDSTORM", sandIntensity = 1.45 },
  { wxId = "ASHFALL", ashIntensity = 1.10 },
  { wxId = "GALE", debrisIntensity = 1.15 },
}) do
  WP.invalidate()
  local okG, errG = pcall(function()
    for _ = 1, 60 do
      WP.update(1 / 60, focus, w)
      WP.draw(Voxel3D, { weather = w })
    end
  end)
  check(okG, w.wxId .. " runs without error: " .. tostring(errG))
  local g = tonumber(WP.describe():match("grain=(%d+)")) or 0
  check(g > 0, w.wxId .. " spawns grains (got: " .. WP.describe() .. ")")
end

-- ---------------------------------------------------------------------------
-- 9. The draw path stops allocating meshes once warm.
-- ---------------------------------------------------------------------------
-- This is the optimisation guard. The old path built a fresh mesh-sized table
-- of per-vertex tables every frame; the new one reuses a buffer and a VBO.
WP.invalidate()
meshesCreated = 0
for _ = 1, 90 do
  WP.update(1 / 60, focus, weather)
  WP.draw(Voxel3D, { weather = weather })
end
local warmup = meshesCreated
meshesCreated = 0
for _ = 1, 300 do
  WP.update(1 / 60, focus, weather)
  WP.draw(Voxel3D, { weather = weather })
end
check(meshesCreated <= 2,
  string.format("steady state creates no new meshes (warmup %d, then %d over 300 frames)",
    warmup, meshesCreated))

-- Mesh count alone does not prove the vertex path stopped churning: the old
-- code reused nothing and built a fresh 7-field table per vertex per frame. So
-- measure allocation directly. At the snow cap the old path produced ~25,200
-- tables a frame; anything in that region shows up immediately here.
collectgarbage("collect")
collectgarbage("collect")
local before = collectgarbage("count")
local FRAMES = 200
for _ = 1, FRAMES do
  WP.update(1 / 60, focus, weather)
  WP.draw(Voxel3D, { weather = weather })
end
local churn = (collectgarbage("count") - before) / FRAMES
io.write(string.format("       [draw+update churn: %.2f KB/frame]\n", churn))
-- Measured at the snow cap with this harness:
--   buffer reused (current)          0.09 KB/frame
--   fresh table per vertex (old)    21.95 KB/frame
-- 2.0 sits an order of magnitude above the real figure and an order of
-- magnitude below the regression, so it is neither flaky nor decorative. An
-- earlier draft of this check used 40 and sailed straight past the mutation --
-- a threshold that cannot fail is not a test.
check(churn < 2.0,
  string.format("steady-state allocation stays flat (%.2f KB/frame)", churn))

-- ---------------------------------------------------------------------------
-- 10. Quality budget is honoured (the require chain reaches the mod's Quality).
-- ---------------------------------------------------------------------------
local FullV = { require = V.require }
local potatoV = {
  require = function(name)
    if name == "Quality" then
      return { budget = function() return { worldPrecip = 0.28 } end }
    end
    return V.require(name)
  end,
}
local WPfull = assert(loadfile(ROOT .. "lib/voxel_atmos/WorldPrecip.lua"))(FullV)
local WPpot = assert(loadfile(ROOT .. "lib/voxel_atmos/WorldPrecip.lua"))(potatoV)
for _ = 1, 90 do
  WPfull.update(1 / 60, focus, weather)
  WPpot.update(1 / 60, focus, weather)
end
local nFull = tonumber(WPfull.describe():match("snow=(%d+)")) or 0
local nPot = tonumber(WPpot.describe():match("snow=(%d+)")) or 0
check(nPot > 0 and nPot < nFull,
  string.format("potato tier cuts the snow cap (%d vs %d)", nPot, nFull))

-- ---------------------------------------------------------------------------
-- 11. Third person takes no face hits.
-- ---------------------------------------------------------------------------
firstPersonFlag = false
local WPtp = assert(loadfile(ROOT .. "lib/voxel_atmos/WorldPrecip.lua"))(V)
for _ = 1, 240 do
  WPtp.update(1 / 60, focus, weather)
  WPtp.draw(Voxel3D, { weather = weather })
end
local tpFace = tonumber(WPtp.describe():match("face=%d+/(%d+)")) or -1
check(tpFace == 0, "no face specks outside first person (got " .. tpFace .. ")")
firstPersonFlag = true

-- ---------------------------------------------------------------------------
io.write(string.format("\n%d checks, %d failure(s)\n", checks, failures))
if failures > 0 then os.exit(1) end
