# The World 1.0.1

- Removed escaped newline sequences from the character-creation prompts that
  could render as stray `n` characters before words.
- Trainer prompt is now a clean single-line `WHAT KIND OF TRAINER ARE YOU?`.
- Rival-count prompt is now `HOW MANY AI RIVALS?`.
- Audited character-creation/menu dialogue for the same stray `nWORD` pattern.
