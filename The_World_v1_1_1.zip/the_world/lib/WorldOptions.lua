local W={}

W.AI_ROWS={

  {key="worldContentScope",label="POKEMON GENERATIONS",type="choice",default="gen1_gen2_gen3",
    choices={
      {"GEN 1","gen1"},
      {"GEN 1 + GEN 2","gen1_gen2"},
      {"GEN 1 + GEN 2 + GEN 3","gen1_gen2_gen3"},
    },
    help="Controls which Pokemon generations can appear in the world. Registered species remain save-safe."},
  {key="worldAbilities",label="ABILITIES",type="choice",default="on",
    choices={{"ON","on"},{"OFF","off"}},
    help="Pokemon abilities from Kanto Reforged. OFF keeps species data but disables ability battle effects."},
  {key="worldHeldItems",label="HELD ITEMS",type="choice",default="on",
    choices={{"ON","on"},{"OFF","off"}},
    help="Gen 2/3 held-item effects and wild held items. Existing held items remain save-safe when OFF."},
  {key="worldModernMoves",label="GEN 2/3 MOVES",type="choice",default="on",
    choices={{"ON","on"},{"OFF","off"}},
    help="Expanded Gen 2/3 move mechanics. Moves stay registered for save compatibility."},
  {key="worldModernTypes",label="DARK/STEEL/FAIRY",type="choice",default="on",
    choices={{"ON","on"},{"OFF","off"}},
    help="Expanded type support required by later-generation Pokemon."},
  {key="worldAI",label="AI TRAINERS",type="choice",default="on",
    choices={{"ON","on"},{"OFF","off"}},
    help="Master switch for autonomous Rivals, Team Rocket, Pokemon Rangers, rival wars and AI tournaments."},
  {key="rivals",label="RIVALS",type="choice",default="all",
    choices={{"OFF","off"},{"TWO","two"},{"ALL","all"}}},
  {key="encounters",label="RIVAL DUELS",type="toggle",default=true},
  {key="pace",label="WORLD PACE",type="choice",default="normal",
    choices={{"SLOW","slow"},{"NORMAL","normal"},{"FAST","fast"}}},
  {key="performance",label="WALKING COST",type="choice",default="balanced",
    choices={{"LOW","low"},{"BALANCED","balanced"},{"FULL","full"}}},
  {key="relationships",label="RIVAL BONDS",type="toggle",default=true},
  {key="sightings",label="RIVAL SIGHTINGS",type="toggle",default=true},
  {key="life_paths",label="RIVAL LIFE PATHS",type="toggle",default=true},
  {key="news_ticker",label="NEWS TICKER",type="toggle",default=true},
  {key="ticker_spam",label="TICKER VOLUME",type="choice",default="normal",
    choices={{"QUIET","quiet"},{"NORMAL","normal"},{"FULL","full"}}},
  {key="rocket_pace",label="ROCKET SPREAD",type="choice",default="normal",
    choices={{"SLOW","slow"},{"NORMAL","normal"},{"AGGRESSIVE","aggressive"}}},
  {key="clone_lag_guard",label="CLONE LAG GUARD",type="toggle",default=true},
  {key="large_pokegear",label="LARGE RIVALGEAR TEXT",type="toggle",default=false},
  {key="debug",label="WORLD AI DEBUG",type="toggle",default=false},
}
function W.rows()
  local out={}
  for _,r in ipairs(W.AI_ROWS) do out[#out+1]=r end
  return out
end
return W
