# The World

The World fully merges AI Rivals 7.6.3 with Weather FX 4.28.70.

Character creation now configures Trainer Class, rival count (including ZERO),
dynamic weather ON/OFF, Weather Intensity, Weather Quality, the opening gauntlet,
and rival naming.

ZERO means no ordinary rivals and no rare special rivals. Team Rocket and
Pokemon Rangers remain independent world factions.

NO WEATHER forces the integrated weather state clear/off and disables
weather-variant encounter output. Weather can still be configured later through
The World's Weather settings.


## Gen 1-3 content

The World 1.1.0 includes the Pokemon, moves, abilities and held items from
Kanto Reforged. The unified options page controls the active generation scope:

- GEN 1
- GEN 1 + GEN 2
- GEN 1 + GEN 2 + GEN 3

Abilities, held items and Gen 2/3 move mechanics can each be switched
independently. Content remains registered behind the scenes for save safety.
