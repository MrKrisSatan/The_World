# The World 1.1.1

- Fixed the startup Lua syntax error in `ai/main.lua` around the new unified
  character-creation option mapping.
- Replaced the fragile deeply nested `and/or` parenthesis chain with a lookup
  table for Weather, WX Pokemon, AI Trainers, generation scope, Abilities,
  Held Items and Gen 2/3 Moves.
- Audited merged Lua sources for conflict markers and common merge-time syntax
  damage.
