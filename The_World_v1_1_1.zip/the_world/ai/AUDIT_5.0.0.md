# AI Rivals 5.0.1 Audit

## Critical startup failure fixed
The distributed 5.0.1 archive referenced `src/Backgrounds.lua` from `main.lua`, `Rival.lua`, and `Rocket.lua`, but the runtime module was missing from the archive. The loader therefore failed during startup with `ai_rivals: missing module src/Backgrounds.lua`.

The 250-record `data/backgrounds.lua` file was present, but the implementation module that loads and applies those records was absent. `src/Backgrounds.lua` has now been restored.

## Snowcoil correction
Casca's optional Weather FX starter is `DRATINI_SNOWCOIL` in the original package. It has been corrected everywhere to `DRATINI_SNOWCOIL` only where the requested implementation identifier is used. (Display/name text should be `Dratini Snowcoil`.)

## Additional checks
- All custom `req(...)` module references now resolve to files in the package.
- All Python static checks pass.
- No NUL bytes or invalid UTF-8 were found in Lua/JSON/Markdown files.
- Manifest remains version 5.0.1.

A Lua runtime was not available in the audit environment, so runtime execution against the game engine could not be performed.
