# AI Rivals 4.7.0 — a hundred lives, four new kinds of relationship, and names Kanto gives you

## 105 life paths, and paths are data now

`data/lifepaths.lua` holds one row per path: its label, its blurb, the facts it
weighs, the facts it *requires*, whether it can be left, and the working life it
becomes. `LifePath` and `Career` both read those rows.

Before this, a path existed in four places — `PATHS`, `LABELS`, a hand-written
line inside `compatibility()`, and `Career.DEFS` — plus a `TRANSITIONS` row and
a headline arm. Sixteen paths meant sixteen of each and that was liveable. A
hundred would have been four hundred edits and four places to disagree. Adding
a path is now a data edit, exactly as adding a rival became one in 3.3.

The five you named are in: **Pokémon Ranger**, **Legendary Hunter**, **Agent of
Celebi**, **Ambassador of Arceus**, **League Champion** — alongside a hundred
others, grouped by the kind of life they are.

**Rarity is a gate, not a small number.** A row may require a fact, and a rival
who lacks it cannot be dealt that path at any score. `AVENGER` needs a betrayal
behind it, `SWORN_RIVAL` needs jealousy, `PROTECTOR` needs family. That is the
mechanism §17 already demanded of Team Rocket, now available to every path —
and still nothing anywhere in the model rolls a die.

## Relationships change, and they change what a rival becomes

Four new states, each placed deliberately in the derivation order:

| State | Reached by |
| --- | --- |
| **Betrayal** | an ally or devoted bond that turned — outranks even NEMESIS |
| **Jealousy** | somebody level with them pulled ahead, and it stung |
| **Fear** | beaten so often and so badly they stop wanting the match |
| **Family** | **declared by the roster** — no sequence of battles makes two rivals siblings |

BETRAYED is the only state in the model that needs a remembered *event*. The
axes decay, so a bond reading "very low regard" a year later cannot tell a
betrayal from an ordinary falling-out — and hatred earned over a hundred
battles is not the same relationship as hatred earned in one afternoon by
somebody who was supposed to be on your side.

Three new causes carry them: `BETRAYED`, `OUTSHONE`, `PROTECTED`.

Six relationship facts now feed the path weights — betrayal, jealousy, fear,
kinship, mentorship, devotion — so **who a rival knows decides what they can
become**. Fear makes a rival avoid the match (`FIGHT_BIAS` 0.20); betrayal makes
them seek it harder than anything else in the model (2.40).

## Titles

> *a powerful female trainer that favours fire types will be known as "Princess
> of Ashes", while a male rival who favours water Pokémon would be "Might of
> Oceans" or "Ocean's Wrath"*

`src/Titles.lua`. Three inputs: the type that dominates the party, the standing
they have actually earned, and gender where the language differs. The same Fire
specialist is **the Ember**, then **the Flamebearer**, then the **Princess of
Ashes**. Rivals use each other's titles in the news and in conversation, and a
record screen shows it under the name.

**Derived, never stored.** A stored title outlives the thing it describes — a
Princess of Ashes whose last Fire type was traded away three hours ago, still
being called that by everyone in Kanto. Change the team and the name changes
with it, which the suite pins directly.

**Rivals actually use them.** A title that only appears on a record screen is
a database field, not a reputation, so it lands wherever one trainer speaks
about another: news headlines, phone gossip, scouting reports ("I've faced the
Might of Oceans once or twice"), and tournament billing. One accessor
(`M:spokenNameOf`) decides the name, so half the game cannot say MATT while the
other half says Might of Oceans. `Scout` stays pure — it reads a stamped
string rather than reaching into `Titles` itself. The player is always
"PLAYER": they have no title here, and inventing one would be speaking for
them.

A title is *earned*: a trainer with one badge has none, and gets their plain
name. And NORMAL needs 70% of a party to count as a specialism where every
other type needs 45%, because Normal is the *default* type — a balanced team
drifts past 45% without anybody having specialised, and "the Perfect Ordinary"
is a wonderful name to earn and a terrible one to be handed by accident.

## Tournaments

- **One a day per initiator** — the player *and each rival separately*. One
  shared key would mean the first rival to hold an event spends everybody's
  day. A boot with no clock has the limit not apply, rather than being locked
  out forever.
- **The purse scales with the field and the crowd.** Participants counted when
  the bracket is built, witnesses (rivals at the venue who are not competing,
  plus the player) counted once when it finishes — so the purse cannot be
  inflated by walking the venue afterwards. Capped at 6×, one to three items,
  and prize money has its own ceiling.

## Five bugs, four of them older than this release

1. **`Career.IMPLEMENTED` was a hand-maintained list that had drifted.** The
   five careers added in 2.4 shipped with full definitions and were never added
   to it — the whole of `career_test`'s long-standing ten-failure baseline. It
   is derived from the rows now.
2. Deriving it exposed **three careers with dead code in their priority lists**:
   TYPE_SPECIALIST never reported to its Gym, COURIER never reached a Mart,
   PHOTOGRAPHER never sought ghosts. All three broke the 1.14 fallback-last
   rule; none was ever checked, because the paths were missing from the list.
3. **TYPE_SPECIALIST could never be offered to anybody, and had not been since
   2.4** — badges+fight, but always less of both than GYM_ASSISTANT. Strictly
   dominated, therefore dead. It has its own signature now (a mono-type team,
   which is what the name means).
4. **I transcribed the sixteen legacy careers by hand and got twelve wrong** —
   homes dropped, metrics renamed (which would have orphaned every saved
   progress counter), thresholds moved. Caught by a script that loads both
   versions and diffs them field by field; the rows are generated from the real
   tables now. Lesson 14 pointed inward: don't hand-mirror a table you can
   generate.
5. **Adding 89 paths crowded three legacy lives out of existence** — not by
   changing their weights, but because the candidate window stayed at three
   while the queue in front of them got six times longer. The window scales
   with the roster now.

## Verification

- **80 suites.** Every pre-existing failure count identical to 4.6.0. Four
  suites went from failing to clean (career, career dialogue, lifepath,
  rival relationships) because the drift above is fixed.
- New: `lifepath_reach_test` (a 40,000-rival sweep asserting **every one of the
  105 paths can actually be offered** — dead content is the failure mode of
  adding a hundred rows), `tournaments_titles_test` (38),
  `paths_titles_static.py`.
- 39 static contracts. Four needed repointing at the data file; `career_static`
  was **strengthened** while being moved — it now checks every objective named
  in every priority list against the vocabulary `AI.lua` implements, which is
  what its comment always claimed and what a hundred hand-written rows need.
  Verified it bites: a typo'd objective fails it.
- `economy_static` gained the player's prize-money door **by name**, not by
  loosening its pattern — and a bare `save.money +` anywhere else still fails.
- `modkit validate` ok; `gen2check` 24 errors / 11 warnings, unchanged. No
  engine patch.
