# AI Rivals 7.5.2

## New-game Red House exit crash
- Added a dedicated pre-starter/new-game guard to static outdoor rival models.
- Connected-map rival slots remain predeclared, but stay at off-map coordinates
  while the player still has no Pokemon.
- This prevents the first Red/Blue/Yellow house -> town transition, and Gold's
  equivalent opening transition, from populating AI-owned objects while the
  engine is still finishing player/new-game setup.
- SKIP GAUNTLET still releases abstract rival simulation immediately; only
  physical outdoor models wait for the player's starter.
- No live map rebuild occurs when the starter is received. Rival models populate
  naturally on a subsequent safe map load.
- `loadPlayerClass()` is now read-only and no longer writes mod save data during
  `game.ready` / `save.loaded`.
- Audited StaticRivals to ensure it performs no live spawn/remove calls.
