# AI Rivals 6.5.0 — Rival Wars & Rocket Stolen Pokémon Market

- Team Rocket thefts now preserve the stolen Pokémon as a persistent asset with original-owner provenance and sale history.
- Rocket members can field stolen Pokémon in their trainer parties, up to the normal six-Pokémon limit.
- Rocket members occasionally buy stolen Pokémon from one another when they meet, moving money and ownership rather than cloning the Pokémon.
- A disguised, non-exposed player can be offered stolen Pokémon directly by the Rocket member currently holding them.
- Player purchases preserve provenance, go to the party when space exists, otherwise to PC storage, and remove the Pokémon from Rocket ownership.
- Stolen-Pokémon prices scale with level and rarity; the seller receives the money.
- Buying stolen Pokémon feeds the existing faction/double-agent evidence system.
- Legacy stolen records from pre-6.5 saves are upgraded on load.
- Rocket Ball black-market sales and NPC-given mission-chain rules remain intact.
