-- 6.3.0 faction standing + double-agent belief state.
-- Reputation is what the player has objectively done for a faction. Trust and
-- suspicion are what that faction currently believes about the player.
local req, mod = ...
local Util = req("src/Util")
local Factions = {}
Factions.__index = Factions

local KEYS = { "rocket", "rangers", "gym", "researchers", "breeders", "collectors", "communities" }
local function clamp(v, lo, hi) v=tonumber(v) or 0; if v<lo then return lo elseif v>hi then return hi end; return math.floor(v) end
local function fieldFor(key)
  key=tostring(key or ""):lower()
  if key=="rocket" then return "rocket" end
  if key=="rangers" or key=="ranger" then return "rangers" end
  if key=="gym" or key=="alliance" then return "gym" end
  if key=="researchers" or key=="research" then return "researchers" end
  if key=="breeders" or key=="breeder" then return "breeders" end
  if key=="collectors" or key=="collector" then return "collectors" end
  if key=="communities" or key=="community" then return "communities" end
end

function Factions.new(saved)
  local self=setmetatable({rocket=0,rangers=0,gym=0,researchers=0,breeders=0,collectors=0,communities=0,
    profiles={}, localStanding={}},Factions)
  for _,k in ipairs(KEYS) do self.profiles[k]={trust=0,suspicion=0,evidence=0,state="UNKNOWN"} end
  if type(saved)=="table" then
    for _,k in ipairs(KEYS) do if tonumber(saved[k]) then self[k]=clamp(saved[k],-100,100) end end
    local ps=type(saved.profiles)=="table" and saved.profiles or {}
    for _,k in ipairs(KEYS) do
      local s=type(ps[k])=="table" and ps[k] or {}
      self.profiles[k]={trust=clamp(s.trust,-100,100),suspicion=clamp(s.suspicion,0,100),evidence=clamp(s.evidence,0,100),state=s.state or "UNKNOWN"}
    end
    self.localStanding=type(saved.localStanding)=="table" and Util.copy(saved.localStanding) or {}
  end
  for _,k in ipairs(KEYS) do self:updateState(k) end
  return self
end
function Factions:get(key) local f=fieldFor(key); return f and self[f] or 0 end
function Factions:profile(key) local f=fieldFor(key); return f and self.profiles[f] or nil end
function Factions:updateState(key)
  local p=self:profile(key); if not p then return "UNKNOWN" end
  if p.suspicion>=85 or p.evidence>=90 then p.state="HUNTED"
  elseif p.suspicion>=65 or p.evidence>=70 then p.state="EXPOSED"
  elseif p.suspicion>=45 then p.state="INVESTIGATED"
  elseif p.suspicion>=25 then p.state="SUSPECTED"
  elseif p.trust>=35 then p.state="TRUSTED"
  else p.state="UNKNOWN" end
  return p.state
end
function Factions:adjust(key,delta,reason)
  local f=fieldFor(key); if not f then return 0 end
  delta=math.floor(tonumber(delta) or 0); self[f]=clamp(self[f]+delta,-100,100); return self[f]
end
function Factions:adjustTrust(key,delta,reason) local p=self:profile(key); if not p then return 0 end; p.trust=clamp(p.trust+(tonumber(delta) or 0),-100,100); self:updateState(key); return p.trust end
function Factions:adjustSuspicion(key,delta,evidence,reason)
  local p=self:profile(key); if not p then return 0 end
  p.suspicion=clamp(p.suspicion+(tonumber(delta) or 0),0,100); p.evidence=clamp(p.evidence+(tonumber(evidence) or 0),0,100); self:updateState(key); return p.suspicion
end
function Factions:coolDown()
  for _,k in ipairs(KEYS) do local p=self.profiles[k]; p.suspicion=clamp(p.suspicion-1,0,100); if p.state~="EXPOSED" and p.state~="HUNTED" then p.evidence=clamp(p.evidence-1,0,100) end; self:updateState(k) end
end
function Factions:label(key) local v=self:get(key); if v>=40 then return "ALLIED" elseif v>=15 then return "FRIENDLY" elseif v>=-14 then return "NEUTRAL" elseif v>=-39 then return "WARY" else return "HOSTILE" end end
function Factions:belief(key) return (self:profile(key) or {}).state or "UNKNOWN" end
function Factions:rocketAmbushMult() local v=self.rocket; if self:belief("rocket")=="HUNTED" then return 1.8 end; if v>=30 then return .55 elseif v<=-30 then return 1.45 end; return 1-(v/200) end
function Factions:questRewardMult(key) local v=self:get(key); return 1+math.max(-.25,math.min(.35,v/200)) end
function Factions:adjustLocal(map,delta) if not map then return end; self.localStanding[map]=clamp((self.localStanding[map] or 0)+(tonumber(delta) or 0),-100,100) end
function Factions:serialize() local out={profiles=Util.copy(self.profiles),localStanding=Util.copy(self.localStanding)}; for _,k in ipairs(KEYS) do out[k]=self[k] end; return out end
return Factions
