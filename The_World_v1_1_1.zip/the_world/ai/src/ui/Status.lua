local req, mod = ...

-- STATUS SCREENS
--
-- Every AI Rivals screen reachable from the pause menu: the status list and
-- the RIVALS entry point that opens it, the per-rival detail and info pages,
-- the performance counters, the error log, standings, story and world news.
--
-- Presentation only. Nothing here decides anything about a rival; it reads
-- what the manager already holds and formats it. Extracted from main.lua in
-- 4.6.1 with the bodies unchanged.
--
-- `install` is called from main.lua at the exact point these registrations
-- used to sit, because hook order is observable: this file's
-- `ui.start_menu.items` wrap must still run before the one Pokegear installs
-- later, or the RIVALS row moves relative to the Pokegear row.

local Util = req("src/Util")
local Story = req("src/Story")
local League = req("src/League")

local Status = {}

-- SCREEN stays owned by main.lua: it builds screen ids outside this file too
-- (`SCREEN .. "Story"`, `SCREEN .. "Detail"`), so it is passed in rather than
-- duplicated here where the two copies could drift apart.
function Status.install(modApi, M, SCREEN)
  mod = modApi or mod

  ------------------------------------------------------------------------
  -- Status screen
  ------------------------------------------------------------------------

  mod.content.screens:register(SCREEN, {
    new = function(game)
      local items = {}
      if Util.lastError then
        items[#items + 1] = {
          label = "LAST ERR",
          right = tostring(Util.lastError):gsub("mods/ai_rivals/", ""):gsub("@ai_rivals/", ""):sub(1, 40),
          value = "_err",
        }
      end
      items[#items + 1] = {
        label = "READY",
        right = tostring(M.ready) .. " n=" .. tostring(#M.rivals),
        value = "_ready",
      }
      local gstate
      if M:gauntletDone() then
        gstate = "done"
      elseif M:gauntletActive() then
        local ph = M.gauntlet.phase or "?"
        if ph == "wait_blue" or ph == "wait_party" then
          gstate = M:blueLabBattled() and ("go " .. ph) or "wait Blue"
        else
          gstate = tostring(ph) .. "#" .. tostring(M.gauntlet.index)
        end
      else
        gstate = "pending"
      end
      items[#items + 1] = {
        label = "GAUNTLET",
        right = tostring(gstate),
        value = "_gauntlet",
      }
      if M:gauntletActive() then
        items[#items + 1] = {
          label = "SKIP GAUNTLET",
          right = "RELEASE RIVALS",
          value = "_skip_gauntlet",
        }
      end
      items[#items + 1] = {
        label = "NEWS",
        right = (M:latestNews():sub(1, 16)),
        value = "_news",
      }
      items[#items + 1] = {
        label = "STANDINGS",
        right = (M.playerChampion and "YOU LEAD")
          or (M:eliteChampion() and (M:eliteChampion().name .. " LEADS"):sub(1, 16))
          or "THE RACE",
        value = "_standings",
      }
      items[#items + 1] = {
        label = "PERFORMANCE",
        right = (M.perf.autoLowSeconds or 0) > 0 and "AUTO LOW" or "DETAILS",
        value = "_perf",
      }
      for _, rival in ipairs(M.rivals) do
        local where = rival.map and Util.spaced(rival.map) or "?"
        -- 3.4.0: REPORT WHERE A RIVAL IS, NOT WHERE IT INTENDS TO BE.
        --
        -- This line read `rival.map` alone, which is the simulation's position
        -- for a rival whether or not it managed to appear. When the Gold sprite
        -- lookup failed, the spawn correctly refused and the rival stayed
        -- abstract -- but the menu went on naming the player's own town, so the
        -- player was told somebody was standing next to them who was not there.
        --
        -- A rival on the player's map that has NOT spawned is marked, so the
        -- menu never claims a presence the player can walk up to and fail to
        -- find. Anywhere else, its map is its map and there is nothing to check.
        if rival.map and rival.map == M:playerMapId()
           and not (M.spawned and M.spawned[rival.id]) then
          where = where .. " (?)"
        end
        items[#items + 1] = {
          label = rival.name,
          right = (rival:badgeCount() .. "B " .. where):sub(1, 18),
          value = rival.id,
        }
      end
      if #M.rivals == 0 then
        items[#items + 1] = { label = "NO RIVALS", right = "OFF", value = "_none" }
      end
      -- Gen1Recomp ListMenu renders the left label and right status into the
      -- same fixed-width row.  Long pairs used to collide visually (for example
      -- STANDINGS + THE RACE, PERFORMANCE + DETAILS, and rival + location).
      -- Keep one blank character between the two columns by fitting every row to
      -- a conservative 16-character content width.  Prefer preserving the label
      -- and trim only the status text; very long labels are capped as a last
      -- resort.
      local function fitStatusRow(item)
        local label = tostring(item.label or "")
        local right = tostring(item.right or "")
        if #label > 10 then label = label:sub(1, 10) end
        local rightRoom = math.max(0, 16 - #label - 1)
        if #right > rightRoom then right = right:sub(1, rightRoom) end
        item.label, item.right = label, right
        return item
      end
      for i = 1, #items do items[i] = fitStatusRow(items[i]) end

      return mod.ui.ListMenu.new(game, "AI RIVALS", items, {
        onChoose = function(value, menu)
          -- API 2 passes the selected item record, older builds passed .value.
          -- Accept both so the status screen remains interactive everywhere.
          value = type(value) == "table" and value.value or value
          if value == "_skip_gauntlet" then
            local ok, line = M:skipGauntlet("selected from Rivals menu")
            M.ticker = { text = (ok and "RIVAL LINK  •  " or "NOTICE  •  ")
              .. tostring(line), age = 0, duration = 8, offset = 0 }
            menu:close()
            return
          end
          if value == "_news" then
            mod.ui.push(game, SCREEN .. "News", {})
            return
          end
          if value == "_standings" then
            mod.ui.push(game, SCREEN .. "Standings", {})
            return
          end
          if value == "_err" then
            mod.ui.push(game, SCREEN .. "Error", {})
            return
          end
          if value == "_perf" then
            mod.ui.push(game, SCREEN .. "Performance", {})
            return
          end
          local rival = M.byId[value]
          if not rival then menu:close() return end
          mod.ui.push(game, SCREEN .. "Detail", {
            rival = rival, items = M:rivalDetailItems(rival),
          })
        end,
      })
    end,
  })

  mod.content.screens:register(SCREEN .. "Performance", {
    new = function(game)
      local p = M.perf or {}
      local sim, walk, frame = p.simulation or {}, p.walking or {}, p.frame or {}
      local function ms(value) return string.format("%.2f MS", tonumber(value) or 0) end
      local items = {
        { label = "PROFILE", right = tostring(mod.options:get("performance") or "balanced"):upper(), value = "_line" },
        { label = "AUTO FALLBACK", right = (p.autoLowSeconds or 0) > 0
            and (tostring(math.ceil(p.autoLowSeconds)) .. " S") or "OFF", value = "_line" },
        { label = "SIM AVERAGE", right = ms(sim.average), value = "_line" },
        { label = "SIM MAXIMUM", right = ms(sim.maximum), value = "_line" },
        { label = "WALK AVERAGE", right = ms(walk.average), value = "_line" },
        { label = "WALK MAXIMUM", right = ms(walk.maximum), value = "_line" },
        { label = "FRAME AVG", right = ms(frame.average), value = "_line" },
        { label = "FRAME MAX", right = ms(frame.maximum), value = "_line" },
        { label = "SAFE REPAIRS", right = tostring(p.recoveries or 0), value = "_line" },
        { label = "RESET METRICS", right = "RESET", value = "_reset" },
      }
      return mod.ui.ListMenu.new(game, "RIVAL PERFORMANCE", items, {
        onChoose = function(value, menu)
          value = type(value) == "table" and value.value or value
          if value == "_reset" then
            M.perf.simulation = { samples = 0, average = 0, maximum = 0 }
            M.perf.walking = { samples = 0, average = 0, maximum = 0 }
            M.perf.frame = { samples = 0, average = 0, maximum = 0 }
            M.perf.autoLowSeconds, M.perf.recoveries = 0, 0
          end
          menu:close()
        end,
      })
    end,
  })

  mod.content.screens:register(SCREEN .. "Detail", {
    new = function(game, arg)
      local rival = arg and arg.rival
      local items = (arg and arg.items) or {}
      -- Keep the live interaction menu deliberately compact. Gen1Recomp draws
      -- label/status into one fixed row, so long action prose belongs in the
      -- info submenu rather than being squeezed over another column.
      for _, item in ipairs(items) do
        local label, right = tostring(item.label or ""), tostring(item.right or "")
        -- The renderer paints left and right columns independently.  Keeping the
        -- combined strings inside the nominal 16-character row is not enough:
        -- glyph widths and the right-column anchor can still make them touch.
        -- Reserve a generous visual gap and keep action/status words compact.
        if #label > 10 then label = label:sub(1, 10) end
        local room = math.max(0, 13 - #label - (right ~= "" and 2 or 0))
        if #right > room then right = right:sub(1, room) end
        item.label, item.right = label, right
      end
      local menu = mod.ui.ListMenu.new(game, rival and rival.name or "RIVAL", items, {
          onChoose = function(value, menu)
            value = type(value) == "table" and value.value or value
            if value == "_info" then
              mod.ui.push(game, SCREEN .. "Info", { rival = rival, items = M:rivalInfoItems(rival) })
              return
            end
            if value == "_goodbye" or value == "_line" then menu:close(); return end
            M:queueRivalAction(rival, value)
            menu:close()
          end,
        })
      -- ListMenu reserves Left/Right for page-jump only when pageJump=true.
      -- This screen leaves pageJump off and owns those two buttons on the
      -- CHALLENGE row, so the player can switch SINGLE <-> DOUBLE in place.
      local baseUpdate = menu.update
      menu.update = function(self, dt)
        local item = self.items and self.items[self.index]
        local value = type(item) == "table" and item.value or nil
        if value == "_challenge" and rival and M:canToggleChallengeDouble(rival)
           and (game.input:wasPressed("left") or game.input:wasPressed("right")) then
          local current = (M.challengeModes and M.challengeModes[rival.id]) or "SINGLE"
          local nextMode = current == "DOUBLE" and "SINGLE" or "DOUBLE"
          M.challengeModes = M.challengeModes or {}
          M.challengeModes[rival.id] = nextMode
          item.right = nextMode == "DOUBLE" and "2V2" or "1V1"
          pcall(function() M:save() end)
        end
        return baseUpdate(self, dt)
      end
      return menu
    end,
  })

  mod.content.screens:register(SCREEN .. "Info", {
    new = function(game, arg)
      local rival = arg and arg.rival
      local items = (arg and arg.items) or {}
      items[#items + 1] = { label = "BACK", value = "_back" }
      for _, item in ipairs(items) do
        local label, right = tostring(item.label or ""), tostring(item.right or "")
        if #label > 11 then label = label:sub(1, 11) end
        local room = math.max(0, 16 - #label - (right ~= "" and 1 or 0))
        if #right > room then right = right:sub(1, room) end
        item.label, item.right = label, right
      end
      return mod.ui.ListMenu.new(game, rival and (tostring(rival.name):sub(1, 11) .. " INFO") or "RIVAL INFO",
        items, {
          onChoose = function(value, menu)
            value = type(value) == "table" and value.value or value
            if value == "_back" or value == "_line" then menu:close(); return end
            M:queueRivalAction(rival, value)
            menu:close()
          end,
        })
    end,
  })

  -- The status row is intentionally short; this screen exposes the complete
  -- message in readable chunks so photographs and bug reports retain the path,
  -- map and operation that failed.
  mod.content.screens:register(SCREEN .. "Error", {
    new = function(game)
      local items = {}
      local history = Util.errorHistory or {}
      if #history == 0 and Util.lastError then history = { Util.lastError } end
      if #history == 0 then history = { "No error has been recorded." } end
      for h = #history, 1, -1 do
        local message = tostring(history[h]):gsub("mods/ai_rivals/", "")
          :gsub("@ai_rivals/", "")
        items[#items + 1] = { label = "ERROR " .. tostring(h), value = "_line" }
        for i = 1, #message, 30 do
          items[#items + 1] = { label = message:sub(i, i + 29), value = "_line" }
        end
      end
      items[#items + 1] = { label = "CLEAR ERROR", value = "_clear" }
      return mod.ui.ListMenu.new(game, "RIVAL ERROR", items, {
        onChoose = function(value, menu)
          value = type(value) == "table" and value.value or value
          if value == "_clear" then
            Util.lastError, Util.errorHistory = nil, {}
          end
          menu:close()
        end,
      })
    end,
  })

  -- §27: the standings. Every rival's progress in one table, so the player can
  -- see the race they are in rather than inferring it from news items.
  mod.content.screens:register(SCREEN .. "Standings", {
    new = function(game)
      local rows = {}
      for _, rival in ipairs(M.rivals) do
        rows[#rows + 1] = League.standing(rival, rival:ensureLeague(),
          rival.champion == true)
      end
      League.sortStandings(rows)
      local items = {}
      if M.playerChampion then
        items[#items + 1] = { label = "YOU", right = "CHAMPION", value = "_line" }
      end
      for _, row in ipairs(rows) do
        items[#items + 1] = {
          label = (tostring(row.name) .. "  " .. row.badges .. "B"):sub(1, 20),
          right = League.status(row):sub(1, 12),
          value = "_line",
        }
        if row.attempts > 0 then
          items[#items + 1] = {
            label = "  league",
            right = ("%dx best %d"):format(row.attempts, row.best):sub(1, 14),
            value = "_line",
          }
        end
      end
      if #items == 0 then items[1] = { label = "NO RIVALS", value = "_line" } end
      return mod.ui.ListMenu.new(game, "STANDINGS", items, {
        onChoose = function(_, menu) menu:close() end,
      })
    end,
  })

  -- One rival's achievements (§21). Locked entries are shown as blanks rather
  -- than hidden, so the list reads as a trainer card rather than as a mystery.
  mod.content.screens:register(SCREEN .. "Story", {
    new = function(game, arg)
      local rival = arg and arg.rival
      local items = {}
      if rival then
        local story = rival:ensureStory()
        items[#items + 1] = { label = "CHAPTER",
          right = rival:chapterLabel():upper():sub(1, 16), value = "_line" }
        items[#items + 1] = { label = "MOOD",
          right = rival:moodLabel():upper():sub(1, 16), value = "_line" }
        for _, milestone in ipairs(Story.MILESTONES) do
          local got = story.unlocked[milestone.id] ~= nil
          items[#items + 1] = {
            label = (got and milestone.label or "- - -"):sub(1, 26),
            right = got and "DONE" or "",
            value = "_line",
          }
        end
      end
      if #items == 0 then items[1] = { label = "NO STORY YET", value = "_line" } end
      return mod.ui.ListMenu.new(game, rival and rival.name or "STORY", items, {
        onChoose = function(_, menu) menu:close() end,
      })
    end,
  })

  -- The world-news screen: everything the rivals have been up to, freshest
  -- last, read-only.
  mod.content.screens:register(SCREEN .. "News", {
    new = function(game)
      local items = {}
      for _, entry in ipairs(M.news or {}) do
        items[#items + 1] = {
          label = (entry.text or ""):sub(1, 32),
          right = tostring(entry.tick or ""),
          value = "_n",
        }
      end
      if #items == 0 then
        items[1] = { label = "THE WORLD IS QUIET.", value = "_n" }
      end
      return mod.ui.ListMenu.new(game, "WORLD NEWS", items, {
        onChoose = function(_, menu) menu:close() end,
      })
    end,
  })

  mod.hooks:wrap("ui.start_menu.items", function(next, game, items)
    local out = next(game, items)
    if type(out) ~= "table" then return out end
    if not M.rivals or #M.rivals == 0 then return out end
    return mod.ui.insertBefore(out, "SAVE", {
      label = "RIVALS",
      onSelect = function() mod.ui.push(game, SCREEN) end,
    })
  end)
end

return Status
