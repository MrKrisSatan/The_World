local req, mod = ...

-- WHICH GAME ARE WE IN?
--
-- Detected from the CONTENT of the loaded dataset, never from a version
-- string.  `docs/mod-api-gen2-compat.md` is explicit that a mod which
-- allow-lists `GameVersion.get() == "red"` excludes itself from Gold by
-- construction, and requiring `src.core.GameVersion` needs `engine_internals`
-- and has no Gen 2 facade at all.  Sniffing the data has neither problem, is
-- free, works headless in a test, and -- the part that actually matters --
-- degrades correctly for a game nobody anticipated: a total conversion that
-- carries Yellow's surfing Pikachu really is Yellow-shaped, and one that
-- carries none of these signals falls through to the default arm rather than
-- to a wrong answer.
--
-- The signals, weakest assumption first:
--
--   gen2    data.gen2Maps / data.gen2Trainers exist.  Gold loads its own
--           tables under those names; a Gen 1 boot has neither.
--   yellow  SPRITE_SURFING_PIKACHU is in the sprite table.  tools/
--           build_rom_data.py emits that record only when the ROM carries the
--           surfing-Pikachu sheet, which is Yellow and nothing else.  The
--           follower sprite is checked as a second witness so a mod that
--           registered a surfing sheet of its own does not flip the answer on
--           its own.
--   gen1    anything else: Red, Blue, or a conversion built on them.  This
--           mod never needs to tell Red from Blue -- they field the same
--           starting trio -- so it does not try.

local Version = {}

local function has(data, table_, key)
  local t = data and data[table_]
  return type(t) == "table" and t[key] ~= nil
end

function Version.detect(data)
  if not data then return "gen1" end
  if data.gen2Maps or data.gen2Trainers then return "gen2" end

  local surfing = has(data, "sprites", "SPRITE_SURFING_PIKACHU")
  local follower = has(data, "sprites", "SPRITE_PIKACHU")
    or has(data, "pokemon", "PIKACHU")
  if surfing and follower then return "yellow" end

  return "gen1"
end

-- The starter set key a roster row is looked up under.  Kept separate from
-- detect() so a caller can override it (a test, a debug verb) without
-- pretending the whole dataset is a different game.
function Version.starterKey(data)
  local id = Version.detect(data)
  if id == "yellow" then return "yellow" end
  if id == "gen2" then return "gen2" end
  return "default"
end

return Version
