
local req, mod = ...
-- 5.0.8: these four were LOCALS of main.lua before the 5.0.0 modular split.
-- An extracted chunk gets its own scope, so every one of them resolved to a
-- nil GLOBAL here -- which is the "attempt to index global 'Util'" crash on
-- the first save. Requiring them is the whole fix; req() is memoised so this
-- is the same table main.lua holds.
local Util = req("src/Util")
local Rival = req("src/Rival")
local Comms = req("src/Comms")
local Ecology = req("src/Ecology")
local WorldState = req("src/WorldState")
local Version = req("src/Version")
local Dialogue = req("src/Dialogue")
local Presence = req("src/Presence")
local Tournaments = req("src/Tournaments")
local Factions = req("src/Factions")
local C = nil
local Persistence = {}

function Persistence.install(modApi, M)
  mod = modApi or mod
  C = M._ctx or {}
  local SAVE_VERSION = C.SAVE_VERSION
  local gauntletLabId = C.gauntletLabId
  local resolveGauntletLab = C.resolveGauntletLab
  local homeMapsFor = C.homeMapsFor

function M:save()
  if not self.ready then return end
  local out = { version = SAVE_VERSION, tick = self.sim and self.sim.tick or 0,
                rivals = {} }
  for _, rival in ipairs(self.rivals) do
    -- A mod-state problem must never veto/corrupt the base game's save.
    local ok, record = pcall(function() return rival:serialize() end)
    if ok and type(record) == "table" then
      out.rivals[rival.id] = record
    else
      -- Minimal recovery record preserves identity/progression and is composed
      -- entirely of scalar/plain-table values accepted by the host serializer.
      out.rivals[rival.id] = {
        id=rival.id,name=rival.name,personalityId=rival.personalityId,
        state=rival.state,map=rival.map,x=rival.x,y=rival.y,
        party=Util.copy(rival.party or {}),badges=Util.copy(rival.badges or {}),
        trainerClassId=rival.trainerClassId,
        happiness=tonumber(rival.happiness) or 60,mood=tostring(rival.mood or "CONTENT"),
      }
    end
  end
  if self.gauntlet and not self.gauntletFinished then
    out.gauntlet = Util.copy(self.gauntlet)
  end
  out.gauntletFinished = self.gauntletFinished == true
  out.eliteChampionId = self.eliteChampionId
  out.blueChampion = self.blueChampion
  out.playerChampion = self.playerChampion == true
  out.companionId = self.companionId
  out.worldStartPending = self.worldStartPending == true
  out.specials = {}
  for _, rival in ipairs(self.rivals or {}) do
    if rival and rival.def and rival.def.rareSpecial then
      out.specials[#out.specials + 1] = rival.id
    end
  end
  -- rivalCount remains the player's ordinary-rival setting; rare specials are
  -- an independent layer and must not inflate the setting on reload.
  out.rivalCount = math.max(0, #self.rivals - #out.specials)
  out.news = Util.copy(self.news or {})
  out.rocket = self.rocket and self.rocket:serialize() or nil
  out.rangers = self.rangers and self.rangers:serialize() or nil
  out.factions = self.factions and self.factions:serialize() or nil
  out.rocketDisguise = self.rocketDisguise and self.rocketDisguise:serialize() or nil
  out.stolenRecovery = self.stolenRecovery and self.stolenRecovery:serialize() or nil
  out.rivalWars = self.rivalWars and self.rivalWars:serialize() or nil
  out.scheduledTournaments = Util.copy(self.scheduledTournaments or {})
  out.quests = self.quests and self.quests:serialize() or nil
  -- 1.36.0: the "recently seen" log is world state, not rival state -- it is
  -- what the PLAYER noticed, so it lives here rather than on any one rival.
  out.presence = Presence.serialize(self.presence)
  -- 2.1.0 §32: the life-path seed. Written once and never recomputed, so a
  -- rival's destiny is the same on every load of this save.
  out.pathSeed = self.pathSeed
  out.seedValue = self.seedValue
  -- 3.0.0: the player's contacts. World state, not rival state -- a phone book
  -- belongs to whoever owns the phone.
  out.comms = Comms.serialize(self.comms)
  out.radioStation = self.radioStation
  out.radioEnabled = self.radioEnabled == true
  out.customMusicFolder = self.customMusicFolder
  out.customMusicTrack = self.customMusicTrack
  out.challengeModes = Util.copy(self.challengeModes or {})
  out.tournaments = self.tournaments and self.tournaments:serialize() or nil
  -- 5.2.0: only the hunting EVENTS. A population is derived from the static
  -- table plus these, every read -- storing the population itself would make
  -- the encounter table and the save two sources for one fact (§26), and the
  -- population is fully recoverable from what remains, which is the house
  -- test for whether something is stored at all.
  out.ecology = self.ecology and self.ecology:serialize(self.tick) or nil
  out.worldState = self.worldState and self.worldState:serialize() or nil
  mod.save:set("state", out)
  -- Durable one-bit backup so a partial state blob cannot re-open the intro
  pcall(function()
    mod.save:set("gauntletFinished", self.gauntletFinished == true)
  end)
end

function M:syncRivalComms()
  self.comms = self.comms or Comms.new(nil)
  for _, rival in ipairs(self.rivals or {}) do
    if rival.phoneContact then
      local id = "PHONE_AIR_" .. string.upper(tostring(rival.id))
      local record = Comms.offer(self.comms, id, {
        name = rival.name,
        kind = "RIVAL",
        trainerId = rival.def and rival.def.trainerClass,
      }, self.seedValue or self.pathSeed or 0)
      if record then
        record.name = rival.name
        record.kind = "RIVAL"
        record.trainerId = rival.def and rival.def.trainerClass
        record.rivalId = rival.id
        record.number = tostring(rival.phoneNumber)
        record.offered = true
        record.accepted = true
      end
    end
  end
end

function M:load()
  if not self.ready then return end
  local saved = mod.save:get("state")
  if self.rocket and type(saved) == "table" then
    pcall(function() self.rocket:load(saved.rocket) end)
  end
  if self.rangers and type(saved) == "table" then
    pcall(function() self.rangers:load(saved.rangers) end)
  end
  if type(saved) == "table" then
    self.factions = Factions.new(saved.factions)
    if self.rocketDisguise then pcall(function() self.rocketDisguise:load(saved.rocketDisguise) end) end
    if self.stolenRecovery then pcall(function() self.stolenRecovery:load(saved.stolenRecovery) end) end
    if self.rivalWars then pcall(function() self.rivalWars:load(saved.rivalWars) end) end
    if type(saved.scheduledTournaments) == "table" then
      self.scheduledTournaments = saved.scheduledTournaments
    end
  end
  if self.quests and type(saved) == "table" then
    pcall(function() self.quests:restore(saved.quests) end)
  end
  if type(saved) == "table" and tonumber(saved.rivalCount) then
    self:setRivalCount(saved.rivalCount)
  end
  local rivals = type(saved) == "table" and saved.rivals or nil
  if self.sim and type(saved) == "table" then
    self.sim.tick = tonumber(saved.tick) or 0
  end
  -- Absent in a pre-1.36 save, which yields an empty log: the player has not
  -- been told about sightings that happened before the system existed.
  self.presence = Presence.new(type(saved) == "table" and saved.presence or nil)
  self.pathSeed = type(saved) == "table" and tonumber(saved.pathSeed) or nil
  -- Absent in a pre-3.0 save, which yields an empty phone book: no contact is
  -- invented for a trainer the player beat before the network existed.
  self.comms = Comms.new(type(saved) == "table" and saved.comms or nil)
  self:syncRivalComms()
  self.radioStation = type(saved) == "table" and saved.radioStation or "POKEMON_MUSIC"
  self.radioEnabled = type(saved) == "table" and saved.radioEnabled == true or false
  self.customMusicFolder = type(saved) == "table" and saved.customMusicFolder or "custom_music"
  self.customMusicTrack = type(saved) == "table" and saved.customMusicTrack or nil
  self.customMusicSource = nil
  -- Custom audio is never auto-opened from an arbitrary host path. The user's selected folder is inside this mod so the sandbox remains authoritative.
  if self.radioStation == "CUSTOM_MUSIC" and not self.customMusicTrack then self.radioEnabled = false end
  self.challengeModes = type(saved) == "table" and type(saved.challengeModes) == "table"
    and Util.copy(saved.challengeModes) or {}
  if not self.tournaments then self.tournaments = Tournaments.new(self) end
  self.ecology = self.ecology or Ecology.new({ seed = self:worldSeed() })
  self.worldState = self.worldState or WorldState.new(self)
  self.ecology.seed = self:worldSeed()
  self.ecology:load(type(saved) == "table" and saved.ecology or nil)
  self.worldState:load(type(saved) == "table" and saved.worldState or nil)
  self.tournaments:restore(type(saved) == "table" and saved.tournaments or nil)
  self.seedValue = type(saved) == "table" and tonumber(saved.seedValue) or nil
  -- A pre-2.6 save has a pathSeed but no world seed. Adopt the one it has
  -- rather than minting a new one: its rivals were dealt their starters under
  -- the old scheme and its destiny was decided under that number.
  if not self.seedValue and self.pathSeed then self.seedValue = self.pathSeed end
  -- Numbers and contact state come back with the rivals themselves; the Gen 2
  -- registry does not survive a boot, so contacts are re-registered rather
  -- than regenerated -- regenerating would hand the player a new number for a
  -- contact they already have.
  if self.phone then
    Util.guard("phone", function()
      self.phone:bootstrapAll()
      self.phone:registerContacts()
    end)
  end
  self.eliteChampionId = type(saved) == "table" and saved.eliteChampionId or nil
  self.blueChampion = type(saved) == "table" and saved.blueChampion or nil
  self.playerChampion = type(saved) == "table" and saved.playerChampion == true
  self.companionId = type(saved) == "table" and saved.companionId or nil
  if self.companionId and not self.byId[self.companionId] then
    self.companionId = nil
  end
  self.worldStartPending = type(saved) == "table" and saved.worldStartPending == true
  -- 7.3.5 migration: older SKIP saves persisted the obsolete "wait for player
  -- starter/Blue battle" brake. A skip choice now means immediate activation.
  pcall(function()
    if mod.save and mod.save.get and mod.save:get("gauntletMode") == "skip" then
      self.worldStartPending = false
    end
  end)
  self.news = type(saved) == "table" and type(saved.news) == "table"
    and Util.copy(saved.news) or {}
  self.tickerQueue = {}
  self.ticker = { text = nil, age = 0, duration = 8, offset = 0 }
  self.pendingRivalMenu, self.pendingRivalAction = nil, nil
  self.pendingMapMaterialize = nil
  self.connectionYieldActive = false
  self.connectionYieldMap = nil
  self.rivalInteractionOpen = false
  for _, rival in ipairs(self.rivals) do
    local record = rivals and rivals[rival.id]
    if not (record and rival:restore(record)) then
      -- only seed an EMPTY party: a rival already holding its starter must
      -- not gain another when boot and New Game both walk this loop
      if #rival.party == 0 then self:seed(rival) end
    end
    -- Migrate saves made before canonical area gates existed. A rival already
    -- parked beyond its private badge/HM progress cannot legally route back
    -- because all adjoining maps may be gated too, so recover it to its first
    -- accessible home. This changes location only; badges, party, PC and goals
    -- remain private and intact.
    if rival.map and rival.canEnterMap and not rival:canEnterMap(rival.map) then
      local recovery
      for _, id in ipairs(homeMapsFor(rival.def)) do
        if self.graph:has(id) and rival:canEnterMap(id) then recovery = id break end
      end
      rival.map = recovery or rival.map
      rival.x, rival.y, rival.spawnedAt = nil, nil, nil
      rival.destination, rival.route, rival.routeIndex = nil, nil, 1
      rival.path, rival.hopClock = nil, nil
      rival:setState("IDLE", "returned behind progression gate")
    end
    -- Old saves and removed map packs can leave navigation pointing at maps
    -- that no longer exist. Preserve all progression, but return the rival to
    -- a valid home and discard only the impossible route/destination.
    if not (rival.map and self.graph:has(rival.map)) then
      local home
      for _, id in ipairs(homeMapsFor(rival.def)) do
        if self.graph:has(id) then home = id break end
      end
      rival.map = home or next(self.graph.nodes)
      rival.x, rival.y, rival.spawnedAt = nil, nil, nil
      rival.route, rival.routeIndex = nil, 1
      rival.destination = nil
      rival:setState("IDLE", "recovered from missing map")
    elseif rival.destination and not self.graph:has(rival.destination) then
      rival.destination, rival.route, rival.routeIndex = nil, nil, 1
      rival:setState("IDLE", "destination no longer exists")
    else
      local validRoute = type(rival.route) == "table"
      if validRoute then
        for _, id in ipairs(rival.route) do
          if not self.graph:has(id) then validRoute = false break end
        end
      end
      if not validRoute then
        rival.route, rival.routeIndex = nil, 1
        if rival.destination then
          pcall(function() rival:setDestination(rival.destination) end)
        end
      end
    end
  end
  self:seedAffectionGraph()
  -- the gauntlet restores its own bookkeeping; a bucket without one (an
  -- older save, or a playthrough past the intro) stays inactive
  -- Finished flag: explicit, durable, never guessed away on load.
  -- Backup key on mod.save in case the state blob was partial.
  local finished = false
  if type(saved) == "table" and saved.gauntletFinished == true then
    finished = true
  end
  pcall(function()
    if mod.save:get("gauntletFinished") == true
        or mod.save:get("gauntletMode") == "skip" then finished = true end
  end)
  -- Infer finished from progress if older saves omitted the flag
  if not finished then
    for _, rival in ipairs(self.rivals) do
      if rival:badgeCount() > 0 then finished = true break end
      if rival.map and rival.map ~= gauntletLabId()
         and rival.map ~= "PALLET_TOWN" and rival.map ~= "NEW_BARK_TOWN"
         and #rival.party > 0 and (rival.ticks or 0) > 20 then
        finished = true
        break
      end
    end
  end
  self.gauntletFinished = finished

  local g = type(saved) == "table" and saved.gauntlet or nil
  local order = {}
  if type(g) == "table" and type(g.order) == "table" then
    for _, id in ipairs(g.order) do
      if self.byId[id] then order[#order + 1] = id end
    end
  end
  local lab = resolveGauntletLab(self.graph)

  if finished then
    -- Never re-arm the intro gauntlet after it is done
    self.gauntlet = nil
  elseif type(g) == "table" and g.active and #order > 0 and lab then
    local restoredPhase = g.phase or "wait_blue"
    -- Dialogue callbacks and battle launcher closures are deliberately not
    -- serialized. A save made during either transient phase must resume at the
    -- safe one-shot challenge boundary instead of waiting for a callback that
    -- no longer exists.
    if restoredPhase == "dialogue" or restoredPhase == "launch_battle"
        or restoredPhase == "battling" then
      restoredPhase = "challenge"
    end
    self.gauntlet = {
      active = true,
      index = math.max(1, tonumber(g.index) or 1),
      order = order,
      lab = lab,
      phase = restoredPhase,
      phaseT = 0,
      challenging = false,
      lastResolvedIndex = tonumber(g.lastResolvedIndex),
    }
    for _, rival in ipairs(self.rivals) do
      if rival.map ~= lab then
        rival.map = lab
        rival.x, rival.y = nil, nil
        pcall(function() rival:setDestination(nil) end)
        if #rival.party == 0 then
          local species = Rival.firstAvailableStarter(rival.def, self.versionKey,
                                                      self.data and self.data.pokemon,
                                                      nil, self:starterOpts(nil, nil, nil, rival.personality))
          if species then pcall(function() rival:addPokemon(species, 5) end) end
        end
        pcall(function() rival:setState("IDLE", "in the lab") end)
      end
    end
  else
    self.gauntlet = nil
  end
  self:syncGen2Parties()
end

function M:syncGen2Party(rival)
  if not (rival and self.generation == 2) then return end
  local classes = self.data and self.data.gen2Trainers and self.data.gen2Trainers.classes
  -- the rival's own class when it registered one, or the story class it rides
  local class = classes and (classes[rival.def.trainerClass]
    or (rival.def.gen2Shadow and classes[rival.def.gen2Shadow]))
  local members = class and class.trainers
  if type(members) ~= "table" then return end
  local rows = {}
  for _, mon in ipairs(rival.party) do
    rows[#rows + 1] = { species = mon.species, level = mon.level,
      dvs = mon.dvs and Util.copy(mon.dvs) or nil,
      shiny = mon.shiny == true, ace = mon.ace == true }
  end
  if #rows == 0 then return end
  for _, row in ipairs(members) do
    if type(row) == "table" then row.party = Util.copy(rows) end
  end
end

function M:syncGen2Parties()
  for _, rival in ipairs(self.rivals) do
    self:syncGen2Party(rival)
  end
end
end

return Persistence
