
local req, mod = ...
-- 5.0.8: locals of main.lua before the modular split; nil globals here.
local Util = req("src/Util")
local Rival = req("src/Rival")
local AI = req("src/AI")
local Pathfinder = req("src/Pathfinder")
local C = nil
local Gauntlet = {}


local function requireBattleState()
  local candidates = {
    "src.battle.BattleState",
    "battle.BattleState",
    "BattleState",
  }
  local errors = {}
  for _, name in ipairs(candidates) do
    local ok, value = pcall(require, name)
    if ok and value then return value end
    errors[#errors + 1] = tostring(value)
  end
  error("AI Rivals: could not load BattleState (" .. table.concat(errors, " | ") .. ")")
end

function Gauntlet.install(modApi, M)
  mod = modApi or mod
  C = M._ctx or {}
  local GAUNTLET_LAB_CANDIDATES = C.GAUNTLET_LAB_CANDIDATES
  local GAUNTLET_DETECT = C.GAUNTLET_DETECT
  local GAUNTLET_ENGAGE = C.GAUNTLET_ENGAGE
  local GAUNTLET_STEP_S = C.GAUNTLET_STEP_S
  local POST_LAB_STARTS_BY_KEY = C.POST_LAB_STARTS_BY_KEY
  local LAB_SLOTS = C.LAB_SLOTS
  local ROSTER = C.ROSTER
  local BattleState = requireBattleState()
  local Game = (rawget(_G, "Game") or nil)
  local PathfinderLocal = Pathfinder
  local gauntletLabId = C.gauntletLabId
  local postLabStarts = C.postLabStarts
  local runningOnIOS = C.runningOnIOS
  -- 5.0.8: activeRoster is a main.lua local too, and unlike the modules above
  -- it is not requireable -- it closes over mod.save/mod.options. It now comes
  -- through the same _ctx seam as every other main.lua value this file needs.
  local activeRoster = C.activeRoster
  -- Module-local aliases are captured here so extracted methods retain the
  -- original closure dependencies without duplicating manager state.

function M:gauntletActive()
  local g = self.gauntlet
  return g ~= nil and g.active == true and type(g.order) == "table"
    and #g.order > 0
end

function M:gauntletRival()
  if not self:gauntletActive() then return nil end
  return self.byId[self.gauntlet.order[self.gauntlet.index]]
end

function M:gauntletDone()
  if self.gauntletFinished == true then return true end
  if self.gauntlet and self.gauntlet.finished == true then return true end
  -- Durable one-bit key is the ultimate authority. Never re-open once set.
  local durable = false
  pcall(function()
    if mod.save and mod.save.get and (mod.save:get("gauntletFinished") == true
        or mod.save:get("gauntletMode") == "skip") then
      durable = true
    end
  end)
  if durable then
    self.gauntletFinished = true
    if self.gauntlet then self.gauntlet.finished = true; self.gauntlet.active = false end
    return true
  end
  return false
end

function M:blueLabBattled()
  if self.blueBattled == true then return true end
  local names = {
    "EVENT_BATTLED_RIVAL_IN_OAKS_LAB",
    "EVENT_BEAT_OAKS_LAB_RIVAL",
    "EVENT_OAKS_LAB_RIVAL_BEATEN",
  }
  local function flagTrue(flags, name)
    if type(flags) ~= "table" then return false end
    local v = flags[name]
    return v == true or v == 1 or v == "true"
  end
  local save = self.game and self.game.save
  local flags = save and save.flags
  for _, name in ipairs(names) do
    if flagTrue(flags, name) then
      self.blueBattled = true
      return true
    end
  end
  pcall(function()
    local okFlags, Flags = pcall(function()
      return require("src.script.Flags")
    end)
    if okFlags and Flags and Flags.get and save then
      for _, name in ipairs(names) do
        if Flags.get(save, name) then
          self.blueBattled = true
        end
      end
    end
  end)
  if self.blueBattled then return true end
  pcall(function()
    if mod.flags and mod.flags.get then
      for _, name in ipairs(names) do
        if mod.flags:get(name) then self.blueBattled = true end
      end
    end
  end)
  return self.blueBattled == true
end

function M:beginGauntlet()
  -- Absolute one-time gate. Once the durable flag is set, never re-arm.
  pcall(function()
    if mod.save and mod.save.get and mod.save:get("gauntletFinished") == true then
      self.gauntletFinished = true
      if self.gauntlet then
        self.gauntlet.active = false
        self.gauntlet.finished = true
      end
    end
  end)
  if self:gauntletDone() then
    return false
  end
  -- Extra safety: if we somehow still have a finished structure, refuse.
  if self.gauntlet and self.gauntlet.finished then
    self.gauntletFinished = true
    return false
  end
  local lab = gauntletLabId()
  -- 2.7.0: no lab, no gauntlet. Previously the resolver returned "OAKS_LAB"
  -- whatever the game was, so on Gold this armed a sequence pointed at a room
  -- that does not exist -- which is what put four rivals "waiting in Oak's
  -- Lab" on a game that has no Oak's Lab.
  if not lab then return false end
  local order = {}
  -- Prefer live rivals list; fall back to roster defs
  -- 5.0.9: rare specials join the WORLD, never the opening queue. See the
  -- matching filter in main.lua's setRivalCount.
  local function ordinaryDef(def)
    return type(def) == "table" and not def.rareSpecial
  end
  if type(self.rivals) == "table" and #self.rivals > 0 then
    for _, r in ipairs(self.rivals) do
      if r and r.id and ordinaryDef(r.def) then order[#order + 1] = r.id end
    end
  else
    local ok, roster = pcall(activeRoster)
    if ok and type(roster) == "table" then
      for _, def in ipairs(roster) do
        if ordinaryDef(def) then order[#order + 1] = def.id end
      end
    end
  end
  if #order == 0 then
    for _, def in ipairs(ROSTER) do order[#order + 1] = def.id end
  end

  -- 3.3.0: THE GAUNTLET IS CAPPED, THE WORLD IS NOT.
  --
  -- Every selected rival lives in the world; only the first
  -- M.GAUNTLET_MAX of them queue up in the lab. Four consecutive battles is
  -- already a long opening -- eight would be a wall between the player and
  -- Route 1 -- so the roster and the gauntlet are now separate numbers rather
  -- than the same one by accident.
  --
  -- The rivals left out are not removed or delayed: they are seeded straight
  -- into the world alongside the others when the gauntlet ends, so "all
  -- rivals in the game at once" holds however large the roster gets.
  while #order > M.GAUNTLET_MAX do table.remove(order) end

  -- Set active FIRST so status never stays on "pending" if later work fails.
  self.gauntlet = {
    active = true, index = 1, order = order, lab = lab,
    phase = "wait_blue", phaseT = 0, challenging = false,
  }
  -- Never clear a previously-set finished flag. Only reach here if not done.
  self.gauntletFinished = false

  for _, rival in ipairs(self.rivals or {}) do
    rival.map = lab
    rival.x, rival.y = nil, nil
    rival.destination = nil
    rival.route = nil
    rival.routeIndex = 1
    rival.path = nil
    if #rival.party == 0 then
      local species
      pcall(function()
        species = Rival.firstAvailableStarter(
          rival.def, self.versionKey, self.data and self.data.pokemon,
          nil, self:starterOpts(nil, nil, nil, rival.personality))
      end)
      if not species and self.data and type(self.data.pokemon) == "table" then
        -- Yellow-safe defaults
        for _, cand in ipairs({ "CHARMANDER", "SQUIRTLE", "BULBASAUR",
                                "PIKACHU", "RATTATA", "PIDGEY" }) do
          if self.data.pokemon[cand] then species = cand break end
        end
        if not species then
          for id, _ in pairs(self.data.pokemon) do species = id break end
        end
      end
      if species then
        pcall(function() rival:addPokemon(species, 5) end)
      end
    end
    pcall(function() rival:setState("IDLE", "in the lab") end)
  end

  pcall(function()
    local world = self:worldView()
    if world and lab and world.playerMap == lab then
      self:spawnFor(lab)
    end
  end)
  return true
end

function M:holdGauntletInLab()
  if self:gauntletDone() then return end
  if not self.gauntlet or not self.gauntlet.active then
    if not self:beginGauntlet() then return end  -- begin itself refuses if done
  end
  local lab = (self.gauntlet and self.gauntlet.lab) or gauntletLabId()
  for _, rival in ipairs(self.rivals) do
    rival.map = lab
    rival.destination = nil
    rival.route = nil
  end
end

function M:healPlayerParty()
  local party = self.game and self.game.save and self.game.save.party
  if type(party) ~= "table" then return end
  local ok, Pokemon = pcall(require, "src.pokemon.Pokemon")
  for _, mon in ipairs(party) do
    if type(mon) == "table" and mon.stats and mon.stats.hp then
      if ok and type(Pokemon.heal) == "function" then
        Util.guard("gauntlet:heal", Pokemon.heal, mon)
      else
        mon.hp = mon.stats.hp
        mon.status = nil
      end
    end
  end
end

function M:gauntletLine(rival, bucket)
  local current = self:gauntletRival()
  local raw = self.dialogue:pick(rival, bucket or {}, 8)
  if not raw then return (rival.name .. ": ...") end
  local tokens = self.dialogue:tokens(rival)
  tokens.NAME = current and current.name or "the next rival"
  return self.dialogue:expand(raw, tokens)
end

function M:talkGauntlet(rival)
  local current = self:gauntletRival()
  if not current then return nil end
  local g = self.gauntlet
  local party = self.game and self.game.save and self.game.save.party
  if current == rival then
    -- The director owns an automatic challenge once this slot has begun. An A
    -- press can arrive again while the text box is closing; returning no rows
    -- prevents that input from queuing a second copy of the same conversation
    -- (and a second battle) behind the first one.
    if g and (g.dialogueIndex == g.index or g.phase == "dialogue"
        or g.phase == "launch_battle" or g.phase == "battling"
        or g.challenging) then
      return nil
    end
    if type(party) ~= "table" or #party == 0 then
      return { { "show_text",
        self:gauntletLine(rival, self.dialogue.lines.gauntletNeedStarter) } }
    end
    self.pending = rival
    -- Record the exact gauntlet battle that is currently live. Both
    -- battle.ended and world.blacked_out can fire for one encounter, so the
    -- resolver must be able to recognise and ignore a duplicate event.
    if self.gauntlet then
      self.gauntlet.activeBattleRival = rival.id
      self.gauntlet.activeBattleIndex = self.gauntlet.index
    end
    rival:setState("CHALLENGING_PLAYER", "gauntlet")
    return {
      { "show_text", self.dialogue:challenge(rival) },
      { "start_battle", "trainer", rival.def.trainerClass, 1 },
    }
  end
  return { { "show_text", self:gauntletLine(rival, self.dialogue.lines.gauntletWait) } }
end

function M:endGauntletBattle(rival)
  local g = self.gauntlet
  if not (g and g.active) then return end
  -- Only the currently active gauntlet battle can advance the sequence. This
  -- blocks a stale battle event, a duplicate callback, or a normal trainer
  -- battle from consuming another rival's turn.
  if g.activeBattleRival and rival and g.activeBattleRival ~= rival.id then
    return
  end
  if g.activeBattleIndex and g.activeBattleIndex ~= g.index then
    return
  end
  -- Accept the fight even if index drifted: match by order membership
  local idx = g.index
  -- battle.ended and world.blacked_out can both fire for the same loss.
  -- Resolve a given Gauntlet slot only once, otherwise the index advances twice
  -- and the player is forced to repeat or skip battles.
  if g.lastResolvedIndex == idx then return end
  if rival and g.order[idx] ~= rival.id then
    for i, id in ipairs(g.order) do
      if id == rival.id then idx = i break end
    end
  end
  if rival and g.order[idx] ~= rival.id then
    -- Still not a gauntlet rival; ignore
    return
  end
  self:healPlayerParty()
  g.lastResolvedIndex = idx
  g.activeBattleRival = nil
  g.activeBattleIndex = nil
  g.dialogueIndex = nil
  g.launchTries = 0
  self._gauntletBattleLauncher = nil
  self._gauntletQueued = false
  self.pending = nil
  g.index = (idx or g.index) + 1
  g.phase = "between"
  g.phaseT = 0
  g.challenging = false
  if g.index > #g.order then
    self:finishGauntlet()
  end
  self:save()
end

function M:finishGauntlet()
  if self.gauntletFinished then return end
  -- Set the durable one-time flag FIRST so any concurrent enter/tick
  -- cannot re-arm the sequence. This is the permanent completion bit.
  self.gauntletFinished = true
  pcall(function()
    if mod.save and mod.save.set then
      mod.save:set("gauntletFinished", true)
    end
  end)
  local g = self.gauntlet
  if g then
    g.active = false
    g.finished = true
  end

  -- Prevent the normal rival challenge system from firing the moment
  -- the four leave the lab (the "level 13 Clefairy rematch" bug).
  for _, r in ipairs(self.rivals or {}) do
    r.encounterCooldown = math.max(r.encounterCooldown or 0, 1200)  -- long lock
    -- 1.11.0: no free balls on leaving the lab.  Rivals start with the
    -- player's pocket money and buy Poké Balls at the first mart / center
    -- they heal at (Rival:restockBalls), so balls come from money won in
    -- battles, never from thin air.
    pcall(function()
      if r.setState then r:setState("TRAVELLING", "post-gauntlet lock") end
    end)
  end

  -- Hard-clear every lab NPC we own
  pcall(function() self:despawnAll() end)
  pcall(function()
    local ow = self.game and self.game.overworld
    if ow and ow.map and ow.map.npcs and ow.map.id == gauntletLabId() then
      local remove = {}
      for i, npc in ipairs(ow.map.npcs) do
        local name = npc.def and npc.def.name
        if type(name) == "string" and name:match("^AIR_") then
          remove[#remove + 1] = i
        end
      end
      for j = #remove, 1, -1 do
        table.remove(ow.map.npcs, remove[j])
      end
    end
  end)
  self.spawned = {}

  for i, r in ipairs(self.rivals) do
    local start = postLabStarts()[((i - 1) % #postLabStarts()) + 1]
    local home = start.map
    -- Do not replace these progression-safe starts with personality homes.
    -- That previously put Chris back in Pallet Town beside Oak's Lab while his
    -- abstract state claimed he was training. The first rival now begins on
    -- Route 1, and every start is reachable without badges or HMs.
    r.map = home
    r.x, r.y = nil, nil
    -- Pay for enough early-route capture attempts even when this scatter start
    -- bypasses Viridian's mart. This is purchased stock, never a free grant.
    pcall(function() if r.buyDepartureBalls then r:buyDepartureBalls(5) end end)
    r.destination = nil
    r.route = nil
    r.routeIndex = 1
    r.path = nil
    r.spawnedAt = nil
    pcall(function()
      r:setState("TRAVELLING", "left the lab")
      r.objective = "TRAIN"
      if r.setDestination then
        r:setDestination(start.dest or "VIRIDIAN_CITY")
      else
        r.destination = start.dest or "VIRIDIAN_CITY"
      end
    end)
    pcall(function() AI.evaluate(r, self:worldView()) end)
    -- If AI.evaluate left them on the lab, force them out again
    if r.map == gauntletLabId() then
      r.map = home
      r.destination = start.dest or "ROUTE_1"
    end
  end

  self.gauntlet = nil
  self:save()
end

function M:skipGauntlet(reason)
  -- Release first. Setting gauntletMode=skip before finishGauntlet would make
  -- gauntletDone return true and strand already-created rivals in Oak's Lab.
  if not self.gauntletFinished then self:finishGauntlet() end
  pcall(function()
    if mod.save and mod.save.set then mod.save:set("gauntletMode", "skip") end
  end)
  self.gauntlet = nil
  self._gauntletStarting = false
  self._gauntletQueued = false
  self._gauntletBattleLauncher = nil
  self.pending = nil
  -- SKIP means the rival world begins immediately. The player deliberately
  -- opted out of the opening gauntlet, so there is no reason to freeze 100
  -- other trainers until Oak hands the player a starter. They can travel,
  -- catch, train and battle while the player's opening story is still running.
  self.worldStartPending = false
  pcall(function() self:save() end)
  return true, "Rival gauntlet skipped" .. (reason and (" (" .. reason .. ").") or ".")
end

function M:gauntletStepTowardPlayer(rival, world)
  if not (rival and world and world.playerX and world.playerY) then return false end
  local rx = rival.x or 3
  local ry = rival.y or 6
  local px, py = world.playerX, world.playerY
  local dist = math.abs(px - rx) + math.abs(py - ry)
  if dist <= GAUNTLET_ENGAGE then return true end

  local grid = self:labWalkGrid()
  local path
  pcall(function()
    path = Pathfinder.find(grid, rx, ry, px, py, {
      adjacent = true,
      budget = 300,
    })
  end)

  local nx, ny, facing = rx, ry, nil
  if type(path) == "table" and #path > 0 then
    local step = path[1]
    nx, ny = step.x, step.y
    facing = step.dir
  else
    -- Greedy step only onto walkable cells
    local dx, dy = px - rx, py - ry
    local cands = {}
    if math.abs(dx) >= math.abs(dy) then
      cands[#cands + 1] = { rx + (dx > 0 and 1 or -1), ry, dx > 0 and "right" or "left" }
      cands[#cands + 1] = { rx, ry + (dy > 0 and 1 or -1), dy > 0 and "down" or "up" }
    else
      cands[#cands + 1] = { rx, ry + (dy > 0 and 1 or -1), dy > 0 and "down" or "up" }
      cands[#cands + 1] = { rx + (dx > 0 and 1 or -1), ry, dx > 0 and "right" or "left" }
    end
    for _, c in ipairs(cands) do
      if Pathfinder.walkable(grid, c[1], c[2]) then
        nx, ny, facing = c[1], c[2], c[3]
        break
      end
    end
  end

  if nx == rx and ny == ry then
    local adx, ady = px - rx, py - ry
    if math.abs(adx) >= math.abs(ady) then
      nx = rx + (px > rx and 1 or -1)
      facing = px > rx and "right" or "left"
    else
      ny = ry + (py > ry and 1 or -1)
      facing = py > ry and "down" or "up"
    end
  end

  rival.map = gauntletLabId()
  pcall(function() self:moveRivalNpc(rival, nx, ny, facing) end)
  if not self.spawned[rival.id] then
    pcall(function() self:spawnFor(gauntletLabId()) end)
  end
  return (math.abs(px - nx) + math.abs(py - ny)) <= GAUNTLET_ENGAGE
end

function M:gauntletPlayerInRange(rival, world)
  if not (rival and world and world.playerX) then return false end
  local rx, ry = rival.x or 2, rival.y or 2
  local dist = math.abs(world.playerX - rx) + math.abs(world.playerY - ry)
  return dist <= GAUNTLET_DETECT
end

function M:gauntletStartChallenge(rival)
  if not rival then return false end
  if self._gauntletQueued then return true end
  local party = self.game and self.game.save and self.game.save.party
  if type(party) ~= "table" or #party == 0 then return false end

  local ow = self:getOverworld()
  if not ow then
    Util.lastError = "auto-challenge: no overworld"
    return false
  end
  if not (runningOnIOS() and type(ow.queueScript) == "function")
      and not (ow.runner and type(ow.runner.run) == "function") then
    Util.lastError = "auto-challenge: no script runner"
    return false
  end
  -- Never queue a second intro fight while Oak/another script is still busy.
  -- The old implementation relied on queueScript + start_battle.  On some
  -- builds queueScript accepts the rows but the trainer verb is never drained,
  -- leaving the first AI rival frozen after saying "Let's battle!".  The
  -- gauntlet now owns the battle launch directly and only uses the script
  -- runner for the dialogue box.
  if not self:overworldIdle() then return false end

  self.pending = rival
  pcall(function() rival:setState("CHALLENGING_PLAYER", "gauntlet") end)
  if self.gauntlet then
    self.gauntlet.activeBattleRival = rival.id
    self.gauntlet.activeBattleIndex = self.gauntlet.index
  end

  local line
  pcall(function()
    if self.dialogue and self.dialogue.lines and self.dialogue.lines.gauntletChallenge then
      line = self:gauntletLine(rival, self.dialogue.lines.gauntletChallenge)
    end
  end)
  if not line and self.dialogue and self.dialogue.challenge then
    line = self.dialogue:challenge(rival)
  end
  line = line or (rival.name .. ": Let's battle!")

  -- iOS is stricter about constructing and pushing a BattleState from mod
  -- code. Use the same queued trainer script as ordinary map encounters so
  -- the engine owns text dismissal, touch focus and battle-state timing.
  if runningOnIOS() and type(ow.queueScript) == "function" then
    self._gauntletQueued = true
    if self.gauntlet then
      self.gauntlet.dialogueIndex = self.gauntlet.index
      self.gauntlet.phase = "battling"
      self.gauntlet.challenging = true
    end
    local queued, accepted = pcall(function()
      return ow:queueScript({
        { "show_text", line },
        { "start_battle", "trainer", rival.def.trainerClass, 1 },
      })
    end)
    if queued and accepted ~= false then return true end
    self._gauntletQueued = false
    if self.gauntlet then
      self.gauntlet.dialogueIndex = nil
      self.gauntlet.phase = "challenge"
      self.gauntlet.challenging = false
    end
    Util.lastError = "iOS gauntlet queue: " .. tostring(accepted)
    return false -- never fall through to the unsupported direct iOS push
  end

  local function directTrainerBattle()
    local ok, result = pcall(function()
      local Game = self.game
      if not Game then
        local okGame, G = pcall(require, "src.core.Game")
        if not okGame then error(G) end
        Game = G
      end
      local controller = Game.overworld or ow
      if not (controller and type(controller.pushBattle) == "function") then
        error("overworld cannot push battles")
      end
      local BattleState = requireBattleState()
      local classId = rival.def and rival.def.trainerClass
      if not classId then error("rival has no trainer class") end

      -- trainer.party is hooked below, so BattleState.newTrainer only needs
      -- the registered class and member index.  The hook swaps in the rival's
      -- live party immediately before the battle is presented.
      local battle = BattleState.newTrainer(Game, classId, 1)
      if not battle or battle.dead then error("trainer battle was refused") end
      if not battle.onFinish then
        battle.onFinish = function(resultValue)
          if controller.afterBattle then
            controller:afterBattle(resultValue, battle)
          end
        end
      end
      controller:pushBattle(battle)
      return true
    end)
    if not ok or result ~= true then
      Util.lastError = "gauntlet battle launch: " .. tostring(result)
      -- Keep the one-shot dialogue token and retry only the launch once the
      -- text state has completely left the stack. Replaying the introduction
      -- here was the source of the endless second-rival conversation loop.
      return false
    end
    return true
  end

  -- Mark this slot as queued BEFORE entering the runner.  Some engine builds
  -- can complete a one-line text script synchronously, so setting the flag
  -- afterwards could resurrect a stale "queued" state after the battle had
  -- already been launched.
  self._gauntletQueued = true
  if self.gauntlet then
    self.gauntlet.dialogueIndex = self.gauntlet.index
    self.gauntlet.phase = "dialogue"
    self.gauntlet.challenging = true
  end

  -- Run only the dialogue through the normal script runner.  Its completion
  -- callback launches the actual trainer battle, eliminating the unreliable
  -- script `start_battle` seam for this intro sequence.
  local ok, err = pcall(function()
    ow.runner:run({ { "show_text", line } }, {
      onDone = function()
        local g = self.gauntlet
        if not (g and g.active and g.dialogueIndex == g.index
            and g.activeBattleRival == rival.id) then return end
        self._gauntletBattleLauncher = directTrainerBattle
        g.phase = "launch_battle"
        g.phaseT = 0
      end,
    })
  end)
  if not ok then
    Util.lastError = "gauntlet dialogue: " .. tostring(err)
    self.pending = nil
    if self.gauntlet then
      self.gauntlet.activeBattleRival = nil
      self.gauntlet.activeBattleIndex = nil
      self.gauntlet.dialogueIndex = nil
      self.gauntlet.challenging = false
      self.gauntlet.phase = "challenge"
    end
    self._gauntletQueued = false
    return false
  end

  return true
end

function M:gauntletDirector(dt)
  if not self:gauntletActive() then return end
  local g = self.gauntlet
  g.phase = g.phase or "wait_party"
  g.phaseT = (g.phaseT or 0) + (dt or 0)

  local world = self:worldView()
  local lab = gauntletLabId()
  if not (world and lab and world.playerMap == lab) then return end

  local party = self.game and self.game.save and self.game.save.party
  local hasParty = type(party) == "table" and #party > 0

  if g.phase == "wait_party" or g.phase == "wait_blue" then
    -- Park on upper lab slots only (never the exit) until Blue is beaten.
    for i, r in ipairs(self.rivals) do
      local cell = LAB_SLOTS[((i - 1) % #LAB_SLOTS) + 1]
      if r.map == lab then
        local tx, ty = cell[1], cell[2]
        if r.x ~= tx or r.y ~= ty then
          pcall(function() self:moveRivalNpc(r, tx, ty, "down") end)
          r.x, r.y = tx, ty
        end
      end
    end
    if hasParty and self:blueLabBattled() then
      g.phase = "approach"
      g.phaseT = 0
    else
      g.phase = hasParty and "wait_blue" or "wait_party"
    end
    return
  end

  if g.phase == "between" then
    if g.phaseT >= 0.6 then
      g.phase = "approach"
      g.phaseT = 0
      g.approachAge = 0
      self._gauntletStarting = false
      self._gauntletQueued = false
    end
    return
  end

  if g.phase == "dialogue" then
    return -- wait for the one-shot introduction to close
  end

  if g.phase == "launch_battle" then
    -- ScriptRunner's onDone can run before the text state is actually popped.
    -- Launch on a later idle overworld update and retry the launch, never the
    -- dialogue, if a particular engine build needs another frame.
    if not self:overworldIdle() then return end
    local launch = self._gauntletBattleLauncher
    if type(launch) ~= "function" then
      Util.lastError = "gauntlet battle launch: missing deferred launcher"
      return
    end
    local ok = false
    pcall(function() ok = launch() end)
    if ok then
      self._gauntletBattleLauncher = nil
      g.phase = "battling"
      g.launchTries = 0
    else
      g.launchTries = (g.launchTries or 0) + 1
    end
    return
  end

  if g.phase == "battling" then
    return -- wait for battle.ended
  end

  if g.phase == "approach" then
    local rival = self:gauntletRival()
    if not rival then
      self:finishGauntlet()
      return
    end
    g.approachAge = (g.approachAge or 0) + (dt or 0)

    -- Always treat lab as in-range after Blue; walk toward player.
    if g.phaseT >= GAUNTLET_STEP_S then
      g.phaseT = 0
      local ready = false
      pcall(function()
        ready = self:gauntletStepTowardPlayer(rival, world)
      end)
      if ready then
        g.phase = "challenge"
        g.phaseT = 0
        g.approachAge = 0
      end
    end
    -- Failsafe: do not wait forever for pathing — start the fight
    if g.approachAge >= 2.5 then
      g.phase = "challenge"
      g.phaseT = 0
      g.approachAge = 0
    end
    return
  end

  if g.phase == "challenge" then
    local rival = self:gauntletRival()
    if not rival then
      self:finishGauntlet()
      return
    end
    if not hasParty then
      g.phase = "wait_party"
      return
    end

    -- Wait out Oak's post-Blue speech / any text box, then queue the fight
    if self._gauntletQueued then return end

    if g.phaseT >= 0.35 then
      g.phaseT = 0
      -- Prefer queuing while busy (FIFO); only force-run when idle
      local ok = false
      pcall(function() ok = self:gauntletStartChallenge(rival) end)
      if ok then
        g.challenging = true
        -- gauntletStartChallenge sets dialogue; its completion callback moves
        -- to launch_battle, and only a successful push moves to battling.
        g.challengeTries = 0
      else
        g.challengeTries = (g.challengeTries or 0) + 1
        -- Keep retrying while scripts run; only skip after long idle failure
        if g.challengeTries >= 40 and runningOnIOS() then
          -- Never silently count a failed iOS launch as a defeated rival.
          -- Keep the slot honest and leave the explicit SKIP GAUNTLET recovery
          -- available in the Rivals screen.
          g.challengeTries = 0
          Util.lastError = Util.lastError or "iOS gauntlet battle is waiting to start"
        elseif g.challengeTries >= 40 and self:overworldIdle() then
          g.index = g.index + 1
          g.challengeTries = 0
          g.challenging = false
          self._gauntletQueued = false
          if g.index > #g.order then
            self:finishGauntlet()
          else
            g.phase = "approach"
            g.approachAge = 0
          end
        end
      end
    end
    return
  end
end
end

return Gauntlet
