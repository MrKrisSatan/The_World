
local req, mod = ...
local CommsApi = req("src/Comms")
local Phone = req("src/Phone")
local C = nil
local CommsManager = {}


local function requireBattleState()
  local candidates = {
    "src.battle.BattleState",
    "battle.BattleState",
    "BattleState",
  }
  local errors = {}
  for _, name in ipairs(candidates) do
    local ok, value = pcall(require, name)
    if ok and value then return value end
    errors[#errors + 1] = tostring(value)
  end
  error("AI Rivals: could not load BattleState (" .. table.concat(errors, " | ") .. ")")
end

function CommsManager.install(modApi, M)
  mod = modApi or mod
  C = M._ctx or {}
  local TALK_TEXT = C.TALK_TEXT
  local Comms = CommsApi

function M:rivalForContact(record)
  if type(record) ~= "table" or record.kind ~= "RIVAL" then return nil end
  local rival = record.rivalId and self.byId and self.byId[record.rivalId]
  if rival then return rival end
  for _, r in ipairs(self.rivals or {}) do
    if ("PHONE_AIR_" .. string.upper(tostring(r.id))) == tostring(record.id) then
      return r
    end
  end
  return nil
end

function M:contactForTrainerBattle(oppClass, partyIndex)
  if not oppClass then return nil end
  local world = self:worldView() or {}
  local mapId = world.playerMap
  if not mapId or Comms.isGymMap(mapId) then return nil end
  if not Comms.isOrdinaryTrainer(oppClass, nil, mapId) then return nil end
  local memberKey = "MEMBER_" .. tostring(tonumber(partyIndex) or 1)
  local key = Comms.contactIdForTrainer(mapId, oppClass, memberKey)
  local def = self:phoneTrainerForContact(key)
  if def then return def end
  for _, candidate in pairs((self.byTrainerClass and self.byTrainerClass[oppClass]) or {}) do
    if candidate.map == mapId then return candidate end
  end
  -- A scripted trainer with no discoverable object can still join the network.
  return {
    id = key,
    name = Comms.trainerDisplayName(oppClass),
    trainerClass = oppClass,
    partyIndex = tonumber(partyIndex) or 1,
    map = mapId,
    synthetic = true,
  }
end

function M:phoneTrainerForContact(id)
  local hit = self.phoneTrainerDefs and self.phoneTrainerDefs[id]
  if hit then return hit end
  local record = self.comms and Comms.get(self.comms, id)
  local classId = record and record.trainerId
  if classId and self.byTrainerClass and self.byTrainerClass[classId] then
    for _, def in pairs(self.byTrainerClass[classId]) do return def end
  end
  return nil
end

function M:offerTrainerPhone(contact)
  if not contact or not self.comms then return false end
  local seed=self.seedValue or self.pathSeed or self:worldSeed() or 0

  -- Gold keeps its native-style behaviour. The scarcity/familiarity model is
  -- specifically for the custom Red/Blue/Yellow phone network.
  if (self.generation or 1)==2 then
    if not Comms.shouldOfferTrainer(seed,contact.id) then return false end
    local record=Comms.offer(self.comms,contact.id,{
      name=contact.name,kind="TRAINER",trainerId=contact.trainerClass,
      personality=contact.personality,
    },seed)
    if record and not record.accepted and not record.declined then
      self.pendingPhoneOffer=record
      return true
    end
    return false
  end

  local record,ready=Comms.noteTrainerBattle(self.comms,contact.id,{
    name=contact.name,trainerId=contact.trainerClass,
    personality=contact.personality,
  },seed)
  if not record then return false end

  -- "Battle 1" is the first meeting. Battle 2+ represents a rematch/repeat
  -- encounter for phone-familiarity purposes.
  if ready then
    local offered=Comms.offer(self.comms,contact.id,{
      name=contact.name,kind="TRAINER",trainerId=contact.trainerClass,
      personality=contact.personality,
    },seed)
    if not offered then return false end
    self.pendingPhoneOffer=offered
    local repeats=math.max(0,(record.battleCount or 1)-1)
    self.ticker={
      text=repeats>0
        and (tostring(contact.name).." finally offers their number after "
          ..tostring(repeats).." rematch"..(repeats==1 and "." or "es."))
        or (tostring(contact.name).." wants to exchange phone numbers."),
      age=0,duration=7,offset=0,
    }
    return true
  end
  return false
end

function M:acceptPendingPhoneOffer(recordOrId)
  -- The offer screen receives the contact record before pendingPhoneOffer is
  -- cleared to stop the screen reopening every update frame.  Accept the
  -- screen-bound record/id first, while retaining the pending slot as a
  -- compatibility fallback for older callers.
  local record = type(recordOrId) == "table" and recordOrId
    or self.pendingPhoneOffer
  local id = type(recordOrId) == "string" and recordOrId
    or (record and record.id)
  if not id then return false end
  local ok = Comms.accept(self.comms, id)
  self.pendingPhoneOffer = nil
  return ok
end

function M:declinePendingPhoneOffer(recordOrId)
  local record = type(recordOrId) == "table" and recordOrId
    or self.pendingPhoneOffer
  local id = type(recordOrId) == "string" and recordOrId
    or (record and record.id)
  if not id then return false end
  local ok = Comms.decline(self.comms, id)
  self.pendingPhoneOffer = nil
  return ok
end

function M:trainerPhoneLine(record, tick)
  local choices = { "REMATCH", "CHAT", "GOSSIP", "WEATHER" }
  local slot = ((tonumber(tick) or 0) + #(record.id or "") + (tonumber(self.seedValue) or 0)) % #choices + 1
  local kind = choices[slot]
  if kind == "WEATHER" and self.compat and type(self.compat.weatherMap) == "function" then
    local ok, rows = pcall(self.compat.weatherMap, self.compat)
    if ok and type(rows) == "table" and #rows > 0 then
      local row = rows[((tonumber(tick) or 0) % #rows) + 1]
      return "WEATHER", ("%s called: Weather report - %s around %s."):format(
        record.name, tostring(row.weather or "CLEAR"):gsub("_", " "), tostring(row.label or row.id or "the region"))
    end
  end
  if kind == "GOSSIP" and #(self.rivals or {}) > 0 then
    local rival = self.rivals[((tonumber(tick) or 0) % #self.rivals) + 1]
    local where = rival.map and tostring(rival.map):gsub("_", " ") or "somewhere on the road"
    local badges = rival.badgeCount and rival:badgeCount() or 0
    local spoken = self.spokenNameOf and self:spokenNameOf(rival) or rival.name
    return "CHAT", ("%s called: I heard %s is around %s with %d badge%s."):format(
      record.name, spoken, where, badges, badges == 1 and "" or "s")
  end
  if kind == "REMATCH" then
    return "REMATCH", record.name .. " called: Want another battle sometime? Give me a call."
  end
  return "CHAT", record.name .. " called for a bit of trainer gossip and to see how your journey is going."
end

function M:updateTrainerPhoneCalls()
  if not (self.comms and self.sim) then return end
  local tick = tonumber(self.sim.tick) or 0
  if tick <= 0 or tick % 720 ~= 0 then return end
  local trainers = {}
  for _, record in ipairs(Comms.listed(self.comms)) do
    if record.kind == "TRAINER" then trainers[#trainers + 1] = record end
  end
  if #trainers == 0 then return end
  local record = trainers[((tick + (tonumber(self.seedValue) or 0)) % #trainers) + 1]
  if not Comms.mayCall(self.comms, record.id, tick, self:worldView()) then return end
  local reason, text = self:trainerPhoneLine(record, tick)
  if reason == "WEATHER" and not (self.compat and self.compat:present("weather")) then
    reason, text = "CHAT", record.name .. " called with some route gossip."
  end
  Comms.record(self.comms, record.id, reason, tick, { incoming = true })
  self.tickerQueue = self.tickerQueue or {}
  local headline = "PHONE  •  " .. text
  if self.ticker and not self.ticker.text then
    self.ticker = { text = headline, age = 0, duration = 8, offset = 0 }
  else
    self.tickerQueue[#self.tickerQueue + 1] = headline
  end
end

function M:callRival(rival)
  if not (rival and self.comms) then return false, "Rival not found." end
  local id = "PHONE_AIR_" .. string.upper(tostring(rival.id))
  local contact = Comms.get(self.comms, id)
  if not contact or not contact.accepted then
    return false, "You don't have " .. tostring(rival.name) .. "'s number."
  end
  local world = self:worldView() or {}
  local map = world.playerMap
  if not map then return false, "You can't make a call here." end
  if rival.id == self.companionId then
    return false, rival.name .. " is already accompanying you."
  end
  rival.phoneSummon = {
    map = map,
    requestedAt = self.sim and self.sim.tick or 0,
    previousObjective = rival.objective,
    previousDestination = rival.destination,
  }
  rival:setDestination(map)
  rival.objective = "PHONE_SUMMON"
  rival:setState("TRAVELLING", "called by the player")
  Comms.record(self.comms, id, "SUMMON_REPLY",
    self.sim and self.sim.tick or 0, { incoming = false })
  self:save()
  self.ticker = {
    text = rival.name .. " is on the way to " .. tostring(map) .. "!",
    age = 0, duration = 8, offset = 0
  }
  return true, rival.name .. " is coming to you."
end

function M:callContact(contactId)
  local record = self.comms and Comms.get(self.comms, contactId)
  if not record or not record.accepted then
    return false, "That number is not in your Pokegear."
  end
  local tick = self.sim and self.sim.tick or 0
  -- Player-initiated calls must not use Comms.mayCall().  That predicate is
  -- deliberately for *incoming* NPC calls and rejects any world marked busy;
  -- an open Pokegear menu is itself busy, which made CALL RIVAL impossible.
  -- Outgoing calls are staged safely (rivals travel to the player; ordinary
  -- trainers queue a rematch) and Comms.record() below still updates the
  -- shared call timestamps so NPCs cannot immediately ring back.
  if record.kind == "RIVAL" then
    local rival = self.byId[record.rivalId]
    if not rival then
      -- Older saves predate the explicit rivalId field.
      for _, r in ipairs(self.rivals or {}) do
        if ("PHONE_AIR_" .. string.upper(tostring(r.id))) == contactId then
          rival = r
          break
        end
      end
    end
    if not rival then return false, "That rival is unavailable." end
    return self:callRival(rival)
  end

  local def = self:phoneTrainerForContact(contactId)
  if not def then return false, "That trainer cannot be reached." end
  local world = self:worldView() or {}
  local map = world.playerMap
  if not map then return false, "You can't make a call here." end

  self.pendingPhoneTrainer = {
    id = contactId,
    trainerClass = def.trainerClass,
    name = def.name,
    rematches = (record.rematch or 0) + 1,
  }
  Comms.record(self.comms, contactId, "REMATCH", tick, { incoming = false })
  record.rematch = (record.rematch or 0) + 1
  self:save()
  -- Trainers are not teleported into battle. A called rematch is staged at
  -- the player's current location, using the same safe overworld battle seam
  -- as the AI rivals. The call itself never interrupts an active battle.
  self.pendingPhoneTrainer.map = map
  self.pendingPhoneTrainer.ready = true
  self.ticker = {
    text = tostring(def.name) .. " is ready for a rematch!",
    age = 0, duration = 8, offset = 0
  }
  return true, tostring(def.name) .. " is ready for a rematch."
end

function M:pushPhoneTrainerBattle(contact)
  local world = mod.world
  local def = self:phoneTrainerForContact(contact and contact.id)
  if not def then return false, "trainer definition unavailable" end
  local ow = self:getOverworld()
  if self.generation == 2 then
    if not (world and type(world.overworld) == "function") then
      return false, "no Gen 2 world facade"
    end
    local ok, err = pcall(function()
      local w = world:overworld()
      w:startBattle({
        trainer = {
          name = def.name,
          class = def.trainerClass,
          classId = def.trainerClass,
          index = def.partyIndex or 1,
          memberId = def.partyIndex or 1,
          party = {},
        },
      }, function() end)
    end)
    if ok then return true end
    return false, tostring(err)
  end
  local ok, result = pcall(function()
    local Game = self.game
    local controller = (Game and Game.overworld) or ow
    if not (controller and type(controller.pushBattle) == "function") then
      error("overworld cannot push battles")
    end
    local BattleState = requireBattleState()
    local battle = BattleState.newTrainer(Game, def.trainerClass, def.partyIndex or 1)
    if not battle or battle.dead then error("trainer battle was refused") end
    controller:pushBattle(battle)
    return true
  end)
  if ok and result == true then return true end
  return false, tostring(result)
end

function M:resolvePhoneTrainerBattle(ev)
  local pending = self.pendingPhoneTrainer
  if not pending then return false end
  local battle = ev and ev.battle
  local oppClass = battle and (battle.oppClass or (battle.trainer and battle.trainer.classId))
  if oppClass and tostring(oppClass) ~= tostring(pending.trainerClass) then return false end
  self.pendingPhoneTrainer = nil
  return true
end
end

return CommsManager
