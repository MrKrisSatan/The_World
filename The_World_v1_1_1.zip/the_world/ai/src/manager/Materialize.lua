
local req, mod = ...
-- 5.0.8: locals of main.lua before the modular split; nil globals here.
local Util = req("src/Util")
local Rival = req("src/Rival")
local AI = req("src/AI")
local Pathfinder = req("src/Pathfinder")
local RuntimePolicy = req("src/RuntimePolicy")
local Sprites = req("src/Sprites")
local C = nil
local Materialize = {}

function Materialize.install(modApi, M)
  mod = modApi or mod
  C = M._ctx or {}
  local LAB_SLOTS = C.LAB_SLOTS
  local RIVAL_SPRITE_PREFER = C.RIVAL_SPRITE_PREFER
  local FACING_TO_RANGE = C.FACING_TO_RANGE
  local PATH_BLOCK_STALL_S = C.PATH_BLOCK_STALL_S
  local SPAWN_FACINGS = C.SPAWN_FACINGS
  local TALK_TEXT = C.TALK_TEXT

function M:despawnAll()
  for id, npcId in pairs(self.spawned) do
    Util.guard("removeNpc", function() mod.world:removeNpc(npcId) end)
    self.spawned[id] = nil
  end
end

function M:activeMap()
  local ow
  pcall(function()
    if mod.world and mod.world.overworld then ow = mod.world:overworld() end
  end)
  ow = ow or (self.game and self.game.overworld)
  return ow, ow and ow.map
end

function M:liveRivalEntity(rival)
  if not rival then return nil end
  local ow = self:activeMap()
  local spawnedId = self.spawned and self.spawned[rival.id]
  local wantedName = "AIR_" .. tostring(rival.id)
  for _, list in ipairs({ (ow and ow.npcs) or {}, (ow and ow.entities) or {} }) do
    for _, npc in ipairs(list) do
      local id = npc.id or npc.index
      local name = npc.name or (npc.def and npc.def.name)
      if npc == spawnedId or id == spawnedId
         or tostring(id) == tostring(spawnedId)
         or name == wantedName then
        return npc
      end
    end
  end
  return nil
end


-- 5.0.3: runtime NPC handles are not authoritative. Gen1Recomp can rebuild the
-- overworld object/entity lists without notifying mods (state refreshes,
-- transitions, compatibility mods, etc.). Before 5.0.3 a stale non-nil entry
-- in self.spawned permanently blocked spawnFor(), making a rival suddenly
-- vanish while its simulation object still existed.
function M:reconcileRivalSprites(mapId)
  if not mapId then return 0 end
  local cleared = 0
  for _, rival in ipairs(self.rivals or {}) do
    if rival.map == mapId and self.spawned and self.spawned[rival.id] then
      local entity = self:liveRivalEntity(rival)
      if not entity then
        self.spawned[rival.id] = nil
        rival.walking = false
        rival.walkAge = 0
        rival.walkTarget = nil
        -- Keep rival.x/y. They are persistent logical coordinates and give
        -- spawnFor() the best chance of rematerialising in the same safe cell.
        rival.spawnedAt = nil
        cleared = cleared + 1
      end
    end
  end
  return cleared
end

function M:liveTerrainWalkable(mapId, x, y)
  local ow, map = self:activeMap()
  if not (map and map.id == mapId and x and y) then return false end
  if map.inBounds and not map:inBounds(x, y) then return false end
  if type(map.isWalkableCell) ~= "function" then return false end
  local ok, walkable = pcall(map.isWalkableCell, map, x, y)
  return ok and walkable == true
end

function M:liveCellOccupied(mapId, x, y, exceptId)
  local ow, map = self:activeMap()
  if not (ow and map and map.id == mapId) then return true end
  local p = ow.player
  if p and p.cellX == x and p.cellY == y then return true end
  for _, npc in ipairs(ow.npcs or {}) do
    if npc.id ~= exceptId and npc.cellX == x and npc.cellY == y then return true end
  end
  return false
end

function M:validRivalCell(rival, overview, x, y, allowTransit)
  if not self:liveTerrainWalkable(rival.map, x, y) then return false end
  if not allowTransit and self:isTransitCell(rival.map, overview, x, y) then return false end
  local npcId = self.spawned and self.spawned[rival.id]
  if self:liveCellOccupied(rival.map, x, y, npcId) then return false end
  return true
end

function M:repairRivalPosition(rival, reason)
  if not rival then return false, "No rival selected." end
  local npcId = self.spawned[rival.id]
  if npcId then pcall(function() mod.world:removeNpc(npcId) end) end
  self.spawned[rival.id] = nil
  rival.x, rival.y, rival.spawnedAt = nil, nil, nil
  rival.walking, rival.localWalkGoal = false, nil
  rival.blockedWalkPulses = 0
  self.walkMapCache = nil
  if self.perf then self.perf.recoveries = (self.perf.recoveries or 0) + 1 end
  local current = self:worldView()
  if current and rival.map == current.playerMap then
    pcall(function() self:spawnFor(rival.map) end)
  end
  return true, rival.name .. " moved to a safe tile" ..
    (reason and (" (" .. reason .. ").") or ".")
end

function M:isTransitCell(mapId, overview, x, y)
  if not (x and y) then return false end
  for _, marker in ipairs((overview and overview.markers) or {}) do
    if marker.kind == "warp" and marker.x == x and marker.y == y then return true end
  end
  local maps = self.data and (self.data.maps or self.data.gen2Maps)
  local def = maps and maps[mapId]
  for _, warp in ipairs((def and def.warps) or {}) do
    if warp.x == x and warp.y == y then return true end
  end
  local w = overview and (overview.width or (overview.rows and #overview.rows[1]))
  local h = overview and overview.rows and #overview.rows
  return w and h and (x <= 0 or y <= 0 or x >= w - 1 or y >= h - 1) or false
end

function M:placementFor(rival, overview, world)
  local grid = Pathfinder.grid(overview)
  if not grid then return nil end
  local px, py = world.playerX, world.playerY
  -- Pathfinder.grid returns w/h (not width/height)
  local w = grid.w or grid.width or 0
  local h = grid.h or grid.height or 0
  if w < 1 or h < 1 then return nil end
  -- OAKS_LAB is only 5x6; the normal "3–14 tiles away" rule would leave
  -- every cell rejected.  On small maps (or during the gauntlet) accept any
  -- walkable cell that is not under the player's feet.
  local small = (w * h) <= 80 or self:gauntletActive()
  local minD, maxD = small and 1 or 3, small and 99 or 14
  local function acceptable(x, y)
    if not Pathfinder.walkable(grid, x, y) then return false end
    if not self:liveTerrainWalkable(rival.map, x, y) then return false end
    if self:isTransitCell(rival.map, overview, x, y) then return false end
    if self:liveCellOccupied(rival.map, x, y, self.spawned[rival.id]) then return false end
    if px and py then
      local d = math.abs(x - px) + math.abs(y - py)
      if d < minD or d > maxD then return false end
    end
    return true
  end
  if rival.x and rival.y and acceptable(rival.x, rival.y) then
    return rival.x, rival.y
  end
  -- deterministic scan from the rival's own RNG so two rivals on one map do
  -- not land on the same cell and the choice replays on reload
  local startX, startY = rival.rng:int(0, math.max(0, w - 1)),
                         rival.rng:int(0, math.max(0, h - 1))
  for dy = 0, h - 1 do
    for dx = 0, w - 1 do
      local x, y = (startX + dx) % w, (startY + dy) % h
      if acceptable(x, y) and not self:cellTaken(x, y) then return x, y end
    end
  end
  -- last resort on tiny maps: any walkable free cell, even adjacent
  if small then
    for dy = 0, h - 1 do
      for dx = 0, w - 1 do
        local x, y = (startX + dx) % w, (startY + dy) % h
        if Pathfinder.walkable(grid, x, y)
           and self:liveTerrainWalkable(rival.map, x, y)
           and not self:liveCellOccupied(rival.map, x, y, self.spawned[rival.id])
           and not self:cellTaken(x, y)
           and not (px == x and py == y) then
          return x, y
        end
      end
    end
  end
  -- Large-map recovery: distance preferences are presentation, collision is
  -- safety. If no nearby cell qualifies, use any proven free interior cell.
  for y = 1, h - 2 do
    for x = 1, w - 2 do
      if Pathfinder.walkable(grid, x, y)
         and self:liveTerrainWalkable(rival.map, x, y)
         and not self:isTransitCell(rival.map, overview, x, y)
         and not self:liveCellOccupied(rival.map, x, y, self.spawned[rival.id])
         and not self:cellTaken(x, y) then return x, y end
    end
  end
  return nil
end

function M:cellTaken(x, y)
  for _, rival in ipairs(self.rivals) do
    if rival.spawnedAt and rival.spawnedAt[1] == x and rival.spawnedAt[2] == y then
      return true
    end
  end
  return false
end

function M:spriteTable()
  local data = (self.game and self.game.data) or self.data
  if type(data) ~= "table" then return nil end
  if self.generation == 2 or data.gen2Maps or data.gen2Trainers then
    return data.gen2Sprites or data.sprites
  end
  return data.sprites
end

function M:safeSprite(preferred)
  local sprites = self:spriteTable()
  if not sprites then return nil end
  if preferred and sprites[preferred] then return preferred end
  if self.sprites then
    local resolved = self.sprites:semanticWalker("male", self.data, preferred)
    if resolved then return resolved end
  end
  -- Deterministic final fallback for diagnostics/total conversions.
  local ids = {}
  for id, rec in pairs(sprites) do
    if type(rec) == "table" and (rec.image or rec.walker or rec.hgssNativeImage) then
      ids[#ids + 1] = id
    end
  end
  table.sort(ids)
  return ids[1]
end

function M:spriteForRival(rival)
  if not (self.sprites and rival) then return nil end
  -- Preserve one LOGICAL walker id for the rival. We deliberately do not
  -- preserve/copy its image or palette: sprite replacement mods remain free
  -- to replace the live art behind this id, while hair/appearance no longer
  -- flips between e.g. COOLTRAINER_F and BRUNETTE_GIRL across refreshes.
  --
  -- 5.1.0: THE STAMP IS THE RIVAL'S APPEARANCE FOR THIS SAVE AND IS NEVER
  -- OVERWRITTEN. It used to be re-resolved whenever exists() said no -- which
  -- is exactly what happens on a Gold boot, where the sprite table is
  -- data.gen2Sprites and holds different ids. A rival therefore came back
  -- from a Gen 2 session wearing a different face on the Gen 1 save that
  -- created them. The stamp now records INTENT; a version that cannot draw it
  -- substitutes for display only.
  local stamped = rival.appearanceSprite
  if stamped then
    if self.sprites:exists(stamped, self.data) then return stamped end
    -- Display substitute. Deliberately NOT written back.
    return self.sprites:walkerFor(rival.def, self.data, stamped)
  end

  local prefer = rival.id and RIVAL_SPRITE_PREFER[rival.id] or nil
  -- One sprite, drawn from the gender pool as a pure function of the world
  -- seed and this rival's id. Authored preferences still win inside
  -- assignWalker, so Chris keeps looking like Blue.
  local seed = 1
  pcall(function() seed = self:worldSeed() or 1 end)
  local resolved = self.sprites:assignWalker(rival.def, self.data, seed, prefer)
  if resolved then rival.appearanceSprite = resolved end
  return resolved
end

function M:entryPlacement(rival, mapId, overview)
  if not (rival and rival.arrivedFrom and overview) then return nil end
  local grid = Pathfinder.grid(overview)
  local maps = self.data and (self.data.maps or self.data.gen2Maps)
  local def = maps and maps[mapId]
  if not (grid and def) then return nil end
  for _, warp in ipairs(def.warps or {}) do
    if warp.destMap == rival.arrivedFrom then
      for radius = 1, 3 do
        local candidates = {
          { warp.x, warp.y + radius }, { warp.x, warp.y - radius },
          { warp.x + radius, warp.y }, { warp.x - radius, warp.y },
        }
        for _, c in ipairs(candidates) do
          if Pathfinder.walkable(grid, c[1], c[2])
             and self:liveTerrainWalkable(mapId, c[1], c[2])
             and not self:isTransitCell(mapId, overview, c[1], c[2])
             and not self:liveCellOccupied(mapId, c[1], c[2])
             and not self:cellTaken(c[1], c[2]) then return c[1], c[2] end
        end
      end
    end
  end
  local side
  for dir, conn in pairs(def.connections or {}) do
    local other = type(conn) == "table" and conn.map or conn
    if other == rival.arrivedFrom then side = tostring(dir):lower() break end
  end
  local candidates = {}
  if side == "north" or side == "up" then
    for x = 1, grid.w - 2 do candidates[#candidates + 1] = { x, 1 } end
  elseif side == "south" or side == "down" then
    for x = 1, grid.w - 2 do candidates[#candidates + 1] = { x, grid.h - 2 } end
  elseif side == "west" or side == "left" then
    for y = 1, grid.h - 2 do candidates[#candidates + 1] = { 1, y } end
  elseif side == "east" or side == "right" then
    for y = 1, grid.h - 2 do candidates[#candidates + 1] = { grid.w - 2, y } end
  end
  for _, c in ipairs(candidates) do
    if Pathfinder.walkable(grid, c[1], c[2])
       and self:liveTerrainWalkable(mapId, c[1], c[2])
       and not self:liveCellOccupied(mapId, c[1], c[2])
       and not self:cellTaken(c[1], c[2]) then
      return c[1], c[2]
    end
  end
  return nil
end

function M:spawnFor(mapId)
  if not mapId then return 0 end
  if self.mapAllowsRuntimeActors and not self:mapAllowsRuntimeActors(mapId) then
    return 0
  end

  -- Central transition guard. The lab gauntlet is deliberately allowed to
  -- materialise while scripts are active because it owns that room; once the
  -- gauntlet is complete, runtime actors must wait for a settled overworld.
  if self.gauntletDone and self:gauntletDone()
     and self.runtimeObjectsSafe and not self:runtimeObjectsSafe(mapId) then
    return 0
  end
  if self.connectionYieldActive then return 0 end

  -- A remembered handle may point to an NPC the engine has already discarded.
  -- Clear those stale handles first or the `not self.spawned[rival.id]` gate
  -- below will suppress that rival forever.
  self:reconcileRivalSprites(mapId)
  local world = self:worldView()
  local slotIdx = 0
  local spawned = 0

  -- Prefer the live overworld controller; fall back to mod.world facade.
  local function overworld()
    local game = self.game
    if game then
      if game.overworld and game.overworld.isOverworld and game.overworld.map then
        return game.overworld
      end
      local stack = game.stack and game.stack.states
      if stack then
        for i = #stack, 1, -1 do
          if stack[i].isOverworld then return stack[i] end
        end
      end
    end
    return nil
  end

  local ow = overworld()
  local overview
  pcall(function()
    if mod.world and mod.world.mapOverview then overview = mod.world:mapOverview() end
  end)

  for rivalIndex, rival in ipairs(self.rivals) do
    if #rival.party == 0 then
      local species = nil
      pcall(function()
        species = Rival.firstAvailableStarter(rival.def, self.versionKey,
                                              self.data and self.data.pokemon,
                                              nil, self:starterOpts(nil, nil, nil, rival.personality))
      end)
      if not species and self.data and type(self.data.pokemon) == "table" then
        for id, _ in pairs(self.data.pokemon) do species = id break end
      end
      if species then
        pcall(function() rival:addPokemon(species, 5) end)
      end
    end

    -- Spawn even with empty party during lab intro so NPCs are visible
    if rival.map == mapId and not self.spawned[rival.id] then
      slotIdx = slotIdx + 1
      local cell = LAB_SLOTS[((slotIdx - 1) % #LAB_SLOTS) + 1]
      -- Prefer live coords so walk-up steps are not snapped back to slots
      local x = rival.x or cell[1]
      local y = rival.y or cell[2]
      -- OAKS_LAB stays a literal here and just below ON PURPOSE: both
      -- branches encode the KANTO lab's 5x6 interior geometry (LAB_SLOTS and
      -- the synthetic grid). Elm's lab is a different room, so Gold falls
      -- through to the proven entry/safe-placement path rather than being put
      -- on cells measured for somewhere else.
      if not rival.x and world and world.playerX and mapId ~= "OAKS_LAB" then
        x = (world.playerX or 4) + (slotIdx % 3)
        y = (world.playerY or 4)
      end
      if mapId ~= "OAKS_LAB" then
        local safeX, safeY = self:entryPlacement(rival, mapId, overview)
        if not safeX then safeX, safeY = self:placementFor(rival, overview, world) end
        if not (safeX and safeY) then
          -- Fail closed: remaining abstract is better than materialising in
          -- an unproven wall/tree cell. A later update/map entry retries.
          rival.x, rival.y = nil, nil
          return spawned
        end
        x, y = safeX, safeY
      end

      local sprite = self:spriteForRival(rival)
      if self.generation == 2 then
        local live = (self.game and self.game.data) or self.data
        local g2 = live and live.gen2Sprites
        if type(g2) == "table" and not g2[sprite] then
          -- Never persist an invalid Gen 1 logical sprite id into a Gold map
          -- definition. Pick a real Gen 2 walker for display only.
          sprite = self.sprites and self.sprites:walkerFor(rival.def, live, nil) or nil
        end
        if type(g2) == "table" and sprite and not g2[sprite] then sprite = nil end
      end
      if not sprite then
        -- No sprite this boot carries. Fail closed, exactly as an unproven
        -- tile does above: the rival stays abstract and a later map entry
        -- retries, rather than a spawn failing on an unknown sprite id.
        Util.lastError = string.format("spawn %s %s: no usable sprite",
          tostring(rival.id), tostring(mapId))
        rival.x, rival.y = nil, nil
        return spawned
      end

      local objDef = {
        index = 90 + rivalIndex,
        name = "AIR_" .. tostring(rival.id),
        sprite = sprite,
        x = x,
        y = y,
        movement = self.generation == 2 and 6 or "STAY",
        radius = self.generation == 2 and { x = 0, y = 0 } or nil,
        -- Always DOWN before this fix -- every materialised rival faced
        -- south until something else moved it. rival.facing carries over
        -- when the rival is mid-step (a real, explicit direction); with no
        -- such state, this is a fresh materialisation and gets a random one
        -- off the rival's own seeded rng, so it is stable for THIS rival on
        -- THIS boot rather than reshuffling every despawn/respawn cycle.
        range = FACING_TO_RANGE[rival.facing]
          or SPAWN_FACINGS[rival.rng and rival.rng:int(1, 4) or math.random(1, 4)],
        solid = false, passable = true, through = true,
        -- A real text binding is what makes A-button interaction authoritative
        -- in Gen 1. world.interacted remains a secondary compatibility path.
        -- On Gold the text id is inert (nothing in the Gen 2 interact ladder
        -- reads it), so the press is served by the talkTo router keyed on the
        -- `name` above instead.
        text = self.generation == 1 and TALK_TEXT or nil,
      }

      -- Preferred: WorldAPI.spawnNpc (stable, owned, gen1+gen2).
      -- Fallback: OverworldState.addRuntimeObject (engine_internals).
      local npcId, err
      if mod.world and type(mod.world.spawnNpc) == "function" then
        local ok, a, b = pcall(function()
          return mod.world:spawnNpc(mapId, objDef)
        end)
        if ok and a then
          npcId = a
        else
          err = tostring(b or a or "spawnNpc failed")
        end
      end
      if not npcId and ow and type(ow.addRuntimeObject) == "function" then
        local ok, a, b = pcall(function()
          return ow:addRuntimeObject(mapId, objDef, mod.id or "ai_rivals")
        end)
        if ok and a then npcId = a else err = tostring(a or b or err) end
      end
      if not npcId and not err then err = "no spawn path" end

      if npcId then
        self.spawned[rival.id] = npcId
        rival.spawnedAt = { x, y }
        rival.x, rival.y = x, y
        rival.arrivedFrom = nil
        spawned = spawned + 1
      else
        Util.lastError = string.format(
          "spawn %s %s sp=%s: %s",
          tostring(rival.id), tostring(mapId), tostring(sprite),
          tostring(err or "nil"))
      end
    end
  end
  return spawned
end

function M:mapExitTarget(rival, overview)
  if rival.destination and rival.map ~= rival.destination and not rival.route
     and self.graph then
    rival.route = self.graph:route(rival.map, rival.destination)
  end
  local nextMap = rival:nextHop()
  if not nextMap then return nil end
  local edge = self.graph and self.graph:edgeBetween(rival.map, nextMap)
  if edge and edge.x ~= nil and edge.y ~= nil then
    -- NPC script movement must never enter a warp tile. Some engine builds
    -- route any actor standing on a warp through the global transition/fade
    -- controller, which flashes the player's whole screen. Walk to a free
    -- tile beside the door, face it, then perform the rival-only abstract hop.
    local grid = Pathfinder.grid(overview)
    local candidates = {
      { edge.x, edge.y + 1 }, { edge.x - 1, edge.y },
      { edge.x + 1, edge.y }, { edge.x, edge.y - 1 },
    }
    local best, bestD
    for _, cell in ipairs(candidates) do
      if grid and Pathfinder.walkable(grid, cell[1], cell[2])
         and self:validRivalCell(rival, overview, cell[1], cell[2], false) then
        local d = math.abs((rival.x or cell[1]) - cell[1])
          + math.abs((rival.y or cell[2]) - cell[2])
        if not bestD or d < bestD then best, bestD = cell, d end
      end
    end
    if best then return best[1], best[2], nextMap end
    return nil
  end
  local maps = self.data and (self.data.maps or self.data.gen2Maps)
  local def = maps and maps[rival.map]
  local direction
  for dir, conn in pairs((def and def.connections) or {}) do
    local id = type(conn) == "table" and conn.map or conn
    if id == nextMap then direction = tostring(dir):lower() break end
  end
  local grid = Pathfinder.grid(overview)
  if not (grid and direction) then return nil end
  local candidates = {}
  if direction == "north" or direction == "up" then
    for x = 1, grid.w - 2 do candidates[#candidates + 1] = { x, 1 } end
  elseif direction == "south" or direction == "down" then
    for x = 1, grid.w - 2 do candidates[#candidates + 1] = { x, grid.h - 2 } end
  elseif direction == "west" or direction == "left" then
    for y = 1, grid.h - 2 do candidates[#candidates + 1] = { 1, y } end
  elseif direction == "east" or direction == "right" then
    for y = 1, grid.h - 2 do candidates[#candidates + 1] = { grid.w - 2, y } end
  end
  local best, bestD
  for _, c in ipairs(candidates) do
    if Pathfinder.walkable(grid, c[1], c[2])
       and self:liveTerrainWalkable(rival.map, c[1], c[2]) then
      local d = math.abs((rival.x or c[1]) - c[1]) + math.abs((rival.y or c[2]) - c[2])
      if not bestD or d < bestD then best, bestD = c, d end
    end
  end
  if best then return best[1], best[2], nextMap end
  return nil
end

function M:relievePathBlock(world)
  local playerMap = world and world.playerMap
  local px, py = world and world.playerX, world and world.playerY
  if not (playerMap and px and py) then self.pathNudgeDone = false return end
  local idle = tonumber(self.playerIdleSeconds) or 0
  if idle < 0.5 then self.pathNudgeDone = false end
  if idle < PATH_BLOCK_STALL_S or self.pathNudgeDone then return end

  local blocker
  for _, rival in ipairs(self.rivals) do
    if rival.map == playerMap and self.spawned[rival.id] and rival.x and rival.y then
      if math.abs(rival.x - px) + math.abs(rival.y - py) == 1 then
        blocker = rival
        break
      end
    end
  end
  if not blocker then return end

  -- Reuse the walk director's cached grid for this map rather than rebuilding
  -- it (see docs/performance.md F4) -- this runs while the player is
  -- standing still on the SAME map that cache already describes.
  local cache = self.walkMapCache
  local overview, grid
  if cache and cache.mapId == playerMap then
    overview, grid = cache.overview, cache.grid
  else
    pcall(function() overview = mod.world and mod.world:mapOverview() end)
    grid = Pathfinder.grid(overview)
  end
  if not grid then return end

  local candidates = {
    { blocker.x, blocker.y - 1 }, { blocker.x, blocker.y + 1 },
    { blocker.x - 1, blocker.y }, { blocker.x + 1, blocker.y },
  }
  for _, c in ipairs(candidates) do
    local cx, cy = c[1], c[2]
    if (cx ~= px or cy ~= py) and Pathfinder.walkable(grid, cx, cy)
       and self:validRivalCell(blocker, overview, cx, cy, false) then
      local facing = math.abs(px - cx) >= math.abs(py - cy)
        and (px > cx and "right" or "left")
        or (py > cy and "down" or "up")
      -- moveRivalNpc is the proven instant-reposition path (handle:setPosition
      -- / :teleport, with rival.x/y/spawnedAt kept in sync) -- the same one
      -- the gauntlet already uses to place a rival without an animated walk.
      if self:moveRivalNpc(blocker, cx, cy, facing) then
        self.pathNudgeDone = true
      end
      return
    end
  end
end

function M:worldWalkDirector(dt, world)
  local staticMap = world and world.playerMap
  if staticMap and self.mapAllowsRuntimeActors
     and not self:mapAllowsRuntimeActors(staticMap) then
    -- Map-owned static rivals are frozen for this visit. Proximity must never
    -- trigger runtime reconciliation, repair, despawn or rematerialisation.
    return
  end
  self.walkAccumulator = (self.walkAccumulator or 0) + (tonumber(dt) or 0)
  local emergency = self.perf and (self.perf.autoLowSeconds or 0) > 0
  local performance = emergency and "emergency"
    or (mod.options:get("performance") or "balanced")
  local interval = performance == "emergency" and 0.60
    or performance == "low" and 0.48
    or (performance == "full" and 0.24 or 0.32)
  if self.walkAccumulator < interval then return end
  self.walkAccumulator = self.walkAccumulator - interval
  -- NPC:update owns interpolation. Commit its finished cell back into the
  -- persistent rival, matching FOLLOWERS_EX's separation of entity and trail.
  for _, rival in ipairs(self.rivals) do
    if rival.walking then
      rival.walkAge = (tonumber(rival.walkAge) or 0) + interval
      local entity = self:liveRivalEntity(rival)
      if entity and not entity.moving then
        rival.x, rival.y = entity.cellX or rival.x, entity.cellY or rival.y
        rival.spawnedAt = { rival.x, rival.y }
        local target = rival.walkTarget
        rival.walking, rival.walkAge, rival.walkTarget = false, 0, nil
        if target and target.onDone and rival.x == target.x and rival.y == target.y then
          pcall(target.onDone)
        end
      elseif rival.walkAge > 1.25 then
        if entity then
          entity.targetX, entity.targetY = nil, nil
          entity.moving, entity.progress = false, 0
          rival.x, rival.y = entity.cellX or rival.x, entity.cellY or rival.y
        end
        rival.walking, rival.walkAge = false, 0
        rival.walkTarget = nil
      end
    elseif self.spawned[rival.id] then
      -- Idle glance: a materialised, stationary rival occasionally turns to
      -- face a new direction, purely cosmetic -- entity.facing only, never
      -- entity.targetX/Y/moving, so this cannot fight the travel logic
      -- above over who owns the entity's position. Same field moveRivalNpc
      -- already writes mid-step; this just writes it while standing still.
      rival.idleGlanceAge = (tonumber(rival.idleGlanceAge) or 0) + interval
      if rival.idleGlanceAge >= (rival.idleGlanceNext or 0) then
        local rng = rival.rng
        rival.idleGlanceNext = rng and rng:int(2, 6) or (2 + math.random() * 4)
        rival.idleGlanceAge = 0
        local dir = SPAWN_FACINGS[rng and rng:int(1, 4) or math.random(1, 4)]:lower()
        if dir ~= rival.facing then
          local entity = self:liveRivalEntity(rival)
          if entity and not entity.moving then
            entity.facing, rival.facing = dir, dir
          end
        end
      end
    end
  end
  local mapId = world and world.playerMap
  local playerInMotion = world and world.playerMoving

  -- Detect engine-side NPC loss even when no map.entered event fires. A stale
  -- self.spawned handle previously made hasVisible true while nothing was
  -- actually rendered, so the rival could remain invisible indefinitely.
  local stale = self:reconcileRivalSprites(mapId)
  if stale > 0 and (not self.runtimeObjectsSafe or self:runtimeObjectsSafe(mapId)) then
    pcall(function() self:spawnFor(mapId) end)
  end

  local hasVisible = false
  for _, rival in ipairs(self.rivals) do
    if rival.map == mapId and self.spawned[rival.id] then hasVisible = true break end
  end
  if self.companionYieldMap == mapId then hasVisible = true end
  if not hasVisible then return end
  -- Static terrain does not change while the player remains on a map. Cache
  -- its conversion instead of rebuilding the full collision grid each pulse.
  local cache = self.walkMapCache
  if not cache or cache.mapId ~= mapId then
    local overview
    pcall(function() overview = mod.world and mod.world:mapOverview() end)
    cache = { mapId = mapId, overview = overview,
              grid = Pathfinder.grid(overview) }
    self.walkMapCache = cache
  end
  local overview, grid = cache.overview, cache.grid
  if not grid then return end
  -- A solid follower must yield before the player steps onto a door or map
  -- seam. Remove only its live NPC; the persistent rival remains attached and
  -- is materialised safely on the destination map by map.entered.
  local companion = self.byId[self.companionId]
  local nearTransit = false
  if companion and world.playerX and world.playerY then
    local head = self.companionTrailHead
    if not head or head.map ~= mapId then
      self.companionTrailHead = {
        map = mapId, x = world.playerX, y = world.playerY,
      }
      self.companionTrailGoal = nil
    elseif head.x ~= world.playerX or head.y ~= world.playerY then
      -- One follower takes the player's previous committed cell. If several
      -- cells passed between pulses, A* catches up one animated tile at a time.
      self.companionTrailGoal = { x = head.x, y = head.y, map = mapId }
      head.x, head.y = world.playerX, world.playerY
    end
    for dy = -1, 1 do
      for dx = -1, 1 do
        if math.abs(dx) + math.abs(dy) <= 1
           and self:isTransitCell(mapId, overview, world.playerX + dx, world.playerY + dy) then
          nearTransit = true
        end
      end
    end
    local companionNpc = self.spawned[companion.id]
    if nearTransit and companionNpc then
      pcall(function() mod.world:removeNpc(companionNpc) end)
      self.spawned[companion.id] = nil
      companion.x, companion.y, companion.spawnedAt = nil, nil, nil
      companion.walking, companion.localWalkGoal, companion.walkTarget = false, nil, nil
      self.companionTrailHead, self.companionTrailGoal = nil, nil
      self.companionYieldMap = mapId
    elseif not nearTransit and self.companionYieldMap == mapId and not companionNpc
       and (not self.runtimeObjectsSafe or self:runtimeObjectsSafe(mapId)) then
      self.companionYieldMap = nil
      pcall(function() self:spawnFor(mapId) end)
    end
  end
  local repaired = false
  for _, rival in ipairs(self.rivals) do
    if rival.map == mapId and self.spawned[rival.id] and rival.x and rival.y
       and (not self:liveTerrainWalkable(mapId, rival.x, rival.y)
            or (not rival.walking and self:isTransitCell(mapId, overview,
                                                         rival.x, rival.y))) then
      self:repairRivalPosition(rival, "invalid or blocking tile")
      repaired = true
    end
  end
  if repaired and (not self.runtimeObjectsSafe or self:runtimeObjectsSafe(mapId)) then
    pcall(function() self:spawnFor(mapId) end)
  end
  -- Spread autonomous walking work across pulses. The companion remains
  -- responsive, but crowds no longer run several 500-node searches together.
  local autonomousId
  local count = #self.rivals
  local phaseCount = performance == "emergency" and 1000000
    or performance == "low" and 6
    or (performance == "full" and 1 or 3)
  self.autonomousWalkPhase = ((self.autonomousWalkPhase or 0) + 1) % phaseCount
  if not playerInMotion and self.autonomousWalkPhase == 0 then
    self.walkCursor = ((self.walkCursor or 0) % math.max(1, count)) + 1
    for offset = 0, count - 1 do
      local candidate = self.rivals[((self.walkCursor + offset - 1) % count) + 1]
      if candidate and candidate.id ~= self.companionId and candidate.map == mapId
         and self.spawned[candidate.id] then
        autonomousId = candidate.id
        self.walkCursor = ((self.walkCursor + offset) % count) + 1
        break
      end
    end
  end
  for _, rival in ipairs(self.rivals) do
    if rival.map == mapId and self.spawned[rival.id] and rival.x and rival.y
       and (rival.id == self.companionId or rival.id == autonomousId)
       and not rival.walking and rival.state ~= "CHALLENGING_PLAYER" then
      local isCompanion = self.companionId == rival.id
      local tx, ty, nextMap
      if isCompanion and world.playerX and world.playerY then
        local trail = self.companionTrailGoal
        if trail and trail.map == mapId
           and self:validRivalCell(rival, overview, trail.x, trail.y, false) then
          tx, ty = trail.x, trail.y
          if rival.x == tx and rival.y == ty then
            self.companionTrailGoal, tx, ty = nil, nil, nil
          end
        end
        if not tx then
          local followCells = {
            { world.playerX, world.playerY + 1 }, { world.playerX - 1, world.playerY },
            { world.playerX + 1, world.playerY }, { world.playerX, world.playerY - 1 },
          }
          local bestDistance
          for _, cell in ipairs(followCells) do
            if self:validRivalCell(rival, overview, cell[1], cell[2], false) then
              local distance = math.abs(rival.x - cell[1]) + math.abs(rival.y - cell[2])
              if not bestDistance or distance < bestDistance then
                tx, ty, bestDistance = cell[1], cell[2], distance
              end
            end
          end
        end
        if tx == rival.x and ty == rival.y then tx, ty = nil, nil end
      else
        tx, ty, nextMap = self:mapExitTarget(rival, overview)
      end
      if not tx and not isCompanion then
        local goal = rival.localWalkGoal
        if not goal or (goal[1] == rival.x and goal[2] == rival.y)
           or self:isTransitCell(mapId, overview, goal[1], goal[2]) then
          rival.localWalkGoal = nil
          local start = rival.rng:int(0, math.max(0, grid.w * grid.h - 1))
          for offset = 0, grid.w * grid.h - 1 do
            local cell = (start + offset) % (grid.w * grid.h)
            local gx, gy = cell % grid.w, math.floor(cell / grid.w)
            local d = math.abs(gx - rival.x) + math.abs(gy - rival.y)
            if d >= 2 and d <= 7 and Pathfinder.walkable(grid, gx, gy)
               and self:liveTerrainWalkable(mapId, gx, gy)
               and not self:isTransitCell(mapId, overview, gx, gy)
               and not self:liveCellOccupied(mapId, gx, gy, self.spawned[rival.id])
               and not self:cellTaken(gx, gy)
               and not (world.playerX == gx and world.playerY == gy) then
              rival.localWalkGoal = { gx, gy }
              break
            end
          end
        end
        goal = rival.localWalkGoal
        tx, ty = goal and goal[1], goal and goal[2]
      end
      if tx and ty then
        if nextMap and rival.x == tx and rival.y == ty then
          local oldNpc = self.spawned[rival.id]
          if oldNpc then pcall(function() mod.world:removeNpc(oldNpc) end) end
          self.spawned[rival.id] = nil
          rival.arrivedFrom = rival.map
          rival.map, rival.x, rival.y = nextMap, nil, nil
          if rival.useHMsForMap then rival:useHMsForMap(nextMap) end
          rival.spawnedAt, rival.localWalkGoal = nil, nil
          rival.hopClock = nil
          if rival.visitMap then rival:visitMap(nextMap) end
          if rival.map == rival.destination then AI.onArrive(rival, world) end
        else
        local blocked = {}
        if world.playerX and world.playerY then
          blocked[world.playerX .. "," .. world.playerY] = true
        end
        for _, other in ipairs(self.rivals) do
          if other ~= rival and other.map == mapId and other.x and other.y then
            blocked[other.x .. "," .. other.y] = true
          end
        end
        -- Include every live NPC in A* itself.  Checking only the immediate
        -- step made the planner repeatedly choose the same occupied tile and
        -- stall beside shopkeepers/trainers instead of walking around them.
        local activeOw = self:activeMap()
        local selfNpc = self.spawned[rival.id]
        for _, npc in ipairs((activeOw and activeOw.npcs) or {}) do
          if npc.id ~= selfNpc and npc.cellX ~= nil and npc.cellY ~= nil then
            blocked[npc.cellX .. "," .. npc.cellY] = true
          end
        end
        local path = Pathfinder.find(grid, rival.x, rival.y, tx, ty,
          { budget = isCompanion and 120 or 240, blocked = blocked })
        local step = type(path) == "table" and path[1]
        if step and self:liveTerrainWalkable(mapId, step.x, step.y)
           and not self:liveCellOccupied(mapId, step.x, step.y,
                                         self.spawned[rival.id]) then
          local leaving = nextMap and step.x == tx and step.y == ty
          self:moveRivalNpc(rival, step.x, step.y, step.dir, leaving and function()
            local oldNpc = self.spawned[rival.id]
            if oldNpc then pcall(function() mod.world:removeNpc(oldNpc) end) end
            self.spawned[rival.id] = nil
            rival.arrivedFrom = rival.map
            rival.map, rival.x, rival.y = nextMap, nil, nil
            if rival.useHMsForMap then rival:useHMsForMap(nextMap) end
            rival.spawnedAt, rival.localWalkGoal = nil, nil
            rival.hopClock = nil
            if rival.visitMap then rival:visitMap(nextMap) end
            if rival.map == rival.destination then AI.onArrive(rival, world) end
          end or nil)
          rival.blockedWalkPulses = 0
        else
          rival.blockedWalkPulses = (rival.blockedWalkPulses or 0) + 1
          if rival.blockedWalkPulses >= 6 then
            self:repairRivalPosition(rival, "path blocked")
          end
        end
        end
      end
    end
  end
end

function M:placementForGen2(rival, world)
  local where = mod.world:current()
  local px, py = where and where.x, where and where.y
  if not (px and py) then return nil end
  -- engine_internals: the facade has no collision query, the map does
  local walkable
  local ok, map = pcall(function()
    return self.game and self.game.world and self.game.world.map
  end)
  if ok and map and type(map.isWalkableCell) == "function" then
    local check = map.isWalkableCell
    walkable = function(x, y)
      local good, res = pcall(check, map, x, y)
      return good and res or nil
    end
  end
  local function acceptable(x, y)
    if walkable then
      local w = walkable(x, y)
      if w == nil or not w then return false end
    end
    local d = math.abs(x - px) + math.abs(y - py)
    if d < 3 or d > 14 then return false end
    return true
  end
  if rival.x and rival.y and acceptable(rival.x, rival.y) then
    return rival.x, rival.y
  end
  local candidates = {}
  for dy = -7, 7 do
    for dx = -7, 7 do
      local d = math.abs(dx) + math.abs(dy)
      if d >= 3 and d <= 7 then
        candidates[#candidates + 1] = { px + dx, py + dy }
      end
    end
  end
  -- shuffle from the rival's own RNG: two rivals do not land on one cell and
  -- the same spot replays on reload
  for i = #candidates, 2, -1 do
    local j = rival.rng:int(1, i)
    candidates[i], candidates[j] = candidates[j], candidates[i]
  end
  for _, c in ipairs(candidates) do
    if acceptable(c[1], c[2]) and not self:cellTaken(c[1], c[2]) then
      return c[1], c[2]
    end
  end
  -- last resort: the player's own cell is walkable by definition
  return px, py
end
end

return Materialize
