local req, mod = ...
local BattleSim = req("src/BattleSim")

-- WHAT THE OTHER TRAINERS CALL THEM (4.7.0).
--
--   "a powerful female trainer that favours fire types will be known as
--    Princess of Ashes, while a male rival who favours water Pokemon would be
--    Might of Oceans or Ocean's Wrath"
--
-- A title is DERIVED, never stored: it is a reading of the team a rival is
-- actually carrying and the standing they have actually earned. Store one and
-- it outlives the thing it describes -- a "Princess of Ashes" whose last Fire
-- type was traded away three hours ago, still being called that by everyone in
-- Kanto. Derived, the title changes when the rival does, which is the whole
-- point of a name the world gives you rather than one you pick.
--
-- THREE INPUTS, IN ORDER OF HOW MUCH THEY MATTER:
--
--   1. TYPE. The type that dominates the party, if any does. No dominant type
--      means no elemental title -- a balanced team gets a standing title
--      instead, because "Princess of Nothing In Particular" is worse than a
--      plain one.
--   2. TIER. Badges and the title decide WHICH of a type's names is used:
--      the same Fire specialist is an Ember, then a Flamebearer, then the
--      Princess of Ashes. A rival with two badges does not get the big name.
--   3. GENDER, only where the language differs (Princess/Prince). Most titles
--      here are ungendered on purpose; a roster of a hundred needs names that
--      work for everyone, and the gendered pair is the exception Christopher
--      asked for rather than the rule.
--
-- Nothing rolls. Two saves of the same rival with the same team produce the
-- same title, which is what makes it usable in conversation: rivals refer to
-- each other by title, and a name that flickered would read as a bug.

local Titles = {}

Titles.DOMINANCE = 0.45      -- share of the party a type needs to define it
Titles.MIN_PARTY = 2         -- one Pokemon is not a specialism

-- NORMAL is held to a higher bar, because it is the DEFAULT type rather than a
-- choice: a balanced team of six unrelated Pokemon can drift past 45% Normal
-- without anybody having specialised in anything, and "the Perfect Ordinary"
-- is a great name to earn and a terrible one to be given by accident. At 70%
-- it means what the other types mean at 45% -- this trainer picked it.
Titles.NORMAL_DOMINANCE = 0.70

-- Tiers, low to high. `champion` outranks everything: whatever else is true of
-- a rival wearing the crown, that is the thing they are known for.
Titles.TIERS = { "ROOKIE", "KNOWN", "FEARED", "LEGENDARY" }

-- Per type: one name per tier from KNOWN upward, and the gendered variants
-- where they exist. ROOKIE deliberately has no elemental name -- a title is
-- something earned, and handing one to a trainer with a starter and two badges
-- devalues every other name on this list.
Titles.BY_TYPE = {
  FIRE = {
    KNOWN = "the Ember", FEARED = "the Flamebearer",
    LEGENDARY = "the Ashen Sovereign",
    female = { LEGENDARY = "Princess of Ashes", FEARED = "the Cinder Maiden" },
    male = { LEGENDARY = "Lord of Ashes", FEARED = "the Cinderbrand" },
  },
  WATER = {
    KNOWN = "the Tidewalker", FEARED = "the Ocean's Wrath",
    LEGENDARY = "the Might of Oceans",
    female = { LEGENDARY = "Queen of Tides" },
    male = { LEGENDARY = "Might of Oceans" },
  },
  GRASS = {
    KNOWN = "the Green Hand", FEARED = "the Thornwarden",
    LEGENDARY = "the Verdant Crown",
  },
  ELECTRIC = {
    KNOWN = "the Spark", FEARED = "the Stormcaller",
    LEGENDARY = "the Thunder Throne",
  },
  PSYCHIC = {
    KNOWN = "the Quiet Mind", FEARED = "the Mindbender",
    LEGENDARY = "the Unseen Sovereign",
  },
  ICE = {
    KNOWN = "the Frostling", FEARED = "the Winterbound",
    LEGENDARY = "the Everwinter",
  },
  ROCK = {
    KNOWN = "the Stonehand", FEARED = "the Unmoved",
    LEGENDARY = "the Mountain's Will",
  },
  GROUND = {
    KNOWN = "the Duststrider", FEARED = "the Earthshaker",
    LEGENDARY = "the Weight of the World",
  },
  FIGHTING = {
    KNOWN = "the Bruiser", FEARED = "the Iron Fist",
    LEGENDARY = "the Unbroken",
  },
  POISON = {
    KNOWN = "the Blightling", FEARED = "the Venomhand",
    LEGENDARY = "the Slow Death",
  },
  FLYING = {
    KNOWN = "the Windborne", FEARED = "the Skyrender",
    LEGENDARY = "the Sovereign of Skies",
  },
  BUG = {
    KNOWN = "the Swarmkeeper", FEARED = "the Hivelord",
    LEGENDARY = "the Thousandfold",
  },
  GHOST = {
    KNOWN = "the Hollow", FEARED = "the Wailing One",
    LEGENDARY = "the Voice Beyond",
  },
  DRAGON = {
    KNOWN = "the Wyrmling", FEARED = "the Dragonsworn",
    LEGENDARY = "the Last Dragon",
  },
  NORMAL = {
    KNOWN = "the Plain-Dealer", FEARED = "the Unassuming",
    LEGENDARY = "the Perfect Ordinary",
  },
  STEEL = {
    KNOWN = "the Ironclad", FEARED = "the Bulwark",
    LEGENDARY = "the Immovable",
  },
  DARK = {
    KNOWN = "the Shade", FEARED = "the Nightbound",
    LEGENDARY = "the Long Dark",
  },
  FAIRY = {
    KNOWN = "the Charm", FEARED = "the Wyldling",
    LEGENDARY = "the Old Bargain",
  },
}

-- For a rival with no dominant type: named for what they have DONE instead.
Titles.BY_STANDING = {
  CHAMPION = "the Champion",
  LEGENDARY = "the Undefeated",
  FEARED = "the Rising",
  KNOWN = "the Contender",
}

Titles.ROCKET = "the Rocket"

local function isTable(v) return type(v) == "table" end

local function call(obj, name, ...)
  if not (isTable(obj) and type(obj[name]) == "function") then return nil end
  local ok, value = pcall(obj[name], obj, ...)
  if ok then return value end
  return nil
end

-- The type this rival's team is ABOUT, or nil when it is not about one.
-- Counts every type a party member has, so a Charizard argues for Fire and
-- Flying both -- which is honest: that is what the team actually threatens
-- with. nil is a real answer here and must stay nil (lesson 7).
function Titles.dominantType(rival, data)
  local party = isTable(rival) and rival.party or {}
  local counted, total = {}, 0
  for _, slot in ipairs(party) do
    local def = call(rival, "speciesDef", slot and slot.species)
      or (isTable(data) and isTable(data.pokemon) and slot and data.pokemon[slot.species])
    local types = BattleSim.typesOf(def)
    for _, kind in ipairs(types or {}) do
      counted[kind] = (counted[kind] or 0) + 1
      total = total + 1
    end
  end
  if #party < Titles.MIN_PARTY or total == 0 then return nil end
  local best, bestCount
  for kind, n in pairs(counted) do
    if not bestCount or n > bestCount or (n == bestCount and kind < best) then
      best, bestCount = kind, n
    end
  end
  if not best then return nil end
  local share = bestCount / total
  local needed = best == "NORMAL" and Titles.NORMAL_DOMINANCE or Titles.DOMINANCE
  if share < needed then return nil end
  return best, share
end

-- How well known they are. Badges are the public measure everybody in Kanto
-- can see, which is why the tier reads them rather than party levels.
function Titles.tier(rival)
  if isTable(rival) and rival.champion == true then return "LEGENDARY" end
  local badges = tonumber(call(rival, "badgeCount")) or 0
  local record = call(rival, "ensureLeague")
  if isTable(record) and (tonumber(record.clears) or 0) > 0 then return "LEGENDARY" end
  if badges >= 7 then return "LEGENDARY" end
  if badges >= 4 then return "FEARED" end
  if badges >= 2 then return "KNOWN" end
  return "ROOKIE"
end

local function genderOf(rival)
  local g = isTable(rival) and (rival.gender or (isTable(rival.def) and rival.def.gender))
  if g == "female" or g == "male" then return g end
  return nil
end

-- The title, or nil for a rival who has not earned one yet. nil is the honest
-- answer for a trainer nobody has heard of, and every caller treats it as
-- "use their name" rather than inventing a placeholder.
function Titles.of(rival, data)
  if not isTable(rival) then return nil end
  -- 5.0.1 rare special characters have earned names that are part of their
  -- identity, not a derived type title. They always use the forced title.
  if type(rival.forcedTitle) == "string" and rival.forcedTitle ~= "" then
    return rival.forcedTitle
  end
  local tier = Titles.tier(rival)
  if tier == "ROOKIE" then return nil end

  -- A Rocket is known for that before anything else. §17 made joining rare
  -- and consequential; the name they get should reflect it.
  if rival.lifePath == "TEAM_ROCKET" or rival.lifePath == "ROCKET_EXECUTIVE" then
    if tier == "LEGENDARY" then return "the Rocket's Shadow" end
    return Titles.ROCKET
  end

  local kind = Titles.dominantType(rival, data)
  local entry = kind and Titles.BY_TYPE[kind] or nil
  if entry then
    local gender = genderOf(rival)
    local gendered = gender and entry[gender] or nil
    if gendered and gendered[tier] then return gendered[tier] end
    if entry[tier] then return entry[tier] end
  end

  if rival.champion == true then return Titles.BY_STANDING.CHAMPION end
  return Titles.BY_STANDING[tier]
end

-- "CHRIS, the Ashen Sovereign" -- for a record screen or an introduction.
function Titles.full(rival, data)
  local name = tostring((isTable(rival) and rival.name) or "?")
  local title = Titles.of(rival, data)
  if not title then return name end
  return name .. ", " .. title
end

-- What another trainer CALLS them in conversation. Rivals use the title where
-- one exists, because that is how a reputation sounds from the outside: you
-- are the Ocean's Wrath to everyone who has not met you.
--
-- `capitalise` is for sentence starts; the titles are stored lower-cased after
-- the article so "beat the Ocean's Wrath" reads correctly mid-sentence.
function Titles.spokenName(rival, data, capitalise)
  local title = Titles.of(rival, data)
  if not title then return tostring((isTable(rival) and rival.name) or "?") end
  if capitalise then
    return (title:gsub("^the ", "The "))
  end
  return title
end

return Titles
