-- Roster selection and creation-menu policy. Data/rivals.lua owns identities;
-- this module owns only how many become live in a particular save.
local RosterPolicy = {}

function RosterPolicy.clamp(value, size, fallback)
  return math.max(0, math.min(size,
    math.floor(tonumber(value) or tonumber(fallback) or 4)))
end

-- 5.0.9: THE ORDINARY ROSTER IS NOT THE WHOLE ROSTER.
--
-- src/Specials.lua appends a rare Berserk character onto ROSTER when the world
-- seed rolls one, so #ROSTER is 100 on most saves and 101, 102 or 103 on the
-- rest. Every site that used #ROSTER as "how many rivals can the player pick"
-- therefore moved with a random roll the player never sees: the creation
-- menu's ALL option read 101, and the clamp ceiling let a 101 through.
--
-- Specials JOINING the world on top of the chosen count is deliberate (see
-- activeRoster in main.lua, and the matching subtraction in
-- Persistence:save). What was never deliberate is a hidden roll changing the
-- menu. These two helpers are the vocabulary for that distinction, and every
-- selection site reads them rather than #roster.
function RosterPolicy.isOrdinary(def)
  return type(def) == "table" and not def.rareSpecial
end

function RosterPolicy.ordinary(roster)
  local out = {}
  for _, def in ipairs(roster or {}) do
    if RosterPolicy.isOrdinary(def) then out[#out + 1] = def end
  end
  return out
end

function RosterPolicy.ordinaryCount(roster)
  return #RosterPolicy.ordinary(roster)
end

function RosterPolicy.active(roster, chosen, mode)
  -- Selection walks the ORDINARY rows, not roster[1..count]. Those are the
  -- same list today only because specials happen to be appended last; reading
  -- the ordinary list means an inserted special can never silently consume a
  -- selection slot.
  local pool = RosterPolicy.ordinary(roster)
  local size = #pool
  local count
  if chosen then count = RosterPolicy.clamp(chosen, size, 4)
  elseif mode == "off" then return {}
  elseif mode == "two" then count = math.min(2, size)
  else count = math.min(4, size) end
  local out = {}
  for i = 1, count do out[i] = pool[i] end
  return out
end

function RosterPolicy.creationChoices(size)
  local labels = { [1] = "ONE", [2] = "TWO", [4] = "FOUR", [5] = "FIVE",
                   [10] = "TEN", [25] = "TWENTY-FIVE", [50] = "FIFTY" }
  local choices, values = { "ZERO" }, { "0" }
  for i = 1, size do
    local label = i == size and "ALL" or labels[i]
    if label then
      choices[#choices + 1], values[#values + 1] = label, tostring(i)
    end
  end
  return choices, values
end

return RosterPolicy
