local req, mod = ...
local Util = req("src/Util")

-- THE POKÉMON LEAGUE (1.39.0).
--
-- Simulated League runs have existed since 1.7 and they were honest -- the same
-- BattleSim, the game's own Elite Four parties, no scaled substitute. What was
-- missing is everything that happens AROUND a run: §28's "fail, analyse, train,
-- modify the team, attempt again", §29's earned Championship, §30's title
-- defence.
--
-- THE BUG THIS RELEASE FIXES
--
-- The retry gate was a flat 16-tick cooldown and nothing else. A rival that
-- reached eight badges with a team the Elite Four could beat attempted the
-- League **1500 times over ten hours of play**, losing all 1500, and logged a
-- news item every time.
--
-- This is precisely the bug the Gym path had in the original build -- "a static
-- gym-confidence gate made a rival attempt Brock 90 times and lose 90 times" --
-- and the fix there was that each failed attempt must raise the bar. The Gym
-- path was fixed. The League path was written from the same template three
-- releases earlier and never was.
--
-- So a failure now does what §28 describes: it records WHERE the rival fell,
-- raises the bar it has to clear before trying again, and sends it away to
-- train. A rival that keeps failing at Lance backs off for longer each time
-- rather than throwing itself at him every sixteen ticks.

local League = {}

-- A conversion may ship a League of any length; the record is bounded to this
-- many stages so a hostile or unusual data set cannot grow the save.
League.MAX_STAGE = 8

-- Retry pacing. The base is the old flat cooldown; the escalation is the fix.
League.BASE_COOLDOWN = 16
League.COOLDOWN_STEP = 140    -- added per UNPRODUCTIVE failure at the same wall
League.MAX_COOLDOWN = 1200    -- ~30 minutes of play; long enough to go train
-- Nobody runs the Elite Four every eight seconds, however well it is going.
League.MIN_GAP = 300

-- How much stronger a rival must be than when it last failed, per failure at
-- the same stage. Measured in TOTAL PARTY LEVELS, and ADDITIVE.
--
-- A multiplicative bar was tried first and it inverts the intent. Requiring
-- "+12% per failure" against the strength you last failed at means the demand
-- grows with the rival: a diligent rival at 900 total levels must find another
-- 540, while a stuck rival at 200 must find only 120. The soak duly reported
-- the stuck rival getting MORE attempts than the training one. An additive
-- step asks the same real improvement of everybody, which is what "get
-- stronger and come back" actually means.
League.BAR_STEP = 4
League.MAX_BAR = 40

-- Ticks of waiting that count for one point of the strength bar.
--
-- Without this the bar is absolute and a rival that plateaus never attempts
-- the League AGAIN -- the 24000-tick soak produced exactly one attempt in ten
-- hours, which is the opposite over-correction to the 1500 it replaced. The
-- intent is "back off and train", not "give up forever", so the requirement
-- relents as the rival waits. A rival that trains hard returns quickly; one
-- that does not returns eventually, and having waited a long time for it.
League.PATIENCE = 12

local function num(v, d) return tonumber(v) or d end

-- ------------------------------------------------------------------
-- The record
-- ------------------------------------------------------------------

function League.newRecord(saved)
  saved = type(saved) == "table" and saved or {}
  local walls = {}
  for stage, losses in pairs(type(saved.walls) == "table" and saved.walls or {}) do
    local n = math.floor(num(stage, 0))
    if n >= 1 and n <= League.MAX_STAGE then
      walls[n] = math.min(999, math.max(0, math.floor(num(losses, 0))))
    end
  end
  local record = {
    attempts = math.max(0, math.floor(num(saved.attempts, 0))),
    clears = math.max(0, math.floor(num(saved.clears, 0))),
    bestStage = Util.clamp(math.floor(num(saved.bestStage, 0)), 0, League.MAX_STAGE),
    lastStage = Util.clamp(math.floor(num(saved.lastStage, 0)), 0, League.MAX_STAGE),
    walls = walls,
    -- Has this rival CLEARED the Elite Four since it last held the title?
    -- §30's title challenge is gated on this and nothing else.
    qualified = saved.qualified == true,
    reigns = math.max(0, math.floor(num(saved.reigns, 0))),
    -- 4.6.0: successful TITLE DEFENCES. A count of an event that happened,
    -- which is why it is stored rather than derived -- there is nothing left
    -- in the world afterwards to read it off. `titleMatches` is the whole
    -- number of title bouts either way, so a record can say "defended 3 of 5"
    -- instead of implying an unbeaten reign.
    defences = math.max(0, math.floor(num(saved.defences, 0))),
    titleMatches = math.max(0, math.floor(num(saved.titleMatches, 0))),
    titleCooldown = math.max(0, math.floor(num(saved.titleCooldown, 0))),
    reignStart = saved.reignStart and math.max(0, math.floor(num(saved.reignStart, 0))) or nil,
    longestReign = math.max(0, math.floor(num(saved.longestReign, 0))),
    -- strength at the moment of the last failure, so the bar means something
    lastStrength = math.max(0, math.floor(num(saved.lastStrength, 0))),
    wait = math.max(0, math.floor(num(saved.wait, 0))),
    unproductive = math.max(0, math.floor(num(saved.unproductive, 0))),
    cooldown = math.max(0, math.floor(num(saved.cooldown, 0))),
  }
  return record
end

function League.serializeRecord(record) return League.newRecord(record) end

-- The stage that keeps stopping this rival, and how often. §28's "analyse
-- weaknesses" -- derived from runs it actually fought, never from knowledge it
-- could not have.
function League.wall(record)
  if type(record) ~= "table" then return nil, 0 end
  local worst, count = nil, 0
  -- Deterministic: ascending stage order, never pairs() order, so two identical
  -- saves name the same wall.
  for stage = 1, League.MAX_STAGE do
    local losses = record.walls[stage] or 0
    if losses > count then worst, count = stage, losses end
  end
  return worst, count
end

-- ------------------------------------------------------------------
-- Attempts
-- ------------------------------------------------------------------

-- `stage` is the stage the run ended at: the one that beat them on a failure,
-- or the full length of the League on a clear.
--
-- Returns the record. Callers read `record.cooldown` for how long to wait.
function League.recordAttempt(record, stage, cleared, opts)
  if type(record) ~= "table" then return record end
  opts = opts or {}
  stage = Util.clamp(math.floor(num(stage, 1)), 1, League.MAX_STAGE)
  local previousStrength = math.max(0, math.floor(num(record.lastStrength, 0)))
  record.attempts = math.min(99999, record.attempts + 1)
  record.lastStage = stage
  record.bestStage = math.max(record.bestStage, stage)
  record.lastStrength = math.max(0, math.floor(num(opts.strength, record.lastStrength)))

  if cleared then
    record.clears = math.min(9999, record.clears + 1)
    record.qualified = true
    -- A clear resets the walls: whatever was stopping them no longer is, and
    -- carrying the old grudge would keep the bar raised against a rival that
    -- has demonstrably solved the problem.
    record.walls = {}
    -- Winning is not a reason to immediately queue up again. A champion has
    -- somewhere else to be, and without this a cleared record re-runs the
    -- League every thirty ticks forever.
    record.cooldown = math.floor(League.MAX_COOLDOWN / 2)
    record.wait = 0
    record.unproductive = 0
    return record
  end

  record.walls[stage] = math.min(999, (record.walls[stage] or 0) + 1)
  record.wait = 0

  -- ESCALATION, AND WHAT IT MEASURES.
  --
  -- The wait must lengthen for a rival that is getting nowhere and NOT for one
  -- visibly working on the problem, or it punishes exactly the behaviour §28
  -- is trying to produce. So escalation counts UNPRODUCTIVE failures: a rival
  -- that came back meaningfully stronger and still lost is making progress,
  -- and its wait resets to the floor.
  --
  -- (Escalating on every failure was tried first. The soak reported the stuck
  -- rival and the training rival making the SAME number of attempts, because
  -- the cooldown had become the only thing that mattered.)
  local improved = previousStrength > 0
    and (record.lastStrength - previousStrength) >= League.BAR_STEP
  if improved then
    record.unproductive = 0
  else
    record.unproductive = math.min(999, math.floor(num(record.unproductive, 0)) + 1)
  end
  record.cooldown = math.max(League.MIN_GAP, math.min(League.MAX_COOLDOWN,
    League.BASE_COOLDOWN + record.unproductive * League.COOLDOWN_STEP))
  return record
end

-- How much stronger the rival must be than when it last failed here. 1 means
-- "no worse than last time"; it climbs with every failure at the same wall.
-- Extra total party levels required beyond the strength this rival last failed
-- with. 0 means "no worse than last time".
function League.bar(record, stage)
  if type(record) ~= "table" then return 0 end
  stage = stage or record.lastStage
  if not stage or stage < 1 then return 0 end
  local failures = record.walls[stage] or 0
  if failures <= 0 then return 0 end
  return math.min(League.MAX_BAR, failures * League.BAR_STEP)
end

-- May this rival start a run right now?
--
-- The bar is a STRENGTH comparison rather than a dice roll: a rival that failed
-- at Lance and has not got any stronger since has no business walking back in,
-- and one that has genuinely trained gets straight back in. That makes §28's
-- loop -- fail, train, return -- the actual mechanism rather than a description.
function League.mayAttempt(record, strength)
  if type(record) ~= "table" then return true end
  if (record.cooldown or 0) > 0 then return false end
  if record.attempts <= 0 then return true end
  local required = math.floor((record.lastStrength or 0) + League.bar(record))
  -- Waiting counts toward the requirement, so the bar cannot strand a rival
  -- outside the League permanently.
  required = required - math.floor(num(record.wait, 0) / League.PATIENCE)
  if required <= 0 then return true end
  return math.floor(num(strength, 0)) >= required
end

-- Tick the cooldown down. Returns true while still waiting.
function League.tick(record)
  if type(record) ~= "table" then return false end
  local left = math.max(0, math.floor(num(record.cooldown, 0)))
  if left > 0 then
    record.cooldown = left - 1
    return true
  end
  record.cooldown = 0
  -- Past the cooldown, patience accrues against the strength bar. Capped so
  -- the counter cannot grow without bound over a long game.
  record.wait = math.min(99999, math.floor(num(record.wait, 0)) + 1)
  return false
end

-- ------------------------------------------------------------------
-- The title (§29, §30)
-- ------------------------------------------------------------------

-- A rival may challenge the sitting Champion only after CLEARING the Elite
-- Four. Before 1.39 the title-challenge path fired on eight badges alone, so a
-- rival could take a shot at the Championship without ever having beaten the
-- Elite Four -- an entitlement the player does not have, and §38 says the AI
-- plays by the same rules.
function League.mayChallengeTitle(record)
  return type(record) == "table" and record.qualified == true
end

-- ------------------------------------------------------------------
-- Title matches (4.6.0)
-- ------------------------------------------------------------------
-- A challenger who has cleared the Elite Four may take on whoever is wearing
-- the crown. Both sides of the bout are recorded here so the two counts can
-- never disagree with each other, and both take a cooldown -- a champion is
-- not defending the title every thirty seconds, and a beaten challenger goes
-- away and trains like they do after any other League failure.

League.TITLE_COOLDOWN = 900

function League.mayTitleMatch(record)
  if type(record) ~= "table" then return false end
  return record.qualified == true and (num(record.titleCooldown, 0) <= 0)
end

function League.recordTitleMatch(record, won, opts)
  if type(record) ~= "table" then return record end
  opts = opts or {}
  record.titleMatches = math.min(99999, num(record.titleMatches, 0) + 1)
  record.titleCooldown = math.max(0, math.floor(
    num(opts.cooldown, League.TITLE_COOLDOWN)))
  if opts.defending then
    -- The champion. A win is a defence; a loss ends the reign, which the
    -- caller closes through endReign so the length is recorded once.
    if won then record.defences = math.min(9999, num(record.defences, 0) + 1) end
    return record
  end
  -- The challenger. Losing consumes the qualification exactly as losing the
  -- title does: to come back they clear the Elite Four again. Anything else
  -- lets one clear buy unlimited attempts at the crown.
  if not won then record.qualified = false end
  return record
end

function League.tickTitle(record)
  if type(record) ~= "table" then return record end
  if num(record.titleCooldown, 0) > 0 then
    record.titleCooldown = math.max(0, num(record.titleCooldown, 0) - 1)
  end
  return record
end

-- 5.9.0: a rival may occupy the physical final Champion encounter only when
-- the save contains evidence that the title was earned. `champion=true` alone
-- is not sufficient, because old/debug/corrupt state must never conjure a
-- rival onto the throne. A recorded reign is the canonical proof; `clears` is
-- accepted for backwards compatibility with older saves that predate reigns.
function League.earnedChampion(record, champion)
  if champion ~= true or type(record) ~= "table" then return false end
  return num(record.reigns, 0) > 0 or num(record.clears, 0) > 0
end

function League.beginReign(record, tick)
  if type(record) ~= "table" then return false end
  record.reigns = math.min(9999, record.reigns + 1)
  record.reignStart = math.max(0, math.floor(num(tick, 0)))
  -- Holding the title consumes the qualification: to get it back after losing
  -- it, a rival must clear the Elite Four again.
  record.qualified = false
  return true
end

function League.endReign(record, tick)
  if type(record) ~= "table" then return 0 end
  local start = record.reignStart
  record.reignStart = nil
  if not start then return 0 end
  local length = math.max(0, math.floor(num(tick, 0)) - start)
  record.longestReign = math.max(record.longestReign, length)
  return length
end

function League.reignLength(record, tick)
  if type(record) ~= "table" or not record.reignStart then return 0 end
  return math.max(0, math.floor(num(tick, 0)) - record.reignStart)
end

-- ------------------------------------------------------------------
-- Presentation
-- ------------------------------------------------------------------

-- §27's standings row. Sorting is the caller's business; this is one rival.
function League.standing(rival, record, champion)
  return {
    id = rival.id,
    name = rival.name,
    badges = rival.badgeCount and rival:badgeCount() or 0,
    caught = rival.collectionSize and rival:collectionSize() or 0,
    attempts = record and record.attempts or 0,
    best = record and record.bestStage or 0,
    clears = record and record.clears or 0,
    defences = record and record.defences or 0,
    champion = champion == true,
    qualified = record and record.qualified == true,
  }
end

-- Deterministic ordering: badges, then League progress, then collection, then
-- id. Never pairs() order, so the table reads the same every time it is opened.
function League.sortStandings(rows)
  table.sort(rows, function(a, b)
    if a.champion ~= b.champion then return a.champion end
    if a.badges ~= b.badges then return a.badges > b.badges end
    if a.clears ~= b.clears then return a.clears > b.clears end
    if a.best ~= b.best then return a.best > b.best end
    if a.caught ~= b.caught then return a.caught > b.caught end
    return tostring(a.id) < tostring(b.id)
  end)
  return rows
end

function League.status(row)
  if row.champion then return "CHAMPION" end
  if row.qualified then return "QUALIFIED" end
  if row.badges >= 8 then return "LEAGUE" end
  return tostring(row.badges) .. " BADGE" .. (row.badges == 1 and "" or "S")
end

-- The name of a stage, for news and the debug overlay. Falls back to a number
-- so a conversion with an unfamiliar League still reads sensibly.
function League.stageLabel(stage, names)
  local name = type(names) == "table" and names[stage]
  if type(name) == "string" and name ~= "" then
    return (name:gsub("_", " "))
  end
  return "stage " .. tostring(stage or "?")
end

function League.describe(record)
  if type(record) ~= "table" then return "no League record" end
  local wall, count = League.wall(record)
  return ("attempts %d  clears %d  best %d  reigns %d  defences %d  longest %d%s%s")
    :format(record.attempts, record.clears, record.bestStage, record.reigns,
      num(record.defences, 0), record.longestReign,
      wall and ("  wall: stage " .. wall .. " x" .. count) or "",
      record.qualified and "  QUALIFIED" or "")
end

return League
