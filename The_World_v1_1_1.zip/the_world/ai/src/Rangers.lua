-- Pokémon Rangers: a small neutral faction that opposes Team Rocket.
-- At most 10 rangers in Kanto. Each is gym-leader strength. They can recruit
-- rivals, arrest Rocket members (temporary removal), heal the player, offer
-- quests, and accept optional battles.
local req, mod = ...
local Util = req("src/Util")
local Happiness = req("src/Happiness")
local TrainerClasses = req("src/TrainerClasses")
local AgentCatching = req("src/AgentCatching")
local Backgrounds = req("src/Backgrounds")
local Names = req("data/names")

local Rangers = {}
Rangers.__index = Rangers

local MAX_RANGERS = 10
local HOME_CANDIDATES = {
  "CERULEAN_CITY", "VERMILION_CITY", "FUCHSIA_CITY", "SAFFRON_CITY",
  "CELADON_CITY", "LAVENDER_TOWN", "CINNABAR_ISLAND", "PEWTER_CITY",
  "VIRIDIAN_CITY", "ROUTE_1",
}

local function clamp(n, lo, hi)
  n = tonumber(n) or lo
  if n < lo then return lo end
  if n > hi then return hi end
  return n
end

function Rangers.new(manager, data, namePools)
  local self = setmetatable({
    manager = manager,
    data = data,
    enabled = true,
    tick = 0,
    nextOp = 40,
    members = {},
    arrested = {}, -- memberId -> releaseTick
    recruitment = {},
    news = {},
    missions = {},
    missionCursor = 0,
    -- 6.1.0: Rangers are now a persistent organisation, not merely roaming
    -- quest NPCs. These values are deliberately small and bounded because the
    -- simulation may run for thousands of ticks on mobile builds.
    resources = 90,
    command = nil,
    jurisdictions = {},
    intelligence = {},
    raids = {},
    strategyTick = 0,
    seed = (manager and manager.worldSeed and manager:worldSeed()) or 1,
    rng = Util.rng(((manager and manager.worldSeed and manager:worldSeed()) or 1) + 4242),
    namePools = namePools or { M = Names.BOYS, F = Names.GIRLS },
  }, Rangers)
  self:generate()
  self:generateOrganisation()
  return self
end

function Rangers:pickHome()
  local graph = self.manager and self.manager.graph
  for _, id in ipairs(HOME_CANDIDATES) do
    if not graph or not graph.has or graph:has(id) then return id end
  end
  return "CERULEAN_CITY"
end

function Rangers:generate()
  local home = self:pickHome()
  local count = clamp(4 + self.rng:int(0, 6), 4, MAX_RANGERS)
  local used = {}
  for i = 1, count do
    local gender = self.rng:chance(0.5) and "M" or "F"
    local pool = gender == "F" and (self.namePools.F or Names.GIRLS)
      or (self.namePools.M or Names.BOYS)
    local name = "RANGER"
    for _ = 1, 40 do
      local candidate = pool[self.rng:int(1, #pool)]
      if candidate and not used[candidate] then
        name, used[candidate] = candidate, true
        break
      end
    end
    -- Gym-leader equivalent: strong base level, scales with player badges later.
    local baseLevel = 28 + self.rng:int(0, 12)
    local speciesPool = {
      "FEAROW", "ARCANINE", "NIDOQUEEN", "NIDOKING", "VILEPLUME", "VICTREEBEL",
      "GOLDUCK", "PRIMEAPE", "POLIWRATH", "ALAKAZAM", "MACHAMP", "GOLEM",
      "RAPIDASH", "SLOWBRO", "MAGNETON", "FARFETCHD", "DODRIO", "DEWGONG",
      "MUK", "CLOYSTER", "GENGAR", "HYPNO", "ELECTRODE", "EXEGGUTOR",
      "MAROWAK", "HITMONLEE", "HITMONCHAN", "WEEZING", "RHYDON", "CHANSEY",
      "KANGASKHAN", "SEADRA", "SEAKING", "STARMIE", "MR_MIME", "SCYTHER",
      "JYNX", "ELECTABUZZ", "MAGMAR", "PINSIR", "TAUROS", "GYARADOS",
      "LAPRAS", "VAPOREON", "JOLTEON", "FLAREON", "AERODACTYL", "SNORLAX",
      "ARTICUNO", "ZAPDOS", "MOLTRES", "DRAGONITE",
    }
    local party = {}
    local n = self.rng:int(3, 6)
    for j = 1, n do
      local sp = speciesPool[self.rng:int(1, #speciesPool)]
      party[#party + 1] = {
        species = sp,
        level = baseLevel + self.rng:int(-2, 4),
      }
    end
    local member = {
      id = "ranger_" .. i,
      name = name,
      rank = i <= 2 and "Captain" or "Ranger",
      gender = gender,
      map = home,
      destination = nil,
      route = nil,
      routeIndex = 1,
      party = party,
      baseLevel = baseLevel,
      active = true,
      alive = true,
      objective = "PATROL",
      successes = 0,
      arrests = 0,
      recruits = 0,
      travelClock = 0,
      travelDelay = nil,
      trainerClass = "AIR_RANGER_" .. i,
      balls = 6 + self.rng:int(0, 5), catches = 0, pc = {},
    }
    TrainerClasses.assign(member,"RANGER",(self.seed or 1)+i*149)
    self.members[#self.members + 1] = member
  end
end

function Rangers:log(text, kind, meta)
  local row = {
    text = tostring(text or ""),
    kind = kind or "news",
    tick = self.tick,
    meta = meta,
  }
  self.news[#self.news + 1] = row
  while #self.news > 40 do table.remove(self.news, 1) end
  if self.manager and self.manager.addNews then
    pcall(function()
      self.manager:addNews({ name = "RANGERS" }, {
        kind = "news", text = row.text,
      })
    end)
  end
end

function Rangers:playerBadgeCount()
  local m = self.manager
  if m and m.playerBadgeCount then return m:playerBadgeCount() end
  return 0
end

function Rangers:storyReady(world)
  local m = self.manager
  if not (m and m.ready) then return false end
  -- Appear after Pewter, same gate as Rocket, so early game stays clean.
  return self:playerBadgeCount() >= 1
end

function Rangers:classForMember(member)
  return member and member.trainerClass or nil
end

function Rangers:memberById(id)
  for _, m in ipairs(self.members or {}) do
    if m.id == id then return m end
  end
  return nil
end

function Rangers:memberForClass(class)
  for _, m in ipairs(self.members or {}) do
    if m.trainerClass == class then return m end
  end
  return nil
end

function Rangers:partyForClass(class)
  local m = self:memberForClass(class)
  if not m then return nil end
  local out = {}
  local badgeBoost = math.max(0, self:playerBadgeCount() - 1) * 2
  for _, slot in ipairs(m.party or {}) do
    out[#out + 1] = {
      species = slot.species,
      level = math.min(70, (tonumber(slot.level) or 30) + badgeBoost),
    }
  end
  return out
end

function Rangers:bindTrainerSlots()
  local gen2 = self.data and self.data.gen2Trainers
  local classes = gen2 and gen2.classes
  local trainers = self.data and self.data.trainers or {}
  for _, member in ipairs(self.members or {}) do
    local class = self:classForMember(member)
    local party = self:partyForClass(class) or { { species="FEAROW", level=30 } }
    local rec = (type(classes)=="table" and classes[class]) or trainers[class]
    if type(rec)=="table" then
      rec.name = member.name
      if type(rec.trainers)=="table" then
        local row = rec.trainers[1]
        if type(row)=="table" then
          row.name = member.name
          row.party = Util.copy(party)
        end
        member.gen2ClassIndex = tonumber(rec.index) or member.gen2ClassIndex
      else
        rec.parties = { Util.copy(party) }
      end
    end
  end
end

function Rangers:registerTrainers()
  return self:bindTrainerSlots()
end

function Rangers:travelInterval(member)
  local base = 36
  if member and member.rank == "Captain" then base = 30 end
  return base + self.rng:int(0, 10)
end

function Rangers:travelReady(member)
  if not member then return false end
  member.travelClock = (tonumber(member.travelClock) or 0) + 1
  if member.travelClock < self:travelInterval(member) then return false end
  member.travelClock = 0
  return true
end

function Rangers:assignRoute(member, destination)
  if not destination or not self.manager or not self.manager.graph then return false end
  local route = self.manager.graph:route(member.map, destination)
  if not route or #route < 2 then return false end
  member.destination, member.route, member.routeIndex = destination, route, 2
  member.objective = "TRAVELLING"
  return true
end

function Rangers:advanceMember(member)
  if not member.destination or not member.route then return false end
  if not self:travelReady(member) then return false end
  local nextMap = member.route[member.routeIndex]
  if not nextMap then
    member.destination, member.route, member.routeIndex = nil, nil, 1
    member.objective = "PATROL"
    return false
  end
  member.map = nextMap
  member.routeIndex = member.routeIndex + 1
  if member.routeIndex > #member.route then
    member.destination, member.route, member.routeIndex = nil, nil, 1
    member.objective = "PATROL"
  end
  return true
end


-- ------------------------------------------------------------------
-- 6.1.0 RANGER ORGANISATION
-- ------------------------------------------------------------------

function Rangers:generateOrganisation()
  if self.command then return end
  local doctrines = { "CONSERVATION", "ENFORCEMENT", "INTELLIGENCE", "COMMUNITY", "MOBILE_RESPONSE" }
  local commander = self.members and self.members[1]
  self.command = {
    commanderId = commander and commander.id or nil,
    commanderName = commander and commander.name or "Ranger Commander",
    doctrine = doctrines[self.rng:int(1, #doctrines)],
    readiness = self.rng:int(45, 85),
    intelligence = self.rng:int(30, 80),
    conservation = self.rng:int(35, 90),
  }
  -- Give every generated Ranger a durable service record and jurisdiction.
  local targets = self:patrolTargets()
  for i, member in ipairs(self.members or {}) do
    member.servicePoints = tonumber(member.servicePoints) or (member.rank == "Captain" and 65 or 8)
    member.missionsCompleted = tonumber(member.missionsCompleted) or 0
    member.raids = tonumber(member.raids) or 0
    member.rank = member.rank or (i <= 2 and "Captain" or "Ranger")
    local mapId = targets[((i - 1) % math.max(1, #targets)) + 1] or member.map
    member.jurisdiction = member.jurisdiction or mapId
    if mapId then self.jurisdictions[mapId] = self.jurisdictions[mapId] or member.id end
  end
end

function Rangers:rankForPoints(points)
  points = tonumber(points) or 0
  if points >= 120 then return "Regional Commander" end
  if points >= 65 then return "Captain" end
  if points >= 25 then return "Field Ranger" end
  if points >= 8 then return "Ranger" end
  return "Volunteer"
end

function Rangers:creditService(member, points, reason)
  if not member then return false end
  member.servicePoints = math.max(0, (tonumber(member.servicePoints) or 0) + (tonumber(points) or 0))
  local old = member.rank
  local nextRank = self:rankForPoints(member.servicePoints)
  if old ~= nextRank then
    member.rank = nextRank
    self:log(member.name .. " was promoted to " .. nextRank .. ".", "promotion",
      { rangerId=member.id, reason=reason, rank=nextRank })
  end
  return true
end

function Rangers:discoverRocketBase(mapId, source)
  if not mapId then return false end
  local rocket = self.manager and self.manager.rocket
  local base = rocket and rocket.bases and rocket.bases[mapId]
  if not base then return false end
  local row = self.intelligence[mapId] or { map=mapId, confidence=0, discoveredTick=self.tick }
  local gain = source == "raid" and 35 or source == "rival" and 18 or 12
  row.confidence = clamp((tonumber(row.confidence) or 0) + gain, 0, 100)
  row.lastSeenTick = self.tick
  row.baseLevel = tonumber(base.level) or 1
  row.known = row.confidence >= 40
  self.intelligence[mapId] = row
  if row.known and not row.announced then
    row.announced = true
    self:log("Rangers identified a Team Rocket base in " .. tostring(mapId):gsub("_", " ") .. ".",
      "intelligence", { location=mapId, source=source })
  end
  return row.known
end

function Rangers:knownRocketBases()
  local out = {}
  for mapId, row in pairs(self.intelligence or {}) do
    if row.known then out[#out+1] = { map=mapId, confidence=tonumber(row.confidence) or 0 } end
  end
  table.sort(out, function(a,b)
    if a.confidence ~= b.confidence then return a.confidence > b.confidence end
    return a.map < b.map
  end)
  return out
end

function Rangers:raidBase(mapId)
  local rocket = self.manager and self.manager.rocket
  local base = rocket and rocket.bases and rocket.bases[mapId]
  if not base then return false end
  local intel = self.intelligence[mapId]
  if not (intel and intel.known) then return false end
  local cost = 12 + (tonumber(base.level) or 1) * 5
  if (tonumber(self.resources) or 0) < cost then return false end
  self.resources = math.max(0, (tonumber(self.resources) or 0) - cost)
  local rangerPower = 35 + (self.command and tonumber(self.command.readiness) or 50)
    + math.min(50, tonumber(intel.confidence) or 0)
  local rocketPower = 45 + (tonumber(base.level) or 1) * 22
    + math.min(50, tonumber(rocket.territory and rocket.territory[mapId]) or 0) * 2
  local chance = clamp(rangerPower / math.max(1, rangerPower + rocketPower), 0.18, 0.82)
  local success = self.rng:chance(chance)
  local record = { map=mapId, tick=self.tick, success=success, cost=cost }
  self.raids[#self.raids+1] = record
  while #self.raids > 40 do table.remove(self.raids, 1) end
  if success then
    if rocket.recordTerritory then rocket:recordTerritory(mapId, -6, "ranger raid") end
    base.level = math.max(0, (tonumber(base.level) or 1) - 1)
    if base.level <= 0 and not base.home then
      rocket.bases[mapId] = nil
      self:log("Rangers dismantled Team Rocket's base in " .. tostring(mapId):gsub("_", " ") .. ".",
        "raid", { location=mapId, success=true })
    else
      self:log("Rangers struck Team Rocket's base in " .. tostring(mapId):gsub("_", " ") .. ".",
        "raid", { location=mapId, success=true })
    end
    for _, member in ipairs(self.members or {}) do
      if member.active and member.map == mapId then
        member.raids = (member.raids or 0) + 1
        self:creditService(member, 8, "raid")
      end
    end
  else
    intel.confidence = math.max(20, (tonumber(intel.confidence) or 40) - 10)
    self:log("A Ranger raid in " .. tostring(mapId):gsub("_", " ") .. " was repelled.",
      "raid", { location=mapId, success=false })
  end
  return success
end

function Rangers:strategicPulse()
  self.strategyTick = (tonumber(self.strategyTick) or 0) + 1
  local rocket = self.manager and self.manager.rocket
  local ws = self.manager and self.manager.worldState
  local pressure = 0
  if ws and ws.routes then
    for mapId, row in pairs(ws.routes) do
      pressure = pressure + (tonumber(row.rocket) or 0)
      if (tonumber(row.rocket) or 0) >= 3 then
        local intel = self.intelligence[mapId] or { map=mapId, confidence=0 }
        local doctrine = self.command and self.command.doctrine or "CONSERVATION"
        local gain = doctrine == "INTELLIGENCE" and 5 or 2
        intel.confidence = clamp((tonumber(intel.confidence) or 0) + gain, 0, 100)
        intel.lastSeenTick = self.tick
        self.intelligence[mapId] = intel
      end
    end
  end
  self.resources = clamp((tonumber(self.resources) or 90) + 3 - pressure * 0.01, 0, 220)
  -- Base discovery is intentionally gradual. Visible pressure produces clues;
  -- a confirmed base still needs sufficient confidence before a raid can fire.
  for mapId in pairs(rocket and rocket.bases or {}) do
    local row = ws and ws.routes and ws.routes[mapId]
    if row and (tonumber(row.rocket) or 0) > 1 then self:discoverRocketBase(mapId, "patrol") end
  end
  local known = self:knownRocketBases()
  if #known > 0 and self.rng:chance(0.22) then self:raidBase(known[1].map) end
end

function Rangers:findRocketOnMap(mapId)
  local rocket = self.manager and self.manager.rocket
  if not rocket then return nil end
  for _, member in ipairs(rocket.members or {}) do
    if member.active and member.map == mapId and not member.defeatedUntil then
      return member
    end
  end
  return nil
end

function Rangers:arrestRocket(ranger, rocketMember)
  if not (ranger and rocketMember) then return false end
  rocketMember.active = false
  rocketMember.defeatedUntil = self.tick + 400 + self.rng:int(0, 200)
  local rocketHome = self.manager and self.manager.rocket and self.manager.rocket.home
  rocketMember.map = rocketHome or rocketMember.map
  ranger.arrests = (ranger.arrests or 0) + 1
  ranger.successes = (ranger.successes or 0) + 1
  self:creditService(ranger, 3, "arrest")
  self.arrested[rocketMember.id] = rocketMember.defeatedUntil
  self:log(ranger.name .. " arrested " .. tostring(rocketMember.name)
    .. " in " .. tostring(ranger.map) .. ".", "arrest", {
      rangerId = ranger.id, rocketId = rocketMember.id,
    })
  return true
end

function Rangers:attemptRecruit(ranger)
  local rivals = self.manager and self.manager.rivals or {}
  local candidates = {}
  for _, rival in ipairs(rivals) do
    if rival and rival.map == ranger.map and not rival.rocketAffiliation
       and not rival.rangerAffiliation and #(rival.party or {}) > 0 then
      candidates[#candidates + 1] = rival
    end
  end
  if #candidates == 0 then return false end
  local rival = candidates[self.rng:int(1, #candidates)]
  -- Rangers recruit more easily than Rocket; still not automatic.
  local chance = 0.18
  pcall(function()
    local bond = rival.bondWith and rival:bondWith("player")
    -- Rivals who dislike Rocket lean ranger.
    if rival.disposition and tonumber(rival.disposition.rocket) then
      chance = chance + math.max(0, -tonumber(rival.disposition.rocket)) * 0.05
    end
  end)
  chance=chance*Happiness.rangerRecruitMultiplier(rival)
  if not self.rng:chance(clamp(chance, 0.05, 0.70)) then
    self.recruitment[#self.recruitment + 1] = {
      rivalId = rival.id, rangerId = ranger.id, success = false, tick = self.tick,
    }
    return false
  end
  rival.rangerAffiliation = {
    rangerId = ranger.id, joinedTick = self.tick, rank = "Volunteer", servicePoints = 0, missions = 0,
  }
  rival.objective = "RANGER"
  ranger.recruits = (ranger.recruits or 0) + 1
  self.recruitment[#self.recruitment + 1] = {
    rivalId = rival.id, rangerId = ranger.id, success = true, tick = self.tick,
  }
  self:log(rival.name .. " joined the Rangers under " .. ranger.name .. ".",
    "recruitment", { rivalId = rival.id, rangerId = ranger.id })
  return true
end

function Rangers:patrolTargets()
  local graph = self.manager and self.manager.graph
  local out = {}
  for _, id in ipairs(HOME_CANDIDATES) do
    if not graph or not graph.has or graph:has(id) then out[#out + 1] = id end
  end
  -- Prefer maps where Rocket is active.
  local rocket = self.manager and self.manager.rocket
  if rocket then
    local hot = {}
    for _, m in ipairs(rocket.members or {}) do
      if m.active and m.map then hot[m.map] = true end
    end
    for mapId in pairs(hot) do
      local found = false
      for _, id in ipairs(out) do if id == mapId then found = true break end end
      if not found then out[#out + 1] = mapId end
    end
  end
  return out
end


function Rangers:activeRocketMaps()
  local rocket = self.manager and self.manager.rocket
  local maps = {}
  if not rocket then return maps end
  for _, m in ipairs(rocket.members or {}) do
    if m.active and m.map and not m.defeatedUntil then maps[m.map] = true end
  end
  local out = {}
  for mapId in pairs(maps) do out[#out+1]=mapId end
  table.sort(out)
  return out
end

function Rangers:missionForMap(mapId)
  for _, mission in ipairs(self.missions or {}) do
    if mission.active ~= false and mission.map == mapId then return mission end
  end
  return nil
end

function Rangers:ensureMission(world)
  local maps = self:activeRocketMaps()
  if #maps == 0 then return nil end
  local mapId = maps[((self.missionCursor or 0) % #maps) + 1]
  local existing = self:missionForMap(mapId)
  if existing then return existing end
  self.missionCursor = (self.missionCursor or 0) + 1
  local types = {"POACHING","PROTECT","CONVOY","RESCUE","OPERATION","RECRUITMENT","HABITAT","LAST_STAND"}
  local kind = types[((self.missionCursor - 1) % #types)+1]
  local counts = {POACHING=25,PROTECT=12,CONVOY=8,RESCUE=10,OPERATION=15,RECRUITMENT=10,HABITAT=12,LAST_STAND=20}
  local mission = {
    id="ranger_op_"..tostring(self.tick).."_"..tostring(self.missionCursor),
    kind=kind, map=mapId, required=counts[kind] or 10, progress=0,
    active=true, assignedRivalId=nil, createdTick=self.tick,
  }
  self.missions[#self.missions+1]=mission
  while #self.missions > 12 do table.remove(self.missions,1) end
  return mission
end

function Rangers:aiMissionFor(rival, world)
  if not rival or rival.rocketAffiliation then return nil end
  if not rival.party or #rival.party == 0 then return nil end
  local mission = self:ensureMission(world)
  if not mission or mission.assignedRivalId then return nil end
  if not rival.ctx or not rival.ctx.graph:has(mission.map) then return nil end
  if rival.routeTo and not rival:routeTo(mission.map) then return nil end
  return mission
end

function Rangers:takeAIMission(rival, mission)
  if not (rival and mission) then return false end
  if mission.assignedRivalId and mission.assignedRivalId ~= rival.id then return false end
  mission.assignedRivalId = rival.id
  rival.rangerMissionId = mission.id
  return true
end

function Rangers:resolveAIMission(rival, mission, world)
  if not (rival and mission and mission.active ~= false) then return false end
  if mission.assignedRivalId ~= rival.id or rival.map ~= mission.map then return false end
  local rocket = self.manager and self.manager.rocket
  local target
  for _, m in ipairs(rocket and rocket.members or {}) do
    if m.active and m.map == mission.map and not m.defeatedUntil then target=m; break end
  end
  if not target then
    mission.assignedRivalId=nil
    rival.rangerMissionId=nil
    return false
  end
  target.defeatedUntil = (rocket.tick or self.tick) + 24
  target.active = false
  mission.progress = (mission.progress or 0) + 1
  rival.rangerMissions = (rival.rangerMissions or 0) + 1
  if rival.creditLeadBattle then pcall(rival.creditLeadBattle, rival, true) end
  if mission.progress >= mission.required then
    mission.active=false
    mission.completedTick=self.tick
    self.resources = clamp((tonumber(self.resources) or 0) + 4, 0, 220)
    if rival.rangerAffiliation then
      rival.rangerAffiliation.missions = (tonumber(rival.rangerAffiliation.missions) or 0) + 1
      rival.rangerAffiliation.servicePoints = (tonumber(rival.rangerAffiliation.servicePoints) or 0) + 6
      rival.rangerAffiliation.rank = self:rankForPoints(rival.rangerAffiliation.servicePoints)
    end
    self:log(rival.name .. " completed a Ranger operation in " .. mission.map .. ".", "mission", {rangerId=rival.id, missionId=mission.id, location=mission.map})
  end
  mission.assignedRivalId=nil
  rival.rangerMissionId=nil
  return true
end

function Rangers:update(dt, world)
  if not self.enabled then return false end
  self.tick = self.tick + 1
  for _,r in ipairs(self.members or {}) do r.wonderTradeCooldown=math.max(0,(tonumber(r.wonderTradeCooldown) or 0)-1) end
  if not self:storyReady(world) then return false end
  if self.tick % 60 == 0 then self:strategicPulse() end

  -- Release expired arrests.
  for _, member in ipairs((self.manager and self.manager.rocket and self.manager.rocket.members) or {}) do
    if member.defeatedUntil and self.tick >= member.defeatedUntil then
      member.defeatedUntil = nil
      member.active = true
    end
  end

  for _, ranger in ipairs(self.members) do
    if ranger.active then
      if (tonumber(ranger.balls) or 0)<=0 and self.tick%120==0 then AgentCatching.restock(ranger,4) end
      if not ranger.destination then
        local mon=AgentCatching.tryCatch(ranger,self.data,self.rng,{chance=0.08*TrainerClasses.catchMultiplier(ranger,self.data,nil,{}),defaultLevel=ranger.baseLevel,origin="ranger_wild"})
        if mon then self:log(ranger.name.." caught "..tostring(mon.species).." while patrolling "..tostring(ranger.map)..".","catch",{rangerId=ranger.id,species=mon.species,map=ranger.map}) end
      end
      if ranger.destination then
        self:advanceMember(ranger)
      else
        -- 7.0.0: Rangers use the same Wonder Trader network as rivals/player.
        -- Keep it occasional so their teams retain an identity.
        if (ranger.wonderTradeCooldown or 0)<=0 and self.rng:chance(0.015) then
          local ok,W=pcall(req,"src/WonderTrade")
          if ok and W and W.simulateAgent then
            local tr=W.simulateAgent(self.manager,ranger,self.rng,{faction="rangers",cooldown=180})
            if tr then self:log(ranger.name.." used the Wonder Trader and received "..tostring(tr.got)..".","trade",{rangerId=ranger.id,species=tr.got}) end
          end
        end
        local rocket = self:findRocketOnMap(ranger.map)
        if rocket then self:discoverRocketBase(ranger.map, "patrol") end
        if rocket and self.rng:chance(0.35) then
          self:arrestRocket(ranger, rocket)
        elseif self.rng:chance(0.12) then
          self:attemptRecruit(ranger)
        elseif self.tick >= self.nextOp then
          local targets = self:patrolTargets()
          if #targets > 0 then
            local dest = targets[self.rng:int(1, #targets)]
            if dest ~= ranger.map then self:assignRoute(ranger, dest) end
          end
        end
      end
    end
  end
  if self.tick >= self.nextOp then
    self.nextOp = self.tick + 50 + self.rng:int(0, 40)
  end
  return true
end

-- Fully heal the player's party. Rangers are neutral and helpful.
function Rangers:healPlayer()
  local save = self.manager and self.manager.game and self.manager.game.save
  local party = save and save.party
  if type(party) ~= "table" then return false, "No party to heal." end
  for _, mon in ipairs(party) do
    if type(mon) == "table" then
      local maxHp = tonumber(mon.maxHp or mon.maxhp or mon.hp)
      if maxHp and maxHp > 0 then mon.hp = maxHp end
      if type(mon.status) ~= "nil" then mon.status = 0 end
      if type(mon.moves) == "table" then
        for _, move in ipairs(mon.moves) do
          if type(move) == "table" and move.pp and move.maxPp then
            move.pp = move.maxPp
          end
        end
      end
    end
  end
  return true, "Your Pokémon were fully healed."
end

function Rangers:dialogueFor(member, context)
  local name = member and member.name or "Ranger"
  if context == "heal" then
    return name .. ": Let me take a look at your Pokémon."
  end
  if context == "challenge" then
    return name .. ": A friendly match, then. Show me what you've got!"
  end
  if context == "quest" then
    return name .. ": Team Rocket is active nearby. Help us keep the routes safe."
  end
  if context == "mission" and type(self.pendingMissionDialogue) == "string" then
    return self.pendingMissionDialogue
  end
  return name .. ": Stay safe out there. We're watching for Team Rocket."
end

function Rangers:memberAtNpc(npcId, npcName)
  if not npcId and not npcName then return nil end
  local name = type(npcName) == "string" and npcName or nil
  for _, m in ipairs(self.members or {}) do
    if name and (name == m.name or name == "AIR_" .. m.id
        or name == "AIR_RANGER_" .. tostring(m.id)
        or name == m.trainerClass
        or name:find("AIR_RANGER", 1, true)) then
      return m
    end
    if npcId and (tostring(npcId) == tostring(m.spawnHandle)
        or tostring(npcId) == tostring(m.spawnId)) then
      return m
    end
  end
  return nil
end

-- HQ map used for the quest board / heal NPC presence.
function Rangers:hqMap()
  local graph = self.manager and self.manager.graph
  for _, id in ipairs({ "CERULEAN_CITY", "FUCHSIA_CITY", "SAFFRON_CITY", "PEWTER_CITY" }) do
    if not graph or not graph.has or graph:has(id) then return id end
  end
  return self:pickHome()
end

function Rangers:spawnFor(mapId, world)
  local manager = self.manager or self.M or self.owner
  if manager and manager.mapAllowsRuntimeActors
     and not manager:mapAllowsRuntimeActors(mapId) then
    return 0
  end
  local manager = self.manager or self.M or self.owner
  if manager and manager.runtimeObjectsSafe
     and not manager:runtimeObjectsSafe(mapId) then
    return 0
  end
  if not mapId or not self:storyReady(world) then return 0 end
  local spawned = 0
  local overview
  pcall(function()
    if mod.world and mod.world.mapOverview then overview = mod.world:mapOverview() end
  end)
  for _, member in ipairs(self.members or {}) do
    if member.active and member.map == mapId and not member.spawnHandle then
      member.spawnId = member.spawnId or ("AIR_RANGER_" .. member.id)
      local x, y = member.x, member.y
      if not (x and y) then
        -- Prefer near player if present, else a stable hash cell.
        local px, py
        pcall(function()
          local w = world or (self.manager and self.manager.worldView and self.manager:worldView())
          if w then px, py = w.playerX, w.playerY end
        end)
        local seed = (tonumber(member.id:match("%d+")) or 1) * 17
        x = (px and (px + 2 + (seed % 3))) or (4 + (seed % 8))
        y = (py and (py + 1 + (seed % 2))) or (4 + (seed % 6))
      end
      local sprite = "COOLTRAINER_M"
      pcall(function()
        if self.manager and self.manager.safeSprite then
          sprite = self.manager:safeSprite(
            member.gender == "F" and "COOLTRAINER_F" or "COOLTRAINER_M") or sprite
        end
      end)
      local objDef = {
        index = 70 + spawned,
        name = member.spawnId,
        sprite = sprite,
        x = x, y = y,
        movement = "STAY",
        range = "DOWN",
        solid = false, passable = true, through = true,
        text = (self.manager and self.manager.generation == 1) and "TEXT_AIR_TALK" or nil,
      }
      local npcId
      if mod.world and type(mod.world.spawnNpc) == "function" then
        local ok, a = pcall(function() return mod.world:spawnNpc(mapId, objDef) end)
        if ok and a then npcId = a end
      end
      if npcId then
        member.spawnHandle = npcId
        member.x, member.y = x, y
        spawned = spawned + 1
      else
        -- Soft presence even without a handle so talk-by-name still works.
        spawned = spawned + 1
      end
    end
  end
  return spawned
end

function Rangers:despawnAll()
  for _, member in ipairs(self.members or {}) do
    if member.spawnHandle then
      pcall(function() mod.world:removeNpc(member.spawnHandle) end)
      member.spawnHandle = nil
    end
  end
end

function Rangers:interactItems(member)
  if not member then return {} end
  return {
    { label = "HEAL MY POKEMON", right = "FULL", value = "_heal" },
    { label = "CHALLENGE", right = "BATTLE", value = "_challenge" },
    { label = "ASK FOR QUEST", right = ">", value = "_quest" },
    { label = "GOODBYE", value = "_goodbye" },
  }
end

function Rangers:performAction(member, value)
  if not member then return false, "No ranger." end
  if value == "_heal" then
    local ok, line = self:healPlayer()
    if ok and self.manager and self.manager.factions then
      self.manager.factions:adjust("rangers", 2, "heal")
    end
    return ok, line or self:dialogueFor(member, "heal")
  end
  if value == "_challenge" then
    local m = self.manager
    if not m then return false, "Cannot battle." end
    local class = self:classForMember(member)
    if not class then return false, "No battle class." end
    m.pendingRanger = member
    local line = self:dialogueFor(member, "challenge")
    local ok = false
    pcall(function()
      local ow = m.getOverworld and m:getOverworld()
      local rows = {
        { "show_text", line },
        { "start_battle", "trainer", class, 1 },
      }
      if ow and ow.runner and type(ow.runner.run) == "function" then
        ok = ow.runner:run(rows) and true or false
      elseif ow and type(ow.queueScript) == "function" then
        ok = ow:queueScript(rows) and true or false
      end
    end)
    if ok and m.factions then m.factions:adjust("rangers", 1, "challenge") end
    return ok, ok and line or "Could not start the battle."
  end
  if value == "_quest" then
    local m = self.manager
    if m and m.quests and m.quests.rangerMissionOffer then
      local q = m.quests.takePendingFollowUp and m.quests:takePendingFollowUp(member.id,member.name) or nil
      local alreadyAdded = q ~= nil
      if not q then q = m.quests:rangerMissionOffer(member) end
      if q and not m.quests:hasObjective(q) then
        m.quests.offers = m.quests.offers or {}
        if not alreadyAdded then m.quests.offers[#m.quests.offers + 1] = q end
        if m.factions then m.factions:adjust("rangers", 3, "quest") end
        return true, q.dialogue or q.description
      end
    end
    return false, member.name .. ": No Ranger operation needs another trainer right now."
  end
  return true, self:dialogueFor(member, "hello")
end

function Rangers:serialize()
  return {
    version = 2,
    seed = self.seed,
    tick = self.tick,
    nextOp = self.nextOp,
    members = Util.copy(self.members),
    arrested = Util.copy(self.arrested),
    recruitment = Util.copy(self.recruitment),
    news = Util.copy(self.news),
    missions = Util.copy(self.missions),
    missionCursor = self.missionCursor,
    resources = self.resources,
    command = Util.copy(self.command),
    jurisdictions = Util.copy(self.jurisdictions),
    intelligence = Util.copy(self.intelligence),
    raids = Util.copy(self.raids),
    strategyTick = self.strategyTick,
    rngState = self.rng and self.rng.state or nil,
  }
end

function Rangers:load(saved)
  if type(saved) ~= "table" then return end
  self.seed = tonumber(saved.seed) or self.seed
  self.rng = Util.rng(self.seed + 4242)
  if saved.rngState then self.rng.state = tonumber(saved.rngState) or self.rng.state end
  self.tick = tonumber(saved.tick) or 0
  self.nextOp = tonumber(saved.nextOp) or 40
  if type(saved.members) == "table" and #saved.members > 0 then
    self.members = saved.members
  end
  self.arrested = type(saved.arrested) == "table" and saved.arrested or {}
  self.recruitment = type(saved.recruitment) == "table" and saved.recruitment or {}
  self.news = type(saved.news) == "table" and saved.news or {}
  self.missions = type(saved.missions) == "table" and saved.missions or {}
  self.missionCursor = tonumber(saved.missionCursor) or 0
  self.resources = tonumber(saved.resources) or self.resources or 90
  self.command = type(saved.command) == "table" and saved.command or self.command
  self.jurisdictions = type(saved.jurisdictions) == "table" and saved.jurisdictions or self.jurisdictions or {}
  self.intelligence = type(saved.intelligence) == "table" and saved.intelligence or self.intelligence or {}
  self.raids = type(saved.raids) == "table" and saved.raids or self.raids or {}
  self.strategyTick = tonumber(saved.strategyTick) or 0
  self:generateOrganisation()
end

return Rangers
