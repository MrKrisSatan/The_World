-- Frame-to-simulation policy. This module owns timing decisions; main.lua
-- remains responsible only for engine hook composition and presentation.
local RuntimePolicy = {}

function RuntimePolicy.trackPlayerMotion(manager, world, dt)
  local playerMap = world and world.playerMap
  if world and playerMap and world.playerX ~= nil and world.playerY ~= nil then
    local key = tostring(playerMap) .. ":" .. tostring(world.playerX)
      .. ":" .. tostring(world.playerY)
    if manager.lastPlayerCell ~= key then
      local moved = manager.lastPlayerCell ~= nil
      manager.lastPlayerCell = key
      manager.playerIdleSeconds = 0
      if moved then
        manager.playerSteps = (tonumber(manager.playerSteps) or 0) + 1
        if manager.quests and manager.quests.onPlayerStep then
          pcall(function() manager.quests:onPlayerStep() end)
        end
      end
    else
      manager.playerIdleSeconds = (manager.playerIdleSeconds or 0)
        + (tonumber(dt) or 0)
    end
    world.playerMoving = (manager.playerIdleSeconds or 0) < 0.45
  else
    manager.lastPlayerCell, manager.playerIdleSeconds = nil, 0
    if world then world.playerMoving = false end
  end
  return world and world.playerMoving or false
end

function RuntimePolicy.configure(sim, performance, paceSeconds)
  performance = performance or "balanced"
  sim.budget = performance == "low" and 1
    or (performance == "full" and 4 or 2)
  sim.socialInterval = performance == "low" and 4
    or (performance == "full" and 1 or 2)
  sim.tickSeconds = paceSeconds
end

return RuntimePolicy
