local S = {}
S.SLOT_COUNT = 8
S.INDEX_BASE = 200
S.placeholderSprite = nil

local function generation(manager)
  local d = manager and manager.data
  return type(d)=="table" and (d.gen2Maps or d.gen2Trainers) and 2 or 1
end
local function mapsFor(manager)
  local d=manager and manager.data
  return d and (d.gen2Maps or d.maps)
end
local function tilesetsFor(manager)
  local d=manager and manager.data
  return d and (d.gen2Tilesets or d.tilesets)
end
local function connected(def)
  if type(def)~="table" or type(def.connections)~="table" then return false end
  for _,c in pairs(def.connections) do if c then return true end end
  return false
end
local function slotName(i) return "AIR_STATIC_RIVAL_SLOT_"..tostring(i) end

local function placeholder(manager)
  if S.placeholderSprite then return S.placeholderSprite end
  local sprite
  pcall(function()
    sprite=manager.sprites:npcFor("rival",manager.data,{
      "SPRITE_BLUE","SPRITE_RED","SPRITE_YOUNGSTER","SPRITE_LASS",
      "SPRITE_COOLTRAINER_M","SPRITE_COOLTRAINER_F",
    })
  end)
  if not sprite then
    local t=manager and manager.data and (manager.data.gen2Sprites or manager.data.sprites)
    if type(t)=="table" then
      for id,def in pairs(t) do
        if type(def)=="table" and def.walker~=false then sprite=id break end
      end
    end
  end
  S.placeholderSprite=sprite
  return sprite
end

local function ensureMapSlots(manager,def)
  if not connected(def) then return false end
  def.objects=def.objects or {}
  local slots={}
  for _,o in ipairs(def.objects) do
    if o and o.airStaticRivalSlot then slots[o.airStaticRivalSlot]=o end
  end
  local sprite=placeholder(manager)
  if not sprite then return false end
  local gen=generation(manager)
  for i=1,S.SLOT_COUNT do
    if not slots[i] then
      def.objects[#def.objects+1]={
        index=S.INDEX_BASE+i-1,x=255,y=255,sprite=sprite,
        movement=gen==2 and 6 or "STAY",range="DOWN",
        text=gen==1 and "AIR_RIVAL_TALK" or nil,
        name=slotName(i),solid=false,passable=true,through=true,
        airStaticRivalSlot=i,
      }
    end
  end
  return true
end

function S.ensureSlots(manager)
  local maps=mapsFor(manager)
  if type(maps)~="table" then return 0 end
  local n=0
  for _,def in pairs(maps) do
    if ensureMapSlots(manager,def) then n=n+1 end
  end
  return n
end

local function rawMapModule(manager)
  local ok,Map
  if generation(manager)==2 then ok,Map=pcall(require,"src.world.gen2.Map")
  else ok,Map=pcall(require,"src.world.Map") end
  return ok and Map or nil
end

local function usedCells(def)
  local used={}
  for _,o in ipairs(def.objects or {}) do
    if o and not o.airStaticRivalSlot and o.x~=nil and o.y~=nil then
      used[tostring(o.x)..":"..tostring(o.y)]=true
    end
  end
  return used
end
local function isWarp(def,x,y)
  for _,w in ipairs(def.warps or {}) do if w.x==x and w.y==y then return true end end
  return false
end
local function nearConnection(def,x,y)
  local w,h=(def.width or 0)*2,(def.height or 0)*2
  local m=2
  for dir,c in pairs(def.connections or {}) do
    if c then
      local d=tostring(dir):lower()
      if (d=="north" or d=="up") and y<=m then return true end
      if (d=="south" or d=="down") and y>=h-1-m then return true end
      if (d=="west" or d=="left") and x<=m then return true end
      if (d=="east" or d=="right") and x>=w-1-m then return true end
    end
  end
  return false
end
local function passable(manager,def,x,y)
  local Map=rawMapModule(manager)
  local ts=tilesetsFor(manager)
  ts=ts and def and ts[def.tileset]
  if not (Map and ts) then return false end
  if type(Map.defPassable)=="function" then
    local ok,v=pcall(Map.defPassable,def,ts,x,y,false)
    return ok and v==true
  end
  return false
end

local function grassCell(manager,def,x,y)
  local Map=rawMapModule(manager)
  local ts=tilesetsFor(manager)
  ts=ts and def and ts[def.tileset]
  if not (Map and ts and type(Map.defCellTile)=="function") then return false end
  local ok,tile=pcall(Map.defCellTile,def,ts,x,y)
  if not ok or tile==nil then return false end

  if generation(manager)==2 then
    local okP,Permissions=pcall(require,"src.world.gen2.Permissions")
    return okP and Permissions and Permissions.isGrass
      and Permissions.isGrass(tile)==true
  end

  -- Gen 1's collision tile is the actual 8x8 tile id; each outdoor tileset
  -- explicitly identifies its tall-grass tile.
  return ts.grassTile~=nil and tile==ts.grassTile
end

local function wantsGrass(rival)
  if not rival then return false end
  if rival.state=="TRAINING" then return true end
  -- Hunting/catching is performed inside the training loop, but preserve the
  -- semantic preference if another personality/state machine exposes a hunt.
  if rival.huntTarget then return true end
  local reason=string.lower(tostring(rival.stateReason or ""))
  return reason:find("catch",1,true)~=nil
      or reason:find("hunt",1,true)~=nil
      or reason:find("train",1,true)~=nil
end

local function positions(manager,def,rivals)
  local candidates,occupied={},usedCells(def)
  local w,h=(def.width or 0)*2,(def.height or 0)*2
  if w<3 or h<3 then return {} end
  local cx,cy=math.floor(w/2),math.floor(h/2)
  local seen={}

  local function add(x,y)
    local k=tostring(x)..":"..tostring(y)
    if seen[k] then return end
    seen[k]=true
    if x<1 or y<1 or x>w-2 or y>h-2 or occupied[k] then return end
    if isWarp(def,x,y) or nearConnection(def,x,y) then return end
    if not passable(manager,def,x,y) then return end
    candidates[#candidates+1]={x=x,y=y,key=k,grass=grassCell(manager,def,x,y)}
  end

  -- Stable centre-out order, then full scan. This keeps models predictable
  -- while still allowing grass preference to select a more believable cell.
  for r=0,math.max(w,h) do
    add(cx+r,cy); add(cx-r,cy); add(cx,cy+r); add(cx,cy-r)
    add(cx+r,cy+1); add(cx-r,cy-1)
  end
  for y=1,h-2 do for x=1,w-2 do add(x,y) end end

  local chosen={}
  local taken={}
  local function pick(preferGrass)
    -- TRAINING/CATCHING: grass first. Everyone else: non-grass first so the
    -- grass is not filled by somebody who is merely passing through town.
    for pass=1,2 do
      for _,c in ipairs(candidates) do
        if not taken[c.key] then
          local match = preferGrass and c.grass or not c.grass
          if (pass==1 and match) or pass==2 then
            taken[c.key]=true
            return {c.x,c.y,grass=c.grass}
          end
        end
      end
    end
    return nil
  end

  -- Place active training/hunting rivals first so limited grass cells go to
  -- the people whose visible activity actually requires wild encounters.
  local order={}
  for i,r in ipairs(rivals or {}) do
    order[#order+1]={index=i,rival=r,grass=wantsGrass(r)}
  end
  table.sort(order,function(a,b)
    if a.grass~=b.grass then return a.grass end
    return tostring(a.rival.id)<tostring(b.rival.id)
  end)

  for _,row in ipairs(order) do
    chosen[row.index]=pick(row.grass)
  end
  return chosen
end

local function rivalSprite(manager,rival)
  local sprite
  pcall(function() sprite=manager:spriteForRival(rival) end)
  return sprite or placeholder(manager)
end

local function playerOpeningReady(manager)
  local game=manager and manager.game
  local save=game and game.save
  if not save then return false end

  -- Having a starter is NOT sufficient on Yellow. Pikachu's first lab ->
  -- Pallet handoff still owns the outdoor object/follower setup. Require the
  -- first post-starter connected-map entry to complete before AI map slots may
  -- be populated on a later map load.
  local party=save.party
  local hasPokemon=(type(party)=="table" and #party>0) or (manager and manager.playerLead)
  if not hasPokemon then return false end
  if manager and manager.playerOpeningOutdoorSafe~=true then return false end
  return true
end

local function hideAllSlots(manager,def)
  if type(def)~="table" then return end
  ensureMapSlots(manager,def)
  for _,o in ipairs(def.objects or {}) do
    if o and o.airStaticRivalSlot then
      o.x,o.y=255,255
      o.name=slotName(o.airStaticRivalSlot)
      o.text=nil
      o.sprite=placeholder(manager)
    end
  end
end

function S.prepareMap(manager,mapId)
  local maps=mapsFor(manager)
  local def=maps and maps[mapId]
  if not (def and connected(def)) then return 0 end

  -- Red/Blue/Yellow and Gold all perform extra player/new-game setup during
  -- the first indoor -> outdoor setMap. Do not populate AI-owned map slots in
  -- that fragile window. The slots remain predeclared but completely off-map.
  if not playerOpeningReady(manager) then
    hideAllSlots(manager,def)
    manager.staticRivalMap=nil
    return 0
  end

  ensureMapSlots(manager,def)
  local slots={}
  for _,o in ipairs(def.objects or {}) do
    if o and o.airStaticRivalSlot then slots[o.airStaticRivalSlot]=o end
  end
  local rivals={}
  for _,r in ipairs(manager.rivals or {}) do
    if r.map==mapId and #rivals<S.SLOT_COUNT then rivals[#rivals+1]=r end
  end
  table.sort(rivals,function(a,b) return tostring(a.id)<tostring(b.id) end)
  for _,r in ipairs(rivals) do
    r.staticInGrass=false
    r.staticActivity=nil
  end
  local pos=positions(manager,def,rivals)
  local gen=generation(manager)
  for i=1,S.SLOT_COUNT do
    local o,r,c=slots[i],rivals[i],pos[i]
    if o and r and c then
      o.x,o.y=c[1],c[2]
      o.sprite=rivalSprite(manager,r)
      o.name="AIR_"..tostring(r.id)
      o.text=gen==1 and "AIR_RIVAL_TALK" or nil
      o.movement=gen==2 and 6 or "STAY"
      o.range=(r.facing and tostring(r.facing):upper()) or "DOWN"
      o.solid,o.passable,o.through=false,true,true
      r.x,r.y=c[1],c[2]
      r.staticVisibleMap,r.staticSlot=mapId,i
      r.staticInGrass=c.grass==true
      r.staticActivity=wantsGrass(r) and "WILD_TRAINING" or "GENERAL"
    elseif o then
      o.x,o.y=255,255
      o.name=slotName(i)
      o.text=nil
      o.sprite=placeholder(manager)
    end
  end
  manager.staticRivalMap=mapId
  return math.min(#rivals,#pos)
end

function S.install(mod_,manager)
  S.ensureSlots(manager)
  if generation(manager)==2 then
    local ok,World=pcall(require,"src.world.gen2.World")
    if ok and type(World)=="table" and not World.__airStaticRivalsV742 then
      local prev=World.setMap
      if type(prev)=="function" then
        World.setMap=function(world,mapId,...)
          S.prepareMap(manager,mapId)
          return prev(world,mapId,...)
        end
        World.__airStaticRivalsV742=true
      end
    end
  else
    local ok,OW=pcall(require,"src.world.OverworldController")
    if ok and type(OW)=="table" and not OW.__airStaticRivalsV742 then
      local prev=OW.setMap
      if type(prev)=="function" then
        OW.setMap=function(world,mapId,...)
          S.prepareMap(manager,mapId)
          return prev(world,mapId,...)
        end
        OW.__airStaticRivalsV742=true
      end
    end
  end
  return true
end

return S
