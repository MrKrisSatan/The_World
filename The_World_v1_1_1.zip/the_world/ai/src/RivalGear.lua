
local req, mod = ...

-- Pokégear for both generations.
-- Gen 2 already has a native phone registry, but Gen 1 does not. This screen
-- therefore owns the presentation and uses src/Comms.lua as the common
-- persistent data model on Red, Blue, Yellow and Gold.
local RivalGear = {}

local STATIONS = {
  { id = "POKEMON_MUSIC", label = "POKEMON MUSIC", song = nil },
  { id = "TRAINER_RADIO", label = "TRAINER RADIO", song = nil },
  { id = "POKEDEX_RADIO", label = "POKEDEX RADIO", song = nil },
  { id = "OFF", label = "RADIO OFF", song = nil },
}

local function stationList(manager)
  local songs = {}
  local audio = manager and manager.data and manager.data.audio
  local source = audio and (audio.songs or audio.music)
  if type(source) == "table" then
    for id in pairs(source) do
      if type(id) == "string" then songs[#songs + 1] = id end
    end
  end
  table.sort(songs)
  local out = {}
  for i = 1, 3 do
    out[i] = {
      id = STATIONS[i].id,
      label = STATIONS[i].label,
      song = songs[i],
    }
  end
  out[4] = STATIONS[4]
  return out
end
local function now()
  if os and os.date then
    return os.date("%H:%M:%S"), os.date("%A %d %B %Y")
  end
  return "--:--:--", "DATE UNKNOWN"
end

local function shortMap(id)
  if not id then return "UNKNOWN" end
  return tostring(id):gsub("_", " ")
end


local function chosenValue(item)
  -- Gen1Recomp API 2 ListMenu passes the selected item table to onChoose.
  -- Older/community builds have sometimes passed the value directly, so keep
  -- the scalar fallback to make Pokégear portable across both shapes.
  if type(item) == "table" then return item.value end
  return item
end

-- ------------------------------------------------------------------
-- Conversation helpers (4.5.0)
-- ------------------------------------------------------------------

-- The engine's text box is 18 columns and shows the LAST TWO lines of
-- whatever it is given (src/render/TextBox.lua:21, ListMenu.lua:264-274), so
-- anything longer than two lines loses its beginning silently. Every spoken
-- line is therefore fitted to what the box can actually show.
local SPEECH_LIMIT = 36

local function speech(name, line)
  line = tostring(line or ""):gsub("%s+", " "):match("^%s*(.-)%s*$") or ""
  if line == "" then line = "..." end
  local prefix = ""
  -- Lines the manager builds already name the speaker; do not say it twice.
  if name and not line:upper():find(tostring(name):upper(), 1, true) then
    prefix = tostring(name):sub(1, 10) .. ": "
  end
  local text = prefix .. line
  if #text > SPEECH_LIMIT then text = text:sub(1, SPEECH_LIMIT) end
  return text
end

-- Same contract as main.lua's fitStatusRow: the label and the right-hand
-- status share one fixed-width row, so keep a blank column between them
-- rather than letting long pairs draw over one another (4.3.1).
local function fitRow(item)
  local label = tostring(item.label or "")
  local right = tostring(item.right or "")
  if #label > 10 then label = label:sub(1, 10) end
  local rightRoom = math.max(0, 16 - #label - 1)
  if #right > rightRoom then right = right:sub(1, rightRoom) end
  item.label, item.right = label, right
  return item
end

local function fitRows(items)
  for i = 1, #items do items[i] = fitRow(items[i]) end
  return items
end

-- A row with NO right-hand column is drawn from x=16 to the right margin at
-- x=152 (ListMenu.lua:222/236), which is seventeen 8px cells. fitRow's ten
-- characters is the LABEL half of a label+status pair and is far too tight for
-- a sentence, so full-width lines get their own fitter -- and wrap onto a
-- second row rather than losing their ending, because "Defended title 3 times"
-- truncated to "Defended t" is worse than no highlight at all.
local WIDE_COLS = 17

local function wideLines(text)
  text = tostring(text or ""):gsub("%s+", " "):match("^%s*(.-)%s*$") or ""
  if text == "" then return {} end
  if #text <= WIDE_COLS then return { text } end
  local cut = 0
  for i = 1, math.min(#text, WIDE_COLS + 1) do
    if text:sub(i, i) == " " then cut = i end
  end
  if cut == 0 then
    return { text:sub(1, WIDE_COLS), text:sub(WIDE_COLS + 1, WIDE_COLS * 2) }
  end
  local head = text:sub(1, cut - 1)
  local tail = text:sub(cut + 1)
  if #tail > WIDE_COLS - 1 then tail = tail:sub(1, WIDE_COLS - 1) end
  return { head, " " .. tail }
end

local function hasRow(items, value)
  for _, item in ipairs(items or {}) do
    if item.value == value then return true end
  end
  return false
end

-- The overworld ticker stays fed as well as the call: the same news is worth
-- reading again once the player is back on the map. It is no longer the ONLY
-- place the answer appears, which is what made calls look dead.
local function tick(manager, prefix, line)
  manager.ticker = { text = tostring(prefix) .. tostring(line), age = 0,
    duration = 8, offset = 0 }
end

-- Every screen this module owns is marked, so one row can hand the map back.
-- A staged rematch or tournament match cannot start until the overworld is
-- idle again (main.lua gates both on M:overworldIdle), and closing ONE list
-- still leaves the player three menus deep -- which is indistinguishable from
-- nothing happening. CLOSE MENU pops the whole Pokegear and stops there: the
-- start menu underneath belongs to the engine and is not ours to close.
local function airMenu(game, title, items, opts)
  local menu = mod.ui.ListMenu.new(game, title, items, opts)
  if type(menu) == "table" then menu.__airRivalGear = true end
  return menu
end

local function closeAll(game)
  local stack = game and game.stack
  if not (stack and stack.top and stack.pop) then return end
  for _ = 1, 12 do
    local top = stack:top()
    if not (type(top) == "table" and top.__airRivalGear) then return end
    stack:pop()
  end
end

local function contactName(c)
  return tostring((c and (c.name or c.id)) or "CONTACT")
end

local function tryPlayMusic(game, song)
  if not song then return false end
  local ok = false
  pcall(function()
    if game and game.music and type(game.music.play) == "function" then
      game.music:play(song)
      ok = true
    end
  end)
  if ok then return true end
  pcall(function()
    if game and game.audio and type(game.audio.playMusic) == "function" then
      game.audio:playMusic(song)
      ok = true
    end
  end)
  return ok
end


local CUSTOM_MUSIC_ROOT = "custom_music"
local AUDIO_EXTENSIONS = {
  ogg = true, mp3 = true, wav = true, flac = true,
}

local function audioFile(name)
  local ext = tostring(name or ""):match("%.([^.]+)$")
  return ext and AUDIO_EXTENSIONS[string.lower(ext)] == true
end

local function safeList(path)
  local ok, rows = pcall(function() return mod:list(path) end)
  if ok and type(rows) == "table" then return rows end
  return {}
end

local function safeInfo(path)
  local ok, info = pcall(function() return mod:info(path) end)
  if ok then return info end
  return nil
end

local function musicFolders()
  local out = { { label = "ROOT", path = CUSTOM_MUSIC_ROOT } }
  for _, name in ipairs(safeList(CUSTOM_MUSIC_ROOT)) do
    local rel = CUSTOM_MUSIC_ROOT .. "/" .. tostring(name)
    local info = safeInfo(rel)
    if info and info.type == "directory" then
      out[#out + 1] = { label = tostring(name):sub(1, 22), path = rel }
    end
  end
  return out
end

local function tracksInFolder(folder)
  local out = {}
  for _, name in ipairs(safeList(folder or CUSTOM_MUSIC_ROOT)) do
    local rel = tostring(folder or CUSTOM_MUSIC_ROOT) .. "/" .. tostring(name)
    local info = safeInfo(rel)
    if info and info.type == "file" and audioFile(name) then
      out[#out + 1] = { label = tostring(name):gsub("%.[^.]+$", ""):sub(1, 24), path = rel }
    end
  end
  table.sort(out, function(a,b) return a.label < b.label end)
  return out
end

local function stopCustomMusic(manager)
  local src = manager and manager.customMusicSource
  if src then pcall(function() src:stop() end) end
  if manager then manager.customMusicSource = nil end
end

-- 5.1.0: CUSTOM MUSIC REPLACES THE GAME'S MUSIC.
--
-- Until now it merely played ON TOP of it. The hook at the bottom of this
-- file forwarded every cue to the engine with the comment "custom audio is a
-- separate user stream", so choosing a track gave you your song AND the map
-- theme at once. Everything below is what "replaces" actually needs.
--
-- Silence every cue EXCEPT a one-shot. `reason = "once"` is the jingle path
-- (item found, badge earned, evolution fanfare); those are sound effects that
-- the engine already ducks the background under, and swallowing them would
-- lose feedback the player needs rather than music they chose to replace.
local KEEP_REASONS = { once = true }

function RivalGear.customMusicActive(manager)
  return manager ~= nil
    and manager.radioEnabled == true
    and manager.radioStation == "CUSTOM_MUSIC"
    and manager.customMusicTrack ~= nil
end

-- The source is a live love.audio object and cannot be serialised, so a
-- reloaded save came back with radioEnabled = true, a saved track, and no
-- sound -- the setting persisted and the music did not. Re-opening the track
-- is the only way to honour what the save says.
function RivalGear.ensureCustomMusic(manager)
  if not RivalGear.customMusicActive(manager) then return false end
  local src = manager.customMusicSource
  if src then
    local playing = false
    pcall(function() playing = src:isPlaying() end)
    if playing then return true end
    local ok = pcall(function() src:play() end)
    if ok then return true end
    stopCustomMusic(manager)
  end
  local source
  local ok = pcall(function()
    source = love.audio.newSource(mod.assets:path(manager.customMusicTrack), "stream")
    source:setLooping(true)
    source:play()
  end)
  if not ok or not source then
    -- §7: the track genuinely may not exist anymore (renamed folder, deleted
    -- file). Fall back to the game's own music rather than to silence, and
    -- clear the setting so this is not retried on every cue.
    manager.customMusicSource = nil
    manager.radioStation = "OFF"
    manager.radioEnabled = false
    manager.customMusicTrack = nil
    pcall(function() manager:save() end)
    return false
  end
  manager.customMusicSource = source
  return true
end

-- Returning nil from music.select stops a NEW cue starting; it does not stop
-- one already playing, because Music.play bails before it touches state. So
-- the map theme that was already running when the player picked a track would
-- carry on forever. Stopping the engine's source here is what makes the
-- replacement complete.
local function silenceEngineMusic(game)
  pcall(function()
    local music = game and game.music
    if music and type(music.stop) == "function" then music:stop() end
  end)
end

-- Handing the map back when custom music is switched off. Without this the
-- world stays silent until the player happens to change map.
local function restoreEngineMusic(game)
  pcall(function()
    local music = game and game.music
    if music and type(music.restoreMap) == "function" then
      music.restoreMap(game.data or (mod.game and mod.game.data))
    end
  end)
end

local function playCustomMusic(game, manager, rel)
  if not rel then return false, "NO TRACK SELECTED" end
  stopCustomMusic(manager)
  -- 5.1.0: ONE DOOR for opening a source. This used to open its own, so the
  -- "start a track" path and the "resume after load" path could disagree
  -- about looping, streaming or what to do when the file is gone (§26).
  manager.customMusicTrack = rel
  manager.radioStation = "CUSTOM_MUSIC"
  manager.radioEnabled = true
  silenceEngineMusic(game)
  if not RivalGear.ensureCustomMusic(manager) then
    return false, "TRACK COULD NOT PLAY"
  end
  manager:save()
  return true, "NOW PLAYING " .. tostring(rel:match("([^/]+)$") or rel)
end

local callerRival = function() return nil end

function RivalGear.init(modApi, manager, comms)
  mod = modApi or mod
  -- A RIVAL contact resolves to a live rival; anything else is an ordinary
  -- trainer and answers at rumour level only. Resolution is the manager's job
  -- because older saves predate the explicit rivalId field.
  callerRival = function(c)
    if not (c and c.kind == "RIVAL") then return nil end
    if type(manager.rivalForContact) == "function" then
      local ok, rival = pcall(manager.rivalForContact, manager, c)
      if ok and rival then return rival end
    end
    return c.rivalId and manager.byId and manager.byId[c.rivalId] or nil
  end
  RivalGear.manager = manager
  RivalGear.comms = comms

  mod.content.screens:register("AIR_RivalGear", {
    new = function(game)
      local items = {
        { label = "CLOCK", right = ">", value = "_clock" },
        { label = "PHONE", right = ">", value = "_phone" },
        { label = "WEATHER TRACKER", right = ">", value = "_map" },
        { label = "QUESTS", right = ">", value = "_quests" },
        { label = "RANKINGS", right = ">", value = "_rankings" },
        { label = "CLONE CALLER", right = ">", value = "_clone" },
        { label = "BREED", right = ">", value = "_breed" },
        { label = "FACTIONS", right = ">", value = "_factions" },
        { label = "RADIO", right = manager.radioEnabled and "ON" or "OFF", value = "_radio" },
      }
      return airMenu(game, "RIVALGEAR", items, {
        onChoose = function(item, menu)
          local value = chosenValue(item)
          if value == "_clock" then
            mod.ui.push(game, "AIR_RivalGearClock", {})
          elseif value == "_phone" then
            mod.ui.push(game, "AIR_RivalGearPhone", {})
          elseif value == "_map" then
            mod.ui.push(game, "AIR_RivalGearMap", {})
          elseif value == "_quests" then
            mod.ui.push(game, "AIR_RivalGearQuests", {})
          elseif value == "_rankings" then
            mod.ui.push(game, "AIR_RivalGearRankings", {})
          elseif value == "_clone" then
            mod.ui.push(game, "AIR_RivalGearCloneCaller", {})
          elseif value == "_breed" then
            mod.ui.push(game, "AIR_RivalGearBreed", {})
          elseif value == "_factions" then
            mod.ui.push(game, "AIR_RivalGearFactions", {})
          elseif value == "_radio" then
            mod.ui.push(game, "AIR_RivalGearRadio", {})
          else
            menu:close()
          end
        end,
      })
    end,
  })

  mod.content.screens:register("AIR_RivalGearClock", {
    new = function(game)
      local clock, date = now()
      return airMenu(game, "RIVALGEAR CLOCK", {
        { label = clock, value = "_line" },
        { label = date:sub(1, 26), value = "_line" },
        { label = "DEVICE TIME", value = "_line" },
        { label = "B TO RETURN", value = "_line" },
      }, { onChoose = function(_, menu) menu:close() end })
    end,
  })

  -- Clone Caller: summon or dismiss batches of AI rivals. Summoning asks
  -- whether to name them or randomise.
  mod.content.screens:register("AIR_RivalGearCloneCaller", {
    new = function(game)
      local n = #(manager.rivals or {})
      local items = {
        { label = "ACTIVE RIVALS", right = tostring(n), value = "_line" },
        { label = "SUMMON +1", right = "ADD", value = "_add1" },
        { label = "SUMMON +5", right = "ADD", value = "_add5" },
        { label = "SUMMON +10", right = "ADD", value = "_add10" },
        { label = "REMOVE -1", right = "CUT", value = "_rem1" },
        { label = "REMOVE -5", right = "CUT", value = "_rem5" },
        { label = "REMOVE -10", right = "CUT", value = "_rem10" },
        { label = "B TO RETURN", value = "_line" },
      }
      return airMenu(game, "CLONE CALLER", items, {
        messageBox = true,
        footer = "Summon rivals or cut lag.",
        onChoose = function(item, menu)
          local value = chosenValue(item)
          if value == "_line" then menu:close(); return end
          local delta = 0
          if value == "_add1" then delta = 1
          elseif value == "_add5" then delta = 5
          elseif value == "_add10" then delta = 10
          elseif value == "_rem1" then delta = -1
          elseif value == "_rem5" then delta = -5
          elseif value == "_rem10" then delta = -10
          end
          if delta > 0 then
            mod.ui.push(game, "AIR_RivalGearCloneName", { delta = delta })
            return
          end
          if delta < 0 and manager.adjustRivalCount then
            local ok, line = manager:adjustRivalCount(delta)
            tick(manager, ok and "CLONE  •  " or "NOTICE  •  ", line or "")
            menu:close()
          end
        end,
      })
    end,
  })

  mod.content.screens:register("AIR_RivalGearCloneName", {
    new = function(game, arg)
      local delta = tonumber(arg and arg.delta) or 1
      local items = {
        { label = "NAME EACH NEW RIVAL", right = ">", value = "_name" },
        { label = "RANDOMISE ALL NAMES", right = "RNG", value = "_random" },
        { label = "CANCEL", value = "_cancel" },
      }
      return airMenu(game, "NEW RIVALS", items, {
        messageBox = true,
        footer = "How should the new rivals be named?",
        onChoose = function(item, menu)
          local value = chosenValue(item)
          if value == "_cancel" or value == "_line" then menu:close(); return end
          if value == "_random" then
            local ok, line = manager:adjustRivalCount(delta)
            tick(manager, ok and "CLONE  •  " or "NOTICE  •  ", line or "")
            closeAll(game)
            return
          end
          if value == "_name" then
            -- Name the next `delta` ordinary slots that are not yet live.
            local ordinary = {}
            -- RosterPolicy is owned by the manager; do not bypass the mod-local
            -- loader with Lua's global require/package.preload.
            local live = {}
            for _, r in ipairs(manager.rivals or {}) do live[r.id] = true end
            local roster = manager.data and nil
            -- Use manager.rivals defs from ROSTER via nameAssignments keys.
            local pending = {}
            local allDefs = {}
            pcall(function()
              -- Fall back: walk nameAssignments / byId gaps from adjustRivalCount.
            end)
            -- Practical path: summon first with random names, then open naming
            -- for each newly added id by comparing before/after sets.
            local before = {}
            for _, r in ipairs(manager.rivals or {}) do before[r.id] = true end
            local ok, line = manager:adjustRivalCount(delta)
            if not ok then
              tick(manager, "NOTICE  •  ", line or "Could not summon.")
              menu:close()
              return
            end
            local newcomers = {}
            for _, r in ipairs(manager.rivals or {}) do
              if not before[r.id] then newcomers[#newcomers + 1] = r end
            end
            if #newcomers == 0 then
              tick(manager, "CLONE  •  ", line or "Done.")
              closeAll(game)
              return
            end
            local function nameAt(i)
              if i > #newcomers then
                pcall(function() manager:syncTrainerNames() end)
                tick(manager, "CLONE  •  ", "Named " .. tostring(#newcomers) .. " rivals.")
                closeAll(game)
                return
              end
              local rival = newcomers[i]
              require("src.ui.Screens").push(game, "NamingScreen", {
                title = "RIVAL NAME?",
                maxLen = 7,
                onDone = function(name)
                  if type(name) == "string" and name ~= "" then
                    rival.name = name
                    if manager.nameAssignments then
                      manager.nameAssignments[rival.id] = name
                    end
                    pcall(function()
                      local existing = mod.save:get("ai_rival_custom_names") or {}
                      if type(existing) ~= "table" then existing = {} end
                      existing[rival.id] = name
                      mod.save:set("ai_rival_custom_names", existing)
                    end)
                  end
                  nameAt(i + 1)
                end,
              })
            end
            nameAt(1)
          end
        end,
      })
    end,
  })


  mod.content.screens:register("AIR_RivalGearBreed", {
    new = function(game)
      local party = manager.game and manager.game.save and manager.game.save.party or {}
      local items = {
        { label = "PICK PARENT A", right = "1", value = "_a" },
        { label = "PICK PARENT B", right = "2", value = "_b" },
        { label = "HATCH EGG", right = "GO", value = "_go" },
        { label = "B TO RETURN", value = "_line" },
      }
      local state = { a = 1, b = 2 }
      local function partyLabel(i)
        local mon = party[i]
        if type(mon) ~= "table" then return "EMPTY" end
        local sp = mon.species or mon.speciesId or "?"
        if type(sp) == "table" then sp = sp.id or sp.name or "?" end
        return tostring(sp):sub(1, 10) .. " Lv" .. tostring(mon.level or "?")
      end
      items[1].right = partyLabel(state.a)
      items[2].right = partyLabel(state.b)
      return airMenu(game, "BREED", items, {
        messageBox = true,
        footer = "Choose two party Pokemon to breed.",
        onChoose = function(item, menu)
          local value = chosenValue(item)
          if value == "_line" then menu:close(); return end
          if value == "_a" then
            state.a = (state.a % math.max(1, #party)) + 1
            for _, row in ipairs(menu.items or {}) do
              if row.value == "_a" then row.right = partyLabel(state.a) end
            end
            return
          end
          if value == "_b" then
            state.b = (state.b % math.max(1, #party)) + 1
            for _, row in ipairs(menu.items or {}) do
              if row.value == "_b" then row.right = partyLabel(state.b) end
            end
            return
          end
          if value == "_go" and manager.breedPartySlots then
            local ok, line = manager:breedPartySlots(state.a, state.b)
            tick(manager, ok and "BREED  •  " or "NOTICE  •  ", line or "")
            if ok then menu:close() end
          end
        end,
      })
    end,
  })

  mod.content.screens:register("AIR_RivalGearFactions", {
    new = function(game)
      local f = manager.factions
      local items = {
        { label = "TEAM ROCKET", right = f and (f:label("rocket") .. " " .. tostring(f:get("rocket"))) or "?", value = "_line" },
        { label = "RANGERS", right = f and (f:label("rangers") .. " " .. tostring(f:get("rangers"))) or "?", value = "_line" },
        { label = "GYM ALLIANCE", right = f and (f:label("gym") .. " " .. tostring(f:get("gym"))) or "?", value = "_line" },
        { label = "B TO RETURN", value = "_line" },
      }
      local scheduled = manager.scheduledTournaments or {}
      if #scheduled > 0 then
        items[#items + 1] = { label = "TOURNAMENTS DUE", right = tostring(#scheduled), value = "_line" }
      end
      return airMenu(game, "FACTIONS", items, {
        onChoose = function(_, menu) menu:close() end,
      })
    end,
  })

  mod.content.screens:register("AIR_RivalGearMap", {
    new = function(game)
      local world = manager:worldView() or {}
      local map = shortMap(world.playerMap)
      local items = {
        { label = "CURRENT LOCATION", value = "_line" },
        { label = map:sub(1, 28), value = "_line" },
      }

      -- Weather FX owns the simulation. Poll a fresh snapshot every open so
      -- the readout matches the live sky (Weather FX 4.3.1 stable exports:
      -- weather, battleWeather, timeOfDay; newer builds may also publish
      -- weatherMap regions).
      local snap
      pcall(function()
        if manager.compat and type(manager.compat.weatherSnapshot) == "function" then
          snap = manager.compat:weatherSnapshot()
        end
      end)
      if type(snap) ~= "table" then
        pcall(function()
          if manager.compat and type(manager.compat.weatherMap) == "function" then
            local rows = manager.compat:weatherMap()
            if type(rows) == "table" then
              snap = { present = true, regions = rows }
            end
          end
        end)
      end

      if type(snap) == "table" and snap.present then
        items[#items + 1] = {
          label = "WEATHER FX",
          right = tostring(snap.version or "LIVE"):sub(1, 10),
          value = "_line",
        }
        if snap.id then
          items[#items + 1] = {
            label = "SKY NOW",
            right = tostring(snap.id):gsub("_", " "):sub(1, 12),
            value = "_line",
          }
        end
        if snap.battle then
          items[#items + 1] = {
            label = "BATTLE WX",
            right = tostring(snap.battle):gsub("_", " "):sub(1, 12),
            value = "_line",
          }
        end
        if snap.tod then
          local todRight = tostring(snap.tod):upper()
          if snap.hour then todRight = todRight .. " " .. tostring(snap.hour) .. "H" end
          items[#items + 1] = {
            label = "TIME OF DAY",
            right = todRight:sub(1, 12),
            value = "_line",
          }
        end

        local weatherRows = snap.regions
        if type(weatherRows) == "table" and #weatherRows > 0 then
          local hasRealRegions = false
          for _, row in ipairs(weatherRows) do
            if type(row) == "table" and row.id and row.id ~= "HERE" then
              hasRealRegions = true
              break
            end
          end
          if hasRealRegions then
            items[#items + 1] = { label = "REGIONS", value = "_line" }
            local generation = tonumber(manager.generation) or 1
            local lands = generation == 2 and { "johto", "kanto" } or { "kanto" }
            for _, land in ipairs(lands) do
              local addedHeader = false
              for _, row in ipairs(weatherRows) do
                if type(row) == "table" and row.land == land and row.id ~= "HERE" then
                  if not addedHeader then
                    items[#items + 1] = { label = land:upper(), value = "_line" }
                    addedHeader = true
                  end
                  local place = tostring(row.label or row.id or "AREA")
                  local weather = tostring(row.weather or "CLEAR"):gsub("_", " ")
                  items[#items + 1] = {
                    label = place:sub(1, 14),
                    right = weather:sub(1, 12),
                    value = "_line",
                  }
                end
              end
            end
          elseif snap.id == nil and weatherRows[1] then
            local row = weatherRows[1]
            items[#items + 1] = {
              label = "SKY NOW",
              right = tostring(row.weather or "CLEAR"):gsub("_", " "):sub(1, 12),
              value = "_line",
            }
          end
        end
      else
        items[#items + 1] = {
          label = "WEATHER FX",
          right = "OFFLINE",
          value = "_line",
        }
        items[#items + 1] = {
          label = "INSTALL WEATHER FX",
          right = "4.3.1+",
          value = "_line",
        }
      end

      items[#items + 1] = {
        label = "PHONE CONTACTS",
        right = tostring(#comms.listed(manager.comms)),
        value = "_line",
      }

      local menu = airMenu(game, "WEATHER TRACKER", items, {
        onChoose = function(_, m) m:close() end,
      })
      -- Live refresh while open so SKY NOW tracks Weather FX without re-entry.
      local age = 0
      local baseUpdate = menu.update
      menu.update = function(self, dt)
        if baseUpdate then baseUpdate(self, dt) end
        age = age + (tonumber(dt) or 0)
        if age < 2.5 then return end
        age = 0
        local snap
        pcall(function()
          if manager.compat and manager.compat.weatherSnapshot then
            snap = manager.compat:weatherSnapshot()
          end
        end)
        if type(snap) ~= "table" or not snap.present then return end
        for _, row in ipairs(self.items or {}) do
          if row.label == "SKY NOW" and snap.id then
            row.right = tostring(snap.id):gsub("_", " "):sub(1, 12)
          elseif row.label == "BATTLE WX" and snap.battle then
            row.right = tostring(snap.battle):gsub("_", " "):sub(1, 12)
          elseif row.label == "TIME OF DAY" and snap.tod then
            local todRight = tostring(snap.tod):upper()
            if snap.hour then todRight = todRight .. " " .. tostring(snap.hour) .. "H" end
            row.right = todRight:sub(1, 12)
          end
        end
      end
      return menu
    end,
  })

  mod.content.screens:register("AIR_RivalGearPhone", {
    new = function(game)
      local contacts = comms.listed(manager.comms)
      local items = {}
      if #contacts == 0 then
        items[1] = { label = "NO CONTACTS YET", value = "_line" }
      else
        for _, c in ipairs(contacts) do
          items[#items + 1] = {
            label = (c.name or c.id):sub(1, 22),
            right = (c.number or "----"):sub(1, 7),
            value = c.id,
          }
        end
      end
      return airMenu(game, "RIVALGEAR PHONE", items, {
        onChoose = function(item, menu)
          local value = chosenValue(item)
          local c = comms.get(manager.comms, value)
          if not c then menu:close(); return end
          mod.ui.push(game, "AIR_RivalGearContact", { contact = c })
        end,
      })
    end,
  })

  mod.content.screens:register("AIR_RivalGearContact", {
    new = function(game, arg)
      local c = arg and arg.contact
      local items = {}
      if not c then items[1] = { label = "NO CONTACT", value = "_line" }
      else
        items[#items + 1] = { label = c.name:sub(1, 24), value = "_line" }
        items[#items + 1] = { label = "NUMBER", right = tostring(c.number), value = "_line" }
        if c.kind == "RIVAL" then
          items[#items + 1] = { label = "CALL RIVAL", value = "_call" }
          items[#items + 1] = { label = "ARRANGE TOURNAMENT AT MY LOCATION", value = "_tournament" }
          items[#items + 1] = { label = "CALL HISTORY", value = "_history" }
        else
          items[#items + 1] = { label = "CALL REMATCH", value = "_call" }
          items[#items + 1] = { label = "CALL HISTORY", value = "_history" }
        end
      end
      return airMenu(game, "CONTACT", items, {
        onChoose = function(item, menu)
          local value = chosenValue(item)
          -- 4.5.0: CALL OPENS A CONVERSATION.
          --
          -- Until now this row staged the call and closed itself, and every
          -- word of the reply went to `manager.ticker` -- which main.lua's
          -- render.hud hook draws ONLY while the overworld is the top of the
          -- state stack. Four screens deep inside the Pokegear, that is
          -- invisible, so a call that worked perfectly looked like a dead
          -- button. The conversation screen answers where the player is.
          if value == "_call" and c then
            mod.ui.push(game, "AIR_RivalGearCall", { contact = c })
            return
          end
          if value == "_tournament" and c and c.kind == "RIVAL" then
            mod.ui.push(game, "AIR_RivalGearTournament", { contact = c })
            return
          end
          if value == "_history" and c then
            mod.ui.push(game, "AIR_RivalGearHistory", { contact = c })
            return
          end
          menu:close()
        end,
      })
    end,
  })

  -- The call itself.  `messageBox` gives this list the engine's standard
  -- bottom text box (src/ui/ListMenu.lua:260-275) and shortens the row budget
  -- to four, so the other side of the line has somewhere to speak and every
  -- answer is read where it was asked for.
  mod.content.screens:register("AIR_RivalGearCall", {
    new = function(game, arg)
      local c = arg and arg.contact
      local rival = callerRival(c)
      local isRival = rival ~= nil
      local name = contactName(c)
      local items = {}
      if not c then
        items[1] = { label = "NO CONTACT", value = "_hangup" }
      elseif isRival then
        local rivalMons = manager.rivalHealthyCount
          and manager:rivalHealthyCount(rival) or 0
        local doubleRight = rivalMons >= 2 and "2V2" or "1 MON"
        items[#items + 1] = { label = "CHALLENGE 1V1", right = "SINGLE", value = "_challenge_single" }
        items[#items + 1] = { label = "CHALLENGE 2V2", right = doubleRight, value = "_challenge_double" }
        items[#items + 1] = { label = "COME HERE", right = "ASK", value = "_summon" }
        items[#items + 1] = {
          label = "ARRANGE TOURNAMENT AT MY LOCATION",
          right = ">",
          value = "_tournament_here",
        }
        items[#items + 1] = {
          label = "SCHEDULE TOURNAMENT LATER",
          right = ">",
          value = "_tournament_later",
        }
        items[#items + 1] = { label = "ASK FOR A QUEST", right = "JOB", value = "_phone_quest" }
        items[#items + 1] = { label = "ASK ABOUT", right = ">", value = "_scout" }
        items[#items + 1] = { label = "HANG UP", value = "_hangup" }
      else
        items[#items + 1] = { label = "REMATCH", right = "BATTLE", value = "_rematch" }
        items[#items + 1] = { label = "ASK ABOUT", right = ">", value = "_scout" }
        items[#items + 1] = { label = "HANG UP", value = "_hangup" }
      end
      fitRows(items)

      local menu
      menu = airMenu(game, name:sub(1, 16), items, {
        messageBox = true,
        footer = speech(name, isRival and "Hey! What do you need?"
          or "Hello? Who is this?"),
        onChoose = function(item, selfMenu)
          local value = chosenValue(item)
          if value == "_hangup" or value == "_line" then
            selfMenu:close()
            return
          end
          if value == "_phone_quest" and rival and manager.phoneQuestOffer then
            local q = manager:phoneQuestOffer(rival)
            if q then
              selfMenu.footer = speech(name, q.dialogue or q.description or "I have a job for you. Check your Pokégear Quests.")
              tick(manager, "QUEST  •  ", tostring(q.title or "New quest offered."))
            else
              selfMenu.footer = speech(name, "Nothing for you right now.")
            end
            return
          end
          if value == "_tournament_later" and rival then
            local world = manager.worldView and manager:worldView() or {}
            local ok, line = manager:scheduleTournament(
              rival.id, 4, "SINGLE", world.playerMap, 180)
            selfMenu.footer = speech(name, line or "Maybe later.")
            tick(manager, ok and "TOURNAMENT  •  " or "NOTICE  •  ", line or "")
            return
          end
          if (value == "_challenge" or value == "_challenge_single"
              or value == "_challenge_double") and rival then
            local wantDouble = value == "_challenge_double"
              or (value == "_challenge"
                  and ((manager.challengeModes or {})[rival.id] == "DOUBLE"))
            local phoneMode = manager.phoneRivalBattleMode
              and manager:phoneRivalBattleMode(rival, wantDouble and "DOUBLE" or "SINGLE")
              or "UNAVAILABLE"
            if phoneMode == "FAINTED" then
              selfMenu.footer = speech(name, "I need to heal first.")
              return
            end
            if phoneMode == "UNAVAILABLE" then
              selfMenu.footer = speech(name, "I can't battle right now.")
              return
            end
            if wantDouble and manager.rivalHealthyCount
               and manager:rivalHealthyCount(rival) < 2 then
              selfMenu.footer = speech(name, "Sorry, I only have one Pokémon with me.")
              tick(manager, "PHONE  • ", "Sorry, I only have one Pokémon with me.")
              return
            end
            local action = wantDouble and "_challenge_double" or "_challenge_single"
            local ok = manager:queueRivalAction(rival, action)
            if ok then
              if type(manager.noteCall) == "function" and c then
                pcall(manager.noteCall, manager, c.id, "CHALLENGE")
              end
              tick(manager, "PHONE  • ",
                (wantDouble and "Double" or "Single")
                .. " challenge accepted. Battle starting here.")
              closeAll(game)
            else
              selfMenu.footer = speech(name, "I can't battle right now.")
            end
            return
          end
          if (value == "_summon" or value == "_rematch") and c then
            -- Protect against throws from callContact (e.g. missing rival,
            -- worldView nil, or save-shape edge cases on older Gen1 saves).
            -- A silent error inside onChoose leaves the player staring at a
            -- frozen conversation with no feedback — the original "does nothing"
            -- symptom for Gen1.
            local callOk, callLine
            do
              local success, a, b = pcall(function()
                return manager:callContact(c.id)
              end)
              if success then
                callOk, callLine = a, b
              else
                callOk, callLine = false, "The line is dead."
              end
            end
            selfMenu.footer = speech(name, callLine)
            tick(manager, callOk and "PHONE  • " or "NOTICE  • ", callLine)
            if callOk then
              -- Some ListMenu builds pass the scalar value to onChoose instead
              -- of the item table. Mutating a non-table silently fails or errors
              -- and leaves the call looking dead. Always locate the live row.
              local row = type(item) == "table" and item or nil
              if not row then
                for _, it in ipairs(selfMenu.items or {}) do
                  if it.value == value then row = it; break end
                end
              end
              if row then
                row.right = value == "_summon" and "ON WAY" or "WAITING"
                fitRow(row)
              end
              -- A staged rematch cannot start while a menu owns the screen:
              -- main.lua only pushes it once the overworld is idle again.
              -- Say so rather than leaving the player waiting on nothing.
              if value == "_rematch" and not hasRow(selfMenu.items, "_close") then
                table.insert(selfMenu.items, 2,
                  fitRow({ label = "CLOSE MENU", right = "FIGHT", value = "_close" }))
              end
            end
            return
          end
          if value == "_close" then
            closeAll(game)
            return
          end
          if (value == "_tournament" or value == "_tournament_here") and c then
            local world = manager:worldView() or {}
            mod.ui.push(game, "AIR_RivalGearTournament", { contact = c, venueMap = world.playerMap })
            return
          end
          if value == "_scout" and c then
            mod.ui.push(game, "AIR_RivalGearAsk", { contact = c, caller = rival })
            return
          end
        end,
      })
      return menu
    end,
  })

  -- Who to ask about.  A rival is never offered themselves as a subject.
  mod.content.screens:register("AIR_RivalGearAsk", {
    new = function(game, arg)
      local c = arg and arg.contact
      local caller = arg and arg.caller
      local items = {}
      for _, other in ipairs(manager.rivals or {}) do
        if not (caller and other.id == caller.id) then
          local badges = other.badgeCount and other:badgeCount() or nil
          items[#items + 1] = fitRow({
            label = tostring(other.name or other.id),
            right = badges and (badges .. "B") or "",
            value = other.id,
          })
        end
      end
      if #items == 0 then
        items[1] = { label = "NO ONE ELSE", value = "_line" }
      end
      return airMenu(game, "ASK ABOUT", items, {
        messageBox = true,
        footer = speech(contactName(c), "Who do you want to hear about?"),
        onChoose = function(item, menu)
          local value = chosenValue(item)
          if value == "_line" then menu:close(); return end
          local subject = manager.byId and manager.byId[value]
          if not subject then menu:close(); return end
          mod.ui.push(game, "AIR_RivalGearScout",
            { contact = c, caller = caller, subject = subject })
        end,
      })
    end,
  })

  -- The answer.  Everything on this screen is derived from what the caller
  -- has actually seen (src/Scout.lua); the levels exist so a contact who has
  -- never met the subject says exactly that instead of reciting their party.
  mod.content.screens:register("AIR_RivalGearScout", {
    new = function(game, arg)
      local c = arg and arg.contact
      local subject = arg and arg.subject
      local report = manager.scoutReport and manager:scoutReport(arg and arg.caller, subject)
        or { headline = "NO ANSWER", line = "I can't help with that.", rows = {} }
      if type(manager.noteCall) == "function" and c then
        pcall(manager.noteCall, manager, c.id, "SCOUT")
      end
      local items = { fitRow({ label = "KNOWS", right = report.headline, value = "_line" }) }
      for _, row in ipairs(report.rows or {}) do
        items[#items + 1] = fitRow({ label = row.label, right = row.right, value = "_line" })
      end
      return airMenu(game,
        tostring((subject and subject.name) or report.subject or "RIVAL"):sub(1, 16),
        items, {
          messageBox = true,
          footer = speech(contactName(c), report.line),
          onChoose = function(_, menu) menu:close() end,
        })
    end,
  })

  mod.content.screens:register("AIR_RivalGearTournament", {
    new = function(game, arg)
      local c = arg and arg.contact
      local name = contactName(c)
      local host = callerRival(c)
      local hostId = (host and host.id) or (c and c.rivalId) or nil
      local state = { count = 3 }

      -- Participant selection is independent of format. The player chooses the
      -- field first, then gets an explicit STANDARD / DOUBLE screen. The count
      -- is capped to rivals that exist in this save; doubles eligibility is
      -- validated on the next screen rather than silently changing this row.
      local function maxAnyCount()
        local single = manager:tournamentLimits("SINGLE")
        return math.max(0, math.min(100, tonumber(single) or 0))
      end
      local function countLabel()
        local max = maxAnyCount()
        if max < 3 then return "NONE" end
        return tostring(math.min(state.count, max)) .. "/" .. tostring(max)
      end
      local items = {
        { label = "RIVALS (3-100)", right = countLabel(), value = "_count" },
        { label = "START", right = ">", value = "_start" },
        { label = "HANG UP", value = "_hangup" },
      }
      fitRows(items)
      local PRESETS = { 3, 4, 8, 16, 32, 64, 100 }
      local function nextPreset()
        local max = maxAnyCount()
        if max < 3 then return end
        local best
        for _, size in ipairs(PRESETS) do
          local capped = math.min(size, max)
          if capped > state.count then best = capped break end
        end
        state.count = best or 3
      end
      local function refresh(menu)
        local max = maxAnyCount()
        if max >= 3 then state.count = math.max(3, math.min(max, state.count)) end
        for _, row in ipairs(menu.items or {}) do
          if row.value == "_count" then row.right = countLabel(); fitRow(row) end
        end
      end

      local menu
      menu = airMenu(game, "TOURNAMENT", items, {
        messageBox = true,
        footer = speech(name, "Choose how many rivals should enter."),
        onChoose = function(item, selfMenu)
          local value = chosenValue(item)
          if value == "_hangup" or value == "_line" then selfMenu:close(); return end
          if value == "_count" then nextPreset(); refresh(selfMenu); return end
          if value == "_start" then
            local max = maxAnyCount()
            if max < 3 then
              selfMenu.footer = speech(name, "We need at least three rivals.")
              tick(manager, "NOTICE  •  ", "NOT ENOUGH RIVALS.")
              return
            end
            state.count = math.max(3, math.min(max, state.count))
            mod.ui.push(game, "AIR_RivalGearTournamentMode", {
              contact = c, hostId = hostId, count = state.count,
              venueMap = arg and arg.venueMap,
            })
            return
          end
        end,
      })
      local baseUpdate = menu.update
      menu.update = function(self, dt)
        local item = self.items and self.items[self.index]
        if item and item.value == "_count" then
          local left = game.input:wasPressed("left")
          local right = game.input:wasPressed("right")
          if left or right then
            local max = maxAnyCount()
            if max >= 3 then
              state.count = math.max(3, math.min(max, state.count + (right and 1 or -1)))
              refresh(self)
            end
          end
        end
        return baseUpdate(self, dt)
      end
      return menu
    end,
  })

  mod.content.screens:register("AIR_RivalGearTournamentMode", {
    new = function(game, arg)
      local c = arg and arg.contact
      local name = contactName(c)
      local count = math.max(3, math.min(100, math.floor(tonumber(arg and arg.count) or 3)))
      local singleMax = math.max(0, math.min(100, tonumber(manager:tournamentLimits("SINGLE")) or 0))
      local doubleMax = math.max(0, math.min(100, tonumber(manager:tournamentLimits("DOUBLE")) or 0))
      local playerParty = manager.game and manager.game.save and manager.game.save.party or {}
      local playerHealthy = 0
      for _, mon in ipairs(playerParty) do
        if (tonumber(mon.hp) or 1) > 0 then playerHealthy = playerHealthy + 1 end
      end
      local doubleOK = playerHealthy >= 2 and doubleMax >= count
      local items = {
        { label = "STANDARD", right = singleMax >= count and "SELECT" or "UNAVAILABLE", value = "_single" },
        { label = "DOUBLE", right = doubleOK and "SELECT" or "UNAVAILABLE", value = "_double" },
        { label = "BACK", value = "_back" },
      }
      fitRows(items)
      return airMenu(game, "BATTLE MODE", items, {
        messageBox = true,
        footer = speech(name, "Choose Standard or Double battles."),
        onChoose = function(item, menu)
          local value = chosenValue(item)
          if value == "_back" then menu:close(); return end
          local mode = value == "_double" and "DOUBLE" or "SINGLE"
          if mode == "SINGLE" and singleMax < count then
            menu.footer = speech(name, "Not enough rivals can enter.")
            return
          end
          if mode == "DOUBLE" and not doubleOK then
            if playerHealthy < 2 then
              menu.footer = speech(name, "You need two healthy Pokemon for doubles.")
            else
              menu.footer = speech(name, "Not enough rivals have two Pokemon.")
            end
            return
          end
          local ok, line = manager:arrangeTournament(arg and arg.hostId, count, mode, arg and arg.venueMap)
          menu.footer = speech(name, line)
          tick(manager, ok and "TOURNAMENT  •  " or "NOTICE  •  ", line)
          if ok then
            if type(manager.noteCall) == "function" and c then
              pcall(manager.noteCall, manager, c.id, "TOURNAMENT")
            end
            closeAll(game)
          end
        end,
      })
    end,
  })


  -- ------------------------------------------------------------------
  -- DYNAMIC QUESTS (5.0.4)
  -- ------------------------------------------------------------------
  mod.content.screens:register("AIR_RivalGearQuests", {
    new = function(game)
      if manager.quests then pcall(function() manager.quests:refresh(true) end) end
      -- Only explicitly offered quests are shown here. World incidents do not
      -- silently become player jobs merely because this screen was opened.
      local quests = {}
      if manager.quests then
        if type(manager.quests.listAll) == "function" then
          pcall(function() quests = manager.quests:listAll() or {} end)
        else
          pcall(function() quests = manager.quests:list() or {} end)
        end
      end
      local items = {}
      local order = { COMPLETE=1, ACTIVE=2, OFFERED=3, CLAIMED=4 }
      table.sort(quests, function(a,b)
        local ao, bo = order[a.status] or 9, order[b.status] or 9
        if ao ~= bo then return ao < bo end
        return tostring(a.id) < tostring(b.id)
      end)
      for _, q in ipairs(quests) do
        if q.status ~= "CLAIMED" then
          local right = q.status == "COMPLETE" and "CLAIM"
            or q.status == "ACTIVE" and (manager.quests:progress(q) or "ACTIVE")
            or "NEW"
          items[#items + 1] = fitRow({
            label = tostring(q.title or "QUEST"),
            right = right,
            value = q.id,
          })
        end
      end
      if #items == 0 then
        items[1] = { label = "NO QUESTS", value = "_line" }
      end
      return airMenu(game, "RIVALGEAR QUESTS", items, {
        onChoose = function(item, menu)
          local value = chosenValue(item)
          if value == "_line" then menu:close(); return end
          mod.ui.push(game, "AIR_RivalGearQuestDetail", { questId = value })
        end,
      })
    end,
  })

  mod.content.screens:register("AIR_RivalGearQuestDetail", {
    new = function(game, arg)
      local q = manager.quests and manager.quests:get(arg and arg.questId) or nil
      local items = {}
      local function line(text)
        for _, part in ipairs(wideLines(text)) do
          items[#items + 1] = { label = part, value = "_line" }
        end
      end
      if not q then
        items[1] = { label = "QUEST NOT FOUND", value = "_line" }
      else
        line((q.giver or "QUEST") .. ": " .. (q.description or q.title or ""))
        items[#items + 1] = fitRow({
          label = "PROGRESS",
          right = manager.quests:progress(q),
          value = "_line",
        })
        items[#items + 1] = fitRow({
          label = "REWARD",
          right = "$" .. tostring(q.rewardMoney or 0),
          value = "_line",
        })
        items[#items + 1] = fitRow({
          label = "BONUS",
          right = "RARE CANDY",
          value = "_line",
        })
        if q.status == "OFFERED" then
          items[#items + 1] = { label = "ACCEPT QUEST", value = "_accept" }
        elseif q.status == "COMPLETE" then
          items[#items + 1] = { label = "CLAIM REWARD", value = "_claim" }
        elseif q.status == "ACTIVE" then
          items[#items + 1] = { label = "QUEST ACTIVE", value = "_line" }
        end
      end
      items[#items + 1] = { label = "BACK", value = "_back" }
      fitRows(items)
      return airMenu(game, tostring(q and q.title or "QUEST"):sub(1, 16), items, {
        messageBox = true,
        footer = q and speech(q.giver or "QUEST", q.dialogue or q.description or q.title) or "Quest unavailable.",
        onChoose = function(item, menu)
          local value = chosenValue(item)
          if value == "_back" then menu:close(); return end
          if not q or value == "_line" then return end
          if value == "_accept" then
            local ok, msg = manager.quests:accept(q.id)
            menu.footer = speech(q.giver or "QUEST", msg)
            tick(manager, ok and "QUEST  •  " or "NOTICE  •  ", msg)
            if ok then menu:close() end
            return
          end
          if value == "_claim" then
            local ok, msg = manager.quests:claim(q.id)
            menu.footer = speech(q.giver or "QUEST", msg)
            tick(manager, ok and "QUEST REWARD  •  " or "NOTICE  •  ", msg)
            if ok then menu:close() end
            return
          end
        end,
      })
    end,
  })

  -- ------------------------------------------------------------------
  -- TRAINER RANKINGS (4.6.0)
  -- ------------------------------------------------------------------
  -- Every trainer in the save on one table, the PLAYER among them and ranked
  -- by the same comparison as everybody else -- the question the screen exists
  -- to answer is "am I winning?", and a screen that lists the rivals and then
  -- mentions the player separately cannot answer it.
  --
  -- Once somebody has beaten the Elite Four the table is topped by a CHAMPION
  -- banner naming them. Selecting any row opens that trainer's record.

  mod.content.screens:register("AIR_RivalGearRankings", {
    new = function(game, arg)
      local rows = manager.trainerRankings and manager:trainerRankings() or {}
      local items = {}
      local champion
      for _, row in ipairs(rows) do
        if row.champion then champion = row end
      end
      if champion then
        items[#items + 1] = fitRow({ label = "CHAMPION", right = "", value = "_line" })
        items[#items + 1] = fitRow({
          label = tostring(champion.name):upper(), right = "",
          value = champion.player and "_player" or champion.id,
        })
      end
      for _, row in ipairs(rows) do
        items[#items + 1] = fitRow({
          -- "1. GREEN" / "2. PLAYER": the rank is part of the label because the
          -- right-hand column is carrying the badge count.
          label = tostring(row.rank) .. ". " .. tostring(row.name):upper(),
          right = row.champion and "CHAMPION"
            or (tostring(row.badges) .. (row.badges == 1 and " BADGE" or " BADGES")),
          value = row.player and "_player" or row.id,
        })
      end
      if #items == 0 then
        items[1] = fitRow({ label = "NO TRAINERS", right = "", value = "_line" })
      end
      return airMenu(game, "TRAINER RANKINGS", items, {
        onChoose = function(item, menu)
          local value = chosenValue(item)
          if value == "_line" then return end
          if value == "_player" then
            mod.ui.push(game, "AIR_RivalGearRecord", { player = true })
            return
          end
          if type(value) == "string" and value ~= "" then
            mod.ui.push(game, "AIR_RivalGearRecord", { rivalId = value })
            return
          end
          menu:close()
        end,
      })
    end,
  })

  -- One trainer's record. Everything on it is DERIVED from the world when the
  -- screen opens (src/Achievements.lua), so it cannot claim a badge the rival
  -- does not hold or a title defence that never happened.
  mod.content.screens:register("AIR_RivalGearRecord", {
    new = function(game, arg)
      local record = manager.trainerRecord
        and manager:trainerRecord(arg and arg.rivalId, arg and arg.player)
        or nil
      local items = {}
      local function line(label, right)
        items[#items + 1] = fitRow({ label = label, right = right or "", value = "_line" })
      end
      -- A sentence, using the whole row and wrapping if it has to.
      local function wide(text)
        for _, part in ipairs(wideLines(text)) do
          items[#items + 1] = { label = part, value = "_line" }
        end
      end
      if not record then
        line("NO RECORD", "")
      else
        if record.title then
          -- What Kanto calls them, under their name at the top of the record.
          for _, part in ipairs(wideLines(record.title)) do
            items[#items + 1] = { label = part, value = "_line" }
          end
        end
        line("BADGES", tostring(record.badges or 0))
        line("ELITE FOUR", tostring(record.eliteFour or "Not yet"))
        line("CHAMPION", record.champion and "Yes" or "No")
        if (record.defences or 0) > 0 then
          line("DEFENCES", tostring(record.defences))
        end
        if record.favourite then
          line("FAVOURITE", tostring(record.favourite))
        end
        line("CAREER", "")
        wide(" " .. tostring(record.career or "Trainer"))
        if #(record.rivalries or {}) > 0 then
          line("RIVALRIES", "")
          for _, row in ipairs(record.rivalries) do
            line(" " .. tostring(row.name), tostring(row.label or ""))
          end
        end
        if #(record.highlights or {}) > 0 then
          line("HIGHLIGHTS", "")
          for _, text in ipairs(record.highlights) do
            -- The bullet IS the row: a highlight is a sentence, so it takes the
            -- whole width rather than being squeezed into a label column.
            wide("*" .. tostring(text))
          end
        end
      end
      return airMenu(game, tostring(record and record.name or "RECORD"):upper(), items, {
        onChoose = function(_, menu) menu:close() end,
      })
    end,
  })

  mod.content.screens:register("AIR_RivalGearHistory", {
    new = function(game, arg)
      local c = arg and arg.contact
      local rows = {}
      for _, h in ipairs(c and c.history or {}) do
        rows[#rows + 1] = {
          label = comms.reasonLabel(h.reason):sub(1, 22),
          right = h.missed and "MISSED" or (h.incoming and "IN" or "OUT"),
          value = "_line",
        }
      end
      if #rows == 0 then rows[1] = { label = "NO CALLS", value = "_line" } end
      return airMenu(game, "CALL HISTORY", rows, {
        onChoose = function(_, menu) menu:close() end,
      })
    end,
  })


  mod.content.screens:register("AIR_RivalGearOffer", {
    new = function(game, arg)
      local c = arg and arg.contact
      local items = {
        { label = c and (c.name or "TRAINER") or "TRAINER", value = "_line" },
        { label = "ACCEPT NUMBER", value = "_accept" },
        { label = "DECLINE", value = "_decline" },
      }
      return airMenu(game, "PHONE OFFER", items, {
        onChoose = function(item, menu)
          local value = chosenValue(item)
          if value == "_accept" then
            local ok = manager:acceptPendingPhoneOffer(c)
            manager.ticker = {
              text = ok and "PHONE NUMBER SAVED." or "COULD NOT SAVE NUMBER.",
              age = 0, duration = 6, offset = 0
            }
          elseif value == "_decline" then
            manager:declinePendingPhoneOffer(c)
            manager.ticker = {
              text = "NUMBER DECLINED.",
              age = 0, duration = 6, offset = 0
            }
          end
          menu:close()
        end,
      })
    end,
  })

  mod.content.screens:register("AIR_RivalGearRadio", {
    new = function(game)
      local stations = stationList(manager)
      local items = {}
      for _, station in ipairs(stations) do
        items[#items + 1] = {
          label = station.label,
          right = manager.radioStation == station.id and "*" or "",
          value = station.id,
        }
      end
      items[#items + 1] = {
        label = "CUSTOM MUSIC",
        right = manager.radioStation == "CUSTOM_MUSIC" and "*" or ">",
        value = "CUSTOM_MUSIC",
      }
      return airMenu(game, "RIVALGEAR RADIO", items, {
        onChoose = function(item, menu)
          local value = chosenValue(item)
          if value == "CUSTOM_MUSIC" then
            mod.ui.push(game, "AIR_RivalGearMusicFolders", {})
            return
          end
          stopCustomMusic(manager)
          for _, station in ipairs(stations) do
            if station.id == value then
              manager.radioStation = station.id
              manager.radioEnabled = station.id ~= "OFF"
              -- 5.1.0: leaving CUSTOM MUSIC must forget the track as well as
              -- the source, or ensureCustomMusic would resurrect it on the
              -- very next cue -- the setting says OFF and the audio says no.
              manager.customMusicTrack = nil
              if station.song then tryPlayMusic(game, station.song)
              else restoreEngineMusic(game) end
              manager:save()
              break
            end
          end
          menu:close()
        end,
      })
    end,
  })

  mod.content.screens:register("AIR_RivalGearMusicFolders", {
    new = function(game)
      local folders = musicFolders()
      local items = {
        { label = "SELECT MUSIC FOLDER", value = "_line" },
      }
      for _, folder in ipairs(folders) do
        items[#items + 1] = {
          label = folder.label,
          right = manager.customMusicFolder == folder.path and "*" or ">",
          value = folder.path,
        }
      end
      if #folders == 1 and #tracksInFolder(CUSTOM_MUSIC_ROOT) == 0 then
        items[#items + 1] = { label = "ADD MUSIC TO", value = "_line" }
        items[#items + 1] = { label = "custom_music/", value = "_line" }
      end
      return airMenu(game, "MUSIC FOLDERS", items, {
        onChoose = function(item, menu)
          local value = chosenValue(item)
          if value == "_line" then return end
          local info = safeInfo(value)
          if not info or info.type ~= "directory" then
            manager.ticker = { text = "NOTICE  •  MUSIC FOLDER NOT FOUND.", age = 0, duration = 7, offset = 0 }
            return
          end
          manager.customMusicFolder = value
          manager:save()
          mod.ui.push(game, "AIR_RivalGearMusicTracks", { folder = value })
        end,
      })
    end,
  })

  mod.content.screens:register("AIR_RivalGearMusicTracks", {
    new = function(game, arg)
      local folder = (arg and arg.folder) or manager.customMusicFolder or CUSTOM_MUSIC_ROOT
      local tracks = tracksInFolder(folder)
      local items = {}
      if #tracks == 0 then
        items[1] = { label = "NO MUSIC FILES", value = "_line" }
        items[2] = { label = "OGG MP3 WAV FLAC", value = "_line" }
      else
        for _, track in ipairs(tracks) do
          items[#items + 1] = {
            label = track.label,
            right = manager.customMusicTrack == track.path and "*" or "",
            value = track.path,
          }
        end
      end
      items[#items + 1] = { label = "RESCAN FOLDER", value = "_rescan" }
      items[#items + 1] = { label = "STOP CUSTOM MUSIC", value = "_stop" }
      return airMenu(game, "CUSTOM MUSIC", items, {
        onChoose = function(item, menu)
          local value = chosenValue(item)
          if value == "_line" then return end
          if value == "_rescan" then
            menu:close()
            mod.ui.push(game, "AIR_RivalGearMusicTracks", { folder = folder })
            return
          end
          if value == "_stop" then
            stopCustomMusic(manager)
            manager.radioStation = "OFF"
            manager.radioEnabled = false
            manager.customMusicTrack = nil
            manager:save()
            -- 5.1.0: hand the map its own theme back. Without this the world
            -- stayed silent until the player happened to change map, which
            -- reads as "stopping the music broke the game".
            restoreEngineMusic(game)
            menu:close()
            return
          end
          local ok, line = playCustomMusic(game, manager, value)
          manager.ticker = { text = (ok and "RADIO  •  " or "NOTICE  •  ") .. tostring(line), age = 0, duration = 8, offset = 0 }
          if ok then menu:close() end
        end,
      })
    end,
  })

  -- The start-menu hook is intentionally local to the Pokegear module. It is
  -- installed for Gen 1 and Gen 2, so a Gold save can use the same summon
  -- path even when the native Pokegear implementation is present.
  mod.hooks:wrap("ui.start_menu.items", function(next, game, items)
    -- API 2 UI hooks are decorator chains: mutate the descriptor list, then
    -- forward it so other mods and the vanilla menu can participate normally.
    if type(items) == "table" then
      mod.ui.insertBefore(items, "SAVE", {
        label = "RIVALGEAR",
        onSelect = function() mod.ui.push(game, "AIR_RivalGear", {}) end,
      })
    end
    return next(game, items)
  end)

  -- If the radio is enabled, retarget map music through the selected station.
  -- We only do this while the player has explicitly enabled a station.
  mod.hooks:wrap("music.select", function(next, song, ctx)
    if manager.radioEnabled then
      if manager.radioStation == "CUSTOM_MUSIC" then
        -- Asked live rather than trusting a flag: the source is runtime-only,
        -- so a freshly loaded save reaches here with the setting on and
        -- nothing playing (§28 -- a stamp is not a fact).
        if RivalGear.ensureCustomMusic(manager) then
          local reason = ctx and ctx.reason
          if KEEP_REASONS[reason] then return next(song, ctx) end
          silenceEngineMusic(ctx and ctx.game or mod.game)
          return nil
        end
        -- The track went missing; ensureCustomMusic has already cleared the
        -- setting, so fall through to the game's own music.
        return next(song, ctx)
      end
      for _, station in ipairs(stationList(manager)) do
        if station.id == manager.radioStation and station.song then
          return station.song
        end
      end
    end
    return next(song, ctx)
  end)
end

return RivalGear
