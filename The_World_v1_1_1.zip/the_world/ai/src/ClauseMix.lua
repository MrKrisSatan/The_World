local req, mod = ...

-- CLAUSE MIXING (5.0.8)
-- ------------------------------------------------------------------
-- Both dialogue banks build their lines the same way: take a list of
-- situations and a list of attitudes and walk the cross product, taking the
-- first N pairs. This module is that walk, in one place, because the first
-- version of it lived twice and was WRONG BOTH TIMES in the same way.
--
-- THE BUG THIS MODULE EXISTS TO PREVENT (§21: a rotation is not a shuffle).
-- The obvious pairing is
--
--     situation[ i % ns ]   with   attitude[ (i * stride) % na ]
--
-- which looks like it wanders the whole grid and does not. Both indices are
-- periodic in i, so the pair sequence repeats after lcm(ns, na) steps --
-- never after ns * na. With ten situations and ten attitudes that is ten
-- distinct lines out of a hundred available, and a cap of fifteen silently
-- delivers ten. The cell is not empty, the lines are not duplicated, and
-- nothing fails: it just quietly ships a third of the content it claims.
-- It was only visible by COUNTING what materialised (§36).
--
-- The fix is to walk ONE index across the whole grid -- k over [0, ns*na) --
-- and decompose it, so every step lands on a pair no earlier step reached.
-- A stride coprime to the grid size keeps consecutive lines from sharing an
-- opening clause without costing coverage.

local ClauseMix = {}

local function gcd(a, b)
  while b ~= 0 do a, b = b, a % b end
  return a
end

-- The largest stride below total that is coprime to it, biased to land near
-- a third of the way round so consecutive picks change both halves. Falls
-- back to 1 (plain in-order walk) when total is small, which is correct
-- rather than merely safe: with a four-element grid there is nothing to
-- scatter.
function ClauseMix.stride(total)
  if total < 5 then return 1 end
  local start = math.floor(total / 3)
  if start < 2 then start = 2 end
  for delta = 0, total do
    local candidate = start + delta
    if candidate >= total then break end
    if gcd(candidate, total) == 1 then return candidate end
  end
  return 1
end

-- Returns up to `cap` distinct combinations. `join(situation, attitude)`
-- builds the line; returning nil from it skips that pair without consuming a
-- slot, which is how a caller rejects a combination that does not read.
function ClauseMix.cross(situations, attitudes, cap, join)
  local out = {}
  local ns = #situations
  local na = #attitudes
  if ns == 0 or na == 0 then return out end
  local total = ns * na
  local limit = (cap and cap < total) and cap or total
  local stride = ClauseMix.stride(total)
  for step = 0, total - 1 do
    if #out >= limit then break end
    local k = (step * stride) % total
    local s = situations[(k % ns) + 1]
    local a = attitudes[math.floor(k / ns) + 1]
    local line = join and join(s, a) or (s .. " " .. a)
    if line ~= nil then out[#out + 1] = line end
  end
  return out
end

return ClauseMix
