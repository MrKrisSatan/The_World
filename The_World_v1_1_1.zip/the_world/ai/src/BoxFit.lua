local req, mod = ...

-- TEXT FITTING (5.0.8)
-- ------------------------------------------------------------------
-- The engine's text box does not wrap. Every hand-written line in this mod
-- carries its own breaks, which is fine for a line somebody typed and
-- impossible for a line that is composed at load time out of two clauses.
--
-- One fitter, used by data/dialogue_extra.lua (rivals) and
-- data/rocket_dialogue.lua (Team Rocket), because two copies of a wrapper
-- will disagree about the column budget within one release -- §26: when two
-- sites implement one rule they will disagree.
--
-- BUDGETS ARE MEASURED, NOT GUESSED. They come from the widest rows the
-- hand-written content already ships: a first row carrying "NAME: " reaches
-- 26 columns, a continuation row reaches 18. Anything this module emits stays
-- inside that envelope, so a build that renders 4.7.0's lines correctly
-- renders these correctly too.
--
-- Tokens expand AFTER fitting, so their widths have to be estimated. The
-- estimates below are deliberately generous: a short name leaves a gap, a
-- long name overflows, and only one of those is a bug.

local BoxFit = {}

BoxFit.TOKEN_WIDTH = {
  NAME = 8, TITLE = 14, TITLECAP = 14, PLAYER = 8, RIVAL = 8,
  BADGES = 1, N = 5, NEXT = 8, CITY = 10, LAST = 8, MON = 9, ACE = 9,
  WINS = 1, LOSSES = 1, RECORD = 3, REL = 12, STYLE = 8, MOOD = 9,
}

BoxFit.ROW = 18          -- a continuation row
BoxFit.ROW_NAMED = 10    -- what is left of row one after "NAME: "
BoxFit.PAGE_ROWS = 4     -- rows before the box needs a new page

function BoxFit.width(word)
  local n, i = 0, 1
  while i <= #word do
    local s, e, key = word:find("^{([A-Z]+)}", i)
    if s then
      n = n + (BoxFit.TOKEN_WIDTH[key] or 6)
      i = e + 1
    else
      n = n + 1
      i = i + 1
    end
  end
  return n
end

-- Greedy fit into rows. A single word wider than the budget still gets its
-- own row rather than being dropped: losing a word silently is worse than one
-- row that runs long, and the volume test measures the overrun either way.
function BoxFit.rows(text, firstLimit, limit)
  limit = limit or BoxFit.ROW
  local out, cur, curw = {}, nil, 0
  local budget = firstLimit or limit
  for word in tostring(text or ""):gmatch("%S+") do
    local w = BoxFit.width(word)
    if cur == nil then
      cur, curw = word, w
    elseif curw + 1 + w <= budget then
      cur, curw = cur .. " " .. word, curw + 1 + w
    else
      out[#out + 1] = cur
      cur, curw = word, w
      budget = limit
    end
  end
  if cur then out[#out + 1] = cur end
  return out
end

-- \n opens the second row of a page, \v scrolls one row, \f starts a page.
function BoxFit.join(rows)
  local out = {}
  for i = 1, #rows do
    if i > 1 then
      local pos = (i - 1) % BoxFit.PAGE_ROWS
      if pos == 0 then out[#out + 1] = "\f"
      elseif pos == 1 then out[#out + 1] = "\n"
      else out[#out + 1] = "\v" end
    end
    out[#out + 1] = rows[i]
  end
  return table.concat(out)
end

-- The common case: a sentence spoken by somebody whose name prefixes it.
function BoxFit.speak(prefix, text)
  if prefix and prefix ~= "" then
    return prefix .. BoxFit.join(BoxFit.rows(text, BoxFit.ROW_NAMED))
  end
  return BoxFit.join(BoxFit.rows(text, BoxFit.ROW))
end

-- A speaker label too long to share row one -- "Executive Marlowe:" is 18
-- columns on its own -- takes the whole first row and the sentence starts
-- underneath it.
function BoxFit.label(label, text)
  local rows = { label }
  for _, row in ipairs(BoxFit.rows(text, BoxFit.ROW)) do
    rows[#rows + 1] = row
  end
  return BoxFit.join(rows)
end

-- Re-flow a line written before this module existed: strip its breaks and run
-- it through the same fitter, keeping a leading "{NAME}: " as a prefix rather
-- than as a word to be wrapped.
function BoxFit.rewrap(line)
  if type(line) ~= "string" then return line end
  local prefix, body = line:match("^(%{NAME%}: )(.*)$")
  if not prefix then prefix, body = "", line end
  body = body:gsub("[\n\v\f]", " "):gsub("%s+", " "):gsub("^%s*(.-)%s*$", "%1")
  return BoxFit.speak(prefix, body)
end

return BoxFit
