-- src/Compat.lua
--
-- The interop surface: detects, lazily, the external mods this mod knows how
-- to talk to, without bundling any of them.  The rules of the whole surface
-- are the ones Weather-fx's own lib/Interop.lua codifies:
--
--   * ask late -- a probe at LOAD time is answered by the mods that have
--     ALREADY run, which for a priority-ordered loader is a lie: playable-luigi
--     (priority 0) runs before this mod (priority 60), crystal (priority 100)
--     runs after it.  `mod.find` is nil for a mod that is absent, disabled,
--     failed, OR has not run yet, so every probe here is a function evaluated
--     at RUNTIME (the intro build, a save load, a tick decision), never in an
--     entry chunk;
--   * cache only positive answers -- nil is never stored, so a mod that is
--     absent when first asked (or not yet loaded) is honestly re-asked the
--     next time instead of being remembered as gone;
--   * probe capability, not name -- where a mod publishes an API, we ask for
--     the capability through mod.find(...).exports; a mod that is present but
--     exposes nothing relevant is still present for gating, just not for calls.

local Compat = {}
Compat.__index = Compat

-- Manifest id per named probe.  One place to read them all, so a rename in
-- another mod is one edit.  `kanto` uses its own require convention, not an
-- exports surface; `silph` publishes listGhosts() through mod.exports.
-- Primary manifest ids, plus common alternates community packs have used.
-- present() tries each id in order; first positive hit wins and is cached.
local IDS = {
  girlMode = { "girl-mode", "girl_mode", "GirlMode" },
  crystal  = { "crystal", "Crystal", "playable-crystal", "playable_crystal" },
  luigi    = { "playable-luigi", "playable_luigi", "luigi", "PlayableLuigi" },
  weather  = { "weather_fx", "weather-fx", "WeatherFx" },
  kanto    = { "Kanto-Reforged", "kanto-reforged", "KantoReforged" },
  silph    = { "silphscope_network", "silph-scope", "silphscope" },
}

function Compat.new(mod)
  return setmetatable({
    mod = mod,
    cache = {},   -- id -> mod.find handle, set only when present
    forced = {},  -- id -> value, tests and diagnostics pin a result
  }, Compat)
end

-- Resolve a probe name or raw id into the list of candidate manifest ids.
local function candidates(id)
  local v = IDS[id]
  if type(v) == "table" then return v end
  if type(v) == "string" then return { v } end
  return { id }
end

-- Tests and the developer console can pin a probe result, by the named probe
-- ("weather") or by its manifest id ("weather_fx").  nil unpins and the next
-- call goes back to the real mod.find.  A pinned table is treated as a found
-- handle (its .exports is what exports() reads), so a fixture can fake the
-- whole surface of another mod.
function Compat:pin(id, value)
  local list = candidates(id)
  -- pin under every candidate so present() sees it regardless of which id
  -- a fixture or console used
  for _, mid in ipairs(list) do
    self.forced[mid] = value
  end
end

-- Is the mod present?  Lazy, positive-only cache: a negative answer is never
-- stored, so a probe asked before the other mod ran is re-asked on the next
-- call rather than stuck at nil.  `id` may be a named probe ("weather") or a
-- manifest id ("weather_fx").
function Compat:present(id)
  local list = candidates(id)
  for _, mid in ipairs(list) do
    local forced = self.forced[mid]
    if forced ~= nil then return forced ~= false end
    if self.cache[mid] ~= nil then return true end
  end
  if not (self.mod and self.mod.find) then return false end
  for _, mid in ipairs(list) do
    local found = self.mod.find(mid)
    if found then
      self.cache[mid] = found
      return true
    end
  end
  return false
end

-- The other mod's exports table, when it has run and published one.  Resolved
-- the same lazy way as present(): a caller asking at load time gets nil
-- honestly instead of an empty table from a mod whose chunk has not run.
function Compat:exports(id)
  local list = candidates(id)
  for _, mid in ipairs(list) do
    local forced = self.forced[mid]
    if type(forced) == "table" then return forced.exports end
  end
  if not self:present(id) then return nil end
  for _, mid in ipairs(list) do
    local found = self.cache[mid]
    if found then return found.exports end
  end
  return nil
end

-- The named probes, the vocabulary the rest of this mod reads.  Each one is a
-- bool: present, or not.  What a present mod is GOOD FOR is answered by the
-- consumer (Dialogue, AI, Simulation), which asks for the capability it needs
-- at the moment it needs it.
function Compat:girlMode() return self:present("girlMode") end
function Compat:crystal()  return self:present("crystal") end
function Compat:luigi()    return self:present("luigi") end
function Compat:weather()  return self:present("weather") end
function Compat:kanto()    return self:present("kanto") end
function Compat:silph()    return self:present("silph") end

-- ------------------------------------------------------------------
-- Capability accessors.  Each is asked at the moment the consumer needs it
-- and answers nil when the other mod has not run or does not publish the
-- capability -- never a value invented by this mod.
-- ------------------------------------------------------------------

-- Is the human player a girl?  Reads the Choose Your Hero answer at call
-- time: the `gender` save key, with the pre-gender-save fallback of the
-- GREEN hero (a save from before the question existed had its gender
-- inferred from the look).  This gates OUR dialogue; it changes nothing in
-- the vanilla game and nothing in Girl-mode's own text.
function Compat:isGirl()
  local save = self.mod and self.mod.save
  if not (save and type(save.get) == "function") then return false end
  local gender = save:get("gender")
  if gender ~= nil then return gender == "girl" end
  return save:get("player", "red") == "green"
end

-- Does Kanto-Reforged allow this species right now (its DEX SCOPE option)?
-- KR publishes no mod.exports; its species_scope module is reached by the
-- mod's OWN require convention, lazily, and pcall'd so a boot that never
-- loaded KR cannot break here.  Every failure path answers true, so this
-- call only ever REMOVES a species -- a scope flip never fabricates one.
function Compat:krAllows(speciesId, mapId)
  if not self:present("kanto") then return true end
  local ok, SpeciesScope = pcall(require, "mods.Kanto-Reforged.species_scope")
  if not ok or type(SpeciesScope) ~= "table" then return true end
  local mod = SpeciesScope._mod
  if not mod or type(SpeciesScope.allowsSpeciesId) ~= "function" then
    return true
  end
  local good, result = pcall(SpeciesScope.allowsSpeciesId,
                             SpeciesScope, mod, speciesId, mapId)
  if not good then return true end
  return result ~= false
end

-- The ghosts other saves have sent to this machine (silphscope_network's
-- shared storage), or nil when the mod is absent or has not published its
-- list yet -- never an empty table pretending to be a real answer.  Each
-- row is { id, name, mapId, x, y, facing, sprite, pic, party, ... }.
function Compat:ghosts()
  local exports = self:exports("silph")
  if not exports or type(exports.listGhosts) ~= "function" then return nil end
  local ok, list = pcall(exports.listGhosts)
  if not ok or type(list) ~= "table" then return nil end
  return list
end

-- The current overworld weather id (weather_fx), or nil.  The id is the
-- catalogue one ("SUNNY", "FOG", "BLIZZARD", ...), not the battle-field
-- string; callers mirror weather_fx's own favoured-type tables against it.
function Compat:weatherId()
  local exports = self:exports("weather")
  if not exports or type(exports.weather) ~= "function" then return nil end
  local ok, id = pcall(exports.weather)
  if not ok then return nil end
  return id
end

-- The battle-field weather string published by Weather FX (RAINY, HAIL,
-- PSYSTORM, ...), or nil. Simulation calls this accessor only at runtime, so
-- Weather FX may load later without creating a stale negative cache entry.
function Compat:battleWeather()
  local exports = self:exports("weather")
  if not exports or type(exports.battleWeather) ~= "function" then return nil end
  local ok, weather = pcall(exports.battleWeather)
  if not ok then return nil end
  return weather
end

-- Live regional weather snapshot published by newer Weather FX builds.
-- Returns nil when Weather FX is absent/older/not loaded yet.  The Pokégear
-- asks every time its map opens, so hot load order and changing fronts are
-- reflected immediately instead of being cached.
--
-- Weather FX 4.3.1 (package 2.3.1) exposes weather / battleWeather / timeOfDay
-- but not weatherMap. Prefer weatherMap when present; otherwise synthesise a
-- single-row snapshot from the stable exports so the tracker is never blank
-- while Weather FX is actually running.
function Compat:weatherMap()
  local exports = self:exports("weather")
  if not exports then return nil end

  -- Preferred companion API (Weather FX builds that publish it).
  if type(exports.weatherMap) == "function" then
    local ok, rows = pcall(exports.weatherMap)
    if ok and type(rows) == "table" and #rows > 0 then return rows end
  end

  -- Weather FX lib surface: Fronts module (regional state) when available.
  if type(exports.lib) == "table" and type(exports.lib.require) == "function" then
    local ok, rows = pcall(function()
      local Fronts = exports.lib.require("Fronts")
      if type(Fronts) ~= "table" or type(Fronts.REGIONS) ~= "table" then return nil end
      local out = {}
      for _, region in ipairs(Fronts.REGIONS) do
        local st = type(Fronts.state) == "table" and Fronts.state[region.id] or nil
        out[#out + 1] = {
          id = region.id, label = region.label or region.id, land = region.land,
          weather = (st and st.id) or "CLEAR",
          secondsLeft = st and math.max(0, math.floor(tonumber(st.left) or 0)) or 0,
        }
      end
      return out
    end)
    if ok and type(rows) == "table" and #rows > 0 then return rows end
  end

  -- Stable fallback for Weather FX 4.3.1 / 2.x: live overworld id only.
  local id
  if type(exports.weather) == "function" then
    local ok, v = pcall(exports.weather)
    if ok and type(v) == "string" and v ~= "" then id = v end
  end
  if id then
    return {
      {
        id = "HERE",
        label = "HERE",
        land = "kanto",
        weather = id,
        secondsLeft = 0,
        source = "weather",
      },
    }
  end

  return nil
end

-- Full live readout for the Pokégear weather screen. Always polled fresh so
-- the values match Weather FX's current State, never a cached snapshot.
-- Compatible with Weather FX 4.3.1 (weather / battleWeather / timeOfDay) and
-- newer builds that also publish weatherMap.
function Compat:weatherSnapshot()
  local exports = self:exports("weather")
  if not exports then
    return { present = false, reason = "Weather FX not loaded" }
  end
  local snap = { present = true, version = nil, id = nil, battle = nil,
                 tod = nil, hour = nil, regions = nil }
  if type(exports.version) == "string" then snap.version = exports.version end
  if type(exports.weather) == "function" then
    local ok, v = pcall(exports.weather)
    if ok and type(v) == "string" then snap.id = v end
  end
  if type(exports.battleWeather) == "function" then
    local ok, v = pcall(exports.battleWeather)
    if ok and type(v) == "string" then snap.battle = v end
  end
  if type(exports.timeOfDay) == "function" then
    local ok, tod, hour = pcall(exports.timeOfDay)
    if ok then
      if type(tod) == "string" then snap.tod = tod end
      if type(hour) == "number" then snap.hour = hour end
    end
  end
  snap.regions = self:weatherMap()
  return snap
end

-- The primary manifest id a named probe maps to (for logging and diagnostics).
function Compat:id(name)
  local list = candidates(name)
  return list[1]
end

return Compat
