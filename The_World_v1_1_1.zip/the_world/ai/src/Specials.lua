local req, mod = ...
local Util = req("src/Util")
local Specials = {}

Specials.DEFS = {
  {
    id = "guts",
    trainerClass = "OPP_AIR_GUTS",
    name = "Guts",
    fixedName = true,
    gender = "male",
    personality = "BLACK_ANGEL",
    backgroundId = "BG_026",
    forcedTitle = "Black Angel",
    rareSpecial = true,
    rocketAdminPotential = true,
    fallbackSprite = "SPRITE_BLACKBELT",
    basePic = "OPP_BLACKBELT",
    aiClass = "OPP_BLACKBELT",
    baseMoney = 700,
    slot = 101,
    seed = 0x47555453,
    starters = { default = { "WX_150_MEWTWO_VOID", "MEWTWO", "MACHOKE" } },
    homeMaps = { default = { "CELADON_CITY", "ROUTE_7", "ROUTE_16" },
                 gen2 = { "GOLDENROD_CITY", "ROUTE_34", "ROUTE_35" } },
    rareChance = 0.035,
  },
  {
    id = "casca",
    trainerClass = "OPP_AIR_CASCA",
    name = "Casca",
    fixedName = true,
    gender = "female",
    personality = "HAWKSWORD",
    backgroundId = "BG_045",
    forcedTitle = nil,
    rareSpecial = true,
    rocketAdminPotential = true,
    fallbackSprite = "SPRITE_COOLTRAINER_F",
    basePic = "OPP_COOLTRAINER_F",
    aiClass = "OPP_COOLTRAINER_F",
    baseMoney = 650,
    slot = 102,
    seed = 0x43415343,
    starters = { default = { "WX_297_DRATINI_SNOWCOIL", "DRATINI", "EEVEE" } },
    homeMaps = { default = { "CELADON_CITY", "ROUTE_8", "ROUTE_17" },
                 gen2 = { "GOLDENROD_CITY", "ROUTE_35", "ROUTE_36" } },
    rareChance = 0.030,
  },
  {
    id = "griffith",
    trainerClass = "OPP_AIR_GRIFFITH",
    name = "Griffith",
    fixedName = true,
    gender = "male",
    personality = "WHITE_HAWK",
    backgroundId = "BG_071",
    forcedTitle = "White Hawk",
    rareSpecial = true,
    rocketAdminPotential = true,
    fallbackSprite = "SPRITE_GENTLEMAN",
    basePic = "OPP_GENTLEMAN",
    aiClass = "OPP_GENTLEMAN",
    baseMoney = 900,
    slot = 103,
    seed = 0x47524646,
    starters = { default = { "WX_300_MEW_PRIMALWEATHER", "MEW", "TOGEPI" } },
    homeMaps = { default = { "CELADON_CITY", "ROUTE_16", "SAFARI_ZONE" },
                 gen2 = { "GOLDENROD_CITY", "ROUTE_34", "SAFARI_ZONE" } },
    rareChance = 0.020,
  },
  -- 5.1.0. A wide-eyed innocent who wandered into the Gym Challenge by
  -- accident, in the register of a certain 1979 comedy about a man who
  -- stumbles into a fortune and back out of it without ever losing his good
  -- humour. Original character and original text -- the register is the
  -- influence, the words are this mod's.
  --
  -- HE STARTS WITH A DITTO AND NOTHING ELSE, which is the joke made
  -- mechanical: Ditto has no identity of its own and becomes whatever it is
  -- standing in front of, which is the whole of this man's character. It is
  -- also a genuinely awful starter -- Transform, no coverage, terrible stats
  -- -- so he is the one special the player can plausibly beat early, and the
  -- one whose late-game team is entirely whatever he happened to pick up.
  --
  -- Rarest of the four (0.015) and the ONLY special with
  -- rocketAdminPotential = false: Rocket recruits ambition, and he has none.
  {
    id = "navin",
    trainerClass = "OPP_AIR_NAVIN",
    name = "Navin",
    fixedName = true,
    gender = "male",
    personality = "WIDE_EYED",
    backgroundId = "BG_012",
    forcedTitle = "The Jerk",
    rareSpecial = true,
    rocketAdminPotential = false,
    fallbackSprite = "SPRITE_YOUNGSTER",
    basePic = "OPP_YOUNGSTER",
    aiClass = "OPP_YOUNGSTER",
    baseMoney = 120,
    slot = 104,
    seed = 0x4E41564E,
    -- No fallback chain. Every other row lists three species so a missing one
    -- degrades gracefully; his ENTIRE starting hand is meant to be one Ditto,
    -- and a fallback would quietly give him a real Pokemon on any boot where
    -- DITTO is absent. DITTO exists in both generations, so the risk this
    -- guards against is a total conversion -- in which case he should have
    -- nothing rather than something.
    starters = { default = { "DITTO" }, gen2 = { "DITTO" } },
    homeMaps = { default = { "VIRIDIAN_CITY", "ROUTE_2", "PEWTER_CITY" },
                 gen2 = { "CHERRYGROVE_CITY", "ROUTE_30", "VIOLET_CITY" } },
    rareChance = 0.015,
  },
}

local function hash(seed, text)
  local h = tonumber(seed) or 1
  h = h % 2147483647
  for i = 1, #tostring(text) do
    h = (h * 33 + tostring(text):byte(i)) % 2147483647
  end
  return h
end

function Specials.enabled(seed, def)
  if not def then return false end
  local roll = (hash(seed, "berserk:" .. def.id) % 100000) / 100000
  return roll < (tonumber(def.rareChance) or 0.02)
end

-- Called once during manager construction. It is intentionally idempotent so
-- a hot reload cannot duplicate a special character.
function Specials.apply(roster, seed, data)
  if type(roster) ~= "table" then return {} end
  -- Persistence is loaded after build, so read the saved world seed/special
  -- roster directly when available. This keeps an old save's rare cast stable
  -- even during the boot phase before M:load restores seedValue.
  local saved, savedIds
  pcall(function()
    saved = mod.save and mod.save:get("state")
    if type(saved) == "table" then
      seed = tonumber(saved.seedValue) or seed
      if type(saved.specials) == "table" then savedIds = saved.specials end
    end
  end)
  local wanted = {}
  if savedIds then
    for _, id in ipairs(savedIds) do wanted[id] = true end
  end
  for i = #roster, 1, -1 do
    if roster[i] and roster[i].rareSpecial then table.remove(roster, i) end
  end
  local chosen = {}
  for _, def in ipairs(Specials.DEFS) do
    local enabled = savedIds and wanted[def.id] or Specials.enabled(seed, def)
    local copy = Util.copy(def)
    copy.rareEnabled = enabled == true
    if copy.rareEnabled then
      roster[#roster + 1] = copy
      chosen[#chosen + 1] = copy.id
    end
  end
  return chosen
end

return Specials
