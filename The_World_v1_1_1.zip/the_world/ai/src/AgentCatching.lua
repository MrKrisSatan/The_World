local A={}
local function slotsFor(data,mapId)
  local by=data and data.encounters and data.encounters[mapId]
  if type(by)=="table" then return by.slots or by.grass or by end
  local g=data and data.gen2Encounters
  for _,kind in ipairs(g and {g.grass,g.swarmGrass,g.water} or {}) do
    local row=kind and kind[mapId]
    if type(row)=="table" then return row.slots or row end
  end
end
function A.candidates(data,mapId)
  local slots=slotsFor(data,mapId)
  local dex=data and (data.pokemon or data.gen2Pokemon) or {}
  local out={}
  for key,e in pairs(type(slots)=="table" and slots or {}) do
    local sp=type(e)=="table" and (e.species or e.mon or e.id)
      or (type(e)=="string" and e or (type(key)=="string" and key or nil))
    local lv=type(e)=="table" and (e.level or e.lvl or e.minLevel or e.min)
      or (type(e)=="number" and e or nil)
    local allowed=true
    pcall(function()
      if mod and mod.exports and type(mod.exports.worldSpeciesAllowed)=="function" then
        allowed=mod.exports.worldSpeciesAllowed(sp)
      end
    end)
    if type(sp)=="string" and dex[sp] and allowed then out[#out+1]={species=sp,level=tonumber(lv)} end
  end
  return out
end
function A.tryCatch(agent,data,rng,opts)
  opts=opts or {}
  if not agent or not agent.map or type(agent.party)~="table" then return nil end
  local pool=A.candidates(data,agent.map)
  if #pool==0 then return nil end
  agent.balls=math.max(0,tonumber(agent.balls) or tonumber(opts.startBalls) or 0)
  if agent.balls<=0 or not rng:chance(tonumber(opts.chance) or 0.12) then return nil end
  local pick=pool[rng:int(1,#pool)]
  local level=math.max(2,math.floor(pick.level or opts.defaultLevel or agent.baseLevel or agent.level or 5))
  local mon={species=pick.species,level=level,origin=opts.origin or "wild_catch"}
  agent.balls=agent.balls-1
  if #agent.party<6 then agent.party[#agent.party+1]=mon
  else
    agent.pc=type(agent.pc)=="table" and agent.pc or {}
    agent.pc[#agent.pc+1]=mon
  end
  agent.catches=(tonumber(agent.catches) or 0)+1
  return mon
end
function A.restock(agent,target)
  target=math.max(1,tonumber(target) or 5)
  agent.balls=math.max(tonumber(agent.balls) or 0,target)
end
return A
