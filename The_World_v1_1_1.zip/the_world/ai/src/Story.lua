local req, mod = ...
local Util = req("src/Util")

-- STORY ARCS (1.35.0).
--
-- Roadmap §4 asks for emergent personal progression -- "do not create a
-- completely rigid script" -- and §21 for a lightweight achievement system.
-- This file is both, and it is deliberately the THINNEST of the four models,
-- because by 1.35 the mod already contains almost everything a story needs:
--
--   1.32 Memory        gave rivals a record of what happened to them
--   1.33 Relationships gave them causes and a directional social graph
--   1.34 TeamPlan      gave them an identity that can visibly change
--
-- The canonical arc from §4 --
--
--   CONFIDENT -> PLAYER DEFEAT -> FRUSTRATED -> TRAINING -> TEAM CHANGE
--             -> REMATCH -> RESPECT
--
-- -- is therefore NOT implemented here as a state machine. Every step of it is
-- already a real event in another system: the defeat is a Memory event, the
-- team change is a TeamPlan drift, the respect is a Relationships state. What
-- was missing was a NARRATOR: something that reads those systems and says what
-- shape the rival's journey is currently in.
--
-- So MOOD and CHAPTER are DERIVED, in the same discipline as the relationship
-- states and the team identity: pure functions of evidence the rival already
-- carries. Nothing here assigns a mood, nothing rolls for one, and a rival
-- cannot be in a chapter it did not earn. Milestones are the only thing this
-- file stores, and they are a fixed closed set, so the save cannot grow.

local Story = {}

Story.MOODS = {
  "CONTENT", "CONFIDENT", "DETERMINED", "FOCUSED",
  "FRUSTRATED", "HUMBLED", "TRIUMPHANT", "RESTLESS",
}

-- The shape of the journey so far, not a script position. A rival can move
-- backwards (a CONTENDER who is badly beaten is in SETBACK again), which is
-- what makes the postgame arcs in §30 work without extra machinery.
Story.CHAPTERS = {
  "ORIGIN", "RISING", "SETBACK", "REBUILDING", "RESURGENT", "CONTENDER", "CHAMPION",
}

local MOOD_SET, CHAPTER_SET = {}, {}
for _, m in ipairs(Story.MOODS) do MOOD_SET[m] = true end
for _, c in ipairs(Story.CHAPTERS) do CHAPTER_SET[c] = true end
function Story.isMood(v) return MOOD_SET[v] == true end
function Story.isChapter(v) return CHAPTER_SET[v] == true end

Story.MOOD_LABELS = {
  CONTENT = "Content", CONFIDENT = "Confident", DETERMINED = "Determined",
  FOCUSED = "Focused", FRUSTRATED = "Frustrated", HUMBLED = "Humbled",
  TRIUMPHANT = "Triumphant", RESTLESS = "Restless",
}
Story.CHAPTER_LABELS = {
  ORIGIN = "Starting out", RISING = "On the rise", SETBACK = "Setback",
  REBUILDING = "Rebuilding", RESURGENT = "Back in it",
  CONTENDER = "Contender", CHAMPION = "Champion",
}

function Story.moodLabel(v) return Story.MOOD_LABELS[v or "CONTENT"] or "Content" end
function Story.chapterLabel(v) return Story.CHAPTER_LABELS[v or "ORIGIN"] or "Starting out" end

-- ------------------------------------------------------------------
-- Milestones (roadmap §21)
-- ------------------------------------------------------------------
-- A CLOSED, ORDERED list. Each is a predicate over the facts snapshot, tested
-- once and remembered forever. Because the list is fixed, `unlocked` has a
-- hard ceiling of #Story.MILESTONES entries whatever happens in the world --
-- there is no bound to enforce at runtime and none to get wrong.
--
-- `news` marks the ones worth telling the player about. The rest are quiet:
-- §31 says do not spam, and "MATT caught his second Pokémon" is not news.

Story.MILESTONES = {
  { id = "FIRST_CATCH",    label = "First Pokémon caught",
    news = false, test = function(f) return f.collection >= 2 end },
  { id = "FIRST_EVOLUTION", label = "First evolution",
    news = true,  test = function(f) return f.evolved end },
  { id = "FIRST_BADGE",    label = "First badge",
    news = true,  test = function(f) return f.badges >= 1 end },
  { id = "FIRST_RIVAL_WIN", label = "First win over a rival",
    news = false, test = function(f) return f.rivalWins >= 1 end },
  { id = "FIRST_PLAYER_WIN", label = "First win over the player",
    news = true,  test = function(f) return f.playerWins >= 1 end },
  { id = "FIRST_PLAYER_LOSS", label = "First defeat by the player",
    news = false, test = function(f) return f.playerLosses >= 1 end },
  { id = "FIRST_SHINY",    label = "First shiny",
    news = true,  test = function(f) return f.shiny end },
  { id = "RARE_CAPTURE",   label = "Rare Pokémon captured",
    news = true,  test = function(f) return f.rare end },
  { id = "TEAM_OF_SIX",    label = "A full team",
    news = false, test = function(f) return f.party >= 6 end },
  { id = "DEX_50",         label = "50 Pokémon collected",
    news = true,  test = function(f) return f.collection >= 50 end },
  { id = "DEX_100_SEEN",   label = "100 Pokémon seen",
    news = true,  test = function(f) return f.seen >= 100 end },
  { id = "TEAM_REBUILT",   label = "Rebuilt their team",
    news = true,  test = function(f) return f.teamChanges >= 1 end },
  { id = "BONDED",         label = "Bonded with a favourite",
    news = false, test = function(f) return f.aceBattles >= 20 end },
  { id = "HALF_BADGES",    label = "Four badges",
    news = false, test = function(f) return f.badges >= 4 end },
  { id = "ALL_BADGES",     label = "All eight badges",
    news = true,  test = function(f) return f.badges >= 8 end },
  { id = "LEAGUE_ATTEMPT", label = "Entered the Elite Four",
    news = true,  test = function(f) return f.leagueAttempts >= 1 end },
  { id = "CHAMPION",       label = "Champion",
    news = true,  test = function(f) return f.champion end },
}

Story.MILESTONE_BY_ID = {}
for _, m in ipairs(Story.MILESTONES) do Story.MILESTONE_BY_ID[m.id] = m end
function Story.milestoneLabel(id)
  local m = Story.MILESTONE_BY_ID[id]
  return m and m.label or tostring(id)
end
function Story.milestoneCount() return #Story.MILESTONES end

-- ------------------------------------------------------------------
-- The record
-- ------------------------------------------------------------------

local function num(v, d) return tonumber(v) or d end

function Story.new(saved)
  saved = type(saved) == "table" and saved or {}
  local unlocked = {}
  for id, tick in pairs(type(saved.unlocked) == "table" and saved.unlocked or {}) do
    -- an id this build does not define is dropped, not carried: a milestone
    -- list that shrinks between versions must not leave orphans in the save
    if Story.MILESTONE_BY_ID[id] then
      unlocked[id] = math.max(0, math.floor(num(tick, 0)))
    end
  end
  return {
    unlocked = unlocked,
    mood = Story.isMood(saved.mood) and saved.mood or "CONTENT",
    moodSince = math.max(0, math.floor(num(saved.moodSince, 0))),
    chapter = Story.isChapter(saved.chapter) and saved.chapter or "ORIGIN",
    chapterSince = math.max(0, math.floor(num(saved.chapterSince, 0))),
    -- the open setback that a rival is currently answering, if any
    setbackTick = saved.setbackTick and math.max(0, math.floor(num(saved.setbackTick, 0))) or nil,
    setbackBy = type(saved.setbackBy) == "string" and saved.setbackBy or nil,
    answered = saved.answered == true,
    seeded = saved.seeded == true,
  }
end

function Story.serialize(story) return Story.new(story) end

function Story.has(story, id)
  return type(story) == "table" and story.unlocked[id] ~= nil
end

function Story.unlockedCount(story)
  local n = 0
  for _ in pairs(type(story) == "table" and story.unlocked or {}) do n = n + 1 end
  return n
end

-- ------------------------------------------------------------------
-- Milestone checking
-- ------------------------------------------------------------------

-- Returns a list of newly unlocked milestone records. Ordered by the declared
-- list, never by pairs(), so two identical saves report them in one order.
--
-- `silent` backfills without reporting. That is the migration path: a save
-- played for twenty hours before this system existed has genuinely earned
-- eight badges, and the correct response is to record them, not to announce
-- eight fresh achievements the moment the player loads.
function Story.check(story, facts, tick, silent)
  if type(story) ~= "table" or type(facts) ~= "table" then return {} end
  tick = math.max(0, math.floor(num(tick, 0)))
  local gained = {}
  for _, milestone in ipairs(Story.MILESTONES) do
    if story.unlocked[milestone.id] == nil then
      local ok, hit = pcall(milestone.test, facts)
      if ok and hit then
        story.unlocked[milestone.id] = tick
        if not silent then gained[#gained + 1] = milestone end
      end
    end
  end
  return gained
end

function Story.backfill(story, facts, tick)
  Story.check(story, facts, tick, true)
  story.seeded = true
  return story
end

-- ------------------------------------------------------------------
-- Setbacks
-- ------------------------------------------------------------------
-- The hinge of §4's arc. A setback is opened by a defeat that matters, and
-- CLOSED by answering it -- beating the same opponent, or clearing the thing
-- that stopped you. While one is open the rival is visibly working on it,
-- which is what turns a loss into a story instead of a statistic.

-- NOT EVERY DEFEAT IS A SETBACK.
--
-- The first version of this opened one on any loss and closed it on any win,
-- and the 24000-tick soak turned the story into a strobe light: chapters
-- flipping every ~7 ticks and 6785 news items. Nothing errored -- it was just
-- unplayable, and no short test could see it.
--
-- Two rules fix it, and both are causal rather than damping:
--
--   SEVERITY  a defeat is a setback when the rival was riding high and got
--             knocked down, or when it is part of a bad run. A rival trading
--             wins and losses around even is having a normal week, not a
--             crisis. (Losing while confident IS §4's arc exactly: CONFIDENT
--             -> PLAYER DEFEAT -> FRUSTRATED.)
--   COOLDOWN  a rival that has just worked its way out of one setback does not
--             fall into the next one the same afternoon.
--
-- `opts` is optional: with no opts the caller is asserting the defeat matters
-- (the tests and the story fixtures do this deliberately). The cooldown always
-- applies, whoever is asking.
Story.SETBACK_COOLDOWN = 600

function Story.openSetback(story, byId, tick, opts)
  if type(story) ~= "table" then return false end
  tick = math.max(0, math.floor(num(tick, 0)))
  if story.setbackTick and not story.answered then return false end
  if story.answeredTick and (tick - story.answeredTick) < Story.SETBACK_COOLDOWN then
    return false
  end
  if type(opts) == "table" then
    -- A defeat by the PLAYER always counts. It is rare, it is the one the
    -- player will remember, and it is the opening beat of §4's arc. Relying on
    -- the confidence read instead would make severity depend on whether the
    -- caller happened to apply the confidence drop before or after reporting
    -- the loss, which is not a thing correctness should hinge on.
    local significant = (byId == "player")
      or num(opts.streak, 0) <= -2
      or num(opts.confidence, 1) >= 1.15
    if not significant then return false end
  end
  story.setbackTick = tick
  story.setbackBy = type(byId) == "string" and byId or nil
  story.answered = false
  return true
end

function Story.answerSetback(story, byId, tick)
  if type(story) ~= "table" then return false end
  if not story.setbackTick or story.answered then return false end
  if story.setbackBy and byId and story.setbackBy ~= byId then return false end
  story.answered = true
  story.answeredTick = math.max(0, math.floor(num(tick, 0)))
  return true
end

function Story.openSetbackAge(story, tick)
  if type(story) ~= "table" or not story.setbackTick or story.answered then return nil end
  return math.max(0, math.floor(num(tick, 0)) - story.setbackTick)
end

-- ------------------------------------------------------------------
-- Derivation
-- ------------------------------------------------------------------
-- Pure. Same facts in, same mood out, on any platform, in any save.

function Story.mood(story, facts)
  if type(facts) ~= "table" then return "CONTENT" end
  local confidence = num(facts.confidence, 1)
  local streak = num(facts.streak, 0)
  local openSetback = type(story) == "table"
    and story.setbackTick ~= nil and story.answered ~= true

  -- Winning the thing you were chasing outranks everything.
  if facts.champion then return "TRIUMPHANT" end
  if facts.justWonBig then return "TRIUMPHANT" end
  -- An open setback the rival has already responded to reads as purpose, not
  -- misery -- this is §4's TRAINING step, and it is what a player who beat
  -- this rival last week should see the next time they meet.
  if openSetback and (facts.teamChangedSinceSetback or facts.trainedSinceSetback) then
    return "DETERMINED"
  end
  if openSetback and confidence <= 0.8 then return "HUMBLED" end
  if streak <= -3 then return "FRUSTRATED" end
  if openSetback then return "FRUSTRATED" end
  if confidence >= 1.3 and streak >= 1 then return "CONFIDENT" end
  if facts.hasGoal then return "FOCUSED" end
  if streak >= 2 then return "CONFIDENT" end
  if not facts.hasGoal and facts.badges < 8 then return "RESTLESS" end
  return "CONTENT"
end

function Story.chapter(story, facts)
  if type(facts) ~= "table" then return "ORIGIN" end
  local openSetback = type(story) == "table"
    and story.setbackTick ~= nil and story.answered ~= true
  if facts.champion then return "CHAMPION" end
  if openSetback then
    -- a rival that has changed its team since the defeat is REBUILDING; one
    -- that has not is still sitting in the SETBACK
    if facts.teamChangedSinceSetback then return "REBUILDING" end
    return "SETBACK"
  end
  -- a recently ANSWERED setback is the payoff beat: they came back
  if type(story) == "table" and story.answered and story.answeredTick
     and num(facts.tick, 0) - story.answeredTick <= 300 then
    return "RESURGENT"
  end
  if facts.badges >= 8 or facts.leagueAttempts >= 1 then return "CONTENDER" end
  if facts.badges >= 1 then return "RISING" end
  return "ORIGIN"
end

-- A chapter TURNING and a chapter turn being NEWS are different questions.
--
-- The soak made this concrete: after the setback rules above, chapters turned a
-- healthy ~118 times per rival over 24000 ticks -- good pacing to see in the UI
-- or on the debug overlay -- but announcing all of them was still 461 news
-- items, which is exactly what §31 forbids.
--
-- So a turn is newsworthy when it is a real phase change rather than a blip:
-- the majors always are, and everything else has to have held the previous
-- chapter long enough to have been a phase at all.
Story.NEWSWORTHY_HOLD = 900
local ALWAYS_NEWS = { CHAMPION = true, CONTENDER = true }

-- Returns mood, chapter, moodChanged, chapterChanged, chapterNotable.
function Story.advance(story, facts, tick)
  if type(story) ~= "table" then return "CONTENT", "ORIGIN", false, false, false end
  tick = math.max(0, math.floor(num(tick, 0)))
  facts = type(facts) == "table" and facts or {}
  facts.tick = facts.tick or tick
  local mood = Story.mood(story, facts)
  local chapter = Story.chapter(story, facts)
  local moodChanged = mood ~= story.mood
  local chapterChanged = chapter ~= story.chapter
  local held = tick - num(story.chapterSince, tick)
  local notable = chapterChanged
    and (ALWAYS_NEWS[chapter] == true or held >= Story.NEWSWORTHY_HOLD)
  if moodChanged then story.mood, story.moodSince = mood, tick end
  if chapterChanged then story.chapter, story.chapterSince = chapter, tick end
  return mood, chapter, moodChanged, chapterChanged, notable == true
end

-- ------------------------------------------------------------------
-- Presentation
-- ------------------------------------------------------------------

-- §31: only important events reach the news. A chapter turn is important; a
-- mood flicker is not, which is why only chapters and flagged milestones have
-- headlines here.
function Story.chapterHeadline(name, chapter, facts)
  name = tostring(name or "?")
  if chapter == "SETBACK" then
    return name .. " is taking a defeat hard."
  elseif chapter == "REBUILDING" then
    return name .. " is rebuilding after a defeat."
  elseif chapter == "RESURGENT" then
    return name .. " is back, and looking dangerous."
  elseif chapter == "CONTENDER" then
    return name .. " is closing in on the League."
  elseif chapter == "RISING" and facts and num(facts.badges, 0) >= 1 then
    return nil -- the badge itself is already news; do not double-report
  end
  return nil
end

function Story.milestoneHeadline(name, milestone)
  if type(milestone) ~= "table" or not milestone.news then return nil end
  return tostring(name or "?") .. " — " .. tostring(milestone.label) .. "!"
end

function Story.describe(story, facts)
  if type(story) ~= "table" then return "ORIGIN/CONTENT" end
  return string.format("%s / %s  milestones %d/%d%s",
    Story.chapterLabel(story.chapter), Story.moodLabel(story.mood),
    Story.unlockedCount(story), Story.milestoneCount(),
    (story.setbackTick and not story.answered)
      and (" | open setback vs " .. tostring(story.setbackBy or "?")) or "")
end

return Story
