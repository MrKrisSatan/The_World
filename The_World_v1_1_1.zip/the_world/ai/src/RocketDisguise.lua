-- 6.4.0: player-facing Rocket disguise, Rocket Ball black market and double-agent infiltration.
-- The uniform is a real registered key item. Its state is saved separately
-- because wearing an item is world state, not inventory state.
local req, mod = ...
local Util = req("src/Util")
local Version = req("src/Version")
local WonderTrade = req("src/WonderTrade")
local D = {}
D.__index = D
D.UNIFORM = "AIR_ROCKET_UNIFORM"
D.ROCKET_BALL = "AIR_ROCKET_BALL"

function D.new(manager)
  return setmetatable({ manager=manager, owned=false, worn=false, fujiGifted=false,
    hideoutUniformPlaced=false, uniformSource=nil,
    stolen=0, rocketJobs=0, rocketBallsBought=0, rocketMoneySpent=0,
    stolenPokemonBought=0, stolenPokemonSpent=0 }, D)
end

function D:syncOwnedFromInventory()
  local game=self.manager and self.manager.game
  local inv=game and game.save and game.save.inventory
  if type(inv)=="table" and (tonumber(inv[self.UNIFORM]) or 0)>0 then
    if not self.owned then
      self.owned=true
      if not self.uniformSource then
        self.uniformSource=Version.detect(game and game.data)=="gen2"
          and "MAHOGANY_HIDEOUT" or "FUJI"
      end
    end
  end
  return self.owned==true
end

function D:isWorn()
  self:syncOwnedFromInventory()
  return self.owned == true and self.worn == true
end
function D:serialize()
  return {version=2, owned=self.owned==true, worn=self.worn==true,
    fujiGifted=self.fujiGifted==true, uniformSource=self.uniformSource,
    stolen=tonumber(self.stolen) or 0,
    rocketJobs=tonumber(self.rocketJobs) or 0, rocketBallsBought=tonumber(self.rocketBallsBought) or 0,
    rocketMoneySpent=tonumber(self.rocketMoneySpent) or 0,
    stolenPokemonBought=tonumber(self.stolenPokemonBought) or 0,
    stolenPokemonSpent=tonumber(self.stolenPokemonSpent) or 0}
end
function D:load(s)
  if type(s)~="table" then return end
  self.owned=s.owned==true; self.worn=self.owned and s.worn==true
  self.fujiGifted=s.fujiGifted==true; self.uniformSource=s.uniformSource
  self.stolen=tonumber(s.stolen) or 0
  self.rocketJobs=tonumber(s.rocketJobs) or 0
  self.rocketBallsBought=tonumber(s.rocketBallsBought) or 0
  self.rocketMoneySpent=tonumber(s.rocketMoneySpent) or 0
  self.stolenPokemonBought=tonumber(s.stolenPokemonBought) or 0
  self.stolenPokemonSpent=tonumber(s.stolenPokemonSpent) or 0
end
function D:toggle()
  self:syncOwnedFromInventory()
  if not self.owned then return false,"You don't have the ROCKET UNIFORM." end
  self.worn=not self.worn
  pcall(function() self.manager:save() end)
  return true, self.worn and "You put on the TEAM ROCKET uniform." or "You changed back into your normal clothes."
end

-- Generation-aware Mr. Fuji gate. Red/Blue/Yellow use the physical Poké
-- Flute as durable proof that the Pokémon Tower rescue happened. Gold has no
-- equivalent Tower rescue or bag-held Poké Flute: Mr. Fuji is encountered in
-- post-League Kanto, so reaching and speaking to him in Lavender is itself the
-- progression gate. This keeps the feature available on Gold without importing
-- Gen 1-only flags/items into a Gen 2 save.
function D:fujiEligible(game)
  if self.fujiGifted then return false end
  local data=game and game.data
  -- Gold gets the disguise from the Mahogany Team Rocket Hideout instead.
  if Version.detect(data)=="gen2" then return false end
  local inv=game and game.save and game.save.inventory or {}
  return (inv.POKE_FLUTE or 0)>0
end

function D:isFujiInteraction(game,map,name)
  if not self:fujiEligible(game) then return false end
  map=string.upper(tostring(map or "")); name=string.upper(tostring(name or ""))
  if not name:find("FUJI",1,true) then return false end
  if Version.detect(game and game.data)=="gen2" then
    return map:find("LAVENDER",1,true)~=nil
  end
  return map:find("FUJI",1,true)~=nil or map:find("POKEMON_HOUSE",1,true)~=nil
end
function D:grantFromFuji(game)
  if not self:fujiEligible(game) then return false end
  game.save.inventory=game.save.inventory or {}
  game.save.inventory[self.UNIFORM]=math.max(1,game.save.inventory[self.UNIFORM] or 0)
  -- A small starter cache makes the mechanic immediately usable.
  game.save.inventory[self.ROCKET_BALL]=(game.save.inventory[self.ROCKET_BALL] or 0)+5
  self.owned=true; self.fujiGifted=true; self.uniformSource="FUJI"
  pcall(function() self.manager:save() end)
  return true
end

function D:rocketFriendly(member)
  if not (self:isWorn() and member and member.active) then return false end
  local factions=self.manager and self.manager.factions
  local state=factions and factions:belief("rocket") or "UNKNOWN"
  -- Once Rocket has hard evidence, cloth alone no longer resets their memory.
  return state ~= "EXPOSED" and state ~= "HUNTED"
end

function D:rocketBallPrice(member)
  local price=1000
  local f=self.manager and self.manager.factions
  if f then
    local rep=tonumber(f:get("rocket")) or 0
    local profile=f.profile and f:profile("rocket") or nil
    local trust=tonumber(profile and profile.trust) or 0
    if rep>=60 or trust>=70 then price=750
    elseif rep>=30 or trust>=40 then price=850
    elseif rep>=10 or trust>=20 then price=900 end
  end
  return price
end

function D:buyRocketBalls(game,member,count)
  count=math.max(1,tonumber(count) or 5)
  if count~=5 then count=5 end
  if not self:rocketFriendly(member) then return false,"ROCKET: We don't sell to outsiders." end
  local save=game and game.save
  if not save then return false,"ROCKET: No deal." end
  local price=self:rocketBallPrice(member)
  local money=tonumber(save.money) or 0
  if money<price then return false,"ROCKET: Come back with $"..tostring(price).."." end
  save.money=money-price
  save.inventory=save.inventory or {}
  save.inventory[self.ROCKET_BALL]=(save.inventory[self.ROCKET_BALL] or 0)+count
  self.rocketBallsBought=(tonumber(self.rocketBallsBought) or 0)+count
  self.rocketMoneySpent=(tonumber(self.rocketMoneySpent) or 0)+price
  if self.manager and self.manager.factions then
    self.manager.factions:adjust("rocket",1,"black_market_purchase")
    if self.manager.doubleAgent then self.manager.doubleAgent:record("ROCKET_PURCHASE",{target=member and member.id}) end
  end
  pcall(function() self.manager:save() end)
  return true,"Bought 5 ROCKET BALLS for $"..tostring(price).."."
end


function D:stolenOffer(member)
  if not self:rocketFriendly(member) then return nil end
  local rocket=self.manager and self.manager.rocket
  if not rocket or not rocket.stolenAssets then return nil end
  local assets=rocket:stolenAssets(member,true)
  for _,asset in ipairs(assets) do
    if asset and asset.species and (asset.status or "HELD")=="HELD" then
      return asset,rocket:stolenPrice(asset)
    end
  end
  return nil
end

local function placePurchasedPokemon(game,asset)
  local save=game and game.save
  if not save then return false,"No save data." end
  local species=asset and asset.species
  if not species then return false,"That Pokémon can't be transferred." end
  local level=math.max(1,math.min(100,tonumber(asset.level) or (asset.pokemon and tonumber(asset.pokemon.level)) or 5))
  local generation=Version.detect(game and game.data)=="gen2" and 2 or 1
  local mon,why=WonderTrade.makeMon(game.data,species,level,generation)
  if type(mon)~="table" then return false,why or "That Pokémon can't be transferred." end
  if type(asset.pokemon)=="table" and asset.pokemon.nickname then mon.nickname=asset.pokemon.nickname end
  mon.aiRivalsProvenance={kind="ROCKET_STOLEN_PURCHASE",assetId=asset.id,
    originalOwnerId=asset.originalOwnerId or asset.rivalId,originalOwnerName=asset.originalOwnerName,
    sellerId=asset.memberId}
  save.party=type(save.party)=="table" and save.party or {}
  if #save.party<6 then
    save.party[#save.party+1]=mon
    return true,"joined your party"
  end
  if generation==2 then
    local ok,Boxes=pcall(require,"src.core.gen2.Boxes")
    if ok and Boxes and type(Boxes.box)=="function" then
      local idx=tonumber(save.currentBox) or 1
      local box=Boxes.box(save,idx)
      local cap=tonumber(Boxes.MONS_PER_BOX) or 20
      if #box<cap then
        box[#box+1]=mon
        return true,"was sent to BOX"..tostring(idx)
      end
      for i=1,(tonumber(Boxes.NUM_BOXES) or 14) do
        local other=Boxes.box(save,i)
        if #other<cap then other[#other+1]=mon; return true,"was sent to BOX"..tostring(i) end
      end
      return false,"All PC BOXES are full."
    end
  end
  local box=save.box or save.pc or save.storage
  if type(box)~="table" then save.box={}; box=save.box end
  box[#box+1]=mon
  return true,"was sent to the PC"
end

function D:buyStolenPokemon(game,member,assetId)
  if not self:rocketFriendly(member) then return false,"ROCKET: Not for sale to you." end
  local rocket=self.manager and self.manager.rocket
  local asset=rocket and rocket:stolenAssetById(assetId)
  if not asset or asset.memberId~=member.id or (asset.status or "HELD")~="HELD" then
    return false,"ROCKET: That Pokémon is no longer available."
  end
  local price=rocket:stolenPrice(asset)
  local save=game and game.save
  if not save or (tonumber(save.money) or 0)<price then return false,"ROCKET: Bring $"..tostring(price).."." end
  local oldMemberId=asset.memberId
  local ok,where=placePurchasedPokemon(game,asset)
  if not ok then return false,where end
  save.money=(tonumber(save.money) or 0)-price
  member.money=(tonumber(member.money) or 300)+price
  asset.saleHistory=type(asset.saleHistory)=="table" and asset.saleHistory or {}
  asset.saleHistory[#asset.saleHistory+1]={from=oldMemberId,to="PLAYER",tick=rocket.tick,reason="player_sale",price=price}
  asset.status="SOLD_TO_PLAYER"; asset.memberId=nil; asset.playerPurchaseTick=rocket.tick
  if rocket.refreshTrainerParty then rocket:refreshTrainerParty(member) end
  self.stolenPokemonBought=(tonumber(self.stolenPokemonBought) or 0)+1
  self.stolenPokemonSpent=(tonumber(self.stolenPokemonSpent) or 0)+price
  if self.manager and self.manager.doubleAgent then
    self.manager.doubleAgent:record("ROCKET_STOLEN_PURCHASE",{target=asset.species,map=member.map})
  elseif self.manager and self.manager.factions then
    self.manager.factions:adjust("rocket",2,"stolen_pokemon_purchase")
  end
  if rocket.log then rocket:log(member.name.." sold a stolen "..tostring(asset.species).." to the disguised player.","theft",
      {species=asset.species,seller=member.id,price=price,assetId=asset.id}) end
  pcall(function() self.manager:save() end)
  return true,"Bought "..Util.spaced(asset.species).." for $"..tostring(price).."; it "..where.."."
end

function D:offerRocketJob(member)
  if not (self:isWorn() and member and self.manager and self.manager.quests) then return nil end
  local q=self.manager.quests
  local pending=q.takePendingFollowUp and q:takePendingFollowUp(member.id,member.name) or nil
  if pending then return pending end
  for _,existing in ipairs(q.offers or {}) do
    if existing.giverId==member.id and (existing.status=="OFFERED" or existing.status=="ACTIVE" or existing.status=="COMPLETE") then
      return existing
    end
  end
  -- Weather FX present? Some Rocket contacts prefer weather exploitation
  -- work. The quest is still born HERE, during the conversation.
  if q.rocketWeatherOffer and q.weatherContext and q:weatherContext() then
    local roll=((tonumber(self.rocketJobs) or 0)+tonumber(q.nextId or 1))%2
    if roll==0 then
      local weatherJob=q:rocketWeatherOffer(member)
      if weatherJob then self.rocketJobs=self.rocketJobs+1; return weatherJob end
    end
  end
  local map=member.map or (self.manager:worldView() or {}).playerMap or "CELADON_CITY"
  local id=q:newId("rocket_job")
  local job={id=id,kind="ROCKET_JOB",rocketMission=true,giver=(member.rank or "Grunt").." "..(member.name or "Rocket"),
    giverId=member.id,title="Rocket Work: "..Util.spaced(map),map=map,status="OFFERED",
    createdTick=q:tick(),rewardMoney=1200,rewardItem=self.ROCKET_BALL,
    description="Complete Team Rocket work in "..Util.spaced(map).." while wearing the Rocket Uniform.",
    dialogue="You're one of us, right? We have work in "..Util.spaced(map)..". Keep the uniform on and handle the operation. Come back when it's done.",
    sourceInteraction=true, offeredByNpc=true, faction="rocket"}
  q.offers[#q.offers+1]=job
  self.rocketJobs=self.rocketJobs+1
  pcall(function() self.manager:save() end)
  return job
end

function D:installGoldHideoutUniform()
  local data=self.manager and self.manager.data
  if Version.detect(data)~="gen2" then return false end
  local maps=data and data.gen2Maps
  local def=maps and maps.TEAM_ROCKET_BASE_B1F
  if type(def)~="table" then return false end

  def.objects=def.objects or {}
  local target

  -- Prefer the vanilla X Accuracy item ball at (21,12). Reusing an existing
  -- object means Gold owns its visibility, collision and pickup lifecycle.
  for _,obj in ipairs(def.objects) do
    if type(obj)=="table" then
      local ball=obj.itemball
      local item=type(ball)=="table" and ball.item or ball
      if item=="X_ACCURACY" or (obj.x==21 and obj.y==12) then
        target=obj
        break
      end
    end
  end
  if not target then return false end

  if type(target.itemball)=="table" then
    target.itemball.item=self.UNIFORM
    target.itemball.quantity=1
  else
    target.itemball={item=self.UNIFORM,quantity=1}
  end
  target.name="ROCKET_UNIFORM_CACHE"
  self.hideoutUniformPlaced=true
  return true
end

function D:install()
  mod.content.items:register(self.UNIFORM,{id=self.UNIFORM,name="ROCKET UNIFORM",price=0,keyItem=true,tossable=false})
  -- Registered as a ball, but the item.use hook below owns trainer theft.
  mod.content.items:register(self.ROCKET_BALL,{id=self.ROCKET_BALL,name="ROCKET BALL",price=0,tossable=false,
    ball=true,autoCatch=true,randMax=0,tossAnim="TOSS_ANIM"})
  pcall(function() self:installGoldHideoutUniform() end)
  local me=self
  mod.content.commands:register("ai_rivals:buy_rocket_balls", {
    foreground=true,
    fn=function(ctx,memberId)
      if ctx.lastCheck~=true then return end
      local member=nil
      if me.manager and me.manager.rocket then
        for _,row in ipairs(me.manager.rocket.members or {}) do if row.id==memberId then member=row break end end
      end
      local ok,line=me:buyRocketBalls(ctx.game,member,5)
      if me.manager then me.manager.ticker={text="ROCKET SHOP  •  "..tostring(line),age=0,duration=7,offset=0} end
    end,
  })
  mod.content.commands:register("ai_rivals:buy_stolen_pokemon", {
    foreground=true,
    fn=function(ctx,memberId,assetId)
      if ctx.lastCheck~=true then return end
      local member=me.manager and me.manager.rocket and me.manager.rocket:memberById(memberId) or nil
      local ok,line=me:buyStolenPokemon(ctx.game,member,assetId)
      if me.manager then me.manager.ticker={text="ROCKET MARKET  •  "..tostring(line),age=0,duration=8,offset=0} end
    end,
  })
  mod.hooks:wrap("item.use",function(next,game,battle,id,target,list,moveIndex,picker)
    if id==me.UNIFORM then
      me:syncOwnedFromInventory()
      local was=me:isWorn()
      local ok,line=me:toggle()
      if was and me.manager and me.manager.doubleAgent then pcall(function() me.manager.doubleAgent:record("REMOVE_UNIFORM",{}) end) end
      if me.manager then me.manager.ticker={text="ROCKET  •  "..line,age=0,duration=6,offset=0} end
      return
    end
    if id==me.ROCKET_BALL and battle and battle.kind=="trainer" then
      if not me:isWorn() then
        if me.manager then me.manager.ticker={text="ROCKET BALL  •  The uniform must be worn.",age=0,duration=5,offset=0} end
        return
      end
      local inv=game.save.inventory or {}; if (inv[id] or 0)<=0 then return end
      inv[id]=inv[id]-1; if inv[id]<=0 then inv[id]=nil end
      if list and list.close then pcall(function() list:close() end) end
      -- BattleState blocks ordinary balls in trainer battles. Rocket Balls
      -- deliberately cross that boundary by presenting this single throw as
      -- a catchable encounter. autoCatch keeps ownership deterministic.
      battle.rocketTheft=true
      battle.rocketTheftOriginalKind="trainer"
      battle.kind="wild"
      battle:throwBall(id)
      me.stolen=me.stolen+1
      if me.manager and me.manager.quests and me.manager.quests.onRocketTheft then
        local map=(me.manager:worldView() or {}).playerMap
        pcall(function() me.manager.quests:onRocketTheft(battle.enemy and battle.enemy.mon and battle.enemy.mon.species,map) end)
      end
      if me.manager and me.manager.doubleAgent then
        local map=(me.manager:worldView() or {}).playerMap
        me.manager.doubleAgent:record("ROCKET_THEFT",{map=map,target=battle.enemy and battle.enemy.mon and battle.enemy.mon.species})
      elseif me.manager and me.manager.factions then me.manager.factions:adjust("rocket",2,"theft") end
      return
    end
    return next(game,battle,id,target,list,moveIndex,picker)
  end)
end
return D
