local req, mod = ...
local Util = req("src/Util")
local Titles = req("src/Titles")

-- LINES ARE DATA.  This module is the only place that knows how to turn a
-- (rival, situation) pair into a string; data/dialogue.lua is the only place
-- that knows what the strings are.  Nothing in the AI branches on text, and
-- nothing here branches on state beyond looking the state up as a key -- which
-- is what keeps "add a personality" a one-file change.
--
-- Selection is deterministic per rival: the line comes from the rival's own
-- LCG, seeded from its saved state, so the same rival standing in the same
-- place says the same thing until something about it actually moves.  A
-- rival that re-rolled its greeting every time the player pressed A would
-- read as noise rather than as a character.

local Dialogue = {}
Dialogue.__index = Dialogue

-- The {REL} token: the noun a rival uses for the player at its current state.
-- Deliberately a lookup rather than a per-personality bucket, because it has
-- to read naturally inside lines that were written before 1.33.
local REL_WORD = {
  FRIENDLY = "a friend", NEUTRAL = "another trainer",
  COMPETITIVE = "competition", RIVALRY = "my rival",
  RESPECT = "someone worth beating", HOSTILE = "a problem",
  MENTOR = "my student", ALLIED = "my ally",
}

-- opts = { compat = Compat facade, save = the mod's save bucket }.  Both are
-- held lazily: the gender gate is read at the moment a line is picked, so a
-- save that answers the intro question after a rival was spoken to is heard
-- by the next line, not frozen at boot.
function Dialogue.new(lines, gyms, opts)
  return setmetatable({
    lines = lines,
    gyms = gyms,
    compat = opts and opts.compat,
    save = opts and opts.save,
    -- 1.33.0: asked live, like the gender gate above, so toggling bonds off
    -- mid-save silences relationship flavour on the very next line.
    relationships = opts and opts.relationships,
  }, Dialogue)
end

-- The player-gender gate for OUR lines.  Two conditions, both asked live:
-- Girl-mode is installed (a probe, so it must be asked after every mod has
-- run, never at load) AND the Choose Your Hero answer says the player is a
-- girl.  This is deliberately narrow: girl-mode's OWN text is that mod's
-- business, and this mod only picks a different arm of its own dialogue.
-- 1.33.0.  Dialogue never computes a relationship; it asks the rival, which
-- is what keeps src/Relationships.lua the only place the rules live.
function Dialogue:bondsEnabled()
  if type(self.relationships) ~= "function" then return true end
  local ok, enabled = pcall(self.relationships)
  return not ok or enabled ~= false
end

function Dialogue:relationshipState(rival, id)
  if not self:bondsEnabled() then return "NEUTRAL" end
  if type(rival.relationshipTo) ~= "function" then return "NEUTRAL" end
  local ok, state = pcall(rival.relationshipTo, rival, id or "player")
  return (ok and type(state) == "string") and state or "NEUTRAL"
end

function Dialogue:isGirl()
  if not self.compat or not self.compat:girlMode() then return false end
  if not self.save or type(self.save.get) ~= "function" then return false end
  local gender = self.save:get("gender")
  if gender ~= nil then return gender == "girl" end
  return self.save:get("player", "red") == "green"
end

-- ------------------------------------------------------------------
-- Bucket resolution
-- ------------------------------------------------------------------

-- A bucket is a flat list of lines, a table of personality -> list with a
-- `default` arm, and optionally a `girl` arm picked when the player is a
-- girl playing with Girl-mode installed.  Resolving in that order means a
-- new personality that nobody wrote lines for still speaks, which is the
-- whole point of `default`; a girl player with no `girl` arm gets the plain
-- lines rather than silence.
local function resolveBucket(bucket, personalityId, girl)
  if type(bucket) ~= "table" then return nil end
  if girl and type(bucket.girl) == "table" and bucket.girl[1] then
    return bucket.girl
  end
  if type(bucket[1]) == "string" then return bucket end
  local byPersonality = personalityId and bucket[personalityId]
  if type(byPersonality) == "table" and byPersonality[1] then
    return byPersonality
  end
  if type(bucket.default) == "table" and bucket.default[1] then
    return bucket.default
  end
  return nil
end

-- ------------------------------------------------------------------
-- Tokens
-- ------------------------------------------------------------------

-- {PLAYER} is deliberately NOT expanded here: the engine's own TextBox
-- substitution owns that token (and {RIVAL}), and expanding it early would
-- bake one save's name into a line the next save reuses.
function Dialogue:tokens(rival)
  local gyms = self.gyms or {}
  local nextBadge = rival:nextBadge()
  local nextGym = nextBadge and (gyms.byBadge or {})[nextBadge] or nil
  local lastBadge = rival.lastBadgeEarned
  local lastGym = lastBadge and (gyms.byBadge or {})[lastBadge] or nil
  local badges = rival:badgeCount()

  local wins = tonumber(rival.playerWins) or 0
  local losses = tonumber(rival.playerLosses) or 0
  local hasRecord = (wins + losses) > 0
  -- 4.7.0: {TITLE} is what the rest of Kanto calls this rival, and {THEM} is
  -- the name to use for SOMEBODY ELSE in a line -- the title if they have
  -- earned one, their plain name if they have not. A rival with no reputation
  -- yet gets their name, never an empty slot or a placeholder.
  local title = Titles.of(rival)
  return {
    NAME = rival.name or "?",
    TITLE = title or (rival.name or "?"),
    -- Their own title spoken as a sentence opener.
    TITLECAP = Titles.spokenName(rival, nil, true),
    BADGES = tostring(badges),
    N = Util.numberWord(badges),
    NEXT = nextGym and nextGym.leader or "the LEAGUE",
    CITY = Util.spaced(nextGym and nextGym.city
      or (gyms.league and gyms.league.city) or "KANTO"),
    LAST = lastGym and lastGym.leader or "them",
    MON = self:speciesName(rival, rival:strongestSpecies()),
    -- Rival's record vs the player. Never show "0-0" / "0-1" on a first meeting
    -- before any real battle has been fought.
    WINS = hasRecord and tostring(wins) or "—",
    LOSSES = hasRecord and tostring(losses) or "—",
    RECORD = hasRecord and (tostring(wins) .. "-" .. tostring(losses))
      or "just getting started",
    -- how this rival currently regards the player, in its own words
    REL = REL_WORD[self:relationshipState(rival, "player")] or "another trainer",
    -- 1.34.0: the rival's own team identity, in its own words
    STYLE = type(rival.teamStyleLabel) == "function"
      and (select(2, pcall(rival.teamStyleLabel, rival)) or "balanced"):lower()
      or "balanced",
    -- 1.35.0: the rival's current mood, in its own words
    MOOD = type(rival.moodLabel) == "function"
      and (select(2, pcall(rival.moodLabel, rival)) or "content"):lower()
      or "content",
    ACE = self:speciesName(rival, type(rival.favouriteSpecies) == "function"
      and (select(2, pcall(rival.favouriteSpecies, rival)) or nil)
      or rival.aceSpecies),
  }
end

function Dialogue:speciesName(rival, species)
  if not species then return "team" end
  local def = rival.speciesDef and rival:speciesDef(species)
  return (def and def.name) or Util.spaced(species)
end

-- gsub with a table replacement would treat an unknown token as "leave it
-- alone", which puts a literal {MON} on screen.  Blanking is worse than a
-- generic word, so unknown tokens fall through to the raw name.
function Dialogue:expand(line, tokens)
  if type(line) ~= "string" then return "" end
  return (line:gsub("{([A-Z]+)}", function(key)
    if key == "PLAYER" or key == "RIVAL" then return "{" .. key .. "}" end
    local value = tokens[key]
    if value == nil then return Util.spaced(key) end
    return tostring(value)
  end))
end

-- ------------------------------------------------------------------
-- Public lookups
-- ------------------------------------------------------------------

function Dialogue:pick(rival, bucket, salt)
  local list = resolveBucket(bucket, rival.personalityId, self:isGirl())
  if not list then return nil end
  -- Draw from a throwaway stream seeded off the rival's live state rather
  -- than advancing the rival's own RNG: talking to someone must not change
  -- what they decide to do next, or the world would drift differently for a
  -- player who chats than for one who walks past.
  local seed = (rival.rng and rival.rng.state or 1)
    + (salt or 0) * 7919
    + (rival.ticks or 0)
  local stream = Util.rng(seed)
  return stream:pick(list)
end

function Dialogue:line(rival, bucket, salt)
  local raw = self:pick(rival, bucket, salt)
  if not raw then return nil end
  return self:expand(raw, self:tokens(rival))
end

-- The greeting shown when the player talks to a rival that is not about to
-- fight them.  A pending badge is bragged about first and exactly once.
function Dialogue:greeting(rival)
  local news = rival.newsPending
  if news then
    -- 1.7.0: "CHAMPION" news uses the dedicated bucket
    local bucket = (news == "CHAMPION")
      and (self.lines.greeting or {}).CHAMPION
      or (self.lines.badgeNews or {})[news]
    local line = bucket and self:line(rival, bucket, 11)
    rival.newsPending = nil
    if line then return line end
  end
  -- Prefer champion flavour when they have cleared the League
  if rival.champion then
    local champ = (self.lines.greeting or {}).CHAMPION
    local line = champ and self:line(rival, champ, 12)
    if line then return line end
  end
  local byState = (self.lines.greeting or {})[rival.state]
  local line = byState and self:line(rival, byState, 1)
  if line then return line end
  local idle = (self.lines.greeting or {}).IDLE
  local line = idle and self:line(rival, idle, 1)
    or (rival.name .. ": ...")
  -- 1.33.0: relationship flavour is an ADDITIONAL prefix opportunity, chosen
  -- before the record reminder because how a rival feels about you is more
  -- interesting than the scoreline.  The existing selection below is
  -- untouched: if there is no relationship line, this reads exactly as 1.32.
  -- 1.35.0: mood is offered first, because what a rival is feeling right now
  -- is more immediate than how it feels about you in general. Both remain
  -- PREFIXES to the 1.32 line, which is still selected exactly as before.
  -- A career is the most striking thing about a rival that has one, so it is
  -- offered first -- and, like every other prefix since 1.33, it never
  -- replaces the 1.32 line underneath.
  local formerly = self:formerlyLine(rival)
  if formerly then
    local roll = (rival.rng and rival.rng.float and rival.rng:float()) or math.random()
    if roll < 0.45 then
      return formerly .. "\f" .. line
    end
  end
  local career = self:careerLine(rival)
  if career then
    local roll = (rival.rng and rival.rng.float and rival.rng:float()) or math.random()
    if roll < 0.5 then
      return career .. "\f" .. line
    end
  end
  local mood = self:moodLine(rival)
  if mood then
    local roll = (rival.rng and rival.rng.float and rival.rng:float()) or math.random()
    if roll < 0.35 then
      return mood .. "\f" .. line
    end
  end
  local relationship = self:relationshipLine(rival, "player")
  if relationship then
    local roll = (rival.rng and rival.rng.float and rival.rng:float()) or math.random()
    if roll < 0.45 then
      return relationship .. "\f" .. line
    end
  end
  local score = self:scoreLine(rival)
  if score and (tonumber(rival.playerWins) or 0) + (tonumber(rival.playerLosses) or 0) > 0 then
    -- ~40% of greets remind the player of the record
    local roll = (rival.rng and rival.rng.float and rival.rng:float()) or math.random()
    if roll < 0.4 then
      return score .. "\f" .. line
    end
  end
  return line
end

-- A state-keyed bucket, resolved through the SAME resolveBucket path as every
-- other line, so a state nobody wrote lines for falls through to `default`
-- and a girl arm still works.  Returns nil when the state is NEUTRAL: neutral
-- is the absence of a relationship, not a thing to comment on.
-- 1.35.0: mood flavour. Same bucket resolution as everything else, so a mood
-- nobody wrote lines for falls through to `default` and CONTENT says nothing --
-- content is the absence of a mood worth remarking on.
-- 2.2.0 §7: a rival who left the Gym Challenge talks about the life it took.
-- Resolved through the same bucket path as everything else, and returns nil
-- for a rival still on the Gym Challenge -- so no ordinary rival can ever
-- speak a line hinting at a destiny it has not taken.
function Dialogue:careerLine(rival)
  if type(rival.lifePathId) ~= "function" then return nil end
  local ok, path = pcall(rival.lifePathId, rival)
  if not ok or path == "GYM_CHALLENGE" then return nil end
  local bucket = (self.lines.career or {})[path]
  if not bucket then return nil end
  return self:line(rival, bucket, 41)
end

-- 2.4.0 §19/§29: what a rival says about where it has BEEN. Offered ahead of
-- the current-career line, because "I was with Team Rocket" is the more
-- arresting fact about a rival who is now a researcher.
function Dialogue:formerlyLine(rival)
  if type(rival.ensureLifePath) ~= "function" then return nil end
  local ok, record = pcall(rival.ensureLifePath, rival)
  if not ok or type(record) ~= "table" then return nil end
  local key
  local redeemed = false
  for _, entry in ipairs(record.history or {}) do
    if entry.path == "TEAM_ROCKET" then redeemed = true end
  end
  if redeemed and record.path ~= "TEAM_ROCKET" then
    key = "TEAM_ROCKET"
  elseif record.path == "GYM_CHALLENGE" and record.previous
     and record.previous ~= "GYM_CHALLENGE" then
    key = "RETURNED"
  end
  if not key then return nil end
  local bucket = (self.lines.formerly or {})[key]
  if not bucket then return nil end
  return self:line(rival, bucket, 43)
end

function Dialogue:moodLine(rival)
  if type(rival.mood) ~= "function" then return nil end
  local ok, mood = pcall(rival.mood, rival)
  if not ok or mood == "CONTENT" then return nil end
  local bucket = (self.lines.mood or {})[mood]
  if not bucket then return nil end
  return self:line(rival, bucket, 37)
end

function Dialogue:relationshipLine(rival, id)
  if not self:bondsEnabled() then return nil end
  local state = self:relationshipState(rival, id or "player")
  if state == "NEUTRAL" then return nil end
  -- COMPETITIVE lines often mention the score. Skip them until a real
  -- battle record exists so first meetings never say "We're 0-0".
  if state == "COMPETITIVE" then
    local wins = tonumber(rival.playerWins) or 0
    local losses = tonumber(rival.playerLosses) or 0
    if wins + losses <= 0 then return nil end
  end
  local bucket = (self.lines.relationship or {})[state]
  if not bucket then return nil end
  return self:line(rival, bucket, 31)
end

function Dialogue:challenge(rival)
  local base = self:line(rival, self.lines.challenge or {}, 2)
    or (rival.name .. ": Let's battle!")
  local wins = tonumber(rival.playerWins) or 0
  local losses = tonumber(rival.playerLosses) or 0
  if wins + losses > 0 then
    local score = self:line(rival, self.lines.scoreRemind or {}, 7)
    if score then
      return score .. "\f" .. base
    end
    return string.format(
      "%s: We're %d-%d.\f%s",
      rival.name or "?", wins, losses, base)
  end
  return base
end

-- Used by the Elite Four champion replacement seam. Keeping this separate
-- from ordinary encounters lets each personality frame the title fight in
-- its own voice without changing the normal rival challenge dialogue.
function Dialogue:championChallenge(rival)
  local bucket = self.lines.eliteChampion or self.lines.challenge or {}
  return self:line(rival, bucket, 29) or self:challenge(rival)
end

function Dialogue:scoreLine(rival)
  local wins = tonumber(rival.playerWins) or 0
  local losses = tonumber(rival.playerLosses) or 0
  if wins + losses <= 0 then return nil end
  return self:line(rival, self.lines.scoreRemind or {}, 7)
    or string.format("%s: Record vs you:\n%d wins, %d losses.",
         rival.name or "?", wins, losses)
end

function Dialogue:afterBattle(rival, rivalWon)
  local bucket = rivalWon and self.lines.afterWin or self.lines.afterLoss
  return self:line(rival, bucket or {}, rivalWon and 3 or 4)
    or (rival.name .. ": ...")
end

function Dialogue:gymLoss(rival)
  return self:line(rival, self.lines.gymLoss or {}, 5)
end

function Dialogue:stateLabel(state)
  return (self.lines.states or {})[state] or Util.spaced(state or "?")
end

return Dialogue
