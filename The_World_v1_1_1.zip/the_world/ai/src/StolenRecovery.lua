local req, mod = ...
local Util = req("src/Util")
local R = {}; R.__index=R

function R.new(manager)
  return setmetatable({manager=manager,recognized={},recovered={},version=1},R)
end
function R:serialize() return {version=1,recognized=Util.copy(self.recognized),recovered=Util.copy(self.recovered)} end
function R:load(s) if type(s)=='table' then self.recognized=Util.copy(s.recognized or {}); self.recovered=Util.copy(s.recovered or {}) end end

local function stores(save)
  return {save and save.party, save and save.box, save and save.pc, save and save.storage}
end
function R:findPlayerPokemon(game,rivalId)
  local save=game and game.save
  for _,store in ipairs(stores(save)) do
    if type(store)=='table' then
      for i,mon in ipairs(store) do
        local p=mon and mon.aiRivalsProvenance
        if p and p.kind=='ROCKET_STOLEN_PURCHASE' and p.originalOwnerId==rivalId then
          return mon,store,i,p
        end
      end
    end
  end
end
function R:recognitionLine(game,rival)
  local mon,_,_,p=self:findPlayerPokemon(game,rival and rival.id)
  if not mon then return nil end
  local species=Util.spaced(mon.species or 'Pokemon')
  if not self.recognized[p.assetId] then
    return rival.name..": Wait... that "..species.." is mine. Team Rocket stole it from me!"
  end
  return rival.name..": I haven't forgotten my "..species..". I want it back."
end
function R:onRecognition(game,rival)
  local mon,_,_,p=self:findPlayerPokemon(game,rival.id); if not mon then return false end
  self.recognized[p.assetId]=true
  rival:rememberEvent({tick=self.manager.tick,type='STOLEN_POKEMON_FOUND',target=p.assetId,location=rival.map})
  if rival.recordRelationship then rival:recordRelationship('PLAYER','BETRAYED',{tick=self.manager.tick}) end
  local q=self.manager.quests
  if q then
    for _,x in ipairs(q.offers or {}) do if x.assetId==p.assetId and x.status~='FAILED' then return true end end
    q:offerFromIssuer(rival,{kind='RETURN_STOLEN_POKEMON',title='Return '..Util.spaced(mon.species),
      description='Return '..Util.spaced(mon.species)..' to '..rival.name..'. Team Rocket stole this exact Pokémon earlier.',
      dialogue=rival.name..': Team Rocket stole that Pokémon from me. Please return it.',
      assetId=p.assetId,species=mon.species,map=rival.map,rewardMoney=500,faction='community'})
  end
  pcall(function() self.manager:save() end)
  return true
end
function R:returnToOwner(game,rival,assetId)
  local mon,store,index,p=self:findPlayerPokemon(game,rival.id)
  if not mon or p.assetId~=assetId then return false end
  table.remove(store,index)
  mon.aiRivalsProvenance.returnedToOriginalOwner=true
  mon.aiRivalsProvenance.returnTick=self.manager.tick
  rival.party=rival.party or {}; rival.party[#rival.party+1]=mon
  self.recovered[assetId]={tick=self.manager.tick,owner=rival.id,method='PLAYER_RETURN'}
  rival:rememberEvent({tick=self.manager.tick,type='STOLEN_POKEMON_RECOVERED',target=assetId,location=rival.map})
  if rival.recordRelationship then rival:recordRelationship('PLAYER','HELPED',{tick=self.manager.tick}) end
  local rocket=self.manager.rocket; local asset=rocket and rocket:stolenAssetById(assetId)
  if asset then asset.status='RECOVERED'; asset.memberId=nil; asset.recoveredBy=rival.id; asset.recoveredTick=rocket.tick end
  if self.manager.worldState then self.manager.worldState:addEvent('RECOVERY',rival.map,rival.name..' recovered a Pokémon stolen by Team Rocket.',{assetId=assetId,species=mon.species}) end
  pcall(function() self.manager:save() end); return true
end
return R
