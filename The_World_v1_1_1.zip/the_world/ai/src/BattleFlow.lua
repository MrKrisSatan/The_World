-- Rival challenge transaction policy. Kept independent of engine hooks so
-- launchers, event adapters and tests can share one identity-safe lifecycle.
local BattleFlow = {}

function BattleFlow.release(manager, rivalId)
  local activeId = manager.rivalBattleActiveRivalId
  if activeId and rivalId and activeId ~= rivalId then return false end
  manager.rivalBattleSequenceActive = false
  manager.rivalBattleActiveRivalId = nil
  manager.pendingRivalBattleLaunch = nil
  manager.worldChallenge = false
  if not activeId or not manager.pending or manager.pending.id == activeId then
    manager.pending = nil
  end
  if not activeId or not manager.pendingChampion
      or manager.pendingChampion.id == activeId then
    manager.pendingChampion = nil
  end
  return true
end

function BattleFlow.endedRival(manager)
  local activeId = manager.rivalBattleActiveRivalId
  return manager.pending or (activeId and manager.byId[activeId]), activeId
end

function BattleFlow.matches(manager, rival, activeId, oppClass, championBattle)
  if not oppClass then return true end
  return rival.def.trainerClass == oppClass
    or (rival.def.gen2Shadow and rival.def.gen2Shadow == oppClass)
    or championBattle
    or (manager.rivalBattleSequenceActive and activeId == rival.id)
end

return BattleFlow
