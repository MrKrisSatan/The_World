local req, mod = ...
local Util = req("src/Util")
local BattleSim = req("src/BattleSim")

local Tournaments = {}
Tournaments.__index = Tournaments

local PLAYER = "__player"

local function healthyCount(rival)
  local n = 0
  for _, slot in ipairs((rival and rival.party) or {}) do
    local hp = tonumber(slot.hp)
    if hp == nil and rival and rival.maxHpOf then hp = rival:maxHpOf(slot) end
    if (hp or 0) > 0 then n = n + 1 end
  end
  return n
end

local function copyIds(rows)
  local out = {}
  for i, v in ipairs(rows or {}) do out[i] = v end
  return out
end

local function shuffle(rows, rng)
  local out = copyIds(rows)
  for i = #out, 2, -1 do
    local j = rng and rng.int and rng:int(1, i) or math.max(1, math.floor(i / 2))
    out[i], out[j] = out[j], out[i]
  end
  return out
end

function Tournaments.new(manager)
  return setmetatable({
    manager = manager,
    active = nil,
    nextAutonomousTick = 0,
    serial = 0,
    lastPlayerTournamentDay = nil,
    -- 4.7.0: "tournaments are only once a day for the player AND EACH RIVAL to
    -- initiate". One key per initiator, so a hundred rivals do not share one
    -- allowance and the player's day is not spent by somebody else's event.
    initiatedDay = {},
  }, Tournaments)
end

function Tournaments:serialize()
  return {
    active = self.active and Util.copy(self.active) or nil,
    nextAutonomousTick = tonumber(self.nextAutonomousTick) or 0,
    serial = tonumber(self.serial) or 0,
    lastPlayerTournamentDay = self.lastPlayerTournamentDay,
    initiatedDay = self.initiatedDay,
  }
end

function Tournaments:restore(saved)
  saved = type(saved) == "table" and saved or {}
  self.active = type(saved.active) == "table" and Util.copy(saved.active) or nil
  self.nextAutonomousTick = tonumber(saved.nextAutonomousTick) or 0
  self.serial = tonumber(saved.serial) or 0
  self.lastPlayerTournamentDay = type(saved.lastPlayerTournamentDay) == "string" and saved.lastPlayerTournamentDay or nil
  -- Bounded on load: one entry per rival that has actually initiated, and a
  -- day key is a short string. A hundred rivals is a hundred small strings,
  -- and yesterday's entries are overwritten rather than accumulated.
  self.initiatedDay = {}
  if type(saved.initiatedDay) == "table" then
    for id, day in pairs(saved.initiatedDay) do
      if type(id) == "string" and type(day) == "string" then
        self.initiatedDay[id] = day
      end
    end
  end
  -- A live player battle cannot survive a process restart. Re-stage that pair
  -- as a pending match rather than pretending it resolved while the game was off.
  if self.active and self.active.playerBattleLive then
    self.active.playerBattleLive = false
    self.active.pendingLaunch = true
  end
end

function Tournaments:eligible(mode)
  local out = {}
  for _, rival in ipairs(self.manager.rivals or {}) do
    local partyCount = #((rival and rival.party) or {})
    if partyCount > 0 and (mode ~= "DOUBLE" or partyCount >= 2) then
      out[#out + 1] = rival
    end
  end
  return out
end

function Tournaments:maxPlayerRivals(mode)
  return math.min(100, #self:eligible(mode))
end


local function calendarDayKey()
  if os and type(os.date) == "function" then
    local ok, value = pcall(os.date, "%Y-%m-%d")
    if ok and type(value) == "string" and value ~= "" then return value end
  end
  return nil
end

local RARE_REWARDS = {
  "RARE_CANDY", "PP_UP", "MAX_REVIVE", "FULL_RESTORE",
  "MAX_ELIXIR", "MAX_ETHER", "NUGGET",
}

function Tournaments:playerTournamentAvailableToday()
  return self:mayInitiateToday(PLAYER)
end

-- May this initiator start a tournament today? `who` is PLAYER or a rival id.
--
-- A boot with no clock (Gen 1 has none of its own; calendarDayKey reads device
-- time) returns true and no key: the limit simply does not apply rather than
-- locking everyone out forever, which is what a nil day key would do if it
-- were treated as a day.
function Tournaments:mayInitiateToday(who)
  local today = calendarDayKey()
  if not today then return true, nil end
  who = who or PLAYER
  if who == PLAYER then
    -- The player's own key stays where it was so existing saves keep their
    -- spent day rather than silently getting a free tournament on upgrade.
    return self.lastPlayerTournamentDay ~= today, today
  end
  return (self.initiatedDay or {})[who] ~= today, today
end

function Tournaments:spendInitiation(who, today)
  if not today then return end
  if who == PLAYER or who == nil then
    self.lastPlayerTournamentDay = today
  else
    self.initiatedDay = self.initiatedDay or {}
    self.initiatedDay[who] = today
  end
end

-- Everyone who can SEE the event. Rivals standing on the venue map who are not
-- in the bracket, plus the player when they are there. A tournament nobody
-- watches is worth less than one the whole of Cerulean turns out for, which is
-- what Christopher asked the rewards to reflect.
function Tournaments:witnesses(t)
  if not (type(t) == "table" and t.venueMap) then return 0 end
  local entered = {}
  for _, id in ipairs(t.allEntrants or t.entrants or {}) do entered[id] = true end
  local seen = 0
  for _, rival in ipairs(self.manager.rivals or {}) do
    if rival and rival.id and not entered[rival.id] and rival.map == t.venueMap then
      seen = seen + 1
    end
  end
  local world = self.manager.worldView and self.manager:worldView() or nil
  if t.playerEntry or (world and world.playerMap == t.venueMap) then
    seen = seen + 1
  end
  return seen
end

-- 4.7.0: THE PURSE SCALES WITH THE CROWD AND THE FIELD.
--
-- "the rare items and money vary depending on how many people witness the
-- tournament and how many rivals participate in it".
--
-- Both halves are bounded and both are read from the world at the moment the
-- bracket was BUILT (participants) and the moment it finishes (witnesses) --
-- so a player cannot inflate the purse by walking the venue afterwards, and a
-- rival wandering off mid-event does not shrink it.
--
-- The multiplier is deliberately sub-linear and capped: a 100-rival event in
-- a crowded city should feel like a real occasion, not like a money printer
-- that makes every other source of income pointless (the "no unbounded
-- resources" line in the brief).
Tournaments.BASE_PURSE = 900
Tournaments.PER_ENTRANT = 0.09
Tournaments.PER_WITNESS = 0.12
Tournaments.MAX_MULTIPLIER = 6.0
Tournaments.EXTRA_ITEM_AT = 2.5      -- multiplier needed for a second item
Tournaments.THIRD_ITEM_AT = 4.5

function Tournaments:purseMultiplier(t)
  local entrants = math.max(0, math.floor(tonumber(t and t.originalCount) or 0))
  local seen = math.max(0, math.floor(tonumber(t and t.witnessCount) or 0))
  local m = 1 + entrants * Tournaments.PER_ENTRANT + seen * Tournaments.PER_WITNESS
  return math.min(Tournaments.MAX_MULTIPLIER, m)
end

function Tournaments:prizeCount(multiplier)
  local n = 1
  if multiplier >= Tournaments.EXTRA_ITEM_AT then n = 2 end
  if multiplier >= Tournaments.THIRD_ITEM_AT then n = 3 end
  return n
end

function Tournaments:awardPlayerPrize(t)
  if not (t and t.champion == PLAYER) then return nil end
  local manager = self.manager
  local rng = manager.rivals and manager.rivals[1] and manager.rivals[1].rng
  local multiplier = self:purseMultiplier(t)
  local wanted = self:prizeCount(multiplier)
  local pool = copyIds(RARE_REWARDS)
  pool = shuffle(pool, rng)
  local won = {}
  for _, item in ipairs(pool) do
    if #won >= wanted then break end
    if manager.givePlayerItem and manager:givePlayerItem(item) then
      won[#won + 1] = item
    end
  end
  -- The purse. Rounded to a round number because prize money in this game
  -- always is, and floored at the base so a tiny event still pays something.
  local money = math.floor(Tournaments.BASE_PURSE * multiplier / 10) * 10
  if manager.givePlayerMoney then pcall(manager.givePlayerMoney, manager, money) end
  t.prizeMoney = money
  t.prizeItems = won
  t.multiplier = multiplier
  return won[1], won, money, multiplier
end

-- 4.7.0: a tournament is a public event, so the announcements use the name the
-- public uses. The player is always "PLAYER": the player has no title in this
-- mod, and inventing one would be speaking for them.
local function participantName(manager, id)
  if id == PLAYER then return "PLAYER" end
  local r = manager.byId and manager.byId[id]
  if not r then return tostring(id) end
  if type(manager.spokenNameOf) == "function" then
    local ok, spoken = pcall(manager.spokenNameOf, manager, r)
    if ok and type(spoken) == "string" and spoken ~= "" then return spoken end
  end
  return r.name or r.id
end

function Tournaments:news(kind, id, other, tournament)
  local r = id ~= PLAYER and self.manager.byId[id] or nil
  local name = participantName(self.manager, id)
  if kind == "eliminated" then
    local by = participantName(self.manager, other)
    if r then self.manager:addNews(r, { kind = "tournament_eliminated", by = by,
      format = tournament.mode })
    else
      self.manager.news[#self.manager.news + 1] = {
        tick = self.manager.sim and self.manager.sim.tick or 0,
        text = name .. " was knocked out of a " .. tournament.mode:lower() .. " tournament by " .. by .. "."
      }
    end
  elseif kind == "won" then
    if r then self.manager:addNews(r, { kind = "tournament_won", format = tournament.mode })
    else
      self.manager.news[#self.manager.news + 1] = {
        tick = self.manager.sim and self.manager.sim.tick or 0,
        text = "The player won the " .. tournament.mode:lower() .. " tournament!"
      }
    end
  end
end

function Tournaments:simMatch(aId, bId, tournament)
  if not bId then return aId end
  if not aId then return bId end
  local a, b = self.manager.byId[aId], self.manager.byId[bId]
  if not (a and b) then return a and aId or bId end
  if a.prepareForBattle then a:prepareForBattle() end
  if b.prepareForBattle then b:prepareForBattle() end
  local result = BattleSim.run(a.ctx.data, a.party, b.party, a.rng)
  local winner = result and result.winner == "b" and b or a
  local loser = winner == a and b or a
  -- Tournament rounds do not strand the whole world with fainted teams: they
  -- are organised events with healing between rounds. The simulator is used
  -- for the result, then both contestants return to their pre-bout HP state.
  if a.heal then pcall(a.heal, a) end
  if b.heal then pcall(b.heal, b) end
  if self.manager.recordBondBattle then
    pcall(self.manager.recordBondBattle, self.manager, a, b.id, winner == a, { tournament = true })
    pcall(self.manager.recordBondBattle, self.manager, b, a.id, winner == b, { tournament = true })
  end
  self:news("eliminated", loser.id, winner.id, tournament)
  return winner.id
end

function Tournaments:finish(t)
  local champion = t.entrants and t.entrants[1]
  t.champion = champion
  t.finished = true
  t.active = false
  -- The crowd is counted ONCE, here, and stored on the bracket: the prize is
  -- then a pure function of the record rather than of whoever happens to be
  -- standing around when the reward code runs.
  t.witnessCount = self:witnesses(t)
  self:news("won", champion, nil, t)
  if t.playerEntry then
    local won = champion == PLAYER
    local prize, items, money = nil, nil, nil
    if won then prize, items, money = self:awardPlayerPrize(t) end
    t.prize = prize
    self.manager.ticker = {
      text = won and ("TOURNAMENT  •  YOU WON!"
        .. (prize and (" PRIZE: " .. tostring(prize):gsub("_", " ")
             .. ((items and #items > 1) and (" +" .. tostring(#items - 1)) or "")) or "")
        .. (money and ("  " .. tostring(money) .. "P") or "")) or
        ("TOURNAMENT  •  " .. participantName(self.manager, champion) .. " WON!"),
      age = 0, duration = 10, offset = 0,
    }
  end
  self.active = nil
  pcall(function() self.manager:save() end)
end

-- Advance a bracket until it either finishes or reaches a player match.
function Tournaments:advance()
  local t = self.active
  if not (t and t.active) then return false end
  while t and t.active do
    if #t.entrants <= 1 then self:finish(t); return true end
    t.roundWinners = t.roundWinners or {}
    t.pairIndex = tonumber(t.pairIndex) or 1
    if t.pairIndex > #t.entrants then
      t.entrants = t.roundWinners
      t.roundWinners = {}
      t.pairIndex = 1
      t.round = (tonumber(t.round) or 1) + 1
    else
      local a = t.entrants[t.pairIndex]
      local b = t.entrants[t.pairIndex + 1]
      if not b then
        t.roundWinners[#t.roundWinners + 1] = a
        t.pairIndex = t.pairIndex + 2
      elseif a == PLAYER or b == PLAYER then
        local opp = a == PLAYER and b or a
        t.pendingOpponent = opp
        t.pendingLaunch = true
        return true
      else
        local winner = self:simMatch(a, b, t)
        t.roundWinners[#t.roundWinners + 1] = winner
        t.pairIndex = t.pairIndex + 2
      end
    end
  end
  return true
end

function Tournaments:startPlayer(hostRivalId, count, mode, venueMap)
  mode = mode == "DOUBLE" and "DOUBLE" or "SINGLE"
  if self.active then return false, "A tournament is already running." end
  local available, today = self:playerTournamentAvailableToday()
  if not available then return false, "You already completed today's tournament." end
  local pool = self:eligible(mode)
  local max = math.min(100, #pool)
  if max < 3 then return false, "At least three eligible rivals are required." end
  count = math.max(3, math.min(max, math.floor(tonumber(count) or 3)))
  if mode == "DOUBLE" then
    local party = self.manager.game and self.manager.game.save and self.manager.game.save.party or {}
    local healthy = 0
    for _, mon in ipairs(party) do if (tonumber(mon.hp) or 1) > 0 then healthy = healthy + 1 end end
    if healthy < 2 then return false, "You need at least two healthy Pokemon for doubles." end
  end
  local host, picked = self.manager.byId[hostRivalId], {}
  if not host then return false, "That rival is no longer available." end
  local hostEligible = false
  for i = #pool, 1, -1 do
    if pool[i].id == host.id then
      picked[#picked + 1] = host.id
      table.remove(pool, i)
      hostEligible = true
      break
    end
  end
  if not hostEligible then
    return false, mode == "DOUBLE"
      and (host.name .. " needs at least two healthy Pokemon for a doubles tournament.")
      or (host.name .. " cannot enter a tournament right now.")
  end
  local rng = (host and host.rng) or (#pool > 0 and pool[1].rng)
  pool = shuffle(pool, rng)
  for _, r in ipairs(pool) do
    if #picked >= count then break end
    picked[#picked + 1] = r.id
  end
  if #picked < 3 then return false, "Not enough rivals can enter." end
  for _, id in ipairs(picked) do
    local entrant = self.manager.byId[id]
    if entrant and entrant.heal then pcall(entrant.heal, entrant) end
  end
  picked[#picked + 1] = PLAYER
  picked = shuffle(picked, rng)
  self.serial = self.serial + 1
  self.active = {
    id = self.serial, active = true, playerEntry = true,
    hostRivalId = hostRivalId, mode = mode, round = 1,
    entrants = picked, originalCount = #picked - 1, pairIndex = 1,
    -- The bracket shrinks as rounds resolve, so the full field is kept for the
    -- crowd count: a knocked-out rival standing at the venue is a spectator,
    -- not a stranger who wandered in.
    allEntrants = copyIds(picked),
    venueMap = venueMap, doubleExp = true, startedDay = today,
  }
  -- Reserve the daily event as soon as the bracket is successfully created.
  -- This prevents save/reload or deliberate mid-tournament resets from spawning
  -- unlimited rare-item/2x-EXP events on the same calendar day.
  self:spendInitiation(PLAYER, today)
  self.manager.news[#self.manager.news + 1] = {
    tick = self.manager.sim and self.manager.sim.tick or 0,
    text = participantName(self.manager, hostRivalId) .. " arranged a " .. mode:lower()
      .. " tournament with " .. tostring(#picked - 1) .. " rivals and the player."
  }
  self:advance()
  pcall(function() self.manager:save() end)
  return true, mode .. " tournament arranged here with " .. tostring(#picked - 1) .. " rivals. Battles award 2x EXP."
end

function Tournaments:onPlayerBattleStarted(rivalId)
  local t = self.active
  if not (t and t.active and t.pendingOpponent == rivalId) then return false end
  t.pendingLaunch = false
  t.playerBattleLive = true
  return true
end

function Tournaments:onPlayerBattleResult(rivalId, playerWon)
  local t = self.active
  if not (t and t.active and t.playerBattleLive and t.pendingOpponent == rivalId) then return false end
  local winner = playerWon and PLAYER or rivalId
  local loser = playerWon and rivalId or PLAYER
  self:news("eliminated", loser, winner, t)
  t.roundWinners[#t.roundWinners + 1] = winner
  t.pairIndex = t.pairIndex + 2
  t.pendingOpponent = nil
  t.playerBattleLive = false
  t.pendingLaunch = false
  if not playerWon then
    -- The bracket continues without the player; resolve the rest immediately.
    self:advance()
    while self.active and self.active.active and not self.active.pendingOpponent do self:advance() end
  else
    self:advance()
  end
  pcall(function() self.manager:save() end)
  return true
end

function Tournaments:updatePending()
  local t = self.active
  if not (t and t.active and t.playerEntry and t.pendingLaunch and t.pendingOpponent) then return false end
  if self.manager.rivalBattleSequenceActive or self.manager.pendingRivalBattleLaunch then return false end
  local rival = self.manager.byId[t.pendingOpponent]
  if not rival then
    t.roundWinners[#t.roundWinners + 1] = PLAYER
    t.pairIndex = t.pairIndex + 2
    t.pendingOpponent, t.pendingLaunch = nil, false
    return self:advance()
  end
  local ok, why = self.manager:startRivalChallenge(rival, t.mode, true)
  if ok then
    self:onPlayerBattleStarted(rival.id)
    self.manager.ticker = { text = "TOURNAMENT  •  VS " .. tostring(rival.name), age = 0,
      duration = 7, offset = 0 }
  else
    self.manager.ticker = { text = "TOURNAMENT  •  " .. tostring(why), age = 0,
      duration = 7, offset = 0 }
  end
  return ok
end

function Tournaments:runAutonomous(count, mode)
  if self.active then return false end
  mode = mode == "DOUBLE" and "DOUBLE" or "SINGLE"
  local pool = self:eligible(mode)
  if #pool < 2 then return false end
  count = math.max(2, math.min(#pool, math.min(100, math.floor(tonumber(count) or math.min(8, #pool)))))
  local rng = pool[1].rng
  pool = shuffle(pool, rng)
  local entrants = {}
  for i = 1, count do entrants[#entrants + 1] = pool[i].id end
  local t = { mode = mode, entrants = entrants, round = 1, playerEntry = false,
              active = true, pairIndex = 1, roundWinners = {} }
  -- Resolve the whole event now. This is intentionally headless: it is part of
  -- the rival world simulation and never steals the player's screen.
  while #t.entrants > 1 do
    local winners = {}
    for i = 1, #t.entrants, 2 do
      local a, b = t.entrants[i], t.entrants[i + 1]
      winners[#winners + 1] = b and self:simMatch(a, b, t) or a
    end
    t.entrants = winners
    t.round = t.round + 1
  end
  self:news("won", t.entrants[1], nil, t)
  return true
end

function Tournaments:maybeAutonomous(tick)
  tick = tonumber(tick) or 0
  if self.active or tick < (tonumber(self.nextAutonomousTick) or 0) then return false end
  local rivals = self.manager.rivals or {}
  if #rivals < 2 then return false end
  local rng = rivals[1] and rivals[1].rng
  self.nextAutonomousTick = tick + ((rng and rng.int and rng:int(420, 900)) or 600)
  if rng and rng.chance and not rng:chance(0.28) then return false end
  local mode = "SINGLE"
  if #self:eligible("DOUBLE") >= 2 and rng and rng.chance and rng:chance(0.30) then mode = "DOUBLE" end
  local max = math.min(16, #self:eligible(mode))
  if max < 2 then return false end
  local count = rng and rng.int and rng:int(2, max) or math.min(4, max)
  return self:runAutonomous(count, mode)
end

return Tournaments
