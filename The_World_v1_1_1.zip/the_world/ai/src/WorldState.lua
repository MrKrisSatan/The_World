local req, mod = ...
local Util = req("src/Util")

-- 5.6.0: the first shared world-state layer.  This does not replace Rocket,
-- Rangers or Ecology.  It is the ledger that lets those systems leave a
-- persistent footprint that other systems can read.
local WorldState = {}
WorldState.__index = WorldState

local MAX_ROUTES = 96
local MAX_EVENTS = 80

local function clamp(n, lo, hi)
  n = tonumber(n) or 0
  if n < lo then return lo end
  if n > hi then return hi end
  return n
end

local function pretty(id)
  return tostring(id or "Unknown"):gsub("_", " "):lower():gsub("(%a)([%w']*)", function(a,b)
    return a:upper() .. b
  end)
end

function WorldState.new(manager, saved)
  local self = setmetatable({
    manager = manager,
    tick = 0,
    routes = {},
    events = {},
    version = 1,
    lastSnapshot = -9999,
    seenRocket = {},
    seenRanger = {},
  }, WorldState)
  if type(saved) == "table" then self:load(saved) end
  return self
end

function WorldState:route(mapId)
  if not mapId then return nil end
  local row = self.routes[mapId]
  if not row then
    row = {
      map = mapId,
      rocket = 0,
      ranger = 0,
      disturbance = 0,
      protection = 0,
      reputation = "CALM",
      lastEventTick = 0,
    }
    self.routes[mapId] = row
  end
  return row
end

function WorldState:addEvent(kind, mapId, text, meta)
  if not text then return false end
  self.events[#self.events + 1] = {
    id = tostring(self.tick) .. ":" .. tostring(#self.events + 1),
    tick = self.tick,
    kind = kind or "world",
    map = mapId,
    text = tostring(text),
    meta = Util.copy(meta or {}),
  }
  while #self.events > MAX_EVENTS do table.remove(self.events, 1) end
  return true
end

function WorldState:reputation(row)
  local danger = (tonumber(row.rocket) or 0) * 2
    + (tonumber(row.disturbance) or 0)
    - (tonumber(row.ranger) or 0) * 2
    - (tonumber(row.protection) or 0)
  if danger >= 18 then return "DANGEROUS" end
  if danger >= 9 then return "DISTURBED" end
  if danger <= -8 then return "PROTECTED" end
  if danger <= -3 then return "PATROLLED" end
  return "CALM"
end

function WorldState:observe(world)
  self.tick = tonumber(world and world.tick) or tonumber(self.manager and self.manager.tick) or self.tick + 1
  if self.tick - self.lastSnapshot < 5 then return false end
  self.lastSnapshot = self.tick

  local rocket = self.manager and self.manager.rocket
  local rangers = self.manager and self.manager.rangers
  local ecology = self.manager and self.manager.ecologyFor and self.manager:ecologyFor()

  local rocketMaps = {}
  for _, member in ipairs(rocket and rocket.members or {}) do
    if member.active and member.map and not member.defeatedUntil then
      local row = self:route(member.map)
      row.rocket = math.min(12, (row.rocket or 0) + 0.20)
      row.disturbance = math.min(20, (row.disturbance or 0) + 0.10)
      row.lastEventTick = self.tick
      rocketMaps[member.map] = (rocketMaps[member.map] or 0) + 1
    end
  end

  for _, ranger in ipairs(rangers and rangers.members or {}) do
    if ranger.active and ranger.map then
      local row = self:route(ranger.map)
      row.ranger = math.min(12, (row.ranger or 0) + 0.18)
      row.protection = math.min(20, (row.protection or 0) + 0.10)
      row.lastEventTick = self.tick
      -- 5.7.0: a patrol is ecological work, not just a reputation number.
      -- Recovery is performed by Ecology itself so no outside system writes
      -- its pressure table directly.
      if ecology and ecology.recover then
        ecology:recover(ranger.map, 0.55, self.tick)
      end
    end
  end

  for mapId, row in pairs(self.routes) do
    row.rocket = math.max(0, (row.rocket or 0) * 0.992)
    row.ranger = math.max(0, (row.ranger or 0) * 0.994)
    row.disturbance = math.max(0, (row.disturbance or 0) * 0.997)
    row.protection = math.max(0, (row.protection or 0) * 0.997)
    row.reputation = self:reputation(row)
    if row.rocket < 0.02 and row.ranger < 0.02 and row.disturbance < 0.02 and row.protection < 0.02 then
      self.routes[mapId] = nil
    end
  end

  -- Convert newly observed Rocket/Ranger incidents into a compact world
  -- chronicle. Incident IDs are save-local and therefore deterministic.
  for _, incident in ipairs(rocket and rocket.incidents or {}) do
    local id = tostring(incident.tick) .. ":" .. tostring(incident.memberId or "") .. ":" .. tostring(incident.kind or "")
    if not self.seenRocket[id] then
      self.seenRocket[id] = true
      if incident.map then
        self:addEvent("ROCKET", incident.map,
          "Team Rocket activity changed the situation in " .. pretty(incident.map) .. ".",
          { operation = incident.operation, species = incident.species })
      end
    end
  end

  for _, incident in ipairs(rangers and rangers.news or {}) do
    local meta = incident.meta or {}
    local id = tostring(incident.tick) .. ":" .. tostring(meta.missionId or "") .. ":" .. tostring(incident.text or "")
    if not self.seenRanger[id] then
      self.seenRanger[id] = true
      self:addEvent("RANGER", meta.location, incident.text, meta)
    end
  end

  -- Touch Ecology here so the world-state layer is aware that ecological
  -- pressure exists, without duplicating or owning the population equation.
  if ecology and ecology.maps then
    for mapId in pairs(ecology.maps) do
      local row = self:route(mapId)
      row.disturbance = math.min(20, (row.disturbance or 0) + 0.05)
    end
  end

  -- Bound route state to the most consequential locations.
  local rows = {}
  for mapId, row in pairs(self.routes) do
    rows[#rows + 1] = { map = mapId, score = (row.rocket or 0) + (row.disturbance or 0) + (row.ranger or 0) }
  end
  if #rows > MAX_ROUTES then
    table.sort(rows, function(a,b) return a.score < b.score end)
    for i = 1, #rows - MAX_ROUTES do self.routes[rows[i].map] = nil end
  end
  return true
end

function WorldState:routeEcology(mapId)
  local row = self.routes[mapId]
  if not row then
    return { rocket=0, ranger=0, disturbance=0, protection=0, reputation="CALM" }
  end
  return {
    rocket = tonumber(row.rocket) or 0,
    ranger = tonumber(row.ranger) or 0,
    disturbance = tonumber(row.disturbance) or 0,
    protection = tonumber(row.protection) or 0,
    reputation = row.reputation or "CALM",
  }
end

function WorldState:routePressure(mapId)
  local row = self.routes[mapId]
  if not row then return 0 end
  return clamp((row.rocket or 0) * 0.5 + (row.disturbance or 0) * 0.35 - (row.ranger or 0) * 0.2, -10, 20)
end

function WorldState:routeStatus(mapId)
  local row = self.routes[mapId]
  return row and row.reputation or "CALM"
end

function WorldState:serialize()
  return { version = 1, tick = self.tick, routes = Util.copy(self.routes), events = Util.copy(self.events) }
end

function WorldState:load(saved)
  if type(saved) ~= "table" then return end
  self.tick = tonumber(saved.tick) or 0
  self.routes = type(saved.routes) == "table" and Util.copy(saved.routes) or {}
  self.events = type(saved.events) == "table" and Util.copy(saved.events) or {}
  while #self.events > MAX_EVENTS do table.remove(self.events, 1) end
end

return WorldState
