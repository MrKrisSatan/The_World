local req, mod = ...
local Util = req("src/Util")
local Backgrounds = {}

-- Hidden social DNA for rivals and Team Rocket.  The records themselves live
-- in data/backgrounds.lua so this module contains only selection and policy.
local RECORDS = req("data/backgrounds")
local BY_ID = {}
for _, row in ipairs(RECORDS or {}) do
  if type(row) == "table" and type(row.id) == "string" then
    BY_ID[row.id] = row
  end
end

local function hash(seed, key)
  local h = 2166136261
  local s = tostring(seed or 1) .. "|" .. tostring(key or "")
  for i = 1, #s do
    h = (h + s:byte(i) * 16777619) % 4294967296
    h = (h * 31 + 7) % 4294967296
  end
  return h
end

local function copy(row)
  return row and Util.copy(row) or nil
end

function Backgrounds.get(id)
  return BY_ID[id]
end

function Backgrounds.forId(seed, key)
  local count = #RECORDS
  if count == 0 then return nil end
  local index = (hash(seed, key) % count) + 1
  return RECORDS[index]
end

function Backgrounds.forSpecial(def, seed)
  if not def then return Backgrounds.forId(seed, "rival") end
  if def.backgroundId and BY_ID[def.backgroundId] then
    return BY_ID[def.backgroundId]
  end
  if def.rareSpecial then
    return Backgrounds.forId(seed, "special:" .. tostring(def.id))
  end
  return Backgrounds.forId(seed, "rival:" .. tostring(def.id))
end

function Backgrounds.startingInventory(background)
  local out = {}
  if type(background) ~= "table" or type(background.items) ~= "table" then return out end
  for item, amount in pairs(background.items) do
    amount = math.floor(tonumber(amount) or 0)
    if amount > 0 then out[item] = amount end
  end
  return out
end

function Backgrounds.disposition(background, subject)
  if type(background) ~= "table" then return 0 end
  local d = background.disposition
  if type(d) ~= "table" then return 0 end
  local value = tonumber(d[subject])
  if value == nil and subject == "rivals" then value = tonumber(d.rival) end
  return math.max(-1, math.min(1, value or 0))
end

local function bias(background, field)
  local b = background and background[field]
  if type(b) ~= "table" then return {} end
  return b
end

function Backgrounds.pathBias(background)
  return bias(background, "pathBias")
end

function Backgrounds.careerBias(background)
  return bias(background, "careerBias")
end

-- Personality remains the primary authored personality. Background values are
-- deliberately tiny nudges and only affect numeric personality fields that
-- already exist on the authored record. No hidden background can replace a
-- named personality or its priority/team-plan identity.
function Backgrounds.applyPersonality(personality, background)
  if type(personality) ~= "table" then return personality end
  local out = copy(personality) or {}
  local b = bias(background, "personalityBias")
  for key, delta in pairs(b) do
    if type(out[key]) == "number" and type(delta) == "number" then
      out[key] = math.max(0, math.min(1.5, out[key] + delta))
    end
  end
  return out
end

Backgrounds.count = #RECORDS
Backgrounds.records = RECORDS
Backgrounds.byId = BY_ID

return Backgrounds
