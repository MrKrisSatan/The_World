local H={}

H.MIN=0
H.MAX=100
H.DEFAULT=60
H.MEMORY_LIMIT=16

local MOODS={
  ecstatic={min=90,label="ECSTATIC"},
  happy={min=75,label="HAPPY"},
  content={min=55,label="CONTENT"},
  frustrated={min=40,label="FRUSTRATED"},
  unhappy={min=25,label="UNHAPPY"},
  miserable={min=10,label="MISERABLE"},
  broken={min=0,label="BROKEN_SPIRIT"},
}

local function clamp(v,a,b) return math.max(a,math.min(b,v)) end

local function personalityBaseline(rival)
  local p=rival and rival.personality or {}
  local id=tostring(rival and (rival.personalityId or p.id or p.label) or ""):upper()
  local base=H.DEFAULT
  if id:find("OPTIM",1,true) or id:find("CHEER",1,true) then base=68 end
  if id:find("GLOOM",1,true) or id:find("CYNIC",1,true) then base=48 end
  if id:find("CRUSADER",1,true) then base=62 end
  return clamp(base,35,75)
end

function H.ensure(rival)
  rival.happiness=clamp(tonumber(rival.happiness) or personalityBaseline(rival),H.MIN,H.MAX)
  rival.happinessBaseline=clamp(tonumber(rival.happinessBaseline) or personalityBaseline(rival),35,75)
  rival.mood=rival.mood or "CONTENT"
  rival.emotionalMemories=type(rival.emotionalMemories)=="table" and rival.emotionalMemories or {}
  rival.pokemonAttachment=type(rival.pokemonAttachment)=="table" and rival.pokemonAttachment or {}
  rival.winStreak=math.max(0,tonumber(rival.winStreak) or 0)
  rival.lossStreak=math.max(0,tonumber(rival.lossStreak) or 0)
  rival.faintHistory=type(rival.faintHistory)=="table" and rival.faintHistory or {}
  rival.breakingPoints=type(rival.breakingPoints)=="table" and rival.breakingPoints or {}
  return rival
end

function H.moodFor(value)
  value=tonumber(value) or H.DEFAULT
  if value>=90 then return "ECSTATIC"
  elseif value>=75 then return "HAPPY"
  elseif value>=55 then return "CONTENT"
  elseif value>=40 then return "FRUSTRATED"
  elseif value>=25 then return "UNHAPPY"
  elseif value>=10 then return "MISERABLE"
  end
  return "BROKEN_SPIRIT"
end

function H.addMemory(rival,kind,text,delta,major,tick,meta)
  H.ensure(rival)
  local m={
    kind=kind or "EVENT",text=tostring(text or kind or "event"),
    delta=tonumber(delta) or 0,major=major==true,tick=tonumber(tick) or rival.ticks or 0,
    meta=meta,
  }
  table.insert(rival.emotionalMemories,1,m)
  while #rival.emotionalMemories>H.MEMORY_LIMIT do table.remove(rival.emotionalMemories) end
  return m
end

local function chooseBreakingPoint(rival,cause)
  if (rival.happiness or 50)>20 then return nil end
  local id=tostring(rival.personalityId or (rival.personality and rival.personality.id) or ""):upper()
  local roll=(rival.rng and rival.rng.int and rival.rng:int(1,100)) or 50
  if id=="CRUSADER" then
    return cause=="POKEMON_STOLEN" and "VENGEFUL" or "SECOND_WIND"
  end
  if cause=="POKEMON_STOLEN" and roll<=45 then return "VENGEFUL" end
  if rival.rocketAffiliation then return "DARK_TURN" end
  if roll<=20 then return "BROKEN_DREAM"
  elseif roll<=40 then return "TEMPTED"
  elseif roll<=60 then return "RANGER_CALLING"
  elseif roll<=80 then return "SECOND_WIND"
  end
  return "WITHDRAWN"
end

function H.triggerBreakingPoint(rival,cause)
  H.ensure(rival)
  if (rival.happiness or 50)>20 then return nil end
  local last=rival.lastBreakingPointTick or -9999
  local now=tonumber(rival.ticks) or 0
  if now-last<80 then return nil end
  local bp=chooseBreakingPoint(rival,cause)
  if not bp then return nil end
  rival.lastBreakingPointTick=now
  rival.breakingPoints[#rival.breakingPoints+1]={kind=bp,cause=cause,tick=now}
  rival.emotionalTrait=bp

  if bp=="VENGEFUL" then
    rival.objective="ROCKET_HUNT"
    rival:setState("EXPLORING","hunting Team Rocket after a personal loss")
  elseif bp=="BROKEN_DREAM" then
    rival.objective="RECOVER"
    rival:setState("IDLE","questioning the Gym Challenge")
  elseif bp=="TEMPTED" then
    rival.rocketTempted=true
  elseif bp=="RANGER_CALLING" then
    rival.rangerCalling=true
  elseif bp=="SECOND_WIND" then
    rival.catchUpMode=true
    rival:setState("TRAINING","determined to turn things around")
  elseif bp=="DARK_TURN" then
    rival.darkTurn=true
  elseif bp=="WITHDRAWN" then
    rival:setState("IDLE","taking time away from battling")
  end
  H.addMemory(rival,"BREAKING_POINT","A major experience changed their outlook.",0,true,now,{breakingPoint=bp,cause=cause})
  return bp
end

function H.adjust(rival,delta,reason,opts)
  H.ensure(rival)
  opts=opts or {}
  local before=rival.happiness
  rival.happiness=clamp(before+(tonumber(delta) or 0),H.MIN,H.MAX)
  rival.mood=opts.mood or H.moodFor(rival.happiness)
  if reason then H.addMemory(rival,opts.kind or "MOOD",reason,delta,opts.major,rival.ticks,opts.meta) end
  local crossed=(before>20 and rival.happiness<=20)
  if opts.major or crossed then
    local bp=H.triggerBreakingPoint(rival,opts.cause or opts.kind)
    return rival.happiness,bp
  end
  return rival.happiness,nil
end

function H.attachment(rival,slot)
  H.ensure(rival)
  if type(slot)~="table" then return 0 end
  local key=tostring(slot.uid or slot.id or slot.species or "pokemon")
  local v=tonumber(rival.pokemonAttachment[key])
  if not v then
    v=slot.starter and 55 or 8
    if slot.ace then v=math.max(v,45) end
    rival.pokemonAttachment[key]=v
  end
  return v,key
end

function H.addAttachment(rival,slot,delta)
  local v,key=H.attachment(rival,slot)
  rival.pokemonAttachment[key]=clamp(v+(tonumber(delta) or 0),0,100)
  return rival.pokemonAttachment[key]
end

function H.noteCatch(rival,species,slot,rare)
  local bonus=rare and 6 or 2
  if rival.huntTarget==species then bonus=bonus+3 end
  H.addAttachment(rival,slot,6)
  return H.adjust(rival,bonus,"Caught "..tostring(species)..".",{kind="CATCH",mood="HAPPY",meta={species=species}})
end

function H.noteEvolution(rival,from,to,slot)
  H.addAttachment(rival,slot,8)
  return H.adjust(rival,3,tostring(from).." evolved into "..tostring(to)..".",{kind="EVOLUTION",mood="HAPPY",meta={from=from,to=to}})
end

function H.noteGym(rival,won,badge,leader)
  if won then
    rival.winStreak=(rival.winStreak or 0)+1; rival.lossStreak=0
    return H.adjust(rival,10,"Earned the "..tostring(badge).." Badge.",{kind="GYM_WIN",major=true,mood="ECSTATIC",meta={badge=badge,leader=leader}})
  end
  rival.lossStreak=(rival.lossStreak or 0)+1; rival.winStreak=0
  local penalty=-7-math.min(5,math.max(0,rival.lossStreak-1)*2)
  return H.adjust(rival,penalty,"Lost a Gym battle to "..tostring(leader)..".",{kind="GYM_LOSS",major=rival.lossStreak>=3,mood="FRUSTRATED",cause="GYM_FAILURE"})
end

function H.noteTrainerBattle(rival,won,trainerName)
  if won then
    rival.winStreak=(rival.winStreak or 0)+1; rival.lossStreak=0
    local bonus=(rival.winStreak>=3) and 3 or 2
    return H.adjust(rival,bonus,"Defeated "..tostring(trainerName or "a trainer")..".",{kind="TRAINER_WIN",mood="HAPPY"})
  end
  rival.lossStreak=(rival.lossStreak or 0)+1; rival.winStreak=0
  local penalty=-3-math.min(4,math.max(0,rival.lossStreak-1))
  return H.adjust(rival,penalty,"Lost to "..tostring(trainerName or "a trainer")..".",{kind="TRAINER_LOSS",mood="FRUSTRATED",major=rival.lossStreak>=4,cause="LOSING_STREAK"})
end

function H.noteRivalBattle(rival,won,other)
  if won then
    rival.winStreak=(rival.winStreak or 0)+1; rival.lossStreak=0
    return H.adjust(rival,4,"Defeated rival "..tostring(other or "")..".",{kind="RIVAL_WIN",mood="HAPPY"})
  end
  rival.lossStreak=(rival.lossStreak or 0)+1; rival.winStreak=0
  return H.adjust(rival,-5,"Lost to rival "..tostring(other or "")..".",{kind="RIVAL_LOSS",mood="FRUSTRATED",major=rival.lossStreak>=4,cause="LOSING_STREAK"})
end

function H.noteFaints(rival)
  H.ensure(rival)
  local totalPenalty=0
  for _,slot in ipairs(rival.party or {}) do
    if (tonumber(slot.hp) or 0)<=0 then
      local _,key=H.attachment(rival,slot)
      local count=(tonumber(rival.faintHistory[key]) or 0)+1
      rival.faintHistory[key]=count
      local penalty=count>=5 and 4 or (count>=3 and 2 or 1)
      totalPenalty=totalPenalty+penalty
      H.addAttachment(rival,slot,-penalty)
    end
  end
  if totalPenalty>0 then
    H.adjust(rival,-totalPenalty,"Their Pokemon have been fainting too often.",{
      kind="FAINTING",mood="FRUSTRATED",major=totalPenalty>=6,cause="FAINTING_STREAK"})
  end
  return totalPenalty
end

function H.noteStolen(rival,slot,species,memberName)
  local attachment=H.attachment(rival,slot)
  local penalty=-15
  if attachment>=70 then penalty=-30 elseif attachment>=45 then penalty=-22 end
  if slot and slot.ace then penalty=penalty-5 end
  return H.adjust(rival,penalty,
    "Team Rocket stole "..tostring(species).." from them.",{
      kind="POKEMON_STOLEN",major=true,mood="ANGRY",cause="POKEMON_STOLEN",
      meta={species=species,rocket=memberName,attachment=attachment}})
end

function H.noteRecovered(rival,species)
  return H.adjust(rival,10,"Recovered "..tostring(species).." from Team Rocket.",{
    kind="POKEMON_RECOVERED",major=true,mood="HOPEFUL",meta={species=species}})
end

function H.noteTrade(rival,species)
  return H.adjust(rival,2,"Completed a Pokemon trade involving "..tostring(species)..".",{kind="TRADE",mood="HAPPY"})
end

function H.noteChampion(rival)
  return H.adjust(rival,20,"Became Pokemon League Champion.",{kind="CHAMPION",major=true,mood="ECSTATIC"})
end

function H.tick(rival)
  H.ensure(rival)
  rival.happinessTick=(tonumber(rival.happinessTick) or 0)+1
  if rival.happinessTick%120~=0 then return end
  local base=rival.happinessBaseline or H.DEFAULT
  if rival.happiness<base then rival.happiness=math.min(base,rival.happiness+1)
  elseif rival.happiness>base+18 then rival.happiness=rival.happiness-1 end
  rival.mood=H.moodFor(rival.happiness)

  -- Low happiness changes priorities, not progression rules.
  if rival.happiness<=20 then
    rival.slump=true
    rival.catchUpMode=false
  elseif rival.happiness>=35 then
    rival.slump=false
  end
end

function H.rocketRecruitMultiplier(rival)
  H.ensure(rival)
  if rival.personalityId=="CRUSADER" or (rival.personality and rival.personality.incorruptibleRocket) then return 0 end
  if rival.happiness<=10 then return 2.4
  elseif rival.happiness<=20 then return 2.0
  elseif rival.happiness<=35 then return 1.55
  elseif rival.happiness>=75 then return 0.55
  elseif rival.happiness>=90 then return 0.30
  end
  return 1
end

function H.rangerRecruitMultiplier(rival)
  H.ensure(rival)
  if rival.rangerCalling then return 2.5 end
  if rival.happiness<=20 then return 1.4 end
  if rival.happiness>=75 then return 1.15 end
  return 1
end

function H.save(rival)
  H.ensure(rival)
  -- Serializer-safe snapshot only. Never return the live memory/attachment
  -- tables because event metadata can contain engine objects/functions.
  local memories={}
  for i=1,math.min(8,#(rival.emotionalMemories or {})) do
    local m=rival.emotionalMemories[i]
    if type(m)=="table" then
      memories[#memories+1]={
        kind=tostring(m.kind or "EVENT"),
        text=tostring(m.text or ""),
        delta=tonumber(m.delta) or 0,
        major=m.major==true,
        tick=tonumber(m.tick) or 0,
      }
    end
  end
  local attachment={}
  for k,v in pairs(rival.pokemonAttachment or {}) do
    if type(k)=="string" or type(k)=="number" then
      attachment[tostring(k)]=clamp(tonumber(v) or 0,0,100)
    end
  end
  return {
    happiness=tonumber(rival.happiness) or H.DEFAULT,
    happinessBaseline=tonumber(rival.happinessBaseline) or H.DEFAULT,
    mood=tostring(rival.mood or "CONTENT"),
    emotionalMemories=memories,pokemonAttachment=attachment,
    winStreak=tonumber(rival.winStreak) or 0,lossStreak=tonumber(rival.lossStreak) or 0,
    emotionalTrait=type(rival.emotionalTrait)=="string" and rival.emotionalTrait or nil,
    rocketTempted=rival.rocketTempted==true,rangerCalling=rival.rangerCalling==true,
    darkTurn=rival.darkTurn==true,slump=rival.slump==true,
  }
end

function H.restore(rival,s)
  if type(s)=="table" then
    for k,v in pairs(s) do rival[k]=v end
  end
  H.ensure(rival)
end

return H
