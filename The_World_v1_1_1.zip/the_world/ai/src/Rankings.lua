local req, mod = ...
local League = req("src/League")

-- TRAINER RANKINGS (4.6.0).
--
-- One table, every trainer in the save, the player among them:
--
--   1. GREEN      8 Badges
--   2. Player     7 Badges
--   3. YELLOW     6 Badges
--
-- THE PLAYER IS A ROW, NOT A FOOTNOTE.
--
-- The existing STANDINGS screen listed the rivals and then mentioned the
-- player separately when they held the title, so the one question the screen
-- exists to answer -- am I winning? -- could not be read off it. Here the
-- player is ranked by the same comparison as everyone else and simply carries
-- a flag so the UI can mark the row.
--
-- Ordering is League.sortStandings, which already resolves badges, then League
-- clears, then best stage, then collection, then id. This module adds the
-- player row, the champion resolution and the numbering, and it is pure: the
-- same world produces the same table every time it is opened, so the ranking
-- never reshuffles under the cursor.

local Rankings = {}

Rankings.MAX_ROWS = 120

local function isTable(v) return type(v) == "table" end

local function call(obj, name, ...)
  if not (isTable(obj) and type(obj[name]) == "function") then return nil end
  local ok, value = pcall(obj[name], obj, ...)
  if ok then return value end
  return nil
end

-- The player's row, built from the same shape League.standing returns for a
-- rival so the sort has one kind of thing to compare.
function Rankings.playerRow(facts)
  facts = isTable(facts) and facts or {}
  return {
    id = "__player",
    name = facts.name or "Player",
    player = true,
    badges = math.max(0, math.floor(tonumber(facts.badges) or 0)),
    caught = math.max(0, math.floor(tonumber(facts.caught) or 0)),
    attempts = math.max(0, math.floor(tonumber(facts.attempts) or 0)),
    best = math.max(0, math.floor(tonumber(facts.best) or 0)),
    clears = math.max(0, math.floor(tonumber(facts.clears) or 0)),
    champion = facts.champion == true,
    qualified = facts.qualified == true,
  }
end

-- rivals: live Rival objects. player: the fact table above (optional -- a
-- boot with no save yet has no player row, and inventing one with zero badges
-- would place a player who has not started ABOVE nobody and below everybody,
-- which is a claim rather than an absence).
function Rankings.build(rivals, player)
  local rows = {}
  for _, rival in ipairs(isTable(rivals) and rivals or {}) do
    if isTable(rival) and rival.id then
      local record = call(rival, "ensureLeague")
      local row = League.standing(rival, record, rival.champion == true)
      row.player = false
      rows[#rows + 1] = row
    end
  end
  if isTable(player) then rows[#rows + 1] = Rankings.playerRow(player) end
  League.sortStandings(rows)
  while #rows > Rankings.MAX_ROWS do table.remove(rows) end
  for i, row in ipairs(rows) do row.rank = i end
  return rows
end

-- Who holds the title, if anybody. Returns the row, so the caller can draw
-- the CHAMPION banner without a second search -- and nil when the title is
-- vacant, which is a real state: the Elite Four have not been beaten yet.
function Rankings.champion(rows)
  for _, row in ipairs(isTable(rows) and rows or {}) do
    if row.champion then return row end
  end
  return nil
end

-- "8 Badges" / "1 Badge". The right-hand column of the ranking, and the
-- champion's row says CHAMPION instead, because that is the fact that matters
-- about them.
function Rankings.badgeLabel(row)
  if not isTable(row) then return "" end
  local n = math.max(0, math.floor(tonumber(row.badges) or 0))
  return n .. " Badge" .. (n == 1 and "" or "s")
end

function Rankings.statusLabel(row)
  if not isTable(row) then return "" end
  if row.champion then return "CHAMPION" end
  return Rankings.badgeLabel(row)
end

-- The display rows, already numbered and fitted, in the order the screen
-- draws them. Names are trimmed here rather than in the screen so the same
-- table can be asserted headlessly.
function Rankings.display(rows, width)
  width = tonumber(width) or 10
  local out = {}
  for _, row in ipairs(isTable(rows) and rows or {}) do
    out[#out + 1] = {
      rank = row.rank,
      id = row.id,
      player = row.player == true,
      label = tostring(row.rank) .. ". " .. tostring(row.name):sub(1, width),
      right = Rankings.statusLabel(row),
    }
  end
  return out
end

return Rankings
