-- 6.4.0: interprets player actions through faction eyes and feeds those
-- actions into the existing rival memory system. No quest is generated here.
local req, mod = ...
local D={}; D.__index=D
function D.new(manager) return setmetatable({manager=manager,history={}},D) end
function D:record(action,ctx)
  ctx=ctx or {}; local m=self.manager; local f=m and m.factions; if not f then return end
  action=tostring(action or "UNKNOWN")
  if action=="ROCKET_THEFT" then
    f:adjust("rocket",3,action); f:adjustTrust("rocket",4,action)
    f:adjust("rangers",-4,action); f:adjustSuspicion("rangers",10,8,action)
    f:adjust("communities",-3,action); f:adjustSuspicion("communities",7,5,action)
  elseif action=="ROCKET_JOB_ACCEPTED" then
    f:adjust("rocket",2,action); f:adjustTrust("rocket",5,action); f:adjustSuspicion("rangers",5,2,action)
  elseif action=="ROCKET_JOB_COMPLETED" then
    f:adjust("rocket",5,action); f:adjustTrust("rocket",8,action); f:adjustSuspicion("rangers",8,5,action)
  elseif action=="ROCKET_PURCHASE" then
    f:adjustTrust("rocket",1,action); f:adjustSuspicion("rangers",1,0,action)
  elseif action=="RANGER_JOB_ACCEPTED" then
    f:adjustTrust("rangers",3,action); f:adjustSuspicion("rocket",4,2,action)
  elseif action=="RANGER_JOB_COMPLETED" then
    f:adjust("rangers",5,action); f:adjustTrust("rangers",7,action); f:adjust("rocket",-3,action); f:adjustSuspicion("rocket",10,7,action)
  elseif action=="BEAT_ROCKET" then
    f:adjustSuspicion("rocket",7,4,action); f:adjustTrust("rangers",2,action)
  elseif action=="LOST_TO_ROCKET" then
    f:adjustSuspicion("rocket",-2,0,action)
  elseif action=="REMOVE_UNIFORM" then
    f:adjustSuspicion("rocket",-1,0,action)
  end
  local row={tick=(m.sim and m.sim.tick) or 0,type=action,location=ctx.map,target=ctx.target}
  self.history[#self.history+1]=row; while #self.history>60 do table.remove(self.history,1) end
  for _,r in ipairs(m.rivals or {}) do
    if r and r.rememberEvent then pcall(function() r:rememberEvent(row) end) end
  end
  pcall(function() m:save() end)
end
return D
