-- Compatibility repairs for released Kanto Reforged builds.
-- AI Rivals loads later and wraps the live engine method at game.ready;
-- Kanto Reforged's files are never edited.

local req, mod = ...
local KantoCompat = { installed = false }
local unpackAny = unpack or table.unpack

-- Kanto Reforged 1.2.0's custom party icon renderer uses the pre-refactor
-- module name. Current desktop and Android builds expose the same API from
-- src.render.Assets. Supply the old name lazily so opening the party picker
-- for medicine cannot fail, without changing Kanto Reforged itself.
function KantoCompat.installAssetAlias(loaded, preload, requireFn)
  loaded = loaded or (package and package.loaded)
  preload = preload or (package and package.preload)
  requireFn = requireFn or require
  if type(loaded) ~= "table" or type(preload) ~= "table" then return false end
  if loaded["src.core.Assets"] or preload["src.core.Assets"] then return true end
  preload["src.core.Assets"] = function()
    return requireFn("src.render.Assets")
  end
  return true
end
-- Kanto Reforged's icon patch can reach an obsolete Assets import when a mod
-- supplies a per-species icon. Intercept only that custom-image branch and
-- render it with the current engine Assets module; built-in icons still pass
-- through the existing renderer unchanged.
function KantoCompat.installPartyIconGuard()
  local okP, PartyMenu = pcall(require, "src.ui.PartyMenu")
  local okS, Sprites = pcall(require, "src.pokemon.Sprites")
  local okA, Assets = pcall(require, "src.render.Assets")
  if not (okP and okS and okA and type(PartyMenu) == "table"
      and type(PartyMenu.drawIcon) == "function"
      and type(Sprites.iconPath) == "function"
      and type(Assets.resolve) == "function") then return false end
  if PartyMenu._aiRivalsKantoIconGuard then return true end

  local original = PartyMenu.drawIcon
  local cache = {}
  PartyMenu.drawIcon = function(game, mon, x, y, selected, counter, forceAlt)
    local icons = game and game.data and game.data.icons
    local def = game and game.data and game.data.pokemon and mon
        and game.data.pokemon[mon.species]
    if not (icons and mon and mon.species) then
      return original(game, mon, x, y, selected, counter, forceAlt)
    end
    local entry = (icons.bySpecies and icons.bySpecies[mon.species])
               or (def and def.icon)
    local name, path
    if type(entry) == "string" then
      name, path = entry, icons.icons and icons.icons[entry]
      if type(path) == "table" then path = path.image end
    elseif type(entry) == "table" then
      path = entry.image
    end
    if not path then
      name = def and def.dex and icons.byDex and icons.byDex[def.dex]
      path = name and icons.icons and icons.icons[name]
      if type(path) == "table" then path = path.image end
    end
    local resolved = Sprites.iconPath(game.data, mon, path, { name = name })
    local builtIn = name and icons.icons and resolved == icons.icons[name]
    if not resolved or builtIn then
      return original(game, mon, x, y, selected, counter, forceAlt)
    end

    if cache[resolved] == nil then
      local ok, img = pcall(love.graphics.newImage, Assets.resolve(resolved))
      cache[resolved] = ok and img or false
    end
    local img = cache[resolved]
    if not img then return end
    local alt = forceAlt or false
    if selected then
      local hp = tonumber(mon.hp) or 0
      local maxHp = math.max(1, tonumber(mon.stats and mon.stats.hp) or 1)
      local px = math.floor(hp * 48 / maxHp)
      local speed = px >= 27 and 5 or px >= 10 and 16 or 32
      alt = math.floor((counter or 0) / speed) % 2 == 1
    end
    local iw, ih = img:getDimensions()
    local frame = ih > 16 and (alt and ((ih >= 64 and 3) or 1) or 0) or 0
    if ih > 16 then
      love.graphics.draw(img,
        love.graphics.newQuad(0, frame * 16, 16, 16, iw, ih), x, y)
    else
      love.graphics.draw(img, x, y)
    end
    return true
  end
  PartyMenu._aiRivalsKantoIconGuard = true
  return true
end
local function isPlayerPartyMon(battle, target)
  if type(target) ~= "table" or type(target.isPlayer) == "boolean" then
    return false
  end
  if battle and battle.player and battle.player.mon == target then return true end
  for _, mon in ipairs((battle and battle.playerParty) or {}) do
    if mon == target then return true end
  end
  local party = battle and battle.game and battle.game.save
      and battle.game.save.party
  for _, mon in ipairs(party or {}) do
    if mon == target then return true end
  end
  return false
end

KantoCompat.isPlayerPartyMon = isPlayerPartyMon

function KantoCompat.wrapExecuteAction(original)
  return function(self, user, target, action, ...)
    if not isPlayerPartyMon(self, target) then
      return original(self, user, target, action, ...)
    end

    -- Kanto Reforged 1.2.0 checks target.isPlayer for every non-nil target.
    -- A party Pokémon has no such field, so Potion use is redirected to the
    -- enemy battler. Mark it only while the inner wrapper runs and restore
    -- the save-owned Pokémon on success or failure.
    local old = target.isPlayer
    target.isPlayer = true
    local results
    if table.pack then
      results = table.pack(pcall(original, self, user, target, action, ...))
    else
      results = { pcall(original, self, user, target, action, ...) }
    end
    target.isPlayer = old
    if not results[1] then error(results[2], 0) end
    return unpackAny(results, 2, results.n or #results)
  end
end

function KantoCompat.install(compat)
  -- Register this harmless legacy-name bridge before probing mod.find. Some
  -- loader builds do not expose content mods through mod.find even though
  -- their Lua modules and data patches are live.
  KantoCompat.installAssetAlias()
  KantoCompat.installPartyIconGuard()
  if KantoCompat.installed or not (compat and compat:kanto()) then return false end
  local ok, BattleState = pcall(require, "src.battle.BattleState")
  if not ok or type(BattleState) ~= "table"
      or type(BattleState.executeAction) ~= "function" then return false end
  if BattleState._aiRivalsKantoPotionTarget then
    KantoCompat.installed = true
    return true
  end
  BattleState.executeAction = KantoCompat.wrapExecuteAction(BattleState.executeAction)
  BattleState._aiRivalsKantoPotionTarget = true
  KantoCompat.installed = true
  return true
end

return KantoCompat
