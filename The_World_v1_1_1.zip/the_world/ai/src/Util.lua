-- Shared helpers.  Every module in this mod is loaded by the tiny loader in
-- main.lua and receives (require, mod) as its varargs, so the first line of
-- each is `local req, mod = ...`.

local M = {}

-- ------------------------------------------------------------------
-- Deterministic RNG
-- ------------------------------------------------------------------
-- love.math.random is shared with the engine's own rolls, so drawing from it
-- would make a rival's decisions depend on how many wild encounters the
-- player happened to trigger.  Each rival owns a 32-bit LCG instead: its seed
-- is saved, so a save reloaded twice makes the same choices, and a debug
-- `simulate` replays identically.  Numbers are the Numerical Recipes LCG,
-- which is plenty for "does he go left or right".
--
-- Lua 5.1 has no integer type and no bitops we can rely on across LuaJIT and
-- plain 5.1, so this stays inside 2^53 by construction: the multiply is
-- split so no intermediate exceeds 2^53.

local MOD = 4294967296  -- 2^32

local Rng = {}
Rng.__index = Rng

function M.rng(seed)
  seed = math.floor(tonumber(seed) or 1) % MOD
  return setmetatable({ state = seed }, Rng)
end

function Rng:next()
  -- state = (1664525 * state + 1013904223) mod 2^32, without ever building
  -- 1664525 * state directly (that overflows the double's exact range).
  local s = self.state
  local hi = math.floor(s / 65536)
  local lo = s % 65536
  local a = 1664525
  local product = ((a * hi) % 65536) * 65536 + a * lo
  self.state = (product + 1013904223) % MOD
  return self.state
end

-- uniform float in [0, 1)
function Rng:float()
  return self:next() / MOD
end

-- inclusive integer range
function Rng:int(lo, hi)
  if hi == nil then lo, hi = 1, lo end
  if hi <= lo then return lo end
  return lo + (self:next() % (hi - lo + 1))
end

function Rng:chance(p)
  if not p or p <= 0 then return false end
  if p >= 1 then return true end
  return self:float() < p
end

function Rng:pick(list)
  if not list or #list == 0 then return nil end
  return list[self:int(1, #list)]
end

-- ------------------------------------------------------------------
-- Table helpers
-- ------------------------------------------------------------------

function M.copy(t)
  if type(t) ~= "table" then return t end
  local out = {}
  for k, v in pairs(t) do out[k] = M.copy(v) end
  return out
end

function M.count(t)
  local n = 0
  for _ in pairs(t or {}) do n = n + 1 end
  return n
end

function M.indexOf(list, value)
  for i, v in ipairs(list or {}) do
    if v == value then return i end
  end
  return nil
end

function M.contains(list, value)
  return M.indexOf(list, value) ~= nil
end

function M.clamp(v, lo, hi)
  if v < lo then return lo end
  if v > hi then return hi end
  return v
end

-- ------------------------------------------------------------------
-- Presentation
-- ------------------------------------------------------------------

-- "ROUTE_12" -> "ROUTE 12", "CERULEAN_CITY" -> "CERULEAN CITY".  Map ids are
-- the only user-visible identifier this mod prints, and the underscore form
-- reads as debug output on a status screen.
function M.spaced(id)
  return (tostring(id or "?"):gsub("_", " "))
end

local WORDS = { "zero", "one", "two", "three", "four",
                "five", "six", "seven", "eight" }

function M.numberWord(n)
  return WORDS[(tonumber(n) or 0) + 1] or tostring(n)
end

-- ------------------------------------------------------------------
-- Safety
-- ------------------------------------------------------------------

function M.recordError(label, err)
  local message = tostring(label) .. ": " .. tostring(err)
  M.lastError = message
  M.errorCount = (M.errorCount or 0) + 1
  M.errorHistory = M.errorHistory or {}
  M.errorHistory[#M.errorHistory + 1] = message
  while #M.errorHistory > 8 do table.remove(M.errorHistory, 1) end
  return message
end

-- Every entry point this mod exposes to the engine (an event listener, a hook
-- link, a screen factory) runs inside one of these.  The buses already pcall
-- their subscribers, but a raise there costs the whole listener for the rest
-- of the frame and lands in the player's error feed; a rival mod should
-- degrade to "that rival did nothing this tick" instead.
function M.guard(label, fn, ...)
  local ok, err = pcall(fn, ...)
  if not ok then
    M.recordError(label, err)
    return nil, err
  end
  return true
end

return M
