local req, mod = ...
local Util = req("src/Util")
local AI = req("src/AI")
local BattleSim = req("src/BattleSim")
local Presence = req("src/Presence")
local Weather = req("src/Weather")
local League = req("src/League")
local Career = req("src/Career")

-- THE WORLD TICK.
--
-- This is the answer to "what are the other three rivals doing while you are
-- in Mt Moon".  It is deliberately NOT a smaller copy of the overworld: no
-- rival off screen has a grid position, a walk animation, a collision test or
-- a wild encounter.  It has a route and a clock.
--
-- BUDGETS -- the whole reason this file is shaped the way it is
--
-- The mod ships with four rivals and is meant to run on a phone, so:
--
--   * The tick is time-based, not frame-based.  Simulation.update takes dt
--     and fires at most once per TICK_SECONDS regardless of frame rate, so a
--     144Hz desktop and a 30fps handheld simulate Kanto at the same speed.
--   * One tick advances at most `budget` rivals (default 2).  Four rivals
--     therefore cost two ticks to come round, which at 1.5s a tick is under a
--     second of lag on a decision nobody can see.
--   * A gym battle is the expensive operation -- it is a whole simulated
--     fight -- so at most one runs per tick, ever.  A rival that wanted to
--     fight and lost the slot fights on the next tick.
--   * Nothing here allocates per frame.  Simulation.update returns
--     immediately unless the accumulator crossed the threshold.
--
-- DETAIL LEVELS
--
--   near   the rival is on the player's map.  It is a real NPC and
--          src/Encounters.lua drives it; this file only does its bookkeeping.
--   far    everything else.  Route progress is a counter, training is a
--          formula, and a gym attempt is one BattleSim.run.

local Simulation = {}

Simulation.TICK_SECONDS = 1.5

-- How many ticks a rival spends crossing one map.  A route is not instant --
-- if it were, a rival could cross Kanto between two of the player's steps and
-- the world would read as teleporting, which is exactly what section 24 of
-- the brief forbids.  Indoor maps are quicker to cross than routes.
-- The states that mean "on the way somewhere".  Reaching a destination while
-- in one of these is an arrival, whether or not a hop happened.
local TRAVEL_STATES = {
  TRAVELLING = true, SEEKING_GYM = true, SEEKING_PLAYER = true,
}

-- 1.34.0: every completed battle credits the rival's LEAD with a battle (and a
-- victory when it won) and credits the types it fielded. Routed through one
-- helper and called at every resolution site, so no battle path can silently
-- skip a Pokémon's service record -- which is what the emergent favourite in
-- roadmap §7 is built from.
local function creditTeam(rival, won, opponentId, tick)
  if not rival then return end
  if rival.creditLeadBattle then
    pcall(rival.creditLeadBattle, rival, won == true)
  end
  -- 1.35.0: the same door carries the story beat. A defeat opens a setback the
  -- rival then has to answer; beating that opponent closes it. Routed here so
  -- the story cannot drift out of step with the service record -- there is one
  -- list of battle sites in this file, not two.
  if opponentId then
    if won == false and rival.noteDefeat then
      pcall(rival.noteDefeat, rival, opponentId, tick)
    elseif won == true and rival.noteVictory then
      pcall(rival.noteVictory, rival, opponentId, tick)
    end
  end
end

local function hopCost(mapId, rival)
  local cost
  if type(mapId) ~= "string" then
    cost = 3
  elseif mapId:sub(1, 6) == "ROUTE_" then
    cost = 4
  elseif mapId:find("CITY") or mapId:find("TOWN") then
    cost = 3
  else
    cost = 2
  end
  -- 1.36.0 §15: familiar ground is quicker to cross. Capped at a 25% saving
  -- and floored at 2 ticks, so navigation memory is a real advantage a
  -- well-travelled rival earns without ever collapsing travel to nothing --
  -- and it changes SPEED only. Whether a rival may enter a map at all is
  -- decided by Rival:canEnterMap, which this does not touch.
  if rival and rival.familiarity then
    local known = rival:familiarity(mapId)
    if known > 0 then
      cost = math.max(2, math.floor(cost * (1 - 0.25 * known) + 0.5))
    end
  end
  return cost
end

-- ------------------------------------------------------------------
-- Training
-- ------------------------------------------------------------------

-- Exp per training tick.  Scaled off the rival's own average level so that
-- grinding does not get faster forever (a Lv40 team does not level on Route 1
-- wilds) and off the personality's trainRate.  The shape is deliberately
-- sub-linear: the gap between a rival and the player narrows over a
-- playthrough instead of running away.
local function trainingExp(rival, playerMap)
  -- Past the ceiling a training tick teaches almost nothing.  Not zero: a
  -- rival parked at the plateau with eight badges should still drift upward,
  -- just slowly enough that it never runs away from the player.
  if rival.atLevelCeiling and rival:atLevelCeiling() then
    return math.max(1, math.floor(rival:averageLevel() * 0.4))
  end
  local level = math.max(1, rival:averageLevel())
  local base = 14 + level * level * 0.55
  -- weather_fx interop: when the sky over the player's map favours this
  -- rival's team it works it harder (fire types love a sun), and when the
  -- sky fights its team the training is lousy.  Local to the player's map,
  -- asked live, neutral in every unknown case.
  local mult = AI.weatherEdge(rival, {
    compat = rival.ctx.compat, playerMap = playerMap,
  })
  return math.floor(base * (rival.personality.trainRate or 1) * mult)
end

-- Rivals are competitors, not an unattended idle game. Keep their training
-- ceiling close to the strongest Pokemon the player can currently field. The
-- small lead preserves pressure without letting five minutes of menu time turn
-- a fresh Lv5 rival into a Lv20 trainer.
local function playerLeadLevel(party)
  local best
  for _, slot in ipairs(type(party) == "table" and party or {}) do
    local level = tonumber(type(slot) == "table" and (slot.level or slot.lvl))
    if level and level >= 1 then best = math.max(best or 1, level) end
  end
  return best
end

-- A training tick also costs a little HP -- a rival grinding through wild
-- Pokemon takes chip damage -- which is what eventually sends it to a Poke
-- Center under its own steam rather than because a timer said so.
local function trainingWear(rival)
  for _, slot in ipairs(rival.party) do
    local max = rival:maxHpOf(slot)
    local cur = tonumber(slot.hp) or max
    slot.hp = Util.clamp(cur - math.max(1, math.floor(max * 0.06)), 0, max)
  end
end

local function mapHasWildEncounters(rival)
  local data, mapId = rival.ctx and rival.ctx.data, rival.map
  if not (data and mapId) then return false end
  local byMap = data.encounters and data.encounters[mapId]
  if type(byMap) == "table" then
    local slots = byMap.slots or byMap.grass or byMap
    if type(slots) == "table" and next(slots) ~= nil then return true end
  end
  local gen2 = data.gen2Encounters
  for _, kind in ipairs(gen2 and { gen2.grass, gen2.water } or {}) do
    local row = kind and kind[mapId]
    local slots = type(row) == "table" and (row.slots or row) or nil
    if type(slots) == "table" and next(slots) ~= nil then return true end
  end
  return false
end

-- Catching.  Held to the same rule as everything else: the species has to be
-- one the loaded game actually has, and it comes off the encounter table for
-- the map the rival is standing on, so a Collector on Route 4 catches things
-- that live on Route 4.  If the encounter table cannot be read, no catch --
-- inventing a species would be faking it.
local function tryCatch(rival)
  -- Organic catches only: never before the Lab gauntlet, never without a
  -- ball. Captures past six are placed in the rival's PC by capturePokemon.
  if rival.canCatch and not rival:canCatch() then return nil end
  if not rival.canCatch then
    -- fallback for very old save shapes that lack the method
    local map = rival.map
    if map == "OAKS_LAB" or map == "PALLET_TOWN" then return nil end
    if (tonumber(rival.balls) or 0) < 1 then return nil end
  end
  -- 2.2.0: a career scales the same chance rather than adding a second gate,
  -- so the personality still decides the baseline and the bias is visible in
  -- one place. The roll is the SAME single rng:chance call, so pre-2.2 saves
  -- replay identically for every rival still on the Gym Challenge (bias 1).
  local chance = (rival.personality.catchChance or 0)
    * (rival.catchBonus and rival:catchBonus() or 1)
    * (rival.careerCatchBias and rival:careerCatchBias() or 1)
  -- Before badge one, an under-sized party is actively trying to recruit.
  -- Personality still matters above the floor, but no ordinary rival spends
  -- an hour grinding Route 2 while refusing almost every legal encounter.
  local earlyFloor = rival.minimumPartyForNextGym and rival:minimumPartyForNextGym() or 1
  if (rival.badgeCount and rival:badgeCount() == 0) and #rival.party < earlyFloor then
    chance = math.max(chance, 0.35)
  end
  if not rival.rng:chance(math.min(1, chance)) then return nil end
  local data = rival.ctx.data
  -- Gen 1 keys encounters by map (data.encounters[map]); Gen 2 keys by kind
  -- first (data.gen2Encounters.grass.ROUTE_29), so walk whichever the game has.
  local slots
  local byMap = data and data.encounters and data.encounters[rival.map]
  if byMap then
    slots = byMap.slots or byMap.grass or byMap
  else
    local gen2 = data and data.gen2Encounters
    local grass = gen2 and (gen2.grass or gen2.swarmGrass)
      and (gen2.grass or gen2.swarmGrass)[rival.map]
    local water = gen2 and gen2.water and gen2.water[rival.map]
    slots = (grass and grass.slots) or (water and water.slots)
  end
  if type(slots) ~= "table" then return nil end
  -- the DEX SCOPE (Kanto-Reforged) is asked per candidate and can only
  -- remove: a species that scope hides is not something a rival may be seen
  -- holding, so it never enters the pool to begin with
  local allows = rival.ctx.compat
    and rival.ctx.compat.krAllows
    and function(s) return rival.ctx.compat:krAllows(s) ~= false end
  local candidates = {}
  local dex = data and (data.pokemon or data.gen2Pokemon) or {}
  for key, entry in pairs(slots) do
    local species = type(entry) == "table" and (entry.species or entry.mon or entry.id)
      or (type(entry)=="string" and entry or (type(key)=="string" and key or nil))
    local level = type(entry) == "table" and (entry.level or entry.lvl or entry.minLevel or entry.min)
      or (type(entry)=="number" and entry or nil)
    local worldAllowed=true
    pcall(function()
      if rival.ctx and rival.ctx.mod and rival.ctx.mod.exports
         and type(rival.ctx.mod.exports.worldSpeciesAllowed)=="function" then
        worldAllowed=rival.ctx.mod.exports.worldSpeciesAllowed(species)
      end
    end)
    if type(species) == "string" and dex[species] and worldAllowed
       and (not allows or allows(species)) then
      candidates[#candidates + 1] = { species = species, level = level }
    end
  end
  if #candidates == 0 then return nil end
  -- 1.34.0: WHAT a rival reaches for is a team-identity decision. The list is
  -- weighted by fit and then drawn with the SAME single rng:int call as
  -- before, so the rival's own stream advances identically and pre-1.34 saves
  -- replay. A single candidate short-circuits, because weighting it would turn
  -- a zero-draw int(1,1) into a real draw and shift the sequence.
  -- Weighting only: every legal encounter stays reachable, so a Fire
  -- specialist standing in water still catches what is actually there.
  local weighted = candidates
  if #candidates > 1 and rival.teamFit then
    weighted = {}
    for _, c in ipairs(candidates) do
      local copies = 1
      local ok, fit = pcall(rival.teamFit, rival, c.species)
      if ok then copies = Util.clamp(1 + math.floor((tonumber(fit) or 0) * 1.5), 1, 3) end
      for _ = 1, copies do weighted[#weighted + 1] = c end
    end
    if #weighted == 0 then weighted = candidates end
  end
  -- 1.15.0: a rival on the hunt leans toward its target species
  local pick
  if rival.huntTarget then
    local hunted
    for _, c in ipairs(candidates) do
      if c.species == rival.huntTarget then hunted = c break end
    end
    if hunted and rival.rng:chance(0.5) then
      pick = hunted
    else
      pick = weighted[rival.rng:int(1, #weighted)]
    end
  else
    pick = weighted[rival.rng:int(1, #weighted)]
  end
  -- caught at roughly the level it is found at, then it has to catch up
  -- Never catch something above the level the rival is currently allowed to
  -- field for its next Gym. This also protects against high-level encounter
  -- tables in conversions and prevents an early-game rival from jumping from
  -- Route 2 straight into an illegal Lv30 catch.
  local catchCap = rival:levelCeiling()
  local level = Util.clamp(math.floor(pick.level or rival:averageLevel() * 0.7),
                           2, math.min(100, catchCap))
  local slot = rival.capturePokemon and rival:capturePokemon(pick.species, level)
    or rival:addPokemon(pick.species, level)
  if slot then
    if rival.recordEncounter then rival:recordEncounter(rival.map, pick.species, true) end
    if rival.registerDex then rival:registerDex(pick.species) end
    -- 2.2.0 §26: a capture is career progress for three of the four careers.
    -- Routed through one door on the rival so they cannot disagree about what
    -- a catch is worth.
    -- tryCatch has no ctx, so the promotion is returned to the caller rather
    -- than logged here. `and ctx and ctx.log` would have been silently dead --
    -- a guard that can never be true is worse than no guard, because it reads
    -- like the case is handled.
    if rival.creditCapture then
      local promoted, level = rival:creditCapture(pick.species, slot)
      if promoted then rival.careerPromotion = level end
    end
    pcall(function() Happiness.noteCatch(rival,pick.species,slot,false) end)
    if rival.huntTarget == pick.species then
      rival.huntTarget, rival.huntMap = nil, nil
    end
    -- 1.14.0: the strongest held ball is used (Great/Ultra are more reliable)
    if rival.spendBall then rival:spendBall()
    elseif rival.takeItem then rival:takeItem("POKE_BALL")
    else rival.balls = math.max(0, (tonumber(rival.balls) or 0) - 1) end
    return pick.species, slot
  end
  return nil
end

-- ------------------------------------------------------------------
-- Gym attempts
-- ------------------------------------------------------------------

-- One attempt at the rival's next gym.  This is the only place a badge is
-- ever awarded, and it awards exactly one, only on a win.
function Simulation.attemptGym(rival, playerMap)
  -- 3.2.0: the hard pacing rule, at the one door a badge can come through.
  --
  -- Can.GYM already refuses to SELECT the objective past the lead, but
  -- selection is advisory: a rival can be halfway to Cerulean when the cap
  -- closes, and the objective is only re-chosen at a decision point. Checking
  -- here means no path -- a stale objective, a debug verb, a future caller --
  -- can put a rival beyond the configured three-badge lead.
  --
  -- It refuses the FIGHT rather than withholding the badge afterwards: a rival
  -- that beats a Gym Leader and receives nothing is a worse bug than one that
  -- waits its turn.
  if rival.mayEarnBadge and not rival:mayEarnBadge() then
    if rival.setState then
      rival:setState("IDLE", "waiting for the player to catch up")
    end
    rival.gymCooldown = math.max(tonumber(rival.gymCooldown) or 0, 120)
    return nil
  end
  local gym, badge = rival:nextGym()
  if not (gym and badge) then return nil, "no gym" end
  if rival:hasBadge(badge) then return nil, "already held" end

  local data = rival.ctx.data
  local leaderParty = BattleSim.leaderParty(data, gym.class, gym.party or 1)

  if not leaderParty or #leaderParty == 0 then
    -- No party to fight.  Refuse rather than roll a die: a badge handed out
    -- because the trainer table was missing is exactly the fake progression
    -- this mod is not allowed to have.
    rival.gymCooldown = 20
    return nil, "no leader party"
  end

  rival.gymAttempts[badge] = (rival.gymAttempts[badge] or 0) + 1
  -- battle weather_fx interop: when the player is standing in the same gym
  -- the fight happens under the player's sky, and that sky moves both sides'
  -- moves exactly as weather_fx models it.  Off the player's map there is no
  -- sky to read, so the fight is weather-neutral.
  local opts = {}
  local compat = rival.ctx.compat
  if compat and compat:weather() and playerMap and playerMap == rival.map then
    opts.weather = compat:battleWeather()
    -- 1.37.0: the chip is resolved from the OVERWORLD id, which is
    -- unambiguous; the battle string is not (STORM and RAIN_LIGHT are both
    -- "RAINY" but chip ELECTRIC and WATER respectively).
    opts.weatherId = compat:weatherId()
    opts.chipType = Weather.chipType(compat, opts.weatherId)
  end
  if rival.prepareForBattle then rival:prepareForBattle() end
  -- The team was selected during a real Poké Center visit. Never access the PC
  -- from inside the Gym immediately before the battle.
  local result = BattleSim.run(data, rival.party, leaderParty, rival.rng, opts)

  -- damage carries out of the fight either way
  for i, slot in ipairs(rival.party) do
    if result.aHp and result.aHp[i] then slot.hp = result.aHp[i] end
  end

  creditTeam(rival, result.winner == "a", gym.class, rival.ticks)
  if result.winner == "a" then
    rival:awardBadge(badge)
    pcall(function() Happiness.noteGym(rival,true,badge,gym.leader) end)
    rival.defeatedLeaders[gym.class] =
      (rival.defeatedLeaders[gym.class] or 0) + 1
    rival.confidence = Util.clamp((rival.confidence or 1) + 0.10, 0.5, 2.0)
    -- a leader is worth real experience
    rival:gainExp(math.floor(120 + (gym.level or 20) * 22))
    rival.gymCooldown = 4
    rival:setState("RETURNING_FROM_GYM", "won " .. badge)
    return { won = true, badge = badge, gym = gym, turns = result.turns }
  end

  pcall(function() Happiness.noteGym(rival,false,badge,gym.leader) end)
  pcall(function() Happiness.noteFaints(rival) end)
  rival.confidence = Util.clamp((rival.confidence or 1) - 0.12, 0.5, 2.0)
  rival.gymCooldown = rival.personality.retryPatience or 6
  rival.lastGymLoss = badge
  -- losing still teaches something, just much less
  rival:gainExp(math.floor(30 + (gym.level or 20) * 4))
  rival:setState("RETURNING_FROM_GYM", "lost to " .. tostring(gym.leader))
  return { won = false, badge = badge, gym = gym, turns = result.turns }
end

-- ------------------------------------------------------------------
-- Ghost fights (silph-scope interop)
-- ------------------------------------------------------------------

-- One headless fight against a silph-scope ghost the rival walked to.  The
-- battle is LOCAL: the win is experience and confidence, nothing is written
-- into silph's storage, no ghost is moved or removed, and the ghost world is
-- unchanged -- this mod only watches.  A ghost with no resolvable party is
-- refused exactly like a missing gym leader party: no result is invented.
function Simulation.attemptGhost(rival, playerMap)
  local compat = rival.ctx.compat
  local ghost = rival.ghostTarget
  if not compat or not compat:silph() or not ghost then
    rival:setState("IDLE", "no ghost to fight")
    return nil, "no ghost"
  end
  local party = ghost.party
  if type(party) ~= "table" or #party == 0 then
    rival:setState("IDLE", "ghost has no party")
    return nil, "no ghost party"
  end
  local data = rival.ctx.data
  -- weather_fx interop: a ghost on the player's map is fought under the
  -- player's sky; anywhere else the fight is weather-neutral
  local opts = {}
  if compat:weather() and playerMap and playerMap == ghost.mapId then
    opts.weather = compat:battleWeather()
    opts.weatherId = compat:weatherId()
    opts.chipType = Weather.chipType(compat, opts.weatherId)
  end
  if rival.prepareForBattle then rival:prepareForBattle() end
  local result = BattleSim.run(data, rival.party, party, rival.rng, opts)

  -- damage carries out of the fight either way
  for i, slot in ipairs(rival.party) do
    if result.aHp and result.aHp[i] then slot.hp = result.aHp[i] end
  end

  creditTeam(rival, result.winner == "a")
  if result.winner == "a" then
    rival:gainExp(math.floor(40 + (ghost.level or 15) * 6))
    rival.confidence = Util.clamp((rival.confidence or 1) + 0.04, 0.5, 2.0)
  else
    rival.confidence = Util.clamp((rival.confidence or 1) - 0.05, 0.5, 2.0)
  end
  rival.ghostCooldown = 6
  rival.ghostTarget = nil
  local won = result.winner == "a"
  rival:setState("IDLE", won and "beat a ghost" or "lost to a ghost")
  return { won = won, ghost = ghost.name or ghost.id, turns = result.turns }
end

-- ------------------------------------------------------------------
-- League aspiration (1.7.0)
-- ------------------------------------------------------------------
-- Once a rival has every badge it routes to the Plateau and, every so often,
-- attempts a simulated Elite Four + Champion run using the loaded game's five
-- real trainer parties. A full win sets rival.champion = true (saved) and
-- raises confidence; missing League data refuses the run instead of inventing
-- opponents, and a loss only costs cooldown and a little confidence.

function Simulation.attemptLeague(rival, playerMap)
  if rival.champion then return nil, "already champion" end
  local data = rival.ctx.data
  local manager = rival.ctx.manager

  -- 4.6.0: A HELD TITLE NO LONGER CLOSES THE ELITE FOUR.
  --
  -- These two refusals used to end the function: while anybody -- the player
  -- or another rival -- wore the crown, no rival could run the League at all.
  -- `qualified` is only ever set by clearing it, and §30's title challenge is
  -- gated on `qualified`, so the moment a champion existed the challenge path
  -- became permanently unreachable. The feature shipped in 1.39 and could
  -- never once have fired: the very event that creates a champion is the event
  -- that stops anybody qualifying to face one.
  --
  -- So a held title now changes what a run is FOR rather than whether it may
  -- happen. With the crown vacant, clearing the League takes it, as before.
  -- With it held, the run stops at the Elite Four and clearing them makes this
  -- rival a CHALLENGER -- the title itself only ever changes hands in a title
  -- match against whoever is holding it (Simulation.tryTitleMatch).
  local titleHolder = nil
  if manager and manager.playerChampion then titleHolder = "player" end
  if manager and not manager.playerChampion and not (data and data.gen2Trainers)
     and BlueChampion.current(manager) then titleHolder="blue" end
  for _, other in ipairs((manager and manager.rivals) or {}) do
    if other ~= rival and other.champion then titleHolder = other end
  end
  local contested = titleHolder ~= nil


  -- Use only the League trainers and parties supplied by the loaded game.
  -- Never generate a scaled substitute: if a conversion has no recognisable
  -- League, it cannot accidentally award the title for zero battles.
  local trainers = data and (data.gen2Trainers or data.trainers)
  local classes = trainers and (trainers.classes or trainers) or {}
  local gen2 = data and data.gen2Trainers ~= nil
  local roles = gen2
    and { { "WILL" }, { "KOGA" }, { "BRUNO" }, { "KAREN" }, { "CHAMPION" } }
    or { { "LORELEI" }, { "BRUNO" }, { "AGATHA" }, { "LANCE" },
         { "RIVAL3", "CHAMPION" } }
  -- The final role IS the sitting Champion. Somebody is already sitting there,
  -- so the run is the Elite Four and stops at the door.
  if contested then
    local elite = {}
    for i = 1, #roles - 1 do elite[i] = roles[i] end
    roles = elite
  end
  local league = {}
  local used = {}
  for _, tokens in ipairs(roles) do
    local selected
    for cls, rec in pairs(classes or {}) do
      local recTable = type(rec) == "table" and rec or {}
      local hay = (tostring(cls) .. " " .. tostring(recTable.name or "")):upper()
      local matches = false
      for _, token in ipairs(tokens) do
        if hay:find(token, 1, true) then matches = true break end
      end
      if matches and not used[cls] and not tostring(cls):find("OPP_AIR_", 1, true) then
        local bestParty, bestStrength
        for index in pairs(recTable.parties or recTable.trainers or {}) do
          if type(index) == "number" then
            local party = BattleSim.leaderParty(data, cls, index)
            local strength = party and BattleSim.strength(data, party) or 0
            if party and #party > 0 and (not bestStrength or strength > bestStrength) then
              bestParty, bestStrength = party, strength
            end
          end
        end
        if bestParty then selected = { class = cls, party = bestParty } break end
      end
    end
    if not selected then return nil, "League trainer data unavailable" end
    used[selected.class] = true
    league[#league + 1] = selected
  end

  local totalTurns = 0
  local avg = math.max(1, math.floor(rival:averageLevel()))
  for i, opponent in ipairs(league) do
    local foe = opponent.party
    if rival.prepareForBattle then rival:prepareForBattle() end
    local result = BattleSim.run(data, rival.party, foe, rival.rng)
    for j, slot in ipairs(rival.party) do
      if result and result.aHp and result.aHp[j] ~= nil then slot.hp = result.aHp[j] end
    end
    totalTurns = totalTurns + (result and result.turns or 0)
    creditTeam(rival, result and result.winner == "a", "LEAGUE", rival.ticks)
    if not result or result.winner ~= "a" then
      rival.leagueAttempts = (rival.leagueAttempts or 0) + 1
      -- 1.39.0: the record decides how long the wait is, and it lengthens with
      -- every failure at this same stage.
      local record = rival.ensureLeague and rival:ensureLeague()
      if record then
        League.recordAttempt(record, i, false,
          { strength = rival.leagueStrength and rival:leagueStrength() or 0 })
        rival.leagueCooldown = record.cooldown or League.MIN_GAP
      else
        -- No record (a rival object from before 1.39). Use the model's floor
        -- rather than the old flat 16: a fallback that silently restores the
        -- 1500-attempt behaviour is worse than no fallback, because it looks
        -- like defensive coding.
        rival.leagueCooldown = League.MIN_GAP
      end
      rival.confidence = Util.clamp((rival.confidence or 1) - 0.08, 0.5, 2.0)
      rival:gainExp(math.floor(20 + avg * 3))
      -- §4: falling at the League is a setback the rival then has to answer.
      if rival.noteDefeat then
        pcall(rival.noteDefeat, rival, "LEAGUE", rival.ticks)
      end
      return { won = false, turns = totalTurns, stage = i,
               wall = record and select(1, League.wall(record)) }
    end
    -- carry residual damage into the next fight, just like a real run
  end

  local record = rival.ensureLeague and rival:ensureLeague()

  -- Cleared, with the crown already on somebody's head: this rival is now a
  -- challenger and nothing else. recordAttempt sets `qualified`, which is the
  -- one thing a title match asks for.
  if contested and titleHolder=="blue" then
    local blueParty,bestStrength
    local trainers0=data and data.trainers
    local classes0=trainers0 and (trainers0.classes or trainers0) or {}
    for cls,rec in pairs(classes0 or {}) do
      local hay=(tostring(cls).." "..tostring(type(rec)=="table" and rec.name or "")):upper()
      if hay:find("RIVAL3",1,true) or hay:find("CHAMPION",1,true) then
        for idx in pairs((type(rec)=="table" and (rec.parties or rec.trainers)) or {}) do
          if type(idx)=="number" then
            local candidate=BattleSim.leaderParty(data,cls,idx)
            local strength=candidate and BattleSim.strength(data,candidate) or 0
            if candidate and #candidate>0 and (not bestStrength or strength>bestStrength) then
              blueParty,bestStrength=candidate,strength
            end
          end
        end
      end
    end
    if not blueParty then return nil,"Blue Champion data unavailable" end
    if rival.prepareForBattle then rival:prepareForBattle() end
    local final=BattleSim.run(data,rival.party,blueParty,rival.rng)
    totalTurns=totalTurns+(final and final.turns or 0)
    if not final or final.winner~="a" then
      rival.leagueAttempts=(rival.leagueAttempts or 0)+1
      if record then League.recordAttempt(record,#league+1,false,{strength=rival:leagueStrength()}) end
      rival.leagueCooldown=record and record.cooldown or League.MIN_GAP
      return {won=false,turns=totalTurns,stage=#league+1,champion="blue"}
    end
    rival.champion=true
    if rival.assumeChampionLifePath then rival:assumeChampionLifePath("defeated Blue for the Pokemon League title") end
    if record then
      League.recordAttempt(record,#league+1,true,{strength=rival:leagueStrength()})
      League.beginReign(record,rival.ticks)
    end
    BlueChampion.loseTitle(manager,rival.id,rival.name,rival.ticks)
    manager.playerChampion=false
    for _,other in ipairs(manager.rivals or {}) do if other~=rival then other.champion=false end end
    rival.newsPending="CHAMPION"
    return {won=true,turns=totalTurns,championDefeated="blue"}
  end

  if contested then
    if record then
      League.recordAttempt(record, #league, true,
        { strength = rival.leagueStrength and rival:leagueStrength() or 0 })
    end
    rival.leagueAttempts = (rival.leagueAttempts or 0) + 1
    rival.leagueCooldown = record and record.cooldown or 40
    rival.confidence = Util.clamp((rival.confidence or 1) + 0.15, 0.5, 2.0)
    rival:gainExp(math.floor(120 + avg * 8))
    rival.newsPending = "QUALIFIED"
    return { won = true, qualified = true, turns = totalTurns }
  end

  rival.champion = true
  if rival.assumeChampionLifePath then rival:assumeChampionLifePath("won the Pokemon League") end
  if record then
    League.recordAttempt(record, #league, true,
      { strength = rival.leagueStrength and rival:leagueStrength() or 0 })
    League.beginReign(record, rival.ticks)
  end
  if manager then
    -- The outgoing champion's reign ends here, and its qualification went with
    -- the title: to get it back it must clear the Elite Four again.
    for _, other in ipairs(manager.rivals or {}) do
      if other ~= rival and other.champion and other.ensureLeague then
        League.endReign(other:ensureLeague(), other.ticks)
      end
    end
    manager.eliteChampionId = rival.id
    manager.playerChampion = false
    for _, other in ipairs(manager.rivals or {}) do
      if other ~= rival then other.champion = false end
    end
  end
  rival.leagueAttempts = (rival.leagueAttempts or 0) + 1
  rival.leagueCooldown = record and record.cooldown or 40
  rival.confidence = Util.clamp((rival.confidence or 1) + 0.25, 0.5, 2.0)
  rival:gainExp(math.floor(200 + avg * 12))
  rival.newsPending = "CHAMPION"
  return { won = true, turns = totalTurns }
end

-- ------------------------------------------------------------------
-- Title matches (4.6.0)
-- ------------------------------------------------------------------
-- "Then rivals can challenge the champion."
--
-- A rival that has cleared the Elite Four while somebody else holds the crown
-- is a CHALLENGER. When one exists and the champion is a rival (a champion
-- who is the PLAYER is challenged in person -- that path is the manager's, and
-- must not be resolved behind the player's back), the two of them meet at the
-- Plateau and the simulator decides it, exactly as every other rival-vs-rival
-- fight in this file is decided.
--
-- One match per world tick at most, both sides on a long cooldown afterwards,
-- and a beaten challenger loses its qualification -- so a single Elite Four
-- clear buys ONE shot at the title rather than an endless queue of them. That
-- is the same lesson the 1500-attempt League bug taught, applied before it can
-- happen here rather than after.

function Simulation.titleChallenger(rivals, champion)
  local best
  for _, rival in ipairs(rivals or {}) do
    if rival and rival ~= champion and not rival.champion and #(rival.party or {}) > 0
       and rival.ensureLeague and League.mayTitleMatch(rival:ensureLeague())
       and not rival:isFainted() then
      -- Deterministic pick: the strongest qualified challenger, ties on id.
      local strength = rival.leagueStrength and rival:leagueStrength() or 0
      if not best or strength > best.strength
         or (strength == best.strength and tostring(rival.id) < tostring(best.rival.id)) then
        best = { rival = rival, strength = strength }
      end
    end
  end
  return best and best.rival or nil
end

function Simulation.tryTitleMatch(rivals, world)
  if not rivals or #rivals < 2 then return nil end
  -- The player wearing the crown is not something this function may settle.
  if world and world.playerChampion then return nil end
  local champion
  for _, rival in ipairs(rivals) do
    if rival and rival.champion then champion = rival break end
  end
  if not champion or #(champion.party or {}) == 0 then return nil end
  local championRecord = champion.ensureLeague and champion:ensureLeague()
  if championRecord and (tonumber(championRecord.titleCooldown) or 0) > 0 then
    return nil
  end
  local challenger = Simulation.titleChallenger(rivals, champion)
  if not challenger then return nil end

  if champion.prepareForBattle then champion:prepareForBattle() end
  if challenger.prepareForBattle then challenger:prepareForBattle() end
  local result = BattleSim.run(challenger.ctx.data, challenger.party,
    champion.party, challenger.rng)
  local challengerWon = result and result.winner == "a"
  local tick = (world and world.tick) or challenger.ticks or 0

  local challengerRecord = challenger.ensureLeague and challenger:ensureLeague()
  if challengerRecord then
    League.recordTitleMatch(challengerRecord, challengerWon, { defending = false })
  end
  if championRecord then
    League.recordTitleMatch(championRecord, not challengerWon, { defending = true })
  end

  if challengerWon then
    -- The crown changes hands. The outgoing champion's reign is closed through
    -- League.endReign so its length is recorded exactly once, and the incoming
    -- one begins a reign -- which also consumes their qualification, so
    -- winning the title does not leave them qualified to challenge themselves.
    if championRecord then League.endReign(championRecord, tick) end
    champion.champion = false
    if champion.leaveChampionLifePath then champion:leaveChampionLifePath("lost the Champion title") end
    challenger.champion = true
    if challenger.assumeChampionLifePath then challenger:assumeChampionLifePath("won the Champion title") end
    if challengerRecord then League.beginReign(challengerRecord, tick) end
    local manager = challenger.ctx and challenger.ctx.manager
    if manager then manager.eliteChampionId = challenger.id end
  end

  -- A title bout is a contest like any other, so it moves the bonds through
  -- the causes that already exist for exactly this: the two of them do not
  -- come away from it feeling the same as before.
  local bonded = not (world and world.relationships == false)
  if bonded then
    local loser = challengerWon and champion or challenger
    local winner = challengerWon and challenger or champion
    if loser.recordRelationship then
      loser:recordRelationship(winner.id, challengerWon and "TITLE_LOST" or "TITLE_TAKEN",
        { tick = tick })
    end
    if winner.recordRelationship then
      winner:recordRelationship(loser.id, "TITLE_TAKEN", { tick = tick })
    end
    if challenger.recordRelationshipBattle then
      challenger:recordRelationshipBattle(champion.id, challengerWon, { tick = tick })
    end
    if champion.recordRelationshipBattle then
      champion:recordRelationshipBattle(challenger.id, not challengerWon, { tick = tick })
    end
  end

  -- Damage carries: a title match is a real fight, not a coin flip.
  for i, slot in ipairs(challenger.party) do
    if result.aHp and result.aHp[i] ~= nil then slot.hp = result.aHp[i] end
  end
  for i, slot in ipairs(champion.party) do
    if result.bHp and result.bHp[i] ~= nil then slot.hp = result.bHp[i] end
  end

  local outcome = {
    challenger = challenger.id, champion = champion.id,
    challengerWon = challengerWon, turns = result and result.turns,
  }
  if world and world.log then
    world.log(challengerWon and challenger or champion, {
      kind = "title_match", challenger = challenger.id, holder = champion.id,
      challengerName = challenger.name, holderName = champion.name,
      won = challengerWon, turns = result and result.turns,
    })
  end
  return outcome
end

-- ------------------------------------------------------------------
-- Rival-vs-rival skirmish (1.7.0)
-- ------------------------------------------------------------------
-- When two or more rivals share a map and both are free (IDLE / TRAINING /
-- EXPLORING / RETURNING_FROM_GYM), there is a chance (personality.rivalFightChance)
-- that one challenges the other.  One skirmish per world tick max.  Winner
-- gains confidence + exp; loser takes wear and may immediately seek a Center.

function Simulation.tryRivalSkirmish(rivals, world)
  if not rivals or #rivals < 2 then return nil end
  -- Winner takes the prize money a duel or skirmish pays.  Scales with the
  -- winner's level like a real trainer's payout, and never exceeds what the
  -- loser is actually carrying.
  local function duelPayout(winner)
    return math.max(10, math.floor(40 + winner:averageLevel() * 5))
  end
  local function transferMoney(winner, loser)
    local payout = math.min(math.max(0, tonumber(loser.money) or 0),
                            duelPayout(winner))
    -- 1.38.0: through the one money door, so the transfer is recorded on
    -- both ledgers and the winner can never receive more than the loser
    -- actually had.
    local taken = loser.forfeit and loser:forfeit(payout)
      or math.min(payout, math.max(0, tonumber(loser.money) or 0))
    payout = taken
    if winner.earn then winner:earn(taken)
    else winner.money = (tonumber(winner.money) or 0) + taken end
    return payout
  end

  -- group by map
  local byMap = {}
  for _, r in ipairs(rivals) do
    if r.id ~= (world and world.companionId)
       and r.map and (r.rivalFightCooldown or 0) <= 0
       and (r.state == "IDLE" or r.state == "TRAINING" or r.state == "EXPLORING"
            or r.state == "RETURNING_FROM_GYM" or r.state == "LEAGUE_READY")
       and #r.party > 0 then
      byMap[r.map] = byMap[r.map] or {}
      byMap[r.map][#byMap[r.map] + 1] = r
    end
  end

  for map, group in pairs(byMap) do
    if #group >= 2 then
      -- pick the most aggressive challenger first
      table.sort(group, function(a, b)
        return (a.personality.rivalFightChance or 0) > (b.personality.rivalFightChance or 0)
      end)
      local a = group[1]
      local chance = a.personality.rivalFightChance or 0.08
      if a.rng:float() < chance then
        local b = group[1 + a.rng:int(1, #group - 1)]
        -- 1.33.0: how a feels about b decides whether the fight actually
        -- happens.  The roll is drawn from a THROWAWAY stream seeded off a's
        -- live state rather than from a.rng, so adding this gate does not
        -- shift a's own RNG sequence and every pre-1.33 decision downstream
        -- of it still replays identically from a save.
        if b and b.id ~= a.id and a.fightBiasToward
           and not (world and world.relationships == false) then
          local bias = a:fightBiasToward(b.id, world and world.tick)
          if bias < 1 then
            local gate = Util.rng((a.rng.state or 1) + (world and world.tick or 0) * 31 + 104729)
            if gate:float() >= bias then b = nil end
          end
        end
        if b and b.id ~= a.id then
          -- They can see each other's current team when they meet. Both make
          -- their selection from the same pre-switch information, so neither
          -- receives an artificial second-mover advantage.
          local seenByA, seenByB = Util.copy(b.party), Util.copy(a.party)
          if a.prepareCounterTeam then a:prepareCounterTeam(b.id, seenByA) end
          if b.prepareCounterTeam then b:prepareCounterTeam(a.id, seenByB) end
          if a.prepareForBattle then a:prepareForBattle() end
          if b.prepareForBattle then b:prepareForBattle() end
          local actualA, actualB = Util.copy(a.party), Util.copy(b.party)
          local result = BattleSim.run(a.ctx.data, a.party, b.party, {})
          for i, slot in ipairs(a.party) do
            if result.aHp and result.aHp[i] ~= nil then slot.hp = result.aHp[i] end
          end
          for i, slot in ipairs(b.party) do
            if result.bHp and result.bHp[i] ~= nil then slot.hp = result.bHp[i] end
          end
          local aWon = result and result.winner == "a"
          creditTeam(a, aWon, b.id, world and world.tick)
          creditTeam(b, not aWon, a.id, world and world.tick)
          if a.rememberOpponent then
            a:rememberOpponent(b.id, actualB, aWon, world and world.tick)
          end
          if b.rememberOpponent then
            b:rememberOpponent(a.id, actualA, not aWon, world and world.tick)
          end
          local winner, loser = aWon and a or b, aWon and b or a
          local payout = transferMoney(winner, loser)
          winner.rivalFightCooldown = 18
          loser.rivalFightCooldown = 18
          winner.lastRivalFight = loser.id
          loser.lastRivalFight = winner.id
          winner.confidence = Util.clamp((winner.confidence or 1) + 0.10, 0.5, 2.0)
          loser.confidence = Util.clamp((loser.confidence or 1) - 0.10, 0.5, 2.0)
          pcall(function() Happiness.noteRivalBattle(winner,true,loser.name) end)
          pcall(function() Happiness.noteRivalBattle(loser,false,winner.name) end)
          pcall(function() Happiness.noteFaints(loser) end)
          winner:gainExp(math.floor(40 + winner:averageLevel() * 4))
          trainingWear(loser)
          if loser.isFainted and loser:isFainted()
             and loser.blackoutToNearestPokemonCenter then
            loser:blackoutToNearestPokemonCenter("lost skirmish to " .. winner.name)
          elseif loser:healthFraction() < ((loser.personality and loser.personality.healAt) or 0.3) then
            loser:setState("HEALING", "lost skirmish to " .. winner.name)
            -- destination will be set on next evaluate
          end
          -- 1.33.0: the contest is the cause.  Both sides record it from
          -- their own side, and only a DERIVED state change is newsworthy.
          local aChanged, aState, bChanged, bState
          local bonded = not (world and world.relationships == false)
          if bonded and a.recordRelationshipBattle then
            local _, _, after, changed = a:recordRelationshipBattle(b.id, aWon,
              { tick = world and world.tick, lead = a:relationshipLead(b) })
            aState, aChanged = after, changed
          end
          if bonded and b.recordRelationshipBattle then
            local _, _, after, changed = b:recordRelationshipBattle(a.id, not aWon,
              { tick = world and world.tick, lead = b:relationshipLead(a) })
            bState, bChanged = after, changed
          end
          if world and world.log then
            world.log(winner, {
              kind = "skirmish",
              vs = loser.id,
              won = aWon,
              money = payout,
              turns = result and result.turns,
            })
            if aChanged then
              world.log(a, { kind = "relationship", with = b.id, state = aState })
            end
            if bChanged then
              world.log(b, { kind = "relationship", with = a.id, state = bState })
            end
          end
          return { a = a.id, b = b.id, won = aWon, money = payout,
                   aState = aState, bState = bState }
        end
      end
    end
  end
  return nil
end

-- ------------------------------------------------------------------
-- Rival-vs-rival duels (1.11.0)
-- ------------------------------------------------------------------
-- The deliberate counterpart to the same-map skirmish: a rival who picked
-- RIVAL_DUEL travelled to another rival's map and now fights it headlessly
-- for money.  The loser pays, the winner takes it, both get a cooldown, and
-- the result is LOCAL -- no shared save writes, the loser just has less
-- pocket money.

function Simulation.attemptDuel(rival)
  local target = rival.rivalTarget
  if not target or not target.id or target.id == rival.id then
    rival:setState("IDLE", "no rival to fight")
    return nil, "no target"
  end
  if #rival.party == 0 or #target.party == 0 then
    rival:setState("IDLE", "no party to duel")
    return nil, "no party"
  end
  local data = rival.ctx.data
  local seenByRival, seenByTarget = Util.copy(target.party), Util.copy(rival.party)
  if rival.prepareCounterTeam then rival:prepareCounterTeam(target.id, seenByRival) end
  if target.prepareCounterTeam then target:prepareCounterTeam(rival.id, seenByTarget) end
  if rival.prepareForBattle then rival:prepareForBattle() end
  if target.prepareForBattle then target:prepareForBattle() end
  local actualRival, actualTarget = Util.copy(rival.party), Util.copy(target.party)
  local result = BattleSim.run(data, rival.party, target.party, rival.rng)
  -- damage carries out of the fight either way
  for i, slot in ipairs(rival.party) do
    if result.aHp and result.aHp[i] ~= nil then slot.hp = result.aHp[i] end
  end
  for i, slot in ipairs(target.party) do
    if result.bHp and result.bHp[i] ~= nil then slot.hp = result.bHp[i] end
  end
  local won = result.winner == "a"
  creditTeam(rival, won, target.id, rival.ticks)
  creditTeam(target, not won, rival.id, target.ticks)
  if rival.rememberOpponent then
    rival:rememberOpponent(target.id, actualTarget, won, rival.ticks)
  end
  if target.rememberOpponent then
    target:rememberOpponent(rival.id, actualRival, not won, target.ticks)
  end
  local winner, loser = won and rival or target, won and target or rival
  local payout = 0
  if won then
    payout = math.min(math.max(0, tonumber(loser.money) or 0),
                      math.max(10, math.floor(40 + winner:averageLevel() * 5)))
    -- 1.38.0: through the one money door, so the transfer is recorded on
    -- both ledgers and the winner can never receive more than the loser
    -- actually had.
    local taken = loser.forfeit and loser:forfeit(payout)
      or math.min(payout, math.max(0, tonumber(loser.money) or 0))
    payout = taken
    if winner.earn then winner:earn(taken)
    else winner.money = (tonumber(winner.money) or 0) + taken end
  end
  winner.confidence = Util.clamp((winner.confidence or 1) + 0.08, 0.5, 2.0)
  loser.confidence = Util.clamp((loser.confidence or 1) - 0.08, 0.5, 2.0)
  winner:gainExp(math.floor(30 + winner:averageLevel() * 4))
  -- 1.14.0 champion continuity: a duel can dethrone the current champion, or
  -- be a successful defence.  The champion keeps improving between defences
  -- because every run it is in feeds it exp.
  local titleMoved = false
  if loser.champion == true and winner.champion ~= true then
    local loserRecord = loser.ensureLeague and loser:ensureLeague()
    local winnerRecord = winner.ensureLeague and winner:ensureLeague()
    -- 5.9.0: an ordinary road duel is NOT automatically a Championship bout.
    -- The challenger must first have cleared the Elite Four and earned a title
    -- match. This prevents a random encounter from manufacturing a Champion.
    if winnerRecord and League.mayTitleMatch(winnerRecord) then
      if loserRecord then
        League.recordTitleMatch(loserRecord, false, { defending = true })
        League.endReign(loserRecord, loser.ticks)
      end
      League.recordTitleMatch(winnerRecord, true, { defending = false })
      winner.champion = true
      loser.champion = false
      if loser.leaveChampionLifePath then loser:leaveChampionLifePath("lost the Champion title") end
      League.beginReign(winnerRecord, winner.ticks)
      if winner.assumeChampionLifePath then winner:assumeChampionLifePath("took the Champion title") end
      winner.newsPending = "CHAMPION"
      titleMoved = true
    end
  elseif winner.champion == true then
    -- An ordinary duel won by the Champion is a spar, not a recorded defence;
    -- title defences happen only through a qualified title challenge.
  end
  rival.rivalFightCooldown = 30
  target.rivalFightCooldown = 30
  rival.lastRivalFight = target.id
  target.lastRivalFight = rival.id
  if loser.isFainted and loser:isFainted()
     and loser.blackoutToNearestPokemonCenter then
    loser:blackoutToNearestPokemonCenter("lost a duel to " .. winner.name)
  elseif loser:healthFraction() < ((loser.personality and loser.personality.healAt) or 0.3) then
    loser:setState("HEALING", "lost a duel to " .. winner.name)
  end
  -- 1.33.0: a duel is the strongest relationship cause in the mod, because
  -- one rival deliberately crossed Kanto to fight the other.  The title
  -- changing hands is recorded on top of the ordinary result, from each
  -- side's own point of view.
  local rivalChanged, rivalState, targetChanged, targetState
  local bonded = rival.ctx and rival.ctx.relationships ~= false
  if bonded and rival.recordRelationshipBattle then
    local _, _, after, changed = rival:recordRelationshipBattle(target.id, won,
      { tick = rival.ticks, lead = rival:relationshipLead(target) })
    rivalState, rivalChanged = after, changed
  end
  if bonded and target.recordRelationshipBattle then
    local _, _, after, changed = target:recordRelationshipBattle(rival.id, not won,
      { tick = target.ticks, lead = target:relationshipLead(rival) })
    targetState, targetChanged = after, changed
  end
  if titleMoved and bonded then
    if winner.recordRelationship then
      local _, _, after, changed = winner:recordRelationship(loser.id, "TITLE_TAKEN",
        { tick = winner.ticks })
      if winner == rival then rivalState, rivalChanged = after, rivalChanged or changed
      else targetState, targetChanged = after, targetChanged or changed end
    end
    if loser.recordRelationship then
      local _, _, after, changed = loser:recordRelationship(winner.id, "TITLE_LOST",
        { tick = loser.ticks })
      if loser == rival then rivalState, rivalChanged = after, rivalChanged or changed
      else targetState, targetChanged = after, targetChanged or changed end
    end
  end
  rival.rivalTarget = nil
  rival:setState("IDLE", won and ("beat " .. tostring(target.name or target.id))
                           or ("lost to " .. tostring(target.name or target.id)))
  return { won = won, vs = target.id, money = payout, turns = result.turns,
           dethroned = titleMoved,
           relationship = rivalChanged and { rival = rival, with = target.id, state = rivalState } or nil,
           targetRelationship = targetChanged and { rival = target, with = rival.id, state = targetState } or nil }
end

-- ------------------------------------------------------------------
-- Trainer battles (1.11.0)
-- ------------------------------------------------------------------
-- A rival training in the world occasionally fights a local trainer headless
-- for money.  The trainer is drawn from the loaded game's own trainer table
-- (gym leaders and this mod's rival classes excluded), the fight is resolved
-- with the same BattleSim as gyms, and winning pays out like a real trainer
-- battle.  The real trainer is untouched -- this is a simulated spar, and the
-- player still meets that trainer in the world.

-- The candidate pool of "enemy trainer" classes for the loaded game, cached
-- on the data table (like the type chart) so one build per boot is enough.
local TRAINER_POOL_KEY = "__ai_rivals_trainer_pool"

local function trainerPool(rival)
  local data = rival.ctx.data
  if not data then return nil end
  local cached = rawget(data, TRAINER_POOL_KEY)
  if cached then return cached end
  local excluded = {}
  local gyms = rival.ctx.gyms or {}
  for _, badge in ipairs(gyms.order or {}) do
    local gym = gyms.byBadge and gyms.byBadge[badge]
    if gym and gym.class then excluded[gym.class] = true end
  end
  if gyms.league and gyms.league.class then excluded[gyms.league.class] = true end
  local manager = rival.ctx.manager
  if manager and type(manager.rivals) == "table" then
    for _, r in ipairs(manager.rivals) do
      if r and r.def then
        if r.def.trainerClass then excluded[r.def.trainerClass] = true end
        if r.def.gen2Shadow then excluded[r.def.gen2Shadow] = true end
      end
    end
  end
  local pool = {}
  local trainers = data.trainers or data.gen2Trainers
  local classes = trainers
  if trainers and trainers.classes then classes = trainers.classes end
  for cls, rec in pairs(classes or {}) do
    if type(rec) == "table" and not excluded[cls] then
      for index, partyRec in pairs(rec.parties or rec.trainers or {}) do
        if type(index) == "number" then
          local party = BattleSim.leaderParty(data, cls, index)
          if party and #party > 0 then
            local map = type(partyRec) == "table"
              and (partyRec.mapId or partyRec.map or partyRec.location) or nil
            map = map or rec.mapId or rec.map or rec.location
            pool[#pool + 1] = { id = tostring(cls) .. "#" .. tostring(index),
                                class = cls, map = map,
                                baseMoney = tonumber(rec.baseMoney) or 50,
                                party = party }
          end
        end
      end
    end
  end
  if #pool == 0 then pool = nil end
  rawset(data, TRAINER_POOL_KEY, pool)
  return pool
end

local function tryTrainerBattle(rival)
  local pool = trainerPool(rival)
  if not pool or #pool == 0 then return nil end
  -- 1.14.0 world persistence: prefer trainers this rival has not beaten yet,
  -- so a defeated trainer stays defeated for that rival's simulation.  Also
  -- skip trainers far above the rival's current gym ceiling.
  local ceiling = (rival.levelCeiling and rival:levelCeiling()) or 100
  local function foeLevel(foe)
    local best = 0
    for _, s in ipairs(foe.party or {}) do
      best = math.max(best, tonumber(s.level) or 0)
    end
    return best
  end
  local undefeated = {}
  for _, entry in ipairs(pool) do
    if (entry.map == nil or entry.map == rival.map)
       and not (rival.hasDefeatedTrainer and
         (rival:hasDefeatedTrainer(entry.id) or rival:hasDefeatedTrainer(entry.class)))
       and foeLevel(entry) <= ceiling + 8 then
      undefeated[#undefeated + 1] = entry
    end
  end
  if #undefeated == 0 then return nil end
  local candidates = undefeated
  local foe = candidates[rival.rng:int(1, #candidates)]
  local data = rival.ctx.data
  if rival.prepareForBattle then rival:prepareForBattle() end
  local result = BattleSim.run(data, rival.party, foe.party, rival.rng)
  for i, slot in ipairs(rival.party) do
    if result.aHp and result.aHp[i] then slot.hp = result.aHp[i] end
  end
  local won = result.winner == "a"
  creditTeam(rival, won)
  local money = 0
  if won then
    money = math.max(10, math.floor(foe.baseMoney * (1 + rival:averageLevel() / 10)))
    if rival.earn then rival:earn(money)
    else rival.money = (tonumber(rival.money) or 0) + money end
    rival.confidence = Util.clamp((rival.confidence or 1) + 0.04, 0.5, 2.0)
    rival:gainExp(math.floor(30 + rival:averageLevel() * 4))
    if rival.defeatedTrainer then rival:defeatedTrainer(foe.id) end
  else
    rival.confidence = Util.clamp((rival.confidence or 1) - 0.04, 0.5, 2.0)
    if rival.isFainted and rival:isFainted() and rival.blackoutToNearestPokemonCenter then
      rival:blackoutToNearestPokemonCenter("lost to a trainer")
    elseif rival:healthFraction() < ((rival.personality and rival.personality.healAt) or 0.3) then
      rival:setState("HEALING", "lost to a trainer")
    end
  end
  return { won = won, trainer = foe.id, trainerClass = foe.class,
           money = money, turns = result.turns }
end


-- Campaign integrity: before a rival leaves a map on its badge journey it must
-- defeat every ordinary trainer whose data is assigned to that map. This uses
-- the same real trainer parties and BattleSim as optional training battles.
local function undefeatedLocalTrainer(rival)
  local pool=trainerPool(rival)
  if not pool then return nil end
  local ceiling=(rival.levelCeiling and rival:levelCeiling()) or 100
  local function foeLevel(foe)
    local best=0
    for _,mon in ipairs(foe.party or {}) do best=math.max(best,tonumber(mon.level) or 0) end
    return best
  end
  for _,foe in ipairs(pool) do
    if foe.map==rival.map
       and not (rival.hasDefeatedTrainer and rival:hasDefeatedTrainer(foe.id))
       and foeLevel(foe)<=ceiling+8 then
      return foe
    end
  end
  return nil
end

local function fightRequiredTrainer(rival,foe)
  if not foe then return true end
  if rival.prepareForBattle then rival:prepareForBattle() end
  local result=BattleSim.run(rival.ctx.data,rival.party,foe.party,rival.rng)
  for i,slot in ipairs(rival.party) do
    if result.aHp and result.aHp[i] then slot.hp=result.aHp[i] end
  end
  local won=result.winner=="a"
  creditTeam(rival,won)
  if won then
    rival:defeatedTrainer(foe.id)
    pcall(function() Happiness.noteTrainerBattle(rival,true,foe.name or foe.id) end)
    rival.campaignTrainerWins=rival.campaignTrainerWins or {}
    rival.campaignTrainerWins[foe.id]=true
    local money=math.max(10,math.floor(foe.baseMoney*(1+rival:averageLevel()/10)))
    if rival.earn then rival:earn(money) else rival.money=(rival.money or 0)+money end
    rival:gainExp(math.floor(30+rival:averageLevel()*4))
    return true
  end
  pcall(function() Happiness.noteTrainerBattle(rival,false,foe.name or foe.id) end)
  pcall(function() Happiness.noteFaints(rival) end)
  rival:gainExp(math.floor(10+rival:averageLevel()*2))
  if rival.isFainted and rival:isFainted() and rival.blackoutToNearestPokemonCenter then
    rival:blackoutToNearestPokemonCenter("lost while clearing the route")
  elseif rival.healthFraction and rival:healthFraction()<0.45 then
    rival:setState("HEALING","recovering from a route trainer")
  end
  return false
end

-- ------------------------------------------------------------------
-- Trades and rematches (1.15.0)
-- ------------------------------------------------------------------

-- Two rivals with duplicate PC Pokemon occasionally swap one each.  The
-- result is LOCAL -- both keep their mon counts, just with the other's
-- species -- and the player just hears about it in the news.
function Simulation.tryTrade(rivals, world)
  if not rivals or #rivals < 2 then return nil end
  local function dupSpecies(r)
    local seen = {}
    for _, s in ipairs(r.party or {}) do
      if s and s.species then seen[s.species] = true end
    end
    for _, box in ipairs(r.pcBoxes or {}) do
      for _, s in ipairs(box) do
        if s and s.species then
          if seen[s.species] then return s.species end
          seen[s.species] = true
        end
      end
    end
    return nil
  end
  local pool = {}
  for _, r in ipairs(rivals) do
    if r.id ~= (world and world.companionId)
       and r.map and not (r.map == "OAKS_LAB" or r.map == "PALLET_TOWN")
       and (r.rivalFightCooldown or 0) <= 0
       and (r.state == "IDLE" or r.state == "TRAINING" or r.state == "EXPLORING"
            or r.state == "LEAGUE_READY") and dupSpecies(r) then
      pool[#pool + 1] = r
    end
  end
  if #pool < 2 then return nil end
  -- Traders must physically be together. Random selection prevents the first
  -- two roster entries from monopolising every trade.
  local pairs_ = {}
  for i = 1, #pool - 1 do
    for j = i + 1, #pool do
      if pool[i].map == pool[j].map then pairs_[#pairs_ + 1] = { pool[i], pool[j] } end
    end
  end
  if #pairs_ == 0 then return nil end
  -- 1.33.0: rivals trade with people they get on with.  A pair that both
  -- willCooperate is offered twice, so warmth changes who meets whom without
  -- ever making a hostile trade impossible -- two rivals in a feud can still
  -- swap a duplicate, it is just far less likely.
  local weighted = {}
  for _, entry in ipairs(pairs_) do
    weighted[#weighted + 1] = entry
    local x, z = entry[1], entry[2]
    if not (world and world.relationships == false)
       and x.willCooperateWith and z.willCooperateWith
       and x:willCooperateWith(z.id, world and world.tick)
       and z:willCooperateWith(x.id, world and world.tick) then
      weighted[#weighted + 1] = entry
    end
  end
  if #weighted > 0 then pairs_ = weighted end
  local chooser = pool[1].rng
  local pair = pairs_[chooser:int(1, #pairs_)]
  local a, b = pair[1], pair[2]
  local x, y = dupSpecies(a), dupSpecies(b)
  if not (x and y) then return nil end
  local function takeOne(r, species)
    for _, box in ipairs(r.pcBoxes or {}) do
      for i, s in ipairs(box) do
        if s.species == species and not s.ace and not s.attached then
          return table.remove(box, i)
        end
      end
    end
    return nil
  end
  local ax, by = takeOne(a, x), takeOne(b, y)
  if ax and by then
    ax.ace, ax.attached, ax.attachment = nil, nil, nil
    by.ace, by.attached, by.attachment = nil, nil, nil
    a:storePokemon(by)
    b:storePokemon(ax)
    a:considerAttachment(by, "rival_trade")
    b:considerAttachment(ax, "rival_trade")
    a:refreshAce(); b:refreshAce()
    -- A completed trade is a favour in both directions.
    local aChanged, aState, bChanged, bState
    local bonded = not (world and world.relationships == false)
    if bonded and a.recordRelationship then
      local _, _, after, changed = a:recordRelationship(b.id, "TRADED",
        { tick = world and world.tick, lead = a:relationshipLead(b) })
      aState, aChanged = after, changed
    end
    if bonded and b.recordRelationship then
      local _, _, after, changed = b:recordRelationship(a.id, "TRADED",
        { tick = world and world.tick, lead = b:relationshipLead(a) })
      bState, bChanged = after, changed
    end
    if world and world.log then
      world.log(a, { kind = "trade", with = b.id, gave = x, got = y })
      if aChanged then world.log(a, { kind = "relationship", with = b.id, state = aState }) end
      if bChanged then world.log(b, { kind = "relationship", with = a.id, state = bState }) end
    end
    return { a = a.id, b = b.id, gave = x, got = y, aState = aState, bState = bState }
  end
  return nil
end

-- After the League a rival occasionally rematches a leader it has beaten,
-- for money and exp.  Nothing is invented: it is a real BattleSim against
-- the leader's actual party.
function Simulation.attemptRematch(rival)
  if (rival.rematchCooldown or 0) > 0 then return nil end
  local cls = rival.pickRematch and rival:pickRematch()
  if not cls then return nil end
  local data = rival.ctx.data
  local party = BattleSim.leaderParty(data, cls, 1)
  if not party or #party == 0 then return nil end
  if rival.prepareForBattle then rival:prepareForBattle() end
  local result = BattleSim.run(data, rival.party, party, rival.rng)
  for i, slot in ipairs(rival.party) do
    if result.aHp and result.aHp[i] then slot.hp = result.aHp[i] end
  end
  local won = result.winner == "a"
  creditTeam(rival, won)
  local money = 0
  if won then
    money = math.max(10, math.floor(60 + rival:averageLevel() * 6))
    if rival.earn then rival:earn(money)
    else rival.money = (tonumber(rival.money) or 0) + money end
    rival.confidence = Util.clamp((rival.confidence or 1) + 0.06, 0.5, 2.0)
    rival:gainExp(math.floor(50 + rival:averageLevel() * 5))
  else
    rival.confidence = Util.clamp((rival.confidence or 1) - 0.06, 0.5, 2.0)
  end
  rival.rematchCooldown = 40
  return { won = won, trainer = cls, money = money, turns = result.turns }
end

-- ------------------------------------------------------------------
-- One rival, one tick
-- ------------------------------------------------------------------

-- `ctx` carries the per-tick world view and the tick's remaining allowances:
--   { playerMap, playerParty, tick, allowGymBattle, near, log }
function Simulation.tickRival(rival, ctx)
  pcall(function() Happiness.tick(rival) end)
  if not rival then return "nil" end
  if rival.recordPokemonCenterVisit then rival:recordPokemonCenterVisit() end
  if rival.takeHmNews and ctx.log then
    for _, event in ipairs(rival:takeHmNews()) do ctx.log(rival, event) end
  end
  if ctx.companionId == rival.id then return "accompanying" end
  rival.ticks = (rival.ticks or 0) + 1
  rival.wonderTradeCooldown = math.max(0,
    (tonumber(rival.wonderTradeCooldown) or 0) - 1)
  local playerLevel = playerLeadLevel(ctx.playerParty)
  if playerLevel then rival.playerPaceLevel = playerLevel end
  -- Remember the player's badges too, so the award-time cap in attemptGym has
  -- a reading even on a path that never passed a world object.
  if tonumber(ctx.playerBadges) then
    rival.playerPaceBadges = math.max(0, math.floor(ctx.playerBadges))
  end
  if rival.useFieldSupplies then rival:useFieldSupplies() end
  -- BREEDER life path: occasional box addition from "breeding" (egg hatch).
  if rival.lifePathId and rival:lifePathId() == "BREEDER"
     and rival.ticks and rival.ticks % 90 == 0
     and rival.addPokemon and rival.storePokemon then
    pcall(function()
      local species = rival.favouriteSpecies and rival:favouriteSpecies()
      if not species and rival.party and rival.party[1] then
        species = rival.party[1].species
      end
      if species then
        local level = 1 + math.floor((rival.badgeCount and rival:badgeCount() or 0) * 1.5)
        local baby = { species = species, level = math.max(1, level) }
        if rival.storePokemon then rival:storePokemon(baby) end
        if rival.creditCareer then rival:creditCareer("bred", 1) end
      end
    end)
  end
  if type(rival.personality) ~= "table" then
    local ps = rival.ctx and rival.ctx.personalities
    rival.personality = (ps and (ps[rival.personalityId] or ps.CHALLENGER))
      or { priorities = { "TRAIN", "EXPLORE" }, wanderChance = 0.1,
           gymConfidence = 0.9, trainRate = 1, healAt = 0.3, partyTarget = 4 }
  end
  if not (rival.ctx and rival.ctx.graph) then
    return "no graph"
  end
  -- Shopping is a location action, not a healing-only action. A healthy rival
  -- passing through a town/Center can replenish balls before the next route.
  if rival.restockBalls then pcall(rival.restockBalls, rival) end
  if rival.isFainted and rival:isFainted() and rival.warpToLastPokemonCenter
     and rival:warpToLastPokemonCenter() then
    rival.objective = "HEAL"
    return "blacked out"
  end

  -- Keep every persisted team legal for the next Gym, including saves made
  -- by older releases before the hard level ceiling existed.
  pcall(function() rival:enforceLevelCeiling() end)

  -- 1.35.0: the narrator runs once per rival tick, BEFORE the state branches
  -- below return early, so a rival parked in one state still has a story. It
  -- reads systems that already exist and stores only milestones, so the cost
  -- is a handful of comparisons -- no sweep, no allocation per rival per tick
  -- beyond the facts table itself.
  -- 2.2.0: drain any career promotion recorded during this tick, here where a
  -- log is actually available. §23: a promotion is worth telling the player
  -- about; the credits that led to it are not.
  if rival.careerPromotion and ctx.log then
    ctx.log(rival, { kind = "career", level = rival.careerPromotion })
    rival.careerPromotion = nil
  end

  if rival.advanceStory then
    local ok, gained, chapter, chapterChanged, _, notable =
      pcall(rival.advanceStory, rival, ctx.tick)
    if ok and ctx.log then
      for _, milestone in ipairs(gained or {}) do
        ctx.log(rival, { kind = "milestone", milestone = milestone.id,
                         notable = milestone.news == true })
      end
      -- the chapter always turns in the UI; only a real phase change is news
      if chapterChanged and notable then
        ctx.log(rival, { kind = "chapter", chapter = chapter })
      end
    end
  end

  -- CHALLENGING_GYM: we are standing in the gym, so fight it.
  if rival.state == "CHALLENGING_GYM" then
    if not ctx.allowGymBattle then return "gym deferred" end
    local outcome = Simulation.attemptGym(rival, ctx.playerMap)
    if outcome and ctx.log then ctx.log(rival, outcome) end
    ctx.gymBattleUsed = true
    return "gym"
  end

  -- CHALLENGING_GHOST: we reached the ghost.  A headless BattleSim fight,
  -- budgeted like a gym battle -- it is the same cost -- and fought here only.
  if rival.state == "CHALLENGING_GHOST" then
    if not ctx.allowGymBattle then return "ghost deferred" end
    local outcome = Simulation.attemptGhost(rival, ctx.playerMap)
    if outcome and ctx.log then
      ctx.log(rival, { kind = "ghost", won = outcome.won, ghost = outcome.ghost })
    end
    ctx.gymBattleUsed = true
    return "ghost"
  end

  if rival.state == "RANGER_MISSION" then
    local manager = rival.ctx and rival.ctx.manager
    local rangers = manager and manager.rangers
    local mission = rangers and rangers.missionForMap(rangers, rival.map)
    if mission and rangers.resolveAIMission then
      rangers:resolveAIMission(rival, mission, world)
      rival:setState("IDLE", "Ranger operation complete")
      rival.objective = "IDLE"
      return "ranger mission"
    end
    rival:setState("IDLE", "Ranger mission unavailable")
    rival.objective = "IDLE"
    return "ranger mission unavailable"
  end

  -- CHALLENGING_RIVAL: we reached the rival we dueled across Kanto for.
  -- Fought headlessly, budgeted like a gym battle, money on the line.
  if rival.state == "CHALLENGING_RIVAL" then
    if not ctx.allowGymBattle then return "duel deferred" end
    local outcome = Simulation.attemptDuel(rival)
    if outcome and ctx.log then
      ctx.log(rival, { kind = "duel", won = outcome.won, vs = outcome.vs,
                       money = outcome.money, dethroned = outcome.dethroned })
      for _, change in ipairs({ outcome.relationship, outcome.targetRelationship }) do
        if change and change.rival then
          ctx.log(change.rival, { kind = "relationship",
                                  with = change.with, state = change.state })
        end
      end
    end
    ctx.gymBattleUsed = true
    return "duel"
  end

  -- Travelling: burn down the hop clock, then move one map.
  if rival.destination and rival.map ~= rival.destination then
    -- The encounter layer owns the grid position of a materialised rival.
    -- Continue simulating activities above and below this block, but never
    -- abstractly hop an on-screen NPC to another map.
    if ctx.near then return "walking" end
    if not rival.route then
      rival.route = rival.routeTo and rival:routeTo(rival.destination)
        or rival.ctx.graph:route(rival.map, rival.destination)
      if not rival.route then
        -- unreachable: drop the destination and let the AI pick again next
        -- objective tick rather than walking on a route that does not exist
        rival.destination = nil
        rival.stuckTicks = (rival.stuckTicks or 0) + 1
        return "unreachable"
      end
    end
    rival.hopClock = (rival.hopClock or hopCost(rival.map, rival)) - 1
    if rival.hopClock > 0 then return "travelling" end

    -- Every badge journey is physical. Before leaving the current map, clear
    -- its actual trainer roster. No teleporting past trainers to reach a gym.
    local requiredFoe=undefeatedLocalTrainer(rival)
    if requiredFoe then
      local cleared=fightRequiredTrainer(rival,requiredFoe)
      if cleared then return "campaign trainer defeated" end
      return "campaign trainer blocked progress"
    end
    rival.campaignClearedMaps=rival.campaignClearedMaps or {}
    rival.campaignClearedMaps[rival.map]=true

    local nextMap = rival:nextHop()
    if not nextMap then
      -- off-route (a warp moved us, a map vanished): re-plan from here
      if rival.ctx and rival.ctx.graph and rival.ctx.graph.route then
        local ok, route = pcall(function()
          return rival.routeTo and rival:routeTo(rival.destination)
            or rival.ctx.graph:route(rival.map, rival.destination)
        end)
        rival.route = ok and route or nil
      else
        rival.route = nil
      end
      rival.hopClock = nil
      rival.stuckTicks = (rival.stuckTicks or 0) + 1
      if rival.stuckTicks > 4 then
        rival.destination = nil
        rival.stuckTicks = 0
      end
      return "replanned"
    end

    -- Revalidate every individual crossing. This catches routes restored from
    -- older saves as well as any objective that was planned before stricter
    -- badge/HM rules were installed. An illegal hop is discarded, never
    -- performed and never charged as an HM use.
    if rival.canEnterMap and not rival:canEnterMap(nextMap) then
      rival.destination, rival.route, rival.routeIndex = nil, nil, 1
      rival.hopClock = nil
      rival:setState("IDLE", "progression gate blocked the route")
      return "route gated"
    end

    rival.arrivedFrom = rival.map
    rival.map = nextMap
    if rival.useHMsForMap then rival:useHMsForMap(nextMap) end
    if rival.visitMap then rival:visitMap(nextMap) end
  -- 2.2.0 §26: an explorer's progress IS arriving somewhere new. Credited off
  -- the arrival that already happens, from the navigation atlas that already
  -- records it -- no new counter, and no way for the two to disagree.
  if rival.creditCareer and rival.familiarity and rival:familiarity(nextMap) == 0 then
    rival:creditCareer("areas", 1)
  end
    rival.x, rival.y = nil, nil    -- abstract: no grid position off screen
    rival.hopClock = hopCost(nextMap, rival)
    rival.stuckTicks = 0
    rival.path = nil

    if rival.map == rival.destination then
      AI.onArrive(rival, ctx)
    end
    return "hopped"
  end

  -- Already standing where it decided to go.  A hop lands via AI.onArrive
  -- below, but a destination the rival was ALREADY on makes no hop at all, so
  -- the arrival has to be recognised here or the rival never leaves the
  -- travel state and never starts doing the thing it travelled for.
  if rival:atDestination() and TRAVEL_STATES[rival.state] then
    AI.onArrive(rival, ctx)
  end

  -- Keep the player's current badge count authoritative. Rivals may range
  -- from three behind to three ahead. Falling three behind does not grant
  -- badges or levels: it only suppresses optional idling/exploration so the
  -- rival works through the same roads, trainers, catches and gyms faster.
  if tonumber(ctx.playerBadges) then
    rival.playerPaceBadges=math.max(0,math.floor(ctx.playerBadges))
  end
  local badgeGap=(rival:badgeCount())-(rival:playerBadges())
  rival.catchUpMode=badgeGap<=-(rival.BADGE_TRAIL or 3)
  if rival.slump then
    -- Slumps reduce optional aggression/wandering without granting or removing
    -- progress. The rival can still heal, train, travel and eventually recover.
    rival.catchUpMode=false
  end

  -- At the destination and working.
  if rival.state == "TRAINING" then
    -- 1.36.0 §14: a training rival may settle into a CAMP -- stay put long
    -- enough that the player can find it in the same place twice. This is not
    -- a new activity (it trains either way); it is a rival choosing to stop
    -- moving, which is what makes the world feel inhabited rather than a set
    -- of drifting dots. The camp only suppresses re-routing; every other rule
    -- below still applies, including the visible-training ban.
    if (rival.campTicks or 0) > 0 then
      rival.campTicks = rival.campTicks - 1
      if rival.campTicks <= 0 then
        rival.campTicks, rival.campMap = nil, nil
        rival.stateReason = "breaking camp"
      end
    elseif rival.campCooldown and rival.campCooldown > 0 then
      rival.campCooldown = rival.campCooldown - 1
    elseif Presence.campWorthy({ map = rival.map,
                                 -- a camp is only legal where training is:
                                 -- the same wild-encounter rule the branch
                                 -- below enforces, asked before settling
                                 canTrain = mapHasWildEncounters(rival),
                                 camping = rival.campTicks ~= nil })
           and rival.rng:chance(0.05) then
      rival.campTicks = Presence.campDuration(rival.rng)
      rival.campMap = rival.map
      rival.campCooldown = 600
      rival.stateReason = "made camp"
      if ctx.log then
        ctx.log(rival, { kind = "camp", map = rival.map })
      end
    end
    -- 1.35.0: §4's TRAINING beat. A rival that answers a defeat by going and
    -- working reads as DETERMINED rather than FRUSTRATED the next time the
    -- player meets it.
    if rival.noteTrained then rival:noteTrained(ctx.tick) end
    -- Visible rivals must never gain abstract EXP while standing on pavement,
    -- beside a building, or in front of the player. Off-screen training is
    -- permitted only on a map with a real encounter table (i.e. a route/cave
    -- where grass or wild encounters actually exist).
    if ctx.near then return "visible training paused" end
    if not mapHasWildEncounters(rival) then
      rival.destination, rival.route = nil, nil
      rival:setState("IDLE", "looking for a wild training area")
      pcall(AI.evaluate, rival, ctx)
      return "seeking encounter map"
    end
    rival.trainingTicks = (rival.trainingTicks or 0) + 1
    -- One simulator update represents decision time, not one completed wild
    -- battle. A rival is processed roughly every three seconds at normal pace;
    -- awarding EXP on every visit compressed about 100 battles into five
    -- minutes. Four visits now make one honest training encounter.
    if rival.trainingTicks % 4 ~= 0 then return "training interval" end
    local events = rival:gainExp(trainingExp(rival, ctx.playerMap))
    trainingWear(rival)
    -- 1.11.0: a training rival sometimes fights a local trainer for money,
    -- which is what pays for the Poké Balls it catches with.  Rare, and on
    -- its own cooldown so it never dominates a session.
    if (rival.trainerBattleCooldown or 0) > 0 then
      rival.trainerBattleCooldown = rival.trainerBattleCooldown - 1
    end
    if (rival.trainerBattleCooldown or 0) <= 0
       and rival.rng:chance(rival.personality.trainerBattleChance or 0.06) then
      local tb = Simulation.tryTrainerBattle(rival)
      if tb then
        rival.trainerBattleCooldown = 24
        if ctx.log then
          ctx.log(rival, { kind = "trainer_battle", won = tb.won,
                           trainer = tb.trainer, money = tb.money })
        end
      end
    end
    local caught, caughtSlot = tryCatch(rival)
    if rival.catchUpMode and not caught and rival.rng:chance(0.35) then
      caught, caughtSlot = tryCatch(rival)
    end
    if caught then
      -- 5.2.0 RIVAL HUNTING PRESSURE. This is the half of the ecology the
      -- player never watches happen: a HARVESTER working Route 3 for an hour
      -- thins it out whether or not anybody is there to see, which is what
      -- makes the world feel inhabited rather than staged. Weighted above a
      -- player catch because a rival takes several while the player takes one.
      --
      -- Routed through Ecology:record like every other pressure event -- one
      -- door, and a static test forbids writing the table anywhere else.
      if ctx.ecology and ctx.ecology.record then
        pcall(function()
          ctx.ecology:record(rival.map, caught, "rivalCatch", ctx.tick or 0)
        end)
      end
      -- HARVESTER bookkeeping: what this rival has personally met here. Kept
      -- on the rival because it is a fact about the rival, not the route.
      if rival.map then
        rival.seenHere = rival.seenHere or {}
        if rival.seenHereMap ~= rival.map then
          rival.seenHere, rival.seenHereMap = {}, rival.map
        end
        rival.seenHere[caught] = true
      end
    end
    if caught and ctx.log then
      ctx.log(rival, { kind = "caught", species = caught })
      if caughtSlot and caughtSlot.ace then
        ctx.log(rival, { kind = "ace", species = caught,
          reason = caughtSlot.shiny and "shiny" or "bond" })
      end
      if rival.hmGoal and rival.canUseHM and rival:canUseHM(rival.hmGoal) then
        rival.hmGoal, rival.hmGoalForced = nil, false
      end
      local milestone = rival.dexMilestone and rival:dexMilestone()
      if milestone then
        ctx.log(rival, { kind = "dex", milestone = milestone })
      end
    end
    -- 1.15.0: occasionally pick something to hunt for the Pokédex
    if not rival.huntTarget and rival.pickHuntTarget and rival.rng:chance(0.05) then
      local target = rival:pickHuntTarget()
      if target and ctx.log then
        ctx.log(rival, { kind = "hunt", species = target })
      end
    end
    -- 1.14.0: training in the world occasionally turns up a TM, which the
    -- rival then teaches to the best suitable Pokemon.
    if rival.findTm and rival.rng:chance(0.02) then
      local move = rival:findTm()
      if move and ctx.log then
        ctx.log(rival, { kind = "tm_found", move = move })
      end
    end
    -- TMs remain in the bag until a Poké Center visit. Teaching them during
    -- route training made PC/move management happen invisibly in the grass.
    if rival.useRareCandy then
      local slot, events = rival:useRareCandy()
      if slot and ctx.log then
        ctx.log(rival, { kind = "candy", species = slot.species, level = slot.level })
        for _, event in ipairs(events or {}) do ctx.log(rival, event) end
      end
    end
    if ctx.log then
      for _, ev in ipairs(events) do ctx.log(rival, ev) end
    end
    -- re-evaluate every few ticks so a rival that is now strong enough stops
    -- grinding and goes to the gym
    if rival.trainingTicks % 4 == 0 then pcall(AI.evaluate, rival, ctx) end
    return "training"
  end

  if rival.state == "HEALING" then
    rival:heal()
    if rival.managePC then rival:managePC() end
    -- A remembered loss can influence the next team, but PC withdrawals occur
    -- only here. Player challenges elsewhere never trigger a Center detour.
    if rival.counterTarget and rival.prepareCounterTeam then
      rival:prepareCounterTeam(rival.counterTarget)
    else
      local gym, badge = rival:nextGym()
      local leaderParty = gym and BattleSim.leaderParty(rival.ctx.data,
        gym.class, gym.party or 1)
      if badge and leaderParty and #leaderParty > 0
         and rival.gymTeamPreparedFor ~= badge then
        rival:swapTeamForGym(leaderParty)
        rival:applyTms(leaderParty, true)
        rival.gymTeamPreparedFor = badge
      end
    end
    -- Town / center stop: top up Poké Balls so later training can catch.
    if rival.restockBalls then
      local bought = rival:restockBalls()
      if bought and bought > 0 and ctx.log then
        ctx.log(rival, { kind = "bought_balls", count = bought })
      end
    end
    -- 1.14.0: at the mart the rival also buys a TM, sells duplicate PC
    -- Pokemon, and teaches any TMs it is holding.
    if rival.buyTms then
      local move = rival:buyTms()
      if move and ctx.log then
        ctx.log(rival, { kind = "tm_bought", move = move })
      end
    end
    -- Give the Wonder Trader first refusal on a boxed duplicate; ordinary
    -- duplicate sales happen afterwards if no trade occurs.
    if rival.wonderTradeDuplicate and (rival.wonderTradeCooldown or 0) <= 0
        and rival.rng:chance(0.25) then
      local trade = rival:wonderTradeDuplicate()
      if trade then
        rival.wonderTradeCooldown = 80
        if ctx.log then
          ctx.log(rival, { kind="wonder_trade", gave=trade.gave, got=trade.got })
          if trade.slot and trade.slot.ace then
            ctx.log(rival, { kind="ace", species=trade.got, reason="shiny trade" })
          end
        end
      end
    end
    if rival.sellDuplicates then
      local money, count = rival:sellDuplicates()
      if money and money > 0 and ctx.log then
        ctx.log(rival, { kind = "sold", money = money, count = count or 0 })
      end
    end
    if rival.applyTms then
      for _, move in ipairs(rival:applyTms(nil, true)) do
        if ctx.log then ctx.log(rival, { kind = "tm_learned", move = move }) end
      end
    end
    pcall(AI.evaluate, rival, ctx)
    return "healed"
  end

  if rival.state == "EXPLORING" or rival.state == "IDLE"
     or rival.state == "RETURNING_FROM_GYM" or rival.state == "DEFEATED"
     or rival.state == "SEEKING_PLAYER" or rival.state == "CHALLENGING_PLAYER" then
    pcall(AI.evaluate, rival, ctx)
    return "evaluated"
  end

  if rival.state == "LEAGUE_READY" then
    -- 1.7.0: periodic simulated League runs.  Still honest — uses the same
    -- BattleSim as gyms against scaled tough parties.  Success sets champion.
    -- 1.39.0: THE ESCALATING GATE.
    --
    -- This branch used to be a flat 16-tick cooldown and nothing else, so a
    -- rival whose team the Elite Four could beat attempted the League 1500
    -- times over ten hours and lost all 1500 -- the identical bug the Gym path
    -- had in the original build and had fixed, in a path written from the same
    -- template and never revisited.
    --
    -- Now a failure records WHERE it fell, lengthens the wait, and raises a
    -- strength bar the rival has to clear before walking back in. A rival that
    -- goes away and trains gets straight back; one that does not, waits.
    local record = rival.ensureLeague and rival:ensureLeague()
    if record then League.tick(record) end
    if (rival.leagueCooldown or 0) > 0 then
      rival.leagueCooldown = rival.leagueCooldown - 1
    end
    local ready = (rival.leagueCooldown or 0) <= 0
      and (not record or rival:mayAttemptLeague())
    if ready and ctx.allowGymBattle then
      local outcome = Simulation.attemptLeague(rival, ctx.playerMap)
      if outcome and ctx.log then
        ctx.log(rival, { kind = "league", won = outcome.won, turns = outcome.turns,
                         qualified = outcome.qualified == true,
                         stage = outcome.stage, attempts = record and record.attempts })
      end
      ctx.gymBattleUsed = true
      if outcome and outcome.won then
        return "league win"
      end
      -- §28: having failed, go and train rather than loitering at the door.
      if outcome and not outcome.won and rival.setState then
        rival:setState("TRAINING", "preparing for another League run")
      end
    end
    -- 1.15.0: a champion or retired rival occasionally rematches a leader it
    -- has beaten, for money and exp, when no League run is due this tick.
    if not ctx.gymBattleUsed then
      if (rival.rematchCooldown or 0) > 0 then
        rival.rematchCooldown = rival.rematchCooldown - 1
      end
      if (rival.rematchCooldown or 0) <= 0 and rival.rng:chance(0.08) then
        local rm = Simulation.attemptRematch(rival)
        if rm and ctx.log then
          ctx.log(rival, { kind = "rematch", won = rm.won,
                           trainer = rm.trainer, money = rm.money })
        end
      end
    end
    rival:gainExp(math.floor(trainingExp(rival, ctx.playerMap) * 0.4))
    return "league"
  end

  pcall(AI.evaluate, rival, ctx)
  return "evaluated"
end

-- ------------------------------------------------------------------
-- The world tick
-- ------------------------------------------------------------------

function Simulation.new(opts)
  return setmetatable({
    accumulator = 0,
    tick = 0,
    cursor = 1,
    budget = (opts and opts.budget) or 2,
    socialInterval = (opts and opts.socialInterval) or 1,
    tickSeconds = (opts and opts.tickSeconds) or Simulation.TICK_SECONDS,
    counters = { ticks = 0, rivalUpdates = 0, gymBattles = 0, paths = 0 },
  }, { __index = Simulation })
end

-- Called from the core.update hook.  Returns true when a tick actually ran,
-- which is what the debug overlay counts.
function Simulation:update(dt, rivals, world)
  self.accumulator = self.accumulator + (tonumber(dt) or 0)
  if self.accumulator < self.tickSeconds then return false end
  self.accumulator = self.accumulator - self.tickSeconds
  -- a long stall (a load, a suspended app) must not replay an hour of Kanto
  -- in one frame; drop the backlog rather than catching up
  if self.accumulator > self.tickSeconds * 4 then self.accumulator = 0 end
  return self:runTick(rivals, world)
end

function Simulation:runTick(rivals, world)
  self.tick = self.tick + 1
  self.counters.ticks = self.counters.ticks + 1
  world = world or {}
  world.tick = self.tick

  local n = #rivals
  if n == 0 then return true end

  -- Center healing is immediate maintenance, not a budgeted AI decision. With
  -- a 100-rival roster the round-robin cursor can take a long time to revisit
  -- one rival; a fainted rival already standing at a Center must not remain at
  -- zero HP while waiting for its turn.
  for _, r in ipairs(rivals) do
    local atCenter = r and r.isAtPokemonCenter and r:isAtPokemonCenter()
    if atCenter then
      if r.recordPokemonCenterVisit then r:recordPokemonCenterVisit() end
      if r.isFainted and r:isFainted() and r.heal then
        r:heal()
        r.objective = "HEAL"
        r:setState("HEALING", "using the Poké Center")
      end
    end
  end

  -- age per-rival cooldowns that are independent of the budget cursor
  for _, r in ipairs(rivals) do
    if (r.rivalFightCooldown or 0) > 0 then
      r.rivalFightCooldown = r.rivalFightCooldown - 1
    end
  end

  local ctx = {
    playerMap = world.playerMap,
    playerParty = world.playerParty,
    -- 3.2.0: this was MISSING. Can.GYM caps a rival at the configured badge lead of the
    -- player and reads `world.playerBadges` -- but the per-tick ctx built here
    -- never carried it, so every evaluation on the simulation path saw nil and
    -- fell back to 0. The manager's own worldView() has always had it, so the
    -- cap worked from main.lua and silently did not from the tick that runs
    -- most of the time.
    playerBadges = world.playerBadges,
    compat = world.compat,
    rivals = world.rivals,
    tick = self.tick,
    companionId = world.companionId,
    log = world.log,
    -- 5.2.0: the live population, so a rival's catches press on the same
    -- table the player's encounters do. Carried on the per-tick ctx for the
    -- reason 3.2.0's comment above records -- the manager's worldView and
    -- this ctx are two different tables, and a field present in one and
    -- missing from the other is how the badge cap silently died.
    ecology = world.ecology,
    allowGymBattle = true,
    gymBattleUsed = false,
  }

  local processed = 0
  local visited = 0
  while processed < self.budget and visited < n do
    if self.cursor > n then self.cursor = 1 end
    local rival = rivals[self.cursor]
    self.cursor = self.cursor + 1
    visited = visited + 1
    if rival then
      ctx.near = (world.playerMap ~= nil and rival.map == world.playerMap)
      ctx.allowGymBattle = not ctx.gymBattleUsed
      local ok = Util.guard("tick:" .. tostring(rival.id),
                            Simulation.tickRival, rival, ctx)
      if ok then
        processed = processed + 1
        self.counters.rivalUpdates = self.counters.rivalUpdates + 1
        if ctx.gymBattleUsed then
          self.counters.gymBattles = self.counters.gymBattles + 1
        end
      end
    end
  end

  -- 4.6.0: title-match cooldowns age every tick, like every other cooldown
  -- that must run whether or not the budget cursor reached that rival.
  for _, r in ipairs(rivals) do
    if r and r.ensureLeague then
      local record = r:ensureLeague()
      if record then League.tickTitle(record) end
    end
  end

  -- 1.7.0: at most one rival-vs-rival skirmish per world tick
  if not ctx.gymBattleUsed and self.tick % self.socialInterval == 0 then
    local blueEvent
    if self.manager and not (self.manager.data and self.manager.data.gen2Trainers)
       and not world.playerChampion then
      BlueChampion.tick(self.manager)
      blueEvent=Util.guard("blue-title",BlueChampion.tryTitleMatch,self.manager,world)
      if not blueEvent then
        blueEvent=Util.guard("blue-qualify",BlueChampion.tryQualify,self.manager,world)
      end
    end
    if blueEvent then return true end
    -- 4.6.0: the crown first. A qualified challenger meeting the champion is
    -- the biggest fight available, and it uses the same one-social-event-per
    -- -tick budget rather than adding a second: a title match happening on the
    -- same tick as a skirmish would double the simulated battles per tick,
    -- which is the number the performance budget is actually about.
    local titled = Util.guard("title", Simulation.tryTitleMatch, rivals, world)
    if not titled then
      local skirmished = Util.guard("skirmish", Simulation.tryRivalSkirmish, rivals, world)
      -- 1.15.0: if nobody fought, two rivals might trade duplicates instead
      if not skirmished then
        Util.guard("trade", Simulation.tryTrade, rivals, world)
      end
    end
  end

  return true
end

Simulation.trainingExp = trainingExp
Simulation.hopCost = hopCost
Simulation.tryCatch = tryCatch
Simulation.tryTrainerBattle = tryTrainerBattle
Simulation.trainerPool = trainerPool

return Simulation
