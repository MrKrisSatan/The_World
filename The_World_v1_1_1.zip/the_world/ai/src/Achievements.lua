local req, mod = ...

-- WHAT A RIVAL HAS ACTUALLY DONE (4.6.0).
--
-- The TRAINER RANKINGS screen opens onto one of these per trainer: badges,
-- League progress, the Pokemon they are known for, the shape of their career,
-- who they measure themselves against, and the handful of deeds worth listing.
--
-- DERIVED, NOT LOGGED.
--
-- The obvious way to build this is a per-rival list of achievement strings
-- appended as things happen. That is a second copy of the world: it can drift
-- from the badge case, it grows without bound, and every new event type needs
-- a matching write at whatever site raises it -- which is how a system ends up
-- claiming a rival beat Brock after a save edit removed the badge.
--
-- So nothing here is stored. A highlight is a sentence about a fact that
-- already exists somewhere authoritative: `rival.badges` joined to the gym
-- table gives "Defeated Brock", the League record gives the Elite Four and the
-- title defences, the party and boxes give the notable captures. The record is
-- recomputed every time the screen opens and cannot disagree with the world.
--
-- The one number this feature needed that did NOT already exist is
-- `record.defences` -- a count of title defences, which is an event and not a
-- state, so it is counted where it happens (src/League.lua) rather than
-- guessed at here.
--
-- Pure and duck-typed: every input is read through a guarded accessor, so the
-- suites drive it with plain tables and the game drives it with live Rivals.

local Achievements = {}

Achievements.MAX_HIGHLIGHTS = 14
Achievements.MAX_RIVALRIES = 4

-- Which one-sided states count as "a rivalry worth naming" on the record.
Achievements.RIVALRY_STATES = {
  RIVALRY = 3, NEMESIS = 4, HOSTILE = 2, ARCH_RIVALS = 3, COMPETITIVE = 1,
}

local function isTable(v) return type(v) == "table" end

local function call(obj, name, ...)
  if not (isTable(obj) and type(obj[name]) == "function") then return nil end
  local ok, value = pcall(obj[name], obj, ...)
  if ok then return value end
  return nil
end

local function spaced(id)
  return (tostring(id or ""):gsub("_", " "))
end

local function titleCase(text)
  return (tostring(text or ""):gsub("(%a)([%w']*)", function(head, tail)
    return head:upper() .. tail:lower()
  end))
end

function Achievements.badges(rival)
  local n = call(rival, "badgeCount")
  if tonumber(n) then return math.floor(tonumber(n)) end
  return nil
end

-- Every Pokemon this rival is holding, party first and then the boxes, so a
-- capture that has been deposited is still a capture.
function Achievements.collection(rival)
  local out = {}
  for _, slot in ipairs(isTable(rival) and rival.party or {}) do
    if isTable(slot) then out[#out + 1] = slot end
  end
  for _, box in ipairs(isTable(rival) and rival.pcBoxes or {}) do
    for _, slot in ipairs(isTable(box) and box or {}) do
      if isTable(slot) then out[#out + 1] = slot end
    end
  end
  return out
end

-- ------------------------------------------------------------------
-- The League half
-- ------------------------------------------------------------------

-- "Defeated" / "Reached stage 3" / "Not yet". Three different facts, and the
-- middle one is the interesting one: a rival that keeps falling at Lance has a
-- story, and reporting that as "Not yet" throws it away.
function Achievements.eliteFour(record, champion)
  if not isTable(record) then
    return champion and "Defeated" or "Not yet"
  end
  local clears = math.floor(tonumber(record.clears) or 0)
  local attempts = math.floor(tonumber(record.attempts) or 0)
  local best = math.floor(tonumber(record.bestStage) or 0)
  if clears > 0 or champion then return "Defeated" end
  if attempts > 0 and best > 0 then return "Reached " .. best end
  if attempts > 0 then return "Attempted" end
  return "Not yet"
end

function Achievements.defences(record)
  if not isTable(record) then return 0 end
  return math.max(0, math.floor(tonumber(record.defences) or 0))
end

-- ------------------------------------------------------------------
-- Career
-- ------------------------------------------------------------------

-- "Trainer -> Champion". A path with the arrow drawn between the stages this
-- rival actually reached, never a plan: a rival that has not cleared the
-- League gets "Trainer", because that is what they are.
function Achievements.career(rival, opts)
  opts = opts or {}
  local steps = { "Trainer" }
  local pathLabel = opts.lifePathLabel
  if type(pathLabel) == "string" and pathLabel ~= ""
     and pathLabel:lower() ~= "gym challenge" then
    steps[#steps + 1] = pathLabel
  end
  local rank = opts.careerRank or call(rival, "careerRank")
  if type(rank) == "string" and rank ~= "" then
    steps[#steps + 1] = titleCase(rank)
  end
  if isTable(rival) and rival.champion == true then
    steps[#steps + 1] = "Champion"
  elseif opts.formerChampion then
    steps[#steps + 1] = "Former Champion"
  end
  return table.concat(steps, " -> ")
end

-- ------------------------------------------------------------------
-- Rivalries
-- ------------------------------------------------------------------

-- Who this rival measures themselves against, strongest first. Reads the
-- bonds that already exist rather than keeping a list: a rivalry that cooled
-- off disappears from the record by itself, which is correct.
function Achievements.rivalries(rival, opts)
  opts = opts or {}
  local names = isTable(opts.names) and opts.names or {}
  local tick = opts.tick
  local rows = {}
  local bonds = isTable(rival) and rival.bonds or nil
  if not isTable(bonds) then return rows end
  for id in pairs(bonds) do
    local state = call(rival, "relationshipTo", id, tick)
    local weight = state and Achievements.RIVALRY_STATES[state]
    if weight then
      local bond = call(rival, "bondWith", id, tick) or {}
      rows[#rows + 1] = {
        id = id,
        name = id == "player" and (opts.playerName or "Player")
          or names[id] or titleCase(spaced(id)),
        state = state,
        weight = weight,
        heat = math.floor(tonumber(bond.rivalry) or 0),
      }
    end
  end
  table.sort(rows, function(a, b)
    if a.weight ~= b.weight then return a.weight > b.weight end
    if a.heat ~= b.heat then return a.heat > b.heat end
    return tostring(a.id) < tostring(b.id)
  end)
  while #rows > Achievements.MAX_RIVALRIES do table.remove(rows) end
  return rows
end

-- ------------------------------------------------------------------
-- Highlights
-- ------------------------------------------------------------------

-- Beaten gym leaders, in ladder order, named from the gym table rather than
-- from a badge id: "Defeated Brock" is what a player remembers, and the join
-- is on the engine's own badge key so a mod that reorders the gyms reorders
-- these too.
function Achievements.gymHighlights(rival, gyms)
  local out = {}
  if not (isTable(rival) and isTable(rival.badges) and isTable(gyms)) then return out end
  for _, badge in ipairs(gyms.order or {}) do
    if rival.badges[badge] then
      local gym = isTable(gyms.byBadge) and gyms.byBadge[badge]
      local leader = gym and gym.leader
      if leader then
        out[#out + 1] = "Defeated " .. titleCase(spaced(leader))
      end
    end
  end
  return out
end

-- Captures worth a line. A species only qualifies by being named in the
-- notable list this build ships (data/notable.lua) or by being shiny: nothing
-- here decides on its own that a Pokemon is impressive, and a boot whose
-- species are unrecognisable simply produces no capture highlights.
function Achievements.captureHighlights(rival, notable)
  local out = {}
  local seen = {}
  local set = {}
  for _, id in ipairs(isTable(notable) and notable or {}) do
    if type(id) == "string" then set[id:upper()] = true end
  end
  for _, slot in ipairs(Achievements.collection(rival)) do
    local species = type(slot.species) == "string" and slot.species:upper() or nil
    if species and not seen[species] then
      if set[species] then
        seen[species] = true
        out[#out + 1] = "Captured " .. titleCase(spaced(species))
      elseif slot.shiny then
        seen[species] = true
        out[#out + 1] = "Caught a shiny " .. titleCase(spaced(species))
      end
    end
  end
  table.sort(out)
  return out
end

function Achievements.leagueHighlights(rival, record)
  local out = {}
  local attempts = isTable(record) and math.floor(tonumber(record.attempts) or 0) or 0
  local clears = isTable(record) and math.floor(tonumber(record.clears) or 0) or 0
  local reigns = isTable(record) and math.floor(tonumber(record.reigns) or 0) or 0
  local defences = Achievements.defences(record)
  if attempts > 0 and clears == 0 then
    out[#out + 1] = "Entered the Elite Four"
  elseif clears > 0 then
    out[#out + 1] = "Cleared the Elite Four"
  end
  if isTable(rival) and rival.champion == true then
    out[#out + 1] = "Became Champion"
  elseif reigns > 0 then
    out[#out + 1] = "Held the title"
  end
  if defences > 0 then
    out[#out + 1] = "Defended title " .. defences
      .. (defences == 1 and " time" or " times")
  end
  if reigns > 1 then
    out[#out + 1] = "Took the title " .. reigns .. " times"
  end
  return out
end

-- The whole list, in the order a career happened: gyms, then captures, then
-- the League. Bounded, and trimmed from the FRONT when it overflows -- the
-- early badges are the part a long career can most afford to lose.
function Achievements.highlights(rival, opts)
  opts = opts or {}
  local out = {}
  local function add(rows)
    for _, line in ipairs(rows) do out[#out + 1] = line end
  end
  add(Achievements.gymHighlights(rival, opts.gyms))
  add(Achievements.captureHighlights(rival, opts.notable))
  add(Achievements.leagueHighlights(rival, opts.league))
  while #out > Achievements.MAX_HIGHLIGHTS do table.remove(out, 1) end
  return out
end

-- ------------------------------------------------------------------
-- The record
-- ------------------------------------------------------------------

function Achievements.record(rival, opts)
  opts = opts or {}
  local record = opts.league
  if record == nil then record = call(rival, "ensureLeague") end
  -- The resolved record has to go BACK into opts before the highlights are
  -- built, or highlights() re-reads opts.league, finds the nil it started
  -- with, and silently reports a champion with no defences and no Elite Four
  -- clear. Resolving a value in one place and reading the unresolved one two
  -- lines later is the whole bug, and the suite caught it.
  opts.league = record
  local champion = isTable(rival) and rival.champion == true
  local badges = Achievements.badges(rival)
  return {
    id = isTable(rival) and rival.id or nil,
    name = (isTable(rival) and rival.name) or opts.name or "TRAINER",
    badges = badges,
    eliteFour = Achievements.eliteFour(record, champion),
    champion = champion,
    defences = Achievements.defences(record),
    -- The ace the rival has actually bonded with, which is the mod's existing
    -- notion of a favourite; nil when they have not formed one yet, never a
    -- stand-in first party slot.
    favourite = call(rival, "favouriteSpecies"),
    career = Achievements.career(rival, opts),
    rivalries = Achievements.rivalries(rival, opts),
    highlights = Achievements.highlights(rival, opts),
  }
end

return Achievements
