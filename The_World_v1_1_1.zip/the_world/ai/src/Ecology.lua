local req, mod = ...
local Util = req("src/Util")

-- AREA POPULATIONS (5.2.0)
-- ==================================================================
-- A route's encounter table stops being the OUTCOME and becomes the CARRYING
-- CAPACITY. What you actually meet is that capacity worked over by everything
-- happening to the animals living there: who has been hunting them, what the
-- sky is doing, what month it is, where the species is migrating, and what
-- the OTHER species on the route are doing in the space left behind.
--
-- The two behaviours Christopher asked for are not two features. They are the
-- same equation read from either end:
--
--   * hunt a species hard and its abundance falls, so it gets rarer -- a
--     species everybody wants becomes temporarily hard to find;
--   * ignore a species and the competition term hands it the share the
--     hunted one gave up, so it flourishes without anyone doing anything.
--
-- DERIVED, NOT STORED. The house rule is "is the fact recoverable from what
-- remains?" A population is not stored -- it is recomputed from the static
-- table plus the pressure events, every time. Only the events are kept,
-- because an encounter that happened is not recoverable from anything else.
--
-- BOUNDED. Pressure decays on a half-life, entries below EPSILON are pruned,
-- and both the map count and the per-map species count are capped. A save
-- that wanders all of Kanto for a hundred hours does not grow without limit.
--
-- ONE DOOR. Every pressure event enters through Ecology:record. Nothing else
-- may write the table -- see tests/ecology_static.py.

local Ecology = {}
Ecology.__index = Ecology

-- Pressure halves every this many ticks. Long enough that a morning spent
-- clearing a route is still felt in the afternoon; short enough that a route
-- you abandoned a week ago has recovered.
Ecology.HALF_LIFE_TICKS = 2400

-- What one event is worth. A confirmed catch REMOVES an animal; an encounter
-- only disturbs one, and a rival sweeping a route removes several without the
-- player seeing any of it.
Ecology.W_ENCOUNTER = 0.25
Ecology.W_CATCH = 1.00
Ecology.W_RIVAL_CATCH = 1.30
Ecology.W_DEFEAT = 0.55

-- How much accumulated pressure it takes to halve a species' abundance.
Ecology.PRESSURE_SCALE = 9

-- A species can be hunted down to a tenth of capacity and no further. A local
-- extinction is not recoverable by the model -- nothing would ever bring it
-- back -- and a route that permanently loses a species is a bug report, not
-- an ecosystem.
Ecology.FLOOR = 0.10
-- And it can bloom to three times capacity when everything favours it.
Ecology.CEILING = 3.0

-- 5.7.0: Ranger protection can actively restore a route instead of merely
-- waiting for the ordinary pressure half-life. Recovery is still bounded and
-- deterministic: no RNG, no population snapshot, only the stored pressure
-- events being allowed to decay faster while somebody is protecting habitat.
Ecology.RANGER_RECOVERY_SCALE = 18
Ecology.MIGRANT_BASE_SHARE = 0.018
Ecology.MIGRANT_MAX_SHARE = 0.12

Ecology.EPSILON = 0.05
Ecology.MAX_MAPS = 96
Ecology.MAX_SPECIES_PER_MAP = 16

-- ------------------------------------------------------------------
-- Pure helpers
-- ------------------------------------------------------------------

local function hash(seed, text)
  local h = 2166136261
  local s = tostring(seed) .. "|" .. tostring(text)
  for i = 1, #s do
    h = (h + s:byte(i) * 16777619) % 4294967296
    h = (h * 31 + 7) % 4294967296
  end
  return h
end

-- 0..1, deterministic.
local function unit(seed, text)
  return hash(seed, text) / 4294967296
end

function Ecology.seasonFor(month)
  month = tonumber(month)
  if not month then return nil end
  if month >= 3 and month <= 5 then return "SPRING" end
  if month >= 6 and month <= 8 then return "SUMMER" end
  if month >= 9 and month <= 11 then return "AUTUMN" end
  return "WINTER"
end

-- WHICH SKY AND WHICH MONTH EACH TYPE LIKES.
--
-- Keyed on the species' own primary type rather than on a per-species table,
-- because a per-species table is 151 rows that would have to be re-derived
-- for Gen 2's 251 and again for any conversion -- §19, a hand-maintained list
-- beside a data table will drift. Type is already in data.pokemon.
local TYPE_WEATHER = {
  WATER = { RAIN = 1.45, STORM = 1.30, SUN = 0.80, SANDSTORM = 0.75, SNOW = 0.90 },
  FIRE = { SUN = 1.50, RAIN = 0.60, STORM = 0.55, SNOW = 0.55, SANDSTORM = 1.10 },
  GRASS = { RAIN = 1.35, SUN = 1.20, SNOW = 0.60, SANDSTORM = 0.70 },
  ELECTRIC = { STORM = 1.60, RAIN = 1.20, SUN = 0.95 },
  ICE = { SNOW = 1.70, HAIL = 1.70, SUN = 0.45, RAIN = 0.95 },
  ROCK = { SANDSTORM = 1.45, RAIN = 0.85, STORM = 0.80 },
  GROUND = { SANDSTORM = 1.40, SUN = 1.15, RAIN = 0.70 },
  BUG = { SUN = 1.30, RAIN = 1.10, SNOW = 0.40, SANDSTORM = 0.70 },
  FLYING = { SUN = 1.20, STORM = 0.55, RAIN = 0.75 },
  GHOST = { FOG = 1.60, STORM = 1.25, SUN = 0.70 },
  POISON = { RAIN = 1.20, FOG = 1.25, SUN = 0.90 },
  PSYCHIC = { FOG = 1.30, STORM = 1.10 },
  DRAGON = { STORM = 1.35, SUN = 1.10 },
  STEEL = { RAIN = 0.85, SANDSTORM = 1.15 },
  DARK = { FOG = 1.35, STORM = 1.15, SUN = 0.75 },
  FAIRY = { SUN = 1.20, FOG = 1.15 },
  NORMAL = {},
  FIGHTING = {},
}

local TYPE_SEASON = {
  WATER = { SUMMER = 1.25, WINTER = 0.80 },
  FIRE = { SUMMER = 1.30, WINTER = 0.70 },
  GRASS = { SPRING = 1.40, SUMMER = 1.20, WINTER = 0.50 },
  BUG = { SPRING = 1.35, SUMMER = 1.45, AUTUMN = 0.85, WINTER = 0.30 },
  ICE = { WINTER = 1.75, AUTUMN = 1.15, SUMMER = 0.40 },
  FLYING = { SPRING = 1.30, AUTUMN = 1.25, WINTER = 0.65 },
  GHOST = { AUTUMN = 1.45, WINTER = 1.10, SPRING = 0.80 },
  DARK = { AUTUMN = 1.30, WINTER = 1.10 },
  ROCK = { SUMMER = 1.10, SPRING = 0.95 },
  GROUND = { SUMMER = 1.20, WINTER = 0.80 },
  ELECTRIC = { SUMMER = 1.25, STORM = 1.0 },
  PSYCHIC = { AUTUMN = 1.15 },
  DRAGON = { SUMMER = 1.15, WINTER = 0.90 },
  POISON = { SUMMER = 1.20, WINTER = 0.70 },
  FAIRY = { SPRING = 1.35, WINTER = 0.85 },
  NORMAL = {},
  FIGHTING = {},
  STEEL = {},
}

function Ecology.primaryType(species, data)
  local def = data and data.pokemon and data.pokemon[species]
  if type(def) ~= "table" then return "NORMAL" end
  local t = def.types
  if type(t) == "table" then return tostring(t[1] or "NORMAL"):upper() end
  return tostring(def.type1 or def.type or "NORMAL"):upper()
end

-- ------------------------------------------------------------------
-- Construction and state
-- ------------------------------------------------------------------

function Ecology.new(ctx)
  return setmetatable({
    ctx = ctx or {},
    maps = {},        -- [mapId] = { [species] = { v = pressure, t = tick } }
    migrations = {},  -- [species] = { [mapId] = { v = displacement, t = tick } }
    adaptations = {}, -- [mapId] = { [species] = { food = id, v = pressure, t = tick } }
    exposures = {},   -- [mapId] = { [species] = { [driver] = {v,t} } }
    ecotypes = {},    -- permanent save-specific local adaptations once established
    capCache = {},
    seed = (ctx and ctx.seed) or 1,
  }, Ecology)
end

-- The CARRYING CAPACITY of a map: the static encounter table, read as a
-- weight per species. Both generations key encounters differently, so this
-- walks whichever shape the boot actually carries -- the same walk
-- Simulation.tryCatch already does, because two walks would disagree (§26).
function Ecology:capacity(mapId, data)
  if not mapId then return nil end
  local cached = self.capCache[mapId]
  if cached ~= nil then return cached ~= false and cached or nil end

  local slots
  local byMap = data and data.encounters and data.encounters[mapId]
  if byMap then
    slots = byMap.slots or byMap.grass or byMap
  else
    local gen2 = data and data.gen2Encounters
    local grass = gen2 and (gen2.grass or gen2.swarmGrass)
      and (gen2.grass or gen2.swarmGrass)[mapId]
    local water = gen2 and gen2.water and gen2.water[mapId]
    slots = (grass and grass.slots) or (water and water.slots)
  end
  if type(slots) ~= "table" then
    self.capCache[mapId] = false
    return nil
  end

  -- A species occupying more slots is commoner, which is exactly what the
  -- vanilla table already encodes. Counting slots reuses that judgement
  -- rather than inventing a second one.
  local cap, total = {}, 0
  for _, slot in ipairs(slots) do
    local species = type(slot) == "table" and slot.species or slot
    if species then
      cap[species] = (cap[species] or 0) + 1
      total = total + 1
    end
  end
  if total == 0 then
    self.capCache[mapId] = false
    return nil
  end
  for species, n in pairs(cap) do cap[species] = n / total end
  self.capCache[mapId] = cap
  return cap
end

-- ------------------------------------------------------------------
-- Pressure -- the only stored quantity
-- ------------------------------------------------------------------

local function decay(value, from, to, halfLife)
  local dt = (tonumber(to) or 0) - (tonumber(from) or 0)
  if dt <= 0 then return value end
  return value * 0.5 ^ (dt / halfLife)
end

function Ecology:pressure(mapId, species, now)
  local byMap = self.maps[mapId]
  local row = byMap and byMap[species]
  if not row then return 0 end
  return decay(row.v or 0, row.t or 0, now or 0, Ecology.HALF_LIFE_TICKS)
end

-- THE ONE DOOR. Every hunting event in the mod arrives here.
--
-- `kind` is one of "encounter", "catch", "rivalCatch", "defeat". They are
-- separate weights rather than one number because the four are genuinely
-- different amounts of harm, and because a report that says "rivals have
-- cleared this route" needs to know which happened.
local WEIGHTS = {
  encounter = Ecology.W_ENCOUNTER,
  catch = Ecology.W_CATCH,
  rivalCatch = Ecology.W_RIVAL_CATCH,
  defeat = Ecology.W_DEFEAT,
}

function Ecology:record(mapId, species, kind, now)
  if not (mapId and species) then return false end
  local weight = WEIGHTS[kind]
  if not weight then return false end
  now = tonumber(now) or 0

  local byMap = self.maps[mapId]
  if not byMap then
    byMap = {}
    self.maps[mapId] = byMap
  end
  local row = byMap[species]
  if row then
    row.v = decay(row.v or 0, row.t or 0, now, Ecology.HALF_LIFE_TICKS) + weight
    row.t = now
  else
    byMap[species] = { v = weight, t = now }
  end
  self:prune(now)
  return true
end

-- Rangers and other habitat-restoration systems use this door to accelerate
-- recovery on a route. This never creates abundance; it only removes a slice
-- of accumulated pressure after first applying the normal time decay.
function Ecology:recover(mapId, strength, now)
  local byMap = self.maps[mapId]
  if not byMap then return false end
  now = tonumber(now) or 0
  strength = math.max(0, tonumber(strength) or 0)
  if strength <= 0 then return false end
  local mult = 0.5 ^ (strength / Ecology.RANGER_RECOVERY_SCALE)
  local changed = false
  for species, row in pairs(byMap) do
    local v = decay(row.v or 0, row.t or 0, now, Ecology.HALF_LIFE_TICKS) * mult
    if v < Ecology.EPSILON then
      byMap[species] = nil
    else
      row.v, row.t = v, now
    end
    changed = true
  end
  if next(byMap) == nil then self.maps[mapId] = nil end
  return changed
end

-- Bounded save (non-negotiable). Decayed-to-nothing rows go; if a map still
-- holds too many species, or too many maps are live, the LEAST pressured go
-- first -- they are the ones whose absence changes the model least.
function Ecology:prune(now)
  now = tonumber(now) or 0
  local liveMaps = {}
  for mapId, byMap in pairs(self.maps) do
    local rows, live = {}, 0
    for species, row in pairs(byMap) do
      local v = decay(row.v or 0, row.t or 0, now, Ecology.HALF_LIFE_TICKS)
      if v < Ecology.EPSILON then
        byMap[species] = nil
      else
        live = live + 1
        rows[#rows + 1] = { species = species, v = v }
      end
    end
    if live > Ecology.MAX_SPECIES_PER_MAP then
      table.sort(rows, function(a, b)
        if a.v ~= b.v then return a.v < b.v end
        return tostring(a.species) < tostring(b.species)
      end)
      for i = 1, live - Ecology.MAX_SPECIES_PER_MAP do
        byMap[rows[i].species] = nil
      end
      live = Ecology.MAX_SPECIES_PER_MAP
    end
    if live == 0 then
      self.maps[mapId] = nil
    else
      local total = 0
      for _, row in ipairs(rows) do total = total + row.v end
      liveMaps[#liveMaps + 1] = { mapId = mapId, v = total }
    end
  end
  if #liveMaps > Ecology.MAX_MAPS then
    table.sort(liveMaps, function(a, b)
      if a.v ~= b.v then return a.v < b.v end
      return tostring(a.mapId) < tostring(b.mapId)
    end)
    for i = 1, #liveMaps - Ecology.MAX_MAPS do
      self.maps[liveMaps[i].mapId] = nil
    end
  end
end

-- ------------------------------------------------------------------
-- Migration
-- ------------------------------------------------------------------
-- A pure function of (world seed, species, season). No stored state and no
-- RNG draw: the same save always has the same species moving the same way in
-- the same month, and two different saves have different ones.
--
-- Each species gets a migration PHASE. In its peak season it concentrates,
-- which means it is commoner on some maps and rarer on others rather than
-- simply commoner everywhere -- a migration that only ever adds is a bonus,
-- not a migration.
function Ecology:migration(species, mapId, season)
  if not (species and mapId and season) then return 1 end
  local phase = hash(self.seed, "migrate:" .. tostring(species)) % 4
  local order = { "SPRING", "SUMMER", "AUTUMN", "WINTER" }
  local peak = order[phase + 1]
  if season ~= peak then
    -- Off-peak everywhere: present, but thinner.
    return 0.85
  end
  -- In its peak season the species concentrates on a seed-chosen share of
  -- maps and thins out on the others.
  local here = unit(self.seed, "migrate:" .. tostring(species) .. ":" .. tostring(mapId))
  if here < 0.35 then return 1.85 end
  return 0.70
end

-- ------------------------------------------------------------------
-- Rocket displacement and ecological adaptation
-- ------------------------------------------------------------------
-- Rocket operations are allowed to change WHERE a species lives, not merely
-- how many are caught. These are separate, bounded events so the ordinary
-- hunting-pressure model remains intact and old saves need no migration data.
Ecology.MIGRATION_HALF_LIFE_TICKS = 1800
Ecology.ADAPTATION_HALF_LIFE_TICKS = 3600
Ecology.MAX_MIGRATION_SPECIES = 16
Ecology.MAX_ADAPTATIONS_PER_MAP = 16

-- 5.8.0: repeated local conditions can cross a threshold and establish a
-- persistent ecotype. Exposure itself fades; the resulting ecotype does not.
Ecology.EXPOSURE_HALF_LIFE_TICKS = 4800
Ecology.ECOTYPE_THRESHOLD = 12
Ecology.MAX_ECOTYPES = 48
local ADAPTATION_DRIVERS = {
  RAIN="WETLAND", STORM="STORM", SUN="HEAT", SNOW="COLD", HAIL="COLD",
  FOG="FOG", SANDSTORM="DUST", SMOG="POLLUTION", ACID_RAIN="POLLUTION",
}

-- How plausible is a connected route as a refuge for a displaced species?
-- We deliberately derive this from the destination's real encounter table.
-- Matching primary types imply compatible food/terrain; a route with no wild
-- table is a poor refuge but remains possible, so conversions are not blocked.
function Ecology:habitatSuitability(species, mapId, data)
  local cap = self:capacity(mapId, data)
  if not cap then return 0.35 end
  if cap[species] then return 1.35 end
  local wanted = Ecology.primaryType(species, data)
  local matching, total = 0, 0
  for resident, share in pairs(cap) do
    total = total + share
    if Ecology.primaryType(resident, data) == wanted then matching = matching + share end
  end
  if total <= 0 then return 0.35 end
  local affinity = matching / total
  return 0.55 + affinity * 0.70
end

function Ecology:chooseMigrationDestination(species, fromMap, candidates, data, salt)
  if type(candidates) ~= "table" or #candidates == 0 then return nil end
  local best, bestScore
  for _, mapId in ipairs(candidates) do
    if mapId ~= fromMap then
      local fit = self:habitatSuitability(species, mapId, data)
      -- Save-seeded jitter prevents every world from choosing the same branch
      -- when two neighbouring habitats are equally plausible.
      local jitter = unit(self.seed, "refuge:" .. tostring(species) .. ":" .. tostring(mapId) .. ":" .. tostring(salt)) * 0.22
      local score = fit + jitter
      if not bestScore or score > bestScore or (score == bestScore and tostring(mapId) < tostring(best)) then
        best, bestScore = mapId, score
      end
    end
  end
  return best
end

function Ecology:migrantPressure(species, mapId, now)
  local bySpecies = self.migrations[species]
  local row = bySpecies and bySpecies[mapId]
  if not row then return 0 end
  return decay(row.v or 0, row.t or 0, now or 0, Ecology.MIGRATION_HALF_LIFE_TICKS)
end

function Ecology:recordMigration(species, fromMap, toMap, amount, now)
  if not (species and toMap) then return false end
  now = tonumber(now) or 0
  amount = math.max(0, tonumber(amount) or 0)
  if amount <= 0 then return false end
  local bySpecies = self.migrations[species]
  if not bySpecies then bySpecies = {}; self.migrations[species] = bySpecies end
  local row = bySpecies[toMap]
  if row then
    row.v = decay(row.v or 0, row.t or 0, now, Ecology.MIGRATION_HALF_LIFE_TICKS) + amount
    row.t = now
  else
    bySpecies[toMap] = { v = amount, t = now, from = fromMap }
  end
  self:pruneMigrations(now)
  return true
end

function Ecology:migrationBias(species, mapId, now)
  local bySpecies = self.migrations[species]
  local row = bySpecies and bySpecies[mapId]
  if not row then return 1 end
  local v = decay(row.v or 0, row.t or 0, now or 0, Ecology.MIGRATION_HALF_LIFE_TICKS)
  -- Displaced populations temporarily favour their new route.
  return math.min(2.5, 1 + v * 0.16)
end

function Ecology:recordAdaptation(mapId, species, foodSource, amount, now)
  if not (mapId and species) then return false end
  now = tonumber(now) or 0
  amount = math.max(0, tonumber(amount) or 0)
  if amount <= 0 then return false end
  local byMap = self.adaptations[mapId]
  if not byMap then byMap = {}; self.adaptations[mapId] = byMap end
  local row = byMap[species]
  if row then
    row.v = decay(row.v or 0, row.t or 0, now, Ecology.ADAPTATION_HALF_LIFE_TICKS) + amount
    row.t = now
    row.food = foodSource or row.food
  else
    byMap[species] = { v = amount, t = now, food = foodSource }
  end
  self:pruneAdaptations(now)
  return true
end

-- Environmental exposure is deliberately recorded through a separate door from
-- hunting pressure. Merely living through unusual conditions is not harm. When
-- the same population experiences enough of one driver, a permanent ecotype is
-- established for this save and location.
function Ecology:recordExposure(mapId, species, driver, amount, now)
  if not (mapId and species and driver) then return false end
  now = tonumber(now) or 0
  amount = math.max(0, tonumber(amount) or 0)
  if amount <= 0 then return false end
  driver = tostring(driver):upper()
  local byMap = self.exposures[mapId] or {}; self.exposures[mapId] = byMap
  local bySpecies = byMap[species] or {}; byMap[species] = bySpecies
  local row = bySpecies[driver]
  if row then
    row.v = decay(row.v or 0, row.t or 0, now, Ecology.EXPOSURE_HALF_LIFE_TICKS) + amount
    row.t = now
  else
    bySpecies[driver] = { v=amount, t=now }
    row = bySpecies[driver]
  end
  if (row.v or 0) >= Ecology.ECOTYPE_THRESHOLD then
    self:establishEcotype(mapId, species, driver, now)
    row.v = Ecology.ECOTYPE_THRESHOLD * 0.35 -- hysteresis prevents instant repeat
  end
  return true
end

function Ecology:observeEnvironment(mapId, species, env)
  env = env or {}
  local weather = env.weather and tostring(env.weather):upper()
  local driver = weather and ADAPTATION_DRIVERS[weather]
  if driver then self:recordExposure(mapId, species, driver, 0.35, env.now) end
  local migration = self:migrantPressure(species, mapId, env.now)
  if migration >= 2.5 then self:recordExposure(mapId, species, "DISPLACED", 0.20, env.now) end
  local adaptation, food = self:adaptationPressure(mapId, species, env.now)
  if adaptation >= 1 and food then
    self:recordExposure(mapId, species, "DIET:" .. tostring(food):upper(), 0.18 + math.min(0.32, adaptation * 0.01), env.now)
  end
end

function Ecology:establishEcotype(mapId, species, driver, now)
  self.ecotypes[mapId] = self.ecotypes[mapId] or {}
  if self.ecotypes[mapId][species] then return false end
  self.ecotypes[mapId][species] = {
    driver=tostring(driver), established=tonumber(now) or 0,
    id=tostring(species) .. "@" .. tostring(mapId) .. ":" .. tostring(driver),
  }
  -- Bound permanent history by oldest establishment tick.
  local rows={}
  for m, bs in pairs(self.ecotypes) do for sp, row in pairs(bs) do rows[#rows+1]={m=m,sp=sp,t=row.established or 0} end end
  if #rows > Ecology.MAX_ECOTYPES then
    table.sort(rows,function(a,b) return a.t < b.t end)
    for i=1,#rows-Ecology.MAX_ECOTYPES do
      local r=rows[i]; self.ecotypes[r.m][r.sp]=nil
      if next(self.ecotypes[r.m])==nil then self.ecotypes[r.m]=nil end
    end
  end
  return true
end

function Ecology:ecotype(mapId, species)
  local byMap=self.ecotypes[mapId]
  return byMap and byMap[species] or nil
end

function Ecology:adaptationPressure(mapId, species, now)
  local byMap = self.adaptations[mapId]
  local row = byMap and byMap[species]
  if not row then return 0, nil end
  return decay(row.v or 0, row.t or 0, now or 0, Ecology.ADAPTATION_HALF_LIFE_TICKS), row.food
end

function Ecology:pruneMigrations(now)
  now = tonumber(now) or 0
  local speciesRows = {}
  for species, byMap in pairs(self.migrations) do
    local live = 0
    for mapId, row in pairs(byMap) do
      row.v = decay(row.v or 0, row.t or 0, now, Ecology.MIGRATION_HALF_LIFE_TICKS)
      row.t = now
      if row.v < Ecology.EPSILON then byMap[mapId] = nil else live = live + 1 end
    end
    if live == 0 then self.migrations[species] = nil
    else speciesRows[#speciesRows + 1] = { species = species, v = live } end
  end
  if #speciesRows > Ecology.MAX_MIGRATION_SPECIES then
    table.sort(speciesRows, function(a,b) return tostring(a.species) < tostring(b.species) end)
    for i=1,#speciesRows-Ecology.MAX_MIGRATION_SPECIES do self.migrations[speciesRows[i].species] = nil end
  end
end

function Ecology:pruneAdaptations(now)
  now = tonumber(now) or 0
  for mapId, bySpecies in pairs(self.adaptations) do
    local rows = {}
    for species, row in pairs(bySpecies) do
      row.v = decay(row.v or 0, row.t or 0, now, Ecology.ADAPTATION_HALF_LIFE_TICKS)
      row.t = now
      if row.v < Ecology.EPSILON then bySpecies[species] = nil
      else rows[#rows + 1] = { species = species, v = row.v } end
    end
    if #rows > Ecology.MAX_ADAPTATIONS_PER_MAP then
      table.sort(rows, function(a,b)
        if a.v ~= b.v then return a.v < b.v end
        return tostring(a.species) < tostring(b.species)
      end)
      for i=1,#rows-Ecology.MAX_ADAPTATIONS_PER_MAP do bySpecies[rows[i].species] = nil end
    end
    if next(bySpecies) == nil then self.adaptations[mapId] = nil end
  end
end

-- ------------------------------------------------------------------
-- Abundance -- the whole model, in one function
-- ------------------------------------------------------------------
-- env = { weather = "RAIN", season = "SUMMER", now = tick }
--
-- Returns a species -> share table summing to 1, plus the map's overall
-- HEALTH (0..1+) which is what the encounter RATE is scaled by.
function Ecology:abundance(mapId, data, env)
  local cap = self:capacity(mapId, data)
  if not cap then return nil, 1 end
  env = env or {}
  local now = tonumber(env.now) or 0
  local world = type(env.world) == "table" and env.world or {}

  -- Native species plus temporary migrants. This is the key 5.7 change: a
  -- displaced Weedle can actually appear on the connected route it fled to,
  -- even when Weedle was not in that route's vanilla encounter slots.
  local speciesSet = {}
  for species in pairs(cap) do speciesSet[species] = true end
  for species, byMap in pairs(self.migrations) do
    local row = byMap and byMap[mapId]
    if row and self:migrantPressure(species, mapId, now) >= Ecology.EPSILON
       and data and data.pokemon and data.pokemon[species] then
      speciesSet[species] = true
    end
  end

  local raw, total, capTotal = {}, 0, 0
  for _, share in pairs(cap) do capTotal = capTotal + share end

  for species in pairs(speciesSet) do
    local nativeShare = cap[species]
    local share = nativeShare
    if not share then
      local mv = self:migrantPressure(species, mapId, now)
      local refuge = self:habitatSuitability(species, mapId, data)
      share = math.min(Ecology.MIGRANT_MAX_SHARE,
        Ecology.MIGRANT_BASE_SHARE * mv * refuge)
    end

    -- 1. HUNTING PRESSURE. Route-wide Rocket disturbance increases stress;
    -- Ranger/protection state softens it. Ranger patrols also call recover(),
    -- so this modifier is immediate while the persistent pressure itself heals.
    local p = self:pressure(mapId, species, now)
    local disturbance = math.max(0, tonumber(world.disturbance) or 0)
      + math.max(0, tonumber(world.rocket) or 0) * 0.7
    local shelter = math.max(0, tonumber(world.protection) or 0)
      + math.max(0, tonumber(world.ranger) or 0) * 0.6
    local effectiveP = math.max(0, p + disturbance * 0.12 - shelter * 0.08)
    local hunted = 0.5 ^ (effectiveP / Ecology.PRESSURE_SCALE)

    -- 2. WEATHER and 3. SEASON, both by primary type.
    local ptype = Ecology.primaryType(species, data)
    local weather = 1
    if env.weather then
      weather = (TYPE_WEATHER[ptype] or {})[tostring(env.weather):upper()] or 1
    end
    local season = 1
    if env.season then
      season = (TYPE_SEASON[ptype] or {})[tostring(env.season):upper()] or 1
    end

    -- 4. Natural seasonal migration and forced Rocket displacement.
    local migrate = self:migration(species, mapId, env.season)
    local displaced = self:migrationBias(species, mapId, now)
    local adaptation = self:adaptationPressure(mapId, species, now)
    local ecotype = self:ecotype(mapId, species)
    local localBias = 1
    if ecotype then
      local currentDriver = env.weather and ADAPTATION_DRIVERS[tostring(env.weather):upper()]
      if currentDriver and currentDriver == ecotype.driver then localBias = 1.18
      elseif tostring(ecotype.driver):sub(1,5) == "DIET:" then localBias = 1.10
      elseif ecotype.driver == "DISPLACED" and displaced > 1 then localBias = 1.12 end
    end

    local value = share * hunted * weather * season * migrate * displaced * localBias
    if adaptation > 0 then
      value = value * math.min(1.35, 1 + adaptation * 0.025)
    end

    -- Native populations are clamped against their vanilla carrying capacity.
    -- Migrants use their temporary refuge share as capacity, allowing a genuine
    -- new local population without pretending the ROM always contained it.
    local lo, hi
    if nativeShare then
      lo, hi = nativeShare * Ecology.FLOOR, nativeShare * Ecology.CEILING
    else
      lo, hi = 0, math.min(Ecology.MIGRANT_MAX_SHARE * 2, share * 2.5)
    end
    if value < lo then value = lo elseif value > hi then value = hi end
    raw[species] = value
    total = total + value
  end
  if total <= 0 then return nil, 1 end

  -- 5. COMPETITION. New arrivals take real encounter share from residents.
  local out = {}
  for species, value in pairs(raw) do out[species] = value / total end

  -- Habitat damage affects encounter frequency as well as composition. Ranger
  -- protection can partially offset it, but cannot push a devastated route
  -- above its biological total just by standing there.
  local health = total / math.max(0.001, capTotal)
  local damage = math.max(0, (tonumber(world.disturbance) or 0) * 0.012
    + (tonumber(world.rocket) or 0) * 0.010
    - (tonumber(world.protection) or 0) * 0.006
    - (tonumber(world.ranger) or 0) * 0.004)
  health = health * math.max(0.35, 1 - damage)
  if health > 1 then health = 1 + (health - 1) * 0.35 end
  return out, health
end

-- Deterministic pick from an abundance table. `roll` is 0..1 and is supplied
-- by the caller, so this function itself draws nothing -- §13: adding an RNG
-- draw to a shared stream retroactively changes existing saves, so the
-- ecology never touches the engine's.
function Ecology.pickFrom(shares, roll)
  if type(shares) ~= "table" then return nil end
  local ids = {}
  for species in pairs(shares) do ids[#ids + 1] = species end
  if #ids == 0 then return nil end
  -- Sorted: pairs() order indexed by a roll is not deterministic (§38).
  table.sort(ids, function(a, b) return tostring(a) < tostring(b) end)
  local acc = 0
  roll = math.min(0.999999, math.max(0, tonumber(roll) or 0))
  for _, species in ipairs(ids) do
    acc = acc + (shares[species] or 0)
    if roll < acc then return species end
  end
  return ids[#ids]
end

-- ------------------------------------------------------------------
-- Rare variants
-- ------------------------------------------------------------------
-- A THRIVING population throws up unusual individuals; a hunted one does not.
-- That is the whole rule, and it gives the player a reason to leave a route
-- alone that is not just "the numbers recover".
--
-- NEVER INVENTS A SPECIES. A variant is either a Weather FX variant id that
-- genuinely exists in this boot's data.pokemon, or -- when none does -- an
-- unusually high level of the ordinary species. Both are legal Pokemon; the
-- non-negotiable is that a mod may not manufacture one.
Ecology.VARIANT_BASE = 0.02
Ecology.VARIANT_LEVEL_BONUS = 4

function Ecology:variantChance(mapId, species, data, env)
  local shares = self:abundance(mapId, data, env)
  local cap = self:capacity(mapId, data)
  if not (shares and cap) then return 0 end
  local base = cap[species]
  if not base then
    local mv = self:migrantPressure(species, mapId, env and env.now)
    if mv < Ecology.EPSILON then return 0 end
    base = math.min(Ecology.MIGRANT_MAX_SHARE,
      Ecology.MIGRANT_BASE_SHARE * mv * self:habitatSuitability(species, mapId, data))
  end
  if base <= 0 then return 0 end
  local ratio = (shares[species] or 0) / base
  if ratio <= 1 then return 0 end
  local chance = Ecology.VARIANT_BASE * (ratio - 1) * 2
  local pressure = self:adaptationPressure(mapId, species, env and env.now)
  if pressure > 0 then
    chance = chance + math.min(0.10, pressure * 0.015)
  end
  -- Established local ecotypes continue favouring compatible rare forms even
  -- after the transient pressure that created them has faded.
  if self:ecotype(mapId, species) then chance = chance + 0.06 end
  return math.min(0.25, chance)
end

-- The variant SPECIES id, if this boot has one. Weather FX ships ids shaped
-- WX_<dex>_<NAME>_<VARIANT>; asking data.pokemon whether the id exists is the
-- §29 rule -- sniff the data, never ask a version.
function Ecology.variantSpecies(species, data, seed, salt)
  local pokemon = data and data.pokemon
  if type(pokemon) ~= "table" then return nil end
  local prefix = "WX_"
  local matches = {}
  local name = tostring(species)
  for id in pairs(pokemon) do
    local sid = tostring(id)
    if sid:sub(1, #prefix) == prefix and sid:find("_" .. name .. "_", 1, true) then
      matches[#matches + 1] = sid
    end
  end
  if #matches == 0 then return nil end
  table.sort(matches)
  local index = (hash(seed, "variant:" .. name .. ":" .. tostring(salt)) % #matches) + 1
  return matches[index]
end

-- ------------------------------------------------------------------
-- Persistence
-- ------------------------------------------------------------------

function Ecology:serialize(now)
  self:prune(now)
  self:pruneMigrations(now)
  self:pruneAdaptations(now)
  local pressure, migrations, adaptations, exposures, ecotypes = {}, {}, {}, {}, {}
  for mapId, byMap in pairs(self.maps) do
    pressure[mapId] = {}
    for species, row in pairs(byMap) do
      pressure[mapId][species] = { v = row.v, t = row.t }
    end
  end
  for species, byMap in pairs(self.migrations) do
    migrations[species] = {}
    for mapId, row in pairs(byMap) do
      migrations[species][mapId] = { v = row.v, t = row.t, from = row.from }
    end
  end
  for mapId, bySpecies in pairs(self.adaptations) do
    adaptations[mapId] = {}
    for species, row in pairs(bySpecies) do
      adaptations[mapId][species] = { v = row.v, t = row.t, food = row.food }
    end
  end
  for mapId, bySpecies in pairs(self.exposures) do
    exposures[mapId] = {}
    for species, drivers in pairs(bySpecies) do
      exposures[mapId][species] = {}
      for driver, row in pairs(drivers) do exposures[mapId][species][driver] = {v=row.v,t=row.t} end
    end
  end
  for mapId, bySpecies in pairs(self.ecotypes) do
    ecotypes[mapId] = {}
    for species, row in pairs(bySpecies) do ecotypes[mapId][species] = Util.copy(row) end
  end
  return { version = 3, pressure = pressure, migrations = migrations, adaptations = adaptations, exposures = exposures, ecotypes = ecotypes }
end

function Ecology:load(saved)
  self.maps, self.migrations, self.adaptations, self.exposures, self.ecotypes = {}, {}, {}, {}, {}
  if type(saved) ~= "table" then return end

  -- 5.2 saves stored the pressure map directly. Keep that shape readable.
  local pressure = saved.pressure
  if type(pressure) ~= "table" then pressure = saved end
  for mapId, rows in pairs(pressure) do
    if type(rows) == "table" then
      local byMap = {}
      for species, row in pairs(rows) do
        local v = tonumber(type(row) == "table" and row.v or row)
        if v and v > 0 then
          byMap[species] = { v = v, t = tonumber(type(row) == "table" and row.t) or 0 }
        end
      end
      if next(byMap) then self.maps[mapId] = byMap end
    end
  end

  if type(saved.migrations) == "table" then
    for species, rows in pairs(saved.migrations) do
      if type(rows) == "table" then
        local byMap = {}
        for mapId, row in pairs(rows) do
          if type(row) == "table" and tonumber(row.v) and tonumber(row.v) > 0 then
            byMap[mapId] = { v=tonumber(row.v), t=tonumber(row.t) or 0, from=row.from }
          end
        end
        if next(byMap) then self.migrations[species] = byMap end
      end
    end
  end

  if type(saved.adaptations) == "table" then
    for mapId, rows in pairs(saved.adaptations) do
      if type(rows) == "table" then
        local bySpecies = {}
        for species, row in pairs(rows) do
          if type(row) == "table" and tonumber(row.v) and tonumber(row.v) > 0 then
            bySpecies[species] = { v=tonumber(row.v), t=tonumber(row.t) or 0, food=row.food }
          end
        end
        if next(bySpecies) then self.adaptations[mapId] = bySpecies end
      end
    end
  end

  if type(saved.exposures) == "table" then
    for mapId, rows in pairs(saved.exposures) do
      if type(rows)=="table" then
        self.exposures[mapId]={}
        for species, drivers in pairs(rows) do
          if type(drivers)=="table" then
            self.exposures[mapId][species]={}
            for driver,row in pairs(drivers) do
              if type(row)=="table" and tonumber(row.v) and tonumber(row.v)>0 then
                self.exposures[mapId][species][driver]={v=tonumber(row.v),t=tonumber(row.t) or 0}
              end
            end
          end
        end
      end
    end
  end
  if type(saved.ecotypes) == "table" then self.ecotypes = Util.copy(saved.ecotypes) end

end

-- ------------------------------------------------------------------
-- Reporting -- so the model is visible to the player, not just true
-- ------------------------------------------------------------------
-- §35: feedback the player cannot see from where they stand is
-- indistinguishable from nothing happening. The Pokegear reads this.
function Ecology:report(mapId, data, env)
  local shares, health = self:abundance(mapId, data, env)
  if not shares then return nil end
  local cap = self:capacity(mapId, data)
  local rows = {}
  for species, share in pairs(shares) do
    local base = cap[species] or 0
    rows[#rows + 1] = {
      species = species,
      share = share,
      ratio = base > 0 and (share / base) or 1,
      pressure = self:pressure(mapId, species, env and env.now or 0),
      native = cap[species] ~= nil,
      migrantPressure = self:migrantPressure(species, mapId, env and env.now or 0),
      ecotype = self:ecotype(mapId, species),
    }
  end
  table.sort(rows, function(a, b)
    if a.share ~= b.share then return a.share > b.share end
    return tostring(a.species) < tostring(b.species)
  end)
  return { health = health, rows = rows }
end

-- A one-line English state for a species, used by the Pokegear and by rival
-- dialogue. Thresholds are RULES, not tuned ratios (§33).
function Ecology.describe(ratio)
  if ratio >= 1.60 then return "THRIVING" end
  if ratio >= 1.15 then return "PLENTIFUL" end
  if ratio >= 0.85 then return "STEADY" end
  if ratio >= 0.50 then return "THINNING" end
  return "SCARCE"
end

return Ecology
