local req, mod = ...

-- TRAVEL STYLES (5.2.0)
-- ==================================================================
-- Four rivals used to behave like four copies of one traveller with different
-- dice. They shared one wander roll, one neighbour weighting and one idea of
-- what "done with this route" meant, so they clumped: same maps, same
-- direction, same pace.
--
-- A STYLE is not a second AI. Same rule as a career (1.14): it is a bias over
-- the objectives and destinations that already exist, so it inherits every
-- fix the planner has accumulated instead of repeating its bugs.
--
--   VANGUARD   pushes to the far edge of what it is allowed to reach
--   WANDERER   takes detours and prefers maps nobody is standing on
--   HARVESTER  stays on a route until it has met most of what lives there
--   GRINDER    stays and battles until its team outgrows the route
--
-- WHAT THIS MAY NOT DO. "Rush ahead" is about POSITION, never pacing.
-- Rival.BADGE_LEAD and the playerPaceLevel ceiling are untouched: a VANGUARD
-- gets further down the map, not further up the badge list, because
-- Christopher's standing requirement is that rivals never end up three gyms
-- ahead. A style that could beat that rule would be a regression sold as a
-- feature.

local Travel = {}

Travel.STYLES = { "VANGUARD", "WANDERER", "HARVESTER", "GRINDER" }

-- Style is DERIVED from the personality, not stored and not rolled. A rival's
-- way of moving is part of who it is, so it should not be a second draw that
-- can disagree with its own character -- and deriving it means old saves get
-- styles without a migration.
--
-- The mapping reads the numbers that already describe the personality rather
-- than naming all seventeen of them, so a personality added later (or by a
-- third party) gets a style automatically instead of falling into a default
-- (§19 -- a hand-maintained list beside a data table will drift).
-- THE STYLE IS A RANK, NOT A SCORE.
--
-- The first version of this was four weighted sums of the same four traits,
-- tuned by eye. Two of the four styles came out MATHEMATICALLY UNREACHABLE --
-- VANGUARD's term dominated the range every personality actually occupies, so
-- HARVESTER and GRINDER could never win for anybody. Nothing errored; the
-- feature shipped, read well in the file and would have been invisible in
-- play. §36, and §33: state the rule, do not tune the ratio.
--
-- So the rule is comparative. Each style owns ONE trait, and a personality
-- takes the style whose trait it ranks highest in ACROSS THE WHOLE CAST. That
-- is self-calibrating: whoever catches the most is the harvester, whoever
-- trains the hardest is the grinder, whatever the absolute numbers are. A
-- personality added later -- or by a third party -- re-ranks everybody
-- automatically instead of falling into a default (§19).
local TRAIT = {
  VANGUARD = "gymConfidence",
  WANDERER = "wanderChance",
  HARVESTER = "catchChance",
  GRINDER = "trainRate",
}

local DEFAULT = { gymConfidence = 0.5, wanderChance = 0.1, catchChance = 0.1, trainRate = 1 }

-- Built once, from data/personalities.lua itself, so the scale is whatever the
-- shipped cast actually is.
local scale
local function scales()
  if scale then return scale end
  scale = {}
  local ok, PERSONALITIES = pcall(req, "data/personalities")
  if not ok or type(PERSONALITIES) ~= "table" then PERSONALITIES = {} end
  for _, trait in pairs(TRAIT) do
    local values = {}
    for _, p in pairs(PERSONALITIES) do
      if type(p) == "table" then
        values[#values + 1] = tonumber(p[trait]) or DEFAULT[trait]
      end
    end
    table.sort(values)
    scale[trait] = values
  end
  return scale
end

-- Share of the cast this personality is at or above, 0..1.
local function percentile(trait, value)
  local values = scales()[trait]
  if not values or #values == 0 then return 0.5 end
  local below = 0
  for _, v in ipairs(values) do
    if v < value then below = below + 1 end
  end
  return below / #values
end

function Travel.styleOf(personality)
  if type(personality) ~= "table" then return "WANDERER" end
  local best, bestRank
  for _, id in ipairs(Travel.STYLES) do        -- fixed order, never pairs()
    local trait = TRAIT[id]
    local value = tonumber(personality[trait]) or DEFAULT[trait]
    local rank = percentile(trait, value)
    if bestRank == nil or rank > bestRank then best, bestRank = id, rank end
  end
  return best
end

-- Exposed so a suite can assert the mapping against the real cast rather than
-- restating it (§19).
Travel.TRAIT = TRAIT

-- ------------------------------------------------------------------
-- Spreading out
-- ------------------------------------------------------------------
-- CROWDING is the thing that actually makes the region feel inhabited rather
-- than convoyed. Counted over the OTHER rivals only, and used as a weight on
-- destinations rather than a ban, so a rival can still follow a friend or
-- converge on a gym when it has a reason to.
function Travel.crowding(rivals, exceptId)
  local counts = {}
  for _, other in ipairs(rivals or {}) do
    if other and other.id ~= exceptId then
      local at = other.map
      if at then counts[at] = (counts[at] or 0) + 1 end
      -- Where they are HEADING counts too, at half weight. Otherwise four
      -- rivals all pick the same empty route in the same tick and the spread
      -- lasts exactly one hop.
      local to = other.destination
      if to and to ~= at then counts[to] = (counts[to] or 0) + 0.5 end
    end
  end
  return counts
end

-- Weight for one candidate map, multiplied onto whatever the planner already
-- decided. Never returns 0: a weight of zero is a ban, and a ban can strand a
-- rival whose only legal neighbour happens to be occupied (§6 -- a guard that
-- can never be satisfied is worse than no guard).
Travel.CROWD_PENALTY = 0.45
Travel.MIN_WEIGHT = 0.08

function Travel.weight(style, mapId, ctx)
  ctx = ctx or {}
  local w = 1

  local crowd = (ctx.crowding or {})[mapId] or 0
  if crowd > 0 then
    w = w * (Travel.CROWD_PENALTY ^ crowd)
  end

  if style == "VANGUARD" then
    -- Further from the player's own position is more interesting, and the
    -- frontier most of all. Distance comes from the caller because only the
    -- manager holds the graph.
    local d = tonumber(ctx.distanceFromPlayer and ctx.distanceFromPlayer[mapId])
    if d then w = w * (1 + math.min(d, 6) * 0.22) end
  elseif style == "WANDERER" then
    -- Actively rewards the unvisited. A wanderer that revisits is a commuter.
    if ctx.visited and not ctx.visited[mapId] then w = w * 1.9 end
    if crowd > 0 then w = w * 0.7 end
  elseif style == "HARVESTER" or style == "GRINDER" then
    -- Both are stayers, so they resist LEAVING rather than preferring a
    -- particular destination. Handled in shouldLinger; here they simply do
    -- not chase the frontier.
    local d = tonumber(ctx.distanceFromPlayer and ctx.distanceFromPlayer[mapId])
    if d and d > 3 then w = w * 0.75 end
  end

  if w < Travel.MIN_WEIGHT then w = Travel.MIN_WEIGHT end
  return w
end

-- ------------------------------------------------------------------
-- Staying put
-- ------------------------------------------------------------------
-- "Catch every Pokemon on a route before moving on" and "battle until my team
-- is strongest" are the same shape: a rival with unfinished business on the
-- map it is standing on.
--
-- Both answer against the map's REAL population (src/Ecology.lua), not the
-- static table -- so a HARVESTER that has hunted a route into scarcity moves
-- on, which is the ecology and the travel style closing the loop on each
-- other rather than each pretending the other does not exist.

Travel.HARVEST_TARGET = 0.75   -- share of the map's species met
Travel.GRIND_MARGIN = 2        -- levels above the map's own before moving on
Travel.LINGER_CAP_TICKS = 900  -- nobody camps forever

function Travel.harvestProgress(seen, shares)
  if type(shares) ~= "table" then return 1, 0, 0 end
  local total, met = 0, 0
  for species in pairs(shares) do
    total = total + 1
    if seen and seen[species] then met = met + 1 end
  end
  if total == 0 then return 1, 0, 0 end
  return met / total, met, total
end

-- `info` carries what the manager knows:
--   style, seenHere (species -> true), shares (from Ecology), health,
--   partyLevel, mapLevel, lingeredTicks
-- Returns true to keep the rival where it is, plus a reason for the log.
function Travel.shouldLinger(info)
  info = info or {}
  local ticks = tonumber(info.lingeredTicks) or 0
  if ticks >= Travel.LINGER_CAP_TICKS then return false, "moved on" end

  if info.style == "HARVESTER" then
    -- A route hunted below half its capacity has nothing left worth staying
    -- for, however much of the list is unticked.
    if (tonumber(info.health) or 1) < 0.5 then return false, "route is bare" end
    local progress = Travel.harvestProgress(info.seenHere, info.shares)
    if progress < Travel.HARVEST_TARGET then
      return true, "still cataloguing"
    end
    return false, "route catalogued"
  end

  if info.style == "GRINDER" then
    local party = tonumber(info.partyLevel)
    local map = tonumber(info.mapLevel)
    -- §5: no information means no reason to linger, not a reason to linger
    -- forever. A missing map level used to read as zero, which is "already
    -- outgrown" -- the opposite of the safe answer here.
    if not (party and map) then return false, "nothing to measure" end
    if party < map + Travel.GRIND_MARGIN then
      return true, "training up"
    end
    return false, "outgrown this route"
  end

  return false, nil
end

-- What the style does to the wander roll, so a WANDERER genuinely detours
-- more than a VANGUARD without either of them getting a second roll.
Travel.WANDER_BIAS = {
  VANGUARD = 0.55,
  WANDERER = 1.80,
  HARVESTER = 0.90,
  GRINDER = 0.60,
}

function Travel.wanderChance(style, base)
  local bias = Travel.WANDER_BIAS[style] or 1
  local value = (tonumber(base) or 0) * bias
  if value < 0 then value = 0 end
  if value > 0.9 then value = 0.9 end
  return value
end

Travel.BLURB = {
  VANGUARD = "pushes ahead of everyone",
  WANDERER = "wanders off the marked routes",
  HARVESTER = "catalogues a route before leaving it",
  GRINDER = "stays and trains until the route is beneath them",
}

return Travel
