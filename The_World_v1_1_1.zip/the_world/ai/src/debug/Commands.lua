local req, mod = ...

-- DEBUG VERBS
--
-- The developer console commands: roster dumps, per-rival inspection (career,
-- league, economy, story, team, relationships, life path, position), and the
-- handful of setters that exist to reproduce a reported state quickly
-- (setpath, setstyle, setbond, tp, givebadge, setstate, simulate, reset).
--
-- Registered unconditionally because the console that reaches them only
-- exists in developer mode; a normal build has no way to type one. Extracted
-- from main.lua in 4.6.1 with the bodies unchanged.
--
-- Read-mostly by design: a verb that CHANGES a rival says so in its name, so
-- that a debug session cannot quietly become the reason a save looks wrong.

local Util = req("src/Util")
local Rival = req("src/Rival")
local Relationships = req("src/Relationships")
local TeamPlan = req("src/TeamPlan")
local Story = req("src/Story")
local Presence = req("src/Presence")
local Weather = req("src/Weather")
local Economy = req("src/Economy")
local League = req("src/League")
local LifePath = req("src/LifePath")
local Career = req("src/Career")

local Commands = {}

function Commands.install(modApi, M)
  mod = modApi or mod

  ------------------------------------------------------------------------
  -- Debug verbs
  ------------------------------------------------------------------------
  -- Registered unconditionally because the developer console that reaches them
  -- only exists in developer mode; a normal build has no way to type one.

  local function eachRival(fn)
    local out = {}
    for _, rival in ipairs(M.rivals) do out[#out + 1] = fn(rival) end
    return table.concat(out, "\n")
  end

  mod.commands:register("rival_list", function()
    return eachRival(function(r)
      return ("%-8s %-16s %-14s badges=%d party=%d dest=%s")
        :format(r.id, r.state, Util.spaced(r.map), r:badgeCount(),
                #r.party, Util.spaced(r.destination or "-"))
    end)
  end)

  mod.commands:register("rivals", function()
    return eachRival(function(r)
      return ("%s: %s on %s -> %s (%d badges, lead L%d, route %d, err %s)")
        :format(r.name, r.state, Util.spaced(r.map),
                Util.spaced(r.destination or "-"), r:badgeCount(),
                r:leadLevel(), r.route and #r.route or 0,
                tostring(Util.lastError))
    end) .. "\nsprites: " .. M.sprites:describe()
  end)

  -- /rival_relationship [id]  -- every bond one rival holds, with the axes and
  -- the last cause, so a state on screen can always be traced to something that
  -- happened.  With no id it prints the whole social graph.
  -- /rival_team [id] -- the identity, where it is drifting, the type credit it
  -- has actually accumulated, and the service record behind the favourite.
  -- /rival_where [id] -- where every rival is, what it is doing there and why,
  -- plus what the player has recently been shown. The one verb to reach for when
  -- the world feels empty: it says whether nothing is happening, or whether
  -- things are happening and the player is simply not being told.
  -- /rival_weather -- what the mod believes about the sky, where that belief
  -- came from (the live Weather FX catalogue or our fallback copy), and what
  -- each rival makes of it. The first line is the one that matters: if it says
  -- `fallback` while Weather FX is installed, the interop is broken and every
  -- weather decision below it is running on a stale mirror.
  -- /rival_economy [id] -- the purse, the spending profile that shapes it, what
  -- has actually been spent per category, and the bag. If two rivals show the
  -- same percentages something has stopped reading their personalities.
  -- /rival_league -- attempts, the stage that keeps stopping each rival, how
  -- long it must now wait, and whether it has EARNED a title shot. If a rival is
  -- stuck, the wall line says what it is stuck on.
  -- /rival_lifepath [id] -- §30's developer view. Everything hidden from the
  -- player is visible here: who is eligible, how much pressure each rival is
  -- under, which lives it could plausibly take, and whether the decision is
  -- locked. This is a debug verb precisely BECAUSE §22 forbids exposing any of
  -- it in the game.
  mod.commands:register("rival_lifepath", function(id)
    local function describe(rival)
      local record = rival:ensureLifePath()
      local pressure = rival:lifePathPressure()
      local eligible = M:lifePathEligible(rival)
      local out = { ("%-8s %s"):format(rival.name,
        LifePath.describe(record, pressure, eligible)) }
      if record.path == LifePath.GYM_CHALLENGE then
        local bits = {}
        for _, entry in ipairs(rival:lifePathCandidates(4)) do
          bits[#bits + 1] = ("%s %d%%"):format(LifePath.label(entry.path),
            math.floor(entry.score * 100 + 0.5))
        end
        out[#out + 1] = "  could become: " .. table.concat(bits, ", ")
      end
      for _, entry in ipairs(record.history) do
        out[#out + 1] = ("  t=%-6d became %s (%s)"):format(entry.tick,
          LifePath.label(entry.path), tostring(entry.reason))
      end
      return table.concat(out, "\n")
    end
    if id then
      local rival = M.byId[id]
      if not rival then return "no such rival: " .. tostring(id) end
      return describe(rival)
    end
    local ids = {}
    for _, r in ipairs(M.rivals) do ids[#ids + 1] = r.id end
    local out = { ("seed %s  divergent this save: %d  eligible: %s"):format(
      tostring(M:lifePathSeed()),
      LifePath.divergentCount(M:lifePathSeed(), nil, #ids),
      table.concat(LifePath.eligibleRivals(M:lifePathSeed(), ids), ", ")) }
    for _, rival in ipairs(M.rivals) do out[#out + 1] = describe(rival) end
    return table.concat(out, "\n")
  end)

  mod.commands:register("rival_career", function(id)
    local function describe(rival)
      return ("%-8s %s"):format(rival.name,
        Career.describe(rival:lifePathId(), rival:ensureCareer()))
        .. ("\n  priorities: %s"):format(table.concat(rival:objectivePriorities(), " "))
        .. ("\n  chases badges: %s"):format(tostring(rival:pursuesBadges()))
    end
    if id then
      local rival = M.byId[id]
      if not rival then return "no such rival: " .. tostring(id) end
      return describe(rival)
    end
    local out = {}
    for _, rival in ipairs(M.rivals) do out[#out + 1] = describe(rival) end
    return table.concat(out, "\n")
  end)

  mod.commands:register("rival_setpath", function(id, path)
    local rival = M.byId[id]
    if not rival then return "no such rival: " .. tostring(id) end
    if not LifePath.isPath(path) then
      return "no such path: " .. tostring(path) .. "\n"
        .. LifePath.GYM_CHALLENGE .. " " .. table.concat(LifePath.PATHS, " ")
    end
    local record = rival:ensureLifePath()
    if path == LifePath.GYM_CHALLENGE then
      -- a debug-only unlock; the game itself has no path back yet (that is §28,
      -- and it is a later release)
      rival.lifePath = LifePath.newRecord()
      return rival.name .. " -> Gym Challenge (debug reset)"
    end
    record.locked = false
    if LifePath.commit(record, path, M.sim and M.sim.tick or 0, "debug") then
      return rival.name .. " -> " .. LifePath.label(path)
    end
    return "refused"
  end)

  mod.commands:register("rival_league", function(id)
    local function describe(rival)
      local record = rival:ensureLeague()
      local wall, count = League.wall(record)
      return ("%-8s %s\n  strength %d  bar %.2f  cooldown %d  may attempt: %s%s")
        :format(rival.name, League.describe(record),
          rival:leagueStrength(), League.bar(record),
          record.cooldown or 0, tostring(rival:mayAttemptLeague()),
          wall and ("\n  stuck at stage " .. wall .. " (" .. count .. " times)") or "")
    end
    if id then
      local rival = M.byId[id]
      if not rival then return "no such rival: " .. tostring(id) end
      return describe(rival)
    end
    local out = { "champion: " .. (M.playerChampion and "PLAYER"
      or (M.eliteChampionId and tostring(M.eliteChampionId)) or "none") }
    for _, rival in ipairs(M.rivals) do out[#out + 1] = describe(rival) end
    return table.concat(out, "\n")
  end)

  mod.commands:register("rival_economy", function(id)
    local function describe(rival)
      local profile = rival:spendingProfile()
      local ledger = rival:ensureLedger()
      local bag = {}
      for _, item in ipairs(Rival.SHOP_ORDER) do
        local n = rival:itemCount(item)
        if n > 0 then bag[#bag + 1] = item:lower() .. "x" .. n end
      end
      return ("%-8s P%-7d earned %-7d lost %-6d spent %d\n  %s\n  bag: %s")
        :format(rival.name, tonumber(rival.money) or 0,
          ledger.earned, ledger.lost, Economy.totalSpent(ledger),
          Economy.describe(ledger, profile),
          bag[1] and table.concat(bag, " ") or "empty")
    end
    if id then
      local rival = M.byId[id]
      if not rival then return "no such rival: " .. tostring(id) end
      return describe(rival)
    end
    local out = {}
    for _, rival in ipairs(M.rivals) do out[#out + 1] = describe(rival) end
    return #out > 0 and table.concat(out, "\n") or "no rivals"
  end)

  mod.commands:register("rival_weather", function()
    local compat = M.compat
    local catalogue, source = Weather.catalogue(compat)
    local n = 0
    for _ in pairs(catalogue) do n = n + 1 end
    local exports = compat and compat.exports and compat:exports("weather")
    local out = {
      ("catalogue: %s (%d entries)  host: %s  version: %s"):format(
        source, n,
        (compat and compat:weather()) and "present" or "absent",
        (type(exports) == "table" and tostring(exports.version)) or "-"),
    }
    local id = compat and compat.weather and compat:weather() and compat:weatherId()
    out[#out + 1] = ("sky: %s  battle: %s  chip: %s  favours: %s"):format(
      tostring(id), tostring(id and Weather.battleString(compat, id)),
      tostring(id and Weather.chipType(compat, id)),
      tostring(id and Weather.favouredType(compat, id)))
    for _, rival in ipairs(M.rivals) do
      out[#out + 1] = ("  %-8s affinity=%+.2f style=%s hunting=%s"):format(
        rival.name, rival:weatherAffinity(),
        rival:teamStyleLabel(), tostring(rival.huntTarget))
    end
    return table.concat(out, "\n")
  end)

  mod.commands:register("rival_where", function(_, id)
    local function describe(rival)
      local kind, why = Presence.place(rival.map)
      local seen = Presence.lastSeen(M.presence, rival.id)
      return ("%-8s %-22s %-16s %s%s%s"):format(
        rival.name, tostring(rival.map), tostring(rival.state),
        tostring(rival.travelReason or "-"),
        why and ("  [" .. why .. "]") or "",
        (rival.campTicks or 0) > 0 and ("  CAMP:" .. rival.campTicks) or "")
        .. (seen and ("\n         last seen t=" .. seen.tick .. " " .. seen.kind) or "")
        .. ("\n         knows %d maps, here x%d"):format(
          rival:navKnownCount(), (rival.visitedMaps or {})[rival.map] or 0)
    end
    if id then
      local rival = M.byId[id]
      if not rival then return "no such rival: " .. tostring(id) end
      return describe(rival)
    end
    local out = {}
    for _, rival in ipairs(M.rivals) do out[#out + 1] = describe(rival) end
    local recent = Presence.recent(M.presence, 5)
    if #recent > 0 then
      out[#out + 1] = "recent sightings:"
      for _, entry in ipairs(recent) do
        out[#out + 1] = ("  t=%-6d %s"):format(entry.tick, entry.note or entry.kind)
      end
    else
      out[#out + 1] = "no sightings yet"
    end
    return table.concat(out, "\n")
  end)

  -- /rival_story [id] -- the derived mood and chapter, the open setback, and the
  -- milestone list, so a chapter on screen can be traced to what caused it.
  mod.commands:register("rival_story", function(_, id)
    local function describe(rival)
      local story = rival:ensureStory()
      local facts = rival:storyFacts()
      local out = { ("%s: %s"):format(rival.name, Story.describe(story, facts)) }
      out[#out + 1] = ("  streak=%d confidence=%.2f goal=%s trained=%s rebuilt=%s"):format(
        facts.streak, facts.confidence, tostring(facts.hasGoal),
        tostring(facts.trainedSinceSetback), tostring(facts.teamChangedSinceSetback))
      local got = {}
      for _, milestone in ipairs(Story.MILESTONES) do
        if story.unlocked[milestone.id] then got[#got + 1] = milestone.id end
      end
      out[#out + 1] = "  " .. (got[1] and table.concat(got, " ") or "no milestones yet")
      return table.concat(out, "\n")
    end
    if id then
      local rival = M.byId[id]
      if not rival then return "no such rival: " .. tostring(id) end
      return describe(rival)
    end
    local out = {}
    for _, rival in ipairs(M.rivals) do out[#out + 1] = describe(rival) end
    return #out > 0 and table.concat(out, "\n") or "no rivals"
  end)

  mod.commands:register("rival_team", function(_, id)
    local function describe(rival)
      local plan = rival:ensureTeamPlan()
      local out = { ("%s: %s (from %s, changed %dx)"):format(rival.name,
        TeamPlan.label(plan.style), TeamPlan.label(plan.seed), plan.changed or 0) }
      if plan.driftToward then
        out[#out + 1] = ("  drifting -> %s  %d/%d"):format(
          TeamPlan.label(plan.driftToward), plan.drift or 0, TeamPlan.DRIFT_LIMIT)
      end
      local types = rival:preferredTypes(4)
      local bits = {}
      for _, t in ipairs(types) do bits[#bits + 1] = t .. "=" .. tostring(plan.types[t]) end
      out[#out + 1] = "  types: " .. (bits[1] and table.concat(bits, " ") or "none yet")
      local now = rival.ticks or 0
      for _, slot in ipairs(rival.party or {}) do
        out[#out + 1] = ("  %-12s L%-3d %s b=%d w=%d fit=%.2f svc=%.1f"):format(
          tostring(slot.species), tonumber(slot.level) or 0,
          slot.ace and "ACE" or "   ", tonumber(slot.battles) or 0,
          tonumber(slot.wins) or 0, rival:teamFit(slot.species, slot),
          TeamPlan.serviceScore(slot, now))
      end
      return table.concat(out, "\n")
    end
    if id then
      local rival = M.byId[id]
      if not rival then return "no such rival: " .. tostring(id) end
      return describe(rival)
    end
    local out = {}
    for _, rival in ipairs(M.rivals) do out[#out + 1] = describe(rival) end
    return #out > 0 and table.concat(out, "\n") or "no rivals"
  end)

  mod.commands:register("rival_setstyle", function(_, id, style)
    local rival = M.byId[id]
    if not rival then return "no such rival: " .. tostring(id) end
    if not TeamPlan.isArchetype(style) then
      return "no such style: " .. tostring(style) .. "\n"
        .. table.concat(TeamPlan.ARCHETYPES, " ")
    end
    rival:ensureTeamPlan().style = style
    rival.teamPlan.drift, rival.teamPlan.driftToward = 0, nil
    return rival.name .. " -> " .. TeamPlan.label(style)
  end)

  mod.commands:register("rival_relationship", function(_, id)
    local tick = M.sim and M.sim.tick or 0
    local function describe(rival)
      local out = { rival.name .. ":" }
      local subjects = { "player" }
      for _, other in ipairs(M.rivals) do
        if other.id ~= rival.id then subjects[#subjects + 1] = other.id end
      end
      for _, subject in ipairs(subjects) do
        local bond = rival:bondWith(subject, tick)
        local other = M.byId[subject]
        out[#out + 1] = ("  %-10s %s"):format(other and other.name or "PLAYER",
          Relationships.describe(bond))
      end
      return table.concat(out, "\n")
    end
    if id then
      local rival = M.byId[id]
      if not rival then return "no such rival: " .. tostring(id) end
      return describe(rival)
    end
    local out = {}
    for _, rival in ipairs(M.rivals) do out[#out + 1] = describe(rival) end
    if #out == 0 then return "no rivals" end
    return table.concat(out, "\n")
  end)

  mod.commands:register("rival_setbond", function(_, id, subject, code)
    local rival = M.byId[id]
    if not rival then return "no such rival: " .. tostring(id) end
    if not Relationships.EFFECTS[code] then
      local names = {}
      for name in pairs(Relationships.EFFECTS) do names[#names + 1] = name end
      table.sort(names)
      return "no such cause: " .. tostring(code) .. "\n" .. table.concat(names, " ")
    end
    local changed, state = M:recordBond(rival, subject, code)
    return ("%s -> %s: %s%s"):format(rival.name, tostring(subject), tostring(state),
      changed and " (changed)" or "")
  end)

  mod.commands:register("rival_tp", function(_, id, mapId)
    local rival = M.byId[id]
    if not rival then return "no such rival: " .. tostring(id) end
    if not M.graph:has(mapId) then return "no such map: " .. tostring(mapId) end
    rival.map, rival.x, rival.y = mapId, nil, nil
    rival:setDestination(nil)
    return rival.name .. " -> " .. mapId
  end)

  mod.commands:register("rival_givebadge", function(_, id, badge)
    local rival = M.byId[id]
    if not rival then return "no such rival: " .. tostring(id) end
    return rival:awardBadge(badge) and (rival.name .. " earned " .. badge)
      or "no change"
  end)

  mod.commands:register("rival_setstate", function(_, id, state)
    local rival = M.byId[id]
    if not rival then return "no such rival: " .. tostring(id) end
    if not Rival.isState(state) then return "no such state: " .. tostring(state) end
    rival:setState(state, "debug")
    return rival.name .. " -> " .. state
  end)

  mod.commands:register("rival_simulate", function(_, count)
    local n = math.max(1, math.min(2000, tonumber(count) or 50))
    for _ = 1, n do M.sim:runTick(M.rivals, M:worldView()) end
    return ("ran %d ticks; %s"):format(n, eachRival(function(r)
      return ("%s=%d badges"):format(r.id, r:badgeCount())
    end))
  end)

  mod.commands:register("rival_reset", function()
    for _, rival in ipairs(M.rivals) do
      -- a true reset clears the team first, since seed only fills an empty party
      rival.party = {}
      M:seed(rival)
    end
    M:despawnAll()
    return "roster reset"
  end)

end

return Commands
