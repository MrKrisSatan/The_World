local req, mod = ...
local Util = req("src/Util")

local Quests = {}
Quests.__index = Quests

local function copy(v)
  return Util.copy(v)
end

local function spaced(id)
  if not id then return "Unknown" end
  local s = tostring(id):gsub("_", " "):lower()
  return (s:gsub("(%a)([%w']*)", function(a,b) return a:upper() .. b end))
end

local function speciesOf(slot)
  return type(slot) == "table" and (slot.species or slot.speciesId or slot.id) or nil
end

local function encounterSlots(data, mapId)
  if not (data and mapId) then return nil end
  local row = data.encounters and data.encounters[mapId]
  if type(row) == "table" then
    local slots = row.slots or row.grass or row
    if type(slots) == "table" and next(slots) ~= nil then return slots end
  end
  local gen2 = data.gen2Encounters
  for _, group in ipairs(gen2 and { gen2.grass, gen2.swarmGrass, gen2.water } or {}) do
    local r = group and group[mapId]
    local slots = type(r) == "table" and (r.slots or r) or nil
    if type(slots) == "table" and next(slots) ~= nil then return slots end
  end
  return nil
end

local function rareSpecies(data, mapId)
  local slots = encounterSlots(data, mapId)
  if type(slots) ~= "table" then return nil end
  local counts, first = {}, {}
  for i, entry in ipairs(slots) do
    local species = type(entry) == "table" and (entry.species or entry.mon) or entry
    if type(species) == "string" then
      counts[species] = (counts[species] or 0) + 1
      first[species] = first[species] or i
    end
  end
  local best, bestScore
  for species, n in pairs(counts) do
    local rec = data and data.pokemon and data.pokemon[species]
    local catch = type(rec) == "table" and tonumber(rec.catchRate or rec.catch_rate) or 255
    -- Fewer encounter slots is the strongest signal. A low catch rate breaks
    -- ties so the quest tends toward genuinely notable local encounters.
    local score = (1000 / math.max(1, n)) + math.max(0, 255 - catch)
    if not bestScore or score > bestScore
       or (score == bestScore and (first[species] or 999) > (first[best] or 0)) then
      best, bestScore = species, score
    end
  end
  return best, bestScore
end

local function allEncounterMaps(data)
  local seen, out = {}, {}
  local function add(id)
    if type(id) == "string" and not seen[id] and encounterSlots(data, id) then
      seen[id] = true
      out[#out + 1] = id
    end
  end
  for id in pairs((data and data.encounters) or {}) do add(id) end
  local gen2 = data and data.gen2Encounters
  for _, group in ipairs(gen2 and { gen2.grass, gen2.swarmGrass, gen2.water } or {}) do
    for id in pairs(group or {}) do add(id) end
  end
  table.sort(out)
  return out
end

local function countSpeciesIn(value, wanted, seen, depth)
  if type(value) ~= "table" or depth > 5 then return 0 end
  if seen[value] then return 0 end
  seen[value] = true
  local n = 0
  local own = speciesOf(value)
  if own == wanted then n = n + 1 end
  for k, child in pairs(value) do
    if type(child) == "table" and k ~= "data" and k ~= "game" and k ~= "world" then
      n = n + countSpeciesIn(child, wanted, seen, depth + 1)
    end
  end
  return n
end

function Quests.new(manager, saved)
  local self = setmetatable({
    manager = manager,
    offers = {},
    history = {},
    nextId = 1,
    lastRefreshTick = -9999,
    captureBaselines = {},
    pendingFollowUps = {},
  }, Quests)
  if type(saved) == "table" then self:restore(saved) end
  return self
end

function Quests:tick()
  return tonumber(self.manager and self.manager.sim and self.manager.sim.tick)
    or tonumber(self.manager and self.manager.rocket and self.manager.rocket.tick)
    or 0
end

function Quests:graphHas(mapId)
  local graph = self.manager and self.manager.graph
  return not graph or not graph.has or graph:has(mapId)
end

function Quests:newId(prefix)
  local id = tostring(prefix or "quest") .. "_" .. tostring(self.nextId)
  self.nextId = self.nextId + 1
  return id
end


-- 7.0.0 weather/faction mission helpers. They only CREATE an offer when an
-- NPC talk path calls them; refresh/observe never invents quests.
function Quests:weatherContext()
  local compat=self.manager and self.manager.compat
  if not (compat and compat.weatherSnapshot) then return nil end
  local ok,snap=pcall(compat.weatherSnapshot,compat)
  if not ok or type(snap)~="table" or snap.present==false then return nil end
  return snap
end

function Quests:weatherVariantPool()
  local out={}
  for id,def in pairs((self.manager and self.manager.data and self.manager.data.pokemon) or {}) do
    if type(id)=="string" and id:match("^WX_") and type(def)=="table" then out[#out+1]=id end
  end
  table.sort(out); return out
end

function Quests:pickWeatherTarget()
  local snap=self:weatherContext(); if not snap then return nil end
  local world=self.manager and self.manager:worldView() or {}
  local map=world.playerMap
  local weather=snap.weather or snap.overworld or snap.id
  local regions=snap.regions
  if type(regions)=="table" and #regions>0 then
    local row=regions[((self.nextId-1)%#regions)+1]
    if type(row)=="table" then map=row.mapId or row.map or row.location or map; weather=row.weather or weather end
  end
  return map,weather,snap
end

function Quests:scientistWeatherOffer(giverId,giverName)
  local map,weather=self:pickWeatherTarget(); if not map then return nil end
  local variants=self:weatherVariantPool(); local useVariant=#variants>0 and ((self.nextId%2)==0)
  local q
  if useVariant then
    local species=variants[((self.nextId-1)%#variants)+1]
    q={id=self:newId("science_weather"),kind="WEATHER_VARIANT",faction="researchers",
      giver=giverName or "Weather Scientist",giverId=giverId,title="Variant Field Study",
      map=map,species=species,status="OFFERED",createdTick=self:tick(),rewardMoney=1800,rewardItem="RARE_CANDY",
      description="Find and catch "..spaced(species).." so its weather adaptation can be studied.",
      dialogue="The weather is changing local Pokémon. I need a live "..spaced(species).." specimen. Catch one and bring your findings back to me.",
      sourceInteraction=true,offeredByNpc=true}
  else
    q={id=self:newId("science_weather"),kind="WEATHER_SURVEY",faction="researchers",
      giver=giverName or "Weather Scientist",giverId=giverId,title="Weather Field Survey",
      map=map,weather=weather or "CLEAR",requiredCount=3,countDone=0,status="OFFERED",createdTick=self:tick(),rewardMoney=1200,rewardItem="RARE_CANDY",
      description="Observe "..spaced(map).." during "..spaced(weather or "CLEAR").." weather for 3 field readings.",
      dialogue="I need field data, not a guess. Go to "..spaced(map).." while the weather is "..spaced(weather or "CLEAR").." and stay long enough for three readings.",
      sourceInteraction=true,offeredByNpc=true}
  end
  if not self:hasObjective(q) then self.offers[#self.offers+1]=q; pcall(function() self.manager:save() end); return q end
  return nil
end

function Quests:rocketWeatherOffer(member)
  if not member then return nil end
  local map,weather=self:pickWeatherTarget(); if not map then return nil end
  local variants=self:weatherVariantPool(); local q
  if #variants>0 and (self.nextId%2)==0 then
    local species=variants[((self.nextId-1)%#variants)+1]
    q={id=self:newId("rocket_weather"),kind="ROCKET_VARIANT_PROCURE",rocketMission=true,faction="rocket",
      giver=(member.rank or "Grunt").." "..(member.name or "Rocket"),giverId=member.id,title="Rocket Variant Procurement",
      map=map,species=species,status="OFFERED",createdTick=self:tick(),rewardMoney=2200,rewardItem="AIR_ROCKET_BALL",
      description="Acquire "..spaced(species).." for Team Rocket's weather-variant program.",
      dialogue="We've got buyers interested in weather variants. Get us a "..spaced(species)..". Catch it, trade for it, whatever works. Just make sure it reaches your collection.",
      sourceInteraction=true,offeredByNpc=true}
  else
    q={id=self:newId("rocket_weather"),kind="ROCKET_WEATHER_THEFT",rocketMission=true,faction="rocket",
      giver=(member.rank or "Grunt").." "..(member.name or "Rocket"),giverId=member.id,title="Storm Cover Job",
      map=map,weather=weather or "CLEAR",requiredCount=2,countDone=0,status="OFFERED",createdTick=self:tick(),rewardMoney=2000,rewardItem="AIR_ROCKET_BALL",
      description="Steal 2 trainer Pokémon in "..spaced(map).." while the weather is "..spaced(weather or "CLEAR")..".",
      dialogue="Bad weather keeps witnesses indoors. Wear the uniform and steal two trainer Pokémon in "..spaced(map).." while it's "..spaced(weather or "CLEAR")..".",
      sourceInteraction=true,offeredByNpc=true}
  end
  if not self:hasObjective(q) then self.offers[#self.offers+1]=q; pcall(function() self.manager:save() end); return q end
  return nil
end

function Quests:rocketOffer()
  local rocket = self.manager and self.manager.rocket
  if not rocket then return nil end
  local byMap = {}
  for _, member in ipairs(rocket.members or {}) do
    if member.active and member.map and not member.defeatedUntil then
      byMap[member.map] = byMap[member.map] or {}
      byMap[member.map][#byMap[member.map] + 1] = member.id
    end
  end
  local world = self.manager:worldView() or {}
  local mapId = world.playerMap
  if not (mapId and byMap[mapId] and #byMap[mapId] > 0) then
    local choices = {}
    for id, ids in pairs(byMap) do
      if #ids > 0 and self:graphHas(id) then choices[#choices + 1] = id end
    end
    table.sort(choices)
    if #choices == 0 then return nil end
    mapId = choices[((self.nextId - 1) % #choices) + 1]
  end
  local targets = copy(byMap[mapId])
  table.sort(targets)
  local count = #targets
  return {
    id = self:newId("rocket"),
    kind = "CLEAR_ROCKETS",
    giver = "POLICE",
    title = "Clear Team Rocket",
    map = mapId,
    targetIds = targets,
    defeated = {},
    status = "OFFERED",
    createdTick = self:tick(),
    rewardMoney = math.min(5000, 500 + count * 250),
    rewardItem = "RARE_CANDY",
    description = "Defeat all " .. tostring(count) .. " Team Rocket "
      .. (count == 1 and "member" or "members") .. " in " .. spaced(mapId) .. ".",
  }
end

function Quests:catchOffer()
  local data = self.manager and self.manager.data
  local maps = allEncounterMaps(data)
  if #maps == 0 then return nil end

  -- Prefer Mt. Moon whenever the loaded conversion exposes it. After that,
  -- rotate through real encounter maps instead of inventing locations.
  local preferred = {}
  for _, id in ipairs(maps) do
    if id:find("MT_MOON", 1, true) then preferred[#preferred + 1] = id end
  end
  local pool = #preferred > 0 and preferred or maps
  local mapId = pool[((self.nextId - 1) % #pool) + 1]
  local species = rareSpecies(data, mapId)
  if not species then return nil end

  return {
    id = self:newId("oak"),
    kind = "CATCH_RARE",
    giver = "PROF. OAK",
    title = "Oak's Rare Pokemon",
    map = mapId,
    species = species,
    status = "OFFERED",
    createdTick = self:tick(),
    rewardMoney = 1000,
    rewardItem = "RARE_CANDY",
    description = "Catch a rare " .. spaced(species) .. " in " .. spaced(mapId)
      .. " for Professor Oak.",
  }
end

function Quests:sameObjective(a, b)
  if not (a and b) or a.kind ~= b.kind then return false end
  if a.kind == "CATCH_RARE" or a.kind == "TRADE_SPECIES" or a.kind == "WEATHER_VARIANT" or a.kind == "ROCKET_VARIANT_PROCURE" then
    return a.map == b.map and a.species == b.species
  end
  if a.kind == "WEATHER_SURVEY" or a.kind == "ROCKET_WEATHER_THEFT" then
    return a.map == b.map and a.weather == b.weather
  end
  if a.kind == "CLEAR_ROCKETS" or a.kind == "DEFEAT_ROCKET" then
    return a.map == b.map
  end
  if a.kind == "GIVE_ITEM" then return a.item == b.item and a.giverId == b.giverId end
  if a.kind == "DEFEAT_RIVAL" then return a.targetRivalId == b.targetRivalId end
  if a.kind == "ACCOMPANY" then return a.giverId == b.giverId end
  if a.rangerMission or b.rangerMission then return a.kind == b.kind and a.map == b.map end
  return false
end

function Quests:hasObjective(q)
  for _, row in ipairs(self.offers or {}) do
    if row.status ~= "CLAIMED" and self:sameObjective(row, q) then return true end
  end
  return false
end

-- How much a rival likes the player (0..1), used to scale accompany duration.
function Quests:playerAffinity(rival)
  if not rival then return 0.35 end
  local affection, regard = 0, 0
  pcall(function()
    local bond = rival.bondWith and rival:bondWith("player")
    if type(bond) == "table" then
      affection = tonumber(bond.affection) or 0
      regard = tonumber(bond.regard) or 0
    end
  end)
  -- affection/regard are roughly -100..100; map into 0..1 with a soft floor.
  local score = (affection + 100) / 200 * 0.65 + (regard + 100) / 200 * 0.35
  if score < 0 then score = 0 elseif score > 1 then score = 1 end
  return score
end

function Quests:pickRivalGiver()
  local rivals = self.manager and self.manager.rivals or {}
  local live = {}
  for _, r in ipairs(rivals) do
    if r and r.id and not r.rocketAffiliation then live[#live + 1] = r end
  end
  if #live == 0 then return nil end
  return live[((self.nextId - 1) % #live) + 1]
end

function Quests:tradeSpeciesOffer()
  local giver = self:pickRivalGiver()
  if not giver then return nil end
  local data = self.manager and self.manager.data
  local maps = allEncounterMaps(data)
  if #maps == 0 then return nil end
  local mapId = maps[((self.nextId - 1) % #maps) + 1]
  local species = rareSpecies(data, mapId)
  if not species then return nil end
  local name = giver.name or giver.id
  return {
    id = self:newId("trade"),
    kind = "TRADE_SPECIES",
    giver = name,
    giverId = giver.id,
    title = name .. " wants a trade",
    map = mapId,
    species = species,
    status = "OFFERED",
    createdTick = self:tick(),
    rewardMoney = 1200,
    rewardItem = "RARE_CANDY",
    description = "Catch a " .. spaced(species) .. " in " .. spaced(mapId)
      .. " and trade it to " .. name .. ".",
  }
end

function Quests:giveItemOffer()
  local giver = self:pickRivalGiver()
  if not giver then return nil end
  local items = {
    "POTION", "SUPER_POTION", "ANTIDOTE", "AWAKENING", "PARLYZ_HEAL",
    "FULL_HEAL", "REVIVE", "ETHER", "REPEL", "SUPER_REPEL", "X_ATTACK",
    "X_DEFEND", "DIRE_HIT", "GUARD_SPEC", "PROTEIN", "IRON", "CARBOS",
  }
  local item = items[((self.nextId - 1) % #items) + 1]
  local name = giver.name or giver.id
  return {
    id = self:newId("item"),
    kind = "GIVE_ITEM",
    giver = name,
    giverId = giver.id,
    title = name .. " needs an item",
    item = item,
    status = "OFFERED",
    createdTick = self:tick(),
    rewardMoney = 800,
    rewardItem = "RARE_CANDY",
    description = "Bring " .. name .. " a " .. spaced(item) .. ".",
  }
end

function Quests:defeatRivalOffer()
  local rivals = self.manager and self.manager.rivals or {}
  if #rivals < 2 then return nil end
  local giver = self:pickRivalGiver()
  if not giver then return nil end
  local targets = {}
  for _, r in ipairs(rivals) do
    if r and r.id and r.id ~= giver.id and not r.rocketAffiliation then
      targets[#targets + 1] = r
    end
  end
  if #targets == 0 then return nil end
  local target = targets[((self.nextId - 1) % #targets) + 1]
  local name = giver.name or giver.id
  local tname = target.name or target.id
  return {
    id = self:newId("duel"),
    kind = "DEFEAT_RIVAL",
    giver = name,
    giverId = giver.id,
    title = name .. " wants a favour",
    targetRivalId = target.id,
    targetName = tname,
    status = "OFFERED",
    createdTick = self:tick(),
    rewardMoney = 1500,
    rewardItem = "RARE_CANDY",
    description = "Defeat " .. tname .. " in battle for " .. name .. ".",
  }
end

function Quests:defeatRocketMemberOffer()
  local rocket = self.manager and self.manager.rocket
  if not rocket then return nil end
  local members = {}
  for _, member in ipairs(rocket.members or {}) do
    if member.active and member.map and not member.defeatedUntil then
      members[#members + 1] = member
    end
  end
  if #members == 0 then return nil end
  local member = members[((self.nextId - 1) % #members) + 1]
  local giver = self:pickRivalGiver()
  local name = (giver and (giver.name or giver.id)) or "A rival"
  return {
    id = self:newId("rocket1"),
    kind = "DEFEAT_ROCKET",
    giver = name,
    giverId = giver and giver.id or nil,
    title = name .. " vs Team Rocket",
    map = member.map,
    targetIds = { member.id },
    targetName = member.name or "a Rocket grunt",
    defeated = {},
    status = "OFFERED",
    createdTick = self:tick(),
    rewardMoney = 1000,
    rewardItem = "RARE_CANDY",
    description = "Defeat " .. tostring(member.name or "a Team Rocket member")
      .. " in " .. spaced(member.map) .. " for " .. name .. ".",
  }
end

function Quests:accompanyOffer()
  local giver = self:pickRivalGiver()
  if not giver then return nil end
  local affinity = self:playerAffinity(giver)
  -- 30 steps when they barely know you; 500 when they like you a lot.
  -- Badge count also stretches the walk -- more badges, longer outings.
  local badges = 0
  pcall(function()
    if self.manager and self.manager.playerBadgeCount then
      badges = self.manager:playerBadgeCount() or 0
    end
  end)
  local steps = math.floor(30 + affinity * 470 + badges * 25)
  if steps < 30 then steps = 30 elseif steps > 500 then steps = 500 end
  local name = giver.name or giver.id
  return {
    id = self:newId("walk"),
    kind = "ACCOMPANY",
    giver = name,
    giverId = giver.id,
    title = "Walk with " .. name,
    requiredSteps = steps,
    stepsDone = 0,
    status = "OFFERED",
    createdTick = self:tick(),
    rewardMoney = math.min(2500, 400 + steps * 3),
    rewardItem = "RARE_CANDY",
    description = "Accompany " .. name .. " for " .. tostring(steps)
      .. " steps. They will join you when you accept.",
  }
end

local RANGER_MISSION_TYPES = {
  {
    kind = "RANGER_FOREST_SWEEP",
    title = "Stop the Poaching",
    description = "Stop Team Rocket from poaching wild Pokemon in %s. Defeat %d Rocket members without leaving the area.",
    dialogue = "Team Rocket is stripping this area for Pokemon. Stay in %s and defeat %d Rocket members. If you leave, the patrol is broken and you must start again.",
    count = 25,
  },
  {
    kind = "RANGER_PROTECT_SPECIES",
    title = "Protect the Population",
    description = "Protect the local %s population in %s. Defeat %d Rocket members operating there.",
    dialogue = "Rocket is targeting %s here. I need you to stay in %s and drive out %d of their members before they can finish the operation.",
    count = 12,
  },
  {
    kind = "RANGER_STOP_CONVOY",
    title = "Stop the Rocket Convoy",
    description = "Intercept Team Rocket's operation in %s. Defeat %d Rocket members before the convoy can move on.",
    dialogue = "Rocket is moving something through %s. Intercept them here and defeat %d members before that convoy gets away.",
    count = 8,
  },
  {
    kind = "RANGER_RESCUE_STOLEN",
    title = "Rescue Stolen Pokemon",
    description = "Rescue Pokemon stolen by Team Rocket in %s. Defeat %d Rocket members involved in the theft.",
    dialogue = "Rocket has been stealing Pokemon around %s. Find their people and defeat %d of them so we can break the theft operation.",
    count = 10,
  },
  {
    kind = "RANGER_BREAK_OPERATION",
    title = "Break the Operation",
    description = "Break Team Rocket's operation in %s by defeating %d Rocket members there.",
    dialogue = "This is bigger than a single grunt. Rocket has built an operation in %s. Break it by defeating %d of their members.",
    count = 15,
  },
  {
    kind = "RANGER_INTERCEPT_RECRUITMENT",
    title = "Stop the Recruitment Drive",
    description = "Stop Team Rocket recruiting in %s. Defeat %d Rocket members before they can expand.",
    dialogue = "Rocket is recruiting in %s. Shut the drive down. Defeat %d Rocket members here and we can stop new recruits from taking root.",
    count = 10,
  },
  {
    kind = "RANGER_ECOLOGY_DEFENSE",
    title = "Defend the Habitat",
    description = "Defend the habitat in %s from Team Rocket. Defeat %d Rocket members in the affected area.",
    dialogue = "Their activity is upsetting the local habitat in %s. Hold the area and defeat %d Rocket members before the damage spreads.",
    count = 12,
  },
  {
    kind = "RANGER_LAST_STAND",
    title = "Ranger Last Stand",
    description = "Hold %s against Team Rocket. Defeat %d Rocket members before the patrol ends.",
    dialogue = "We're stretched thin. I need you at %s. Stay there and defeat %d Rocket members. This is our last stand for the route.",
    count = 20,
  },
}

function Quests:rangerMissionOffer(ranger)
  local rangers = self.manager and self.manager.rangers
  local rocket = self.manager and self.manager.rocket
  if not (rangers and rocket and #rangers.members > 0) then return nil end
  local byMap, speciesByMap = {}, {}
  for _, member in ipairs(rocket.members or {}) do
    if member.active and member.map and not member.defeatedUntil then
      byMap[member.map] = byMap[member.map] or {}
      byMap[member.map][#byMap[member.map]+1] = member.id
    end
  end
  local maps = {}
  for mapId in pairs(byMap) do maps[#maps+1] = mapId end
  table.sort(maps)
  if #maps == 0 then return nil end
  local mapId = maps[((self.nextId - 1) % #maps) + 1]
  local data = self.manager.data
  local species = nil
  local row = data and data.encounters and data.encounters[mapId]
  local slots = row and (row.slots or row.grass or row)
  if type(slots) == "table" then
    for _, e in ipairs(slots) do
      local sp = type(e)=="table" and (e.species or e.mon) or e
      if type(sp)=="string" then species=sp; break end
    end
  end
  local def = RANGER_MISSION_TYPES[((self.nextId - 1) % #RANGER_MISSION_TYPES) + 1]
  local n = tonumber(def.count) or 10
  if def.kind == "RANGER_FOREST_SWEEP" and not tostring(mapId):find("FOREST",1,true) then
    n = 20
  end
  local name = (ranger and ranger.name) or "Ranger"
  local title = def.title
  local desc
  local dialogue
  if def.kind == "RANGER_FOREST_SWEEP" then
    desc = string.format(def.description, spaced(mapId), n)
    dialogue = string.format(def.dialogue, spaced(mapId), n)
  elseif def.kind == "RANGER_PROTECT_SPECIES" then
    local sp = spaced(species or "Pokemon")
    desc = string.format(def.description, sp, spaced(mapId), n)
    dialogue = string.format(def.dialogue, sp, spaced(mapId), n)
  else
    desc = string.format(def.description, spaced(mapId), n)
    dialogue = string.format(def.dialogue, spaced(mapId), n)
  end
  local q = {
    id=self:newId("ranger"), kind=def.kind, giver=name, giverId=ranger and ranger.id or nil,
    title=title, map=mapId, targetIds=copy(byMap[mapId]), defeated={},
    requiredCount=n, countDone=0, status="OFFERED", createdTick=self:tick(),
    rewardMoney=1500 + n*50, rewardItem="RARE_CANDY", description=desc,
    dialogue=dialogue, species=species, rangerMission=true, faction="rangers",
    sourceInteraction=true, offeredByNpc=true,
  }
  return q
end

function Quests:rangerPatrolOffer(ranger)
  return self:rangerMissionOffer(ranger)
end

-- 6.3.0: generic dynamic requests may only be minted by a concrete issuer.
-- World events can suggest a need, but they cannot place a quest in the log.
function Quests:offerFromIssuer(issuer, spec)
  if type(issuer)~="table" or not (issuer.id or issuer.name) or type(spec)~="table" then return nil end
  local q=copy(spec)
  q.id=q.id or self:newId(q.faction or "request")
  q.giver=q.giver or issuer.name or issuer.id
  q.giverId=q.giverId or issuer.id
  q.status="OFFERED"; q.createdTick=self:tick()
  q.sourceInteraction=true; q.offeredByNpc=true
  q.dialogue=q.dialogue or (tostring(q.giver)..": "..tostring(q.description or "I need your help."))
  if self:hasObjective(q) then return nil end
  self.offers[#self.offers+1]=q
  pcall(function() self.manager:save() end)
  return q
end

-- 6.4.0: completing a job can create a *potential* next chapter, but it is
-- deliberately held outside the Pokégear. It only becomes a quest when the
-- original issuer (or a compatible faction NPC) speaks to the player again.
function Quests:queueFollowUp(q)
  if type(q)~="table" or not q.giverId then return nil end
  local chapter=(tonumber(q.chainChapter) or 1)+1
  if chapter>4 then return nil end
  local spec={
    chainId=q.chainId or q.id, chainParent=q.id, chainChapter=chapter,
    giver=q.giver, giverId=q.giverId, faction=q.faction, map=q.map,
    rocketMission=q.rocketMission==true, rangerMission=q.rangerMission==true,
    sourceInteraction=false, offeredByNpc=false,
  }
  if q.rocketMission or q.faction=="rocket" then
    spec.kind="ROCKET_JOB"; spec.title="Rocket Follow-up: "..spaced(q.map or "operation")
    spec.requiredCount=math.min(3,chapter); spec.countDone=0
    spec.description="Steal "..tostring(spec.requiredCount).." trainer Pokémon in "..spaced(q.map or "the operation area").." using Rocket Balls."
    spec.dialogue="Good. That opened another opportunity. Head back to "..spaced(q.map or "the operation area").." and finish the next stage."
    spec.rewardMoney=1400+chapter*250; spec.rewardItem="AIR_ROCKET_BALL"
  elseif q.rangerMission or q.faction=="rangers" then
    spec.kind="RANGER_FOLLOWUP"; spec.title="Ranger Follow-up: "..spaced(q.map or "operation")
    spec.description="Return to "..tostring(q.giver or "the Ranger").." for the next stage of the response."
    spec.dialogue="Your last operation changed things. We have a follow-up assignment in "..spaced(q.map or "the area")..". I need you there again."
    spec.rewardMoney=1600+chapter*250; spec.rewardItem="RARE_CANDY"
  else
    spec.kind="FOLLOW_UP"; spec.title="Follow-up: "..tostring(q.title or "Request")
    spec.description="Speak with "..tostring(q.giver or "the issuer").." about what happened next."
    spec.dialogue="What you did had consequences. I need your help with the next part."
    spec.rewardMoney=tonumber(q.rewardMoney) or 750; spec.rewardItem=q.rewardItem or "RARE_CANDY"
  end
  self.pendingFollowUps[#self.pendingFollowUps+1]=spec
  while #self.pendingFollowUps>20 do table.remove(self.pendingFollowUps,1) end
  return spec
end

function Quests:takePendingFollowUp(issuerId,issuerName)
  for i,spec in ipairs(self.pendingFollowUps or {}) do
    if spec.giverId==issuerId then
      table.remove(self.pendingFollowUps,i)
      spec.giver=issuerName or spec.giver
      spec.id=self:newId(spec.faction or "followup")
      spec.status="OFFERED"; spec.createdTick=self:tick()
      spec.sourceInteraction=true; spec.offeredByNpc=true
      self.offers[#self.offers+1]=spec
      pcall(function() self.manager:save() end)
      return spec
    end
  end
  return nil
end

function Quests:refresh(force)
  local tick = self:tick()
  if not force and tick - (self.lastRefreshTick or -9999) < 120 then return false end
  self.lastRefreshTick = tick
  -- IMPORTANT: a quest is never created merely because the Pokégear screen
  -- was opened or because the world tick advanced. Offers are created only by
  -- an explicit conversation/request path (rival phone call, rival dialogue,
  -- Ranger conversation, etc.).
  local untouched = {}
  for i, q in ipairs(self.offers or {}) do
    if q.status == "OFFERED" then untouched[#untouched+1] = i end
  end
  while #untouched > 8 do
    table.remove(self.offers, untouched[1])
    untouched = {}
    for i, q in ipairs(self.offers or {}) do
      if q.status == "OFFERED" then untouched[#untouched+1] = i end
    end
  end
  return true
end

function Quests:list()
  self:refresh(false)
  return self.offers
end

-- Everything the Pokégear Quests screen should show: formal offers plus
-- active Rocket incident requests so the player has one place for every job.
function Quests:listAll()
  self:refresh(false)
  local out = {}
  for _, q in ipairs(self.offers or {}) do out[#out+1] = q end
  return out
end

function Quests:get(id)
  for _, q in ipairs(self.offers or {}) do if q.id == id then return q end end
  return nil
end

function Quests:accept(id)
  local q = self:get(id)
  if not q then return false, "Quest not found." end
  if q.status ~= "OFFERED" then return false, "Quest is already " .. tostring(q.status):lower() .. "." end
  local active = 0
  for _, row in ipairs(self.offers) do
    if row.status == "ACTIVE" or row.status == "COMPLETE" then active = active + 1 end
  end
  if active >= 8 then return false, "Finish a quest before taking another." end
  q.status = "ACTIVE"
  q.acceptedTick = self:tick()
  if self.manager and self.manager.doubleAgent then
    if q.rocketMission or q.faction=="rocket" then self.manager.doubleAgent:record("ROCKET_JOB_ACCEPTED",{map=q.map,target=q.giverId})
    elseif q.rangerMission or q.faction=="rangers" then self.manager.doubleAgent:record("RANGER_JOB_ACCEPTED",{map=q.map,target=q.giverId}) end
  end
  if q.kind == "CATCH_RARE" or q.kind == "TRADE_SPECIES" or q.kind == "WEATHER_VARIANT" or q.kind == "ROCKET_VARIANT_PROCURE" then
    q.baseline = self:ownedCount(q.species)
    self.captureBaselines[q.id] = q.baseline
  end
  if q.rangerMission then
    local currentMap = nil
    pcall(function() currentMap = self.manager:worldView().playerMap end)
    q.playerMap = currentMap
    q.countDone = 0
  end
  if q.kind == "ACCOMPANY" and q.giverId and self.manager and self.manager.setCompanion then
    local rival = self.manager.byId and self.manager.byId[q.giverId]
    if rival then
      pcall(function() self.manager:setCompanion(rival) end)
      q.stepsDone = 0
    end
  end
  pcall(function() self.manager:save() end)
  return true, "Quest accepted."
end

function Quests:ownedCount(species)
  local save = self.manager and self.manager.game and self.manager.game.save
  if type(save) ~= "table" or not species then return 0 end

  -- Search only structures that can reasonably own Pokemon. This covers the
  -- common Gen1Recomp party, PC/boxes and conversion-specific storage shapes.
  local roots = {
    save.party, save.boxes, save.pcBoxes, save.storage, save.pc,
    save.pokemonBoxes, save.box,
  }
  local n = 0
  for _, value in ipairs(roots) do
    n = n + countSpeciesIn(value, species, {}, 0)
  end
  return n
end

function Quests:complete(q, line)
  if not q or q.status ~= "ACTIVE" then return false end
  q.status = "COMPLETE"
  q.completedTick = self:tick()
  q.completionLine = line
  local manager = self.manager
  if manager and manager.doubleAgent then
    if q.rocketMission or q.faction=="rocket" then manager.doubleAgent:record("ROCKET_JOB_COMPLETED",{map=q.map,target=q.giverId})
    elseif q.rangerMission or q.faction=="rangers" then manager.doubleAgent:record("RANGER_JOB_COMPLETED",{map=q.map,target=q.giverId}) end
  end
  if manager then
    manager.ticker = {
      text = "QUEST COMPLETE  •  " .. tostring(q.title),
      age = 0, duration = 9, offset = 0,
    }
    pcall(function()
      manager:addNews({ name = q.giver or "Quest" }, {
        kind = "news", text = tostring(line or q.title) .. " Quest complete."
      })
    end)
    pcall(function() manager:save() end)
  end
  return true
end

function Quests:observe(world)
  if not world or not world.playerMap then return false end
  local changed = false
  for _, q in ipairs(self.offers or {}) do
    if q.status == "ACTIVE" and q.rangerMission then
      if q.playerMap and q.playerMap ~= world.playerMap then
        q.countDone = 0
        q.playerMap = world.playerMap
        q.leftArea = true
        changed = true
      elseif not q.playerMap then
        q.playerMap = world.playerMap
      end
    end
    if q.status == "ACTIVE" and q.kind == "CATCH_RARE" and q.map == world.playerMap then
      local baseline = tonumber(q.baseline)
      if baseline == nil then
        q.baseline = self:ownedCount(q.species)
      else
        local now = self:ownedCount(q.species)
        if now > baseline then
          self:complete(q, "A " .. spaced(q.species) .. " was caught in " .. spaced(q.map) .. ".")
          changed = true
        end
      end
    end
    if q.status=="ACTIVE" and (q.kind=="WEATHER_VARIANT" or q.kind=="ROCKET_VARIANT_PROCURE") then
      local now=self:ownedCount(q.species); local baseline=tonumber(q.baseline) or 0
      if now>baseline then self:complete(q,spaced(q.species).." was acquired for the mission."); changed=true end
    elseif q.status=="ACTIVE" and q.kind=="WEATHER_SURVEY" and q.map==world.playerMap then
      local snap=self:weatherContext(); local current=snap and (snap.weather or snap.overworld or snap.id)
      if tostring(current)==tostring(q.weather) then
        q.lastReadingTick=q.lastReadingTick or -9999
        if self:tick()-q.lastReadingTick>=20 then q.lastReadingTick=self:tick(); q.countDone=(q.countDone or 0)+1; changed=true end
        if (q.countDone or 0)>=(q.requiredCount or 3) then self:complete(q,"The weather survey in "..spaced(q.map).." is complete.") end
      end
    end
  end
  return changed
end

function Quests:progress(q)
  if not q then return "" end
  if q.kind == "CLEAR_ROCKETS" or q.kind == "DEFEAT_ROCKET" then
    local done, total = 0, #(q.targetIds or {})
    for _, id in ipairs(q.targetIds or {}) do if q.defeated and q.defeated[id] then done = done + 1 end end
    return tostring(done) .. "/" .. tostring(total)
  elseif q.kind == "CATCH_RARE" or q.kind == "TRADE_SPECIES" or q.kind == "WEATHER_VARIANT" or q.kind == "ROCKET_VARIANT_PROCURE" then
    if q.status == "COMPLETE" or q.status == "CLAIMED" then return "DONE" end
    return "SEARCHING"
  elseif q.kind == "GIVE_ITEM" then
    if q.status == "COMPLETE" or q.status == "CLAIMED" then return "GIVEN" end
    return spaced(q.item or "ITEM")
  elseif q.kind == "DEFEAT_RIVAL" then
    if q.status == "COMPLETE" or q.status == "CLAIMED" then return "DEFEATED" end
    return tostring(q.targetName or "RIVAL")
  elseif q.kind == "ACCOMPANY" then
    local need = tonumber(q.requiredSteps) or 30
    local done = tonumber(q.stepsDone) or 0
    return tostring(math.min(done, need)) .. "/" .. tostring(need)
  elseif q.kind == "WEATHER_SURVEY" then
    return tostring(math.min(tonumber(q.countDone) or 0,tonumber(q.requiredCount) or 3)).."/"..tostring(q.requiredCount or 3).." READINGS"
  elseif q.kind == "ROCKET_WEATHER_THEFT" then
    return tostring(math.min(tonumber(q.countDone) or 0,tonumber(q.requiredCount) or 2)).."/"..tostring(q.requiredCount or 2).." STOLEN"
  elseif q.kind == "ROCKET_JOB" then
    local done=tonumber(q.countDone) or 0; local need=tonumber(q.requiredCount) or 1
    return tostring(math.min(done,need)).."/"..tostring(need).." STOLEN"
  elseif q.kind == "ROCKET_REQUEST" then
    return q.map and spaced(q.map) or "WATCH"
  elseif q.rangerMission then
    local done = tonumber(q.countDone) or 0
    local need = tonumber(q.requiredCount) or 1
    return tostring(math.min(done, need)) .. "/" .. tostring(need)
  end
  return ""
end

-- Called when the player moves one tile while a companion accompany quest is active.
function Quests:onPlayerStep()
  local changed = false
  local companionId = self.manager and self.manager.companionId
  if not companionId then return false end
  for _, q in ipairs(self.offers or {}) do
    if q.status == "ACTIVE" and q.kind == "ACCOMPANY" and q.giverId == companionId then
      q.stepsDone = (tonumber(q.stepsDone) or 0) + 1
      if q.stepsDone >= (tonumber(q.requiredSteps) or 30) then
        self:complete(q, "You walked with " .. tostring(q.giver) .. ".")
      end
      changed = true
    end
  end
  return changed
end

-- Called after the player wins a battle against a rival.
function Quests:onRivalDefeated(rivalId)
  if not rivalId then return false end
  local changed = false
  for _, q in ipairs(self.offers or {}) do
    if q.status == "ACTIVE" and q.kind == "DEFEAT_RIVAL" and q.targetRivalId == rivalId then
      self:complete(q, "You defeated " .. tostring(q.targetName or rivalId) .. ".")
      changed = true
    end
  end
  return changed
end

-- Called when a Rocket member is defeated by the player.
-- Accepts either a member table or a member id string.
function Quests:onRocketDefeated(memberOrId, mapId)
  local memberId = memberOrId
  if type(memberOrId) == "table" then
    memberId = memberOrId.id
    mapId = mapId or memberOrId.map
  end
  if not memberId then return false end
  local changed = false
  local playerMap = nil
  pcall(function() playerMap = self.manager:worldView().playerMap end)
  for _, q in ipairs(self.offers or {}) do
    if q.status == "ACTIVE" and q.rangerMission and q.map == mapId and q.map == playerMap then
      q.countDone = (tonumber(q.countDone) or 0) + 1
      changed = true
      if q.countDone >= (tonumber(q.requiredCount) or 1) then
        self:complete(q, "The Ranger operation in " .. spaced(q.map) .. " was stopped.")
      end
    end
  end
  for _, q in ipairs(self.offers or {}) do
    if q.status == "ACTIVE" and (q.kind == "CLEAR_ROCKETS" or q.kind == "DEFEAT_ROCKET") then
      local isTarget = false
      for _, id in ipairs(q.targetIds or {}) do
        if id == memberId then isTarget = true break end
      end
      if isTarget then
        q.defeated = q.defeated or {}
        q.defeated[memberId] = true
        changed = true
        local left = 0
        for _, id in ipairs(q.targetIds or {}) do
          if not q.defeated[id] then left = left + 1 end
        end
        if left == 0 then
          self:complete(q, q.kind == "DEFEAT_ROCKET"
            and ("You defeated " .. tostring(q.targetName or "Team Rocket") .. ".")
            or ("Team Rocket was driven out of " .. spaced(q.map) .. "."))
        end
      end
    end
  end
  if changed then pcall(function() self.manager:save() end) end
  return changed
end

-- Called when the player hands an item to a rival (talk/help path).
function Quests:onItemGiven(rivalId, itemId)
  if not (rivalId and itemId) then return false end
  local changed = false
  local wanted = tostring(itemId):upper()
  for _, q in ipairs(self.offers or {}) do
    if q.status == "ACTIVE" and q.kind == "GIVE_ITEM"
       and q.giverId == rivalId
       and tostring(q.item or ""):upper() == wanted then
      self:complete(q, "You gave " .. spaced(q.item) .. " to " .. tostring(q.giver) .. ".")
      changed = true
    end
  end
  return changed
end

-- Called when the player trades a species to a rival.
function Quests:onSpeciesTraded(rivalId, species)
  if not (rivalId and species) then return false end
  local changed = false
  for _, q in ipairs(self.offers or {}) do
    if q.status == "ACTIVE" and q.kind == "TRADE_SPECIES"
       and q.giverId == rivalId
       and tostring(q.species) == tostring(species) then
      self:complete(q, "You traded " .. spaced(species) .. " to " .. tostring(q.giver) .. ".")
      changed = true
    end
  end
  return changed
end

-- Rocket jobs progress through actual Rocket Ball thefts, not passive world ticks.
function Quests:onRocketTheft(species,mapId)
  local changed=false
  for _,q in ipairs(self.offers or {}) do
    if q.status=="ACTIVE" and q.kind=="ROCKET_WEATHER_THEFT" and (not q.map or q.map==mapId) then
      local snap=self:weatherContext(); local current=snap and (snap.weather or snap.overworld or snap.id)
      if tostring(current)==tostring(q.weather) then
        q.countDone=(tonumber(q.countDone) or 0)+1; changed=true
        if q.countDone>=(tonumber(q.requiredCount) or 2) then self:complete(q,"The weather-covered Rocket theft is complete.") end
      end
    elseif q.status=="ACTIVE" and q.kind~="ROCKET_WEATHER_THEFT" and (q.kind=="ROCKET_JOB" or q.rocketMission)
       and (not q.map or q.map==mapId) then
      q.countDone=(tonumber(q.countDone) or 0)+1
      q.lastStolenSpecies=species
      changed=true
      if q.countDone >= (tonumber(q.requiredCount) or 1) then
        self:complete(q,"Team Rocket received the stolen Pokémon from "..spaced(mapId or q.map)..".")
      end
    end
  end
  return changed
end

function Quests:claim(id)
  local q = self:get(id)
  if not q then return false, "Quest not found." end
  if q.status ~= "COMPLETE" then return false, "Quest is not complete." end

  -- Reward each half independently and persist it. If an unusual conversion
  -- temporarily refuses one grant, reopening the Pokégear retries only the
  -- missing half instead of duplicating the other reward.
  if not q.candyGranted then
    q.candyGranted = self.manager:givePlayerItem(q.rewardItem or "RARE_CANDY") == true
  end
  if not q.moneyGranted then
    q.moneyGranted = self.manager:givePlayerMoney(q.rewardMoney or 500) == true
  end
  if not (q.candyGranted and q.moneyGranted) then
    pcall(function() self.manager:save() end)
    return false, "Reward could not be fully delivered."
  end

  q.status = "CLAIMED"
  q.claimedTick = self:tick()
  if not q.followUpQueued then
    q.followUpQueued = self:queueFollowUp(q) ~= nil
  end
  self.history[#self.history + 1] = copy(q)
  while #self.history > 40 do table.remove(self.history, 1) end
  pcall(function() self.manager:save() end)
  return true, "Received $" .. tostring(q.rewardMoney or 0) .. " and " .. spaced(q.rewardItem or "RARE_CANDY") .. "."
end

function Quests:serialize()
  return {
    version = 1,
    offers = copy(self.offers or {}),
    history = copy(self.history or {}),
    nextId = self.nextId,
    lastRefreshTick = self.lastRefreshTick,
    pendingFollowUps = copy(self.pendingFollowUps or {}),
  }
end

function Quests:restore(saved)
  if type(saved) ~= "table" then return end
  self.offers = type(saved.offers) == "table" and copy(saved.offers) or {}
  self.history = type(saved.history) == "table" and copy(saved.history) or {}
  self.nextId = math.max(1, tonumber(saved.nextId) or 1)
  self.lastRefreshTick = tonumber(saved.lastRefreshTick) or -9999
  self.pendingFollowUps = type(saved.pendingFollowUps)=="table" and copy(saved.pendingFollowUps) or {}
  self.captureBaselines = {}
end

return Quests
