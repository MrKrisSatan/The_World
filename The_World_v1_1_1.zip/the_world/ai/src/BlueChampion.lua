local req, mod = ...
local BattleSim = req("src/BattleSim")
local League = req("src/League")

local B={}
B.ID="blue"

local function trainers(manager)
  local d=manager and manager.data
  return d and (d.gen2Trainers or d.trainers)
end

local function classes(manager)
  local t=trainers(manager)
  return t and (t.classes or t) or {}
end

local function blueParty(manager)
  -- Blue is the Gen 1 Champion. In Gold the sitting vanilla Champion is Lance,
  -- so this subsystem deliberately stays out of Gen 2.
  local d=manager and manager.data
  if d and d.gen2Trainers then return nil end
  local best,bestStrength
  for cls,rec in pairs(classes(manager)) do
    local hay=(tostring(cls).." "..tostring(type(rec)=="table" and rec.name or "")):upper()
    if hay:find("RIVAL3",1,true) or hay:find("CHAMPION",1,true) then
      for idx in pairs((type(rec)=="table" and (rec.parties or rec.trainers)) or {}) do
        if type(idx)=="number" then
          local party=BattleSim.leaderParty(d,cls,idx)
          local strength=party and BattleSim.strength(d,party) or 0
          if party and #party>0 and (not bestStrength or strength>bestStrength) then
            best,bestStrength=party,strength
          end
        end
      end
    end
  end
  return best
end

function B.ensure(manager)
  manager.blueChampion=type(manager.blueChampion)=="table" and manager.blueChampion or {}
  local b=manager.blueChampion
  if b.initialized~=true then
    b.initialized=true
    b.champion=true
    b.reigns=1
    b.defences=0
    b.losses=0
    b.titleCooldown=0
    b.qualified=false
    b.qualifyCooldown=0
    b.history={{kind="REIGN_BEGAN",tick=0,opponent=nil}}
  end
  b.history=type(b.history)=="table" and b.history or {}
  return b
end

function B.current(manager)
  local b=B.ensure(manager)
  return b.champion==true
end

local function headline(manager,text)
  if manager and manager.addSystemNews then
    pcall(manager.addSystemNews,manager,text)
  elseif manager and manager.tickerQueue then
    manager.tickerQueue[#manager.tickerQueue+1]="LEAGUE  • "..text
  elseif manager then
    manager.ticker={text="LEAGUE  • "..text,age=0,duration=9,offset=0}
  end
end

function B.loseTitle(manager,toId,toName,tick)
  local b=B.ensure(manager)
  if not b.champion then return false end
  b.champion=false; b.losses=(b.losses or 0)+1
  b.qualified=false; b.qualifyCooldown=League.MIN_GAP
  b.history[#b.history+1]={kind="TITLE_LOST",tick=tick or 0,opponent=toId}
  manager.eliteChampionId=toId
  headline(manager,"BLUE lost the Champion title to "..tostring(toName or toId)..".")
  return true
end

function B.winTitle(manager,fromId,fromName,tick)
  local b=B.ensure(manager)
  b.champion=true; b.qualified=false
  b.reigns=(b.reigns or 0)+1
  b.titleCooldown=League.TITLE_GAP or 40
  b.history[#b.history+1]={kind="TITLE_WON",tick=tick or 0,opponent=fromId}
  manager.eliteChampionId="blue"
  for _,r in ipairs(manager.rivals or {}) do r.champion=false end
  headline(manager,"BLUE reclaimed the Champion title from "..tostring(fromName or fromId)..".")
  return true
end

function B.tick(manager)
  local b=B.ensure(manager)
  b.titleCooldown=math.max(0,(tonumber(b.titleCooldown) or 0)-1)
  b.qualifyCooldown=math.max(0,(tonumber(b.qualifyCooldown) or 0)-1)
end

function B.tryQualify(manager,world)
  local b=B.ensure(manager)
  if b.champion or b.qualified or (b.qualifyCooldown or 0)>0 then return nil end
  local holder
  for _,r in ipairs(manager.rivals or {}) do if r.champion then holder=r break end end
  if not holder then return nil end

  -- Blue has to clear the Elite Four again before every title shot. Use the
  -- real League parties, excluding the sitting Champion.
  local d=manager.data
  local roles={{"LORELEI"},{"BRUNO"},{"AGATHA"},{"LANCE"}}
  local blue=blueParty(manager)
  if not blue then return nil end
  local used={}
  for stage,tokens in ipairs(roles) do
    local foe
    for cls,rec in pairs(classes(manager)) do
      local hay=(tostring(cls).." "..tostring(type(rec)=="table" and rec.name or "")):upper()
      local match=false
      for _,tok in ipairs(tokens) do if hay:find(tok,1,true) then match=true break end end
      if match and not used[cls] then
        for idx in pairs((type(rec)=="table" and (rec.parties or rec.trainers)) or {}) do
          if type(idx)=="number" then
            foe=BattleSim.leaderParty(d,cls,idx)
            if foe and #foe>0 then used[cls]=true break end
          end
        end
      end
      if foe then break end
    end
    if not foe then return nil end
    local result=BattleSim.run(d,blue,foe,holder.rng)
    if not result or result.winner~="a" then
      b.qualifyCooldown=League.MIN_GAP
      b.history[#b.history+1]={kind="ELITE_FOUR_LOSS",tick=(world and world.tick) or 0,stage=stage}
      return {qualified=false,stage=stage}
    end
  end
  b.qualified=true
  b.qualifyCooldown=League.TITLE_GAP or 40
  b.history[#b.history+1]={kind="ELITE_FOUR_CLEAR",tick=(world and world.tick) or 0}
  headline(manager,"BLUE cleared the Elite Four and earned a Champion rematch.")
  return {qualified=true}
end

function B.tryTitleMatch(manager,world)
  local b=B.ensure(manager)
  if b.champion or not b.qualified or (b.titleCooldown or 0)>0 then return nil end
  local holder
  for _,r in ipairs(manager.rivals or {}) do if r.champion then holder=r break end end
  if not holder or holder:isFainted() then return nil end
  local blue=blueParty(manager)
  if not blue then return nil end
  if holder.prepareForBattle then holder:prepareForBattle() end
  local result=BattleSim.run(manager.data,blue,holder.party,holder.rng)
  local blueWon=result and result.winner=="a"
  local tick=(world and world.tick) or holder.ticks or 0
  b.qualified=false
  b.titleCooldown=League.TITLE_GAP or 40
  local rec=holder.ensureLeague and holder:ensureLeague()
  if rec then League.recordTitleMatch(rec,not blueWon,{defending=true}) end
  if blueWon then
    if rec then League.endReign(rec,tick) end
    if holder.leaveChampionLifePath then holder:leaveChampionLifePath("lost the Champion title to Blue") end
    B.winTitle(manager,holder.id,holder.name,tick)
  else
    b.losses=(b.losses or 0)+1
    b.history[#b.history+1]={kind="TITLE_LOSS",tick=tick,opponent=holder.id}
    if rec then League.recordTitleMatch(rec,true,{defending=true}) end
    headline(manager,tostring(holder.name).." successfully defended the title against BLUE.")
  end
  return {blueWon=blueWon,champion=holder.id,turns=result and result.turns}
end

return B
