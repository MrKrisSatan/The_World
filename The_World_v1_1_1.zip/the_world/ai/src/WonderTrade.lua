-- Wonder Trade, absorbed into AI Rivals.
-- The receive transaction is defensive and supports registered string-ID
-- species (including Weather FX variants) that intentionally have no ROM
-- index. Such species use a text handoff instead of the index-based animation.

local req, mod = ...
local W = { installed = false }

local PERFECT = { attack=15, defense=15, speed=15, special=15, hp=15 }
local OT_NAMES = { "ASH", "MISTY", "BROCK", "GARY", "JOY", "BILL", "LANCE",
  "ERIKA", "KOGA", "SABRINA", "BLAINE", "SURGE", "OAK", "DAISY", "RED",
  "BLUE", "LEAF", "GREEN", "JANINE", "WILL", "KAREN", "BRUNO", "AGATHA" }
local GEN1 = { "VIRIDIAN_POKECENTER", "PEWTER_POKECENTER", "CERULEAN_POKECENTER",
  "LAVENDER_POKECENTER", "VERMILION_POKECENTER", "CELADON_POKECENTER",
  "FUCHSIA_POKECENTER", "CINNABAR_POKECENTER", "SAFFRON_POKECENTER",
  "MT_MOON_POKECENTER", "ROCK_TUNNEL_POKECENTER" }
local GEN2 = { "CHERRYGROVE_POKECENTER_1F", "VIOLET_POKECENTER_1F",
  "ROUTE_32_POKECENTER_1F", "AZALEA_POKECENTER_1F", "GOLDENROD_POKECENTER_1F",
  "ECRUTEAK_POKECENTER_1F", "OLIVINE_POKECENTER_1F", "CIANWOOD_POKECENTER_1F",
  "MAHOGANY_POKECENTER_1F", "BLACKTHORN_POKECENTER_1F",
  "SILVER_CAVE_POKECENTER_1F", "INDIGO_PLATEAU_POKECENTER_1F",
  "VIRIDIAN_POKECENTER_1F", "PEWTER_POKECENTER_1F", "CERULEAN_POKECENTER_1F",
  "ROUTE_10_POKECENTER_1F", "VERMILION_POKECENTER_1F",
  "LAVENDER_POKECENTER_1F", "CELADON_POKECENTER_1F",
  "SAFFRON_POKECENTER_1F", "FUCHSIA_POKECENTER_1F", "CINNABAR_POKECENTER_1F" }
local TEXT, NPC_INDEX = "AIR_WONDER_TRADE", 92

local function rand(lo, hi)
  local f = love and love.math and love.math.random or math.random
  return f(lo, hi)
end

-- Which generation are we on -- or NIL when nobody can say yet.
--
-- This used to answer 1 on a fall-through.  W.install runs from the entry
-- chunk, where the manager is not ready and `mod.game` is often not up, so
-- that default registered Gen 1 `map_scripts` onto a Gold boot.  map_scripts
-- has NO Gen 2 home (src/mods/Schemas.lua: the Gen 2 VM runs cart bytecode,
-- not Lua row lists), so the loader reported "the map_scripts registry has no
-- Gen 2 target" in the mod manager's error feed on every Gold launch.
--
-- An unknown generation is not Gen 1.  Callers decide what to do with nil;
-- what they must not do is act on a guess.
local function gen(manager, mod_)
  if manager and manager.ready and manager.generation then return manager.generation end
  -- The manifest-independent signal: Gold loads its own tables under these
  -- names, and a Gen 1 boot has neither (same test as src/Version.lua).
  local data = mod_ and mod_.game and mod_.game.data
  if data then
    if data.gen2Maps or data.gen2Trainers then return 2 end
    if data.maps then return 1 end
  end
  -- `src.core.GameVersion` is NOT consulted, and that is deliberate.  It is not
  -- one of the fifteen names the Gen 2 adapter serves, so a require made from a
  -- mod chunk on Gold answers the Gen 1 module -- which reports generation 1.
  -- Measured: it is what put the map_scripts write onto a Gold boot even after
  -- the manager fallback was fixed.  A version oracle that is confidently wrong
  -- is worse than no oracle, which is the whole point of MK409 and of
  -- src/Version.lua's data sniffing.
  return nil
end

local function monSpecies(mon)
  local id = mon and (mon.species or mon.speciesId or mon.id)
  if type(id) == "table" then id = id.id or id.name end
  return type(id) == "string" and id or nil
end

function W.buildPool(data, manager)
  local pool, mapId = {}, nil
  pcall(function() mapId = manager:worldView().playerMap end)
  for id, def in pairs((data and data.pokemon) or {}) do
    local allowed = true
    if manager and manager.compat and manager.compat.krAllows then
      local ok, result = pcall(manager.compat.krAllows, manager.compat, id, mapId)
      allowed = not ok or result ~= false
    end
    if type(id) == "string" and id ~= "EGG" and type(def) == "table"
        and type(def.baseStats) == "table" and allowed then
      pool[#pool + 1] = id
    end
  end
  table.sort(pool)
  return pool
end

local function validate(mon, species)
  return type(mon) == "table" and monSpecies(mon) == species
end

local function perfectGen1(mon, data, species, level)
  mon.dvs = { attack=15, defense=15, speed=15, special=15, hp=15 }
  mon.shiny = true
  local ok, Stats = pcall(require, "src.pokemon.Stats")
  if not ok or not Stats or type(Stats.calc) ~= "function" then return end
  local def = data and data.pokemon and data.pokemon[species]
  local attempts = {
    function() return Stats.calc(def, level, mon.dvs, mon.statExp) end,
    function() return Stats.calc(data, species, level, mon.dvs, mon.statExp) end,
  }
  for _, calc in ipairs(attempts) do
    local good, stats = pcall(calc)
    if good and type(stats) == "table" and tonumber(stats.hp) then
      mon.stats, mon.hp = stats, stats.hp
      return
    end
  end
end

function W.makeMon(data, species, level, generation)
  level = math.max(2, math.min(100, math.floor(tonumber(level) or 5)))
  local def = data and data.pokemon and data.pokemon[species]
  if type(def) ~= "table" then return nil, "species definition missing" end
  if generation == 2 then
    local ok, Mon = pcall(require, "src.battle.gen2.Mon")
    if not ok or not Mon or type(Mon.new) ~= "function" then return nil, "Gen2 Mon unavailable" end
    local opts = { dvs={ attack=15, defense=15, speed=15, special=15 }, shiny=true }
    local attempts = {
      function() return Mon.new(data, species, level, opts) end,
      function() return Mon.new(species, level, opts) end,
      function() return Mon.new(def, level, opts) end,
    }
    for _, make in ipairs(attempts) do
      local made, mon = pcall(make)
      if made and validate(mon, species) then
        mon.dvs, mon.shiny = mon.dvs or opts.dvs, true
        return mon
      end
    end
    return nil, "no compatible Gen2 constructor"
  end
  local ok, Pokemon = pcall(require, "src.pokemon.Pokemon")
  if not ok or not Pokemon or type(Pokemon.new) ~= "function" then
    return nil, "Pokemon constructor unavailable"
  end
  local attempts = {
    function() return Pokemon.new(def, level) end,
    function() return Pokemon.new(species, level) end,
    function() return Pokemon.new(data, species, level) end,
  }
  for _, make in ipairs(attempts) do
    local made, mon = pcall(make)
    if made and validate(mon, species) then
      perfectGen1(mon, data, species, level)
      return mon
    end
  end
  return nil, "no compatible Pokemon constructor"
end

local function speciesName(data, id)
  local def = data and data.pokemon and data.pokemon[id]
  return (def and def.name) or tostring(id):gsub("_", " ")
end

local function say(game, text, onDone, generation)
  if generation == 2 then
    local world = game and game.world
    if world and type(world.showText) == "function" then
      local ok = pcall(world.showText, world, text, onDone)
      if ok then return true end
    end
  end
  local ok, TextBox = pcall(require, "src.render.TextBox")
  if ok and TextBox and game and game.stack then
    local made, box = pcall(TextBox.new, game, text, onDone)
    if made and box then game.stack:push(box); return true end
  end
  if onDone then pcall(onDone) end
  return false
end

local function markDex(save, species)
  local dex = save and save.pokedex
  if type(dex) ~= "table" then return end
  for _, key in ipairs({ "seen", "owned", "caught" }) do
    if type(dex[key]) ~= "table" then dex[key] = {} end
    dex[key][species] = true
  end
end

function W.animationSafe(data, sent, received)
  local a, b = monSpecies(sent), monSpecies(received)
  local da = a and data and data.pokemon and data.pokemon[a]
  local db = b and data and data.pokemon and data.pokemon[b]
  -- Registered Weather FX/Kanto species use string identity and intentionally
  -- omit the ROM index. TradeAnim indexes ROM sheets, so bypass it for either.
  return type(da) == "table" and type(db) == "table"
    and type(da.index) == "number" and type(db.index) == "number"
end

local function emit(name, payload)
  pcall(function() require("src.mods.Runtime").emit(name, payload) end)
end

local function evolve(game, mon, generation, done)
  local finished = false
  local function finish()
    if finished then return end
    finished = true
    if done then pcall(done) end
  end
  local ok = pcall(function()
    if generation == 2 then
      local Evolution = require("src.core.gen2.Evolution")
      local entry = Evolution.checkMon(game.data, mon, { link=true })
      if not entry then finish(); return end
      require("src.ui.Screens").push(game, "Gen2EvolutionAnim", {
        mon=mon, entry=entry, save=game.save, onDone=finish })
    else
      local Evolution = require("src.pokemon.Evolution")
      local target = select(1, Evolution.pendingFor(game, mon, { kind="trade" }))
      if not target then finish(); return end
      Evolution.evolve(game, mon, target, finish, "TRADE")
    end
  end)
  if not ok then finish() end
end

local function showResult(mod, game, sent, received, generation)
  local sentName = sent.nickname or speciesName(game.data, monSpecies(sent))
  local recvName = received.nickname or speciesName(game.data, monSpecies(received))
  say(game, sentName .. " was\nswapped for\v" .. recvName .. "!", function()
    evolve(game, received, generation, function()
      say(game, "Come back anytime\nfor another trade!", nil, generation)
      pcall(function() mod.save:set("wonderTrades",
        (mod.save:get("wonderTrades", 0) or 0) + 1) end)
    end)
  end, generation)
end

local function animateOrFinish(mod, game, sent, received, generation)
  if not W.animationSafe(game.data, sent, received) then
    showResult(mod, game, sent, received, generation)
    return
  end
  local ok, Screens = pcall(require, "src.ui.Screens")
  if not ok or not Screens or type(Screens.push) ~= "function" then
    showResult(mod, game, sent, received, generation); return
  end
  local screen = generation == 2 and "Gen2TradeAnim" or "TradeAnim"
  local pushed = pcall(Screens.push, game, screen, {
    sent=sent, received=received, given=sent, enemyName=received.ot,
    playerOt=game.save.player and game.save.player.name,
    playerOtId=sent.otId or (game.save.player and game.save.player.id),
    enemyOtId=received.otId, row={ otName=received.ot, otId=received.otId },
    save=game.save, onDone=function()
      pcall(function()
        local top = game.stack and game.stack:top()
        if top and tostring(top.screenId or ""):find("TradeAnim") then game.stack:pop() end
      end)
      showResult(mod, game, sent, received, generation)
    end,
  })
  if not pushed then showResult(mod, game, sent, received, generation) end
end

function W.beginTrade(mod_, manager, game)
  mod_ = mod_ or mod
  game = game or (manager and manager.game) or mod_.game
  local generation = gen(manager)
  local party = game and game.save and game.save.party
  if type(party) ~= "table" or #party < 1 then
    if game then say(game, "You need a POKéMON\nto WONDER TRADE!", nil, generation) end
    return false
  end
  local ok, PartyMenu = pcall(require, "src.ui.PartyMenu")
  if not ok or not PartyMenu or type(PartyMenu.new) ~= "function" then return false end
  local resolved = false
  local function afterPick(picked)
    if resolved then return end
    resolved = true
    if not picked then say(game, "Maybe next time!", nil, generation); return end
    local slot
    for i, mon in ipairs(party) do if mon == picked then slot = i break end end
    if not slot then say(game, "That POKéMON moved.\nPlease try again!", nil, generation); return end
    local pool = W.buildPool(game.data, manager) -- rebuild: Weather FX may load later
    if #pool == 0 then say(game, "The network is\ndown right now...", nil, generation); return end
    local start = rand(1, #pool)
    local received, species, why
    for offset = 0, #pool - 1 do
      local candidate = pool[((start + offset - 1) % #pool) + 1]
      if candidate ~= monSpecies(picked) or #pool == 1 then
        received, why = W.makeMon(game.data, candidate, picked.level, generation)
        if received then species = candidate; break end
      end
    end
    if not received then
      say(game, "No compatible trade\nwas found. Try again!", nil, generation)
      return false, why
    end
    received.traded, received.shiny = true, true
    received.ot = OT_NAMES[rand(1, #OT_NAMES)]
    received.otName, received.otId = received.ot, rand(0, 65535)
    local sent = party[slot]
    -- Atomic commit: construction and validation completed before the party
    -- changes. Post-commit events and UI are all guarded/fallback-capable.
    party[slot] = received
    markDex(game.save, species)
    emit("pokemon.received", { mon=received, from="wonder_trade", peerName=received.ot })
    emit("trade.completed", { sent=sent, received=received })
    animateOrFinish(mod_, game, sent, received, generation)
    return true
  end
  local made, menu = pcall(PartyMenu.new, game, {
    pickOnly=true, onCancel=function() afterPick(nil) end,
    onSwitch=function(mon) afterPick(mon) end,
  })
  if not made or not menu then return false end
  game.stack:push(menu)
  return true
end


-- 7.0.0: shared AI-side Wonder Trader. This is deliberately simulation-only:
-- rivals/Rangers/Rocket do not push UI, but they use the exact same merged
-- species pool as the player-facing attendant, including registered WX_* forms.
-- holder.party uses portable {species,level,...} slots. Rocket members may use
-- their native `pokemon`/`level` pair instead via opts.rocketMember.
function W.simulateAgent(manager, holder, rng, opts)
  opts = opts or {}
  if not (manager and holder and manager.data) then return nil end
  local function roll(lo,hi)
    if rng and type(rng.int)=="function" then return rng:int(lo,hi) end
    return rand(lo,hi)
  end
  local pool = W.buildPool(manager.data, manager)
  if #pool < 2 then return nil end
  local slot, slotIndex, oldSpecies, level
  if opts.rocketMember then
    oldSpecies = holder.pokemon
    level = tonumber(holder.level) or 5
    if not oldSpecies then return nil end
  else
    local party = holder.party
    if type(party) ~= "table" or #party == 0 then return nil end
    local candidates = {}
    for i,v in ipairs(party) do
      if type(v)=="table" and monSpecies(v) and not v.stolenAssetId and not v.ace then
        candidates[#candidates+1]=i
      end
    end
    if #candidates==0 then return nil end
    slotIndex=candidates[roll(1,#candidates)]; slot=party[slotIndex]
    oldSpecies=monSpecies(slot); level=tonumber(slot.level) or 5
  end
  local start=roll(1,#pool); local species
  for off=0,#pool-1 do
    local candidate=pool[((start+off-1)%#pool)+1]
    if candidate~=oldSpecies then species=candidate break end
  end
  if not species then return nil end
  local received={species=species,level=math.max(2,math.min(100,math.floor(level))),
    shiny=true,traded=true,origin="wonder_trade",ot="WONDER",
    dvs={attack=15,defense=15,speed=15,special=15,hp=15}}
  if opts.rocketMember then
    holder.pokemon=species; holder.level=received.level
  else
    holder.party[slotIndex]=received
  end
  holder.wonderTradeCooldown=opts.cooldown or 120
  holder.wonderTrades=(tonumber(holder.wonderTrades) or 0)+1
  emit("trade.completed", {sent={species=oldSpecies,level=level},received=received,
    ai=true, faction=opts.faction, traderId=holder.id})
  return {gave=oldSpecies,got=species,slot=received}
end

function W.install(mod_, manager)
  if W.installed then return W end
  W.installed = true
  local generation = gen(manager, mod_)
  if not generation then
    -- Defer the whole install rather than guess.  game.ready carries the real
    -- merged data, and W.installed is still false here so this runs once.
    W.installed = false
    mod_.events:on("game.ready", function()
      if W.installed then return end
      W.install(mod_, manager)
    end)
    return W
  end
  local centers = generation == 2 and GEN2 or GEN1
  -- Ask the live merged sprite table instead of forcing a particular visual.
  -- Sprite overhaul mods keep ownership of whatever art sits behind the
  -- selected logical id, and renamed-id overhauls can be found semantically.
  local sprite
  pcall(function()
    if manager and manager.sprites and type(manager.sprites.npcFor) == "function" then
      sprite = manager.sprites:npcFor("attendant", manager.data,
        { "SPRITE_SUPER_NERD", "SPRITE_CLERK", "SPRITE_GENTLEMAN", "SPRITE_TEACHER" })
    end
  end)
  if not sprite then
    -- Do not append an invalid object when an extreme conversion has no
    -- drawable walker yet. game.ready can reinstall once merged data exists.
    W.installed = false
    return W
  end
  for _, mapId in ipairs(centers) do
    pcall(function() mod_.content.maps:patch(mapId, { objects={ __append={ {
      index=NPC_INDEX, x=7, y=4, sprite=sprite,
      movement=generation == 2 and 6 or "STAY", range="DOWN",
      text=TEXT, name="WONDER_TRADE",
    } } } }) end)
  end
  pcall(function() mod_.content.commands:register("ai_rivals:wonder_trade", {
    foreground=true, fn=function(ctx) return W.beginTrade(mod_, manager, ctx.game) end,
  }) end)
  if generation == 1 then
    for _, mapId in ipairs(centers) do
      pcall(function() mod_.content.map_scripts:register(mapId, { priority=-4, talk={
        [TEXT]={ {"face_player"}, {"ask", "WONDER TRADE?\nSwap one POKéMON\vfor a surprise!"},
          {"jump_if_false", "no"}, {"ai_rivals:wonder_trade"}, {"jump", "end"},
          {"label", "no"}, {"show_text", "Come back if you\nchange your mind!"} },
      } }) end)
    end
  else
    -- Gold has no map_scripts.talk route to a mod object, so the attendant is
    -- served by the same OverworldController.talkTo seam the rivals use.
    -- This used to replace OW.talkTo directly; two independent replacements of
    -- one engine field made correctness depend on install order, so both now
    -- register with the single router in src/Gen2Talk.lua.
    local Gen2Talk = req("src/Gen2Talk")
    Gen2Talk.register("ai_rivals:wonder_trade", function(world, npc)
      local def = npc and npc.def
      if not (def and (def.name == "WONDER_TRADE" or def.text == TEXT)) then
        return false
      end
      W.beginTrade(mod_, manager, (world and world.game) or mod_.game)
      return true
    end, 30)
    mod_.events:on("game.ready", function() Gen2Talk.install() end)
  end
  return W
end

return W
