local T={}

T.CLASSES={
TRAINER={label="TRAINER",positive={},negative={}},
ACE_TRAINER={label="ACE TRAINER",positive={"BATTLE_XP_25","MONEY_20","DODGE_05"},negative={"DAMAGE_TAKEN_10","CATCH_MINUS_10"},expMultiplier=1.25,moneyMultiplier=1.20,dodgeChance=0.05,incomingDamageMultiplier=1.10,catchMultiplier=0.90},
COLLECTOR={label="COLLECTOR",positive={"CATCH_25","RARE_70","HIGH_DV_20"},negative={"BATTLE_XP_MINUS_10","SHOP_15"},catchMultiplier=1.25,rareEncounterMultiplier=1.70,highDvChance=0.20,expMultiplier=0.90,shopPriceMultiplier=1.15},
BREEDER={label="BREEDER",positive={"LOW_LEVEL_XP_35","HIGH_DV_25","FRIENDSHIP_50"},negative={"MONEY_MINUS_15"},lowLevelExpMultiplier=1.35,highDvChance=0.25,friendshipMultiplier=1.50,moneyMultiplier=0.85},
PRODIGY={label="PRODIGY",positive={"BATTLE_XP_50","HIGH_DV_35","MONEY_15"},negative={"DAMAGE_TAKEN_10","CATCH_MINUS_05"},expMultiplier=1.50,highDvChance=0.35,moneyMultiplier=1.15,incomingDamageMultiplier=1.10,catchMultiplier=0.95},
LUCKY_TRAINER={label="LUCKY TRAINER",positive={"MAX_DV_70","RARE_50","CATCH_10"},negative={"MONEY_MINUS_20","SHOP_10"},perfectDvChance=0.70,rareEncounterMultiplier=1.50,catchMultiplier=1.10,moneyMultiplier=0.80,shopPriceMultiplier=1.10},
SURVIVALIST={label="SURVIVALIST",positive={"DODGE_10","CATCH_10","STATUS_RESIST_25"},negative={"BATTLE_XP_MINUS_10"},dodgeChance=0.10,catchMultiplier=1.10,statusResist=0.25,expMultiplier=0.90},
RANGER={label="RANGER",positive={"CATCH_25","DODGE_05","RARE_25"},negative={"ROCKET_HOSTILE","MONEY_MINUS_10"},catchMultiplier=1.25,dodgeChance=0.05,rareEncounterMultiplier=1.25,moneyMultiplier=0.90,rangerAffinity=1.80,rocketAffinity=0.20},
ROCKET={label="ROCKET",positive={"MONEY_50","CATCH_15","ROCKET_REWARD_X2"},negative={"RANGER_HOSTILE","BATTLE_XP_MINUS_10"},moneyMultiplier=1.50,catchMultiplier=1.15,expMultiplier=0.90,rocketAffinity=2.00,rangerAffinity=0.20},
SCIENTIST={label="SCIENTIST",positive={"RARE_70","HIGH_DV_30","CATCH_UNSEEN_20"},negative={"BATTLE_XP_MINUS_15","DAMAGE_TAKEN_05"},rareEncounterMultiplier=1.70,highDvChance=0.30,unseenCatchMultiplier=1.20,expMultiplier=0.85,incomingDamageMultiplier=1.05},
GAMBLER={label="GAMBLER",positive={"MONEY_VARIABLE","RARE_40","PERFECT_DV_10"},negative={"BAD_DV_15","DAMAGE_TAKEN_05"},rareEncounterMultiplier=1.40,perfectDvChance=0.10,worseDvChance=0.15,incomingDamageMultiplier=1.05,gambleMoney=true},
UNDERDOG={label="UNDERDOG",positive={"HIGHER_LEVEL_XP_X2","CATCH_HIGHER_25"},negative={"LOWER_LEVEL_XP_MINUS_20"},higherLevelExpMultiplier=2.0,lowerLevelExpMultiplier=0.80,higherLevelCatchMultiplier=1.25},
GLASS_CANNON={label="GLASS CANNON",positive={"DAMAGE_DEALT_20","BATTLE_XP_25"},negative={"DAMAGE_TAKEN_20"},outgoingDamageMultiplier=1.20,incomingDamageMultiplier=1.20,expMultiplier=1.25},
TREASURE_HUNTER={label="TREASURE HUNTER",positive={"MONEY_50","RARE_25","ITEM_FIND_25"},negative={"CATCH_MINUS_15","BATTLE_XP_MINUS_10"},moneyMultiplier=1.50,rareEncounterMultiplier=1.25,itemFindMultiplier=1.25,catchMultiplier=0.85,expMultiplier=0.90},
WEATHER_CHASER={label="WEATHER CHASER",positive={"WX_RARE_70","WEATHER_CATCH_25","WEATHER_XP_25"},negative={"WEATHER_DAMAGE_10"},rareEncounterMultiplier=1.35,weatherVariantMultiplier=1.70,weatherCatchMultiplier=1.25,weatherExpMultiplier=1.25,weatherDamageMultiplier=1.10},
CHAMPION_ASPIRANT={label="CHAMPION ASPIRANT",positive={"TRAINER_XP_25","TRAINER_MONEY_25","DODGE_05"},negative={"GYM_DIFFICULTY_10"},expMultiplier=1.25,moneyMultiplier=1.25,dodgeChance=0.05,gymDifficultyMultiplier=1.10},
BUG_CATCHER={label="BUG CATCHER",positive={"BUG_CATCH_35","BUG_XP_35","BUG_RARE_50"},negative={"BUG_WEAKNESS_10"},typeCatch={BUG=1.35},typeExp={BUG=1.35},typeRare={BUG=1.50},typeIncoming={BUG=1.10}},
FISHER={label="FISHER",positive={"WATER_CATCH_40","WATER_XP_25","WATER_RARE_50"},negative={"LAND_XP_MINUS_10"},typeCatch={WATER=1.40},typeExp={WATER=1.25},typeRare={WATER=1.50},landExpMultiplier=0.90},
}
T.ORDER={"TRAINER","ACE_TRAINER","COLLECTOR","BREEDER","PRODIGY","LUCKY_TRAINER","SURVIVALIST","RANGER","ROCKET","SCIENTIST","GAMBLER","UNDERDOG","GLASS_CANNON","TREASURE_HUNTER","WEATHER_CHASER","CHAMPION_ASPIRANT","BUG_CATCHER","FISHER"}

local function hash(seed,text)
 local h=(tonumber(seed) or 1)%2147483647; text=tostring(text or "")
 for i=1,#text do h=(h*1103515245+text:byte(i)+12345)%2147483647 end
 return h
end
function T.get(id) return T.CLASSES[id] or T.CLASSES.TRAINER end
function T.label(id) return T.get(id).label end
function T.valid(id) return type(id)=="string" and T.CLASSES[id]~=nil end
function T.choices()
 local a,b={},{}
 for _,id in ipairs(T.ORDER) do a[#a+1]=T.label(id); b[#b+1]=id end
 return a,b
end

local POOLS={
 RIVAL={"TRAINER","ACE_TRAINER","COLLECTOR","BREEDER","PRODIGY","LUCKY_TRAINER","SURVIVALIST","SCIENTIST","GAMBLER","UNDERDOG","GLASS_CANNON","TREASURE_HUNTER","WEATHER_CHASER","CHAMPION_ASPIRANT","BUG_CATCHER","FISHER"},
 RANGER={"RANGER","RANGER","SURVIVALIST","BREEDER","SCIENTIST","ACE_TRAINER","COLLECTOR"},
 ROCKET={"ROCKET","ROCKET","ACE_TRAINER","COLLECTOR","SCIENTIST","GAMBLER","GLASS_CANNON","TREASURE_HUNTER"},
}
local function bias(agent,pool)
 local p=agent and agent.personality
 local id=type(p)=="table" and (p.id or p.label) or p
 id=tostring(id or ""):upper()
 local want
 if id:find("CRUSADER",1,true) then want="CHAMPION_ASPIRANT"
 elseif id:find("COLLECT",1,true) then want="COLLECTOR"
 elseif id:find("STRATEG",1,true) or id:find("CHALLENG",1,true) then want="ACE_TRAINER"
 elseif id:find("SPEED",1,true) then want="PRODIGY"
 elseif id:find("SCIENT",1,true) or id:find("RESEARCH",1,true) then want="SCIENTIST" end
 if not want then return pool end
 local out={want,want}; for _,v in ipairs(pool) do out[#out+1]=v end; return out
end
function T.assign(agent,faction,seed)
 if type(agent)~="table" then return "TRAINER" end
 if T.valid(agent.trainerClassId) then agent.trainerClass=T.get(agent.trainerClassId); return agent.trainerClassId end
 local pool=bias(agent,POOLS[faction or "RIVAL"] or POOLS.RIVAL)
 local id=pool[1+(hash(seed,tostring(agent.id or agent.name or "agent")..":class")%#pool)]
 agent.trainerClassId=id; agent.trainerClass=T.get(id); return id
end

local function defFor(data,species)
 local d=data and (data.pokemon or data.gen2Pokemon); return d and species and d[species]
end
local function types(data,species)
 local d=defFor(data,species) or {}; return {d.type1 or d.type,d.type2}
end
local function typed(map,list)
 local m=1
 if type(map)~="table" then return m end
 for _,t in ipairs(list or {}) do if t and map[t] then m=math.max(m,tonumber(map[t]) or 1) end end
 return m
end
function T.catchMultiplier(subject,data,species,ctx)
 local c=T.get(type(subject)=="table" and subject.trainerClassId or subject)
 local m=(tonumber(c.catchMultiplier) or 1)*typed(c.typeCatch,types(data,species))
 if ctx and ctx.weather and ctx.weather~="CLEAR" then m=m*(tonumber(c.weatherCatchMultiplier) or 1) end
 if ctx and ctx.higherLevel then m=m*(tonumber(c.higherLevelCatchMultiplier) or 1) end
 if ctx and ctx.unseen then m=m*(tonumber(c.unseenCatchMultiplier) or 1) end
 return m
end
function T.expMultiplier(subject,data,species,ctx)
 local c=T.get(type(subject)=="table" and subject.trainerClassId or subject)
 local m=(tonumber(c.expMultiplier) or 1)*typed(c.typeExp,types(data,species))
 if ctx and ctx.higherLevel then m=m*(tonumber(c.higherLevelExpMultiplier) or 1) end
 if ctx and ctx.lowerLevel then m=m*(tonumber(c.lowerLevelExpMultiplier) or 1) end
 if ctx and ctx.lowLevel then m=m*(tonumber(c.lowLevelExpMultiplier) or 1) end
 if ctx and ctx.weather and ctx.weather~="CLEAR" then m=m*(tonumber(c.weatherExpMultiplier) or 1) end
 if ctx and ctx.land and c.landExpMultiplier then m=m*c.landExpMultiplier end
 return m
end
function T.moneyMultiplier(subject,rng)
 local c=T.get(type(subject)=="table" and subject.trainerClassId or subject)
 if c.gambleMoney then
  local r
  if rng and rng.int then r=rng:int(50,400)
  elseif love and love.math and love.math.random then r=love.math.random(50,400)
  else r=math.random(50,400) end
  return r/100
 end
 return tonumber(c.moneyMultiplier) or 1
end
local function chance(rng,p)
 if not p or p<=0 then return false end
 if rng and rng.chance then return rng:chance(p) end
 local r=(love and love.math and love.math.random and love.math.random()) or math.random()
 return r<p
end
function T.modifyDVs(subject,mon,rng)
 if type(mon)~="table" then return false end
 local c=T.get(type(subject)=="table" and subject.trainerClassId or subject)
 local d=type(mon.dvs)=="table" and mon.dvs or {}
 local changed=false
 if chance(rng,c.perfectDvChance) then
  d.attack,d.defense,d.speed,d.special=15,15,15,15
  if d.specialAttack~=nil then d.specialAttack=15 end
  if d.specialDefense~=nil then d.specialDefense=15 end
  changed=true
 elseif chance(rng,c.highDvChance) then
  for _,k in ipairs({"attack","defense","speed","special","specialAttack","specialDefense"}) do
   if d[k]~=nil or k=="attack" or k=="defense" or k=="speed" or k=="special" then d[k]=math.max(tonumber(d[k]) or 0,12) end
  end
  changed=true
 elseif chance(rng,c.worseDvChance) then
  for _,k in ipairs({"attack","defense","speed","special","specialAttack","specialDefense"}) do
   if d[k]~=nil or k=="attack" or k=="defense" or k=="speed" or k=="special" then d[k]=math.min(tonumber(d[k]) or 7,5) end
  end
  changed=true
 end
 if changed then mon.dvs=d end
 return changed
end

local function encounterSlots(data,mapId)
 local e=data and data.encounters and data.encounters[mapId]
 if type(e)=="table" then return e.slots or e.grass or e end
 local g=data and data.gen2Encounters
 for _,bucket in ipairs(g and {g.grass,g.swarmGrass,g.water} or {}) do
  local row=bucket and bucket[mapId]; if type(row)=="table" then return row.slots or row end
 end
end
function T.modifyEncounter(id,data,enc,ctx,rng)
 local rare=tonumber(T.get(id).rareEncounterMultiplier) or 1
 if rare<=1 or not (enc and enc.species and ctx and ctx.mapId) then return enc end
 local slots=encounterSlots(data,ctx.mapId); if type(slots)~="table" then return enc end
 local dex=data and (data.pokemon or data.gen2Pokemon) or {}; local pool={}
 for key,row in pairs(slots) do
  local sp=type(row)=="table" and (row.species or row.mon or row.id) or (type(row)=="string" and row or (type(key)=="string" and key or nil))
  if sp and dex[sp] then pool[#pool+1]={species=sp,rate=tonumber(dex[sp].catchRate or dex[sp].catch_rate) or 255} end
 end
 if #pool<2 then return enc end
 table.sort(pool,function(a,b) if a.rate~=b.rate then return a.rate<b.rate end return tostring(a.species)<tostring(b.species) end)
 if not chance(rng,math.min(0.45,(rare-1)*0.25)) then return enc end
 local top=math.max(1,math.ceil(#pool*0.25)); local i
 if rng and rng.int then i=rng:int(1,top)
 elseif love and love.math and love.math.random then i=love.math.random(1,top)
 else i=math.random(1,top) end
 return {species=pool[i].species,level=enc.level,classRare=true}
end
T.TRAIT_TEXT={
 BATTLE_XP_25="+25% BATTLE EXP",
 MONEY_20="+20% PRIZE MONEY",
 DODGE_05="5% CHANCE TO DODGE",
 DAMAGE_TAKEN_10="+10% DAMAGE TAKEN",
 CATCH_MINUS_10="-10% CATCH RATE",
 CATCH_25="+25% CATCH RATE",
 RARE_70="+70% RARE ENCOUNTERS",
 HIGH_DV_20="20% BETTER DV CHANCE",
 BATTLE_XP_MINUS_10="-10% BATTLE EXP",
 SHOP_15="+15% SHOP PRICES",
 LOW_LEVEL_XP_35="+35% EXP FOR WEAKER TEAM MEMBERS",
 HIGH_DV_25="25% BETTER DV CHANCE",
 FRIENDSHIP_50="+50% FRIENDSHIP GROWTH",
 MONEY_MINUS_15="-15% PRIZE MONEY",
 BATTLE_XP_50="+50% BATTLE EXP",
 HIGH_DV_35="35% BETTER DV CHANCE",
 MONEY_15="+15% PRIZE MONEY",
 CATCH_MINUS_05="-5% CATCH RATE",
 MAX_DV_70="70% CHANCE FOR MAX DVS",
 RARE_50="+50% RARE ENCOUNTERS",
 CATCH_10="+10% CATCH RATE",
 MONEY_MINUS_20="-20% PRIZE MONEY",
 SHOP_10="+10% SHOP PRICES",
 DODGE_10="10% CHANCE TO DODGE",
 STATUS_RESIST_25="25% STATUS RESISTANCE",
 RARE_25="+25% RARE ENCOUNTERS",
 ROCKET_HOSTILE="TEAM ROCKET IS MORE HOSTILE",
 MONEY_MINUS_10="-10% PRIZE MONEY",
 MONEY_50="+50% PRIZE MONEY",
 CATCH_15="+15% CATCH RATE",
 ROCKET_REWARD_X2="2X ROCKET JOB REWARDS",
 RANGER_HOSTILE="RANGERS ARE MORE HOSTILE",
 HIGH_DV_30="30% BETTER DV CHANCE",
 CATCH_UNSEEN_20="+20% CATCH RATE ON UNSEEN POKEMON",
 BATTLE_XP_MINUS_15="-15% BATTLE EXP",
 DAMAGE_TAKEN_05="+5% DAMAGE TAKEN",
 MONEY_VARIABLE="PRIZE MONEY CAN ROLL 0.5X-4X",
 RARE_40="+40% RARE ENCOUNTERS",
 PERFECT_DV_10="10% CHANCE FOR MAX DVS",
 BAD_DV_15="15% CHANCE OF WORSE DVS",
 HIGHER_LEVEL_XP_X2="2X EXP VS HIGHER LEVELS",
 CATCH_HIGHER_25="+25% CATCH VS HIGHER LEVELS",
 LOWER_LEVEL_XP_MINUS_20="-20% EXP VS WEAKER POKEMON",
 DAMAGE_DEALT_20="+20% DAMAGE DEALT",
 DAMAGE_TAKEN_20="+20% DAMAGE TAKEN",
 ITEM_FIND_25="+25% ITEM FIND CHANCE",
 CATCH_MINUS_15="-15% CATCH RATE",
 WX_RARE_70="+70% WX/WEATHER VARIANT CHANCE",
 WEATHER_CATCH_25="+25% CATCH RATE IN WEATHER",
 WEATHER_XP_25="+25% EXP IN WEATHER",
 WEATHER_DAMAGE_10="+10% WEATHER DAMAGE TAKEN",
 TRAINER_XP_25="+25% TRAINER BATTLE EXP",
 TRAINER_MONEY_25="+25% TRAINER PRIZE MONEY",
 GYM_DIFFICULTY_10="GYM OPPONENTS ARE 10% TOUGHER",
 BUG_CATCH_35="+35% BUG CATCH RATE",
 BUG_XP_35="+35% EXP FOR BUG POKEMON",
 BUG_RARE_50="+50% RARE BUG ENCOUNTERS",
 BUG_WEAKNESS_10="+10% DAMAGE TO BUG WEAKNESSES",
 WATER_CATCH_40="+40% WATER CATCH RATE",
 WATER_XP_25="+25% EXP FOR WATER POKEMON",
 WATER_RARE_50="+50% RARE WATER ENCOUNTERS",
 LAND_XP_MINUS_10="-10% EXP FROM LAND ENCOUNTERS",
}

function T.traitText(id)
  return T.TRAIT_TEXT[id] or tostring(id or ""):gsub("_"," ")
end

function T.confirmationText(id)
  local c=T.get(id)
  local pages={}
  local first={c.label}
  if id=="TRAINER" then
    first[#first+1]="NO POSITIVE TRAITS"
    first[#first+1]="NO NEGATIVE TRAITS"
    first[#first+1]="THE CLASSIC POKEMON JOURNEY."
    pages[#pages+1]=table.concat(first,"\n")
  else
    first[#first+1]="POSITIVES:"
    for _,trait in ipairs(c.positive or {}) do
      first[#first+1]=T.traitText(trait)
    end
    pages[#pages+1]=table.concat(first,"\n")

    local second={"NEGATIVES:"}
    for _,trait in ipairs(c.negative or {}) do
      second[#second+1]=T.traitText(trait)
    end
    if #(c.negative or {})==0 then second[#second+1]="NONE" end
    pages[#pages+1]=table.concat(second,"\n")
  end
  pages[#pages+1]="IS THIS YOUR CLASS?"
  return table.concat(pages,"\f")
end

function T.summary(id)
 local c=T.get(id); local out={c.label}
 for _,v in ipairs(c.positive or {}) do out[#out+1]="+"..v:gsub("_"," ") end
 for _,v in ipairs(c.negative or {}) do out[#out+1]="-"..v:gsub("_"," ") end
 return out
end
return T
