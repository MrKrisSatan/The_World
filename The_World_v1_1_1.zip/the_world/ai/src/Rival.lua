local req, mod = ...
local Util = req("src/Util")
local Happiness = req("src/Happiness")
local TrainerClasses = req("src/TrainerClasses")
local BattleSim = req("src/BattleSim")
local Memory = req("src/Memory")
local Relationships = req("src/Relationships")
local TeamPlan = req("src/TeamPlan")
local Story = req("src/Story")
local Weather = req("src/Weather")
local Economy = req("src/Economy")
local League = req("src/League")
local LifePath = req("src/LifePath")
local Career = req("src/Career")
local Names = req("data/names")
local Backgrounds = req("src/Backgrounds")

-- ONE AI TRAINER.
--
-- A rival is data.  Everything about it that must survive a save -- where it
-- is, what it wants, what is in its party, which badges it has won, how many
-- times it has beaten the player -- lives in fields on this table and goes
-- through src/Save.lua unchanged.  Nothing here reaches the engine: the
-- manager hands in `ctx` (data, graph, personality tables) and this module
-- reads it.  That is what lets the whole state machine run in a headless
-- test with no LOVE, no world and no save.
--
-- PARTY REPRESENTATION
--
-- A rival's party is a list of engine PARTY SLOTS:
--
--   { species = "CHARMELEON", level = 28, exp = 21952, moves = { ... },
--     hp = 63 }
--
-- That is exactly the shape `data.trainers[x].parties[n]` uses, which is not
-- a coincidence -- it is the whole design.  The `trainer.party` hook hands
-- this list straight to the engine when the player fights a rival, and the
-- engine builds the real Pokemon objects from it with its own Pokemon.new,
-- its own DVs and its own stat calc.  There is no parallel Pokemon type in
-- this mod and no second copy of the species table.

local Rival = {}
Rival.__index = Rival

Rival.STATES = {
  "IDLE", "TRAVELLING", "TRAINING", "SEEKING_GYM", "CHALLENGING_GYM",
  "RETURNING_FROM_GYM", "SEEKING_PLAYER", "CHALLENGING_PLAYER", "HEALING",
  "EXPLORING", "DEFEATED", "LEAGUE_READY",
  "SEEKING_GHOST", "CHALLENGING_GHOST",
  "SEEKING_RIVAL", "CHALLENGING_RIVAL",
}

local STATE_SET = {}
for _, s in ipairs(Rival.STATES) do STATE_SET[s] = true end

function Rival.isState(name) return STATE_SET[name] == true end

-- The rival economy.  Rivals start with the same pocket money the player
-- does, earn more by winning battles against each other and against the
-- world's trainers, and spend it on the only thing they buy: Poké Balls.
Rival.STARTING_MONEY = 3000
Rival.POKEBALL_PRICE = 200

-- Every rival owns a real bag rather than a special-purpose ball counter.
-- Prices deliberately match the ordinary Gen 1 mart where possible.  The
-- bag is saved, spent at towns, used before battles, and can be looted by the
-- player after a win.
Rival.SHOP = {
  POKE_BALL = { price = 200, target = 5, kind = "ball" },
  GREAT_BALL = { price = 600, target = 2, kind = "ball" },
  ULTRA_BALL = { price = 1200, target = 1, kind = "ball" },
  POTION = { price = 300, target = 3, heal = 20 },
  SUPER_POTION = { price = 700, target = 2, heal = 50 },
  HYPER_POTION = { price = 1200, target = 1, heal = 200 },
  ANTIDOTE = { price = 100, target = 2, cure = "POISON" },
  PARLYZ_HEAL = { price = 200, target = 1, cure = "PARALYSIS" },
  AWAKENING = { price = 200, target = 1, cure = "SLEEP" },
  BURN_HEAL = { price = 250, target = 1, cure = "BURN" },
  ICE_HEAL = { price = 250, target = 1, cure = "FREEZE" },
  REPEL = { price = 350, target = 2, field = true },
  RARE_CANDY = { price = 4800, target = 1, candy = true },
}
Rival.SHOP_ORDER = { "POKE_BALL", "POTION", "ANTIDOTE", "REPEL",
  "SUPER_POTION", "PARLYZ_HEAL", "AWAKENING", "BURN_HEAL", "ICE_HEAL",
  "HYPER_POTION", "RARE_CANDY" }

-- A few useful TMs a rival can buy or find.  Keyed by move id; only moves the
-- loaded game actually has are ever offered, and a species can only be taught
-- one when the game's own TM compatibility allows it.
Rival.TM_PRICES = {
  THUNDERBOLT = 1200, ICE_BEAM = 1300, EARTHQUAKE = 1500, PSYCHIC = 1400,
  SURF = 1000, DIG = 700, FLAMETHROWER = 1200, SLUDGE_BOMB = 1000,
}

-- HMs are private rival progression, never aliases for the player's bag or
-- badges. Winning the enabling badge gives that rival access to the matching
-- HM; it still has to own a compatible Pokémon and keep the move taught.
local HM_ITEM = {
  CUT = "HM01", FLY = "HM02", SURF = "HM03", STRENGTH = "HM04",
  FLASH = "HM05", WHIRLPOOL = "HM06", WATERFALL = "HM07",
}
local HM_BY_BADGE = {
  BOULDERBADGE = "FLASH", CASCADEBADGE = "CUT", THUNDERBADGE = "FLY",
  RAINBOWBADGE = "STRENGTH", SOULBADGE = "SURF",
  ZEPHYR = "FLASH", HIVE = "CUT", PLAIN = "STRENGTH", FOG = "SURF",
  STORM = "FLY", GLACIER = "WHIRLPOOL", RISING = "WATERFALL",
}

-- ------------------------------------------------------------------
-- Experience curves
-- ------------------------------------------------------------------
-- Gen 1's four curves.  Implemented here rather than read off the engine
-- because `growth_rates` is a registry of records, not of functions, and the
-- exp-to-level direction is what a rival needs -- the engine only ever goes
-- the other way when awarding.  A species whose record names no curve is
-- MEDIUM_FAST, which is what the ROM's default is.

local CURVES = {
  MEDIUM_FAST = function(n) return n * n * n end,
  FAST = function(n) return math.floor(4 * n * n * n / 5) end,
  SLOW = function(n) return math.floor(5 * n * n * n / 4) end,
  MEDIUM_SLOW = function(n)
    return math.max(0, math.floor(6 * n * n * n / 5 - 15 * n * n
                                  + 100 * n - 140))
  end,
}

local function curveFor(def)
  local name = def and (def.growthRate or def.growth_rate)
  return CURVES[name] or CURVES.MEDIUM_FAST
end

-- ------------------------------------------------------------------
-- Starters (2.6.0: dealt from a pool, not fixed per rival)
-- ------------------------------------------------------------------
--
-- A rival's starter is now dealt at random from data/rivals.lua's pool for the
-- loaded game -- Charmander, Bulbasaur, Squirtle, Eevee, Pikachu or Clefairy
-- on Gen 1, plus Cyndaquil, Totodile and Chikorita on Gold.
--
-- RANDOM BETWEEN SAVES, FIXED WITHIN ONE.
--
-- The deal is a PURE FUNCTION of (world seed, rival slot). The seed is created
-- once at new game and persisted, so two playthroughs differ and reloading
-- never changes who has what. That distinction matters more here than
-- anywhere else in the mod: a rival's ace, its team identity, its type credit
-- and half its story are all downstream of the Pokemon it opened with, so a
-- starter that rerolled on load would quietly invalidate five other systems.
--
-- Dealt WITHOUT REPLACEMENT: the pool is rotated by the seed and each rival
-- takes the entry at its own slot, so with six species and four rivals nobody
-- opens with four Pikachu. When a boot carries fewer species than the roster
-- the deal degrades to sharing rather than to nothing.

Rival.STARTER_SEED_DEFAULT = 0

local function hashSeed(seed, text)
  local h = 2166136261
  local s = tostring(seed) .. "|" .. tostring(text)
  for i = 1, #s do
    h = (h + s:byte(i) * 16777619) % 4294967296
    h = (h * 31 + 7) % 4294967296
  end
  return h
end

-- The pool for this game, filtered to what the boot actually carries.
-- Deterministic order; `pokemon` and `allows` are the same filters
-- firstAvailableStarter has always applied.
function Rival.starterPool(roster, versionKey, pokemon, allows, opts)
  opts = opts or {}
  local pools = roster and roster.pools
  local pool = pools and (pools[versionKey or "default"] or pools.default)
  local out, seen = {}, {}
  local function add(species)
    if species and not seen[species]
       and (not pokemon or pokemon[species])
       and (not allows or allows(species)) then
      seen[species] = true
      out[#out + 1] = species
    end
  end
  for _, species in ipairs(pool or {}) do add(species) end

  -- 7.2.2: universal supplemental starter bases. These are eligible in all
  -- supported games and their registered Weather FX variants may participate
  -- under the same "base species must already be a starter" rule.
  for _, species in ipairs({ "EEVEE", "CLEFAIRY", "PIKACHU" }) do
    add(species)
  end

  -- 7.2.3: Gold additionally uses Johto's three traditional starters.
  -- Because these are added before starterBase is built below, registered
  -- WX variants of each are eligible automatically when Weather FX is loaded.
  local vk = tostring(versionKey or ""):lower()
  if vk == "gold" or vk == "gen2" then
    for _, species in ipairs({ "CHIKORITA", "CYNDAQUIL", "TOTODILE" }) do
      add(species)
    end
  end

  -- 7.2.0: Weather FX expands the starter DEAL with real registered WX species.
  -- Never manufacture an id: only species present in data.pokemon are eligible.
  -- Limit the expansion so variants enrich the hand rather than drowning out
  -- the normal starter pool.
  if opts.weatherFx and type(pokemon) == "table" then
    -- 7.2.1: only weather variants of species already present in the
    -- ordinary starter pool are eligible. Weather FX enriches starters,
    -- it does not turn the starter pool into the entire WX registry.
    local starterBase = {}
    for _, baseSpecies in ipairs(out) do
      starterBase[tostring(baseSpecies):upper()] = true
    end

    local function wxBaseSpecies(species)
      local raw = tostring(species)
      if not raw:match("^WX_") then return nil end
      local body = raw:sub(4):upper()

      for base in pairs(starterBase) do
        local padded = "_" .. body .. "_"
        local token = "_" .. base .. "_"
        if padded:find(token, 1, true) then return base end
      end
      return nil
    end

    local wx = {}
    for species in pairs(pokemon) do
      if wxBaseSpecies(species) and (not allows or allows(species)) then
        wx[#wx + 1] = species
      end
    end
    table.sort(wx)
    local cap = math.max(3, math.min(18, #out * 2))
    if #wx > cap then
      local ranked = {}
      local seed = tonumber(opts.seed) or Rival.STARTER_SEED_DEFAULT
      for _, species in ipairs(wx) do
        ranked[#ranked + 1] = { species=species, key=hashSeed(seed, "wxstarter:"..species) }
      end
      table.sort(ranked, function(a,b) return a.key == b.key and a.species < b.species or a.key < b.key end)
      wx = {}
      for i=1,cap do wx[i]=ranked[i].species end
    end
    for _, species in ipairs(wx) do add(species) end
  end
  if #out == 0 then
    -- A conversion that carries none of the pool. Fall back to the roster's
    -- own last-resort list rather than to nothing, but never deal these in an
    -- ordinary game.
    for _, species in ipairs(roster and roster.fallbackStarters or {}) do
      if (not pokemon or pokemon[species]) and (not allows or allows(species)) then
        out[#out + 1] = species
      end
    end
  end
  return out
end

-- The starter preference chain for this roster row in the game that is
-- actually loaded.
--
-- A row that still declares its own `starters` wins outright, so a third-party
-- roster -- or a row that genuinely wants a fixed species -- keeps working,
-- legacy flat-list form included. Otherwise the shared pool is dealt.
function Rival.starterChain(def, versionKey, opts)
  local starters = def and def.starters
  if type(starters) == "table" then
    if type(starters[1]) == "string" then return starters end   -- legacy flat
    local chain = starters[versionKey or "default"] or starters.default
    if type(chain) == "table" and #chain > 0 then return chain end
  end

  opts = opts or {}
  local pool = opts.pool
  if not pool then
    pool = Rival.starterPool(opts.roster, versionKey, opts.pokemon, opts.allows, opts)
  end
  if #pool == 0 then return {} end

  -- SHUFFLE the pool by the seed, then take this rival's slot.
  --
  -- A plain rotation was tried first and it is far too coarse: with the pool
  -- as one fixed ring there are only as many possible hands as there are
  -- species, so 400 different saves produced six different hands and the four
  -- rivals always held four CONSECUTIVE pool entries. Sorting by a per-species
  -- hash of the seed is a real permutation, so the six-species pool yields
  -- hundreds of distinct hands instead of six.
  --
  -- Deterministic: the sort key is a pure hash and ties break on the species
  -- name, so the permutation never depends on the order pairs() happened to
  -- yield or on which host is running.
  local seed = tonumber(opts.seed) or Rival.STARTER_SEED_DEFAULT
  local slot = math.max(1, math.floor(tonumber(def and def.slot) or 1))
  local ranked = {}
  local bias = opts.personality and opts.personality.weatherStarterBias
  local function biasScore(species)
    if type(bias) ~= "table" or not tostring(species):match("^WX_") then return 0 end
    local upper = tostring(species):upper()
    for rank, token in ipairs(bias) do
      if upper:find(tostring(token):upper(), 1, true) then return (#bias - rank + 1) * 100000000 end
    end
    return 0
  end
  for _, species in ipairs(pool) do
    ranked[#ranked + 1] = {
      species = species,
      key = (hashSeed(seed, species) - biasScore(species)) % 4294967296
    }
  end
  table.sort(ranked, function(a, b)
    if a.key ~= b.key then return a.key < b.key end
    return a.species < b.species
  end)
  -- Each rival starts at its own slot in that permutation and keeps the rest
  -- as its fallback chain, so the deal is without replacement while the pool
  -- is big enough and degrades to sharing when it is not.
  local chain = {}
  for i = 0, #ranked - 1 do
    chain[#chain + 1] = ranked[((slot - 1 + i) % #ranked) + 1].species
  end
  return chain
end

-- The first species in that chain the loaded game actually has -- and, when
-- `allows` is given, that the caller's scope filter accepts.  nil is a real
-- answer (a conversion that removed every candidate, or a scope that hides
-- them all); the caller decides what to do about it rather than being handed
-- an invented species.
function Rival.firstAvailableStarter(def, versionKey, pokemon, allows, opts)
  opts = opts or {}
  opts.pokemon, opts.allows = opts.pokemon or pokemon, opts.allows or allows
  for _, species in ipairs(Rival.starterChain(def, versionKey, opts)) do
    if (not pokemon or pokemon[species])
       and (not allows or allows(species)) then
      return species
    end
  end
  return nil
end

function Rival.expForLevel(def, level)
  return curveFor(def)(math.max(1, math.floor(level)))
end

-- ------------------------------------------------------------------
-- Construction
-- ------------------------------------------------------------------

-- ctx = { data, personalities, graph, gyms }
function Rival.new(def, ctx)
  local personalityId = def.personality
  if type(def.personalities) == "table" and #def.personalities > 0 then
    local key = hashSeed(ctx.starterSeed or 1, "personality:" .. def.id)
    personalityId = def.personalities[(key % #def.personalities) + 1]
  end
  local personality = ctx.personalities[personalityId]
    or ctx.personalities.CHALLENGER
  local background = Backgrounds.forSpecial(def, ctx.starterSeed or 1)
  -- The background is hidden social DNA. It nudges an authored personality
  -- rather than replacing it, so the named personality remains the stronger
  -- signal and Shawn's special personality stays special.
  personality = Backgrounds.applyPersonality(personality, background)
  local self = setmetatable({
    id = def.id,
    name = def.fixedName and def.name
      or ((ctx.assignedNames and ctx.assignedNames[def.id])
      or Names.forDef(def, ctx.starterSeed or 1, ctx.roster or {})),
    gender = def.gender,
    def = def,
    ctx = ctx,
    personality = personality,
    personalityId = personalityId,
    backgroundId = background and background.id or nil,
    background = background,
    forcedTitle = def.forcedTitle,
    rocketAdminPotential = def.rocketAdminPotential == true,
    backgroundApplied = true,
    backgroundDispositionApplied = false,

    state = "IDLE",
    objective = nil,
    map = nil,
    x = nil, y = nil,
    destination = nil,
    route = nil,          -- list of map ids, strategic
    routeIndex = 1,
    path = nil,           -- list of grid steps, local, never saved
    pathAge = 0,
    stuckTicks = 0,

    party = {},
    badges = {},          -- badge id -> true.  NEVER the player's inventory.
    defeatedLeaders = {}, -- trainer class -> attempts won
    gymAttempts = {},     -- badge id -> attempts made
    gymCooldown = 0,

    playerWins = 0,       -- battles the RIVAL won against the player
    playerLosses = 0,
    lastPlayerBattle = nil,
    opponentKnowledge = {}, -- opponent id -> last legitimately observed party/results
    memory = Memory.new(),   -- bounded battle history and observed player habits
    -- 1.33.0: subject id ("player" or another rival's id) -> bond. The ONLY
    -- social store; dialogue, duels, trades and cooperation all read it.
    bonds = Relationships.new(),
    -- 1.34.0: the team identity. Seeded from personality.teamPlan, which had
    -- been declared in data/personalities.lua and read by nothing until now.
    teamPlan = TeamPlan.new(nil, personality and personality.teamPlan),
    -- 1.35.0: the narrator. Milestones are stored; mood and chapter are
    -- derived from the other systems every time they are asked for.
    story = Story.new(),
    -- 1.38.0: where the money went. Bounded by the fixed category list.
    ledger = Economy.newLedger(),
    -- 1.39.0: League attempts, the stage that keeps stopping them, and the
    -- qualification a title challenge requires.
    league = League.newRecord(),
    -- 2.1.0: whether this rival is still on the Gym Challenge, and what it
    -- became if not. Eligibility and pressure are DERIVED; only the decision
    -- lives here.
    lifePath = LifePath.newRecord(),
    -- 2.2.0: career metrics, one column per metric the path declares
    career = {},
    lastSeenTick = nil,
    confidence = 1.0,
    encounterCooldown = 0,
    -- Stable logical walker id. The image behind this id remains owned by the
    -- live sprite table, so replacement mods can still replace the artwork.
    appearanceSprite = nil,

    trainingTicks = 0,
    ticks = 0,
    newsPending = nil,    -- badge count to brag about next time we talk
    rng = Util.rng(def.seed or 1),

    -- Poké Ball stock. Starts at 0 in the lab; rivals buy more with the
    -- money they win (see Rival:restockBalls). tryCatch consumes one.
    balls = 0,
    inventory = Backgrounds.startingInventory(background), -- hidden background items
    pcBoxes = { {} },        -- caught Pokemon beyond the six active slots
    repelTicks = 0,

    -- Money won from battles, spent on Poké Balls.  Seeds to the same
    -- pocket money the player starts with.
    money = (background and tonumber(background.money)) or Rival.STARTING_MONEY,

    -- 1.7.0
    champion = false,           -- true after a successful simulated League run
    leagueAttempts = 0,
    leagueCooldown = 0,
    rivalFightCooldown = 0,   -- ticks before this rival will start another skirmish
    lastRivalFight = nil,       -- id of the last rival it fought
    -- 1.11.0
    rivalTarget = nil,          -- the rival this rival is currently duelling
    trainerBattleCooldown = 0,  -- ticks before this rival takes on a trainer again
    -- 1.14.0
    tms = {},                   -- move ids this rival owns a TM for
    hms = {},                   -- HM move -> enabling badge / private ownership
    hmUses = {},                -- HM move -> map transitions performed
    hmNewsPending = {},         -- runtime events drained by Simulation
    hmGoal = nil,               -- field move currently blocking progression
    defeatedTrainers = {},      -- trainer classes this rival has beaten (persists)
    visitedMaps = {},           -- private route/story exploration history
    campaignClearedMaps = {},    -- maps whose local trainer roster was cleared
    campaignTrainerWins = {},   -- exact trainer ids beaten on the badge journey
    encounterHistory = {},      -- map -> species -> encounters/catches
    -- 1.15.0
    dex = {},                   -- species this rival has held/seen
    lastDexMilestone = 0,       -- the last Pokédex milestone it announced
    huntTarget = nil,           -- the species it is currently hunting
    rematchCooldown = 0,        -- ticks before it can rematch a leader again
    wonderTradeCooldown = 0,    -- Center visits before another Wonder Trade
    aceSpecies = nil,           -- display/save hint; slot.ace is authoritative
  }, Rival)
  return self
end

-- ------------------------------------------------------------------
-- Party
-- ------------------------------------------------------------------

function Rival:speciesDef(species)
  local data = self.ctx.data
  return data and data.pokemon and data.pokemon[species] or nil
end

-- The moves this species knows at `level`, newest four, from the engine's own
-- learnset.  A species with no learnset keeps whatever it had; a species with
-- no moves at all gets the constants' fallbackMove so a party slot is never
-- unable to act.
function Rival:movesFor(species, level)
  local def = self:speciesDef(species)
  local learned = {}
  for _, entry in ipairs((def and def.level1Moves) or {}) do
    learned[#learned + 1] = entry
  end
  for _, entry in ipairs((def and def.learnset) or {}) do
    local at = entry.level or entry.at
    local move = entry.move or entry.id
    if move and at and at <= level then learned[#learned + 1] = move end
  end
  local moves = {}
  -- keep the last four, in learn order, de-duplicated
  for i = math.max(1, #learned - 3), #learned do
    local id = learned[i]
    if id and not Util.contains(moves, id) then moves[#moves + 1] = id end
  end
  if #moves == 0 then
    local data = self.ctx.data
    local fallback = data and data.constants and data.constants.fallbackMove
    if fallback and data.moves and data.moves[fallback] then
      moves[1] = fallback
    end
  end
  return moves
end

function Rival:maxHpOf(slot)
  local combatant = BattleSim.combatant(self.ctx.data, slot)
  return combatant.maxHp
end

function Rival:addPokemon(species, level)
  if not self:speciesDef(species) then return nil, "unknown species" end
  -- the Kanto-Reforged DEX SCOPE is asked live and can only remove: a species
  -- that scope hides is not something this rival should be seen holding
  if self.ctx.compat and self.ctx.compat:krAllows(species) == false then
    return nil, "out of scope"
  end
  -- THE GAUNTLET LOCK.  Until Oak's Lab is finished a rival fields exactly
  -- one Pokemon -- its starter -- no matter how many seeding, load or spawn
  -- paths run.  Repeated empty-bucket re-seeds used to stack a starter every
  -- call; this gate makes a full party of Charmanders in the lab impossible.
  if self.gauntletComplete and not self:gauntletComplete() then
    if #self.party >= 1 then return nil, "gauntlet lock" end
  end
  local cap = self.ctx.data and self.ctx.data.constants
    and self.ctx.data.constants.partyMax or 6
  if #self.party >= cap then return nil, "party full" end
  local def = self:speciesDef(species)
  local slot = {
    species = species,
    level = Util.clamp(math.floor(level or 5), 1, 100),
    moves = self:movesFor(species, level or 5),
  }
  slot.exp = Rival.expForLevel(def, slot.level)
  slot.hp = self:maxHpOf(slot)
  self.party[#self.party + 1] = slot
  if self.registerDex then self:registerDex(species) end
  if self.syncHmProgress then self:syncHmProgress() end
  return slot
end

local function baseStatTotal(def)
  local b = def and def.baseStats or {}
  return (tonumber(b.hp) or 0) + (tonumber(b.attack) or 0)
    + (tonumber(b.defense) or 0) + (tonumber(b.speed) or 0)
    + (tonumber(b.special) or tonumber(b.sp_attack) or 0)
end

-- A caught/traded Pokémon may become personally important to its trainer.
-- The bond lives on the portable slot, so it survives save/load, evolution,
-- PC storage and every engine generation without object identity tricks.
function Rival:considerAttachment(slot, origin)
  if type(slot) ~= "table" or not slot.species then return false end
  local def = self:speciesDef(slot.species) or {}
  local catch = tonumber(def.catchRate or def.catch_rate) or 255
  local bst = baseStatTotal(def)
  local score = 0
  if slot.shiny then score = score + 100 end
  if catch <= 45 then score = score + 45 end
  if catch <= 10 then score = score + 25 end
  if bst >= 450 then score = score + 40 end
  if bst >= 550 then score = score + 25 end
  if tostring(slot.species):match("^WX_") then score = score + 25 end
  if score <= 0 then return false end
  local chance = math.min(0.95, 0.30 + score / 160)
  if not slot.shiny and self.rng and not self.rng:chance(chance) then return false end
  slot.attached = true
  slot.attachment = math.max(tonumber(slot.attachment) or 0, score)
  slot.origin = origin or slot.origin or "caught"
  self:refreshAce()
  return true
end

-- 1.34.0: the ace is no longer decided by how REMARKABLE a Pokémon is.
--
-- Attachment alone makes the ace a fact about the species -- two Collectors who
-- each catch a Lapras end up with the same ace -- which is the opposite of what
-- roadmap §7 asks for. Service record (battles fought, victories, how long it
-- has been on the team, whether it was the starter) now counts alongside it, so
-- the favourite emerges from what a Pokémon has DONE for this trainer.
--
-- A Pokémon with a real service record can become the ace without ever having
-- been "attached", which is how an ordinary starter grows into the ace it
-- should have been all along.
function Rival:refreshAce()
  local best, bestScore
  local now = tonumber(self.ticks) or 0
  local function visit(slot)
    if type(slot) ~= "table" then return end
    slot.ace = nil
    -- Eligible to be the favourite at all: something remarkable about it, or
    -- it was the first Pokémon, or it has actually served. A Pokémon that has
    -- done nothing and is nothing special is not anybody's favourite.
    local service = TeamPlan.serviceScore(slot, now)
    local eligible = slot.attached == true
      or slot.origin == "starter"
      or service >= 20
    if not eligible then return end
    local value = (tonumber(slot.attachment) or 0)
      + baseStatTotal(self:speciesDef(slot.species)) / 10
      + (tonumber(slot.level) or 1)
      + service
    if not bestScore or value > bestScore then best, bestScore = slot, value end
  end
  for _, slot in ipairs(self.party or {}) do visit(slot) end
  for _, box in ipairs(self.pcBoxes or {}) do for _, slot in ipairs(box) do visit(slot) end end
  if best then best.ace = true; self.aceSpecies = best.species
  else self.aceSpecies = nil end
  return best
end

function Rival:gauntletComplete()
  local manager = self.ctx and self.ctx.manager
  if not manager then return self.map ~= "OAKS_LAB" and self.map ~= "PALLET_TOWN" end
  return manager.gauntletDone and manager:gauntletDone() or manager.gauntletFinished == true
end

function Rival:ensureInventory()
  if type(self.inventory) ~= "table" then self.inventory = {} end
  -- v1.11 saves stored balls separately.  Migrate them without duplicating
  -- stock from a save already written by this release.
  if self.inventory.POKE_BALL == nil then
    self.inventory.POKE_BALL = math.max(0, tonumber(self.balls) or 0)
  end
  self.balls = math.max(0, tonumber(self.inventory.POKE_BALL) or 0)
  if type(self.pcBoxes) ~= "table" or #self.pcBoxes == 0 then self.pcBoxes = { {} } end
end

function Rival:itemCount(item)
  self:ensureInventory()
  return math.max(0, tonumber(self.inventory[item]) or 0)
end

function Rival:takeItem(item, count)
  self:ensureInventory()
  count = math.max(1, math.floor(count or 1))
  if self:itemCount(item) < count then return false end
  self.inventory[item] = self.inventory[item] - count
  if item == "POKE_BALL" then self.balls = self.inventory[item] end
  return true
end

function Rival:addItem(item, count)
  self:ensureInventory()
  count = math.max(1, math.floor(count or 1))
  self.inventory[item] = self:itemCount(item) + count
  if item == "POKE_BALL" then self.balls = self.inventory[item] end
  return self.inventory[item]
end

function Rival:storePokemon(slot)
  self:ensureInventory()
  local box = self.pcBoxes[#self.pcBoxes]
  if #box >= 30 then box = {}; self.pcBoxes[#self.pcBoxes + 1] = box end
  box[#box + 1] = slot
  return #self.pcBoxes, #box
end

-- Captures fill the active party first and then go to the rival's PC.  This
-- makes six a team cap, not a collection cap, and gives the AI storage to
-- manage just like the player has.
-- Tag the starter, so §7's "first Pokémon" is a signal the favourite can
-- actually use rather than an accident of catch order.
function Rival:markStarter(slot)
  if type(slot) ~= "table" then return false end
  slot.origin = slot.origin or "starter"
  if slot.since == nil then slot.since = tonumber(self.ticks) or 0 end
  return true
end

-- 2.2.0: one door for every career credit a capture earns, so the four
-- careers cannot disagree about what a catch is worth.
function Rival:creditCapture(species, slot)
  if not Career.isCareer(self:lifePathId()) then return false end
  local promoted = self:creditCareer("caught", 1)
  promoted = self:creditCareer("studied", 1) or promoted
  promoted = self:creditCareer("encounters", 1) or promoted
  if slot and (tonumber(slot.attachment) or 0) >= 45 then
    promoted = self:creditCareer("rare", 1) or promoted
    promoted = self:creditCareer("rareFinds", 1) or promoted
  end
  return promoted
end

function Rival:capturePokemon(species, level)
  if #self.party < 6 then
    local slot, err = self:addPokemon(species, level)
    if slot then self:considerAttachment(slot, "caught") end
    return slot, slot and "party" or err
  end
  if not self:speciesDef(species) then return nil, "unknown species" end
  local slot = { species = species, level = Util.clamp(math.floor(level or 5), 1, 100) }
  slot.moves = self:movesFor(species, slot.level)
  slot.exp = Rival.expForLevel(self:speciesDef(species), slot.level)
  slot.hp = self:maxHpOf(slot)
  self:storePokemon(slot)
  self:considerAttachment(slot, "caught")
  if self.registerDex then self:registerDex(species) end
  if self.syncHmProgress then self:syncHmProgress() end
  return slot, "pc"
end

-- Exchange one boxed duplicate through the local Wonder Trade network.
-- Rival slots are portable simulation data; shiny/perfect metadata is kept
-- until the slot is materialised for a real battle.
function Rival:wonderTradeDuplicate()
  self:ensureInventory()
  local counts = {}
  for _, slot in ipairs(self.party or {}) do
    if slot.species then counts[slot.species] = (counts[slot.species] or 0) + 1 end
  end
  for _, box in ipairs(self.pcBoxes or {}) do
    for _, slot in ipairs(box) do
      if slot.species then counts[slot.species] = (counts[slot.species] or 0) + 1 end
    end
  end
  local offers = {}
  for _, box in ipairs(self.pcBoxes or {}) do
    for i, slot in ipairs(box) do
      if slot.species and (counts[slot.species] or 0) > 1
          and not slot.ace and not slot.attached then
        offers[#offers + 1] = { box=box, index=i, slot=slot }
      end
    end
  end
  if #offers == 0 then return nil end
  local offer = offers[self.rng:int(1, #offers)]
  local pool = {}
  for id, def in pairs((self.ctx.data and self.ctx.data.pokemon) or {}) do
    if type(id) == "string" and id ~= "EGG" and id ~= offer.slot.species
        and type(def) == "table" and type(def.baseStats) == "table"
        and (not self.ctx.compat or self.ctx.compat:krAllows(id) ~= false) then
      pool[#pool + 1] = id
    end
  end
  if #pool == 0 then return nil end
  table.sort(pool)
  local species = pool[self.rng:int(1, #pool)]
  local level = Util.clamp(math.floor(tonumber(offer.slot.level) or 5), 1, 100)
  local received = {
    species=species, level=level, moves=self:movesFor(species, level),
    shiny=true, traded=true, dvs={ attack=15, defense=15, speed=15, special=15, hp=15 },
    origin="wonder_trade", ot="WONDER",
  }
  received.exp = Rival.expForLevel(self:speciesDef(species), level)
  received.hp = self:maxHpOf(received)
  offer.box[offer.index] = received
  self:registerDex(species)
  self:considerAttachment(received, "wonder_trade")
  self:refreshAce()
  return { gave=offer.slot.species, got=species, slot=received }
end

function Rival:managePC()
  self:ensureInventory()
  -- Never field more than six. If an old save exceeds the cap, store extras.
  while #self.party > 6 do self:storePokemon(table.remove(self.party)) end
  -- Replace a fainted active member with a healthy stored one where possible.
  for i, slot in ipairs(self.party) do
    if (tonumber(slot.hp) or 0) <= 0 then
      for _, box in ipairs(self.pcBoxes) do
        if #box > 0 then
          local replacement = table.remove(box, 1)
          self:storePokemon(slot)
          self.party[i] = replacement
          break
        end
      end
    end
  end
end

function Rival:prepareForBattle()
  self:ensureInventory()
  self:managePC()
  -- Status is optional in the simulator but is preserved when an engine slot
  -- supplies it; antidotes and other cures are therefore not decorative.
  for _, slot in ipairs(self.party) do
    local status = tostring(slot.status or "")
    local cures = { POISON = "ANTIDOTE", PARALYSIS = "PARLYZ_HEAL", SLEEP = "AWAKENING", BURN = "BURN_HEAL", FREEZE = "ICE_HEAL" }
    local cure = cures[status]
    if cure and self:takeItem(cure) then slot.status = nil end
    local max, cur = self:maxHpOf(slot), tonumber(slot.hp) or self:maxHpOf(slot)
    if cur > 0 and cur < max * 0.65 then
      for _, item in ipairs({ "HYPER_POTION", "SUPER_POTION", "POTION" }) do
        local spec = Rival.SHOP[item]
        if self:takeItem(item) then
          slot.hp = math.min(max, cur + spec.heal)
          break
        end
      end
    end
  end
end

function Rival:useFieldSupplies()
  self:ensureInventory()
  if (self.repelTicks or 0) > 0 then self.repelTicks = self.repelTicks - 1; return end
  -- Only burn a Repel while travelling a route this rival does NOT want to
  -- train on.  On its own training ground a Repel would be wasted money.
  local training = self.ctx and self.ctx.gyms and self.ctx.gyms.training
  local isTrainingSpot = type(training) == "table"
    and self.map and Util.contains(training, self.map)
  if self.map and self.map:match("^ROUTE_") and not isTrainingSpot
     and self:itemCount("REPEL") > 0 and self.rng:chance(0.20)
     and self:takeItem("REPEL") then
    self.repelTicks = 8
  end
end

-- ------------------------------------------------------------------
-- Ball tiers (1.14.0)
-- ------------------------------------------------------------------
-- Poke, Great and Ultra balls live in the bag.  Rivals buy better balls once
-- their savings allow and use the strongest they hold, which makes catches
-- more reliable -- that is what "save for stronger balls" means.

local BALL_BONUS = { POKE_BALL = 1.0, GREAT_BALL = 1.3, ULTRA_BALL = 1.6 }

function Rival:bestBall()
  self:ensureInventory()
  if self:itemCount("ULTRA_BALL") > 0 then return "ULTRA_BALL" end
  if self:itemCount("GREAT_BALL") > 0 then return "GREAT_BALL" end
  if self:itemCount("POKE_BALL") > 0 then return "POKE_BALL" end
  return nil
end

function Rival:spendBall()
  local ball = self:bestBall()
  if not ball then return nil end
  if self:takeItem(ball) then return ball end
  return nil
end

function Rival:catchBonus()
 local ball=self:bestBall(); local base=(ball and BALL_BONUS[ball]) or 1
 return base*TrainerClasses.catchMultiplier(self,self.ctx and self.ctx.data,nil,{})
end

-- ------------------------------------------------------------------
-- The PC (1.14.0)
-- ------------------------------------------------------------------
-- The rival treats its boxes like the player's: deposit and withdraw at
-- will, swap the best team in for a gym, and let long-term collection live
-- in storage instead of the six active slots.

function Rival:depositPokemon(index)
  self:ensureInventory()
  if not self.party[index] then return false end
  if self.party[index].ace then return false end
  local slot = table.remove(self.party, index)
  self:storePokemon(slot)
  return true
end

function Rival:withdrawPokemon(species)
  self:ensureInventory()
  if #self.party >= 6 then return nil end
  for _, box in ipairs(self.pcBoxes or {}) do
    for i, slot in ipairs(box) do
      if slot.species == species then
        local taken = table.remove(box, i)
        self.party[#self.party + 1] = taken
        self:refreshAce()
        return taken
      end
    end
  end
  return nil
end

-- Sell only surplus boxed Pokémon.  One specimen of every species is always
-- retained across the active party and PC, preserving the long-term
-- collection instead of treating the boxes as disposable overflow.
function Rival:sellDuplicates()
  self:ensureInventory()
  local owned = {}
  for _, slot in ipairs(self.party or {}) do
    if slot.species then owned[slot.species] = (owned[slot.species] or 0) + 1 end
  end
  for _, box in ipairs(self.pcBoxes or {}) do
    for _, slot in ipairs(box) do
      if slot.species then owned[slot.species] = (owned[slot.species] or 0) + 1 end
    end
  end

  local earned, sold = 0, 0
  for _, box in ipairs(self.pcBoxes or {}) do
    for i = #box, 1, -1 do
      local slot = box[i]
      local species = slot and slot.species
      if species and not slot.ace and not slot.attached
         and (owned[species] or 0) > 1 then
        local def = self:speciesDef(species) or {}
        local value = tonumber(def.price or def.sellPrice or def.baseExp
          or def.base_exp) or 100
        value = math.max(50, math.floor(value * math.max(1, tonumber(slot.level) or 1) / 4))
        table.remove(box, i)
        owned[species] = owned[species] - 1
        earned, sold = earned + value, sold + 1
      end
    end
  end
  self:earn(earned)
  return earned, sold
end

-- ------------------------------------------------------------------
-- Move management (1.14.0)
-- ------------------------------------------------------------------

-- Learn a move on a slot, replacing the weakest known move when at four.
function Rival:learnMove(slot, moveId)
  local data = self.ctx.data
  if not (slot and slot.species and moveId) then return false end
  if not (data.moves and data.moves[moveId]) then return false end
  local moves = slot.moves or {}
  slot.moves = moves
  if Util.contains(moves, moveId) then return true end
  if #moves < 4 then
    moves[#moves + 1] = moveId
    return true
  end
  local weakest, wi
  for i, mid in ipairs(moves) do
    local d = data.moves[mid]
    local pow = d and (d.power or 0) or 0
    -- An HM is permanent field progression for this rival. Ordinary level-up
    -- and TM management may replace weak attacks, but never a required HM.
    if not (self.hms and self.hms[mid])
       and (not weakest or pow < (data.moves[weakest]
         and (data.moves[weakest].power or 0) or 0)) then
      weakest, wi = mid, i
    end
  end
  if not weakest then return false end
  local newPower = (data.moves[moveId] and data.moves[moveId].power) or 0
  local oldPower = (data.moves[weakest] and data.moves[weakest].power) or 0
  if newPower <= oldPower then return false end
  moves[wi] = moveId
  return true
end

-- Whether this species can be taught the TM move.  Uses the game's own TM
-- compatibility when the data has it; with no TM data at all, any TM move is
-- accepted (the game gives every species a TM list).
function Rival:canTmLearn(species, moveId)
  local data = self.ctx.data
  local def = self:speciesDef(species)
  local list = def and (def.tms or def.tmMoves)
  if not list and data then
    list = data.tm_moves and data.tm_moves[species]
  end
  if list == nil then return false end
  if list[moveId] == true or list[moveId] == 1 then return true end
  for _, id in ipairs(list) do
    if id == moveId then return true end
  end
  return false
end

-- Spend one owned TM to teach the move to the best suitable slot.
function Rival:tmLearn(moveId, oppParty, activeOnly)
  if not (self.tms and self.tms[moveId]) then return nil end
  local pool = {}
  for _, s in ipairs(self.party) do pool[#pool + 1] = s end
  if not activeOnly then
    for _, box in ipairs(self.pcBoxes or {}) do
      for _, s in ipairs(box) do pool[#pool + 1] = s end
    end
  end
  local best, bestScore
  local move = self.ctx.data.moves and self.ctx.data.moves[moveId]
  for _, slot in ipairs(pool) do
    if self:canTmLearn(slot.species, moveId) then
      local _, current = self:bestEffectiveMove(slot, oppParty or {})
      local score = tonumber(move and move.power) or 0
      if oppParty and #oppParty > 0 and move then
        local total, n = 0, 0
        for _, foe in ipairs(oppParty) do
          local fdef = self:speciesDef(foe.species)
          if fdef then
            total = total + BattleSim.effectiveness(self.ctx.data,
              move.type or "NORMAL", BattleSim.typesOf(fdef))
            n = n + 1
          end
        end
        if n > 0 then score = score * total / n end
      end
      if not Util.contains(slot.moves or {}, moveId)
         and (not bestScore or score - current > bestScore) then
        best, bestScore = slot, score - current
      end
    end
  end
  if best and self:learnMove(best, moveId) then
    self.tms[moveId] = nil
    return best
  end
  return nil
end

-- The TM moves this rival could buy, filtered to the loaded game's moves.
function Rival:tmShop()
  local data = self.ctx.data
  local shop = {}
  for move, price in pairs(Rival.TM_PRICES or {}) do
    if data.moves and data.moves[move] then shop[move] = price end
  end
  return shop
end

function Rival:buyTms()
  self:ensureInventory()
  local shop = self:tmShop()
  local best, bestPrice, bestValue
  for move, price in pairs(shop) do
    local compatible = false
    local knownType = {}
    local candidates = {}
    for _, slot in ipairs(self.party or {}) do candidates[#candidates + 1] = slot end
    for _, box in ipairs(self.pcBoxes or {}) do
      for _, slot in ipairs(box) do candidates[#candidates + 1] = slot end
    end
    for _, slot in ipairs(candidates) do
      for _, known in ipairs(slot.moves or {}) do
        local kd = self.ctx.data.moves and self.ctx.data.moves[known]
        if kd and kd.type then knownType[kd.type] = true end
      end
      if self:canTmLearn(slot.species, move) then compatible = true end
    end
    local def = self.ctx.data.moves and self.ctx.data.moves[move]
    if compatible and def and not self.tms[move] then
      local value = ((tonumber(def.power) or 0) + (knownType[def.type] and 0 or 35))
        / math.max(1, price)
      if not bestValue or value > bestValue then
        best, bestPrice, bestValue = move, price, value
      end
    end
  end
  if not best then return nil end
  if (tonumber(self.money) or 0) - bestPrice < 600 then return nil end
  -- A TM is a training purchase and is recorded as one.
  if self:spend(bestPrice, "TRAINING") <= 0 then return nil end
  self.tms[best] = true
  return best
end

function Rival:findTm()
  local shop = self:tmShop()
  local moves = {}
  for move in pairs(shop) do moves[#moves + 1] = move end
  if #moves == 0 then return nil end
  local move = moves[self.rng:int(1, #moves)]
  self.tms[move] = true
  return move
end

-- Teach every owned, not-yet-applied TM; returns the move ids applied.
function Rival:applyTms(oppParty, activeOnly)
  local applied = {}
  if self.isAtPokemonCenter and not self:isAtPokemonCenter() then return applied end
  for moveId in pairs(self.tms or {}) do
    if self:tmLearn(moveId, oppParty, activeOnly) then applied[#applied + 1] = moveId end
  end
  return applied
end

-- ------------------------------------------------------------------
-- World persistence (1.14.0)
-- ------------------------------------------------------------------

function Rival:defeatedTrainer(class)
  self.defeatedTrainers = self.defeatedTrainers or {}
  self.defeatedTrainers[class] = true
end

function Rival:hasDefeatedTrainer(class)
  return self.defeatedTrainers and self.defeatedTrainers[class] == true
end

-- 1.36.0: NAVIGATION MEMORY (roadmap §15).
--
-- `visitedMaps` has counted arrivals since 1.14 and been read by nobody. It is
-- exactly the navigation memory §15 asks for, so this extends it rather than
-- adding a parallel structure: a map a rival has walked several times is a map
-- it knows, and knowing it makes crossing it quicker.
--
-- THE HARD RULE, from §15 and §38: familiarity may only change how FAST a
-- rival crosses ground it is already allowed to cross. It must never open a
-- route. Every progression and HM gate lives in Rival:canEnterMap and
-- Rival:routeTo, and nothing here touches either -- a rival that has crossed
-- Cerulean a hundred times still cannot pass the Snorlax without the Flute.
--
-- Bounded: familiarity is capped per map, and the table is capped in total,
-- evicting the least-known maps first. A rival cannot accumulate an unbounded
-- atlas over a long game.
Rival.NAV_LIMIT = 64        -- maps a rival keeps familiarity for
Rival.NAV_MAX = 12          -- visits beyond which a map is simply "known"

function Rival:visitMap(mapId)
  if not mapId then return end
  self.visitedMaps = self.visitedMaps or {}
  self.visitedMaps[mapId] = math.min(Rival.NAV_MAX,
    (self.visitedMaps[mapId] or 0) + 1)
  -- The map just arrived at is protected from eviction. Without this a full
  -- atlas can never learn anywhere new: a first visit scores 1, which is
  -- always the least familiar entry, so the rival evicts the ground it is
  -- standing on every single time and familiarity is permanently frozen at
  -- whatever it knew when the table filled. Found by the 24000-tick soak.
  self:trimNavMemory(mapId)
end

-- Deterministic eviction: least familiar first, ties broken on the map id so
-- two identical saves prune identically. `protect` is never evicted.
function Rival:trimNavMemory(protect)
  local maps = self.visitedMaps
  if type(maps) ~= "table" then return end
  local ids = {}
  for id in pairs(maps) do
    if id ~= protect then ids[#ids + 1] = id end
  end
  local total = #ids + (protect and maps[protect] and 1 or 0)
  if total <= Rival.NAV_LIMIT then return end
  table.sort(ids, function(a, b)
    local ca, cb = maps[a] or 0, maps[b] or 0
    if ca ~= cb then return ca > cb end
    return a < b
  end)
  local keep = Rival.NAV_LIMIT - (protect and maps[protect] and 1 or 0)
  for i = keep + 1, #ids do maps[ids[i]] = nil end
end

-- 0 for unseen ground, 1 for a road walked many times.
function Rival:familiarity(mapId)
  if type(mapId) ~= "string" then return 0 end
  local seen = (self.visitedMaps or {})[mapId] or 0
  return Util.clamp(seen / Rival.NAV_MAX, 0, 1)
end

function Rival:knowsRoute(mapId)
  return self:familiarity(mapId) >= 0.5
end

-- How many maps this rival has learned. Surfaced on the debug overlay.
function Rival:navKnownCount()
  local n = 0
  for _, seen in pairs(self.visitedMaps or {}) do
    if seen >= Rival.NAV_MAX / 2 then n = n + 1 end
  end
  return n
end

function Rival:recordEncounter(mapId, species, caught)
  if not (mapId and species) then return end
  self.encounterHistory = self.encounterHistory or {}
  local bySpecies = self.encounterHistory[mapId] or {}
  self.encounterHistory[mapId] = bySpecies
  local entry = bySpecies[species] or { seen = 0, caught = 0 }
  bySpecies[species] = entry
  entry.seen = (entry.seen or 0) + 1
  if caught then entry.caught = (entry.caught or 0) + 1 end
end

-- ------------------------------------------------------------------
-- Goals beyond badges (1.15.0)
-- ------------------------------------------------------------------

-- The Pokédex: every species this rival has held counts toward milestones.
function Rival:registerDex(species)
  if not species then return end
  self.dex = self.dex or {}
  self.dex[species] = true
end

function Rival:dexCount()
  local n = 0
  for _ in pairs(self.dex or {}) do n = n + 1 end
  return n
end

local DEX_MILESTONES = { 10, 25, 50, 100, 150 }

-- The milestone just crossed, or nil.  The caller turns it into news.
function Rival:dexMilestone()
  local count = self:dexCount()
  for _, m in ipairs(DEX_MILESTONES) do
    if count >= m and (self.lastDexMilestone or 0) < m then
      self.lastDexMilestone = m
      return m
    end
  end
  return nil
end

-- Pick a species to hunt from the loaded encounter tables.  Returns it (and
-- stores it) or nil when the game has no encounter data.
function Rival:pickHuntTarget()
  local data = self.ctx.data
  local found = {}
  local function addSlots(slots, mapId)
    for _, entry in ipairs(slots or {}) do
      local sp = type(entry) == "table" and (entry.species or entry.mon) or entry
      if type(sp) == "string" and data.pokemon and data.pokemon[sp]
         and not (self.dex and self.dex[sp]) then
        found[sp] = found[sp] or {}
        if mapId and self.ctx.graph:has(mapId) then
          found[sp][#found[sp] + 1] = mapId
        end
      end
    end
  end
  for mapId, slots in pairs(data and data.encounters or {}) do
    addSlots(slots.slots or slots.grass or slots, mapId)
  end
  local gen2 = data and data.gen2Encounters
  if gen2 then
    for _, kind in ipairs({ gen2.grass, gen2.water }) do
      for mapId, slots in pairs(kind or {}) do addSlots(slots.slots or slots, mapId) end
    end
  end
  local list = {}
  for sp in pairs(found) do list[#list + 1] = sp end
  if #list == 0 then return nil end
  -- Deterministic order before any weighting: pairs() order differs between
  -- runs, and the draw below must reproduce from a save.
  table.sort(list)
  -- 1.37.0 §19: the sky decides what is out there. Weather FX biases wild
  -- encounters toward the sky's favoured type and bans others outright, so a
  -- rival hunting in this weather is likelier to pick something the weather
  -- will actually produce -- and a WEATHER rival leans harder still.
  --
  -- WEIGHTING ONLY. A banned species stays in the pool at weight 1: Weather FX
  -- can change the sky at any moment, and a rival that refused to look for
  -- Growlithe while it rained would simply stop hunting. The draw consumes the
  -- SAME single rng:int call, so pre-1.37 saves replay identically.
  local pool = list
  local skyType = self:weatherFocusType()
  if skyType and #list > 1 then
    local weathery = self:teamStyle() == "WEATHER"
    local weighted = {}
    for _, sp in ipairs(list) do
      local copies = 1
      for _, t in ipairs(BattleSim.typesOf(self:speciesDef(sp))) do
        if Weather.canonicalType(t) == skyType then
          copies = weathery and 4 or 2
          break
        end
      end
      for _ = 1, copies do weighted[#weighted + 1] = sp end
    end
    if #weighted > 0 then pool = weighted end
  end
  self.huntTarget = pool[self.rng:int(1, #pool)]
  local maps = found[self.huntTarget]
  self.huntMap = maps and #maps > 0 and maps[self.rng:int(1, #maps)] or nil
  return self.huntTarget
end

-- A beaten gym leader class to rematch, or nil.
function Rival:pickRematch()
  local beaten = {}
  for cls in pairs(self.defeatedLeaders or {}) do beaten[#beaten + 1] = cls end
  if #beaten == 0 then return nil end
  return beaten[self.rng:int(1, #beaten)]
end

-- ------------------------------------------------------------------
-- Player interaction (1.15.0)
-- ------------------------------------------------------------------

-- A small item to hand over after losing to the player, or nil.
function Rival:pickGiftItem()
  self:ensureInventory()
  local choices = {}
  for item, count in pairs(self.inventory or {}) do
    if tonumber(count) and count > 0 and item ~= "POKE_BALL" then
      choices[#choices + 1] = item
    end
  end
  if #choices == 0 then return nil end
  -- 5.0.9: SORT BEFORE DRAWING. `choices` is built by pairs() over the
  -- inventory, so its ORDER is table hash order -- which is not stable across
  -- processes. Indexing an unordered list with the rival's own deterministic
  -- RNG produced a DIFFERENT gift on different runs of the same save, which
  -- is the one thing this mod's RNG is supposed to rule out. It also made
  -- tests/ai_rivals_test.lua flaky, and a flaky suite is what hid the roster
  -- roll for six releases.
  table.sort(choices)
  local item = choices[self.rng:int(1, #choices)]
  if self:takeItem(item) then return item end
  return nil
end

-- ------------------------------------------------------------------
-- Teams (1.14.0)
-- ------------------------------------------------------------------

-- The slot's best move against an opposing party, as (moveId, score).
function Rival:bestEffectiveMove(slot, oppParty)
  local data = self.ctx.data
  local moves = slot and slot.moves or {}
  local best, bestScore
  for _, mid in ipairs(moves) do
    local mdef = data.moves and data.moves[mid]
    if mdef and (mdef.power or 0) > 0 then
      local total, n = 0, 0
      for _, os in ipairs(oppParty or {}) do
        local odef = self:speciesDef(os.species)
        if odef then
          total = total + BattleSim.effectiveness(data, mdef.type or "NORMAL",
                                                  BattleSim.typesOf(odef))
          n = n + 1
        end
      end
      if n > 0 then
        local score = (mdef.power or 0) * total / n
        if not bestScore or score > bestScore then best, bestScore = mid, score end
      end
    end
  end
  return best, bestScore or 0
end

-- The strongest team this rival can field against an opposing party, drawn
-- from the active six and the PC, ordered by level then type coverage.
function Rival:teamFor(oppParty)
  self:ensureInventory()
  local pool = {}
  for _, s in ipairs(self.party) do pool[#pool + 1] = s end
  for _, box in ipairs(self.pcBoxes or {}) do
    for _, s in ipairs(box) do pool[#pool + 1] = s end
  end
  local function score(slot, covered)
    local lvl = tonumber(slot.level) or 1
    local _, moveScore = self:bestEffectiveMove(slot, oppParty)
    local novelty = 0
    local def = self:speciesDef(slot.species)
    local ownTypes = BattleSim.typesOf(def)
    local incoming, threats = 0, 0
    for _, foe in ipairs(oppParty or {}) do
      local fdef = self:speciesDef(foe.species)
      local attackTypes = {}
      for _, t in ipairs(BattleSim.typesOf(fdef)) do attackTypes[t] = true end
      for _, mid in ipairs(foe.moves or {}) do
        local md = self.ctx.data.moves and self.ctx.data.moves[mid]
        if md and md.type and (tonumber(md.power) or 0) > 0 then attackTypes[md.type] = true end
      end
      for attackType in pairs(attackTypes) do
        incoming = incoming + BattleSim.effectiveness(self.ctx.data, attackType, ownTypes)
        threats = threats + 1
      end
    end
    local defence = 0
    if threats > 0 then
      local average = (incoming / threats) / 10 -- BattleSim uses x10 multipliers
      -- Resistance is valuable and a broad weakness is expensive. This is
      -- deliberately below the level weight so scouting helps without making
      -- a severely under-levelled counter magically preferable.
      defence = (1 - average) * 36
    end
    for _, t in ipairs(BattleSim.typesOf(def)) do
      if not covered[t] then novelty = novelty + 14 end
    end
    for _, mid in ipairs(slot.moves or {}) do
      local md = self.ctx.data.moves and self.ctx.data.moves[mid]
      if md and md.type and not covered[md.type] then novelty = novelty + 6 end
    end
    -- 1.34.0: the IDENTITY term. Deliberately smaller than the level and
    -- matchup terms -- a rival brings what beats the gym, and only chooses
    -- between comparable options by what its team is supposed to look like.
    -- Set high enough and four rivals would field identical "optimal" teams
    -- for every fight, which is the failure roadmap §39 names.
    local identity = self:teamFit(slot.species, slot) * 12
    return lvl * 2 + moveScore / 10 + novelty + defence + identity
      + (slot.ace and 10000 or (slot.attached and 80 or 0))
  end
  local ordered, covered = {}, {}
  while #pool > 0 do
    local bestIndex, bestScore
    for i, slot in ipairs(pool) do
      local value = score(slot, covered)
      if not bestScore or value > bestScore then bestIndex, bestScore = i, value end
    end
    local picked = table.remove(pool, bestIndex)
    ordered[#ordered + 1] = picked
    local def = self:speciesDef(picked.species)
    for _, t in ipairs(BattleSim.typesOf(def)) do covered[t] = true end
    for _, mid in ipairs(picked.moves or {}) do
      local md = self.ctx.data.moves and self.ctx.data.moves[mid]
      if md and md.type then covered[md.type] = true end
    end
  end
  return ordered
end

-- Swap the active party to the best available team for the next gym; unchosen
-- active members go back to the PC.  No-op when there is nothing stored.
function Rival:swapTeamForGym(oppParty)
  self:ensureInventory()
  if self.isAtPokemonCenter and not self:isAtPokemonCenter() then
    return self.party, false
  end
  local stored = 0
  for _, box in ipairs(self.pcBoxes or {}) do stored = stored + #box end
  if stored == 0 then return self.party, false end
  local oldParty = self.party
  local pool = self:teamFor(oppParty)
  local chosen = {}
  for i = 1, math.min(6, #pool) do chosen[#chosen + 1] = pool[i] end
  local inChosen = {}
  for _, s in ipairs(chosen) do inChosen[s] = true end
  for _, box in ipairs(self.pcBoxes or {}) do
    for i = #box, 1, -1 do
      if inChosen[box[i]] then table.remove(box, i) end
    end
  end
  self.party = chosen
  for _, s in ipairs(oldParty) do
    if not inChosen[s] then self:storePokemon(s) end
  end
  return self.party, true
end

-- Store only information this rival could have observed in a completed or
-- face-to-face battle. Engine Pokémon objects are reduced to portable data so
-- opponent knowledge remains safe across saves and game generations.
function Rival:rememberOpponent(id, party, won, tick, includeMoves)
  if not id or type(party) ~= "table" or #party == 0 then return false end
  self.opponentKnowledge = self.opponentKnowledge or {}
  local snapshot = {}
  for _, slot in ipairs(party) do
    local species = slot and (slot.species or slot.speciesId or slot.id)
    if type(species) == "table" then species = species.id or species.name end
    if type(species) == "string" then
      local moves = {}
      if includeMoves ~= false then
        for _, move in ipairs(slot.moves or {}) do
          local mid = type(move) == "table" and (move.id or move.move or move.name) or move
          if type(mid) == "string" then moves[#moves + 1] = mid end
        end
      end
      snapshot[#snapshot + 1] = {
        species = species, level = tonumber(slot.level) or 1, moves = moves,
      }
    end
  end
  if #snapshot == 0 then return false end
  local old = self.opponentKnowledge[id] or {}
  self.opponentKnowledge[id] = {
    party = snapshot,
    wins = (tonumber(old.wins) or 0) + (won == true and 1 or 0),
    losses = (tonumber(old.losses) or 0) + (won == false and 1 or 0),
    lastSeen = tonumber(tick) or tonumber(old.lastSeen) or 0,
  }
  if won == false then self.counterTarget = id end
  return true
end

function Rival:knownOpponentParty(id)
  local memory = self.opponentKnowledge and self.opponentKnowledge[id]
  return memory and memory.party or nil
end

function Rival:rememberRevealedMove(id, species, moveId)
  if type(species) ~= "string" or type(moveId) ~= "string" then return false end
  local party = self:knownOpponentParty(id)
  for _, slot in ipairs(party or {}) do
    if slot.species == species then
      slot.moves = slot.moves or {}
      if not Util.contains(slot.moves, moveId) then slot.moves[#slot.moves + 1] = moveId end
      return true
    end
  end
  return false
end

function Rival:isAtPokemonCenter()
  local map = tostring(self.map or "")
  if map:find("POKECENTER", 1, true) then return true end
  for _, id in ipairs((self.ctx and self.ctx.healingMaps) or {}) do
    if id == self.map then return true end
  end
  return false
end

function Rival:recordPokemonCenterVisit()
  if not self:isAtPokemonCenter() then return false end
  self.lastPokemonCenter = self.map
  return true
end

function Rival:blackoutToNearestPokemonCenter(reason, forceFaint)
  if forceFaint then
    for _, slot in ipairs(self.party or {}) do slot.hp = 0 end
  elseif not self:isFainted() then
    return false
  end
  local graph = self.ctx and self.ctx.graph
  local centers = self.ctx and self.ctx.healingMaps or {}
  -- Blackout always means the nearest reachable Center from the defeat map.
  -- lastPokemonCenter is only a fallback for incomplete conversion graphs.
  local center = graph and graph:nearest(self.map, centers) or nil
  if not center and self.lastPokemonCenter
     and (not graph or graph:has(self.lastPokemonCenter)) then
    center = self.lastPokemonCenter
  end
  center = center or centers[1]
  if not center then return false end
  self.map, self.x, self.y = center, nil, nil
  self.destination = center
  self.route, self.routeIndex, self.path = nil, 1, nil
  self.walking, self.localWalkGoal = false, nil
  self.lastPokemonCenter = center
  self.objective = "HEAL"
  self:setState("HEALING", reason or "blacked out")
  self.travelReason = "Blacked out to " .. Util.spaced(center)
  return true, center
end

-- Backwards-compatible name retained for older callers/tests. Its behaviour is
-- intentionally corrected to nearest-Center blackout semantics.
function Rival:warpToLastPokemonCenter()
  return self:blackoutToNearestPokemonCenter("blacked out to the nearest Poké Center", false)
end

function Rival:needsCounterVisit()
  if not self.counterTarget or self:isAtPokemonCenter() then return false end
  for _, box in ipairs(self.pcBoxes or {}) do
    if #box > 0 then return true end
  end
  return next(self.tms or {}) ~= nil
end

function Rival:needsGymPrepVisit()
  if self:isAtPokemonCenter() then return false end
  local _, badge = self:nextGym()
  if not badge or self.gymTeamPreparedFor == badge then return false end
  for _, box in ipairs(self.pcBoxes or {}) do
    if #box > 0 then return true end
  end
  return next(self.tms or {}) ~= nil
end

function Rival:prepareCounterTeam(id, observedParty)
  local party = observedParty or self:knownOpponentParty(id)
  if type(party) ~= "table" or #party == 0 then return false end
  -- PC withdrawals and deliberate TM work happen only at a real Center. A
  -- challenge elsewhere is accepted with the team currently on hand.
  if not self:isAtPokemonCenter() then return false end
  -- Pick the six first, then spend TMs only on Pokémon that will actually
  -- fight this matchup.
  self:swapTeamForGym(party)
  self:applyTms(party, true)
  self.counterPreparedFor = id
  self.gymTeamPreparedFor = nil
  self.counterTarget = nil
  return true
end

function Rival:leadLevel()
  local best = 0
  for _, slot in ipairs(self.party) do
    best = math.max(best, tonumber(slot.level) or 0)
  end
  return best
end

function Rival:averageLevel()
  if #self.party == 0 then return 0 end
  local sum = 0
  for _, slot in ipairs(self.party) do sum = sum + (tonumber(slot.level) or 0) end
  return sum / #self.party
end

function Rival:strongestSpecies()
  local best
  for _, slot in ipairs(self.party) do
    if not best or (slot.level or 0) > (best.level or 0) then best = slot end
  end
  if not best then return "POKéMON" end
  local def = self:speciesDef(best.species)
  return (def and def.name) or best.species
end

-- Party HP as a fraction of maximum.  This is what HEALING keys off, and what
-- the simulator carries forward between fights, so a rival that just lost to
-- Misty does not walk straight into the next gym at full health.
function Rival:healthFraction()
  if #self.party == 0 then return 1 end
  local cur, max = 0, 0
  for _, slot in ipairs(self.party) do
    local slotMax = self:maxHpOf(slot)
    max = max + slotMax
    cur = cur + Util.clamp(tonumber(slot.hp) or slotMax, 0, slotMax)
  end
  if max == 0 then return 1 end
  return cur / max
end

function Rival:heal()
  for _, slot in ipairs(self.party) do
    slot.hp = self:maxHpOf(slot)
    slot.status = nil
  end
  -- Stored Pokémon are restored at the Center too.  This makes a later PC
  -- withdrawal useful instead of returning a still-fainted collection slot.
  for _, box in ipairs(self.pcBoxes or {}) do
    for _, slot in ipairs(box) do
      slot.hp = self:maxHpOf(slot)
      slot.status = nil
    end
  end
end

function Rival:isFainted()
  for _, slot in ipairs(self.party) do
    -- 3.5.0: a slot with NO hp field is a Pokemon nobody has damaged yet, not
    -- a fainted one. `tonumber(slot.hp) or 0` read nil as zero, so a freshly
    -- added party member -- addPokemon before the first battle stamps hp --
    -- made the whole rival read as FAINTED, and a FAINTED rival refuses to
    -- battle. An absent value means "unknown", and the honest default for
    -- unknown HP is full.
    local max = 0
    local ok, value = pcall(function() return self:maxHpOf(slot) end)
    if ok then max = tonumber(value) or 0 end
    local hp = tonumber(slot.hp)
    if hp == nil then hp = max end
    if hp > 0 then return false end
  end
  return #self.party > 0
end

-- ------------------------------------------------------------------
-- Progression
-- ------------------------------------------------------------------

-- Award exp across the party and apply every consequence: level ups, new
-- moves from the learnset, and evolutions.  Returns a list of change records
-- the caller can log or turn into dialogue.
-- Exp never carries a slot past the rival's current ceiling.  Clamping here
-- rather than in each caller is what makes the guarantee hold: gym wins,
-- training ticks and the plateau trickle all arrive through this one door,
-- and a rival that outran its badges by 30 levels was the soak run's second
-- finding.  The ceiling rises with each badge, so this delays growth rather
-- than capping it forever.
function Rival:gainExp(amount)
  amount=(tonumber(amount) or 0)*TrainerClasses.expMultiplier(self,self.ctx and self.ctx.data,nil,{})
  local events = {}
  local cap = (self.ctx.data and self.ctx.data.constants
               and self.ctx.data.constants.levelCap) or 100
  -- the ceiling is the tighter of the two and moves with the badge ladder
  cap = math.min(cap, self:levelCeiling())
  -- exp is split, but not evenly: the lead takes the larger share, which is
  -- what keeps a rival's party shaped like a real one instead of six clones
  local share = math.max(1, math.floor(amount / math.max(1, #self.party)))
  for i, slot in ipairs(self.party) do
    local def = self:speciesDef(slot.species)
    if def then
      local weight = i == 1 and 1.5 or 1.0
      slot.exp = (tonumber(slot.exp) or Rival.expForLevel(def, slot.level))
        + math.floor(share * weight)
      local level = tonumber(slot.level) or 1
      while level < cap and slot.exp >= Rival.expForLevel(def, level + 1) do
        level = level + 1
        events[#events + 1] = { kind = "level", species = slot.species,
                                level = level }
      end
      if level ~= slot.level then
        slot.level = level
        -- Add newly available natural moves through the same four-move policy
        -- used everywhere else.  Rebuilding the list here used to erase TMs.
        for _, id in ipairs(self:movesFor(slot.species, level)) do
          if not Util.contains(slot.moves or {}, id) and self:learnMove(slot, id) then
            events[#events + 1] = { kind = "move", species = slot.species,
                                    move = id }
          end
        end
        -- a level up restores nothing in Gen 1 except the HP the new maximum
        -- adds, so top up by the difference rather than to full
        local newMax = self:maxHpOf(slot)
        slot.hp = math.min(newMax, (tonumber(slot.hp) or newMax) + 1)
        local evolved = self:tryEvolve(slot)
        if evolved then
          pcall(function() Happiness.noteEvolution(self,evolved,slot.species,slot) end)
          -- 1.34.0: seeing a Pokémon pay off is evidence for an
          -- evolution-focused identity. 1.35.0: and it is the FIRST_EVOLUTION
          -- milestone, recorded as a flag rather than a counter because only
          -- the first one is a story beat.
          self:observeTeamEvidence("EVOLVED")
          self.storyEvolved = true
          self:creditCareer("evolved", 1)
          self:creditCareer("raised", 1)
          events[#events + 1] = { kind = "evolve", from = evolved,
                                  into = slot.species }
        end
      end
    end
  end
  return events
end

-- Level evolutions only.  Stone and trade evolutions need an item or a second
-- trainer; a rival that evolved a Pikachu with no Thunderstone would be
-- inventing progress.  The evolution record is read in both the Gen 1 shape
-- (`species`) and the Gen 2 one (`into`), because the registry documents both.
function Rival:tryEvolve(slot)
  local def = self:speciesDef(slot.species)
  for _, evo in ipairs((def and def.evolutions) or {}) do
    local method = evo.method or evo.kind
    local level = tonumber(evo.level)
    local into = evo.species or evo.into or evo.target
    local isLevel = (method == nil or method == "EVOLVE_LEVEL"
                     or method == "level") and level ~= nil
    -- a target the DEX SCOPE hides is skipped, never silently reached around
    local scoped = (self.ctx.compat == nil)
      or self.ctx.compat:krAllows(into) ~= false
    if isLevel and into and self:speciesDef(into) and scoped
       and (tonumber(slot.level) or 0) >= level then
      local from = slot.species
      slot.species = into
      -- Evolution does not make a Pokémon forget its existing or TM moves.
      -- Add any evolution-form moves without replacing the whole set.
      for _, id in ipairs(self:movesFor(into, slot.level)) do
        if not Util.contains(slot.moves or {}, id) then self:learnMove(slot, id) end
      end
      slot.hp = math.min(self:maxHpOf(slot), (tonumber(slot.hp) or 1) + 5)
      return from
    end
  end
  return nil
end

-- ------------------------------------------------------------------
-- Badges
-- ------------------------------------------------------------------
-- Rival badges are private.  They live in this table and nowhere near
-- save.inventory, so nothing a rival does can add a badge to the player's
-- trainer card or open a HM gate for them.

-- The level this rival is training TOWARDS.  Beyond it there is nothing left
-- to grind for: the next gym is the only thing on its list, so it should go
-- and fight it rather than keep farming Route 1.  With every badge held the
-- ceiling opens to the cap, which is what makes LEAGUE_READY rivals keep
-- creeping up at the plateau instead of freezing.
-- ------------------------------------------------------------------
-- Pacing with the player (3.2.0)
-- ------------------------------------------------------------------
-- A rival that is three gyms ahead has stopped being a rival and become
-- scenery the player can never catch. Two levers keep them alongside:
--
--   BADGES  a rival may lead the player by at most BADGE_LEAD. Because
--           Rival:canEnterMap gates the campaign on the rival's OWN badge
--           count, capping badges caps how far across Kanto they roam as
--           well -- routes follow progression rather than needing a second
--           mechanism. That is asserted in tests/pace_test.lua.
--   LEVELS  Rival:levelCeiling already caps at the player's lead + 3. What it
--           did NOT do is behave when the player has no party yet.
--
-- The badge cap is enforced at the AWARD, not only at objective selection.
-- Selection is advisory -- a rival can be mid-journey when the player's badge
-- count changes, and Can.GYM is only consulted when an objective is chosen --
-- so the honest place for a hard rule is the one door a badge can come
-- through.

-- Rivals may naturally drift up to three badges ahead of the player. The
-- lower side is handled by the simulation catch-up drive: at three behind,
-- optional wandering yields to campaign progress until the gap closes.
Rival.BADGE_LEAD = 3
Rival.BADGE_TRAIL = 3

-- Ceiling before the player has a party at all.
Rival.OPENING_LEVEL_CAP = 8

-- The player's badge count as this rival last saw it. nil means "not told
-- yet", which is treated as 0 rather than as unlimited -- an unknown player
-- must never read as permission.
function Rival:playerBadges()
  return math.max(0, math.floor(tonumber(self.playerPaceBadges) or 0))
end

function Rival:badgeLead()
  return self:badgeCount() - self:playerBadges()
end

-- May this rival win another badge right now?
function Rival:mayEarnBadge()
  return self:badgeLead() < Rival.BADGE_LEAD
end

function Rival:levelCeiling()
  local gym = self:nextGym()
  -- 3.2.0: a player with no party yet used to mean NO CAP (100), so a rival
  -- could grind freely for the whole of the opening before the player's first
  -- Pokemon existed -- and arrive at Brock twenty levels up. An unknown player
  -- now reads as the starting level, not as permission.
  local playerCap = self.playerPaceLevel
    and Util.clamp(math.floor(self.playerPaceLevel) + 3, 5, 100)
    or Rival.OPENING_LEVEL_CAP
  if not gym then return playerCap end
  -- Gym level + 2 is the absolute pre-gym ceiling. Brock's Lv14 ace therefore
  -- permits Lv16 at most, and no personality can silently turn that into Lv20+.
  local margin = math.min(2, math.max(0, tonumber(self.personality.levelMargin) or 2))
  local gymCap = Util.clamp(math.floor((gym.level or 20) + margin), 5, 100)
  return math.min(gymCap, playerCap)
end

function Rival:atLevelCeiling()
  return self:averageLevel() >= self:levelCeiling()
end

-- Use one owned Rare Candy on the lowest-level active Pokémon that is still
-- below the rival's progression ceiling. The candy is consumed only when a
-- level can actually be gained.
function Rival:useRareCandy()
  if self:itemCount("RARE_CANDY") <= 0 then return nil end
  local cap, picked = self:levelCeiling()
  for _, slot in ipairs(self.party or {}) do
    if (tonumber(slot.level) or 1) < cap
       and (not picked or (slot.level or 1) < (picked.level or 1)) then
      picked = slot
    end
  end
  if not picked then return nil end
  local def = self:speciesDef(picked.species)
  if not def then return nil end
  picked.exp = math.max(tonumber(picked.exp) or 0,
    Rival.expForLevel(def, (tonumber(picked.level) or 1) + 1))
  if not self:takeItem("RARE_CANDY") then return nil end
  local before = picked.level
  local events = self:gainExp(0)
  return picked.level ~= before and picked or nil, events
end

-- Party size is progression-aware. A rival should look like another trainer
-- travelling through Kanto, not a late-game collector who somehow has six
-- monsters before Brock. Start with one starter only. After each badge the
-- roster grows by one slot until six. Personalities can choose to stop
-- earlier, but never exceed the progression ceiling.
function Rival:partyTarget()
  -- Oak's gauntlet is the sole early-team lock.  Once it is complete, every
  -- rival may build a full team regardless of gym progression or personality.
  if not self:gauntletComplete() then return 1 end
  return 6
end

-- Early-route pacing. A normal rival should have built a recognisable team
-- before earning the first badge rather than reaching Brock with only its
-- starter. This is a battle-readiness floor, not a free catch: the Pokemon
-- still have to be encountered and a real ball is still consumed.
function Rival:minimumPartyForNextGym()
  if not self:gauntletComplete() then return 1 end
  if self:badgeCount() == 0 then return 3 end
  return 1
end

-- Buy a small travelling stock out of the rival's own money. This is used at
-- the post-lab release because some scatter starts begin on Route 2 and would
-- otherwise bypass Viridian's shop entirely. No balls are created for free.
function Rival:buyDepartureBalls(minimum)
  self:ensureInventory()
  minimum = math.max(0, math.floor(tonumber(minimum) or 5))
  local have = self:itemCount("POKE_BALL")
  local need = math.max(0, minimum - have)
  if need == 0 then return 0 end
  local price = Rival.SHOP.POKE_BALL.price
  local count = math.min(need, math.floor((tonumber(self.money) or 0) / price))
  if count <= 0 then return 0 end
  if self:spend(count * price, "BALLS") <= 0 then return 0 end
  self:addItem("POKE_BALL", count)
  return count
end


-- Organic Poké Ball economy. Rivals do not invent catches from thin air:
-- they spend balls, and they buy more with the money they have won, only
-- once they have left the intro lab and are standing at a real mart stop
-- (town / Poké Center). Personality catchChance scales how aggressively
-- they top up.  Returns how many balls were actually bought; a rival with
-- no money buys nothing.
-- ------------------------------------------------------------------
-- Money (1.38.0)
-- ------------------------------------------------------------------
-- ONE DOOR. Every change to a rival's purse goes through these two, so the
-- ledger cannot drift from the balance and no call site can spend money the
-- rival does not have. Before 1.38 eight separate sites did
-- `rival.money = rival.money + x` by hand.

function Rival:ensureLedger()
  if type(self.ledger) ~= "table" or type(self.ledger.spent) ~= "table" then
    self.ledger = Economy.newLedger(self.ledger)
  end
  return self.ledger
end

function Rival:earn(amount)
  amount=(tonumber(amount) or 0)*TrainerClasses.moneyMultiplier(self,self.rng)
  amount = math.floor(tonumber(amount) or 0)
  if amount <= 0 then return 0 end
  self:ensureLedger()
  self.money = math.max(0, (tonumber(self.money) or 0)) + amount
  Economy.recordIncome(self.ledger, amount)
  return amount
end

-- Returns the amount actually spent -- 0 when the rival cannot afford it.
-- A caller may not assume the spend succeeded; that is the whole point.
function Rival:spend(amount, category)
  amount = math.floor(tonumber(amount) or 0)
  if amount <= 0 then return 0 end
  local purse = math.max(0, math.floor(tonumber(self.money) or 0))
  if amount > purse then return 0 end
  self:ensureLedger()
  self.money = purse - amount
  Economy.recordSpend(self.ledger, category or "HEALING", amount)
  return amount
end

-- Money taken by another trainer (a lost duel). Not a purchase, so it is
-- recorded as a loss rather than against a spending category.
function Rival:forfeit(amount)
  amount = math.floor(tonumber(amount) or 0)
  if amount <= 0 then return 0 end
  local purse = math.max(0, math.floor(tonumber(self.money) or 0))
  local taken = math.min(purse, amount)
  self:ensureLedger()
  self.money = purse - taken
  Economy.recordIncome(self.ledger, -taken)
  return taken
end

-- ------------------------------------------------------------------
-- League (1.39.0)
-- ------------------------------------------------------------------

-- ------------------------------------------------------------------
-- Life path (2.1.0)
-- ------------------------------------------------------------------

function Rival:ensureLifePath()
  if type(self.lifePath) ~= "table" or not self.lifePath.path then
    self.lifePath = LifePath.newRecord(self.lifePath)
  end
  return self.lifePath
end

function Rival:lifePathId() return self:ensureLifePath().path end

-- 2.2.0 --------------------------------------------------------------------

function Rival:ensureCareer()
  local path = self:lifePathId()
  if type(self.career) ~= "table" then self.career = Career.newProgress(path) end
  -- A record whose columns do not match the current path is rebuilt: this is
  -- what makes a later career change (or a renamed metric) safe.
  for _, metric in ipairs((Career.def(path) or {}).metrics or {}) do
    if self.career[metric] == nil then
      self.career = Career.newProgress(path, self.career)
      break
    end
  end
  return self.career
end

function Rival:careerRank() return Career.rank(self:lifePathId(), self:ensureCareer()) end
function Rival:careerLevel() return Career.level(self:lifePathId(), self:ensureCareer()) end

-- Credit a career metric. Returns whether the rival was PROMOTED, so the
-- caller can decide whether it is news -- the credit itself never is.
function Rival:creditCareer(metric, amount)
  local path = self:lifePathId()
  if not Career.isCareer(path) then return false end
  local before = self:careerLevel()
  if not Career.credit(path, self:ensureCareer(), metric, amount) then return false end
  local after = self:careerLevel()
  if after > before then
    self:ensureLifePath().careerLevel = after
    return true, after
  end
  return false
end

-- The objective order this rival works to. A rival on the Gym Challenge, or on
-- a career a later release will build, gets its personality's own list back --
-- which is what lets 2.3 and 2.4 land without touching AI.evaluate again.
function Rival:objectivePriorities()
  return Career.priorities(self:lifePathId())
    or (self.personality and self.personality.priorities)
    or { "TRAIN", "EXPLORE" }
end

function Rival:pursuesBadges()
  return Career.pursuesBadges(self:lifePathId())
end

function Rival:careerCatchBias()
  local base = Career.catchBias(self:lifePathId())
  local bias = self:backgroundCareerBias()
  local path = self:lifePathId()
  return (tonumber(base) or 0) * (1 + (tonumber(bias[path]) or 0))
end

function Rival:careerBlurb() return Career.blurb(self:lifePathId()) end
function Rival:careerFieldwork() return Career.fieldwork(self:lifePathId()) end

-- 2.3.0: where this rival works, resolved once and remembered.
--
-- Resolved lazily rather than at commit time, because the map graph may not be
-- built yet when a career is taken and because a conversion may register maps
-- late. Cached on the rival so the search does not repeat every tick, and
-- re-run only if the cached building has become unreachable -- which is the
-- honest response to a game where it never existed in the first place.
function Rival:careerHome()
  local path = self:lifePathId()
  if not Career.isLocated(path) then return nil end
  if self.careerHomeMap and self.careerHomeFor == path then
    if self.ctx.graph:has(self.careerHomeMap)
       and self:canEnterMap(self.careerHomeMap) then
      return self.careerHomeMap
    end
  end
  local maps = self.ctx.data and self.ctx.data.maps
  if type(maps) ~= "table" then return nil end
  local ids = {}
  for id in pairs(maps) do ids[#ids + 1] = id end
  local home = Career.findHome(path, ids,
    function(id) return self.ctx.graph:has(id) and self:canEnterMap(id) end,
    function(matches)
      -- nearest by route, so a Centre assistant works at the Centre it can
      -- actually reach rather than one across a progression gate
      local best = self.ctx.graph.nearest
        and select(1, self.ctx.graph:nearest(self.map, matches))
      return best
    end)
  self.careerHomeMap, self.careerHomeFor = home, path
  return home
end

-- Is this rival at its post right now? Read by the presence observer so a
-- sighting says what it is actually doing.
function Rival:atCareerHome()
  local home = self:careerHome()
  return home ~= nil and self.map == home
end
function Rival:onGymChallenge() return LifePath.onGymChallenge(self:ensureLifePath()) end

-- The facts life-path decisions are made from. Every field is READ from a
-- system that already owns it -- personality, League, economy, memory, team
-- identity, navigation, relationships -- so there is no new counter and
-- nothing that can disagree with the rest of the mod.
function Rival:backgroundDisposition(subject)
  return Backgrounds.disposition(self.background, subject)
end

function Rival:backgroundPathBias()
  return Backgrounds.pathBias(self.background)
end

function Rival:backgroundCareerBias()
  return Backgrounds.careerBias(self.background)
end

function Rival:lifePathFacts()
  local personality = self.personality or {}
  local record = self:ensureLeague()
  local wall, wallCount = League.wall(record)
  local ghost = 0
  for _, slot in ipairs(self.party or {}) do
    for _, t in ipairs(BattleSim.typesOf(self:speciesDef(slot.species))) do
      if t == "GHOST" then ghost = ghost + 1 end
    end
  end
  -- `gymAttempts` is a table of badge id -> attempts, not a count; summing it
  -- is what "how much has this rival thrown at gyms" actually means.
  local gymFailures = 0
  for badge, attempts in pairs(self.gymAttempts or {}) do
    local n = tonumber(attempts) or 0
    if self.badges and self.badges[badge] then n = math.max(0, n - 1) end
    gymFailures = gymFailures + n
  end
  local badgeDrought = math.max(0, (tonumber(self.ticks) or 0)
    - (tonumber(self.lastBadgeTick) or 0))
  local facts = {
    catchChance = personality.catchChance,
    challengeChance = personality.challengeChance,
    wanderChance = personality.wanderChance,
    badges = self:badgeCount(),
    collection = self:collectionSize(),
    seen = self:dexCount(),
    money = tonumber(self.money) or 0,
    confidence = tonumber(self.confidence) or 1,
    champion = self.champion == true,
    playerLosses = tonumber(self.playerLosses) or 0,
    leagueFailures = wallCount or 0,
    gymFailures = gymFailures,
    badgeDrought = self:badgeCount() >= 8 and 0 or badgeDrought,
    ghostAffinity = math.min(1, ghost / 3),
    mapsKnown = self:navKnownCount(),
    teamStyle = self:teamStyle(),
    hostileToPlayer = self:relationshipTo("player") == "HOSTILE",
    -- 4.6.0: §17 gates Team Rocket behind GRIEVANCE, and until now the only
    -- grievance the model could see was toward the PLAYER. Christopher's
    -- "Competition -> Hatred -> Team Rocket conflict" is a rival-to-rival arc,
    -- so a rival who has come to hate another rival now reads as aggrieved
    -- too. Same fact, same weight, one more way to earn it -- not a second
    -- mechanism bolted on beside the first.
    hostileToRival = self:hasNemesis(),
  }
  -- The relationship facts ride along in the same table, so LifePath sees one
  -- reading of this rival and there is no second call site to forget.
  for fact, value in pairs(self:relationshipFacts()) do facts[fact] = value end
  -- Background path bias is deliberately small. It can break close ties in
  -- Life Path ranking, but it cannot unlock a gated path by itself.
  facts.backgroundPathBias = self:backgroundPathBias()
  return facts
end

-- 4.7.0: THE RELATIONSHIP FACTS.
--
-- "Relationships should change... this can affect Life Paths." These six are
-- how: each is a 0..1 reading of this rival's bonds, and data/lifepaths.lua
-- weights and GATES paths on them, so who a rival knows decides what they can
-- become. AVENGER is unreachable without a betrayal; PROTECTOR without kin.
--
-- Derived on every read, stored nowhere. Absent means ZERO, never a default:
-- a rival nobody has wronged is not slightly betrayed (lesson 5).
function Rival:relationshipFacts(tick)
  local out = { betrayal = 0, jealousy = 0, fear = 0, kinship = 0,
                mentorship = 0, devotion = 0 }
  local bonds = type(self.bonds) == "table" and self.bonds or {}
  for id in pairs(bonds) do
    local state = self:relationshipTo(id, tick)
    local bond = self:bondWith(id, tick)
    -- Strength, not just presence: one betrayal reads lower than three, so a
    -- rival defined by what was done to them scores higher than one who has
    -- had a single bad day.
    if state == "BETRAYED" then
      out.betrayal = math.max(out.betrayal,
        math.min(1, 0.6 + 0.2 * math.max(0, (tonumber(bond.betrayals) or 1) - 1)))
    end
    if state == "JEALOUS" then
      out.jealousy = math.max(out.jealousy,
        math.min(1, 0.5 + (tonumber(bond.rivalry) or 0) / 200))
    end
    if state == "FEARFUL" then
      local edge = (tonumber(bond.losses) or 0) - (tonumber(bond.wins) or 0)
      out.fear = math.max(out.fear, math.min(1, 0.5 + edge / 24))
    end
    if state == "FAMILY" or bond.kin == true then
      out.kinship = math.max(out.kinship, state == "FAMILY" and 1 or 0.6)
    end
    if state == "MENTOR" or state == "PROTEGE" or state == "ADMIRER" then
      out.mentorship = math.max(out.mentorship, state == "ADMIRER" and 0.6 or 1)
    end
    if state == "DEVOTED" then out.devotion = 1 end
  end
  return out
end

-- Does this rival hate somebody? NEMESIS is the state that means it, and
-- HOSTILE is the step before. Derived from the bonds, so it cools off by
-- itself when the bond does.
function Rival:hasNemesis()
  for id in pairs(type(self.bonds) == "table" and self.bonds or {}) do
    if id ~= "player" then
      local state = self:relationshipTo(id)
      if state == "NEMESIS" then return true end
    end
  end
  return false
end

-- Who, if anyone. Used by duel targeting and by the news, so the arc is
-- visible as behaviour rather than only as a label.
function Rival:nemesisId()
  local worst
  for id in pairs(type(self.bonds) == "table" and self.bonds or {}) do
    if id ~= "player" and self:relationshipTo(id) == "NEMESIS" then
      if not worst or tostring(id) < tostring(worst) then worst = id end
    end
  end
  return worst
end

function Rival:lifePathPressure()
  if not self:onGymChallenge() then return 1 end
  return LifePath.pressure(self:lifePathFacts())
end

function Rival:lifePathStage()
  return LifePath.stage(self:lifePathPressure(), self:ensureLifePath().locked)
end

function Rival:lifePathCandidates(limit)
  return LifePath.rankPaths(self:lifePathFacts(), limit or LifePath.candidateWindow())
end

function Rival:ensureLeague()
  if type(self.league) ~= "table" or type(self.league.walls) ~= "table" then
    self.league = League.newRecord(self.league)
  end
  return self.league
end

-- Team strength is what the League bar is measured in, so a rival that failed
-- and then genuinely trained can go straight back and one that has not cannot.
function Rival:leagueStrength()
  local total = 0
  for _, slot in ipairs(self.party or {}) do
    total = total + (tonumber(slot.level) or 1)
  end
  return math.floor(total)
end

function Rival:mayAttemptLeague()
  return League.mayAttempt(self:ensureLeague(), self:leagueStrength())
end

function Rival:leagueWall()
  return League.wall(self:ensureLeague())
end

function Rival:mayChallengeTitle()
  return League.mayChallengeTitle(self:ensureLeague())
end

function Rival:earnedChampionTitle()
  return League.earnedChampion(self:ensureLeague(), self.champion == true)
end

function Rival:assumeChampionLifePath(reason)
  return LifePath.assumeChampion(self:ensureLifePath(), self.ticks, reason)
end

function Rival:leaveChampionLifePath(reason)
  return LifePath.leaveChampion(self:ensureLifePath(), self.ticks, reason)
end

function Rival:spendingProfile()
  return Economy.profile(self.personality, self.teamStyle and self:teamStyle() or nil)
end

function Rival:restockBalls()
  local map = self.map
  if not map or map == "OAKS_LAB" or map == "PALLET_TOWN" then
    return 0
  end
  local centers = self.ctx and self.ctx.gyms and self.ctx.gyms.centers
  local atCenter = false
  if type(centers) == "table" then
    for _, id in ipairs(centers) do
      if id == map then atCenter = true break end
    end
  end
  -- Also treat the parent town of a center / any *_CITY / *_TOWN as a mart stop
  if not atCenter then
    if map:match("_CITY$") or map:match("_TOWN$") or map:match("POKECENTER")
       or map:match("MART") then
      atCenter = true
    end
  end
  if not atCenter then return 0 end
  self:ensureInventory()
  local boughtBalls = 0
  local profile = self:spendingProfile()

  -- EMERGENCY FIRST, and outside the budget.
  --
  -- A rival with an empty bag and no way to catch anything is broken rather
  -- than thrifty, so two Poké Balls come off the top before any category is
  -- funded. This is the one purchase that ignores the profile: a Speedrunner
  -- that has decided balls are a low priority still needs to own one.
  if self:itemCount("POKE_BALL") == 0 then
    local price = Rival.SHOP.POKE_BALL.price
    local count = math.min(2, math.floor((tonumber(self.money) or 0) / price))
    if count > 0 and self:spend(count * price, "BALLS") > 0 then
      self:addItem("POKE_BALL", count)
      boughtBalls = boughtBalls + count
    end
  end

  -- Premium balls are SAVED for, not budgeted for: they cost more than a
  -- single category share, so they are bought when the rival has genuinely
  -- put enough by, and the reserve below stops ordinary shopping eating it.
  if self:badgeCount() >= 4
     and (tonumber(self.money) or 0) >= 4000
     and self:itemCount("ULTRA_BALL") < Rival.SHOP.ULTRA_BALL.target then
    if self:spend(Rival.SHOP.ULTRA_BALL.price, "BALLS") > 0 then
      self:addItem("ULTRA_BALL", 1)
    end
  elseif (tonumber(self.money) or 0) >= 2500
     and self:itemCount("GREAT_BALL") < Rival.SHOP.GREAT_BALL.target then
    local buy = math.min(Rival.SHOP.GREAT_BALL.target - self:itemCount("GREAT_BALL"),
                         math.floor(((tonumber(self.money) or 0) - 1200)
                                    / Rival.SHOP.GREAT_BALL.price))
    if buy > 0 and self:spend(buy * Rival.SHOP.GREAT_BALL.price, "BALLS") > 0 then
      self:addItem("GREAT_BALL", buy)
    end
  end

  -- THE BUDGET. What is left after the reserve is divided between categories
  -- by the rival's profile, and each category may only spend its own share.
  -- This is what makes the shop a decision: money spent on balls is money not
  -- available for potions, so a Collector and a Strategist leave the mart with
  -- visibly different bags.
  local reserve = self:itemCount("ULTRA_BALL") == 0 and 1200 or 600
  local spendable = math.max(0, (tonumber(self.money) or 0) - reserve)
  local budget = Economy.budget(spendable, profile)

  for _, item in ipairs(Rival.SHOP_ORDER) do
    local spec = Rival.SHOP[item]
    if spec and item ~= "RARE_CANDY" then
      local category = Economy.categoryOf(item)
      local target = Economy.targetFor(item, spec, profile, self.personality)
      local deficit = math.max(0, target - self:itemCount(item))
      local afford = math.floor((budget[category] or 0) / spec.price)
      local count = math.min(deficit, afford)
      if count > 0 then
        local cost = count * spec.price
        if self:spend(cost, category) > 0 then
          self:addItem(item, count)
          budget[category] = (budget[category] or 0) - cost
          if item == "POKE_BALL" then boughtBalls = boughtBalls + count end
        end
      end
    end
  end
  return boughtBalls
end

-- True only when a catch is allowed: out of the lab, under party target,
-- and holding at least one ball.
function Rival:canCatch()
  local map = self.map
  if not self:gauntletComplete() or map == "OAKS_LAB" or map == "PALLET_TOWN" then return false end
  if not self:bestBall() then return false end
  return true
end

-- Hard safety net for old saves and every source of growth. This is separate
-- from gainExp because catches, restored saves, and older mod versions can
-- otherwise leave a rival above the next Gym's legal ceiling.
function Rival:enforceLevelCeiling()
  local cap = self:levelCeiling()
  for _, slot in ipairs(self.party or {}) do
    local level = tonumber(slot.level) or 1
    if level > cap then
      local def = self:speciesDef(slot.species)
      slot.level = cap
      slot.exp = Rival.expForLevel(def, cap)
      -- Clamping an old save must not erase taught TM moves. Natural move
      -- legality is less destructive than silently rewriting the full set.
      local max = self:maxHpOf(slot)
      slot.hp = math.min(tonumber(slot.hp) or max, max)
    end
  end
end

function Rival:badgeCount()
  local n = 0
  for _, order in ipairs(self.ctx.gyms.order) do
    if self.badges[order] then n = n + 1 end
  end
  return n
end

function Rival:hasBadge(id) return self.badges[id] == true end

-- The next badge on the ladder this rival does not hold.  Order is the
-- engine's constants.badges order via ctx.gyms.order, so a mod that reorders
-- the gyms reorders the rivals' ladder too.
function Rival:nextBadge()
  for _, id in ipairs(self.ctx.gyms.order) do
    if not self.badges[id] then return id end
  end
  return nil
end

function Rival:nextGym()
  local badge = self:nextBadge()
  if not badge then return nil end
  return self.ctx.gyms.byBadge[badge], badge
end

function Rival:awardBadge(id)
  if not id or self.badges[id] then return false end
  self.badges[id] = true
  -- the badge just won, for the "{LAST} wasn't even close" dialogue token.
  -- Kept as its own field rather than derived: nextBadge() has already moved
  -- on by the time anything asks, so the ladder cannot answer this.
  self.lastBadgeEarned = id
  -- 2.1.0: when the last badge landed. A long drought is one of the honest
  -- signals that a rival has stalled on the Gym Challenge.
  self.lastBadgeTick = math.floor(tonumber(self.ticks) or 0)
  self.newsPending = self:badgeCount()
  self:syncHmProgress()
  return true
end

function Rival:hmMoveExists(move)
  local data = self.ctx and self.ctx.data
  if data and data.moves then return data.moves[move] ~= nil end
  local item = HM_ITEM[move]
  return data and data.items and item and data.items[item] ~= nil or false
end

function Rival:canHmLearn(species, move)
  if self:canTmLearn(species, move) then return true end
  local def = self:speciesDef(species)
  local list = def and (def.tms or def.tmMoves)
  local item = HM_ITEM[move]
  if type(list) ~= "table" or not item then return false end
  if list[item] == true or list[item] == 1 then return true end
  for _, id in ipairs(list) do if id == item then return true end end
  return false
end

function Rival:teachHM(move)
  if not (self.hms and self.hms[move]) or not self:hmMoveExists(move) then
    return nil
  end
  local pool = {}
  for _, slot in ipairs(self.party or {}) do pool[#pool + 1] = slot end
  for _, box in ipairs(self.pcBoxes or {}) do
    for _, slot in ipairs(box) do pool[#pool + 1] = slot end
  end
  for _, slot in ipairs(self.party or {}) do
    if Util.contains(slot.moves or {}, move) then return slot end
  end
  for _, slot in ipairs(pool) do
    if self:canHmLearn(slot.species, move) then
      -- A boxed Pokémon cannot clear an overworld obstacle. Bring the HM user
      -- onto the active team, storing one non-HM party member if necessary.
      local active = false
      for _, held in ipairs(self.party or {}) do
        if held == slot then active = true break end
      end
      if not active then
        for _, box in ipairs(self.pcBoxes or {}) do
          for i, held in ipairs(box) do
            if held == slot then table.remove(box, i) break end
          end
        end
        if #self.party >= 6 then
          local swap = #self.party
          for i = #self.party, 1, -1 do
            local protected = false
            for _, known in ipairs(self.party[i].moves or {}) do
              if self.hms[known] then protected = true break end
            end
            if not protected then swap = i break end
          end
          self:storePokemon(table.remove(self.party, swap))
        end
        self.party[#self.party + 1] = slot
      end
      slot.moves = slot.moves or {}
      if Util.contains(slot.moves, move) then return slot end
      if #slot.moves < 4 then
        slot.moves[#slot.moves + 1] = move
      else
        local replace
        for i, known in ipairs(slot.moves) do
          if not self.hms[known] then
            local power = self.ctx.data.moves[known]
              and (self.ctx.data.moves[known].power or 0) or 0
            if not replace or power < replace.power then
              replace = { index = i, power = power }
            end
          end
        end
        if not replace then return nil end
        slot.moves[replace.index] = move
      end
      self.hmNewsPending = self.hmNewsPending or {}
      self.hmNewsPending[#self.hmNewsPending + 1] = {
        kind = "hm_taught", move = move, species = slot.species,
      }
      return slot
    end
  end
  return nil
end

function Rival:syncHmProgress()
  self.hms, self.hmUses = self.hms or {}, self.hmUses or {}
  for badge, move in pairs(HM_BY_BADGE) do
    if self:hasBadge(badge) and self:hmMoveExists(move) then
      local newlyOwned = not self.hms[move]
      self.hms[move] = badge
      if newlyOwned then
        self.hmNewsPending[#self.hmNewsPending + 1] = {
          kind = "hm_obtained", move = move,
        }
      end
      self:teachHM(move)
    end
  end
end

function Rival:canUseHM(move)
  if not self:hmMoveExists(move) then return true end -- conversion has no HM
  if not (self.hms and self.hms[move]) then return false end
  for _, slot in ipairs(self.party or {}) do
    if Util.contains(slot.moves or {}, move) then return true end
  end
  return false
end

function Rival:missingHMForMap(mapId)
  for _, move in ipairs(self:requiredHMsForMap(mapId)) do
    if not self:canUseHM(move) then return move end
  end
  return nil
end

function Rival:requiredHMsForMap(mapId)
  local u, out = tostring(mapId or ""):upper(), {}
  local function need(move) if self:hmMoveExists(move) then out[#out + 1] = move end end
  if u:find("ROCK_TUNNEL", 1, true) or u:find("DARK_CAVE", 1, true) then need("FLASH") end
  if u:find("VERMILION_GYM", 1, true) or u:find("CELADON_GYM", 1, true)
     or u:find("ILEX_FOREST", 1, true) then need("CUT") end
  if u == "CINNABAR_ISLAND" or u:find("SEAFOAM", 1, true)
     or u:find("ROUTE_19", 1, true) or u:find("ROUTE_20", 1, true)
     or u:find("ROUTE_21", 1, true) or u:find("ROUTE_40", 1, true)
     or u:find("ROUTE_41", 1, true) or u == "CIANWOOD_CITY" then need("SURF") end
  if u:find("VICTORY_ROAD", 1, true) or u:find("SEAFOAM", 1, true)
     or u:find("ICE_PATH", 1, true) or u:find("MT_MORTAR", 1, true) then need("STRENGTH") end
  if u:find("WHIRL_ISLAND", 1, true) then need("WHIRLPOOL") end
  if u:find("TOHJO_FALLS", 1, true) or u:find("MT_SILVER", 1, true) then need("WATERFALL") end
  return out
end

function Rival:useHMsForMap(mapId)
  self.hmUses = self.hmUses or {}
  for _, move in ipairs(self:requiredHMsForMap(mapId)) do
    if not self:canUseHM(move) then return false, move end
    self.hmUses[move] = (self.hmUses[move] or 0) + 1
    if not (self.visitedMaps and self.visitedMaps[mapId]) then
      self.hmNewsPending = self.hmNewsPending or {}
      self.hmNewsPending[#self.hmNewsPending + 1] = {
        kind = "hm_used", move = move, map = mapId,
      }
    end
  end
  return true
end

function Rival:takeHmNews()
  local out = self.hmNewsPending or {}
  self.hmNewsPending = {}
  return out
end

-- The first HM preventing the next Gym/League route. This inspects the raw
-- graph only to discover the obstruction; the route actually travelled still
-- goes through routeTo() and its strict private HM/badge checks.
function Rival:neededHMForProgress()
  self:syncHmProgress()
  if self.hmGoalForced and self.hmGoal then
    if not self:canUseHM(self.hmGoal) then return self.hmGoal end
    self.hmGoal, self.hmGoalForced = nil, false
  end
  local target
  local gym = self:nextGym()
  if gym then target = gym.map or gym.city
  else
    local league = self.ctx and self.ctx.gyms and self.ctx.gyms.league
    target = league and (league.map or league.city)
  end
  if not (target and self.ctx.graph:has(target)) then return nil end
  local direct = self:missingHMForMap(target)
  if direct then return direct, target end
  local raw = self.ctx.graph:route(self.map, target)
  for _, mapId in ipairs(raw or {}) do
    local move = self:missingHMForMap(mapId)
    if move then return move, mapId end
  end
  return nil
end

-- Find a reachable grass encounter containing a species that can learn the
-- missing HM. Water-only encounters are deliberately excluded: requiring
-- Surf to catch the Pokémon needed for Surf would be a circular soft-lock.
function Rival:pickHmHuntTarget(move)
  if not move then return nil end
  local data, found = self.ctx.data, {}
  local function add(mapId, slots)
    if not (mapId and self.ctx.graph:has(mapId) and self:canEnterMap(mapId)) then return end
    if not self:routeTo(mapId) then return end
    for _, entry in ipairs(slots or {}) do
      local species = type(entry) == "table" and (entry.species or entry.mon) or entry
      if type(species) == "string" and data.pokemon and data.pokemon[species]
         and self:canHmLearn(species, move) then
        found[#found + 1] = { species = species, map = mapId }
      end
    end
  end
  for mapId, rec in pairs(data and data.encounters or {}) do
    if type(rec) == "table" then add(mapId, rec.grass or rec.slots or rec) end
  end
  local gen2 = data and data.gen2Encounters
  for mapId, rec in pairs(gen2 and gen2.grass or {}) do
    add(mapId, rec.slots or rec)
  end
  if #found == 0 then return nil end
  local pick = found[self.rng:int(1, #found)]
  self.huntTarget, self.huntMap, self.hmGoal = pick.species, pick.map, move
  return pick.species, pick.map
end

-- Conservative private story gates. Only maps with reliable, universal
-- progression meaning are restricted; conversions and ordinary routes remain
-- routable rather than guessing at the player's flags.
-- Kanto city names as Gold spells them. Routes are handled numerically below.
Rival.KANTO_CITIES = {
  "PALLET_TOWN", "VIRIDIAN", "PEWTER", "CERULEAN", "VERMILION", "LAVENDER",
  "CELADON", "FUCHSIA", "SAFFRON", "CINNABAR", "MT_MOON", "ROCK_TUNNEL",
  "SILPH_CO", "SAFARI_ZONE", "SEAFOAM", "POWER_PLANT", "DIGLETTS_CAVE",
  "VICTORY_ROAD_1", "PEWTER_CITY",
}

-- Is this a Kanto map on a Gold boot? Kanto is postgame there.
--
-- INDIGO_PLATEAU is excluded on purpose: it is the JOHTO league too, reached
-- from Route 26 long before Kanto opens.
function Rival.isKantoOnGold(upper)
  if type(upper) ~= "string" then return false end
  if upper:find("INDIGO_PLATEAU", 1, true) then return false end
  local route = upper:match("^ROUTE_(%d+)")
  if route then
    -- Gold: Johto is routes 26-48, Kanto 1-25.
    return tonumber(route) <= 25
  end
  for _, token in ipairs(Rival.KANTO_CITIES) do
    if upper:find(token, 1, true) then return true end
  end
  return false
end

function Rival:canEnterMap(mapId)
  if type(mapId) ~= "string" then return false end
  local upper = mapId:upper()
  local badges = self:badgeCount()
  for _, move in ipairs(self:requiredHMsForMap(mapId)) do
    if not self:canUseHM(move) then return false end
  end
  if upper:find("VICTORY_ROAD", 1, true) or upper:find("ROUTE_23", 1, true)
     or upper:find("INDIGO_PLATEAU", 1, true) then
    return self:nextBadge() == nil
  end
  -- The raw ROM map graph describes physical connections, not overworld
  -- blockers such as Snorlax, the cycling-road gate or story checkpoints.
  -- Without private progression floors an exploring rival can chain random
  -- neighbouring maps from Pallet all the way to Fuchsia with no badges.
  -- Apply the canonical Kanto campaign stages to cities and their approaches;
  -- conversions without Kanto's badge table retain their own graph behaviour.
  local byBadge = self.ctx and self.ctx.gyms and self.ctx.gyms.byBadge

  -- 2.10.0 -- GOLD: KANTO IS POSTGAME.
  --
  -- Reported: "in gen 2 gold the rivals are starting in Kanto. That's post
  -- game in gen 2."
  --
  -- Two things combined. Gold's map table really does contain every Kanto
  -- map -- they are simply unreachable until the Elite Four is beaten -- and
  -- the campaign floors below only engage when `byBadge.BOULDERBADGE` exists,
  -- which is the KANTO badge table. On a Gold boot byBadge is the Johto table
  -- (ZEPHYR, HIVE, ...), so that whole block was skipped and a rival had NO
  -- progression floor of any kind. Free to walk the raw connection graph, it
  -- wandered into content the player cannot reach for another forty hours.
  --
  -- The gate mirrors the player's own: Kanto opens when the League is beaten.
  -- Identified by Kanto's city names plus its route NUMBERS -- Gold's Johto
  -- routes are 26 and up, Kanto's are 25 and down, which is a clean split that
  -- needs no per-map table. INDIGO_PLATEAU is deliberately NOT in the set: it
  -- is the Johto league, reached from Route 26, and blocking it would wall a
  -- rival out of its own main story.
  if byBadge and byBadge.ZEPHYR and not byBadge.BOULDERBADGE then
    if not self.champion and Rival.isKantoOnGold(upper) then return false end
  end

  if byBadge and byBadge.BOULDERBADGE then
    local floors = {
      { 5, { "CINNABAR", "ROUTE_19", "ROUTE_20", "ROUTE_21", "SEAFOAM" } },
      { 4, { "FUCHSIA", "SAFARI_ZONE", "ROUTE_12", "ROUTE_13", "ROUTE_14",
              "ROUTE_15", "ROUTE_16", "ROUTE_17", "ROUTE_18", "SAFFRON",
              "SILPH_CO" } },
      { 2, { "VERMILION", "CELADON", "LAVENDER", "ROCK_TUNNEL",
              "ROUTE_5", "ROUTE_6", "ROUTE_7", "ROUTE_8", "ROUTE_9",
              "ROUTE_10", "ROUTE_11", "DIGLETTS_CAVE" } },
      { 1, { "CERULEAN", "MT_MOON", "ROUTE_3", "ROUTE_4" } },
    }
    for _, floor in ipairs(floors) do
      for _, token in ipairs(floor[2]) do
        -- Passing the area floor does not automatically grant access to a Gym
        -- interior; allow the stricter ordered-Gym check below to run too.
        if upper:find(token, 1, true) and badges < floor[1] then return false end
      end
    end
  end
  for index, badge in ipairs(self.ctx.gyms.order or {}) do
    local gym = self.ctx.gyms.byBadge and self.ctx.gyms.byBadge[badge]
    -- Gate the Gym interior, never its city: Viridian City is an early travel
    -- hub even though its Gym is last in Kanto.
    if gym and mapId == gym.map then
      return badges >= index - 1
    end
  end
  return true
end

function Rival:routeTo(mapId)
  local graph = self.ctx and self.ctx.graph
  if not (graph and mapId and self.map) then return nil end
  if not self:canEnterMap(mapId) then return nil end
  if graph.routeAllowed then
    return graph:routeAllowed(self.map, mapId, function(id) return self:canEnterMap(id) end)
  end
  return graph:route(self.map, mapId)
end

-- ------------------------------------------------------------------
-- State machine
-- ------------------------------------------------------------------

function Rival:setState(state, reason)
  if not STATE_SET[state] then return false end
  if self.state == state then return false end
  self.previousState = self.state
  self.state = state
  self.stateReason = reason
  self.stateSince = self.ticks
  return true
end

function Rival:setDestination(mapId)
  self.destination = mapId
  self.route, self.routeIndex = nil, 1
  if not (mapId and self.map and self.ctx and self.ctx.graph and self.ctx.graph.route) then
    return
  end
  local ok, route = pcall(function()
    return self:routeTo(mapId)
  end)
  self.route = ok and route or nil
end

-- The next map on the strategic route, or nil when we are already there or
-- have no route.
function Rival:nextHop()
  local route = self.route
  if not route then return nil end
  for i = 1, #route do
    if route[i] == self.map then return route[i + 1] end
  end
  -- the rival is off its own route (a warp moved it, a map was unregistered);
  -- the caller re-plans rather than guessing
  return nil
end

function Rival:atDestination()
  return self.destination == nil or self.map == self.destination
end

-- ------------------------------------------------------------------
-- The player relationship
-- ------------------------------------------------------------------

function Rival:rememberPlayerBattle(observation)
  observation = observation or {}
  observation.rivalWon = observation.rivalWon == true
  self.memory = Memory.playerBattle(self.memory, observation)
  return self.memory
end

function Rival:rememberEvent(event)
  self.memory = Memory.new(self.memory)
  return Memory.event(self.memory, event)
end

-- ------------------------------------------------------------------
-- Relationships (1.33.0)
-- ------------------------------------------------------------------
-- Thin, deliberately.  Every rule about what a bond means lives in
-- src/Relationships.lua; these five methods exist so callers never have to
-- know that `bonds` is a plain table, and so the tick is supplied from one
-- place rather than by each caller guessing.

function Rival:relationshipTick(tick)
  return math.max(0, math.floor(tonumber(tick) or tonumber(self.ticks) or 0))
end

-- The bond as of now, decayed.  A subject never met reads as a blank NEUTRAL
-- bond rather than nil.
function Rival:bondWith(id, tick)
  self.bonds = type(self.bonds) == "table" and self.bonds or Relationships.new()
  local bond = Relationships.bond(self.bonds, id, self:relationshipTick(tick))
  -- Kin is a fact about the ROSTER, so it is stamped here, on the one path
  -- every bond read goes through, rather than at whichever site happens to
  -- create the bond first. Re-stamped every read on purpose: a save written
  -- before a roster edit then agrees with the roster it is loaded against,
  -- instead of remembering a family that no longer exists.
  bond.kin = self:isKinWith(id)
  return bond
end

function Rival:relationshipTo(id, tick)
  return Relationships.state(self:bondWith(id, tick))
end

-- 4.7.0: WHO THIS RIVAL WANTS TO BE NEAR.
--
-- 4.6 gave lovers a reason to travel together. The relationship careers
-- (PROTECTOR, FAMILY_TRAINER, DISCIPLE, DEVOTED_PARTNER) want the same
-- machinery for a different reason, so the QUESTION is generalised rather than
-- the mechanism copied: a partner, then family, then a teacher. First match
-- wins, ties break on id, so the answer is stable across loads.
function Rival:closeCompanionId(rivals, tick)
  local partner = self:partnerAmong(rivals, tick)
  if partner then return partner.id, "partner" end
  local kin, teacher
  for _, other in ipairs(rivals or {}) do
    if other and other.id and other.id ~= self.id then
      if self:isKinWith(other.id) then
        if not kin or tostring(other.id) < tostring(kin) then kin = other.id end
      end
      local state = self:relationshipTo(other.id, tick)
      if state == "PROTEGE" or state == "ADMIRER" then
        if not teacher or tostring(other.id) < tostring(teacher) then teacher = other.id end
      end
    end
  end
  if kin then return kin, "family" end
  if teacher then return teacher, "teacher" end
  return nil
end

-- Family is DECLARED, not derived: no sequence of battles makes two rivals
-- siblings. Roster rows may name kin directly, and the generated roster deals
-- a handful of ties from the world seed the same way it deals starters.
function Rival:isKinWith(id)
  local kin = self.def and self.def.kin
  if type(kin) == "table" then
    for _, other in ipairs(kin) do if other == id then return true end end
  elseif type(kin) == "string" then
    return kin == id
  end
  return false
end

-- 4.6.0: what the TWO of them are, which neither can decide alone. LOVERS
-- needs both sides at DEVOTED, a FEUD needs both sides cold. `other` is the
-- live rival, because the answer depends on a bond this rival does not own.
function Rival:pairStateWith(other, tick)
  if type(other) ~= "table" or not other.bondWith or other.id == self.id then
    return "NONE"
  end
  local mine = self:bondWith(other.id, tick)
  local theirs = other:bondWith(self.id, tick)
  return Relationships.pairState(mine, theirs)
end

-- The rival this one is inseparable from, if any. Deterministic: ties break on
-- id, so a rival with two mutual devotions (which the thresholds make close to
-- impossible) still behaves the same way on every load.
function Rival:partnerAmong(rivals, tick)
  local best
  for _, other in ipairs(rivals or {}) do
    if other and other.id and other.id ~= self.id then
      if self:pairStateWith(other, tick) == "LOVERS" then
        if not best or tostring(other.id) < tostring(best.id) then best = other end
      end
    end
  end
  return best
end

-- How much this rival's badge case is ahead of the subject's.  Feeds the
-- MENTOR derivation, which is the one state that needs more than the bond.
function Rival:relationshipLead(other)
  if type(other) ~= "table" or not other.badgeCount then return 0 end
  return self:badgeCount() - other:badgeCount()
end

-- Returns bond, previousState, newState, changed.
function Rival:recordRelationship(id, code, opts)
  self.bonds = type(self.bonds) == "table" and self.bonds or Relationships.new()
  opts = opts or {}
  opts.tick = self:relationshipTick(opts.tick)
  return Relationships.apply(self.bonds, id, code, opts)
end

function Rival:recordRelationshipBattle(id, won, opts)
  self.bonds = type(self.bonds) == "table" and self.bonds or Relationships.new()
  opts = opts or {}
  opts.tick = self:relationshipTick(opts.tick)
  return Relationships.battle(self.bonds, id, won == true, opts)
end

-- The multiplier the AI applies to its own duel/skirmish odds against this
-- subject.  Hostility shows up as behaviour, not just as a label.
-- ------------------------------------------------------------------
-- Story (1.35.0)
-- ------------------------------------------------------------------
-- The facts snapshot is the whole integration point. Everything in it is READ
-- from a system that already owns it -- Memory for the recent record, TeamPlan
-- for identity changes, Relationships for the social read, the party and badge
-- case for progress. Nothing here is a new counter, because a second copy of
-- "how many battles has this rival won" is a second thing to get wrong.

function Rival:ensureStory()
  if type(self.story) ~= "table" or not self.story.mood then
    self.story = Story.new(self.story)
  end
  return self.story
end

-- Recent form, from the memory this rival already keeps: positive is a win
-- streak, negative a losing one. Only completed battles count.
function Rival:recentStreak()
  local events = self.memory and self.memory.events or {}
  local streak = 0
  for i = #events, 1, -1 do
    local outcome = events[i] and events[i].outcome
    if outcome == "win" then
      if streak < 0 then break end
      streak = streak + 1
    elseif outcome == "loss" then
      if streak > 0 then break end
      streak = streak - 1
    end
    if math.abs(streak) >= 6 then break end
  end
  return streak
end

function Rival:collectionSize()
  local n = #(self.party or {})
  for _, box in ipairs(self.pcBoxes or {}) do n = n + #box end
  return n
end

function Rival:storyFacts()
  self:ensureStory()
  local story = self.story
  local shiny, rare, aceBattles = false, false, 0
  local function visit(slot)
    if type(slot) ~= "table" then return end
    if slot.shiny then shiny = true end
    if (tonumber(slot.attachment) or 0) >= 45 then rare = true end
    if slot.ace then aceBattles = math.max(aceBattles, tonumber(slot.battles) or 0) end
  end
  for _, slot in ipairs(self.party or {}) do visit(slot) end
  for _, box in ipairs(self.pcBoxes or {}) do
    for _, slot in ipairs(box) do visit(slot) end
  end

  local rivalWins = 0
  for id, bond in pairs((self.bonds or {})) do
    if id ~= "player" then rivalWins = rivalWins + (tonumber(bond.wins) or 0) end
  end

  local plan = self:ensureTeamPlan()
  local tick = tonumber(self.ticks) or 0
  return {
    tick = tick,
    badges = self:badgeCount(),
    party = #(self.party or {}),
    collection = self:collectionSize(),
    seen = self:dexCount(),
    playerWins = tonumber(self.playerWins) or 0,
    playerLosses = tonumber(self.playerLosses) or 0,
    rivalWins = rivalWins,
    leagueAttempts = tonumber(self.leagueAttempts) or 0,
    champion = self.champion == true,
    confidence = tonumber(self.confidence) or 1,
    streak = self:recentStreak(),
    shiny = shiny,
    rare = rare,
    aceBattles = aceBattles,
    evolved = self.storyEvolved == true,
    teamChanges = tonumber(plan.changed) or 0,
    -- §4's TRAINING and TEAM CHANGE beats, read from the systems that own them
    teamChangedSinceSetback = story.setbackTick ~= nil
      and (tonumber(self.teamChangedAt) or -1) > story.setbackTick,
    trainedSinceSetback = story.setbackTick ~= nil
      and (tonumber(self.trainedAt) or -1) > story.setbackTick,
    hasGoal = (self.huntTarget ~= nil) or (self.hmGoal ~= nil)
      or (self.destination ~= nil and self.destination ~= self.map),
  }
end

-- One call per tick from the simulation. Returns newly unlocked milestones and
-- whether the chapter turned, so the caller decides what is worth telling the
-- player. Mood changes are deliberately not reported: §31 says do not spam,
-- and a mood is something you notice by talking to someone.
function Rival:advanceStory(tick)
  local story = self:ensureStory()
  tick = math.max(0, math.floor(tonumber(tick) or tonumber(self.ticks) or 0))
  local facts = self:storyFacts()
  facts.tick = tick
  local gained
  if not story.seeded then
    -- first sight of a pre-1.35 save: record what it has already earned
    Story.backfill(story, facts, tick)
    gained = {}
  else
    gained = Story.check(story, facts, tick)
  end
  local _, chapter, _, chapterChanged, chapterNotable =
    Story.advance(story, facts, tick)
  -- Milestones are the durable history §32 asks for, and Rival:rememberEvent
  -- has existed unused since 1.32; this is what it was for.
  for _, milestone in ipairs(gained) do
    self:rememberEvent({ tick = tick, type = "MILESTONE", target = milestone.id })
  end
  return gained, chapter, chapterChanged, facts, chapterNotable
end

function Rival:mood() return self:ensureStory().mood end
function Rival:moodLabel() return Story.moodLabel(self:mood()) end
function Rival:chapter() return self:ensureStory().chapter end
function Rival:chapterLabel() return Story.chapterLabel(self:chapter()) end

-- A defeat that matters opens a setback; beating that opponent closes it.
-- The severity read is supplied from the rival's own state, so the model
-- decides what counts as a setback and the caller only reports the defeat.
function Rival:noteDefeat(byId, tick)
  return Story.openSetback(self:ensureStory(), byId,
    tick or self.ticks or 0,
    { streak = self:recentStreak(), confidence = tonumber(self.confidence) or 1 })
end

function Rival:noteVictory(overId, tick)
  return Story.answerSetback(self:ensureStory(), overId,
    tick or self.ticks or 0)
end

function Rival:noteTrained(tick)
  self.trainedAt = math.max(tonumber(self.trainedAt) or 0,
    math.floor(tonumber(tick) or tonumber(self.ticks) or 0))
end

-- ------------------------------------------------------------------
-- Team identity (1.34.0)
-- ------------------------------------------------------------------
-- Thin, like the relationship methods: every rule lives in src/TeamPlan.lua.

function Rival:ensureTeamPlan()
  if type(self.teamPlan) ~= "table" or not self.teamPlan.style then
    self.teamPlan = TeamPlan.new(self.teamPlan,
      self.personality and self.personality.teamPlan)
  end
  return self.teamPlan
end

function Rival:teamStyle() return self:ensureTeamPlan().style end
function Rival:teamStyleLabel() return TeamPlan.label(self:teamStyle()) end
function Rival:battleStyle() return TeamPlan.battleStyle(self:teamStyle()) end

function Rival:preferredType()
  local id, share = TeamPlan.preferredType(self:ensureTeamPlan())
  return id, share
end

function Rival:preferredTypes(count)
  return TeamPlan.preferredTypes(self:ensureTeamPlan(), count)
end

function Rival:favouriteSpecies()
  local ace = self:refreshAce()
  return ace and ace.species or nil
end

-- 1.37.0: the sky, as this rival sees it. Every weather read in this file goes
-- through these three, so nothing else has to know whether Weather FX is even
-- installed -- with no host they return nil / 0 and every caller behaves
-- exactly as it did before weather existed.
function Rival:currentWeatherId()
  local compat = self.ctx and self.ctx.compat
  if not compat or not compat.weather or not compat:weather() then return nil end
  return compat:weatherId()
end

-- The type the sky currently favours, which is what a WEATHER team builds
-- around and what a weather hunter goes looking for.
function Rival:weatherFocusType(id)
  local compat = self.ctx and self.ctx.compat
  if not compat then return nil end
  return Weather.favouredType(compat, id or self:currentWeatherId())
end

-- -1..1: does this sky suit the team it is actually fielding right now?
function Rival:weatherAffinity(id)
  local compat = self.ctx and self.ctx.compat
  if not compat then return 0 end
  id = id or self:currentWeatherId()
  if not id then return 0 end
  local types = {}
  for _, slot in ipairs(self.party or {}) do
    for _, t in ipairs(BattleSim.typesOf(self:speciesDef(slot.species))) do
      types[#types + 1] = t
    end
  end
  return Weather.affinity(compat, id, types)
end

-- How well a species fits this rival's identity. `slot` is optional; when
-- given, its own moves and ace flag are taken into account.
function Rival:teamFit(species, slot)
  local def = self:speciesDef(species or (slot and slot.species))
  if not def then return 0 end
  return TeamPlan.fit(self:ensureTeamPlan(), def,
    slot and slot.moves or self:movesFor(species or slot.species,
      slot and slot.level or 5),
    self.ctx.data, { favourite = slot and slot.ace == true,
                     -- a WEATHER identity focuses on the sky, not its record
                     skyType = self:weatherFocusType() })
end

-- Evidence that this rival's identity should move. Returns previous, new,
-- changed so the caller can decide whether it is newsworthy.
function Rival:observeTeamEvidence(reason)
  local _, before, after, changed = TeamPlan.observe(self:ensureTeamPlan(), reason)
  if changed then
    -- 1.35.0: stamp WHEN the identity moved. Story.chapter needs to tell a
    -- rebuild that answers a defeat from one that happened long before it.
    self.teamChangedAt = math.floor(tonumber(self.ticks) or 0)
  end
  return before, after, changed
end

-- Credit the active lead with a battle it actually fought, and credit the
-- team's types with the result. The lead is used rather than the whole party
-- because "most battles" should mean the Pokémon that does the fighting, and
-- because it is the one fact every battle site already knows without needing
-- a per-slot HP snapshot.
function Rival:creditLeadBattle(won)
  self:ensureTeamPlan()
  local lead = self.party and self.party[1]
  if type(lead) == "table" then
    lead.battles = math.min(9999, (tonumber(lead.battles) or 0) + 1)
    if won then lead.wins = math.min(9999, (tonumber(lead.wins) or 0) + 1) end
    if lead.since == nil then lead.since = tonumber(self.ticks) or 0 end
  end
  local types = {}
  for _, slot in ipairs(self.party or {}) do
    for _, id in ipairs(BattleSim.typesOf(self:speciesDef(slot.species))) do
      types[#types + 1] = id
    end
  end
  TeamPlan.creditTypes(self.teamPlan, types, won == true)
  -- A type that has come to dominate this rival's record turns it into a
  -- specialist -- but only once, and only on real accumulated credit.
  -- 1.37.0: these two readings are EXCLUSIVE, and picking between them matters.
  --
  -- A mono-Electric team winning in a thunderstorm is evidence for a type
  -- specialist AND for a weather specialist, and firing both alternately makes
  -- them cancel under 1.34's contradictory-evidence rule -- so a rival that
  -- most obviously deserves the WEATHER identity could never reach it. When
  -- the dominant type is exactly what the sky favours, the SKY is the better
  -- explanation for the wins, so that is the evidence recorded. When they
  -- differ, the record stands on its own and type mastery is.
  local dominant, share = self:preferredType()
  local sky = self:weatherFocusType()
  local rodeTheSky = won and sky ~= nil and self:weatherAffinity() > 0.25
  if rodeTheSky and (dominant == nil or dominant == sky) then
    self:observeTeamEvidence("RODE_THE_SKY")
  elseif share >= TeamPlan.MONO_SHARE then
    self:observeTeamEvidence("TYPE_MASTERY")
  elseif rodeTheSky then
    self:observeTeamEvidence("RODE_THE_SKY")
  end
  self:refreshAce()
  return lead
end

function Rival:fightBiasToward(id, tick)
  return Relationships.fightBias(self:relationshipTo(id, tick))
end

function Rival:willCooperateWith(id, tick)
  return Relationships.willCooperate(self:relationshipTo(id, tick))
end
function Rival:recordPlayerBattle(rivalWon, tick)
  if rivalWon then
    self.playerWins = self.playerWins + 1
    self.confidence = Util.clamp(self.confidence + 0.15, 0.5, 2.0)
  else
    self.playerLosses = self.playerLosses + 1
    self.confidence = Util.clamp(self.confidence - 0.20, 0.5, 2.0)
  end
  self.lastPlayerBattle = tick
  self.lastResult = rivalWon and "win" or "loss"
  -- a beaten rival goes and trains; it does not quietly get stronger
  self.encounterCooldown = rivalWon and 18 or 36
end

function Rival:battleParty()
  -- a defensive copy: the engine builds Pokemon from these slots and a party
  -- record it mutated would rewrite the rival's saved team
  local out = {}
  for _, slot in ipairs(self.party) do
    out[#out + 1] = { species = slot.species,
                      level = Util.clamp(math.floor(slot.level or 5), 1, 100),
                      moves = slot.moves and Util.copy(slot.moves) or nil,
                      dvs = slot.dvs and Util.copy(slot.dvs) or nil,
                      shiny = slot.shiny == true,
                      ace = slot.ace == true }
  end
  if #out == 0 then
    -- the engine asserts on an empty party; a rival with nothing is a bug
    -- upstream, but it must not take the battle screen down with it
    local opts = { seed = self.ctx.starterSeed, roster = self.ctx.roster,
                   pokemon = self.ctx.data and self.ctx.data.pokemon }
    out[1] = { species = Rival.firstAvailableStarter(self.def,
                 self.ctx.versionKey, self.ctx.data and self.ctx.data.pokemon,
                 nil, opts)
                 or Rival.starterChain(self.def, self.ctx.versionKey, opts)[1],
               level = 5 }
  end
  return out
end

-- ------------------------------------------------------------------
-- Serialization
-- ------------------------------------------------------------------
-- Data only: no metatables, no functions, no engine object references.  The
-- runtime-only fields (path, ctx, rng object, the npc handle) are rebuilt on
-- load, which is why they are absent here rather than nil-ed.

function Rival:serialize()
  return {
    id = self.id,
    -- 4.7.1: the rival's assigned given name is save state. This prevents a
    -- reload or an old save migration from silently renaming a character.
    name = self.name,
    personalityId = self.personalityId,
    backgroundId = self.backgroundId,
    forcedTitle = self.forcedTitle,
    rocketAdminPotential = self.rocketAdminPotential == true,
    backgroundApplied = self.backgroundApplied == true,
    backgroundDispositionApplied = self.backgroundDispositionApplied == true,
    state = self.state,
    objective = self.objective,
    travelReason = self.travelReason,
    map = self.map, x = self.x, y = self.y,
    destination = self.destination,
    party = Util.copy(self.party),
    badges = Util.copy(self.badges),
    defeatedLeaders = Util.copy(self.defeatedLeaders),
    gymAttempts = Util.copy(self.gymAttempts),
    gymCooldown = self.gymCooldown,
    playerWins = self.playerWins,
    playerLosses = self.playerLosses,
    lastPlayerBattle = self.lastPlayerBattle,
    opponentKnowledge = Util.copy(self.opponentKnowledge or {}),
    memory = Memory.serialize(self.memory),
    bonds = Relationships.serialize(self.bonds),
    teamPlan = TeamPlan.serialize(self.teamPlan),
    story = Story.serialize(self.story),
    ledger = Economy.serializeLedger(self.ledger),
    league = League.serializeRecord(self.league),
    lifePath = LifePath.serializeRecord(self.lifePath),
    career = Career.serializeProgress(self:lifePathId(), self.career),
    lastBadgeTick = self.lastBadgeTick,
    playerPaceLevel = self.playerPaceLevel,
    playerPaceBadges = self.playerPaceBadges,
    -- 2.5.0 (absorbed from 1.30): persistent trainer phone number and contact
    -- state. A number must survive a load without being regenerated, or the
    -- contact the player saved points at nobody.
    trainerClassId = self.trainerClassId,
    -- 7.6.2: keep save payload flat and serializer-safe. The host save encoder
    -- has stricter nested-table limits than ordinary Lua tables.
    happiness = tonumber(self.happiness) or Happiness.DEFAULT,
    happinessBaseline = tonumber(self.happinessBaseline) or Happiness.DEFAULT,
    mood = tostring(self.mood or "CONTENT"),
    emotionalTrait = type(self.emotionalTrait) == "string" and self.emotionalTrait or nil,
    rocketTempted = self.rocketTempted == true,
    rangerCalling = self.rangerCalling == true,
    darkTurn = self.darkTurn == true,
    slump = self.slump == true,
    winStreak = tonumber(self.winStreak) or 0,
    lossStreak = tonumber(self.lossStreak) or 0,
    phoneNumber = self.phoneNumber,
    phoneUnlocked = self.phoneUnlocked == true,
    phoneContact = self.phoneContact == true,
    phoneOfferDeclined = self.phoneOfferDeclined == true,
    phoneRelationshipThreshold = self.phoneRelationshipThreshold,
    lastCallTime = self.lastCallTime,
    nextCallTime = self.nextCallTime,
    callCooldown = self.callCooldown,
    storyEvolved = self.storyEvolved == true,
    teamChangedAt = self.teamChangedAt,
    trainedAt = self.trainedAt,
    campTicks = self.campTicks,
    campMap = self.campMap,
    campCooldown = self.campCooldown,
    counterTarget = self.counterTarget,
    counterPreparedFor = self.counterPreparedFor,
    gymTeamPreparedFor = self.gymTeamPreparedFor,
    lastPokemonCenter = self.lastPokemonCenter,
    appearanceSprite = self.appearanceSprite,
    confidence = self.confidence,
    encounterCooldown = self.encounterCooldown,
    trainingTicks = self.trainingTicks,
    ticks = self.ticks,
    newsPending = self.newsPending,
    lastBadgeEarned = self.lastBadgeEarned,
    lastResult = self.lastResult,
    rngState = self.rng.state,
    balls = tonumber(self.balls) or 0,
    inventory = Util.copy(self.inventory or {}),
    pcBoxes = Util.copy(self.pcBoxes or { { } }),
    repelTicks = self.repelTicks or 0,
    money = tonumber(self.money) or 0,
    -- 1.7.0
    champion = self.champion == true,
    leagueAttempts = self.leagueAttempts or 0,
    leagueCooldown = self.leagueCooldown or 0,
    rivalFightCooldown = self.rivalFightCooldown or 0,
    lastRivalFight = self.lastRivalFight,
    -- 1.11.0
    trainerBattleCooldown = self.trainerBattleCooldown or 0,
    -- 1.14.0
    tms = Util.copy(self.tms or {}),
    hms = Util.copy(self.hms or {}),
    hmUses = Util.copy(self.hmUses or {}),
    hmGoal = self.hmGoal,
    hmGoalForced = self.hmGoalForced == true,
    defeatedTrainers = Util.copy(self.defeatedTrainers or {}),
    visitedMaps = Util.copy(self.visitedMaps or {}),
    encounterHistory = Util.copy(self.encounterHistory or {}),
    -- 1.15.0
    dex = Util.copy(self.dex or {}),
    lastDexMilestone = self.lastDexMilestone or 0,
    huntTarget = self.huntTarget,
    huntMap = self.huntMap,
    rematchCooldown = self.rematchCooldown or 0,
    wonderTradeCooldown = self.wonderTradeCooldown or 0,
    aceSpecies = self.aceSpecies,
  }
end

function Rival:restore(saved)
  if type(saved) ~= "table" then return false end
  local function take(key, default)
    local v = saved[key]
    if v == nil then return default end
    return v
  end
  if type(saved.name) == "string" and saved.name ~= "" then
    self.name = saved.name
  elseif self.def and type(self.def.name) == "string" and self.def.name ~= "" then
    -- Pre-4.7.1 saves never serialized the display name. Keep their original
    -- authored name instead of unexpectedly renaming an existing character.
    self.name = self.def.name
  end
  if type(saved.personalityId) == "string" and saved.personalityId ~= "" then
    self.personalityId = saved.personalityId
    self.personality = self.ctx.personalities[self.personalityId]
      or self.personality
  end
  if type(saved.backgroundId) == "string" then
    self.backgroundId = saved.backgroundId
    self.background = Backgrounds.get(saved.backgroundId) or self.background
  end
  if type(saved.forcedTitle) == "string" then self.forcedTitle = saved.forcedTitle end
  if saved.rocketAdminPotential ~= nil then
    self.rocketAdminPotential = saved.rocketAdminPotential == true
  end
  self.backgroundApplied = saved.backgroundApplied == true
  self.backgroundDispositionApplied = saved.backgroundDispositionApplied == true
  self.state = STATE_SET[saved.state] and saved.state or "IDLE"
  self.objective = take("objective")
  self.travelReason = take("travelReason", self.stateReason or "Taking a break")
  self.map = take("map")
  self.x, self.y = take("x"), take("y")
  self.destination = take("destination")
  self.party = type(saved.party) == "table" and Util.copy(saved.party) or {}
  self.badges = type(saved.badges) == "table" and Util.copy(saved.badges) or {}
  self.defeatedLeaders = type(saved.defeatedLeaders) == "table"
    and Util.copy(saved.defeatedLeaders) or {}
  self.gymAttempts = type(saved.gymAttempts) == "table"
    and Util.copy(saved.gymAttempts) or {}
  self.gymCooldown = tonumber(take("gymCooldown", 0)) or 0
  self.playerWins = tonumber(take("playerWins", 0)) or 0
  self.playerLosses = tonumber(take("playerLosses", 0)) or 0
  self.lastPlayerBattle = take("lastPlayerBattle")
  self.opponentKnowledge = type(saved.opponentKnowledge) == "table"
    and Util.copy(saved.opponentKnowledge) or {}
  self.memory = Memory.new(saved.memory)
  -- A pre-1.33 save simply has no bonds key. Relationships.new(nil) yields an
  -- empty store, which reads as NEUTRAL toward everyone -- the correct
  -- migration: no history is invented for battles that happened before the
  -- system existed.
  self.bonds = Relationships.new(saved.bonds)
  -- A pre-1.34 save has no teamPlan key, so the identity is re-seeded from the
  -- rival's personality exactly as a new game would: no history is invented,
  -- and a rival that has been played for hours simply starts expressing the
  -- identity it always nominally had.
  self.teamPlan = TeamPlan.new(saved.teamPlan,
    self.personality and self.personality.teamPlan)
  -- A pre-1.35 save has no story key. The milestones it has genuinely earned
  -- are backfilled SILENTLY on the first check (see Rival:advanceStory), so a
  -- twenty-hour save records eight badges rather than announcing eight fresh
  -- achievements the moment it loads.
  self.story = Story.new(saved.story)
  -- A pre-1.38 save has no ledger. It starts empty rather than being
  -- back-filled from current holdings: the money it spent before this system
  -- existed was spent, and inventing a history for it would be a lie the
  -- debug overlay then repeats.
  self.ledger = Economy.newLedger(saved.ledger)
  -- A pre-1.39 save carries leagueAttempts but no record. The attempt count is
  -- carried across (it is real); the walls are not invented, and `qualified` is
  -- false -- a rival that was champion before this system existed keeps the
  -- title but must clear the Elite Four again to earn a fresh title shot, which
  -- is the same rule every rival plays under from here.
  self.league = League.newRecord(saved.league)
  -- A pre-2.1 save has no lifePath key: the rival is on the Gym Challenge,
  -- which is what it was actually doing. Eligibility is recomputed from the
  -- world seed rather than stored, so an existing save picks up its destiny
  -- the first time it is asked -- and gets the same answer every load.
  self.lifePath = LifePath.newRecord(saved.lifePath)
  -- Progress is rebuilt from the path's own metric list, so a save that
  -- changed career (or a build that renamed a metric) cannot carry orphan
  -- columns forward.
  self.career = Career.newProgress(LifePath.isPath(saved.lifePath and saved.lifePath.path)
    and saved.lifePath.path or LifePath.GYM_CHALLENGE, saved.career)
  self.lastBadgeTick = tonumber(saved.lastBadgeTick)
  -- Pacing survives a load. Without this the first tick after loading has no
  -- player reading, so the ceiling opened and a rival could take a free level
  -- every time the player reloaded.
  self.playerPaceLevel = tonumber(saved.playerPaceLevel)
  self.playerPaceBadges = tonumber(saved.playerPaceBadges)
  -- 7.6.2: accept the short-lived 7.6.0/7.6.1 nested format if a host
  -- managed to write one, but persist only the flat safe subset from now on.
  if type(saved.happinessState) == "table" then
    Happiness.restore(self, saved.happinessState)
  else
    Happiness.restore(self, {
      happiness=saved.happiness,
      happinessBaseline=saved.happinessBaseline,
      mood=saved.mood,
      emotionalTrait=saved.emotionalTrait,
      rocketTempted=saved.rocketTempted == true,
      rangerCalling=saved.rangerCalling == true,
      darkTurn=saved.darkTurn == true,
      slump=saved.slump == true,
      winStreak=saved.winStreak,
      lossStreak=saved.lossStreak,
    })
  end
  self.trainerClassId = saved.trainerClassId or self.trainerClassId or "TRAINER"
  self.trainerClass = TrainerClasses.get(self.trainerClassId)
  self.phoneNumber = saved.phoneNumber
  self.phoneUnlocked = saved.phoneUnlocked == true
  self.phoneContact = saved.phoneContact == true
  self.phoneOfferDeclined = saved.phoneOfferDeclined == true
  self.phoneRelationshipThreshold = tonumber(saved.phoneRelationshipThreshold)
  self.lastCallTime = tonumber(saved.lastCallTime)
  self.nextCallTime = tonumber(saved.nextCallTime)
  self.callCooldown = tonumber(saved.callCooldown)
  if self.league.attempts == 0 then
    self.league.attempts = math.max(0, math.floor(tonumber(saved.leagueAttempts) or 0))
  end
  self.storyEvolved = saved.storyEvolved == true
  self.teamChangedAt = tonumber(saved.teamChangedAt)
  self.trainedAt = tonumber(saved.trainedAt)
  self.campTicks = tonumber(saved.campTicks)
  self.campMap = saved.campMap
  self.campCooldown = tonumber(saved.campCooldown)
  self.counterTarget = take("counterTarget")
  self.counterPreparedFor = take("counterPreparedFor")
  self.gymTeamPreparedFor = take("gymTeamPreparedFor")
  self.lastPokemonCenter = take("lastPokemonCenter")
  self.appearanceSprite = take("appearanceSprite")
  self.confidence = tonumber(take("confidence", 1)) or 1
  self.encounterCooldown = tonumber(take("encounterCooldown", 0)) or 0
  self.trainingTicks = tonumber(take("trainingTicks", 0)) or 0
  self.ticks = tonumber(take("ticks", 0)) or 0
  self.newsPending = take("newsPending")
  self.lastBadgeEarned = take("lastBadgeEarned")
  self.lastResult = take("lastResult")
  self.balls = tonumber(take("balls", 0)) or 0
  self.inventory = type(saved.inventory) == "table" and Util.copy(saved.inventory) or {}
  self.pcBoxes = type(saved.pcBoxes) == "table" and Util.copy(saved.pcBoxes) or { {} }
  self.repelTicks = tonumber(take("repelTicks", 0)) or 0
  self:ensureInventory()
  self.money = tonumber(take("money", Rival.STARTING_MONEY)) or 0
  self.rng = Util.rng(tonumber(saved.rngState) or self.def.seed or 1)
  -- 1.7.0
  self.champion = saved.champion == true
  self.leagueAttempts = tonumber(take("leagueAttempts", 0)) or 0
  self.leagueCooldown = tonumber(take("leagueCooldown", 0)) or 0
  self.rivalFightCooldown = tonumber(take("rivalFightCooldown", 0)) or 0
  self.lastRivalFight = take("lastRivalFight")
  -- 1.11.0 (runtime-only: the duel target is rebuilt, never restored)
  self.rivalTarget = nil
  self.trainerBattleCooldown = tonumber(take("trainerBattleCooldown", 0)) or 0
  -- 1.14.0
  self.tms = type(saved.tms) == "table" and Util.copy(saved.tms) or {}
  self.hms = type(saved.hms) == "table" and Util.copy(saved.hms) or {}
  self.hmUses = type(saved.hmUses) == "table" and Util.copy(saved.hmUses) or {}
  self.hmGoal = take("hmGoal")
  self.hmGoalForced = saved.hmGoalForced == true
  self.hmNewsPending = {}
  self.defeatedTrainers = type(saved.defeatedTrainers) == "table"
    and Util.copy(saved.defeatedTrainers) or {}
  self.visitedMaps = type(saved.visitedMaps) == "table"
    and Util.copy(saved.visitedMaps) or {}
  self.encounterHistory = type(saved.encounterHistory) == "table"
    and Util.copy(saved.encounterHistory) or {}
  -- 1.15.0
  self.dex = type(saved.dex) == "table" and Util.copy(saved.dex) or {}
  self.lastDexMilestone = tonumber(take("lastDexMilestone", 0)) or 0
  self.huntTarget = take("huntTarget")
  self.huntMap = take("huntMap")
  self.rematchCooldown = tonumber(take("rematchCooldown", 0)) or 0
  self.wonderTradeCooldown = tonumber(take("wonderTradeCooldown", 0)) or 0
  self.aceSpecies = take("aceSpecies")
  self:refreshAce()
  self:syncHmProgress()
  -- runtime-only, always rebuilt
  self.route, self.routeIndex, self.path = nil, 1, nil
  if self.destination and self.map and self.ctx and self.ctx.graph
     and self.ctx.graph.route then
    local ok, route = pcall(function()
      return self:routeTo(self.destination)
    end)
    self.route = ok and route or nil
  end
  -- scrub any party slot naming a species this boot does not have (a mod was
  -- removed between saves); dropping the slot beats a battle that asserts
  local kept = {}
  for _, slot in ipairs(self.party) do
    if slot and slot.species and self:speciesDef(slot.species) then
      kept[#kept + 1] = slot
    end
  end
  self.party = kept
  self:refreshAce()
  return true
end

return Rival
