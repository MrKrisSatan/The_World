-- 6.7.0: proactive rival-vs-Rocket recovery wars.
-- A stolen Pokemon remains one asset. Rivals can pursue its current holder,
-- recruit friends, recover it, fail and form grudges, or ask the player for
-- help. Player quests are only created by onTalkOffer, never by update().
local req, mod = ...
local Util = req("src/Util")
local Relationships = req("src/Relationships")
local W = {}; W.__index = W

local function maxLevel(party)
  local n=1
  for _,m in ipairs(party or {}) do n=math.max(n,tonumber(m.level) or 1) end
  return n
end

function W.new(manager)
  return setmetatable({manager=manager, version=2, cases={}, history={}, nextPulse=0,
    alliances={}, betrayals={}, revenge={}, defenses={}, socialPulse=0},W)
end
function W:serialize()
  return {version=2,cases=Util.copy(self.cases),history=Util.copy(self.history),nextPulse=self.nextPulse,
    alliances=Util.copy(self.alliances),betrayals=Util.copy(self.betrayals),revenge=Util.copy(self.revenge),
    defenses=Util.copy(self.defenses),socialPulse=self.socialPulse}
end
function W:load(s)
  if type(s)~="table" then return end
  self.cases=Util.copy(s.cases or {}); self.history=Util.copy(s.history or {})
  self.nextPulse=tonumber(s.nextPulse) or 0
  self.alliances=Util.copy(s.alliances or {}); self.betrayals=Util.copy(s.betrayals or {})
  self.revenge=Util.copy(s.revenge or {}); self.defenses=Util.copy(s.defenses or {})
  self.socialPulse=tonumber(s.socialPulse) or 0
end
function W:tick()
  return tonumber(self.manager and self.manager.sim and self.manager.sim.tick)
    or tonumber(self.manager and self.manager.rocket and self.manager.rocket.tick) or 0
end
function W:rivalById(id)
  for _,r in ipairs(self.manager.rivals or {}) do if r.id==id then return r end end
end
function W:eligibleAsset(asset)
  return asset and (asset.status or "HELD")=="HELD" and asset.memberId and asset.originalOwnerId
end
function W:caseFor(asset)
  if not self:eligibleAsset(asset) then return nil end
  local c=self.cases[asset.id]
  if not c then
    c={assetId=asset.id,ownerId=asset.originalOwnerId,holderId=asset.memberId,status="TRACKING",
       createdTick=self:tick(),attempts=0,helpers={},playerAsked=false}
    self.cases[asset.id]=c
  else c.holderId=asset.memberId end
  return c
end
function W:chooseHelpers(owner)
  local helpers={}
  for _,r in ipairs(self.manager.rivals or {}) do
    if r~=owner and not r.rocketAffiliation and not r.retired and #(r.party or {})>0 then
      local ok=false
      pcall(function()
        local bond=r:relationshipTo(owner.id,self:tick())
        ok=Relationships.willCooperate(bond and bond.state or bond)
      end)
      if ok then helpers[#helpers+1]=r end
    end
  end
  table.sort(helpers,function(a,b) return tostring(a.id)<tostring(b.id) end)
  return helpers
end
function W:record(rival, typ, target, location)
  if rival and rival.rememberEvent then
    pcall(function() rival:rememberEvent({tick=self:tick(),type=typ,target=target,location=location}) end)
  end
end
function W:recover(asset, owner, holder, helpers, method)
  if not (asset and owner) then return false end
  local mon=Util.copy(asset.pokemon or {species=asset.species,level=asset.level})
  mon.aiRivalsProvenance=mon.aiRivalsProvenance or {}
  mon.aiRivalsProvenance.kind="ROCKET_STOLEN_RECOVERED"
  mon.aiRivalsProvenance.assetId=asset.id
  mon.aiRivalsProvenance.originalOwnerId=owner.id
  mon.aiRivalsProvenance.recoveredTick=self:tick()
  owner.party=owner.party or {}; owner.party[#owner.party+1]=mon
  asset.status="RECOVERED"; asset.recoveredBy=owner.id; asset.recoveredTick=self:tick(); asset.memberId=nil
  local c=self.cases[asset.id]; if c then c.status="RECOVERED"; c.recoveredTick=self:tick(); c.method=method end
  self:record(owner,"STOLEN_POKEMON_RECOVERED",asset.id,holder and holder.map or owner.map)
  for _,h in ipairs(helpers or {}) do
    self:record(h,"HELPED_RECOVER_POKEMON",asset.id,holder and holder.map)
    if owner.recordRelationship then pcall(function() owner:recordRelationship(h.id,"PROTECTED",{tick=self:tick()}) end) end
    if h.recordRelationship then pcall(function() h:recordRelationship(owner.id,"COOPERATED",{tick=self:tick()}) end) end
  end
  if holder then
    holder.stolenPokemon=math.max(0,(tonumber(holder.stolenPokemon) or 0)-1)
    pcall(function() self.manager.rocket:refreshTrainerParty(holder) end)
  end
  self.history[#self.history+1]={tick=self:tick(),assetId=asset.id,ownerId=owner.id,holderId=holder and holder.id,method=method or "RIVAL_RAID",result="RECOVERED"}
  while #self.history>80 do table.remove(self.history,1) end
  if self.manager.worldState then pcall(function()
    self.manager.worldState:addEvent("RIVAL_RECOVERY",owner.map,owner.name.." recovered "..Util.spaced(asset.species).." from Team Rocket.",{assetId=asset.id,ownerId=owner.id})
  end) end
  -- Complete an already-given player recovery quest. Never invent one here.
  for _,q in ipairs((self.manager.quests and self.manager.quests.offers) or {}) do
    if q.kind=="RECOVER_FROM_ROCKET" and q.assetId==asset.id and q.status=="ACTIVE" then
      q.status="COMPLETE"; q.completedTick=self:tick()
    end
  end
  return true
end
function W:attemptCase(asset,c)
  local rocket=self.manager.rocket; if not rocket then return end
  local owner=self:rivalById(c.ownerId); local holder=rocket:memberById(asset.memberId)
  if not owner or owner.rocketAffiliation or owner.retired or not holder then return end
  c.holderId=holder.id
  -- Pursuit is visible in the world: owner and a small number of friends head
  -- toward the holder instead of resolving entirely off-screen at once.
  if owner.map~=holder.map then
    owner.objective="RECOVER_STOLEN_POKEMON"; owner.stateReason="tracking stolen "..Util.spaced(asset.species)
    pcall(function() owner:setDestination(holder.map) end)
    local helpers=self:chooseHelpers(owner)
    for i=1,math.min(2,#helpers) do
      local h=helpers[i]; c.helpers[h.id]=true
      if h.map~=holder.map and not h.rocketAffiliation then
        h.objective="HELP_RECOVER_POKEMON"; h.stateReason="helping "..owner.name
        pcall(function() h:setDestination(holder.map) end)
      end
    end
    return
  end
  local helpers={}
  for id in pairs(c.helpers or {}) do local h=self:rivalById(id); if h and h.map==holder.map then helpers[#helpers+1]=h end end
  local rivalPower=maxLevel(owner.party)+#helpers*5+(tonumber(owner.badges) or 0)*2
  local rocketPower=(tonumber(holder.level) or 5)+(tonumber(holder.strength) or 1)*4
  local chance=math.max(.18,math.min(.88,.52+(rivalPower-rocketPower)*.018))
  c.attempts=(c.attempts or 0)+1; c.lastAttemptTick=self:tick()
  if self.manager.rocket.rng:chance(chance) then
    self:recover(asset,owner,holder,helpers,"RIVAL_RAID")
  else
    c.status="FAILED_RETRY"; c.failures=(c.failures or 0)+1
    self:record(owner,"FAILED_STOLEN_RECOVERY",asset.id,holder.map)
    owner.rocketConflict={memberId=holder.id,result="lost_recovery",tick=self:tick()}
    for _,h in ipairs(helpers) do
      self:record(h,"FAILED_RECOVERY_AID",asset.id,holder.map)
      if owner.recordRelationship then pcall(function() owner:recordRelationship(h.id,"COOPERATED",{tick=self:tick()}) end) end
    end
    holder.successes=(tonumber(holder.successes) or 0)+1
    self.history[#self.history+1]={tick=self:tick(),assetId=asset.id,ownerId=owner.id,holderId=holder.id,result="FAILED"}
  end
end

local function pairKey(a,b)
  a,b=tostring(a),tostring(b)
  if a>b then a,b=b,a end
  return a.."|"..b
end

function W:relationshipState(a,b)
  if not (a and b and a.relationshipTo) then return "NEUTRAL" end
  local ok,bond=pcall(function() return a:relationshipTo(b.id,self:tick()) end)
  if not ok then return "NEUTRAL" end
  return (type(bond)=="table" and bond.state) or bond or "NEUTRAL"
end

function W:pushHistory(row)
  row=row or {}; row.tick=row.tick or self:tick()
  self.history[#self.history+1]=row
  while #self.history>100 do table.remove(self.history,1) end
end

-- 6.9.0: mutual friends can become an explicit alliance. This is deliberately
-- derived from the existing relationship model rather than a second friendship
-- score. Faction betrayal can later break the same alliance.
function W:considerAlliance(a,b)
  if not (a and b and a.id and b.id) or a==b then return end
  local key=pairKey(a.id,b.id)
  if self.alliances[key] and self.alliances[key].active then return end
  if a.rocketAffiliation ~= b.rocketAffiliation and (a.rocketAffiliation or b.rocketAffiliation) then return end
  local sa,sb=self:relationshipState(a,b),self:relationshipState(b,a)
  if Relationships.willCooperate(sa) and Relationships.willCooperate(sb) then
    self.alliances[key]={a=a.id,b=b.id,active=true,formedTick=self:tick()}
    self:record(a,"RIVAL_ALLIANCE_FORMED",b.id,a.map)
    self:record(b,"RIVAL_ALLIANCE_FORMED",a.id,b.map)
    self:pushHistory({kind="ALLIANCE",a=a.id,b=b.id,result="FORMED"})
  end
end

-- Joining Rocket can turn an existing friendship/alliance into a remembered
-- betrayal. The relationship system owns the actual axis changes.
function W:considerBetrayal(a,b)
  if not (a and b and a.id and b.id) or a==b then return end
  if not (a.rocketAffiliation ~= b.rocketAffiliation and (a.rocketAffiliation or b.rocketAffiliation)) then return end
  local key=pairKey(a.id,b.id)
  if self.betrayals[key] then return end
  local alliance=self.alliances[key]
  local cooperative=Relationships.willCooperate(self:relationshipState(a,b))
    or Relationships.willCooperate(self:relationshipState(b,a))
  if not (cooperative or (alliance and alliance.active)) then return end
  self.betrayals[key]={a=a.id,b=b.id,tick=self:tick(),rocket=a.rocketAffiliation and a.id or b.id}
  if alliance then alliance.active=false; alliance.brokenTick=self:tick(); alliance.reason="ROCKET_BETRAYAL" end
  if a.recordRelationship then pcall(function() a:recordRelationship(b.id,"BETRAYED",{tick=self:tick()}) end) end
  if b.recordRelationship then pcall(function() b:recordRelationship(a.id,"BETRAYED",{tick=self:tick()}) end) end
  self:record(a,"RIVAL_BETRAYED",b.id,a.map); self:record(b,"RIVAL_BETRAYED",a.id,b.map)
  self:pushHistory({kind="BETRAYAL",a=a.id,b=b.id,result="ROCKET_DEFECTION"})
end

-- Hostile or betrayed rivals may actively travel after one another. The actual
-- battle is still resolved by the normal simulation when they meet, preserving
-- all existing battle, money and relationship rules.
function W:considerRevenge(a,b)
  if not (a and b and a.id and b.id) or a==b or a.retired or b.retired then return end
  local state=self:relationshipState(a,b)
  if state~="BETRAYED" and state~="NEMESIS" and state~="HOSTILE" then return end
  local key=tostring(a.id)..">"..tostring(b.id)
  local r=self.revenge[key]
  if r and self:tick()-(tonumber(r.lastTick) or 0)<160 then return end
  self.revenge[key]={hunter=a.id,target=b.id,lastTick=self:tick(),state=state}
  a.objective="REVENGE_RIVAL"; a.stateReason="hunting "..tostring(b.name or b.id)
  pcall(function() a:setDestination(b.map) end)
  self:record(a,"REVENGE_HUNT",b.id,b.map)
  self:pushHistory({kind="REVENGE",a=a.id,b=b.id,result="HUNT_STARTED",state=state})
end

-- A friend who learns about a recent Rocket clash can move to the threatened
-- rival and help. This is generation-neutral: it uses simulated map IDs and
-- existing Rocket members, not Red/Blue/Yellow/Gold-specific scripts.
function W:considerDefense(defender,target)
  if not (defender and target and defender.id and target.id) or defender==target then return end
  if defender.rocketAffiliation or target.rocketAffiliation or defender.retired then return end
  if not Relationships.willCooperate(self:relationshipState(defender,target)) then return end
  local conflict=target.rocketConflict
  if type(conflict)~="table" or self:tick()-(tonumber(conflict.tick) or -9999)>140 then return end
  local key=tostring(defender.id)..">"..tostring(target.id)
  local d=self.defenses[key]
  if d and self:tick()-(tonumber(d.tick) or 0)<140 then return end
  self.defenses[key]={defender=defender.id,target=target.id,memberId=conflict.memberId,tick=self:tick(),status="RESPONDING"}
  defender.objective="DEFEND_RIVAL_FROM_ROCKET"; defender.stateReason="defending "..tostring(target.name or target.id)
  pcall(function() defender:setDestination(target.map) end)
  self:record(defender,"RIVAL_DEFENSE_RESPONSE",target.id,target.map)
end

function W:resolveDefenses()
  local rocket=self.manager.rocket
  for _,d in pairs(self.defenses or {}) do
    if d.status=="RESPONDING" then
      local defender,target=self:rivalById(d.defender),self:rivalById(d.target)
      if defender and target and defender.map==target.map then
        local member=rocket and rocket:memberById(d.memberId)
        local allyPower=maxLevel(defender.party)+maxLevel(target.party)+(tonumber(defender.badges) or 0)+(tonumber(target.badges) or 0)
        local rocketPower=member and ((tonumber(member.level) or 5)+(tonumber(member.strength) or 1)*5) or 1
        local chance=math.max(.25,math.min(.92,.60+(allyPower-rocketPower)*.012))
        local won=(not member) or (rocket.rng and rocket.rng:chance(chance))
        d.status=won and "DEFENDED" or "FAILED"; d.resolvedTick=self:tick()
        if won then
          if defender.recordRelationship then pcall(function() defender:recordRelationship(target.id,"PROTECTED",{tick=self:tick()}) end) end
          if target.recordRelationship then pcall(function() target:recordRelationship(defender.id,"PROTECTED",{tick=self:tick()}) end) end
          self:record(defender,"DEFENDED_RIVAL_FROM_ROCKET",target.id,target.map)
          self:record(target,"RIVAL_DEFENDED_ME",defender.id,target.map)
          target.rocketConflict=nil
        else
          self:record(defender,"FAILED_TO_DEFEND_RIVAL",target.id,target.map)
          self:record(target,"ROCKET_AMBUSH_WITH_ALLY",defender.id,target.map)
        end
        self:pushHistory({kind="DEFENSE",a=defender.id,b=target.id,memberId=d.memberId,result=d.status})
      end
    end
  end
end

function W:updateSocialWars()
  local now=self:tick(); if now<(self.socialPulse or 0) then return end
  self.socialPulse=now+40
  local rivals=self.manager.rivals or {}
  for i=1,#rivals do
    for j=i+1,#rivals do
      local a,b=rivals[i],rivals[j]
      self:considerAlliance(a,b); self:considerBetrayal(a,b)
      self:considerRevenge(a,b); self:considerRevenge(b,a)
      self:considerDefense(a,b); self:considerDefense(b,a)
    end
  end
  self:resolveDefenses()
end

function W:update(dt,world)
  self:updateSocialWars()
  local now=self:tick(); if now<(self.nextPulse or 0) then return end
  self.nextPulse=now+20
  local rocket=self.manager.rocket; if not rocket then return end
  for _,asset in ipairs(rocket.stolen or {}) do
    if self:eligibleAsset(asset) then
      local c=self:caseFor(asset)
      if not c.lastAttemptTick or now-c.lastAttemptTick>=80 then self:attemptCase(asset,c) end
    end
  end
end
-- Dialogue preview for a rival whose Pokemon is still in Rocket hands.
function W:requestLine(rival)
  if not rival then return nil end
  local rocket=self.manager.rocket
  for _,asset in ipairs(rocket and rocket.stolen or {}) do
    if self:eligibleAsset(asset) and asset.originalOwnerId==rival.id then
      local c=self:caseFor(asset)
      if not c.playerAsked then
        return rival.name..": Team Rocket still has my "..Util.spaced(asset.species)..". Help me get it back before they sell it again!",asset,c
      end
    end
  end
end
-- This is the ONLY route from a proactive recovery case into the player's
-- quest log: called from the rival's actual talk interaction.
function W:onTalkOffer(rival)
  local line,asset,c=self:requestLine(rival); if not asset then return nil end
  c.playerAsked=true; c.playerAskedTick=self:tick()
  local q=self.manager.quests
  if q then
    for _,x in ipairs(q.offers or {}) do if x.assetId==asset.id and x.status~="FAILED" then return x end end
    return q:offerFromIssuer(rival,{kind="RECOVER_FROM_ROCKET",title="Recover "..Util.spaced(asset.species),
      description="Recover "..Util.spaced(asset.species).." from Team Rocket and return it to "..rival.name..".",
      dialogue=line,assetId=asset.id,species=asset.species,map=(self.manager.rocket:memberById(asset.memberId) or {}).map,
      rewardMoney=750,faction="community"})
  end
end
return W
