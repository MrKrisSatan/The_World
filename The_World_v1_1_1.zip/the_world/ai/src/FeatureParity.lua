-- 7.1.0: explicit four-game feature contract.
-- Shared systems must be available in Red, Blue, Yellow and Gold. Engine-level
-- differences are handled by adapters (Gen2Talk, gen2 battle constructors,
-- gen2 encounter tables/boxes) rather than by disabling gameplay systems.
local F = {}
F.games = { red=true, blue=true, yellow=true, gold=true }
F.features = {
  rivals=true, roaming=true, gyms=true, league=true, champion=true,
  phone=true, rivalgear=true, quests=true, mission_chains=true,
  team_rocket=true, rocket_uniform=true, rocket_balls=true,
  stolen_pokemon=true, double_agent=true, rangers=true, factions=true,
  rival_wars=true, relationships=true, memory=true, ecology=true,
  weather_fx=true, weather_research=true, wonder_trade=true,
  tournaments=true, achievements=true, double_battles=true,
}
function F.supports(game, feature)
  return F.games[tostring(game or ''):lower()] == true and F.features[feature] == true
end
function F.matrix()
  local out={}
  for game in pairs(F.games) do
    out[game]={}
    for feature,value in pairs(F.features) do out[game][feature]=value==true end
  end
  return out
end
return F
