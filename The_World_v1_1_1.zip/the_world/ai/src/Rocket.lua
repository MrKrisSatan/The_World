local req, mod = ...
local Util = req("src/Util")
local Happiness = req("src/Happiness")
local TrainerClasses = req("src/TrainerClasses")
local AgentCatching = req("src/AgentCatching")
local Rival = req("src/Rival")
local Pathfinder = req("src/Pathfinder")
local Data = req("data/rocket")
local Backgrounds = req("src/Backgrounds")
local RocketDialogue = req("data/rocket_dialogue")
local BoxFit = req("src/BoxFit")
local Rocket = {}
Rocket.__index = Rocket

local function clamp(v, a, b)
  v = tonumber(v) or a
  if v < a then return a end
  if v > b then return b end
  return v
end

local function mapPick(graph, candidates, rng)
  local pool = {}
  for _, id in ipairs(candidates or {}) do
    if graph and graph:has(id) then pool[#pool + 1] = id end
  end
  if #pool == 0 then return nil end
  return pool[rng:int(1, #pool)]
end

local function validSpecies(data, preferred)
  local p = data and (data.pokemon or data.gen2Pokemon)
  if type(p) ~= "table" then return preferred end
  if p[preferred] then return preferred end
  local aliases = {
    NIDORAN_M={"NIDORAN_M","NIDORAN♂","NIDORAN"},
    NIDORAN_F={"NIDORAN_F","NIDORAN♀","NIDORAN"},
    MEOWTH={"MEOWTH"}, HOUNDOUR={"HOUNDOUR"},
  }
  for _, id in ipairs(aliases[preferred] or {}) do if p[id] then return id end end
  return nil
end

local function strengthPartyLevel(member)
  return clamp((member.level or 5) + ((member.strength or 1) - 1) * 2, 5, 45)
end

-- ECOLOGY MISSION RESOLVER
-- Never carries a hard-coded "Weedle on Route 2" table. It reads the loaded
-- encounter data, which means every route and every legal species can become a
-- different Rocket job in Gen 1, Gen 2, or a conversion.
local function encounterSlots(data, mapId)
  local byMap = data and data.encounters and data.encounters[mapId]
  if byMap then return byMap.slots or byMap.grass or byMap end
  local gen2 = data and data.gen2Encounters
  local grass = gen2 and (gen2.grass or gen2.swarmGrass)
  local water = gen2 and gen2.water
  local row = grass and grass[mapId]
  if row then return row.slots or row end
  row = water and water[mapId]
  if row then return row.slots or row end
  return nil
end

local function ecologyTargets(data, graph)
  local rows = {}
  local seen = {}
  local maps = data and data.maps or {}
  local encounterMaps = {}
  if data and data.encounters then
    for mapId in pairs(data.encounters) do encounterMaps[#encounterMaps+1] = mapId end
  end
  local gen2 = data and data.gen2Encounters
  for _, kind in ipairs(gen2 and {gen2.grass, gen2.water, gen2.swarmGrass} or {}) do
    for mapId in pairs(kind or {}) do
      if not seen[mapId] then encounterMaps[#encounterMaps+1] = mapId; seen[mapId]=true end
    end
  end
  table.sort(encounterMaps)
  for _, mapId in ipairs(encounterMaps) do
    if not graph or graph:has(mapId) then
      local speciesSeen = {}
      for _, entry in ipairs(encounterSlots(data,mapId) or {}) do
        local species = type(entry) == "table" and (entry.species or entry.mon) or entry
        if type(species) == "string" and not speciesSeen[species] then
          speciesSeen[species]=true
          rows[#rows+1]={map=mapId,species=species}
        end
      end
    end
  end
  table.sort(rows, function(a,b)
    if a.map ~= b.map then return a.map < b.map end
    return a.species < b.species
  end)
  return rows
end

local function migrationNeighbours(graph, mapId, data)
  local out, fallback = {}, {}
  local seen={}
  for _, edge in ipairs(graph and graph:neighbours(mapId) or {}) do
    if edge.to and not seen[edge.to] then
      seen[edge.to]=true
      fallback[#fallback+1]=edge.to
      if encounterSlots(data, edge.to) then out[#out+1]=edge.to end
    end
  end
  if #out == 0 then out = fallback end
  table.sort(out)
  return out
end

function Rocket.new(manager, data, namePool)
  local seed = tonumber(manager:worldSeed()) or 1
  local self = setmetatable({
    manager = manager, data = data, namePool = namePool or {}, seed = seed, rng = Util.rng(seed + 7919),
    tick = 0, nextOp = 180, members = {}, leaders = {}, operations = {},
    incidents = {}, news = {}, quests = {}, seized = {}, recruitment = {}, stolen = {},
    ambushCooldown = 0, playerAmbushCooldown = 0, enabled = true,
    resources = 100, strategyTick = 0, territory = {}, bases = {}, leadership = nil, playerHeat = 0,
    stolenMarket = {}, stolenTradeCount = 0,
  }, Rocket)
  self:generate()
  return self
end

function Rocket:generate()
  local graph = self.manager.graph
  local start = graph and graph:has("ROCKET_HIDEOUT") and "ROCKET_HIDEOUT"
    or (graph and graph:has("CELADON_CITY") and "CELADON_CITY")
    or mapPick(graph, Data.locations, self.rng)
  self.home = start
  local leaderCount = self.rng:int(1, 3)
  for i = 1, leaderCount do
    local name = Data.leaderNames[self.rng:int(1, #Data.leaderNames)]
    self.leaders[i] = { id="rocket_leader_"..i, name=name, rank="Leader", ambition=self.rng:int(1,100), operationWins=0, operationLosses=0, map=start }
  end
  local doctrines = Data.doctrines or {"EXPANSIONIST","POACHER","RECRUITER","SCIENTIFIC","COVERT"}
  local doctrine = doctrines[self.rng:int(1, #doctrines)]
  local chief = self.leaders[1]
  self.leadership = {
    leaderId = chief and chief.id or "rocket_leader_1",
    leaderName = chief and chief.name or "Rocket Leader",
    doctrine = doctrine,
    aggression = self.rng:int(35, 90),
    secrecy = self.rng:int(25, 95),
    recruitment = self.rng:int(25, 95),
  }
  if start then
    self.bases[start] = { map=start, level=2, established=0, hidden=true, home=true }
    self.territory[start] = 10
  end
  local count = self.rng:int(7, 13)
  for i = 1, count do
    local gender = self.rng:chance(0.5) and "M" or "F"
    local pool = self.namePool and self.namePool[gender]
    local name = pool and pool[self.rng:int(1,#pool)] or (gender == "M" and "Rocket"..i or "Rocket"..i)
    local species = Data.starterPokemon[self.rng:int(1,#Data.starterPokemon)]
    species = validSpecies(self.data, species)
    local backgroundProfile = Backgrounds.forId(self.seed, "rocket_" .. i)
    local member = {
      id="rocket_"..i, name=name, gender=gender, rank="Grunt", role=Data.roles[self.rng:int(1,#Data.roles)],
      background=Data.backgrounds[self.rng:int(1,#Data.backgrounds)],
      backgroundId=backgroundProfile and backgroundProfile.id or nil,
      backgroundProfile=backgroundProfile,
      goal=Data.goals[self.rng:int(1,#Data.goals)],
      money=(backgroundProfile and tonumber(backgroundProfile.money)) or 300,
      inventory=Backgrounds.startingInventory(backgroundProfile),
      disposition={
        player=Backgrounds.disposition(backgroundProfile,"player"),
        rivals=Backgrounds.disposition(backgroundProfile,"rival"),
        rocket=Backgrounds.disposition(backgroundProfile,"rocket"),
      },
      strength=self.rng:int(1,5), loyalty=self.rng:int(35,95), ambition=self.rng:int(25,100),
      redemption=self.rng:int(1,100), map=start, destination=nil, route=nil, routeIndex=1,
      pokemon=species, level=5 + self.rng:int(0,4), successes=0, failures=0, promotions=0, demotions=0,
      currentOp=nil, missionTarget=nil, returningHome=false, travelClock=0, travelDelay=nil,
      recruitmentAttempts=0, stolenPokemon=0, active=true, alive=true, objective="ESTABLISH_BASE",
      balls=8+self.rng:int(0,6), catches=0, pc={},
      rngState=nil, trainerClass=nil,
    }
    TrainerClasses.assign(member,"ROCKET",(self.seed or 1)+i*131)
    self.members[#self.members+1] = member
  end
end

function Rocket:log(text, kind, meta)
  local row = { tick=self.tick, text=text, kind=kind or "rocket", meta=Util.copy(meta or {}) }
  self.news[#self.news+1] = row
  while #self.news > 40 do table.remove(self.news,1) end
  if kind == "major" or kind == "theft" or kind == "recruitment" or kind == "ecology" then
    local location = meta and meta.location
    local quest = { id="rocket_quest_"..tostring(self.tick).."_"..tostring(#self.quests+1), title=text, location=location, tick=self.tick, active=true }
    self.quests[#self.quests+1]=quest
    while #self.quests > 20 do table.remove(self.quests,1) end
    for _, rival in ipairs(self.manager.rivals or {}) do
      if rival and not rival.rocketAffiliation and rival.map then
        local target = location or self.home
        if target and self.manager.graph and self.manager.graph:has(target) then
          local route=self.manager.graph:route(rival.map,target)
          if route and #route <= 8 then
            rival.objective="INVESTIGATE_ROCKET"
            pcall(function() rival:setDestination(target) end)
          end
        end
      end
    end
  end
  local m = self.manager
  if m and m.addNews then pcall(function() m:addNews({ name="Team Rocket" }, { kind="rocket", text=text }) end) end
end

function Rocket:availableRivals()
  local out = {}
  for _, r in ipairs(self.manager.rivals or {}) do
    if r and not r.rocketAffiliation and #r.party > 0 and not r.retired then out[#out+1] = r end
  end
  return out
end


-- 5.0.8: the lines moved to data/rocket_dialogue.lua and became a cross
-- product of situation x rank x role. Built once, at load, rather than per
-- call: composing ~10,000 sentences inside dialogueFor would run on the frame
-- a player presses A.
local ROCKET_LINES = RocketDialogue.build()

-- How long after a battle a Rocket keeps talking about it. Ticks, and
-- deliberately finite: "you beat me once" is interesting for a while and
-- becomes a rival who never moved on.
Rocket.OUTCOME_MEMORY_TICKS = 600

function Rocket:dialogueFor(member, context)
  context = context or "idle"
  if context == "talk" then
    -- What just happened between this Rocket and the player outranks what
    -- they are doing, because it is the thing the player also remembers.
    -- Bounded by OUTCOME_MEMORY_TICKS and by the outcome being recorded at
    -- all -- a missing tick means "no information", not "just now" (§5).
    local outcome = member and member.lastOutcome
    local at = member and tonumber(member.lastOutcomeTick)
    local now = tonumber(self.tick) or 0
    if outcome and at and (now - at) <= Rocket.OUTCOME_MEMORY_TICKS
       and ROCKET_LINES[outcome] then
      context = outcome
    elseif member and member.returningHome then context = "returning"
    elseif member and member.destination then context = "travelling"
    else context = "idle" end
  end

  local byContext = ROCKET_LINES[context] or ROCKET_LINES.idle
  local rank = member and member.rank or "Grunt"
  local role = member and member.role or "default"
  local byRank = byContext[rank] or byContext.default or byContext.Grunt
  local pool = byRank
  if type(pool) == "table" and type(pool[1]) ~= "string" then
    pool = pool[role] or pool.default
  end
  if type(pool) ~= "table" or #pool == 0 then
    pool = ROCKET_LINES.idle and ROCKET_LINES.idle.Grunt
      and ROCKET_LINES.idle.Grunt.default
  end
  if type(pool) ~= "table" or #pool == 0 then
    return ((member and member.name) or "Rocket") .. ": ..."
  end

  local salt = tonumber(self.tick) or 0
  local idNum = tonumber(tostring(member and member.id or ""):match("(%d+)$")) or 1
  local index = ((salt + idNum * 7) % #pool) + 1
  local label = member and ((member.rank or "Grunt") .. " " .. (member.name or "Rocket"))
    or "Rocket Grunt"
  -- "Executive Marlowe:" is already 18 columns, so the label takes the whole
  -- first row and the sentence starts underneath it. Before 5.0.8 the label
  -- and a 44-character sentence were concatenated raw and the tail simply ran
  -- off the box.
  return BoxFit.label(label .. ":", pool[index])
end

-- Called from main.lua's battle.ended handler. Stored rather than derived
-- because nothing else in a member's state records who won -- successes and
-- failures also move on operations that never involved the player.
function Rocket:noteBattleOutcome(member, playerWon)
  if type(member) ~= "table" then return end
  member.lastOutcome = playerWon and "beaten" or "won"
  member.lastOutcomeTick = tonumber(self.tick) or 0
  if playerWon then
    self.playerHeat = clamp((tonumber(self.playerHeat) or 0) + 1, 0, 20)
  else
    self.playerHeat = clamp((tonumber(self.playerHeat) or 0) - 0.5, 0, 20)
  end
end

function Rocket:nextRouteMap(member)
  if not (member and member.route and member.routeIndex) then return nil end
  return member.route[member.routeIndex]
end

function Rocket:visibleExitTarget(member, nextMap)
  if not (member and nextMap and self.manager and self.manager.graph) then return nil end
  local edge = self.manager.graph:edgeBetween(member.map, nextMap)
  local overview
  pcall(function()
    if mod.world and mod.world.mapOverview then overview = mod.world:mapOverview() end
  end)
  local grid = Pathfinder.grid(overview)
  if not grid then return nil end

  if edge and edge.x ~= nil and edge.y ~= nil then
    local candidates = {
      { edge.x, edge.y + 1 }, { edge.x - 1, edge.y },
      { edge.x + 1, edge.y }, { edge.x, edge.y - 1 },
    }
    local best, bestD
    for _, c in ipairs(candidates) do
      if Pathfinder.walkable(grid, c[1], c[2]) then
        local d = math.abs((member.x or c[1]) - c[1]) + math.abs((member.y or c[2]) - c[2])
        if not bestD or d < bestD then best, bestD = c, d end
      end
    end
    if best then return best[1], best[2], grid end
  end

  local maps = self.data and (self.data.maps or self.data.gen2Maps)
  local def = maps and maps[member.map]
  local direction
  for dir, conn in pairs((def and def.connections) or {}) do
    local id = type(conn) == "table" and conn.map or conn
    if id == nextMap then direction = tostring(dir):lower() break end
  end
  if not direction then return nil end
  local candidates = {}
  if direction == "north" or direction == "up" then
    for x=1,grid.w-2 do candidates[#candidates+1]={x,1} end
  elseif direction == "south" or direction == "down" then
    for x=1,grid.w-2 do candidates[#candidates+1]={x,grid.h-2} end
  elseif direction == "west" or direction == "left" then
    for y=1,grid.h-2 do candidates[#candidates+1]={1,y} end
  elseif direction == "east" or direction == "right" then
    for y=1,grid.h-2 do candidates[#candidates+1]={grid.w-2,y} end
  end
  local best,bestD
  for _,c in ipairs(candidates) do
    if Pathfinder.walkable(grid,c[1],c[2]) then
      local dist=math.abs((member.x or c[1])-c[1])+math.abs((member.y or c[2])-c[2])
      if not bestD or dist<bestD then best,bestD=c,dist end
    end
  end
  if best then return best[1],best[2],grid end
  return nil
end

function Rocket:walkVisibleMember(member, world)
  if not (member and world and member.map == world.playerMap and self.spawned and self.spawned[member.id]) then
    return false
  end
  local nextMap = self:nextRouteMap(member)
  if not nextMap then return false end
  local tx, ty, grid = self:visibleExitTarget(member, nextMap)
  if not (tx and ty and grid and member.x and member.y) then return false end

  if member.x == tx and member.y == ty then
    self:removeLiveMember(member)
    member.map = nextMap
    member.x, member.y = nil, nil
    member.routeIndex = member.routeIndex + 1
    if member.map == member.destination then
      member.destination, member.route, member.routeIndex = nil, nil, 1
      member.objective = member.returningHome and "ESTABLISH_BASE" or "OPERATE"
    end
    return true
  end

  local blocked = {}
  if world.playerX and world.playerY then blocked[world.playerX .. "," .. world.playerY] = true end
  local path = Pathfinder.find(grid, member.x, member.y, tx, ty, { budget=220, blocked=blocked })
  local step = type(path)=="table" and path[1]
  if not step then return true end

  local handle
  pcall(function()
    if mod.world and mod.world.npc then
      handle = mod.world:npc(member.map, self.spawned[member.id])
    end
  end)
  local move = handle and (handle.setPosition or handle.teleport)
  if move then
    local facing = step.dir
    local ok, moved = pcall(move, handle, step.x, step.y, facing)
    if ok and moved ~= false then
      member.x, member.y = step.x, step.y
    end
  end
  return true
end

function Rocket:startMission(member, op, target)
  if not (member and op and target) then return false end
  -- Every mission begins at the Celadon hideout. Members that are still away
  -- must physically/strategically return before receiving a new assignment.
  if member.map ~= self.home then
    member.currentOp = nil
    member.missionTarget = nil
    member.returningHome = true
    return self:assignRoute(member, self.home)
  end
  member.currentOp = op.id
  member.missionTarget = target
  member.returningHome = false
  if op.target == "ECOLOGY" and self.pendingEcologyTarget
     and self.pendingEcologyTarget.map == target then
    member.ecologyTarget = Util.copy(self.pendingEcologyTarget)
    self.pendingEcologyTarget = nil
  else
    member.ecologyTarget = nil
  end
  if target == member.map then
    member.objective = "OPERATE"
    return true
  end
  return self:assignRoute(member, target)
end

function Rocket:routeStrategicValue(mapId)
  if not mapId then return 0 end
  local value = tonumber(self.territory[mapId]) or 0
  local ws = self.manager and self.manager.worldState
  if ws and ws.routeEcology then
    local row = ws:routeEcology(mapId)
    value = value + (tonumber(row.rocket) or 0) * 2
    value = value - (tonumber(row.ranger) or 0) * 2
    value = value + (tonumber(row.disturbance) or 0) * 0.5
  end
  return value
end

function Rocket:strategyWeight(op, member)
  local w = tonumber(op.weight) or 1
  local doctrine = self.leadership and self.leadership.doctrine or "EXPANSIONIST"
  if doctrine == "EXPANSIONIST" then
    if op.id == "HIDEOUT" or op.id == "SMUGGLE" or op.id == "SHAKE_DOWN" then w = w * 1.8 end
  elseif doctrine == "POACHER" then
    if op.target == "ECOLOGY" or op.id == "POKEMON_HEIST" then w = w * 1.9 end
  elseif doctrine == "RECRUITER" then
    if op.id == "RECRUIT" or op.id == "PROPAGANDA" then w = w * 2.1 end
  elseif doctrine == "SCIENTIFIC" then
    if op.id == "FOOD_SOURCE_EXPERIMENT" or op.id == "SILPH_RAID" then w = w * 2.0 end
  elseif doctrine == "COVERT" then
    if op.id == "SCOUT" or op.id == "SMUGGLE" or op.id == "RECRUIT" then w = w * 1.7 end
    if op.id == "SAFARI_SEIZURE" then w = w * 0.55 end
  end
  if (tonumber(self.resources) or 0) < 25 and (tonumber(op.danger) or 0) >= 4 then w = w * 0.35 end
  if member and member.rank == "Leader" and (op.id == "SAFARI_SEIZURE" or op.id == "SILPH_RAID") then w = w * 1.35 end
  local heat = tonumber(self.playerHeat) or 0
  if heat >= 6 then
    -- Rocket has noticed the player. Covert leadership scouts first; more
    -- aggressive organisations retaliate through trainer-facing operations.
    if op.id == "SCOUT" then w = w * (doctrine == "COVERT" and 2.0 or 1.35) end
    if op.id == "SHAKE_DOWN" or op.id == "PROPAGANDA" then w = w * 1.4 end
  end
  return math.max(0, math.floor(w * 100 + 0.5))
end

function Rocket:recordTerritory(mapId, amount, reason)
  if not mapId then return end
  self.territory[mapId] = clamp((tonumber(self.territory[mapId]) or 0) + (tonumber(amount) or 0), 0, 20)
  if self.manager and self.manager.worldState and self.manager.worldState.addEvent and math.abs(tonumber(amount) or 0) >= 2 then
    self.manager.worldState:addEvent("ROCKET_TERRITORY", mapId,
      "Team Rocket's influence changed in " .. tostring(mapId):gsub("_"," ") .. ".",
      { amount=amount, reason=reason })
  end
end

function Rocket:establishBase(mapId, member)
  if not mapId or mapId == self.home then return false end
  local existing = self.bases[mapId]
  if existing then
    existing.level = clamp((tonumber(existing.level) or 1) + 1, 1, 3)
    existing.lastExpanded = self.tick
  else
    self.bases[mapId] = { map=mapId, level=1, established=self.tick, hidden=true, home=false,
      founder=member and member.id or nil }
    self:log("Team Rocket established a hidden base in " .. tostring(mapId):gsub("_"," ") .. ".", "major", {location=mapId})
  end
  self:recordTerritory(mapId, 4, "base")
  return true
end

function Rocket:strategicPulse()
  self.strategyTick = (tonumber(self.strategyTick) or 0) + 1
  local rangerPressure = 0
  local ws = self.manager and self.manager.worldState
  if ws and ws.routes then
    for mapId, row in pairs(ws.routes) do
      rangerPressure = rangerPressure + (tonumber(row.ranger) or 0)
      if (tonumber(row.ranger) or 0) > (tonumber(row.rocket) or 0) + 4 then
        self:recordTerritory(mapId, -0.35, "ranger pressure")
      end
    end
  end
  self.resources = clamp((tonumber(self.resources) or 100) + 2 - rangerPressure * 0.015, 0, 250)
  self.playerHeat = math.max(0, (tonumber(self.playerHeat) or 0) * 0.985)
  for mapId, score in pairs(self.territory) do
    local floor = self.bases[mapId] and 2 or 0
    local nextScore = math.max(floor, (tonumber(score) or 0) * 0.995)
    if nextScore < 0.05 then self.territory[mapId] = nil else self.territory[mapId] = nextScore end
  end
  self:internalStolenMarketPulse()
end

function Rocket:chooseOperation(member)
  local weighted, total = {}, 0
  for _, op in ipairs(Data.operations) do
    local w = self:strategyWeight(op, member)
    if op.id == "RECRUIT" and #self:availableRivals() == 0 then w = 0 end
    if op.id == "SAFARI_SEIZURE" and self.seized.SAFARI_ZONE then w = 0 end
    if op.target == "ECOLOGY" and #ecologyTargets(self.data, self.manager.graph) == 0 then w = 0 end
    total = total + w
    if w > 0 then weighted[#weighted+1] = {op=op,total=total} end
  end
  if total <= 0 then return Data.operations[1] end
  local roll = self.rng:int(1,total)
  for _, row in ipairs(weighted) do if roll <= row.total then return row.op end end
  return weighted[#weighted].op
end

function Rocket:assignRoute(member, destination)
  if not destination or not self.manager.graph then return false end
  local route = self.manager.graph:route(member.map, destination)
  if not route or #route < 2 then return false end
  member.destination, member.route, member.routeIndex = destination, route, 2
  member.objective = "TRAVELLING"
  return true
end

function Rocket:advanceMember(member, world)
  if not member.destination or not member.route then return false end
  local nextMap = member.route[member.routeIndex]
  if not nextMap then
    member.destination, member.route, member.routeIndex = nil,nil,1
    return false
  end

  -- When the player can see this Rocket, the NPC must actually walk to the
  -- map exit. It is not allowed to disappear from the middle of the road and
  -- reappear on the next map.
  if not self:travelReady(member) then return false end

  if world and member.map == world.playerMap and self.spawned and self.spawned[member.id] then
    return self:walkVisibleMember(member, world)
  end

  -- Off-screen simulation still traverses the graph ONE EDGE AT A TIME, but
  -- now each edge requires a substantial travel interval. Rocket members no
  -- longer race from Celadon to Pallet in the first few moments of a save.
  member.map = nextMap
  member.x, member.y = nil, nil
  member.routeIndex = member.routeIndex + 1
  if member.map == member.destination then
    member.destination, member.route, member.routeIndex = nil,nil,1
    if member.returningHome then
      member.returningHome = false
      member.currentOp = nil
      member.missionTarget = nil
      member.objective = "ESTABLISH_BASE"
    else
      member.objective = "OPERATE"
    end
  end
  return true
end

function Rocket:chooseEcologyTarget(op)
  local graph, data = self.manager.graph, self.data
  local rows = ecologyTargets(data, graph)
  if #rows == 0 then return nil end
  self.ecologyMissionCursor = (tonumber(self.ecologyMissionCursor) or 0) + 1
  local row = rows[((self.ecologyMissionCursor - 1) % #rows) + 1]
  local memberId = tostring(op.id) .. ":" .. tostring(self.ecologyMissionCursor)
  local foodSources = Data.foodSources or {"berries", "wild honey", "fallen fruit"}
  local food = foodSources[(self.rng:int(1,#foodSources))]
  return {
    map=row.map, species=row.species, foodSource=food,
    cursor=self.ecologyMissionCursor, key=memberId,
  }
end

function Rocket:findTargetMap(op)
  local graph = self.manager.graph
  if op.target == "ECOLOGY" then
    local target = self:chooseEcologyTarget(op)
    if target then
      -- The map remains the routing target. The species/food is carried beside
      -- it because older saves and the route walker expect a string map id.
      self.pendingEcologyTarget = target
      return target.map
    end
  end
  if op.target == "SAFARI" and graph and graph:has("SAFARI_ZONE") then return "SAFARI_ZONE" end
  if op.target == "SILPH" and graph and graph:has("SILPH_CO") then return "SILPH_CO" end
  return mapPick(graph, Data.locations, self.rng) or self.home
end

function Rocket:attemptRecruit(member)
  local rivals = self:availableRivals()
  if #rivals == 0 then return false end
  local rival = rivals[self.rng:int(1,#rivals)]
  member.recruitmentAttempts = member.recruitmentAttempts + 1
  -- 7.2.0 Crusaders are absolutely incorruptible. Backgrounds, bonds,
  -- leadership doctrine and lucky rolls cannot override this veto.
  if rival.personalityId == "CRUSADER"
     or (rival.personality and rival.personality.incorruptibleRocket == true) then
    self.recruitment[#self.recruitment+1] = {
      rivalId=rival.id, memberId=member.id, success=false,
      incorruptible=true, tick=self.tick
    }
    self:log(rival.name .. " rejected Team Rocket on principle.", "recruitment",
      { rivalId=rival.id, memberId=member.id, incorruptible=true })
    return false
  end
  local pressure = (member.loyalty + member.ambition + member.strength * 8) / 220
  local rivalPressure = 0.15
  if rival.lifePath and rival.lifePath.decision then rivalPressure = rivalPressure + 0.15 end
  local bond = 0
  if rival.bondWith then pcall(function() local b=rival:bondWith(member.id); bond=tonumber(b and b.affection) or 0 end) end
  local backgroundRocket = rival.backgroundDisposition
    and tonumber(rival:backgroundDisposition("rocket")) or 0
  local specialPenalty = rival.rocketAdminPotential and 0.08 or 0
  local memberBackground = member.disposition and tonumber(member.disposition.rocket) or 0
  local chance = clamp((0.22 + pressure * 0.35 + rivalPressure
    + backgroundRocket * 0.18 + memberBackground * 0.10
    - math.max(0,bond)/300 + specialPenalty)
    * Happiness.rocketRecruitMultiplier(rival),
    0.02, 0.90)
  local success = member.rng and Util.rng(member.rng):chance(chance) or self.rng:chance(chance)
  if success then
    local rocketRank = rival.rocketAdminPotential and "Admin" or "Recruit"
    rival.rocketAffiliation = {
      memberId=member.id, joinedTick=self.tick, rank=rocketRank,
      specialAdmin = rival.rocketAdminPotential == true,
    }
    rival.objective = "ROCKET"
    rival:setState("IDLE", "joined Team Rocket")
    self.recruitment[#self.recruitment+1] = { rivalId=rival.id, memberId=member.id, success=true, tick=self.tick }
    self:log(rival.name .. " was recruited by Team Rocket.", "recruitment", { rivalId=rival.id, memberId=member.id })
  else
    self.recruitment[#self.recruitment+1] = { rivalId=rival.id, memberId=member.id, success=false, tick=self.tick }
    self:log(member.name .. " failed to recruit a rival.", "recruitment", { rivalId=rival.id, memberId=member.id })
  end
  return success
end


function Rocket:attemptRivalResistance(member)
  local rivals={}
  for _, rival in ipairs(self.manager.rivals or {}) do
    if rival and not rival.rocketAffiliation and rival.map==member.map and #(rival.party or {})>0 then
      rivals[#rivals+1]=rival
    end
  end
  if #rivals==0 then return nil end
  local rival=rivals[self.rng:int(1,#rivals)]
  local rivalLevel=0
  for _,slot in ipairs(rival.party or {}) do rivalLevel=math.max(rivalLevel,tonumber(slot.level) or 1) end
  local rocketPower=strengthPartyLevel(member)+member.strength*2
  local rivalPower=rivalLevel+(rival.personality and tonumber(rival.personality.gymConfidence) or 0)*4
  local won=self.rng:chance(clamp(0.45+(rocketPower-rivalPower)*0.018,0.12,0.88))
  if won then
    member.successes=member.successes+1
    rival.rocketConflict={memberId=member.id,result="lost",tick=self.tick}
    pcall(function() Happiness.noteTrainerBattle(rival,false,member.name) end)
    self:log(rival.name .. " lost a skirmish with Team Rocket.","operation",{rivalId=rival.id,location=member.map})
  else
    member.failures=member.failures+1
    rival.rocketConflict={memberId=member.id,result="won",tick=self.tick}
    pcall(function() Happiness.noteTrainerBattle(rival,true,member.name) end)
    self:log(rival.name .. " fought back against Team Rocket.","recruitment",{rivalId=rival.id,location=member.map})
  end
  return won
end

function Rocket:attemptSteal(member)
  local rivals = self:availableRivals()
  if #rivals == 0 then return false end
  local rival = rivals[self.rng:int(1,#rivals)]
  local party = rival.party or {}
  if #party == 0 then return false end
  local slotIndex = self.rng:int(1,#party)
  local slot = party[slotIndex]
  local chance = clamp(0.08 + member.strength * 0.035 + (slot.level and math.max(0, 20-slot.level)*0.002 or 0), 0.05, 0.32)
  if self.rng:chance(chance) then
    table.remove(party, slotIndex)
    local species = slot.species or slot.speciesId or "Pokemon"
    pcall(function() Happiness.noteStolen(rival,slot,species,member.name) end)
    member.stolenPokemon = member.stolenPokemon + 1
    local assetId = "stolen_" .. tostring(self.tick) .. "_" .. tostring(#self.stolen + 1)
    local asset = { id=assetId, rivalId=rival.id, originalOwnerId=rival.id, originalOwnerName=rival.name,
      memberId=member.id, species=species, level=tonumber(slot.level) or 5, pokemon=Util.copy(slot),
      tick=self.tick, status="HELD", saleHistory={} }
    self.stolen[#self.stolen+1] = asset
    self:refreshTrainerParty(member)
    self:log("Team Rocket stole " .. tostring(species) .. " from " .. rival.name .. ".", "theft", { rivalId=rival.id, species=species, assetId=assetId })
    return true
  end
  self:log(member.name .. " failed a Pokémon theft attempt against " .. rival.name .. ".", "failure", { rivalId=rival.id })
  return false
end


-- 6.5.0: stolen Pokemon are persistent Rocket assets, not counters.  The
-- current holder may field them, transfer them to another member, or sell
-- them to the disguised player.  Ownership history stays on the asset.
function Rocket:stolenAssets(member, heldOnly)
  local out = {}
  local memberId = type(member) == "table" and member.id or member
  for _, asset in ipairs(self.stolen or {}) do
    if asset.memberId == memberId and (not heldOnly or (asset.status or "HELD") == "HELD") then
      out[#out+1] = asset
    end
  end
  table.sort(out, function(a,b)
    local at,bt=tonumber(a.tick) or 0,tonumber(b.tick) or 0
    if at~=bt then return at<bt end
    return tostring(a.id or "")<tostring(b.id or "")
  end)
  return out
end

function Rocket:stolenAssetById(id)
  for _, asset in ipairs(self.stolen or {}) do if asset.id == id then return asset end end
  return nil
end

function Rocket:stolenPrice(asset)
  if not asset then return nil end
  local level = clamp(tonumber(asset.level) or (asset.pokemon and asset.pokemon.level) or 5, 1, 100)
  local price = 500 + level * 90
  local defs = self.data and (self.data.pokemon or self.data.gen2Pokemon)
  local def = defs and defs[asset.species]
  local catchRate = def and tonumber(def.catchRate)
  if catchRate then price = price + math.max(0, 180 - catchRate) * 6 end
  return math.max(750, math.floor((price + 49) / 50) * 50)
end

function Rocket:transferStolen(asset, buyer, reason, price)
  if not asset or not buyer or (asset.status or "HELD") ~= "HELD" then return false end
  local old = asset.memberId
  asset.saleHistory = type(asset.saleHistory)=="table" and asset.saleHistory or {}
  asset.saleHistory[#asset.saleHistory+1] = { from=old, to=buyer.id, tick=self.tick,
    reason=reason or "rocket_trade", price=tonumber(price) or 0 }
  asset.memberId = buyer.id
  asset.lastTransferTick = self.tick
  self:refreshTrainerParty(self:memberById(old))
  self:refreshTrainerParty(buyer)
  self.stolenTradeCount = (tonumber(self.stolenTradeCount) or 0) + 1
  return true
end

function Rocket:internalStolenMarketPulse()
  if #(self.members or {}) < 2 then return false end
  -- Keep this occasional.  The market should create stories, not reshuffle
  -- every stolen Pokemon every minute.
  if not self.rng:chance(0.22) then return false end
  local sellers={}
  for _,m in ipairs(self.members or {}) do
    if m.active and #self:stolenAssets(m,true)>0 then sellers[#sellers+1]=m end
  end
  if #sellers==0 then return false end
  local seller=sellers[self.rng:int(1,#sellers)]
  local buyers={}
  for _,m in ipairs(self.members or {}) do
    if m.active and m.id~=seller.id and m.map==seller.map then buyers[#buyers+1]=m end
  end
  if #buyers==0 then return false end
  local buyer=buyers[self.rng:int(1,#buyers)]
  local assets=self:stolenAssets(seller,true)
  local asset=assets[self.rng:int(1,#assets)]
  local price=math.max(150,math.floor((self:stolenPrice(asset) or 750)*0.35))
  buyer.money=tonumber(buyer.money) or 300
  seller.money=tonumber(seller.money) or 300
  if buyer.money < price then return false end
  buyer.money=buyer.money-price; seller.money=seller.money+price
  if self:transferStolen(asset,buyer,"rocket_sale",price) then
    self:log(buyer.name .. " bought a stolen " .. tostring(asset.species) .. " from " .. seller.name .. ".",
      "theft", {species=asset.species,from=seller.id,to=buyer.id,price=price,assetId=asset.id})
    return true
  end
  return false
end

function Rocket:resolveEcologyOperation(member, op)
  local target = member and member.ecologyTarget
  if not target then return false end
  local eco
  pcall(function()
    if self.manager and self.manager.ecologyFor then eco = self.manager:ecologyFor() end
  end)
  if not eco then return false end

  local mapId, species = target.map, target.species
  local amount = ({
    SPECIES_SWEEP = 7,
    SPECIES_POACH = 5,
    DRIVE_MIGRATION = 4,
    FOOD_SOURCE_EXPERIMENT = 2,
    HABITAT_STRIP = 5,
    BREEDING_SITE = 9,
  })[op.id] or 3

  -- The mission is a series of ecological events rather than one magic
  -- percentage. This lets the existing abundance equation turn the result
  -- into fewer encounters, competition from other species, and recovery.
  local captures = math.max(2, math.floor(amount + member.strength))
  for _ = 1, captures do
    eco:record(mapId, species, "rivalCatch", self.tick)
  end

  local neighbours = migrationNeighbours(self.manager.graph, mapId, self.data)
  if op.id == "DRIVE_MIGRATION" or op.id == "SPECIES_SWEEP" or op.id == "HABITAT_STRIP" then
    if #neighbours > 0 then
      -- Seeded choice, not engine RNG. One save may push the Weedle north;
      -- another may push it into a cave, depending on the actual graph.
      local dest = eco.chooseMigrationDestination
        and eco:chooseMigrationDestination(species, mapId, neighbours, self.data,
          tostring(op.id) .. ":" .. tostring(self.tick) .. ":" .. tostring(member.id))
        or neighbours[((self.rng:int(1,#neighbours) - 1) % #neighbours) + 1]
      eco:recordMigration(species, mapId, dest, 4 + member.strength * 0.5, self.tick)
      target.migrationDestination = dest
    end
  end

  if op.id == "FOOD_SOURCE_EXPERIMENT" or op.id == "HABITAT_STRIP" then
    target.foodSource = target.foodSource or "berries"
    eco:recordAdaptation(mapId, species, target.foodSource, 4 + member.strength * 0.5, self.tick)
    target.adaptationTriggered = true
  end

  member.ecologyMissions = (member.ecologyMissions or 0) + 1
  member.ecologySuccesses = (member.ecologySuccesses or 0) + 1
  self.incidents[#self.incidents + 1] = {
    tick=self.tick, kind="ecology", operation=op.id, map=mapId,
    species=species, foodSource=target.foodSource,
    migrationDestination=target.migrationDestination,
    memberId=member.id,
  }
  while #self.incidents > 60 do table.remove(self.incidents,1) end

  local prettySpecies = Util.spaced and Util.spaced(species) or tostring(species)
  local prettyMap = Util.spaced and Util.spaced(mapId) or tostring(mapId)
  local detail
  if op.id == "SPECIES_SWEEP" then
    detail = "Team Rocket ordered a sweep to catch every " .. prettySpecies
      .. " they could find in " .. prettyMap .. "."
  elseif op.id == "DRIVE_MIGRATION" then
    detail = "Team Rocket deliberately drove the " .. prettySpecies
      .. " population out of " .. prettyMap .. "."
  elseif op.id == "FOOD_SOURCE_EXPERIMENT" then
    detail = "Team Rocket changed the food source available to " .. prettySpecies
      .. " in " .. prettyMap .. "."
  elseif op.id == "HABITAT_STRIP" then
    detail = "Team Rocket stripped part of the " .. prettyMap
      .. " habitat used by " .. prettySpecies .. "."
  elseif op.id == "BREEDING_SITE" then
    detail = "Team Rocket raided a " .. prettySpecies
      .. " breeding site in " .. prettyMap .. "."
  else
    detail = "Team Rocket poached the " .. prettySpecies .. " population in "
      .. prettyMap .. "."
  end
  if target.migrationDestination then
    detail = detail .. " Reports say the population is moving toward "
      .. tostring(target.migrationDestination) .. "."
  end
  if target.adaptationTriggered then
    detail = detail .. " A new food source is changing the local population."
  end
  self:log(detail, "ecology", { location=mapId, species=species,
    migrationDestination=target.migrationDestination, foodSource=target.foodSource })
  member.successes = member.successes + 1
  return true
end

function Rocket:resolveOperation(member, op)
  if op.target == "ECOLOGY" then
    local ok = self:resolveEcologyOperation(member, op)
    if ok and member.missionTarget then
      self:recordTerritory(member.missionTarget, 1.5, op.id)
      self.resources = clamp((tonumber(self.resources) or 0) + 4, 0, 250)
    end
    return ok
  end
  if op.id == "RECRUIT" then
    local recruited=self:attemptRecruit(member)
    if not recruited and self.rng:chance(0.35) then self:attemptRivalResistance(member) end
    return recruited
  end
  if op.id == "POKEMON_HEIST" then
    local result=self:attemptSteal(member)
    if not result and self.rng:chance(0.3) then self:attemptRivalResistance(member) end
    return result
  end
  if op.id == "SAFARI_SEIZURE" then
    local chance = clamp(0.18 + member.strength*0.08,0.1,0.6)
    if self.rng:chance(chance) then
      self.seized.SAFARI_ZONE = { tick=self.tick, leader=member.name }
      member.successes=member.successes+1
      self:log("TEAM ROCKET HAS SEIZED THE SAFARI ZONE.", "major", { location="SAFARI_ZONE" })
      return true
    end
  elseif op.id == "SILPH_RAID" then
    local chance = clamp(0.15 + member.strength*0.06,0.1,0.55)
    if self.rng:chance(chance) then
      member.successes=member.successes+1
      self.resources=clamp((tonumber(self.resources) or 0)+14,0,250)
      self:recordTerritory(member.missionTarget or "SILPH_CO", 2, "silph raid")
      self:log("Rocket raiders breached a Silph facility.","operation",{location="SILPH_CO"})
      return true
    end
  elseif op.id == "HIDEOUT" then
    local chance = clamp(0.38 + member.strength*0.06 + ((self.leadership and self.leadership.secrecy or 50)/500),0.25,0.85)
    if self.rng:chance(chance) then
      member.successes=member.successes+1
      self.resources=clamp((tonumber(self.resources) or 0)-8,0,250)
      self:establishBase(member.missionTarget, member)
      return true
    end
  else
    local chance = clamp(0.35 + member.strength*0.07,0.2,0.8)
    if self.rng:chance(chance) then member.successes=member.successes+1; self.resources=clamp((tonumber(self.resources) or 0)+3,0,250); self:recordTerritory(member.missionTarget, 0.75, op.id); return true end
  end
  member.failures=member.failures+1
  return false
end

function Rocket:promoteDemote(member)
  if member.successes >= 4 and member.rank == "Grunt" then member.rank="Executive"; member.promotions=member.promotions+1; self:log(member.name .. " was promoted to Executive.","promotion") end
  if member.failures >= 4 and member.rank == "Executive" and member.promotions > member.demotions then member.rank="Grunt"; member.demotions=member.demotions+1; self:log(member.name .. " was demoted to Grunt.","demotion") end
  if member.successes >= 8 and member.rank == "Executive" then member.rank="Leader"; member.promotions=member.promotions+1; self:log(member.name .. " rose to Rocket Leader.","promotion") end
end

function Rocket:checkRedemption(member)
  if member.rank == "Leader" or member.failures < 5 then return end
  local chance = clamp(0.005 + member.redemption/10000, 0.005, 0.015)
  if self.rng:chance(chance) then
    member.active=false
    member.objective="REDEEMED"
    local rivals = self.manager.rivals or {}
    local existing = false
    for _, r in ipairs(rivals) do if r and r.name == member.name then existing=true break end end
    if not existing and self.manager.rivalContext then
      local id="REDEEMED_"..tostring(member.id):upper()
      local def={ id=id, slot=#rivals+1, gender=member.gender, personality="CHALLENGER", trainerClass="AIR_REDEEMED_"..tostring(member.id):upper(), baseMoney=50, homeMaps={member.map or self.home} }
      self.manager.rivalContext.assignedNames=self.manager.rivalContext.assignedNames or {}
      self.manager.rivalContext.assignedNames[id]=member.name
      local ok, rival=pcall(function() return Rival.new(def,self.manager.rivalContext) end)
      if ok and rival then
        local species=validSpecies(self.data,member.pokemon) or member.pokemon
        if species then pcall(function() rival:addPokemon(species,clamp(strengthPartyLevel(member),5,45)) end) end
        rival.map=member.map or self.home
        rival.objective="REDEEMED_FROM_ROCKET"
        rival.rocketRedemption={from=member.id,tick=self.tick}
        rivals[#rivals+1]=rival
        self.manager.byId[id]=rival
        self.manager.rivalCount=#rivals
        self:log(member.name .. " abandoned Team Rocket and became a rival.", "redemption", {rivalId=id,location=rival.map})
      else
        self:log(member.name .. " abandoned Team Rocket, but could not enter the trainer circuit yet.", "redemption")
      end
    end
    self.recruitment[#self.recruitment+1]={memberId=member.id,success=true,redeemed=true,tick=self.tick}
  end
end


function Rocket:spriteFor(member)
  local sprites = self.data and (self.data.sprites or self.data.gen2Sprites)
  if type(sprites) ~= "table" then return nil end
  local ids={}
  for id, rec in pairs(sprites) do
    local text=tostring(id):upper()
    if text:find("ROCKET",1,true) and type(rec)=="table" then ids[#ids+1]=id end
  end
  table.sort(ids)
  if #ids > 0 then return ids[1] end
  -- Fall back to the existing sprite semantic resolver so a conversion without
  -- a dedicated Rocket sheet still gets visible NPCs.
  if self.manager.sprites and self.manager.sprites.semanticWalker then
    local ok, id=pcall(function() return self.manager.sprites:semanticWalker(member.gender=="F" and "female" or "male", self.data, nil) end)
    if ok then return id end
  end
  return nil
end


function Rocket:playerIsRocket()
  local m = self.manager
  -- Future-facing seam for the eventual player-joins-Rocket feature. Nothing
  -- in 5.0.4 sets these fields, so the player is always hostile to Rocket now.
  return m and (m.playerRocketAffiliation == true or m.playerFaction == "TEAM_ROCKET")
end

function Rocket:removeLiveMember(member)
  if not member then return end
  self.spawned = self.spawned or {}
  local npc = self.spawned[member.id]
  if npc then pcall(function() mod.world:removeNpc(npc) end) end
  self.spawned[member.id] = nil
end

function Rocket:onPlayerDefeated(member)
  if not member then return false end
  self:removeLiveMember(member)
  member.active = false
  member.defeatedUntil = self.tick + 60
  member.objective = "RECOVERING"
  member.destination, member.route, member.routeIndex = nil, nil, 1
  member.x, member.y = nil, nil
  return true
end

function Rocket:recoverDefeated()
  for _, member in ipairs(self.members or {}) do
    if not member.active and member.defeatedUntil
       and self.tick >= tonumber(member.defeatedUntil) then
      member.defeatedUntil = nil
      member.active = true
      member.map = self.home or member.map
      member.objective = "ESTABLISH_BASE"
      member.x, member.y = nil, nil
    end
  end
end

function Rocket:spawnFor(mapId, world)
  local manager = self.manager or self.M or self.owner
  if manager and manager.mapAllowsRuntimeActors
     and not manager:mapAllowsRuntimeActors(mapId) then
    return 0
  end
  local manager = self.manager or self.M or self.owner
  if manager and manager.runtimeObjectsSafe
     and not manager:runtimeObjectsSafe(mapId) then
    return 0
  end
  if not mapId then return 0 end
  if not self:playerStoryReady(world) then return 0 end
  self.spawned=self.spawned or {}
  local spawned=0
  for i, member in ipairs(self.members or {}) do
    if member.active and not member.defeatedUntil and member.map==mapId
       and not self.spawned[member.id] then
      local sprite=self:spriteFor(member)
      if sprite and mod.world and type(mod.world.spawnNpc)=="function" then
        local x=(world and world.playerX or 4)+((member.strength or 1)%3)+1
        local y=(world and world.playerY or 4)
        local obj={
          index=1400+i,
          name="AIR_ROCKET_"..member.id,
          sprite=sprite,
          x=x, y=y,
          movement="STAY", range="DOWN",
          -- Do not trap the player if a conversion has unusual collision at
          -- the guessed spawn cell; hostility is enforced by sight checks.
          solid=false, passable=true, through=true,
          text="AIR_ROCKET_TALK",
        }
        local ok,id=pcall(function() return mod.world:spawnNpc(mapId,obj) end)
        if ok and id then
          self.spawned[member.id]=id
          member.x,member.y=x,y
          spawned=spawned+1
        end
      end
    end
  end
  return spawned
end

function Rocket:despawnAll()
  for id,npc in pairs(self.spawned or {}) do pcall(function() mod.world:removeNpc(npc) end) end
  self.spawned={}
end

function Rocket:memberAtNpc(npcId, npcName)
  for _, member in ipairs(self.members or {}) do
    local wanted="AIR_ROCKET_"..member.id
    if npcId and tostring(npcId)==tostring(self.spawned and self.spawned[member.id]) then return member end
    if npcName and tostring(npcName)==wanted then return member end
  end
  return nil
end

function Rocket:maybeAmbushPlayer(world)
  if not world or not world.playerMap or self.playerAmbushCooldown > 0 then return false end
  if self:playerIsRocket() then return false end
  if self.manager.rivalBattleSequenceActive then return false end
  if world.playerMoving then return false end

  local px, py = tonumber(world.playerX), tonumber(world.playerY)
  if not (px and py) then return false end
  for _, member in ipairs(self.members or {}) do
    if member.active and not member.defeatedUntil and member.map == world.playerMap
       and self.spawned and self.spawned[member.id] and member.x and member.y then
      local dx, dy = math.abs(px - member.x), math.abs(py - member.y)
      -- Spawned Rocket NPCs use a five-tile trainer sight radius. This is
      -- deterministic: no RNG roll can make a visible grunt peaceful.
      if (dx == 0 and dy <= 5) or (dy == 0 and dx <= 5) or (dx + dy <= 3) then
        local cool = 18
        pcall(function()
          local f = self.manager and self.manager.factions
          if f and f.rocketAmbushMult then
            -- Higher Rocket rep -> longer cooldown between ambushes.
            cool = math.floor(18 * (f:rocketAmbushMult() or 1))
            cool = math.max(10, math.min(40, cool))
          end
        end)
        self.playerAmbushCooldown=cool
        self:log("Rocket attack on sight in " .. Util.spaced(world.playerMap) .. ".",
          "ambush", { memberId=member.id, location=world.playerMap })
        self.manager:rocketAmbush(member)
        return true
      end
    end
  end
  return false
end


function Rocket:playerBadgeCount()
  local m = self.manager
  local save = m and m.game and m.game.save
  local badges = 0
  pcall(function()
    if not save then return end
    if type(save.badges) == "number" then badges = save.badges end
    if type(save.badgeCount) == "number" then badges = math.max(badges, save.badgeCount) end
    if type(save.badges) == "table" then
      local n = 0
      for _, v in pairs(save.badges) do
        if v == true or (type(v) == "number" and v > 0) then n = n + 1 end
      end
      badges = math.max(badges, n)
    end
    if type(save.player) == "table" then
      local p = save.player
      if type(p.badges) == "number" then badges = math.max(badges, p.badges) end
      if type(p.badgeCount) == "number" then badges = math.max(badges, p.badgeCount) end
      if type(p.badges) == "table" then
        local n = 0
        for _, v in pairs(p.badges) do
          if v == true or (type(v) == "number" and v > 0) then n = n + 1 end
        end
        badges = math.max(badges, n)
      end
    end
  end)
  return badges
end

function Rocket:playerStoryReady(world)
  local m = self.manager
  if not (m and m.ready) then return false end
  if m.gauntletActive and m:gauntletActive() then return false end

  -- Team Rocket stays underground until the player has the Pewter Gym badge
  -- (first badge). They must not spill into the opening routes before that.
  local badges = self:playerBadgeCount()
  if badges < 1 then
    return false
  end

  local map = world and world.playerMap
  local earlyMap = map == "PALLET_TOWN" or map == "OAKS_LAB" or map == "REDS_HOUSE_1F"
    or map == "REDS_HOUSE_2F" or map == "BLUES_HOUSE"
  if earlyMap then
    return false
  end

  -- Warm-up after the badge gate so a freshly unlocked roster does not
  -- instantly flood the region the moment Brock falls.
  return (tonumber(self.tick) or 0) >= 120
end

function Rocket:travelInterval(member)
  -- Strategic Rocket movement is intentionally slower than rival movement.
  -- Members spread outward from Celadon one map edge at a time; higher ranks
  -- are only modestly faster. Delays are long so the organisation expands
  -- gradually across Kanto rather than appearing everywhere at once.
  local base = 48
  local rank = member and member.rank
  if rank == "Executive" then base = 40
  elseif rank == "Leader" then base = 36 end
  -- Early expansion (few badges) is slower still — they creep out of Celadon.
  local badges = self:playerBadgeCount()
  if badges <= 1 then base = base + 24
  elseif badges <= 3 then base = base + 12 end
  -- Player option: ROCKET SPREAD (slow / normal / aggressive).
  local pace = "normal"
  pcall(function()
    if mod and mod.options and mod.options.get then
      pace = tostring(mod.options:get("rocket_pace") or "normal")
    end
  end)
  if pace == "slow" then base = math.floor(base * 1.55)
  elseif pace == "aggressive" then base = math.max(18, math.floor(base * 0.55)) end
  local jitter = member and member.travelDelay
  if not jitter then
    jitter = base + self.rng:int(0, 14)
    if member then member.travelDelay = jitter end
  end
  return jitter
end

function Rocket:travelReady(member)
  if not member then return false end
  member.travelClock = (tonumber(member.travelClock) or 0) + 1
  local delay = self:travelInterval(member)
  if member.travelClock < delay then return false end
  member.travelClock = 0
  member.travelDelay = nil
  return true
end

function Rocket:update(dt, world)
  if not self.enabled then return false end
  self.tick=self.tick+1
  for _,m in ipairs(self.members or {}) do m.wonderTradeCooldown=math.max(0,(tonumber(m.wonderTradeCooldown) or 0)-1) end
  self:recoverDefeated()
  self.ambushCooldown=math.max(0,self.ambushCooldown-1)
  self.playerAmbushCooldown=math.max(0,self.playerAmbushCooldown-1)

  if self.tick % 60 == 0 then self:strategicPulse() end

  -- Opening protection: Rocket remains at the Celadon hideout while the
  -- player is still in the character-creation / first-starter phase.
  if not self:playerStoryReady(world) then
    return false
  end

  if self.tick < self.nextOp then
    self:maybeAmbushPlayer(world)
    return false
  end
  self.nextOp=self.tick+self.rng:int(45,90)
  local member=self.members[self.rng:int(1,#self.members)]
  if not member or not member.active then return false end
  -- 7.0.0: Rocket members can use the same Wonder Trader pool. Stolen assets
  -- are excluded: those stay in Rocket's provenance-aware black market.
  if member.map==self.home and (member.wonderTradeCooldown or 0)<=0 and self.rng:chance(0.025) then
    local ok,W=pcall(req,"src/WonderTrade")
    if ok and W and W.simulateAgent then
      local tr=W.simulateAgent(self.manager,member,self.rng,{faction="rocket",rocketMember=true,cooldown=180})
      if tr then
        self:refreshTrainerParty(member)
        self:log(member.name.." used the Wonder Trader and received "..tostring(tr.got)..".","trade",{memberId=member.id,species=tr.got})
      end
    end
  end

  if (tonumber(member.balls) or 0)<=0 and member.map==self.home then AgentCatching.restock(member,8) end
  if not member.destination and member.map~=self.home then
    local mon=AgentCatching.tryCatch(member,self.data,self.rng,{chance=0.16*TrainerClasses.catchMultiplier(member,self.data,nil,{}),defaultLevel=strengthPartyLevel(member),origin="rocket_poached"})
    if mon then
      self:refreshTrainerParty(member)
      self:log(member.name.." caught "..tostring(mon.species).." during a Rocket operation in "..tostring(member.map)..".","catch",{memberId=member.id,species=mon.species,map=member.map})
    end
  end
  if member.destination then
    self:advanceMember(member, world)
    self:maybeAmbushPlayer(world)
    return true
  end

  -- If an assigned mission has reached its target, resolve it there, then walk
  -- all the way back to the Celadon hideout before another mission is issued.
  if member.currentOp and member.missionTarget and member.map == member.missionTarget then
    local op
    for _, candidate in ipairs(Data.operations or {}) do
      if candidate.id == member.currentOp then op = candidate break end
    end
    op = op or self:chooseOperation(member)
    self:resolveOperation(member,op)
    self:promoteDemote(member)
    self:checkRedemption(member)
    if member.active then
      member.objective = op.id
      member.returningHome = true
      self:assignRoute(member, self.home)
    end
  elseif member.map ~= self.home then
    -- Save migration / interrupted old mission: do not issue a fresh job in
    -- the field. Return to base through the map graph first.
    member.returningHome = true
    self:assignRoute(member, self.home)
  else
    local op=self:chooseOperation(member)
    local target=self:findTargetMap(op)
    if target then self:startMission(member,op,target) end
  end
  self:maybeAmbushPlayer(world)
  return true
end


function Rocket:memberById(id)
  for _, m in ipairs(self.members or {}) do if m.id == id then return m end end
  return nil
end

function Rocket:classForMember(member)
  if not member then return nil end
  member.trainerClass = member.trainerClass or ("AIR_ROCKET_" .. tostring(member.id):upper())
  return member.trainerClass
end

function Rocket:memberForClass(class)
  local needle = tostring(class)
  for _, m in ipairs(self.members or {}) do
    if self:classForMember(m) == needle then return m end
  end
  return nil
end

function Rocket:partyForClass(class)
  local member = self:memberForClass(class)
  if not member then return nil end
  local party = {}
  local species = validSpecies(self.data, member.pokemon) or member.pokemon
  if species then party[#party+1] = { species=species, level=clamp(strengthPartyLevel(member),1,100) } end
  -- Rocket members actually use the Pokemon they stole. Keep their own lead
  -- Pokemon, then fill remaining party slots with currently held assets.
  for _,asset in ipairs(self:stolenAssets(member,true)) do
    if #party>=6 then break end
    local p=type(asset.pokemon)=="table" and Util.copy(asset.pokemon) or {}
    p.species=validSpecies(self.data,asset.species) or asset.species
    p.level=clamp(tonumber(p.level) or tonumber(asset.level) or strengthPartyLevel(member),1,100)
    if p.species then party[#party+1]=p end
  end
  return #party>0 and party or nil
end

function Rocket:refreshTrainerParty(member)
  if not member then return false end
  local class=self:classForMember(member)
  local party=self:partyForClass(class)
  if not party then return false end
  local trainers=self.data and self.data.trainers
  local def=trainers and trainers[class]
  if type(def)=="table" then
    def.parties={party}
    return true
  end
  return false
end

function Rocket:bindTrainerSlots()
  local gen2 = self.data and self.data.gen2Trainers
  local classes = gen2 and gen2.classes
  local trainers = self.data and self.data.trainers or {}
  for _, member in ipairs(self.members or {}) do
    local class = self:classForMember(member)
    local party = self:partyForClass(class) or { { species="RATTATA", level=5 } }
    local rec = (type(classes)=="table" and classes[class]) or trainers[class]
    if type(rec)=="table" then
      rec.name = member.name
      if type(rec.trainers)=="table" then
        local row = rec.trainers[1]
        if type(row)=="table" then
          row.name = member.name
          row.party = Util.copy(party)
        end
        member.gen2ClassIndex = tonumber(rec.index) or member.gen2ClassIndex
      else
        rec.parties = { Util.copy(party) }
      end
    end
  end
end

-- Backward-compatible name for callers in older save/plugin integrations.
-- It deliberately does NOT register content after load.
function Rocket:registerTrainers()
  return self:bindTrainerSlots()
end

function Rocket:serialize()
  return {
    version=3, seed=self.seed, tick=self.tick, nextOp=self.nextOp, home=self.home,
    members=Util.copy(self.members), leaders=Util.copy(self.leaders), incidents=Util.copy(self.incidents),
    news=Util.copy(self.news), seized=Util.copy(self.seized), recruitment=Util.copy(self.recruitment),
    stolen=Util.copy(self.stolen), quests=Util.copy(self.quests),
    ecologyMissionCursor=self.ecologyMissionCursor or 0,
    ambushCooldown=self.ambushCooldown, playerAmbushCooldown=self.playerAmbushCooldown,
    rngState=self.rng and self.rng.state or nil,
    resources=self.resources, strategyTick=self.strategyTick, territory=Util.copy(self.territory),
    bases=Util.copy(self.bases), leadership=Util.copy(self.leadership), playerHeat=self.playerHeat,
    stolenTradeCount=self.stolenTradeCount,
  }
end

function Rocket:load(saved)
  if type(saved) ~= "table" then return end
  self.seed=tonumber(saved.seed) or self.seed
  self.rng=Util.rng(self.seed + 7919)
  if saved.rngState then self.rng.state=tonumber(saved.rngState) or self.rng.state end
  self.tick=tonumber(saved.tick) or 0
  self.nextOp=tonumber(saved.nextOp) or 8
  self.home=saved.home or self.home
  if type(saved.members)=="table" and #saved.members>0 then self.members=saved.members end
  self.incidents = type(saved.incidents)=="table" and saved.incidents or self.incidents
  self.ecologyMissionCursor = tonumber(saved.ecologyMissionCursor) or 0
  for _, member in ipairs(self.members or {}) do
    if not member.backgroundProfile then
      member.backgroundProfile = Backgrounds.forId(self.seed, member.id)
      member.backgroundId = member.backgroundProfile and member.backgroundProfile.id or member.backgroundId
      member.money = tonumber(member.money) or (member.backgroundProfile and member.backgroundProfile.money) or 300
      member.inventory = type(member.inventory) == "table" and member.inventory
        or Backgrounds.startingInventory(member.backgroundProfile)
      member.disposition = member.disposition or {
        player=Backgrounds.disposition(member.backgroundProfile,"player"),
        rivals=Backgrounds.disposition(member.backgroundProfile,"rival"),
        rocket=Backgrounds.disposition(member.backgroundProfile,"rocket"),
      }
    end
  end
  if type(saved.leaders)=="table" then self.leaders=saved.leaders end
  self.incidents=saved.incidents or {}; self.news=saved.news or {}; self.seized=saved.seized or {}
  self.recruitment=saved.recruitment or {}; self.stolen=saved.stolen or {}; self.quests=saved.quests or {}
  self.stolenTradeCount=tonumber(saved.stolenTradeCount) or 0
  -- Upgrade pre-6.5 theft rows, which stored only species/memberId.
  for i,asset in ipairs(self.stolen) do
    asset.id=asset.id or ("legacy_stolen_"..tostring(i))
    asset.status=asset.status or "HELD"
    asset.originalOwnerId=asset.originalOwnerId or asset.rivalId
    asset.level=tonumber(asset.level) or 5
    asset.pokemon=type(asset.pokemon)=="table" and asset.pokemon or {species=asset.species,level=asset.level}
    asset.saleHistory=type(asset.saleHistory)=="table" and asset.saleHistory or {}
  end
  self.spawned={}
  self.ambushCooldown=tonumber(saved.ambushCooldown) or 0
  self.playerAmbushCooldown=tonumber(saved.playerAmbushCooldown) or 0
  self.resources=tonumber(saved.resources) or self.resources or 100
  self.strategyTick=tonumber(saved.strategyTick) or 0
  self.territory=type(saved.territory)=="table" and saved.territory or self.territory or {}
  self.bases=type(saved.bases)=="table" and saved.bases or self.bases or {}
  self.leadership=type(saved.leadership)=="table" and saved.leadership or self.leadership
  self.playerHeat=tonumber(saved.playerHeat) or 0
  if self.home and not self.bases[self.home] then self.bases[self.home]={map=self.home,level=2,established=0,hidden=true,home=true} end
  if self.home and self.territory[self.home] == nil then self.territory[self.home]=10 end
end

return Rocket
