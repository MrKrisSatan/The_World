local req, mod = ...

-- src/Scout.lua -- WHAT ONE TRAINER CAN HONESTLY TELL YOU ABOUT ANOTHER.
--
-- 4.5.0's Pokegear call lets the player ask a contact about a rival's team.
-- The answer must be knowledge, not omniscience: a rival reports what they
-- have actually seen across a battle table, and an ordinary trainer only ever
-- repeats what is public (badges, and where somebody was last seen).
--
-- Derived, never stored (house style): the level is recomputed from the bond
-- and the subject's live party every time the screen opens, so a report can
-- never go stale or contradict the world.
--
-- "No information" means NO information (lesson 5): a subject nobody has met
-- and whose whereabouts are unknown produces NONE and says so, rather than
-- defaulting to zero badges or an empty team the caller never saw.
--
-- Pure and duck-typed on purpose: every input is read through a guarded
-- accessor, so the module runs against fixtures in a headless suite and
-- against live Rival objects in game without a second code path.

local Scout = {}

Scout.LEVELS = { "NONE", "RUMOUR", "SEEN", "KNOWN" }
-- One shared table is fought at a tournament, a route ambush or a challenge;
-- three is when a caller has seen the whole rotation rather than a lead.
Scout.SEEN_BATTLES = 1
Scout.KNOWN_BATTLES = 3
Scout.MAX_ROWS = 8

local function isTable(v) return type(v) == "table" end

function Scout.fit(text, limit)
  text = tostring(text or "")
  limit = tonumber(limit) or 36
  if #text > limit then return text:sub(1, limit) end
  return text
end

-- 4.7.0: WHAT ONE RIVAL CALLS ANOTHER.
--
-- "Other rivals should use their titles when referring to them in
-- conversation." A caller who has heard of somebody uses the name Kanto uses;
-- one describing an unknown trainer uses their plain name, because that is all
-- there is to use.
--
-- The title arrives as `spokenName` on the subject rather than being computed
-- here: this module is pure and duck-typed, and reaching into Titles from it
-- would give it a dependency it does not need for a string the caller already
-- knows. main.lua stamps it (M:spokenNameOf) before the report is built.
local function nameOf(r, fallback)
  if isTable(r) and type(r.spokenName) == "string" and r.spokenName ~= "" then
    return r.spokenName
  end
  if isTable(r) and type(r.name) == "string" and r.name ~= "" then return r.name end
  return fallback or "THEY"
end

local function partyOf(r)
  if isTable(r) and isTable(r.party) then return r.party end
  return {}
end

-- nil, not 0: a badge count nobody can answer is unknown, and a caller must
-- not be able to report "no badges" for somebody they have never heard of.
local function badgesOf(r)
  if not (isTable(r) and type(r.badgeCount) == "function") then return nil end
  local ok, n = pcall(r.badgeCount, r)
  if ok and tonumber(n) then return math.floor(tonumber(n)) end
  return nil
end

local function areaOf(r)
  local map = isTable(r) and r.map or nil
  if type(map) ~= "string" or map == "" then return nil end
  return (map:gsub("_", " "))
end

local function levelOf(slot)
  local level = tonumber(isTable(slot) and slot.level)
  if level then return math.floor(level) end
  return nil
end

-- The head-to-head record the CALLER holds for the SUBJECT. Wins plus losses
-- is the number of times these two have actually stood across a battle from
-- one another, which is exactly the evidence a report may be built from.
function Scout.battlesBetween(caller, subject, tick)
  if not (isTable(caller) and isTable(subject)) then return 0 end
  if type(caller.bondWith) ~= "function" or not subject.id then return 0 end
  local ok, bond = pcall(caller.bondWith, caller, subject.id, tick)
  if not (ok and isTable(bond)) then return 0 end
  return (tonumber(bond.wins) or 0) + (tonumber(bond.losses) or 0)
end

function Scout.level(caller, subject, tick)
  if not isTable(subject) then return "NONE" end
  local battles = Scout.battlesBetween(caller, subject, tick)
  if battles >= Scout.KNOWN_BATTLES then return "KNOWN" end
  if battles >= Scout.SEEN_BATTLES then return "SEEN" end
  -- An ordinary trainer never reaches SEEN: they hold no bond record at all,
  -- so their best is the same public rumour anybody on the route repeats.
  if badgesOf(subject) or areaOf(subject) then return "RUMOUR" end
  return "NONE"
end

local function aceSlot(party)
  local best, bestLevel
  for _, slot in ipairs(party) do
    local level = levelOf(slot) or 0
    if not bestLevel or level > bestLevel then best, bestLevel = slot, level end
  end
  return best
end

local function speciesRow(slot)
  local species = isTable(slot) and slot.species
  if type(species) ~= "string" or species == "" then return nil end
  local level = levelOf(slot)
  return { label = species:sub(1, 10), right = level and ("L" .. level) or "L?" }
end

-- Report shape: { level, headline, line, rows }.
--   line     one short spoken answer for the call's text box (<= 36 chars,
--            which is the two 18-column lines the box actually shows)
--   rows     display-ready label/right pairs for the answer screen
function Scout.report(caller, subject, tick)
  local subjectName = nameOf(subject, "THAT TRAINER")
  local level = Scout.level(caller, subject, tick)
  local rows = {}
  local party = partyOf(subject)
  local badges, area = badgesOf(subject), areaOf(subject)

  if level == "KNOWN" then
    if #party == 0 then
      rows[#rows + 1] = { label = "TEAM", right = "NONE SEEN" }
    end
    for _, slot in ipairs(party) do
      local row = speciesRow(slot)
      if row and #rows < Scout.MAX_ROWS then rows[#rows + 1] = row end
    end
  elseif level == "SEEN" then
    local lead, ace = speciesRow(party[1]), speciesRow(aceSlot(party))
    if lead then
      lead.label = lead.label:sub(1, 10)
      rows[#rows + 1] = lead
    end
    if ace and (not lead or ace.label ~= lead.label) then rows[#rows + 1] = ace end
    if #party > 0 then
      rows[#rows + 1] = { label = "PARTY", right = tostring(#party) }
    elseif #rows == 0 then
      rows[#rows + 1] = { label = "TEAM", right = "NONE SEEN" }
    end
  end

  if level ~= "NONE" then
    if badges then rows[#rows + 1] = { label = "BADGES", right = tostring(badges) } end
    if area then rows[#rows + 1] = { label = "AROUND", right = area:sub(1, 9) } end
  end

  local headline, line
  if level == "KNOWN" then
    headline = "BATTLED OFTEN"
    line = "I know " .. subjectName .. "'s team well."
  elseif level == "SEEN" then
    headline = "BATTLED ONCE"
    line = "I've faced " .. subjectName .. " once or twice."
  elseif level == "RUMOUR" then
    headline = "ONLY RUMOURS"
    line = "I've only heard about " .. subjectName .. "."
  else
    headline = "NOTHING KNOWN"
    line = "I've never crossed paths with them."
  end

  if #rows == 0 then
    rows[#rows + 1] = { label = "NO NEWS", right = "" }
  end

  return {
    level = level,
    headline = headline,
    line = Scout.fit(line, 36),
    rows = rows,
    subject = subjectName,
  }
end

-- Ordinary trainers hold no bond record, so they answer at rumour level by
-- construction: this is the same public gossip trainerPhoneLine already tells.
function Scout.rumour(subject, tick)
  return Scout.report(nil, subject, tick)
end

return Scout
