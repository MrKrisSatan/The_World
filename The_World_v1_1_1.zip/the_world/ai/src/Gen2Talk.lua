local req, mod = ...

-- TALKING TO A MOD-SPAWNED NPC ON GOLD
--
-- The bug this exists for: on Gold you could walk up to a rival, press A, and
-- nothing happened.
--
-- Gen 1 and Gen 2 answer an A press through completely different doors.
--
--   Gen 1  every dynamic NPC carries a `text` id, and `map_scripts.talk`
--          binds a handler to that id.  main.lua registers TALK_TEXT beside
--          every loaded map and the rival's objDef carries it.  Works.
--
--   Gen 2  `World:interactBody` (src/world/gen2/World.lua) walks a fixed
--          ladder of arms: trainer, strength boulder, itemball, then
--          `npc.def.scriptKey`, then bg events, then tile events.  A
--          mod-spawned rival has NONE of those -- no trainer flag, no
--          itemball, and above all no `scriptKey`, because a scriptKey names
--          bytecode in the cart's own extracted script table and a mod cannot
--          mint one.  So the press finds the object, matches no arm, falls
--          through to the tile events and ends at `interacted(..., "none")`.
--
-- That is why `world.interacted` never rescued it either: Gold only emits the
-- `"npc"` kind from the scriptKey arm, so the event our Gen 1 fallback listens
-- for is never raised for exactly the objects we spawn.
--
-- The seam Gold does provide is deliberate and documented: before any built-in
-- arm, `interactBody` asks `Gen1Facade.talkToWrapper()`, which is a mod's
-- replacement of `OverworldController.talkTo`, calls it as `(world, npc)`, and
-- a TRUE return suppresses the built-in path entirely.  `talkTo` is a BACKED
-- member of the OverworldController facade (Guide-Preparing-Your-Mod-For-Gen-2),
-- so this needs no engine patch -- it is the supported route.
--
-- WHY A ROUTER AND NOT A SECOND PATCH.  `src/WonderTrade.lua` already replaced
-- `OW.talkTo` for its Gold attendant, chaining to whatever it found.  A second
-- independent replacement for rivals would make correctness depend on which
-- one installed first, and on each remembering to chain.  Two owners of one
-- mutable engine field is the ownership problem this project has been bitten
-- by before, so there is ONE DOOR: this module owns `OW.talkTo`, everything
-- else registers a handler with it.
--
-- Handlers are tried in ascending `priority`.  A handler returns true when it
-- consumed the press; anything else passes to the next one, and finally to
-- whatever non-ours `talkTo` we found when we installed (so a third mod that
-- got there first still runs).

local Gen2Talk = {}

local SENTINEL = "__aiRivalsTalkRouterV733"

Gen2Talk.handlers = {}
Gen2Talk.installed = false

-- Register a named handler.  Re-registering the same id replaces it, so a
-- reload cannot stack duplicates.
function Gen2Talk.register(id, fn, priority)
  if type(id) ~= "string" or type(fn) ~= "function" then
    return false, "id and function required"
  end
  Gen2Talk.unregister(id)
  table.insert(Gen2Talk.handlers, {
    id = id, fn = fn, priority = tonumber(priority) or 50,
  })
  table.sort(Gen2Talk.handlers, function(a, b)
    if a.priority == b.priority then return a.id < b.id end
    return a.priority < b.priority
  end)
  return true
end

function Gen2Talk.unregister(id)
  for i = #Gen2Talk.handlers, 1, -1 do
    if Gen2Talk.handlers[i].id == id then
      table.remove(Gen2Talk.handlers, i)
      return true
    end
  end
  return false
end

-- Resolve the stable key an NPC record is known by.  Gold's pooled objects and
-- Gen 1's runtime objects agree on `def.name`, which is what our spawner sets
-- (`AIR_<rival id>`), but the wrapper is defensive: a build that hands back a
-- bare def, or an object whose id lives elsewhere, must not raise inside an
-- interaction.
function Gen2Talk.npcKey(npc)
  if type(npc) ~= "table" then return nil end
  local key
  pcall(function()
    -- Runtime/pooled ids on Gold are engine-owned and may not match the token
    -- WorldAPI.spawnNpc returned. The object's mod-owned name is stable.
    key = (npc.def and (npc.def.name or npc.def.id))
      or npc.name
      or npc.id
  end)
  return key
end

-- Install the router onto the live OverworldController.  Safe to call more
-- than once: the sentinel makes it idempotent, which matters because
-- `game.ready` fires again on a New Game after the title screen.
function Gen2Talk.install()
  local ok, OW = pcall(require, "src.world.OverworldController")
  if not ok or type(OW) ~= "table" then return false, "no OverworldController" end
  if OW[SENTINEL] then
    Gen2Talk.installed = true
    return true
  end

  local previousInteract = OW.interact
  local previousTalkTo = OW.talkTo

  local function dispatch(world, npc)
    if not npc then return false end
    for _, handler in ipairs(Gen2Talk.handlers) do
      local consumed
      local okH, err = pcall(function()
        consumed = handler.fn(world, npc)
      end)
      if not okH then
        if mod and mod.log then
          mod.log:warn("talk handler %s failed: %s", tostring(handler.id),
                       tostring(err))
        end
      elseif consumed == true then
        return true
      end
    end
    return false
  end

  local function facingNpc(world)
    if type(world) ~= "table" then return nil end
    local p = world.player
    if not p then return nil end
    local delta = {
      up={0,-1}, down={0,1}, left={-1,0}, right={1,0},
    }
    local d = delta[p.facing]
    if not d then return nil end
    local x, y = (p.cellX or 0) + d[1], (p.cellY or 0) + d[2]

    -- Prefer the world's own lookup, but do not depend on its collision/
    -- passability policy: AI rivals are intentionally passable.
    if type(world.npcAt) == "function" then
      local okN, npc = pcall(world.npcAt, world, x, y)
      if okN and npc then return npc end
    end
    for _, npc in ipairs(world.npcs or {}) do
      local nx = npc.cellX or (npc.def and npc.def.x)
      local ny = npc.cellY or (npc.def and npc.def.y)
      local covers = false
      if type(npc.covers) == "function" then
        local okC, result = pcall(npc.covers, npc, x, y)
        covers = okC and result == true
      end
      if covers or (nx == x and ny == y) then return npc end
    end
    return nil
  end

  -- Early seam: catches passable runtime objects before Gold's fixed
  -- interaction ladder decides they have no ROM script.
  OW.interact = function(world)
    local npc = facingNpc(world)
    if npc and dispatch(world, npc) then return true end
    if type(previousInteract) == "function" then
      return previousInteract(world)
    end
    return false
  end

  -- Late seam: Gold calls this after it has resolved a facing object.
  -- Keeping both seams makes this resilient to engine revisions and lets
  -- Wonder Trader / Rocket / Rangers share the same one-owner router.
  OW.talkTo = function(world, npc)
    if dispatch(world, npc) then return true end
    if type(previousTalkTo) == "function" then
      return previousTalkTo(world, npc)
    end
    return false
  end

  OW[SENTINEL] = true
  Gen2Talk.installed = true
  return true
end

return Gen2Talk
