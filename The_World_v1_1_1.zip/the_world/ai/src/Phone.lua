local req, mod = ...
local Util = req("src/Util")
local Career = req("src/Career")
local LifePath = req("src/LifePath")

-- ABSORBED FROM 1.30 (in 2.5.0), rewired.
--
-- This file shipped in 1.30 and was dropped somewhere before 1.31.5; nothing
-- in 1.31-2.4 replaced it, so the phone had simply been missing for eight
-- releases. It comes back unchanged except for one coupling: it used to ask
-- the 1.30 `LifePaths` module for a call bias, and that module is superseded
-- (see docs) -- the bias now comes from the 2.2 career model, which is where
-- "what is this rival doing with itself" now lives.

-- How much more (or less) inclined this rival is to use the phone. A rival
-- that took a people-facing life calls more; one that went to ground calls
-- less. Returns 0 for a rival on the Gym Challenge, so absorbed 1.30
-- behaviour is unchanged for the ordinary case.
local PHONE_BIAS = {
  BREEDER = 1, RESEARCHER = 1, OAK_ASSISTANT = 2, CENTER_ASSISTANT = 2,
  MART_WORKER = 1, GHOST_RESEARCHER = 1, GYM_ASSISTANT = 1,
  EXPLORER = 0, TOWER_CARETAKER = -1, RETIRED = -1, TEAM_ROCKET = -2,
}

-- Careers whose rival files reports rather than chatter, and careers whose
-- rival would rather not be on anyone's contact list.
local WEATHER_REPORTERS = { RESEARCHER = true, OAK_ASSISTANT = true,
                            GHOST_RESEARCHER = true }
local DARK = { TEAM_ROCKET = true }

local LifePaths = {}

-- Shape preserved exactly as 1.30's consumers expect it -- a TABLE of
-- offerBias / weatherReportBias / dark, not a number. The first rewrite
-- returned a bare number and every call site that indexed it threw; the
-- absorbed code is unchanged, so it is the shim's job to match the contract
-- rather than the callers' job to adapt.
function LifePaths.phoneBias(rival)
  local path
  if type(rival) == "table" and type(rival.lifePathId) == "function" then
    local ok, id = pcall(rival.lifePathId, rival)
    if ok then path = id end
  end
  return {
    offerBias = PHONE_BIAS[path or ""] or 0,
    weatherReportBias = WEATHER_REPORTERS[path or ""] == true,
    dark = DARK[path or ""] == true,
  }
end

-- ------------------------------------------------------------------
-- Rival phone system (Gen 2 Pokegear + lightweight Gen 1 fallback)
-- ------------------------------------------------------------------
-- Every AI rival owns a persistent trainer phone number.  On Gold the
-- contact is registered into the engine's phone_contacts registry so it
-- appears in the Pokegear.  On Gen 1 there is no Pokegear; numbers still
-- exist for save compatibility and for any future UI, but calls are only
-- delivered through the news ticker / talk prompts.
--
-- Relationship gate: a rival offers their number once relationshipScore
-- reaches their personality threshold.  After acceptance, they may call
-- the player with prioritised reasons (challenge, weather, swarm, rare,
-- life path, team update, casual).  Calls are infrequent and remember
-- what was already reported.
-- ------------------------------------------------------------------

local Phone = {}
Phone.__index = Phone

-- Priority ranks (higher wins).  Casual must never hide a Rocket or
-- champion event.
local PRIORITY = {
  EMERGENCY         = 100,
  MAJOR_STORY       = 90,
  RARE_POKEMON      = 70,
  SWARM             = 60,
  WEATHER           = 50,
  CHALLENGE         = 40,
  LIFE_PATH         = 35,
  TEAM_UPDATE       = 25,
  LEAGUE_UPDATE     = 25,
  CASUAL            = 10,
}

-- Personality -> how many positive battles / interactions before offering.
local OFFER_THRESHOLD = {
  CHALLENGER  = 52,
  SPEEDRUNNER = 62,
  COLLECTOR   = 48,
  STRATEGIST  = 58,
}

-- Call cooldown ranges in simulation ticks (normal pace ~1.5s/tick).
local COOLDOWN = {
  min = 180,   -- ~4.5 minutes real time at normal pace
  max = 480,   -- ~12 minutes
  afterDecline = 120,
}

local function personalityId(rival)
  local p = rival and rival.personality
  if type(p) == "table" then return p.label or p.id end
  if type(p) == "string" then return p end
  return "CHALLENGER"
end

local function relationshipScore(rival)
  if rival and type(rival.bondWith) == "function" then
    local ok, bond = pcall(rival.bondWith, rival, "player")
    if ok and type(bond) == "table" then return tonumber(bond.affection) or 0 end
  end
  return 0
end

local function uniqueNumber(rival, used)
  -- Deterministic 3-digit trainer number from rival seed/id so it never
  -- changes across save/load.  Range 100-899 avoids common NPC blocks.
  local seed = tonumber(rival.def and rival.def.seed) or 0
  local h = 0
  local id = tostring(rival.id or "")
  for i = 1, #id do h = (h * 33 + id:byte(i)) % 100000 end
  local n = 100 + ((seed + h) % 800)
  while used[n] do
    n = 100 + ((n + 17) % 800)
  end
  used[n] = true
  return n
end

function Phone.new(manager)
  return setmetatable({
    manager = manager,
    contactsRegistered = {},
    pendingCall = nil,       -- { rivalId, kind, priority, text, meta }
    reported = {},           -- eventKey -> tick when reported to player
    tick = 0,
  }, Phone)
end

-- ------------------------------------------------------------------
-- Per-rival phone state
-- ------------------------------------------------------------------

function Phone:ensureRival(rival)
  if not rival then return end
  if rival.phoneNumber then return end
  local used = {}
  for _, r in ipairs(self.manager.rivals or {}) do
    if r.phoneNumber then used[r.phoneNumber] = true end
  end
  rival.phoneNumber = uniqueNumber(rival, used)
  rival.phoneUnlocked = rival.phoneUnlocked == true
  rival.phoneContact = rival.phoneContact == true
  rival.phoneOfferDeclined = rival.phoneOfferDeclined == true
  local storedThreshold = tonumber(rival.phoneRelationshipThreshold)
  if storedThreshold and storedThreshold < 20 then storedThreshold = nil end -- migrate pre-affection saves
  rival.phoneRelationshipThreshold = storedThreshold
    or OFFER_THRESHOLD[personalityId(rival)]
    or 52

  -- Similar to ordinary trainers, rivals should feel familiar before handing
  -- over a number. Unlike ordinary trainers, EVERY rival eventually offers.
  -- 1..4 player battles is their normal requirement, deterministically unique
  -- to the save/rival; six battles is the hard eventual guarantee.
  if not tonumber(rival.phoneBattleThreshold) then
    local base=tonumber(rival.def and rival.def.seed) or 0
    local h=0
    for i=1,#tostring(rival.id or "") do
      h=(h*31+tostring(rival.id):byte(i))%997
    end
    rival.phoneBattleThreshold=1+((base+h)%4)
  end
  rival.phoneBattleThreshold=math.max(1,math.min(4,math.floor(rival.phoneBattleThreshold)))
  rival.phoneOfferDeclinedAt=tonumber(rival.phoneOfferDeclinedAt) or 0
  rival.lastCallTime = tonumber(rival.lastCallTime) or 0
  rival.nextCallTime = tonumber(rival.nextCallTime) or 0
  rival.callCooldown = tonumber(rival.callCooldown) or 0
end

function Phone:bootstrapAll()
  for _, rival in ipairs(self.manager.rivals or {}) do
    self:ensureRival(rival)
  end
  self:registerContacts()
end

-- ------------------------------------------------------------------
-- Gen 2 phone_contacts registration
-- ------------------------------------------------------------------

function Phone:registerContacts()
  local M = self.manager
  if (M.generation or 1) ~= 2 then return end
  if not (mod.content and mod.content.phone_contacts
          and type(mod.content.phone_contacts.register) == "function") then
    return
  end
  -- 2.5.0: the two `goto continue` skips this loop shipped with in 1.30 are a
  -- Lua 5.2 extension. LuaJIT accepts them, so the file was fine on LOVE --
  -- but plain 5.1 does not, which means the whole module failed to parse in
  -- the headless test harness and could never be covered by a test. Rewritten
  -- as a plain guarded block: identical behaviour, one fewer host it depends
  -- on, and now testable.
  for i, rival in ipairs(M.rivals or {}) do
    self:ensureRival(rival)
    local contactId = "PHONE_AIR_" .. string.upper(tostring(rival.id))
    if rival.phoneContact and not self.contactsRegistered[contactId] then
    local ok = pcall(function()
      mod.content.phone_contacts:register(contactId, {
        index = 80 + i,
        number = rival.phoneNumber,
        class = rival.def and rival.def.trainerClass or ("OPP_AIR_" .. string.upper(rival.id)),
        caller = rival.name or rival.id,
        callee = rival.name or rival.id,
        map = rival.map,
      })
    end)
    if not ok then
      -- Record-semantics registries may already have the id from a prior
      -- boot; patch instead of register.
      pcall(function()
        mod.content.phone_contacts:patch(contactId, {
          number = rival.phoneNumber,
          caller = rival.name or rival.id,
          map = rival.map,
        })
      end)
    end
    self.contactsRegistered[contactId] = true
    end
  end
end

-- ------------------------------------------------------------------
-- Offer number
-- ------------------------------------------------------------------

function Phone:maybeOffer(rival)
  self:ensureRival(rival)
  if rival.phoneContact then return nil end
  local battles=(tonumber(rival.playerWins) or 0)+(tonumber(rival.playerLosses) or 0)
  local required=tonumber(rival.phoneBattleThreshold) or 2

  -- A declined rival may ask again after at least two more battles. This is
  -- necessary for the "every rival eventually" guarantee without pestering
  -- the player on the very next conversation.
  if rival.phoneOfferDeclined then
    if battles < (tonumber(rival.phoneOfferDeclinedAt) or battles)+2 then return nil end
    rival.phoneOfferDeclined=false
  end

  if battles < required then return nil end
  local threshold = rival.phoneRelationshipThreshold or 52
  local bias = LifePaths.phoneBias(rival)
  threshold = math.max(25, threshold - (bias.offerBias or 0) * 5)

  -- Normal route: familiarity + relationship. Eventual route: after six real
  -- player battles, the rival offers regardless of affection. Rivalry itself
  -- is a relationship, even when the two trainers do not particularly like
  -- one another.
  if relationshipScore(rival) < threshold and battles < 6 then return nil end
  rival.phoneUnlocked = true
  local lines = {
    CHALLENGER  = "Hey. We've traded enough blows. Want my number?",
    SPEEDRUNNER = "You're not slow. Take my number — call if you can keep up.",
    COLLECTOR   = "I've been finding rare stuff. Want my number so I can tip you off?",
    STRATEGIST  = "We've been through enough battles. Shall I give you my number?",
  }
  local pathLines = {
    BREEDER = "I raise Pokémon carefully. Want my number for tips?",
    RESEARCHER = "I've been logging field data. Take my number for reports.",
    ROCKET = "…Fine. Here's a number. Don't waste my time.",
    ACE = "You're a real opponent. Exchange numbers?",
    CHAMPION = "League bound. Stay in touch.",
  }
  local pid = personalityId(rival)
  local text = pathLines[rival.lifePath] or lines[pid]
    or ("Hey, we've been through a lot together. Want my number?")
  return {
    kind = "offer",
    rivalId = rival.id,
    text = text,
    options = { "Accept", "Decline" },
  }
end

function Phone:acceptOffer(rival)
  self:ensureRival(rival)
  rival.phoneContact = true
  rival.phoneUnlocked = true
  rival.phoneOfferDeclined = false
  self:registerContacts()
  local M = self.manager
  if M and type(M.syncRivalComms) == "function" then
    pcall(function() M:syncRivalComms() end)
  end
  local M = self.manager
  if M and M.addNews then
    M:addNews(rival, {
      kind = "phone",
      text = rival.name .. " shared their phone number ("
        .. tostring(rival.phoneNumber) .. ").",
    })
  end
  return true
end

function Phone:declineOffer(rival)
  self:ensureRival(rival)
  rival.phoneOfferDeclined = true
  rival.phoneOfferDeclinedAt =
    (tonumber(rival.playerWins) or 0)+(tonumber(rival.playerLosses) or 0)
  -- A refusal raises the social bar, but cannot permanently delete a rival
  -- from the eventual phone network.
  rival.phoneRelationshipThreshold =
    math.min(90,(rival.phoneRelationshipThreshold or 52)+6)
  rival.nextCallTime = (self.tick or 0) + COOLDOWN.afterDecline
  return true
end

-- ------------------------------------------------------------------
-- Call generation
-- ------------------------------------------------------------------

local function alreadyReported(self, key, tick, window)
  local prev = self.reported[key]
  if not prev then return false end
  return (tick - prev) < (window or 400)
end

local function markReported(self, key, tick)
  self.reported[key] = tick
end

local function lineFor(rival, kind, meta)
  local name = rival.name or "Rival"
  local pid = personalityId(rival)
  local map = meta and meta.map
  local species = meta and meta.species
  local weather = meta and meta.weather
  local badge = meta and meta.badge
  local rocketText = meta and meta.text

  local byKind = {
    ROCKET_ALERT = {
      CHALLENGER = "Rocket activity! " .. tostring(rocketText or "Something is happening out there."),
      STRATEGIST = "I heard a Rocket report: " .. tostring(rocketText or "Rocket is moving."),
      COLLECTOR = "Team Rocket is after Pokémon again. " .. tostring(rocketText or "Be careful."),
      SPEEDRUNNER = "Rocket alert. " .. tostring(rocketText or "Stay out of their way."),
    },
    CHALLENGE = {
      CHALLENGER  = "Stop dodging me. I've got a new team near "
        .. (map and Util.spaced(map) or "here") .. ".",
      SPEEDRUNNER = "I'm near " .. (map and Util.spaced(map) or "town")
        .. ". Think you can beat me now?",
      COLLECTOR   = "Come battle me on "
        .. (map and Util.spaced(map) or "the route")
        .. " — I want to test my latest catch.",
      STRATEGIST  = "I've adjusted my lineup. Meet me near "
        .. (map and Util.spaced(map) or "the center") .. " if you dare.",
    },
    WEATHER = {
      CHALLENGER  = "Weird sky out here — "
        .. (weather or "odd weather") .. " around "
        .. (map and Util.spaced(map) or "the route") .. ".",
      SPEEDRUNNER = "Weather's changing near "
        .. (map and Util.spaced(map) or "town")
        .. ". Doesn't slow me down.",
      COLLECTOR   = "There's " .. (weather or "strange weather")
        .. " around " .. (map and Util.spaced(map) or "the area")
        .. " — perfect for rare finds!",
      STRATEGIST  = "I've noted " .. (weather or "unusual weather")
        .. " near " .. (map and Util.spaced(map) or "the route") .. ".",
    },
    SWARM = {
      COLLECTOR   = "You won't believe it! There's a swarm of "
        .. (species and Util.spaced(species) or "Pokémon")
        .. " on " .. (map and Util.spaced(map) or "the route") .. "!",
      CHALLENGER  = "Swarm near " .. (map and Util.spaced(map) or "here")
        .. ". Good training fodder.",
      SPEEDRUNNER = "Swarm on " .. (map and Util.spaced(map) or "a route")
        .. ". Not wasting time on it.",
      STRATEGIST  = "A swarm of " .. (species and Util.spaced(species) or "Pokémon")
        .. " was reported near " .. (map and Util.spaced(map) or "town") .. ".",
    },
    RARE_POKEMON = {
      COLLECTOR   = "I saw a really unusual "
        .. (species and Util.spaced(species) or "Pokémon")
        .. " near " .. (map and Util.spaced(map) or "the area") .. "!",
      STRATEGIST  = "Rare sighting: "
        .. (species and Util.spaced(species) or "something odd")
        .. " around " .. (map and Util.spaced(map) or "here") .. ".",
      CHALLENGER  = "Something strong showed up near "
        .. (map and Util.spaced(map) or "town") .. ".",
      SPEEDRUNNER = "Rare mon on " .. (map and Util.spaced(map) or "route")
        .. ". Catch it if you care.",
    },
    TEAM_UPDATE = {
      CHALLENGER  = "My new ace finally evolved!",
      SPEEDRUNNER = "Team updated. Next badge is mine.",
      COLLECTOR   = "You need to see what I caught today!",
      STRATEGIST  = "I've refined the team composition again.",
    },
    LEAGUE_UPDATE = {
      CHALLENGER  = "I just earned another badge. Keep up.",
      SPEEDRUNNER = "Badge secured. Moving on.",
      COLLECTOR   = "Got a badge — and a few new catches on the way.",
      STRATEGIST  = "Gym strategy paid off. Badge secured.",
    },
    CASUAL = {
      CHALLENGER  = "Still training. Don't get soft.",
      SPEEDRUNNER = "No time to talk. Still running.",
      COLLECTOR   = "Hope you're finding cool Pokémon too!",
      STRATEGIST  = "Just checking in. Stay sharp.",
    },
  }
  local set = byKind[kind] or byKind.CASUAL
  return set[pid] or set.CHALLENGER or (name .. " called.")
end

function Phone:considerCall(rival, world)
  self:ensureRival(rival)
  if not rival.phoneContact then return nil end
  local tick = self.tick or 0
  if tick < (tonumber(rival.nextCallTime) or 0) then return nil end
  if (tonumber(rival.callCooldown) or 0) > 0 then
    rival.callCooldown = rival.callCooldown - 1
    return nil
  end

  local candidates = {}
  local compat = self.manager.compat
  -- Team Rocket alerts share the same call network as rival reports. A major
  -- Rocket incident is a world fact, so any rival with a phone can report it.
  if self.manager.rocket and type(self.manager.rocket.news) == "table" then
    local latest=self.manager.rocket.news[#self.manager.rocket.news]
    if latest and (latest.kind == "major" or latest.kind == "theft" or latest.kind == "recruitment")
       and (tick - (tonumber(latest.tick) or 0)) < 120 then
      local key="rocket:"..tostring(latest.tick)..":"..tostring(latest.text)
      if not alreadyReported(self,key,tick,500) then
        candidates[#candidates+1]={kind="ROCKET_ALERT",priority=95,meta={text=latest.text},eventKey=key}
      end
    end
  end
  local mapId = rival.map

  -- Weather report (Researchers prioritise these)
  local pathBias = LifePaths.phoneBias(rival)
  if compat and compat.weatherId then
    local wid = compat:weatherId()
    if wid and wid ~= "CLEAR" and wid ~= "SUNNY" then
      local key = "weather:" .. tostring(wid) .. ":" .. tostring(mapId)
      if not alreadyReported(self, key, tick, 300) then
        local pri = PRIORITY.WEATHER
        if pathBias.weatherReportBias then pri = pri + 15 end
        candidates[#candidates + 1] = {
          kind = "WEATHER",
          priority = pri,
          meta = { weather = wid, map = mapId },
          eventKey = key,
        }
      end
    end
  end

  -- Weather variants / rare forms as "rare" tips for collectors
  if compat and compat.weatherVariantCandidates then
    local variants = compat:weatherVariantCandidates(mapId)
    if type(variants) == "table" and #variants > 0 then
      local v = variants[1]
      local key = "variant:" .. tostring(v.species) .. ":" .. tostring(mapId)
      if not alreadyReported(self, key, tick, 400) then
        candidates[#candidates + 1] = {
          kind = "RARE_POKEMON",
          priority = PRIORITY.RARE_POKEMON,
          meta = { species = v.species, map = mapId },
          eventKey = key,
        }
      end
    end
  end

  -- Challenge
  local challengeChance = 0.35
  if personalityId(rival) == "CHALLENGER" then challengeChance = 0.55 end
  if personalityId(rival) == "SPEEDRUNNER" then challengeChance = 0.25 end
  if rival.rng and rival.rng:chance(challengeChance) then
    candidates[#candidates + 1] = {
      kind = "CHALLENGE",
      priority = PRIORITY.CHALLENGE,
      meta = { map = mapId },
    }
  end

  -- Team / league updates from recent news flags on the rival
  if rival.lastBadgeEarned and not alreadyReported(self,
      "badge:" .. rival.id .. ":" .. tostring(rival.lastBadgeEarned), tick, 500) then
    candidates[#candidates + 1] = {
      kind = "LEAGUE_UPDATE",
      priority = PRIORITY.LEAGUE_UPDATE,
      meta = { badge = rival.lastBadgeEarned },
      eventKey = "badge:" .. rival.id .. ":" .. tostring(rival.lastBadgeEarned),
    }
  end

  if rival.newsPending and rival.newsPending.kind == "evolved" then
    candidates[#candidates + 1] = {
      kind = "TEAM_UPDATE",
      priority = PRIORITY.TEAM_UPDATE,
      meta = {},
    }
  end

  -- Occasional casual
  if #candidates == 0 and rival.rng and rival.rng:chance(0.08) then
    candidates[#candidates + 1] = {
      kind = "CASUAL",
      priority = PRIORITY.CASUAL,
      meta = {},
    }
  end

  if #candidates == 0 then
    rival.nextCallTime = tick + rival.rng:int(COOLDOWN.min, COOLDOWN.max)
    return nil
  end

  table.sort(candidates, function(a, b)
    return (a.priority or 0) > (b.priority or 0)
  end)
  local best = candidates[1]
  if best.eventKey then markReported(self, best.eventKey, tick) end

  local text = lineFor(rival, best.kind, best.meta)
  rival.lastCallTime = tick
  rival.nextCallTime = tick + rival.rng:int(COOLDOWN.min, COOLDOWN.max)
  rival.callCooldown = 40

  return {
    rivalId = rival.id,
    kind = best.kind,
    priority = best.priority,
    text = text,
    meta = best.meta or {},
  }
end

-- ------------------------------------------------------------------
-- Tick: offer checks + outbound calls
-- ------------------------------------------------------------------

function Phone:update(dt, rivals, world)
  self.tick = (self.tick or 0) + 1
  if self.pendingCall then return end

  -- One offer or one call attempt per update, budgeted.
  for _, rival in ipairs(rivals or {}) do
    self:ensureRival(rival)
    if not rival.phoneContact and not rival.phoneOfferDeclined then
      local offer = self:maybeOffer(rival)
      if offer then
        self.pendingCall = offer
        return
      end
    end
  end

  -- Outbound calls from contacts only, round-robin by tick.
  local n = #(rivals or {})
  if n == 0 then return end
  local start = (self.tick % n) + 1
  for i = 0, n - 1 do
    local rival = rivals[((start + i - 1) % n) + 1]
    if rival and rival.phoneContact then
      local call = self:considerCall(rival, world)
      if call then
        self.pendingCall = call
        local M = self.manager
        if M and M.addNews then
          M:addNews(rival, {
            kind = "phone",
            text = (rival.name or "Rival") .. " called: " .. call.text,
          })
        end
        return
      end
    end
  end
end

function Phone:consumePending()
  local p = self.pendingCall
  self.pendingCall = nil
  return p
end

-- ------------------------------------------------------------------
-- Serialization helpers for Rival
-- ------------------------------------------------------------------

function Phone.fieldsFromRival(rival)
  return {
    phoneNumber = rival.phoneNumber,
    phoneUnlocked = rival.phoneUnlocked == true,
    phoneContact = rival.phoneContact == true,
    phoneOfferDeclined = rival.phoneOfferDeclined == true,
    phoneRelationshipThreshold = rival.phoneRelationshipThreshold,
    lastCallTime = rival.lastCallTime,
    nextCallTime = rival.nextCallTime,
    callCooldown = rival.callCooldown,
  }
end

function Phone.applyToRival(rival, saved)
  if type(saved) ~= "table" then return end
  if saved.phoneNumber then rival.phoneNumber = tonumber(saved.phoneNumber) end
  rival.phoneUnlocked = saved.phoneUnlocked == true
  rival.phoneContact = saved.phoneContact == true
  rival.phoneOfferDeclined = saved.phoneOfferDeclined == true
  if saved.phoneRelationshipThreshold then
    rival.phoneRelationshipThreshold = tonumber(saved.phoneRelationshipThreshold)
  end
  rival.lastCallTime = tonumber(saved.lastCallTime) or 0
  rival.nextCallTime = tonumber(saved.nextCallTime) or 0
  rival.callCooldown = tonumber(saved.callCooldown) or 0
end

return Phone
