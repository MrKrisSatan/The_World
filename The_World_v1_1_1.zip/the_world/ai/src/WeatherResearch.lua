-- 7.0.0 Weather Research quest-giver. A physical NPC interaction is the only
-- door into scientist weather quests; Weather FX/world ticks never write a
-- quest directly into the Pokégear.
local req, mod = ...
local R = { installed=false }
local TEXT, NPC_INDEX = "AIR_WEATHER_SCIENTIST", 93
local GEN1 = { "VIRIDIAN_POKECENTER", "PEWTER_POKECENTER", "CERULEAN_POKECENTER",
  "LAVENDER_POKECENTER", "VERMILION_POKECENTER", "CELADON_POKECENTER",
  "FUCHSIA_POKECENTER", "CINNABAR_POKECENTER", "SAFFRON_POKECENTER",
  "MT_MOON_POKECENTER", "ROCK_TUNNEL_POKECENTER" }
local GEN2 = { "CHERRYGROVE_POKECENTER_1F", "VIOLET_POKECENTER_1F",
  "ROUTE_32_POKECENTER_1F", "AZALEA_POKECENTER_1F", "GOLDENROD_POKECENTER_1F",
  "ECRUTEAK_POKECENTER_1F", "OLIVINE_POKECENTER_1F", "CIANWOOD_POKECENTER_1F",
  "MAHOGANY_POKECENTER_1F", "BLACKTHORN_POKECENTER_1F", "SILVER_CAVE_POKECENTER_1F",
  "INDIGO_PLATEAU_POKECENTER_1F", "VIRIDIAN_POKECENTER_1F", "PEWTER_POKECENTER_1F",
  "CERULEAN_POKECENTER_1F", "ROUTE_10_POKECENTER_1F", "VERMILION_POKECENTER_1F",
  "LAVENDER_POKECENTER_1F", "CELADON_POKECENTER_1F", "SAFFRON_POKECENTER_1F",
  "FUCHSIA_POKECENTER_1F", "CINNABAR_POKECENTER_1F" }

local function generation(manager, mod_)
  if manager and manager.ready and manager.generation then return manager.generation end
  local data=mod_ and mod_.game and mod_.game.data
  if data and (data.gen2Maps or data.gen2Trainers) then return 2 end
  if data and data.maps then return 1 end
  return nil
end

local function existing(manager,giverId)
  for _,q in ipairs((manager.quests and manager.quests.offers) or {}) do
    if q.giverId==giverId and (q.status=="OFFERED" or q.status=="ACTIVE" or q.status=="COMPLETE") then return q end
  end
end

function R.offer(manager,mapId)
  if not (manager and manager.quests) then return nil,"My instruments aren't ready yet." end
  local giverId="weather_scientist:"..tostring(mapId)
  local old=existing(manager,giverId)
  if old then return old, old.dialogue or old.description end
  if not manager.quests:weatherContext() then
    return nil,"My weather instruments are offline. I can't issue field work until Weather FX is active."
  end
  local q=manager.quests:scientistWeatherOffer(giverId,"Weather Scientist")
  if not q then return nil,"I have no new field assignment right now. Check back after conditions change." end
  return q,q.dialogue or q.description
end

local function showGen1(ctx,text)
  local ok,TextBox=pcall(require,"src.render.TextBox")
  if not (ok and TextBox and ctx and ctx.game and ctx.game.stack) then return end
  local runner=ctx.runner
  ctx.game.stack:push(TextBox.new(ctx.game,text,function() if runner then runner:resume() end end))
  if runner then runner:yield() end
end

function R.install(mod_,manager)
  if R.installed then return R end
  local gen=generation(manager,mod_)
  if not gen then
    mod_.events:on("game.ready",function() if not R.installed then R.install(mod_,manager) end end)
    return R
  end
  R.installed=true
  local centers=gen==2 and GEN2 or GEN1
  local sprite
  pcall(function()
    if manager and manager.sprites and manager.sprites.npcFor then
      sprite=manager.sprites:npcFor("scientist",manager.data,{"SPRITE_SCIENTIST","SPRITE_SUPER_NERD","SPRITE_OAK_AIDE","SPRITE_TEACHER"})
    end
  end)
  if not sprite then R.installed=false; return R end
  for _,mapId in ipairs(centers) do
    pcall(function() mod_.content.maps:patch(mapId,{objects={__append={{index=NPC_INDEX,x=9,y=4,sprite=sprite,
      movement=gen==2 and 6 or "STAY",range="DOWN",text=TEXT,name="WEATHER_SCIENTIST"}}}}) end)
  end
  if gen==1 then
    pcall(function() mod_.content.commands:register("ai_rivals:weather_scientist_offer",{foreground=true,fn=function(ctx,mapId)
      local q,line=R.offer(manager,mapId); showGen1(ctx,line or "No new research today.")
      if q and manager then manager.ticker={text="RESEARCH  •  "..tostring(q.title),age=0,duration=8,offset=0} end
    end}) end)
    for _,mapId in ipairs(centers) do
      local m=mapId
      pcall(function() mod_.content.map_scripts:register(m,{priority=-3,talk={
        [TEXT]={{"face_player"},{"ai_rivals:weather_scientist_offer",m}}
      }}) end)
    end
  else
    local Gen2Talk=req("src/Gen2Talk")
    Gen2Talk.register("ai_rivals:weather_scientist",function(world,npc)
      local def=npc and npc.def
      if not (def and (def.name=="WEATHER_SCIENTIST" or def.text==TEXT)) then return false end
      local mapId=world and world.map and (world.map.id or (world.map.def and world.map.def.id)) or (manager:worldView() or {}).playerMap
      local q,line=R.offer(manager,mapId)
      if world and world.showText then pcall(world.showText,world,line or "No new research today.") end
      if q then manager.ticker={text="RESEARCH  •  "..tostring(q.title),age=0,duration=8,offset=0} end
      return true
    end,31)
    mod_.events:on("game.ready",function() Gen2Talk.install() end)
  end
  return R
end
return R
