local req, mod = ...
local Util = req("src/Util")

-- COMMUNICATIONS (3.0.0).
--
-- The contact and call model behind the Pokegear. See
-- docs/pokegear-feasibility.md for the audit this is built on; the finding
-- that shapes it is worth repeating here because it is not obvious:
--
--   src/mods/Schemas.lua lines 620-639 list `phone_contacts`, `radio_channels`
--   and `landmarks` as registries with NO Gen 1 home. Writes are dropped and
--   reported. The comment is explicit that "the systems themselves are absent
--   from Red rather than spelled differently there", and Gold's
--   src/ui/gen2/Pokegear.lua is not one of the fifteen modules Gen2Compat
--   adapts.
--
-- So a Gen 1 Pokegear cannot wrap Gold's. This model owns its own state and
-- TARGETS the engine's Gen 2 registry when it exists -- which is exactly what
-- src/Phone.lua has done since 1.30 (Pokegear registration on Gold, news
-- ticker on Gen 1). This generalises that file's contact handling from
-- "rivals" to "anyone"; it does not replace it (§18, §46: rivals must not get
-- a second phone implementation).
--
-- WHAT THIS FILE IS NOT
--
-- It is not a scheduler that runs itself, and it owns no UI. It is the data
-- model plus the rules for who may call whom and when. The tick, the screens
-- and the summon controller are later releases, and keeping them out means
-- this can be tested headlessly and cannot spam anything on its own.

local Comms = {}

-- ------------------------------------------------------------------
-- Contact types (§18)
-- ------------------------------------------------------------------
-- A TYPE FIELD, not a class hierarchy. §29 warns the system must let ordinary
-- trainers be summoned later "without rewriting the system", and the way to
-- guarantee that is for a rival and a fisherman to be the same record with a
-- different value in one column.

Comms.TYPES = { "RIVAL", "TRAINER", "PROFESSOR", "SPECIAL" }
local TYPE_SET = {}
for _, t in ipairs(Comms.TYPES) do TYPE_SET[t] = true end
function Comms.isType(t) return TYPE_SET[t] == true end

-- Bounds. §35 asks for a larger Gen 1 list than Gold's, and configurable.
Comms.CONTACT_LIMIT = 200
Comms.HISTORY_LIMIT = 24      -- call log; §32 wants history, not an archive
Comms.MISSED_LIMIT = 8

-- Call reasons (§30's event vocabulary). A closed set: a caller may only ring
-- for a reason named here, so a typo cannot invent a call type nothing renders.
Comms.REASONS = {
  "REMATCH", "CHALLENGE", "WEATHER", "SWARM", "RARE", "GIFT",
  "RESEARCH", "LIFE_PATH", "ROCKET", "CHAT", "SUMMON_REPLY",
  -- 4.5.0's Pokegear conversation: arranging an event, and asking a contact
  -- what they know about another trainer. Both are calls the player made, so
  -- both belong in the history the CALL HISTORY screen reads.
  "TOURNAMENT", "SCOUT", "CHALLENGE",
}
local REASON_SET = {}
for _, r in ipairs(Comms.REASONS) do REASON_SET[r] = true end
function Comms.isReason(r) return REASON_SET[r] == true end

-- §27's interrupt priorities, lowest number wins. A rival already inside a
-- critical event does not drop it because the player rang.
Comms.PRIORITY = {
  STORY = 1, BATTLE = 2, ROCKET = 3, LIFE_PATH = 4,
  SUMMON = 5, GYM = 6, TRAIN = 7, EXPLORE = 8, CASUAL = 9,
}

local function num(v, d) return tonumber(v) or d end

-- ------------------------------------------------------------------
-- Numbers (§34)
-- ------------------------------------------------------------------
-- Deterministic in (world seed, contact id): stable across save/load, distinct
-- between playthroughs, and never regenerated. §45 requires persistence, and a
-- number that changed on load would point the player's saved contact at
-- nobody -- the one thing a phone book must never do.
--
-- Formatted as Gen 2 does (##-####) rather than invented, because that is what
-- the Pokegear draws.

local function hash(seed, text)
  local h = 2166136261
  local s = tostring(seed) .. "|" .. tostring(text)
  for i = 1, #s do
    h = (h + s:byte(i) * 16777619) % 4294967296
    h = (h * 31 + 7) % 4294967296
  end
  return h
end

function Comms.numberFor(seed, contactId)
  if type(contactId) ~= "string" or contactId == "" then return nil end
  local h = hash(seed, "number:" .. contactId)
  return string.format("%02d-%04d", h % 100, math.floor(h / 100) % 10000)
end

-- ------------------------------------------------------------------
-- The record
-- ------------------------------------------------------------------

local function normalise(saved, id)
  saved = type(saved) == "table" and saved or {}
  local history = {}
  for _, entry in ipairs(type(saved.history) == "table" and saved.history or {}) do
    if type(entry) == "table" and Comms.isReason(entry.reason) then
      history[#history + 1] = {
        reason = entry.reason,
        tick = math.max(0, math.floor(num(entry.tick, 0))),
        incoming = entry.incoming == true,
        missed = entry.missed == true,
      }
    end
  end
  while #history > Comms.HISTORY_LIMIT do table.remove(history, 1) end
  return {
    id = id,
    name = type(saved.name) == "string" and saved.name:sub(1, 24) or id,
    kind = Comms.isType(saved.kind) and saved.kind or "TRAINER",
    trainerId = type(saved.trainerId) == "string" and saved.trainerId or nil,
    rivalId = type(saved.rivalId) == "string" and saved.rivalId or nil,
    number = type(saved.number) == "string" and saved.number or nil,
    -- §11: offered and accepted are different states. A trainer who asked and
    -- was refused must not keep asking, and must not appear in the list.
    offered = saved.offered == true,
    accepted = saved.accepted == true,
    declined = saved.declined == true,
    rematch = math.max(0, math.floor(num(saved.rematch, 0))),
    -- 7.4.5: familiarity exists before a number is offered. Ordinary trainers
    -- may need several repeat battles, and some saves/NPCs never exchange
    -- numbers at all.
    battleCount = math.max(0, math.floor(num(saved.battleCount, 0))),
    phoneEligible = saved.phoneEligible == true,
    phoneNever = saved.phoneNever == true,
    phoneOfferAfter = math.max(1, math.floor(num(saved.phoneOfferAfter, 1))),
    lastCall = math.max(0, math.floor(num(saved.lastCall, 0))),
    cooldown = math.max(0, math.floor(num(saved.cooldown, 0))),
    personality = type(saved.personality) == "string"
      and saved.personality:sub(1, 24) or nil,
    history = history,
  }
end

function Comms.new(saved)
  saved = type(saved) == "table" and saved or {}
  local contacts = {}
  local ids = {}
  for id, record in pairs(type(saved.contacts) == "table" and saved.contacts or {}) do
    if type(id) == "string" and id ~= "" then
      contacts[id] = normalise(record, id)
      ids[#ids + 1] = id
    end
  end
  -- Deterministic eviction if a save somehow exceeds the cap: keep the most
  -- recently active, ties on id.
  if #ids > Comms.CONTACT_LIMIT then
    table.sort(ids, function(a, b)
      local la, lb = contacts[a].lastCall, contacts[b].lastCall
      if la ~= lb then return la > lb end
      return a < b
    end)
    for i = Comms.CONTACT_LIMIT + 1, #ids do contacts[ids[i]] = nil end
  end
  local missed = {}
  for _, entry in ipairs(type(saved.missed) == "table" and saved.missed or {}) do
    if type(entry) == "table" and type(entry.id) == "string" then
      missed[#missed + 1] = {
        id = entry.id,
        reason = Comms.isReason(entry.reason) and entry.reason or "CHAT",
        tick = math.max(0, math.floor(num(entry.tick, 0))),
      }
    end
  end
  while #missed > Comms.MISSED_LIMIT do table.remove(missed, 1) end
  return { contacts = contacts, missed = missed,
           lastAnyCall = math.max(0, math.floor(num(saved.lastAnyCall, 0))) }
end

function Comms.serialize(state) return Comms.new(state) end

function Comms.count(state)
  local n = 0
  for _ in pairs(type(state) == "table" and state.contacts or {}) do n = n + 1 end
  return n
end

function Comms.get(state, id)
  if type(state) ~= "table" then return nil end
  return state.contacts[id]
end

-- ------------------------------------------------------------------
-- Joining the network (§11, §36)
-- ------------------------------------------------------------------

-- A contact exists as soon as somebody OFFERS, but is only listed once the
-- player accepts. §36 insists the player is never left unsure whether a number
-- saved, so the two states are separate and the caller reports the accept.
function Comms.offer(state, id, info, seed)
  if type(state) ~= "table" or type(id) ~= "string" or id == "" then return nil end
  info = type(info) == "table" and info or {}
  local record = state.contacts[id]
  if record and (record.accepted or record.declined) then return record end
  if not record then
    if Comms.count(state) >= Comms.CONTACT_LIMIT then return nil end
    record = normalise({
      name = info.name, kind = info.kind, trainerId = info.trainerId,
      -- 4.5.0: a RIVAL contact carries which rival it is. The record schema
      -- has always had the field; the offer dropped it, so every rival contact
      -- reached the Pokegear anonymous and callers had to re-derive the rival
      -- from the contact id. syncRivalComms stamped it afterwards, which meant
      -- one path had it and the other silently did not.
      rivalId = info.rivalId,
      personality = info.personality,
    }, id)
    state.contacts[id] = record
  end
  record.offered = true
  record.number = record.number or Comms.numberFor(seed, id)
  return record
end

function Comms.accept(state, id)
  local record = Comms.get(state, id)
  if not record or not record.offered or record.declined then return false end
  record.accepted = true
  return true
end

-- §11: a refusal is remembered, so nobody nags.
function Comms.decline(state, id)
  local record = Comms.get(state, id)
  if not record then return false end
  record.declined = true
  record.accepted = false
  return true
end

function Comms.listed(state)
  local out = {}
  for id, record in pairs(type(state) == "table" and state.contacts or {}) do
    if record.accepted then out[#out + 1] = record end
  end
  -- Deterministic order: type first (§37's categories), then name, then id.
  local rank = {}
  for i, t in ipairs(Comms.TYPES) do rank[t] = i end
  table.sort(out, function(a, b)
    if a.kind ~= b.kind then return (rank[a.kind] or 99) < (rank[b.kind] or 99) end
    if a.name ~= b.name then return a.name < b.name end
    return a.id < b.id
  end)
  return out
end

-- ------------------------------------------------------------------
-- Calls (§30, §38, §39)
-- ------------------------------------------------------------------

-- Per-contact and world-wide cooldowns, exactly as Presence budgets sightings.
-- §28 is explicit that the player should feel they are contacting a person
-- rather than spawning an NPC, and the budget is what produces that.
Comms.CALL_COOLDOWN = 3600     -- one contact
Comms.GLOBAL_COOLDOWN = 900    -- any contact

-- May this contact ring the player right now?
--
-- `world.busy` is the §39 gate: battles, menus, cutscenes, text, transitions,
-- evolution, trading and saving. The caller decides what busy means; this
-- refuses outright when it is true rather than queueing, because a queue that
-- fires the instant a battle ends is still an interruption.
function Comms.mayCall(state, id, tick, world)
  local record = Comms.get(state, id)
  if not record or not record.accepted then return false end
  if type(world) == "table" and world.busy then return false end
  tick = math.max(0, math.floor(num(tick, 0)))
  if tick - num(state.lastAnyCall, 0) < Comms.GLOBAL_COOLDOWN then return false end
  if tick - num(record.lastCall, 0) < Comms.CALL_COOLDOWN then return false end
  if num(record.cooldown, 0) > tick then return false end
  return true
end

-- Record a call that actually happened. Returns the history entry.
function Comms.record(state, id, reason, tick, opts)
  local record = Comms.get(state, id)
  if not record then return nil end
  if not Comms.isReason(reason) then return nil end
  opts = opts or {}
  tick = math.max(0, math.floor(num(tick, 0)))
  local entry = {
    reason = reason, tick = tick,
    incoming = opts.incoming ~= false,
    missed = opts.missed == true,
  }
  record.history[#record.history + 1] = entry
  while #record.history > Comms.HISTORY_LIMIT do table.remove(record.history, 1) end
  record.lastCall = tick
  state.lastAnyCall = tick
  if entry.missed then
    state.missed[#state.missed + 1] = { id = id, reason = reason, tick = tick }
    while #state.missed > Comms.MISSED_LIMIT do table.remove(state.missed, 1) end
  end
  return entry
end

-- §31: what the player is told when they next open the Pokegear.
function Comms.missedCalls(state)
  local out = {}
  for _, entry in ipairs(type(state) == "table" and state.missed or {}) do
    out[#out + 1] = entry
  end
  return out
end

function Comms.clearMissed(state)
  if type(state) == "table" then state.missed = {} end
end

-- §32: newest first, across every contact.
function Comms.callHistory(state, limit)
  local rows = {}
  for id, record in pairs(type(state) == "table" and state.contacts or {}) do
    for _, entry in ipairs(record.history) do
      rows[#rows + 1] = { id = id, name = record.name, reason = entry.reason,
                          tick = entry.tick, incoming = entry.incoming,
                          missed = entry.missed }
    end
  end
  table.sort(rows, function(a, b)
    if a.tick ~= b.tick then return a.tick > b.tick end
    return a.id < b.id
  end)
  local out = {}
  for i = 1, math.min(limit or Comms.HISTORY_LIMIT, #rows) do out[#out + 1] = rows[i] end
  return out
end

-- ------------------------------------------------------------------
-- Presentation
-- ------------------------------------------------------------------

Comms.TYPE_LABELS = {
  RIVAL = "Rivals", TRAINER = "Trainers",
  PROFESSOR = "Professors", SPECIAL = "Special",
}

Comms.REASON_LABELS = {
  REMATCH = "Rematch", CHALLENGE = "Battle Challenge", WEATHER = "Weather Report",
  SWARM = "Swarm Report", RARE = "Rare Pokemon", GIFT = "Gift",
  RESEARCH = "Research", LIFE_PATH = "News", ROCKET = "Warning",
  CHAT = "Chat", SUMMON_REPLY = "Meeting",
  TOURNAMENT = "Tournament", SCOUT = "Asked About", CHALLENGE = "Challenge",
}

function Comms.reasonLabel(r) return Comms.REASON_LABELS[r or ""] or "Call" end
function Comms.typeLabel(t) return Comms.TYPE_LABELS[t or ""] or "Contacts" end

function Comms.describe(state)
  return ("%d/%d contacts, %d missed"):format(
    Comms.count(state), Comms.CONTACT_LIMIT,
    #(type(state) == "table" and state.missed or {}))
end


-- ------------------------------------------------------------------
-- Kanto trainer discovery
-- ------------------------------------------------------------------

local GYM_SUFFIXES = { "_GYM", "_GYM_1F", "_GYM_2F" }

function Comms.isGymMap(mapId)
  local s = tostring(mapId or ""):upper()
  for _, suffix in ipairs(GYM_SUFFIXES) do
    if s:sub(-#suffix) == suffix then return true end
  end
  if s:find("_GYM", 1, true) then return true end
  return s:find("ELITE", 1, true) ~= nil
end

local function trainerClassFromObject(obj)
  if type(obj) ~= "table" then return nil end
  local c = obj.trainerClass or obj.class
  if type(c) == "table" then c = c.id or c.class or c.classId end
  if type(c) == "string" or type(c) == "number" then return c end
  if type(obj.trainer) == "table" then
    c = obj.trainer.trainerClass or obj.trainer.class
    if type(c) == "table" then c = c.id or c.class or c.classId end
    if type(c) == "string" or type(c) == "number" then return c end
  end
  return nil
end

local function walkObjects(value, fn, seen, index)
  if type(value) ~= "table" then return end
  seen = seen or {}
  if seen[value] then return end
  seen[value] = true
  index = index or { n = 0 }
  index.n = index.n + 1
  fn(value, index.n)
  for k, v in pairs(value) do
    if type(k) ~= "string" or k ~= "data" then
      if type(v) == "table" then walkObjects(v, fn, seen, index) end
    end
  end
end

function Comms.trainerDisplayName(classId)
  local s = tostring(classId or "TRAINER"):gsub("^OPP_", ""):gsub("_", " ")
  return s:sub(1,1) .. s:sub(2):lower()
end

function Comms.contactIdForTrainer(mapId, trainerClass, objectName)
  local a = tostring(mapId or "UNKNOWN"):upper()
  local b = tostring(trainerClass or "TRAINER"):upper()
  local c = tostring(objectName or ""):upper()
  if c == "" then c = "CLASS" end
  return ("PHONE_T_%s_%s_%s"):format(a, b, c):gsub("[^A-Z0-9_]", "_")
end

local ROCKET_MARKERS = { "ROCKET", "GIOVANNI", "EXECUTIVE", "ADMIN", "GRUNT" }
local RIVAL_MARKERS = { "RIVAL", "CHAMPION", "ELITE" }

function Comms.isRocketTrainer(classId, name, mapId)
  local text = (tostring(classId or "") .. " " .. tostring(name or "") .. " " .. tostring(mapId or "")):upper()
  for _, marker in ipairs(ROCKET_MARKERS) do
    if text:find(marker, 1, true) then return true end
  end
  local map = tostring(mapId or ""):upper()
  local cls = tostring(classId or ""):upper()
  if map:find("SILPH", 1, true) and cls:find("SCIENTIST", 1, true) then return true end
  return false
end

function Comms.isOrdinaryTrainer(classId, name, mapId)
  if not classId or Comms.isGymMap(mapId) or Comms.isRocketTrainer(classId, name, mapId) then return false end
  local text = (tostring(classId) .. " " .. tostring(name or "")):upper()
  for _, marker in ipairs(RIVAL_MARKERS) do if text:find(marker, 1, true) then return false end end
  return true
end

function Comms.trainerPhoneProfile(seed, contactId)
  -- Stable per SAVE + NPC. About 58% of ordinary trainers are willing to
  -- exchange numbers at all. Of those, only a minority offer immediately;
  -- many require repeat battles. This keeps the phonebook personal rather than
  -- turning every route into a census.
  local roll=hash(seed or 1,"phone-profile:"..tostring(contactId))%100
  if roll>=58 then return {eligible=false,never=true,after=nil} end
  local depth=hash(seed or 1,"phone-depth:"..tostring(contactId))%100
  local after
  if depth<24 then after=1
  elseif depth<55 then after=2
  elseif depth<82 then after=3
  else after=4 end
  return {eligible=true,never=false,after=after}
end

function Comms.noteTrainerBattle(state,id,info,seed)
  if type(state)~="table" or type(id)~="string" then return nil,false end
  local record=state.contacts[id]
  if not record then
    if Comms.count(state)>=Comms.CONTACT_LIMIT then return nil,false end
    local profile=Comms.trainerPhoneProfile(seed,id)
    record=normalise({
      name=info and info.name, kind="TRAINER",
      trainerId=info and info.trainerId,
      personality=info and info.personality,
      phoneEligible=profile.eligible, phoneNever=profile.never,
      phoneOfferAfter=profile.after or 99,
    },id)
    state.contacts[id]=record
  end
  record.battleCount=(tonumber(record.battleCount) or 0)+1
  local ready=record.phoneEligible and not record.phoneNever
    and not record.accepted and not record.declined and not record.offered
    and record.battleCount >= (record.phoneOfferAfter or 1)
  return record,ready
end

-- Compatibility predicate retained for older callers/tests.
function Comms.shouldOfferTrainer(seed, contactId)
  return Comms.trainerPhoneProfile(seed,contactId).eligible
end

function Comms.trainerFromObject(obj, mapId)
  if Comms.isGymMap(mapId) then return nil end
  local classId = trainerClassFromObject(obj)
  if not classId then return nil end
  local name = obj.name or obj.label or obj.trainerName
  if not Comms.isOrdinaryTrainer(classId, name, mapId) then return nil end
  local objectName = obj.name or obj.id or obj.objectId
  local coordinateKey = objectName
  if obj.x ~= nil or obj.y ~= nil then
    coordinateKey = tostring(objectName or "TRAINER") .. "_" .. tostring(obj.x or "?")
      .. "_" .. tostring(obj.y or "?")
  end
  return {
    id = Comms.contactIdForTrainer(mapId, classId, coordinateKey),
    name = type(name) == "string" and name or Comms.trainerDisplayName(classId),
    trainerClass = classId,
    partyIndex = tonumber(obj.partyIndex or obj.memberId or obj.index) or 1,
    map = mapId,
    objectName = objectName,
  }
end

function Comms.discoverTrainers(data, graph, generation)
  local out = {}
  local maps = data and (generation == 2 and data.gen2Maps or data.maps) or {}
  if type(maps) ~= "table" then return out end
  local function visit(mapId, map)
    if Comms.isGymMap(mapId) then return end
    walkObjects(map and (map.objects or map.object or map.npcs or map.events or map), function(obj)
      local contact = Comms.trainerFromObject(obj, mapId)
      if contact and not out[contact.id] then out[contact.id] = contact end
    end)
  end
  for mapId, map in pairs(maps) do
    if type(mapId) == "string" and type(map) == "table" then
      visit(mapId, map)
    end
  end
  return out
end

function Comms.indexByTrainerClass(defs)
  local out = {}
  for id, def in pairs(defs or {}) do
    if def and def.trainerClass then
      out[def.trainerClass] = out[def.trainerClass] or {}
      out[def.trainerClass][id] = def
    end
  end
  return out
end


return Comms
