------------------------------------------------------------------------
-- AI Rivals
------------------------------------------------------------------------
-- Four persistent AI trainers walk Kanto on their own clock.  They route
-- across the real map graph, train, queue at gym doors, win and LOSE gym
-- battles, keep their own badge case, and turn up to fight the player with
-- whatever party they actually have at that moment.
--
-- WHAT THIS FILE OWNS
--   * the module loader (this mod is many files; the engine loads one)
--   * RivalManager: the roster, the save bucket, the engine seams
--   * every subscription and hook link
-- The thinking lives in src/; nothing below decides anything about a rival.
--
-- THE THREE SEAMS THAT MAKE IT WORK WITHOUT A SECOND BATTLE ENGINE
--   1. `trainers` registry + the `trainer.party` hook.  Each rival owns one
--      trainer record whose party is a placeholder.  When a battle against
--      that class starts, the hook swaps in the rival's LIVE party -- so the
--      player fights CHARMELEON Lv28 because the rival really has one.
--   2. `mod.world:spawnNpc` / `removeNpc`.  A rival is a real overworld
--      object only while the player shares its map; everywhere else it is a
--      row in a table being advanced by the tick.
--   3. `core.update`.  One accumulator, one tick every 1.5s, a bounded
--      number of rivals per tick.  Nothing in this mod runs per frame.
------------------------------------------------------------------------

------------------------------------------------------------------------
-- Module loader
------------------------------------------------------------------------
-- The engine loads exactly one chunk per mod, so a multi-file mod brings its
-- own require.  `mod:read` is the supported way to get at a file inside the
-- mod directory -- it works identically from a folder install and from a
-- packed .modpkg (mod:read works in both installs).  Each module receives
-- (req, mod) as varargs, which is why every file opens `local req, mod = ...`.

return function(mod)

local loaded, loading = {}, {}


local function requireBattleState()
  local candidates = {
    "src.battle.BattleState",
    "battle.BattleState",
    "BattleState",
  }
  local errors = {}
  for _, name in ipairs(candidates) do
    local ok, value = pcall(require, name)
    if ok and value then return value end
    errors[#errors + 1] = tostring(value)
  end
  error("AI Rivals: could not load BattleState (" .. table.concat(errors, " | ") .. ")")
end

local function req(name)
  local hit = loaded[name]
  if hit ~= nil then return hit end
  if loading[name] then
    error("ai_rivals: circular require of " .. name, 0)
  end
  loading[name] = true
  local source = mod:read(name .. ".lua")
  if not source then
    error("ai_rivals: missing module " .. name .. ".lua", 0)
  end
  -- Sandbox binds load/loadstring to the mod env; prefer loadstring (works
  -- on Lua 5.1 AND as a 5.2 alias), then the 5.2+ string `load`.  Both are
  -- pcall'd so a build where the other does not take a string never kills
  -- the mod load.
  local chunk, err
  if type(loadstring) == "function" then
    local ok, c = pcall(loadstring, source, "@ai_rivals/" .. name .. ".lua")
    if ok then chunk = c else err = c end
  end
  if not chunk and type(load) == "function" then
    local ok, c = pcall(load, source, "@ai_rivals/" .. name .. ".lua")
    if ok then chunk = c else err = c end
  end
  if not chunk then error("ai_rivals: " .. tostring(err), 0) end
  local value = chunk(req, mod)
  loading[name] = nil
  loaded[name] = value == nil and true or value
  return loaded[name]
end

local Util       = req("src/Util")
local MapGraph   = req("src/MapGraph")
local Pathfinder = req("src/Pathfinder")
local BattleSim  = req("src/BattleSim")
local Rival      = req("src/Rival")
local AI         = req("src/AI")
local Simulation = req("src/Simulation")
local Sprites    = req("src/Sprites")
local Version    = req("src/Version")
local Dialogue   = req("src/Dialogue")
local DoubleBattles = req("src/DoubleBattles")
local WonderTrade = req("src/WonderTrade")
local WeatherResearch = req("src/WeatherResearch")
local KantoCompat = req("src/KantoCompat")
local Memory = req("src/Memory")
local Relationships = req("src/Relationships")
local TeamPlan = req("src/TeamPlan")
local Story = req("src/Story")
local Presence = req("src/Presence")
local Weather = req("src/Weather")
local Economy = req("src/Economy")
local League = req("src/League")
local LifePath = req("src/LifePath")
local Career = req("src/Career")
local Phone = req("src/Phone")
local Comms = req("src/Comms")
local BattleFlow = req("src/BattleFlow")
local RuntimePolicy = req("src/RuntimePolicy")
local RosterPolicy = req("src/RosterPolicy")
local Gen2Talk = req("src/Gen2Talk")
local StaticRivals = req("src/StaticRivals")
local BlueChampion = req("src/BlueChampion")
local TrainerClasses = req("src/TrainerClasses")
local Happiness = req("src/Happiness")
local Scout = req("src/Scout")
local Achievements = req("src/Achievements")
local Rankings = req("src/Rankings")
local NOTABLE = req("data/notable")
local RivalGear = req("src/RivalGear")
local Tournaments = req("src/Tournaments")
local Ecology    = req("src/Ecology")
local WorldState = req("src/WorldState")
local Travel     = req("src/Travel")
local Titles = req("src/Titles")
local Names = req("data/names")
local Status = req("src/ui/Status")
local Commands = req("src/debug/Commands")
local RocketManager = req("src/Rocket")
local RangersManager = req("src/Rangers")
local Factions = req("src/Factions")
local RocketDisguise = req("src/RocketDisguise")
local DoubleAgent = req("src/DoubleAgent")
local StolenRecovery = req("src/StolenRecovery")
local RivalWars = req("src/RivalWars")
local Quests = req("src/Quests")
local Specials = req("src/Specials")
local Backgrounds = req("src/Backgrounds")

local Compat     = req("src/Compat")
local FeatureParity = req("src/FeatureParity")

-- The complete double-battle implementation is bundled into this mod so a
-- companion works without a second installation.
DoubleBattles(mod)

local ROSTER        = req("data/rivals")

-- 5.0.8: forward declaration. The comment at `M = {` below has claimed since
-- 1.x that M is declared "before the map helpers reference it" -- it was not:
-- homeMapsFor sits ABOVE it and was reading the nil GLOBAL M, so the
-- version-keyed arm of every roster row's homeMaps was dead and Gold rivals
-- silently fell back to the Kanto list. Declaring the local up here makes the
-- comment true and keeps M off the global table.
local M

-- A roster row's home maps for the game actually loaded. Accepts the flat
-- list form too, so a third-party roster written before 2.10 keeps working.
local function homeMapsFor(def)
  local maps = def and def.homeMaps
  if type(maps) ~= "table" then return {} end
  if type(maps[1]) == "string" then return maps end
  return maps[(M and M.versionKey) or "default"] or maps.default or {}
end
local PERSONALITIES = req("data/personalities")
local GYMS          = req("data/gyms")
local LINES         = req("data/dialogue")

local SAVE_VERSION = 11
local TALK_TEXT = "AIR_RIVAL_TALK"
local ROCKET_TALK_TEXT = "AIR_ROCKET_TALK"      -- the text id our spawned NPCs carry
local SCREEN = "AiRivalsStatus"

-- The manager.  Declared up here -- before the map helpers below reference
-- it -- so a closure is never left holding the global `M` (which would be
-- nil and crash the first gauntlet resolution).  `Sprites` is already
-- required above.
M = {
  game = nil,
  data = nil,
  graph = nil,
  -- 3.5.0 (from the 3.4.1 patch): ONE rival battle at a time.
  --
  -- A rival battle is a TRANSACTION, not an instant: dialogue, the deferred
  -- launch, the battle itself, then the bookkeeping and gauntlet progression
  -- that follow battle.ended. Every one of those windows could previously be
  -- re-entered -- by a second talk in the same frame, a nearby rival's duel
  -- AI, a repeated Gen 2 engagement event, or a stale delayed callback -- and
  -- the second entrant would corrupt the first's state.
  --
  -- The sequence ID is what makes a STALE callback distinguishable from a live
  -- one: a callback carrying an older id cannot start anything.
  rivalBattleSequenceActive = false,
  rivalBattleSequenceId = 0,
  rivalBattleActiveRivalId = nil,

  rivals = {},          -- ordered list
  byId = {},
  sim = nil,
  sprites = Sprites.new(mod),
  dialogue = nil,
  spawned = {},         -- rival id -> npc handle id, current map only
  pending = nil,        -- the rival whose battle is about to start
  ready = false,
  generation = 1,
  news = {},            -- 1.14.0: ring buffer of world-news lines
  ticker = { text = nil, age = 0, duration = 8, offset = 0 },
  tickerQueue = {},
  companionId = nil,
  worldStartPending = false,
  pendingRivalMenu = nil,
  pendingRivalAction = nil,
  pendingMapMaterialize = nil,
  connectionYieldActive = false,
  connectionYieldMap = nil,
  pendingPhoneTrainer = nil,
  pendingTrainerContact = nil,
  phoneTrainerDefs = {},
  phoneContactObjects = {},
  radioStation = "POKEMON_MUSIC",
  radioEnabled = false,
  customMusicFolder = "custom_music",
  customMusicTrack = nil,
  customMusicSource = nil,
  challengeModes = {},
  tournaments = nil,
  tournamentExpActive = false,
  playerClassId = "TRAINER",
  playerOpeningOutdoorSafe = false,
  playerOpeningOutdoorMap = nil,
  classBattleMoneyBefore = nil,
  classBattlePartyBefore = nil,
  classBattleBoxBefore = nil,
  perf = {
    simulation = { samples = 0, average = 0, maximum = 0 },
    walking = { samples = 0, average = 0, maximum = 0 },
    -- Observational only: whole core.update body, so it sees the steady-state
    -- cost (F1/F2/F4-F7 in docs/performance.md) that sim/walk cannot. Does not
    -- feed slowStrikes/autoLowSeconds -- adding a measurement must not change
    -- when the mod decides it is struggling.
    frame = { samples = 0, average = 0, maximum = 0 },
    autoLowSeconds = 0, recoveries = 0,
  },
  log = {},             -- replaced below with the news-writing function
}

-- Player tournament matches are special events: every ordinary EXP award
-- produced by the engine during one of these battles is doubled.  The flag is
-- raised only after the bracket launches its player match and is cleared by
-- battle.ended/blackout, so wild battles and ordinary rival challenges are
-- untouched.
mod.hooks:wrap("exp.gain", function(next,c)
 local gained=next(c); local amount=tonumber(gained); if not amount then return gained end
 if M.tournamentExpActive then amount=amount*2 end
 local species
 pcall(function() species=(c and (c.species or (c.mon and c.mon.species))) or (M.game and M.game.save and M.game.save.party and M.game.save.party[1] and M.game.save.party[1].species) end)
 amount=amount*TrainerClasses.expMultiplier(M.playerClassId,M.data,species,{})
 return math.max(1,math.floor(amount))
end)

mod.hooks:wrap("catch.rate",function(next,...)
 local rate,guaranteed=next(...)
 if type(rate)~="number" or guaranteed then return rate,guaranteed end
 local args={...}; local ctx=args[1]; local species
 if type(ctx)=="table" then species=ctx.species or (ctx.targetDef and ctx.targetDef.id) end
 local m=TrainerClasses.catchMultiplier(M.playerClassId,M.data,species,{})
 return math.max(1,math.min(255,math.floor(rate*m))),guaranteed
end)

mod.hooks:wrap("battle.damage",function(next,ctx)
 local damage,info=next(ctx)
 if type(damage)~="number" or damage<=0 then return damage,info end
 local cls=TrainerClasses.get(M.playerClassId)
 local function player(side)
  if type(side)~="table" then return false end
  return side.isPlayer==true or side.player==true or side.side=="player" or side.team=="player" or (side.mon and side.mon.isPlayer==true)
 end
 local u=ctx and (ctx.user or ctx.attacker or ctx.source)
 local t=ctx and (ctx.target or ctx.defender)
 local up=player(u) or (ctx and (ctx.userSide=="player" or ctx.attackerSide=="player" or ctx.userIsPlayer==true))
 local tp=player(t) or (ctx and (ctx.targetSide=="player" or ctx.defenderSide=="player" or ctx.targetIsPlayer==true))
 if tp and (tonumber(cls.dodgeChance) or 0)>0 then
  local r=(love and love.math and love.math.random and love.math.random()) or math.random()
  if r<cls.dodgeChance then info=type(info)=="table" and info or {}; info.classDodged=true; return 0,info end
 end
 if up then damage=damage*(tonumber(cls.outgoingDamageMultiplier) or 1) end
 if tp then damage=damage*(tonumber(cls.incomingDamageMultiplier) or 1) end
 return math.max(1,math.floor(damage)),info
end)

function M:setPlayerClass(id)
 if not TrainerClasses.valid(id) then id="TRAINER" end
 self.playerClassId=id
 pcall(function() mod.save:set("playerTrainerClass",id) end)
 return id
end
function M:loadPlayerClass()
  local id
  pcall(function() id=mod.save:get("playerTrainerClass") end)
  if not TrainerClasses.valid(id) then
    pcall(function() id=mod.save:get("ai_rivals_player_class") end)
  end
  id=TrainerClasses.valid(id) and id or "TRAINER"
  self.playerClassId=id
  return id
end
local function classStorageCounts(save)
 local p=save and save.party
 local b=save and (save.box or save.pc or save.storage)
 return type(p)=="table" and #p or 0,type(b)=="table" and #b or 0
end
local function applyPlayerClassDVsAfterBattle()
 local save=M.game and M.game.save; if not save then return end
 local p0,b0=M.classBattlePartyBefore or 0,M.classBattleBoxBefore or 0
 local p=save.party; local b=save.box or save.pc or save.storage
 if type(p)=="table" then for i=p0+1,#p do TrainerClasses.modifyDVs(M.playerClassId,p[i]) end end
 if type(b)=="table" then for i=b0+1,#b do TrainerClasses.modifyDVs(M.playerClassId,b[i]) end end
end

local function performanceClockMs()
  local value
  pcall(function()
    if love and love.timer and love.timer.getTime then
      value = love.timer.getTime() * 1000
    elseif os and os.clock then
      value = os.clock() * 1000
    end
  end)
  return value
end

function M:recordPerformance(kind, started)
  local finished = performanceClockMs()
  if not (started and finished) then return end
  local elapsed = math.max(0, finished - started)
  local row = self.perf and self.perf[kind]
  if not row then return end
  row.samples = (row.samples or 0) + 1
  row.average = row.samples == 1 and elapsed
    or (row.average * 0.9 + elapsed * 0.1)
  row.maximum = math.max(row.maximum or 0, elapsed)
  local limit = kind == "walking" and 8 or 12
  if elapsed > limit then
    row.slowStrikes = (row.slowStrikes or 0) + 1
  else
    row.slowStrikes = math.max(0, (row.slowStrikes or 0) - 1)
  end
  if row.slowStrikes >= 3 then
    self.perf.autoLowSeconds = math.max(self.perf.autoLowSeconds or 0, 20)
    row.slowStrikes = 0
  end
end

-- The world log is a function the simulation calls for every event; it turns
-- each one into a line of news the player can read ("Matt caught a Pikachu",
-- "Larissa beat Misty").  `news` holds the freshest lines.
M.log = function(rival, event)
  return M:addNews(rival, event)
end

-- The newest news line, for the status screen.
function M:latestNews()
  local news = self.news
  return news[#news] and news[#news].text or "The world is quiet."
end

-- Turn a simulation event into a line of news.  Every event the tick logs
-- (catches, levels, evolutions, gym results, duels, trainer battles, ghost
-- hunts, League runs) becomes a sentence the player can read.
function M:addNews(rival, event)
  if not (rival and event and type(event) == "table") then return end
  local name = rival.name or rival.id or "?"
  local line
  local kind = event.kind
  if event.gym ~= nil then
    line = event.won
      and (name .. " beat " .. tostring(event.gym.leader or "a Gym Leader") .. "!")
      or (name .. " lost to " .. tostring(event.gym.leader or "a Gym Leader") .. ".")
  elseif kind == "caught" then
    line = name .. " caught a " .. Util.spaced(event.species or "Pokemon") .. "."
  elseif kind == "level" then
    line = name .. "'s " .. Util.spaced(event.species or "mon")
      .. " reached Lv" .. tostring(event.level) .. "."
  elseif kind == "evolve" then
    line = name .. "'s " .. Util.spaced(event.from or "mon") .. " evolved into "
      .. Util.spaced(event.into or "something") .. "!"
  elseif kind == "move" then
    line = name .. " learned " .. Util.spaced(event.move or "a move") .. "."
  elseif kind == "tournament_eliminated" then
    line = name .. " was knocked out of a " .. tostring(event.format or "SINGLE"):lower()
      .. " tournament by " .. tostring(event.by or "another rival") .. "."
  elseif kind == "tournament_won" then
    line = name .. " won a " .. tostring(event.format or "SINGLE"):lower() .. " tournament!"
  elseif kind == "duel" then
    if event.dethroned then
      line = name .. " dethroned the Champion!"
    else
      line = name .. (event.won and " beat " or " lost to ")
        .. tostring(event.vs or "a rival") .. " in a duel."
    end
  elseif kind == "skirmish" then
    line = name .. (event.won and " beat " or " lost to ")
      .. tostring(event.vs or "a rival") .. " in a skirmish."
  elseif kind == "trainer_battle" then
    line = name .. (event.won and " beat " or " lost to ")
      .. Util.spaced(event.trainer or "a trainer") .. "."
  elseif kind == "ghost" then
    line = name .. (event.won and " beat " or " lost to ")
      .. tostring(event.ghost or "a ghost") .. "."
  elseif kind == "title_match" then
    -- 4.6.0. Named from the CHALLENGER's side either way, because "X took the
    -- title from Y" and "Y held them off" are the same event told once.
    local holder = event.holderName or tostring(event.holder or "the Champion")
    local challengerName = event.challengerName or tostring(event.challenger or "a rival")
    if event.won then
      line = challengerName .. " took the title from " .. holder .. "!"
    else
      line = holder .. " held the title against " .. challengerName .. "."
    end
  elseif kind == "league" then
    if event.won and event.qualified then
      -- Cleared the Elite Four while somebody else wears the crown: this is a
      -- challenger now, not a champion, and saying so is the point.
      line = name .. " cleared the Elite Four and wants a title shot."
    elseif event.won then
      line = name .. " conquered the League!"
    elseif event.stage then
      -- Saying WHERE they fell is what makes a repeated failure a story rather
      -- than a repeated line. The escalating gate above means this is now a
      -- handful of items over a session instead of one every sixteen ticks.
      line = name .. " fell at the League, stage " .. tostring(event.stage) .. "."
    else
      line = name .. " fell at the League."
    end
  elseif kind == "rocket" then
    line = tostring(event.text or "Team Rocket activity reported.")
  elseif kind == "champion" then
    line = tostring(event.text or name)
  elseif kind == "bought_balls" then
    line = name .. " bought " .. tostring(event.count or 0) .. " Poke Ball(s)."
  elseif kind == "tm_found" then
    line = name .. " found a TM for " .. Util.spaced(event.move or "a move") .. "."
  elseif kind == "tm_bought" then
    line = name .. " bought a TM for " .. Util.spaced(event.move or "a move") .. "."
  elseif kind == "tm_learned" then
    line = name .. " taught " .. Util.spaced(event.move or "a move")
      .. " to " .. Util.spaced(event.species or "a Pokemon") .. "."
  elseif kind == "hm_obtained" then
    line = name .. " obtained the HM for " .. Util.spaced(event.move or "a field move") .. "."
  elseif kind == "hm_taught" then
    line = name .. " taught " .. Util.spaced(event.move or "an HM")
      .. " to " .. Util.spaced(event.species or "a Pokémon") .. "."
  elseif kind == "hm_used" then
    line = name .. " used " .. Util.spaced(event.move or "an HM")
      .. " to reach " .. Util.spaced(event.map or "a new area") .. "."
  elseif kind == "hm_hunt" then
    line = name .. " is hunting " .. Util.spaced(event.species or "a Pokémon")
      .. " that can learn " .. Util.spaced(event.move or "an HM") .. "."
  elseif kind == "sold" then
    line = name .. " sold " .. tostring(event.count or 0)
      .. " duplicate(s) for Y" .. tostring(event.money or 0) .. "."
  elseif kind == "candy" then
    line = name .. " used a Rare Candy on "
      .. Util.spaced(event.species or "a Pokemon") .. "."
  elseif kind == "dex" then
    line = name .. " filled " .. tostring(event.milestone or 0)
      .. " Pokédex entries!"
  elseif kind == "hunt" then
    line = name .. " is hunting a " .. Util.spaced(event.species or "Pokemon") .. "."
  elseif kind == "trade" then
    line = name .. " traded a " .. Util.spaced(event.gave or "Pokemon")
      .. " for " .. Util.spaced(event.got or "Pokemon")
      .. " with " .. tostring(event.with or "a rival") .. "."
  elseif kind == "wonder_trade" then
    line = name .. " Wonder Traded " .. Util.spaced(event.gave or "a duplicate")
      .. " for a shiny " .. Util.spaced(event.got or "Pokemon") .. "!"
  elseif kind == "ace" then
    line = name .. " made " .. Util.spaced(event.species or "a Pokemon")
      .. " their team ace after forming a special bond."
  elseif kind == "rematch" then
    line = name .. (event.won and " beat " or " lost to ")
      .. Util.spaced(event.trainer or "a leader") .. " in a rematch."
  elseif kind == "life_transition" then
    line = LifePath.transitionHeadline(name, event.from, event.to)
  elseif kind == "life_path" then
    -- §22/§23: phrased as something the world noticed, never as a system
    -- announcement, and rare by construction -- at most two rivals per save
    -- can ever produce one of these.
    line = LifePath.headline(name, event.path)
  elseif kind == "career" then
    line = Career.promotionHeadline(name, rival and rival:lifePathId(), event.level)
  elseif kind == "sighting" then
    -- Already rate-limited and already phrased by Presence.observe; this arm
    -- exists so sightings share the one news channel rather than opening a
    -- second one the player has to watch.
    line = event.note
  elseif kind == "camp" then
    return   -- a camp is something you FIND, not something you are told about
  elseif kind == "milestone" then
    -- §21/§31: milestones are recorded for every rival, but only the flagged
    -- ones are worth interrupting the player for.
    if event.notable ~= true then return end
    line = Story.milestoneHeadline(name, Story.MILESTONE_BY_ID[event.milestone])
  elseif kind == "chapter" then
    line = Story.chapterHeadline(name, event.chapter, event.facts)
  elseif kind == "team_style" then
    -- 1.34.0. Only an actual identity CHANGE reaches here, and identity moves
    -- only on accumulated evidence, so this is rare by construction.
    line = name .. " is rebuilding their team around a "
      .. TeamPlan.label(event.style):lower() .. " strategy."
  elseif kind == "relationship" then
    -- 1.33.0.  Only a DERIVED state transition reaches here, and only through
    -- Relationships.headline, so the player is never told the same shift twice
    -- in two different sentences.  A change with no headline (into NEUTRAL,
    -- say) is real but not news.
    local other = self.byId[event.with]
    line = Relationships.headline(name, other and self:spokenNameOf(other) or "the player",
                                  event.state)
  elseif kind == "news" then
    line = tostring(event.text)
  end
  if not line then return end
  self.news[#self.news + 1] = { tick = self.sim and self.sim.tick or 0, text = line }
  if #self.news > 40 then table.remove(self.news, 1) end
  -- TICKER VOLUME: quiet drops routine training/explore noise; full shows all.
  local volume = "normal"
  pcall(function() volume = tostring(mod.options:get("ticker_spam") or "normal") end)
  if volume == "quiet" and kind and (kind == "train" or kind == "explore"
      or kind == "heal" or kind == "wander") then
    return line
  end
  local headline = "WORLD NEWS  •  " .. line
  if self.ticker and self.ticker.text then
    self.tickerQueue = self.tickerQueue or {}
    local previous = self.tickerQueue[#self.tickerQueue] or self.ticker.text
    if previous ~= headline then
      self.tickerQueue[#self.tickerQueue + 1] = headline
      -- Headlines are transient UI, not history. Keep the newest few so rapid
      -- training events cannot create an unbounded, increasingly stale queue.
      while #self.tickerQueue > 8 do table.remove(self.tickerQueue, 1) end
    end
  else
    self.ticker = { text = headline, age = 0, duration = 8, offset = 0 }
  end
  return line
end

-- The map where the intro gauntlet plays out.
-- pret/pokered (and gen1recomp) use OAKS_LAB for the interior lab map and
-- PALLET_TOWN for the outdoor town.  The player receives their starter and
-- meets Oak *inside* OAKS_LAB, so that is the primary home for the gauntlet.
-- PALLET_TOWN is kept as a fallback for total conversions that only ship the
-- outdoor map.  Gen 2 has neither under these names, so the gauntlet simply
-- does not start there (same as 1.6.0).
-- pret/pokered and Yellow both use OAKS_LAB for the interior.  Resolve from
-- the live map table first (graph can lag if build ran on incomplete data).
--
-- 2.7.0 -- GOLD.  The comment above used to claim "Gen 2 has neither under
-- these names, so the gauntlet simply does not start there", and the code did
-- not do that: the candidate list held only Kanto maps and the fallback
-- RETURNED "OAKS_LAB" regardless.  On Gold that named a map the game does not
-- have, so the mod announced a gauntlet in Oak's Lab, told the player the
-- rivals were waiting there, and sent them to a room that does not exist.
--
-- Gold's equivalents are Elm's lab and New Bark Town.  They are candidates in
-- their own right rather than aliases, and the fallback is now nil -- a boot
-- with none of these really has nowhere to hold the gauntlet, and saying so is
-- better than naming a room at random.
local GAUNTLET_LAB_CANDIDATES = {
  "OAKS_LAB", "ELMS_LAB", "PALLET_TOWN", "NEW_BARK_TOWN",
}
local function mapExists(id)
  if not id then return false end
  local g = M.graph
  if type(g) == "table" then
    if type(g.has) == "function" then
      local ok, hit = pcall(g.has, g, id)
      if ok and hit then return true end
    elseif type(g.nodes) == "table" and g.nodes[id] then
      return true
    end
  end
  local maps = M.data and (M.data.maps or M.data.gen2Maps)
  if type(maps) == "table" and maps[id] then return true end
  local game = M.game
  local gmaps = game and game.data and game.data.maps
  if type(gmaps) == "table" and gmaps[id] then return true end
  return false
end
local function resolveGauntletLab(graph)
  for _, id in ipairs(GAUNTLET_LAB_CANDIDATES) do
    if mapExists(id) then return id end
    if type(graph) == "table" then
      if type(graph.has) == "function" then
        local ok, hit = pcall(graph.has, graph, id)
        if ok and hit then return id end
      elseif type(graph.nodes) == "table" and graph.nodes[id] then
        return id
      end
    end
  end
  -- No lab and no starting town in this boot. nil is the honest answer; every
  -- caller below treats it as "there is no gauntlet here".
  return nil
end
local function gauntletLabId()
  return resolveGauntletLab(M.graph)
end

-- Is the intro gauntlet possible in this game at all? Read by the intro
-- screen, so a boot with no lab never offers a battle it cannot stage.
function M:gauntletLab()
  return resolveGauntletLab(M.graph)
end

function M:gauntletPossible()
  return self:gauntletLab() ~= nil
end

-- The room's name as a player would say it. Known rooms get their real name;
-- anything else (a conversion, a randomiser) falls back to the spaced map id,
-- which is at least true -- unlike naming somebody else's laboratory.
local LAB_LABELS = {
  OAKS_LAB = "Oak's Lab",
  ELMS_LAB = "Elm's Lab",
  PALLET_TOWN = "Pallet Town",
  NEW_BARK_TOWN = "New Bark Town",
}

function M:labLabel(id)
  id = id or self:gauntletLab()
  if not id then return "the lab" end
  return LAB_LABELS[id] or Util.spaced(id)
end

-- Gen 2 only: rival id -> the numeric class constant its overworld object
-- must carry to engage a trainer battle.  Filled at registration time.
local GEN2_CLASS = {}
local REGISTERED_TRAINERS = {}

------------------------------------------------------------------------
-- Options
------------------------------------------------------------------------

-- The World: one combined Weather + AI settings page is registered by root Settings.lua.


local PACE = { slow = 3.0, normal = 1.5, fast = 0.6 }

local function worldAIEnabled()
  local ok,v=pcall(function() return mod.options:get("worldAI") end)
  if ok and v~=nil then return v==true or v=="on" end
  local saved
  pcall(function() saved=mod.save:get("world_ai_trainers_enabled") end)
  return saved==nil or saved==true or saved=="on"
end

local function runningOnIOS()
  local ok, os = pcall(function()
    return love and love.system and love.system.getOS and love.system.getOS()
  end)
  return ok and (os == "iOS" or os == "IOS")
end

-- Gen 2 tells us so by having no Gen 1 map-script dispatch.  We ask the
-- manifest-independent way: mod.game is Gold's Game2 instance, whose data
-- carries gen2Maps.  Nothing here changes behaviour except the routes we can
-- take to start a battle and show text.
local function detectGeneration(data)
  if data and (data.gen2Maps or data.gen2Trainers) and not data.maps then
    return 2
  end
  return 1
end

local function mapsTable(data)
  if not data then return {} end
  return data.maps or data.gen2Maps or {}
end

local function activeRoster()
  local chosen
  pcall(function()
    chosen = tonumber(mod.save:get("aiRivalCount"))
  end)
  local mode = mod.options:get("rivals")
  if not worldAIEnabled() then return {} end
  if chosen==0 then return {} end
  local base = RosterPolicy.active(ROSTER, chosen, mode)
  if mode == "off" then return base end
  local seen = {}
  for _, def in ipairs(base) do seen[def.id] = true end
  -- Rare Berserk-inspired characters are an independent world event rather
  -- than replacements for the ordinary four-rival cast. If the save rolled
  -- one, it joins the active world even when the player chose the default
  -- four-rival roster.
  for _, def in ipairs(ROSTER) do
    if def.rareSpecial and def.rareEnabled and not seen[def.id] then
      base[#base + 1] = def
      seen[def.id] = true
    end
  end
  return base
end

-- Registration can happen before Persistence:load restores a rival object.
-- Prefer a saved display name when one exists, otherwise use this save's
-- seeded assignment. That keeps engine trainer cards/battle labels aligned
-- with the rival object on old saves as well as new ones.
function M:rivalRegistrationName(def)
  local savedName
  pcall(function()
    local state = mod.save:get("state")
    local row = type(state) == "table" and type(state.rivals) == "table"
      and state.rivals[def.id] or nil
    savedName = type(row) == "table" and row.name or nil
    if (not savedName) and type(row) == "table"
       and type(def.name) == "string" then
      savedName = def.name
    end
  end)
  if type(savedName) == "string" and savedName ~= "" then return savedName end
  if def.fixedName and type(def.name) == "string" then return def.name end
  return (self.nameAssignments and self.nameAssignments[def.id])
    or Names.forDef(def, self:worldSeed(), ROSTER)
end

-- Keep engine trainer records aligned with live rival display names so
-- dialogue and battle banners show the same name after a rename.
function M:syncTrainerNames()
  local data = self.data
  if not data then return end
  local trainers = data.trainers or data.gen2Trainers
  if type(trainers) ~= "table" then return end
  for _, rival in ipairs(self.rivals or {}) do
    local def = rival.def
    local class = def and def.trainerClass
    local name = rival.name
    if type(class) == "string" and type(name) == "string" and name ~= "" then
      local rec = trainers[class]
      if type(rec) == "table" then
        rec.name = name
      end
      -- Gen 2 class-shaped records: update member rows too.
      if type(rec) == "table" and type(rec.trainers) == "table" then
        for _, member in ipairs(rec.trainers) do
          if type(member) == "table" then member.name = name end
        end
      end
      -- Force re-register so engines that cache the class name at register
      -- time pick up the rename for battle banners.
      if mod.content and mod.content.trainers
         and type(mod.content.trainers.register) == "function" then
        pcall(function()
          local payload = rec
          if type(payload) ~= "table" then
            -- Never invent a fallback trainer record here. On Gold a Gen 1
            -- `parties` record is schema-invalid; registration proper happens
            -- in registerGen1Trainers/registerGen2Trainers.
            return
          else
            payload.name = name
          end
          mod.content.trainers:register(class, payload)
        end)
      end
    end
    if def and def.gen2Shadow and type(trainers[def.gen2Shadow]) == "table" then
      local shadow = trainers[def.gen2Shadow]
      shadow.name = name
      if type(shadow.trainers) == "table" then
        for _, member in ipairs(shadow.trainers) do
          if type(member) == "table" then member.name = name end
        end
      end
    end
  end
end

------------------------------------------------------------------------
-- Content registration (load time)
------------------------------------------------------------------------

-- GEN 1 registration: one trainer record per rival.  `parties` must be
-- non-empty and valid at registration time because the schema checks it, but
-- the party the player actually fights never comes from here -- see the
-- trainer.party hook.  The placeholder is the rival's own first starter
-- preference, so even if the hook were somehow bypassed the battle is coherent
-- rather than empty.
-- Every cross-reference in a trainers record is schema-checked against the
-- MERGED tables, so naming a species, portrait or AI class the loaded game
-- does not have is a load error rather than a warning.  That is the correct
-- strictness, and it means this mod must resolve each reference against the
-- game in front of it: Yellow, a randomizer, a total conversion and the
-- ROM-free fixture dataset all carry different id sets.  A field whose target
-- is missing is OMITTED (the engine's own default covers it); only the party
-- species has no default, so it walks the preference chain and the record is
-- skipped entirely if nothing in it exists.
local function registerGen1Trainers(data)
  local versionKey = Version.starterKey(data)
  local pokemon = (data and data.pokemon) or {}
  local trainers = (data and data.trainers) or {}
  local aiClasses = (data and data.ai_classes) or {}

  for _, def in ipairs(ROSTER) do
    local species = Rival.firstAvailableStarter(def, versionKey, pokemon,
                                                nil, M:starterOpts())
    if species then
      -- Also recognise an already-merged record after a hot reload. The local
      -- guard covers boot + ready in one load; this covers a replaced mod
      -- chunk while the engine's content registry remains alive.
      if trainers[def.trainerClass] then
        REGISTERED_TRAINERS[def.trainerClass] = true
      end
      local record = {
        id = def.trainerClass,
        name = M:rivalRegistrationName(def),
        parties = { { { species = species, level = 5 } } },
        baseMoney = def.baseMoney or 50,
      }
      -- borrow the vanilla class's portrait and battle AI only where they
      -- exist; without them the engine draws its default pic and uses the
      -- generic AI, which is a coherent trainer, just a plainer one
      if trainers[def.basePic] then record.basePic = def.basePic end
      if aiClasses[def.aiClass] then record.aiClass = def.aiClass end
      if not REGISTERED_TRAINERS[def.trainerClass] then
        local ok = Util.guard("trainers:register:" .. def.id, function()
          mod.content.trainers:register(def.trainerClass, record)
        end)
        if ok then REGISTERED_TRAINERS[def.trainerClass] = true end
      end
    end
  end
end

-- GEN 2 registration.  Gold's trainers table is shaped differently: it is
-- keyed by CLASS, each class carries a numeric `index` and a `trainers`
-- MEMBER list, and each member row carries its own `party` (Gen 1's `parties`
-- list does not exist).  Registering a Gen 1-shaped record is a schema miss,
-- so the whole branch is Gen 2-shaped or nothing.
--
-- Two strategies, per rival:
--
--   * `gen2Shadow` names a vanilla class whose every member's party is
--     replaced in place.  The story rival's classes (RIVAL1, RIVAL2) become
--     this rival: no new record is registered, the class keeps its own index,
--     portrait, AI and member ids, and every scripted battle of that class --
--     however the story scripts call it -- is a battle against this rival.
--   * without one, a fresh class is registered past the highest index the
--     game has, so a rival with no vanilla slot to ride still exists as a
--     schema-valid class.  The player can meet it but Gold has no way to
--     start a trainer battle against it without the engine patch (docs).
local function registerGen2Trainers(data)
  local gen2 = data and (data.gen2Trainers or data.trainers)
  local classes = gen2 and gen2.classes
  if type(classes) ~= "table" then return end

  local maxIndex = 0
  for _, cls in pairs(classes) do
    if type(cls) == "table" and type(cls.index) == "number" then
      maxIndex = math.max(maxIndex, cls.index)
    end
  end
  local fresh = maxIndex

  local pokemon = (data and data.pokemon) or {}
  for _, def in ipairs(ROSTER) do
    local species = Rival.firstAvailableStarter(def, "gen2", pokemon,
                                                nil, M:starterOpts())
    if species then
      local placeholder = { { species = species, level = 5 } }
      local shadow = def.gen2Shadow and classes[def.gen2Shadow]
      if shadow then
        local members = shadow.trainers
        if type(members) == "table" and #members > 0 then
          for _, row in ipairs(members) do
            row.party = Util.copy(placeholder)
          end
          if def.baseMoney and not shadow.baseMoney then
            shadow.baseMoney = def.baseMoney
          end
        end
        -- the numeric class constant the spawned overworld object carries so
        -- the A press engages this class
        GEN2_CLASS[def.id] = type(shadow.index) == "number" and shadow.index or 0
      else
        fresh = fresh + 1
        local record = {
          id = def.trainerClass,
          name = M:rivalRegistrationName(def),
          index = fresh,
          baseMoney = def.baseMoney or 50,
          trainers = { {
            index = 1,
            id = def.id .. "1",
            name = def.name,
            party = Util.copy(placeholder),
          } },
        }
        local existing = classes[def.trainerClass]
        if existing then
          REGISTERED_TRAINERS[def.trainerClass] = true
          GEN2_CLASS[def.id] = tonumber(existing.index) or fresh
        else
          GEN2_CLASS[def.id] = fresh
        end
        if not REGISTERED_TRAINERS[def.trainerClass] then
          local ok = Util.guard("trainers:register:" .. def.id, function()
            mod.content.trainers:register(def.trainerClass, record)
          end)
          if ok then REGISTERED_TRAINERS[def.trainerClass] = true end
        end
      end
    end
  end
end


-- 7.3.0: Team Rocket and Ranger casts are save-seeded, but trainer CONTENT
-- cannot be save-seeded on Gold because the registry freezes before game.ready.
-- Predeclare a fixed number of legal slots while content is still mutable.
local FACTION_TRAINER_SLOTS_REGISTERED = {}
local function registerFactionTrainerSlots(data)
  if not (mod.content and mod.content.trainers
      and type(mod.content.trainers.register) == "function") then return end

  local isGen2 = detectGeneration(data) == 2
  local gen2 = data and data.gen2Trainers
  local classes = gen2 and gen2.classes
  local trainers = (data and data.trainers) or {}

  local function species(preferred, fallback)
    local p = data and (data.pokemon or data.gen2Pokemon) or {}
    if p[preferred] then return preferred end
    if p[fallback] then return fallback end
    for id in pairs(p) do return id end
    return fallback
  end

  local function one(prefix, i, defaultName, preferredSpecies, baseMoney, classIndex)
    local class = prefix .. tostring(i)
    if FACTION_TRAINER_SLOTS_REGISTERED[class] then return end
    if trainers[class] or (type(classes) == "table" and classes[class]) then
      FACTION_TRAINER_SLOTS_REGISTERED[class] = true
      return
    end

    local sp = species(preferredSpecies, "RATTATA")
    local record
    if isGen2 and type(classes) == "table" then
      record = {
        id = class,
        name = defaultName,
        index = classIndex,
        baseMoney = baseMoney,
        trainers = { {
          index = 1,
          id = class .. "_1",
          name = defaultName,
          party = { { species = sp, level = 5 } },
        } },
      }
    else
      record = {
        id = class,
        name = defaultName,
        parties = { { { species = sp, level = 5 } } },
        baseMoney = baseMoney,
      }
    end

    local ok = pcall(function() mod.content.trainers:register(class, record) end)
    if ok then FACTION_TRAINER_SLOTS_REGISTERED[class] = true end
  end

  -- Rocket.generate creates 7..13 members; Rangers.generate creates 4..10.
  for i = 1, 13 do
    one("AIR_ROCKET_ROCKET_", i, "ROCKET", "RATTATA", 30, 180 + i - 1)
  end
  for i = 1, 10 do
    one("AIR_RANGER_", i, "RANGER", "FEAROW", 80, 220 + i - 1)
  end
end

local function registerTrainers(data)
  registerFactionTrainerSlots(data)
  if detectGeneration(data) == 2 then
    registerGen2Trainers(data)
    return
  end
  registerGen1Trainers(data)
end

-- One shared handler for every Gen 1 map. Dynamic NPCs are only interactable
-- when they carry a text ID whose map has a matching map_scripts.talk entry;
-- world.interacted is notification-only/absent in several engine builds.
local function showGoldDialogue(game, ow, text, onDone)
  if detectGeneration(game and game.data or M.data) ~= 2 then return false end

  -- Gen2 World owns showText directly. The OverworldController facade's
  -- runner is a compatibility shim and is not the right lifecycle owner for
  -- a mod-spawned NPC conversation.
  if ow and type(ow.showText) == "function" then
    local ok, result = pcall(ow.showText, ow, tostring(text or ""), onDone)
    return ok and result ~= false
  end

  -- When the router receives a facade-ish object, resolve the live world.
  local world
  pcall(function()
    world = mod.world and mod.world.overworld and mod.world:overworld()
  end)
  if world and type(world.showText) == "function" then
    local ok, result = pcall(world.showText, world, tostring(text or ""), onDone)
    return ok and result ~= false
  end
  return false
end

local function rivalTalkHandler(game, ow, npc, done)
  local npcKey
  pcall(function() npcKey = npc and (npc.id or npc.name or (npc.def and npc.def.name)) end)
  local rival = M:rivalAtNpc(npcKey) or M:facedRival()
  if not rival then if done then done() end return end

  if M:gauntletActive() then
    local rows = M:talkGauntlet(rival)
    if type(rows) == "table" and ow and ow.runner then
      ow.runner:run(rows, { npc = npc, onDone = done })
    elseif done then done() end
    return
  end

  -- Normal world interaction: show the greeting text box first, then open
  -- the action menu once the player advances past it. This keeps dialogue
  -- readable and avoids the previous deferred-menu flag getting stuck.
  M.game = game or M.game
  if M.rivalInteractionOpen then
    if done then done() end
    return
  end
  M.rivalInteractionOpen = true
  if M.stolenRecovery and M.quests then
    for _,q in ipairs(M.quests.offers or {}) do
      if q.kind=="RETURN_STOLEN_POKEMON" and q.giverId==rival.id and (q.status=="ACTIVE" or q.status=="OFFERED") then
        if M.stolenRecovery:returnToOwner(game,rival,q.assetId) then q.status="COMPLETE"; q.completedTick=M.tick end
      end
    end
  end
  local recoveryLine = M.stolenRecovery and M.stolenRecovery:recognitionLine(game, rival)
  local warLine = (not recoveryLine and M.rivalWars) and M.rivalWars:requestLine(rival) or nil
  local line = recoveryLine or warLine or M.pendingLine or (M.dialogue and M.dialogue:greeting(rival)) or (rival.name .. ".")
  if recoveryLine and M.stolenRecovery then M.stolenRecovery:onRecognition(game, rival)
  elseif warLine and M.rivalWars then M.rivalWars:onTalkOffer(rival) end
  M.pendingLine = nil
  local rows = { { "show_text", tostring(line) } }
  local function finishOpen()
    -- Script callbacks still run inside the event dispatcher on some builds.
    -- Let core.update push the menu from the next idle overworld frame.
    M.pendingRivalMenu = rival.id
    M.rivalInteractionOpen = false
  M.pendingMapMaterialize = nil
  M.connectionYieldActive = false
  M.connectionYieldMap = nil
    if done then done() end
  end
  if showGoldDialogue(game, ow, line, finishOpen) then
    return
  end

  if ow and ow.runner and type(ow.runner.run) == "function" then
    local okRun, accepted = pcall(function()
      return ow.runner:run(rows, { npc = npc, onDone = finishOpen })
    end)
    if okRun and accepted ~= false then return end
  end

  if ow and type(ow.queueScript) == "function" then
    local okQ, accepted = pcall(function() return ow:queueScript(rows, {
      onDone = finishOpen
    }) end)
    if okQ and accepted ~= false then return end
  end

  -- No text path: still make the interaction useful and release the lock.
  finishOpen()
end


local function rocketTalkHandler(game, ow, npc, done)
  if not M.rocket then if done then done() end return end
  local npcKey
  pcall(function() npcKey = npc and (npc.id or npc.name or (npc.def and npc.def.name)) end)
  local member = M.rocket:memberAtNpc(npcKey, npcKey)
  if not member then
    local where=M:worldView()
    if where then
      member=M.rocket:memberAtNpc(nil, "AIR_ROCKET_"..tostring(where.rocketMemberId or ""))
    end
  end
  if not member then if done then done() end return end
  M.game=game or M.game
  if M.rivalBattleSequenceActive then if done then done() end return end
  if M.rocketDisguise and M.rocketDisguise:rocketFriendly(member) then
    local job=M.rocketDisguise:offerRocketJob(member)
    local price=M.rocketDisguise:rocketBallPrice(member)
    local line=job and ("ROCKET: "..tostring(job.dialogue)) or "ROCKET: Keep your head down and do your job."
    local rows={
      {"show_text","ROCKET: Need supplies? 5 ROCKET BALLS are $"..tostring(price)..". Want them?"},
      {"ask","Buy 5 ROCKET BALLS for $"..tostring(price).."?"},
      {"ai_rivals:buy_rocket_balls",member.id},
    }
    local asset,monPrice=M.rocketDisguise:stolenOffer(member)
    if asset then
      rows[#rows+1]={"show_text","ROCKET: I've also got a "..Util.spaced(asset.species)..". Don't ask where it came from. $"..tostring(monPrice).."."}
      rows[#rows+1]={"ask","Buy the "..Util.spaced(asset.species).." for $"..tostring(monPrice).."?"}
      rows[#rows+1]={"ai_rivals:buy_stolen_pokemon",member.id,asset.id}
    end
    rows[#rows+1]={"show_text",line}
    if ow and ow.runner and type(ow.runner.run)=="function" then
      pcall(function() ow.runner:run(rows,{npc=npc,onDone=done}) end)
    elseif ow and type(ow.queueScript)=="function" then pcall(function() ow:queueScript(rows) end); if done then done() end
    elseif done then done() end
    return
  end
  M.pendingRocket=member
  M.rivalBattleSequenceActive=true
  M.rivalBattleActiveRivalId=nil
  local class=M.rocket:classForMember(member)
  local rocketLine = M.rocket:dialogueFor(member, "challenge")
  local rows={{"show_text", rocketLine},{"start_battle","trainer",class,1}}
  if ow and ow.runner and type(ow.runner.run)=="function" then
    pcall(function() ow.runner:run(rows,{npc=npc,onDone=done}) end)
  elseif ow and type(ow.queueScript)=="function" then
    pcall(function() ow:queueScript(rows) end)
    if done then done() end
  elseif done then done() end
end

-- Register the stable text ID beside every loaded Gen 1 map. Compose
-- registration does not replace vanilla scripts; unsupported conversion maps
-- fail locally and retain the event-hook fallback.
local function registerTalkScripts(data)
  if detectGeneration(data) == 2 then
    -- Gold reaches a mod-spawned NPC through the Gen2Talk router on
    -- OverworldController.interact. This runs before the cart's built-in
    -- interaction ladder, so a runtime object needs no ROM scriptKey.
    -- See src/Gen2Talk.lua for the full reasoning.  Registering the handler
    -- is free; the router installs itself once a world exists.
    Gen2Talk.register("ai_rivals:rivals", function(world, npc)
      local key = Gen2Talk.npcKey(npc)
      local name, defName, runtimeId
      pcall(function()
        name = npc and npc.name
        defName = npc and npc.def and npc.def.name
        runtimeId = npc and npc.id
      end)
      local rival = M:rivalAtNpc(defName)
        or M:rivalAtNpc(name)
        or M:rivalAtNpc(key)
        or M:rivalAtNpc(runtimeId)
        or M:facedRival()
      if not rival then return false end
      local game = (world and world.game) or M.game or mod.game
      rivalTalkHandler(game, world, npc, nil)
      return true
    end, 40)
    Gen2Talk.register("ai_rivals:rocket", function(world, npc)
      if not M.rocket then return false end
      local key = Gen2Talk.npcKey(npc)
      local name
      pcall(function() name = npc and (npc.name or (npc.def and npc.def.name)) end)
      local member = M.rocket:memberAtNpc(key, name or key)
      if not member then return false end
      local game = (world and world.game) or M.game or mod.game
      rocketTalkHandler(game, world, npc, nil)
      return true
    end, 55)
    Gen2Talk.install()
    return
  end
  local ids = { OAKS_LAB = true, PALLET_TOWN = true }
  for id in pairs(mapsTable(data) or {}) do ids[id] = true end
  M.talkScriptMaps = M.talkScriptMaps or {}
  for id in pairs(ids) do
    if not M.talkScriptMaps[id] then
      local ok = pcall(function() mod.content.map_scripts:register(id, {
        priority = -5,
        talk = { [TALK_TEXT] = rivalTalkHandler, [ROCKET_TALK_TEXT] = rocketTalkHandler },
      }) end)
      if ok then M.talkScriptMaps[id] = true end
    end
  end
end

------------------------------------------------------------------------
-- Roster construction
------------------------------------------------------------------------

function M:seedAffectionGraph()
  local seed = tonumber(self.seedValue) or tonumber(self.pathSeed) or self:worldSeed() or 1
  for _, rival in ipairs(self.rivals or {}) do
    rival.bonds = type(rival.bonds) == "table" and rival.bonds or Relationships.new()
    Relationships.seedAffection(rival.bonds, "player", seed, rival.id)
    for _, other in ipairs(self.rivals or {}) do
      if other.id ~= rival.id then
        Relationships.seedAffection(rival.bonds, other.id, seed, rival.id)
      end
    end
    -- Apply hidden background disposition once. Existing saves keep their
    -- relationship history and receive only this small migration nudge.
    if rival.backgroundDispositionApplied ~= true then
      local playerBond = rival.bonds.player
      if playerBond then
        playerBond.affection = math.max(0, math.min(100,
          (tonumber(playerBond.affection) or 50)
            + (rival:backgroundDisposition("player") or 0) * 12))
      end
      for _, other in ipairs(self.rivals or {}) do
        if other.id ~= rival.id and rival.bonds[other.id] then
          local b = rival.bonds[other.id]
          b.affection = math.max(0, math.min(100,
            (tonumber(b.affection) or 50)
              + (rival:backgroundDisposition("rival") or 0) * 8))
        end
      end
      rival.backgroundDispositionApplied = true
    end
  end
end

function M:build(data)
  self.data = data
  self.generation = detectGeneration(data)
  -- which starting set the roster hands out; see src/Version.lua
  self.versionKey = Version.starterKey(data)
  -- 5.0.1: independently roll the three rare special characters once per
  -- save. The selected identities are then part of the roster for this world.
  Specials.apply(ROSTER, self:worldSeed(), data)
  -- 4.7.1: names are dealt once per save from the gender-specific 400-name
  -- pools. The saved world seed makes the cast stable across reloads.
  self.nameAssignments = Names.assign(self:worldSeed(), ROSTER)
  -- Character-creation overrides (named or randomised in the Oak speech).
  do
    local custom
    pcall(function() custom = mod.save:get("ai_rival_custom_names") end)
    if type(custom) ~= "table" and type(self.pendingIntroCustomNames) == "table" then
      custom = self.pendingIntroCustomNames
    end
    if type(custom) == "table" then
      for id, name in pairs(custom) do
        if type(id) == "string" and type(name) == "string" and name ~= "" then
          self.nameAssignments[id] = name
        end
      end
      self.pendingIntroCustomNames = nil
    end
  end
  self.graph = MapGraph.build(mapsTable(data))
  -- 5.0.1: Team Rocket is a dark reflection of the rival simulation. It gets
  -- its own save-seeded cast, economy, operations and strategic map travel.
  self.rocket = RocketManager.new(self, data, { M = Names.BOYS, F = Names.GIRLS })
  self.rangers = RangersManager.new(self, data, { M = Names.BOYS, F = Names.GIRLS })
  -- Trainer slots were predeclared before the registry froze. At runtime we
  -- only bind the seeded cast's names/parties into those existing records.
  pcall(function() self.rocket:bindTrainerSlots() end)
  pcall(function() self.rangers:bindTrainerSlots() end)
  self.factions = Factions.new(nil)
  self.rocketDisguise = RocketDisguise.new(self)
  self.doubleAgent = DoubleAgent.new(self)
  self.stolenRecovery = StolenRecovery.new(self)
  self.rivalWars = RivalWars.new(self)
  pcall(function() self.rocketDisguise:install() end)
  self.scheduledTournaments = {}
  self.quests = Quests.new(self)
  self.worldState = WorldState.new(self)
  pcall(function() self.quests:refresh(true) end)
  -- 4.2.0: build the Kanto trainer phone directory from the loaded ROM data.
  -- The directory is derived at runtime, so Red/Blue/Yellow keep their own
  -- trainer roster and no ROM-derived trainer data is shipped by the mod.
  self.phoneTrainerDefs = Comms.discoverTrainers(data, self.graph, self.generation)
  self.byTrainerClass = Comms.indexByTrainerClass(self.phoneTrainerDefs)
  self.phoneContactObjects = {}
  -- 2.5.0: the phone, absorbed from 1.30. Guarded at every step -- Gen 1 has
  -- no Pokegear, so on Red/Blue/Yellow the numbers exist for save
  -- compatibility and calls are delivered through the news ticker instead.
  self.phone = Phone.new(self)
  self.comms = self.comms or Comms.new(nil)
  Util.guard("phone", function() self.phone:bootstrapAll() end)

  self.dialogue = Dialogue.new(LINES, GYMS,
    { compat = self.compat, save = mod.save,
      relationships = function() return self:relationshipsEnabled() end })

  -- Resolve the data-file map name lists against the game that is actually
  -- loaded, so a name this cache does not have is dropped rather than routed
  -- to.  Yellow renames a couple of maps; a total conversion renames many.
  -- The ladder itself is per generation: Gold's badges are Johto's, so the
  -- gen2 section carries its own order/centers/training lists.
  local source = self.generation == 2 and GYMS.gen2 or GYMS
  local gyms = Util.copy(source)
  gyms.centers = self.graph:filterExisting(source.centers)
  gyms.training = self.graph:matching(source.trainingPrefixes)
  -- the badge ladder is the ENGINE's, not ours: constants.badges is what the
  -- player's own trainer card reads, so the rivals climb the same one
  local badges = data and data.constants and data.constants.badges
  if type(badges) == "table" and #badges > 0 then
    local order = {}
    for _, entry in ipairs(badges) do
      local id = type(entry) == "table" and entry.id or entry
      if type(id) == "string" and gyms.byBadge[id] then order[#order + 1] = id end
    end
    if #order > 0 then gyms.order = order end
  end
  self.gyms = gyms

  local ctx = { data = data, personalities = PERSONALITIES,
                graph = self.graph, gyms = gyms,
                -- AI.Destination.HEAL and Rival:isAtPokemonCenter/
                -- blackoutToNearestPokemonCenter read ctx.healingMaps; the
                -- one place that ever built the actual list wrote it onto
                -- gyms.centers instead (see Rival.lua's OWN correct read at
                -- self.ctx.gyms.centers). The three readers therefore always
                -- saw nil/empty -- a rival told to HEAL routed to "wherever
                -- it already is", and a blackout had no real Center to fall
                -- back to. Same table, both names, until the readers are
                -- unified onto gyms.centers directly.
                healingMaps = gyms.centers,
                versionKey = self.versionKey,
                compat = self.compat, save = mod.save,
                -- the emergency-party fallback in Rival:battleParty needs the
                -- same deal the manager uses, or it would hand out a species
                -- from a different permutation
                starterSeed = self:worldSeed(), roster = ROSTER,
                weatherFx = self.compat and self.compat:present("weather") or false,
                assignedNames = self.nameAssignments,
                -- 1.33.0: the relationship gate reaches attemptDuel, which is
                -- handed a rival rather than a world view. Refreshed each tick
                -- below so toggling the option takes effect immediately.
                relationships = self:relationshipsEnabled(),
                manager = self }
  self.rivalContext = ctx

  self.rivals, self.byId = {}, {}
  for _, def in ipairs(activeRoster()) do
    local rival = Rival.new(def, ctx)
    TrainerClasses.assign(rival,"RIVAL",(ctx.starterSeed or 1)+(#self.rivals*97))
    self.rivals[#self.rivals + 1] = rival
    self.byId[def.id] = rival
  end
  self.rivalCount = #self.rivals
  self:seedAffectionGraph()

  local performance = mod.options:get("performance") or "balanced"
  self.sim = Simulation.new({
    budget = performance == "low" and 1 or (performance == "full" and 4 or 2),
    socialInterval = performance == "low" and 4
      or (performance == "full" and 1 or 2),
    tickSeconds = PACE[mod.options:get("pace")] or PACE.normal,
  })
  self.tournaments = Tournaments.new(self)
  self.ready = true
  pcall(function() self:syncTrainerNames() end)
end

-- Apply the new-game roster-size answer immediately. Trainer and sprite
-- definitions remain registered for compatibility, but only these live Rival
-- objects are simulated, spawned, saved, or placed in the intro gauntlet.
-- Clone Caller: grow or shrink the live ordinary-rival roster by delta.
-- Newly summoned rivals may receive custom names via pendingCloneNames.
-- Summoned clones start weaker (low levels) so early-game +10 is safer.
function M:adjustRivalCount(delta, customNames)
  delta = math.floor(tonumber(delta) or 0)
  if delta == 0 then return false, "No change." end
  local ordinary = RosterPolicy.ordinaryCount(ROSTER)
  local current = 0
  pcall(function() current = tonumber(mod.save:get("aiRivalCount")) or #self.rivals end)
  if current < 1 then current = math.min(4, ordinary) end
  local target = RosterPolicy.clamp(current + delta, ordinary, current)
  target = math.max(1, math.min(ordinary, math.floor(tonumber(target) or current)))
  if target == current and delta > 0 then
    return false, "All ordinary rivals are already active."
  end
  if target == current and delta < 0 then
    return false, "At least one rival must remain."
  end
  -- Soft lag guard: prefer despawning distant rivals first when removing.
  if delta < 0 and mod.options:get("clone_lag_guard") ~= false then
    pcall(function() self:despawnDistantRivals(math.abs(delta)) end)
  end
  pcall(function() mod.save:set("aiRivalCount", target) end)
  if type(customNames) == "table" and self.nameAssignments then
    for id, name in pairs(customNames) do
      if type(id) == "string" and type(name) == "string" and name ~= "" then
        self.nameAssignments[id] = name
      end
    end
    pcall(function()
      local existing = mod.save:get("ai_rival_custom_names") or {}
      if type(existing) ~= "table" then existing = {} end
      for id, name in pairs(customNames) do existing[id] = name end
      mod.save:set("ai_rival_custom_names", existing)
    end)
  end
  local before = {}
  for _, rival in ipairs(self.rivals or {}) do before[rival.id] = true end
  local ok = self:setRivalCount(target)
  if ok then
    local badges = 0
    pcall(function() badges = self:playerBadgeCount() or 0 end)
    local starterLv = math.max(5, 5 + badges)
    for _, rival in ipairs(self.rivals or {}) do
      if rival and not before[rival.id] then
        if #(rival.party or {}) == 0 and self.seed then
          pcall(function() self:seed(rival) end)
        end
        -- Weaker clones: clamp party levels near badge-scaled starter level.
        for _, mon in ipairs(rival.party or {}) do
          if type(mon) == "table" and tonumber(mon.level) then
            mon.level = math.min(tonumber(mon.level) or starterLv, starterLv + 2)
          end
        end
        rival.cloneSummoned = true
      end
      if type(customNames) == "table" and customNames[rival.id] then
        rival.name = customNames[rival.id]
      end
    end
    pcall(function() self:syncTrainerNames() end)
    local diff = target - current
    if diff > 0 then
      return true, "Summoned " .. tostring(diff) .. " rival"
        .. (diff == 1 and "" or "s") .. " (" .. tostring(target) .. " total)."
    end
    return true, "Removed " .. tostring(-diff) .. " rival"
      .. (diff == -1 and "" or "s") .. " (" .. tostring(target) .. " total)."
  end
  return false, "Could not change rival count."
end

-- Prefer despawning rivals far from the player before roster shrink.
function M:despawnDistantRivals(count)
  count = math.max(1, math.floor(tonumber(count) or 1))
  local world = self:worldView()
  local px, py, pmap = world and world.playerX, world and world.playerY, world and world.playerMap
  local ranked = {}
  for _, rival in ipairs(self.rivals or {}) do
    local dist = 9999
    if pmap and rival.map == pmap and rival.x and rival.y and px and py then
      dist = math.abs(rival.x - px) + math.abs(rival.y - py)
    elseif pmap and rival.map ~= pmap then
      dist = 5000
    end
    ranked[#ranked + 1] = { rival = rival, dist = dist }
  end
  table.sort(ranked, function(a, b) return a.dist > b.dist end)
  for i = 1, math.min(count, #ranked) do
    local rival = ranked[i].rival
    local npcId = self.spawned and self.spawned[rival.id]
    if npcId then
      pcall(function() mod.world:removeNpc(npcId) end)
      self.spawned[rival.id] = nil
    end
  end
end

-- Player breeding: combine two party slots into an egg-level offspring in box.
function M:breedPartySlots(slotA, slotB)
  local save = self.game and self.game.save
  local party = save and save.party
  if type(party) ~= "table" then return false, "No party." end
  slotA = math.floor(tonumber(slotA) or 0)
  slotB = math.floor(tonumber(slotB) or 0)
  local a, b = party[slotA], party[slotB]
  if not (type(a) == "table" and type(b) == "table") then
    return false, "Pick two party Pokémon."
  end
  if slotA == slotB then return false, "Pick two different Pokémon." end
  local speciesA = a.species or a.speciesId or a.id
  local speciesB = b.species or b.speciesId or b.id
  if type(speciesA) == "table" then speciesA = speciesA.id or speciesA.name end
  if type(speciesB) == "table" then speciesB = speciesB.id or speciesB.name end
  if type(speciesA) ~= "string" or type(speciesB) ~= "string" then
    return false, "Invalid party data."
  end
  -- Offspring inherits species of the first parent (simple Day Care style).
  local babySpecies = speciesA
  local level = 1
  local box = save.box or save.pc or save.storage
  if type(box) ~= "table" then
    save.box = save.box or {}
    box = save.box
  end
  local baby = { species = babySpecies, level = level, hp = 1, maxHp = 1 }
  box[#box + 1] = baby
  return true, "An Egg hatched into " .. Util.spaced(babySpecies) .. "! Sent to the PC."
end

function M:scheduleTournament(hostRivalId, count, mode, venueMap, delayTicks)
  delayTicks = math.max(30, math.floor(tonumber(delayTicks) or 120))
  local tick = (self.sim and self.sim.tick) or 0
  self.scheduledTournaments = self.scheduledTournaments or {}
  local entry = {
    hostId = hostRivalId,
    count = math.max(3, math.floor(tonumber(count) or 3)),
    mode = mode == "DOUBLE" and "DOUBLE" or "SINGLE",
    venueMap = venueMap,
    fireAt = tick + delayTicks,
    created = tick,
  }
  self.scheduledTournaments[#self.scheduledTournaments + 1] = entry
  return true, "Tournament scheduled. Check Pokégear for the reminder."
end

function M:updateScheduledTournaments()
  local list = self.scheduledTournaments
  if type(list) ~= "table" or #list == 0 then return end
  local tick = (self.sim and self.sim.tick) or 0
  local remain = {}
  for _, entry in ipairs(list) do
    if entry.fireAt and tick >= entry.fireAt then
      local ok, line = self:arrangeTournament(entry.hostId, entry.count, entry.mode, entry.venueMap)
      if ok then
        self:addNews({ name = "TOURNAMENT" }, {
          kind = "news", text = line or "A scheduled tournament is starting!",
        })
      end
    else
      remain[#remain + 1] = entry
    end
  end
  self.scheduledTournaments = remain
end

-- Offer a one-off quest when the player calls a rival.
function M:phoneQuestOffer(rival)
  if not (rival and self.quests) then return nil end
  local makers = {
    function() return self.quests.giveItemOffer and self.quests:giveItemOffer() end,
    function() return self.quests.tradeSpeciesOffer and self.quests:tradeSpeciesOffer() end,
    function() return self.quests.accompanyOffer and self.quests:accompanyOffer() end,
    function() return self.quests.defeatRivalOffer and self.quests:defeatRivalOffer() end,
  }
  for _, mk in ipairs(makers) do
    local q
    pcall(function() q = mk() end)
    if type(q) == "table" then
      q.giver = rival.name
      q.giverId = rival.id
      q.source = "phone"
      self.quests.offers = self.quests.offers or {}
      self.quests.offers[#self.quests.offers + 1] = q
      return q
    end
  end
  return nil
end

-- In-person quest accept / claim while talking to a rival.
function M:rivalQuestItems(rival)
  local items = {}
  if not (rival and self.quests) then return items end
  for _, q in ipairs(self.quests.offers or {}) do
    if q.giverId == rival.id then
      if q.status == "OFFERED" then
        items[#items + 1] = {
          label = "ACCEPT: " .. tostring(q.title or "QUEST"):sub(1, 16),
          value = "_qaccept:" .. tostring(q.id),
        }
      elseif q.status == "COMPLETE" then
        items[#items + 1] = {
          label = "CLAIM: " .. tostring(q.title or "QUEST"):sub(1, 16),
          value = "_qclaim:" .. tostring(q.id),
        }
      elseif q.status == "ACTIVE" and q.kind == "GIVE_ITEM" then
        items[#items + 1] = {
          label = "HAND OVER ITEM",
          right = tostring(q.item or "ITEM"):sub(1, 10),
          value = "_help",
        }
      elseif q.status == "ACTIVE" and q.kind == "TRADE_SPECIES" then
        items[#items + 1] = {
          label = "TRADE FOR QUEST",
          value = "_trade",
        }
      elseif q.status == "ACTIVE" and q.kind == "ACCOMPANY" then
        items[#items + 1] = {
          label = "START WALKING",
          value = "_accompany",
        }
      end
    end
  end
  return items
end

function M:setRivalCount(value)
  local count = RosterPolicy.clamp(value, RosterPolicy.ordinaryCount(ROSTER), 4)
  if not self.rivalContext then return false end
  local old = self.byId or {}
  local selected = activeRoster()
  local rivals, byId = {}, {}
  for _, def in ipairs(selected) do
    local rival = old[def.id] or Rival.new(def, self.rivalContext)
    TrainerClasses.assign(rival,"RIVAL",(self:worldSeed() or 1)+(#rivals*97))
    rivals[#rivals + 1], byId[def.id] = rival, rival
  end
  count = #rivals
  for id, rival in pairs(old) do
    if not byId[id] then
      local npcId = self.spawned and self.spawned[id]
      if npcId then pcall(function() mod.world:removeNpc(npcId) end) end
      if self.spawned then self.spawned[id] = nil end
      if self.companionId == id then self.companionId = nil end
      if self.pending and self.pending.id == id then self.pending = nil end
    end
  end
  self.rivals, self.byId, self.rivalCount = rivals, byId, count
  pcall(function() self:syncTrainerNames() end)
  if self.gauntlet and type(self.gauntlet.order) == "table" then
    -- 5.0.9: THE OPENING GAUNTLET IS ORDINARY RIVALS ONLY.
    --
    -- A rolled rare special was being queued in Oak's lab, so about one save
    -- in ten opened with a Lv5 starter against a rival holding MEWTWO. The
    -- special still joins the world -- that is the whole point of the layer --
    -- it just does not stand in the intro queue. Same reasoning as 3.3.0's
    -- "the gauntlet is capped, the world is not".
    local order = {}
    for _, rival in ipairs(rivals) do
      if RosterPolicy.isOrdinary(rival.def) then order[#order + 1] = rival.id end
    end
    self.gauntlet.order = order
    self.gauntlet.index = math.min(tonumber(self.gauntlet.index) or 1, #order)
    if self.gauntlet.active then
      local lab = self.gauntlet.lab or gauntletLabId()
      for _, rival in ipairs(rivals) do
        rival.map, rival.x, rival.y = lab, nil, nil
        rival.destination, rival.route, rival.routeIndex = nil, nil, 1
        rival.path = nil
        if #rival.party == 0 then
          local species = Rival.firstAvailableStarter(
            rival.def, self.versionKey, self.data and self.data.pokemon,
            nil, self:starterOpts(nil, nil, nil, rival.personality))
          if species then rival:markStarter(rival:addPokemon(species, 5)) end
        end
        rival:setState("IDLE", "in the lab")
      end
    end
  end
  return true
end

-- A brand new rival: put it on its home map with one starter, the way the
-- player starts.  Growth is earned from here, never granted.
function M:seed(rival)
  local def = rival.def
  local home
  for _, id in ipairs(homeMapsFor(def)) do
    if self.graph:has(id) then home = id break end
  end
  rival.map = home or next(self.graph.nodes)
  rival.x, rival.y = nil, nil
  -- Seed a starter only into an EMPTY party.  M:load re-seeds on every
  -- empty bucket during boot + New Game; an unguarded add used to stack a
  -- starter per call, which is how a rival reached the lab with a full
  -- party of starters.
  if #rival.party == 0 then
    local species = Rival.firstAvailableStarter(def, self.versionKey,
                                                self.data and self.data.pokemon,
                                                nil, self:starterOpts(nil, nil, nil, rival.personality))
    if species then rival:markStarter(rival:addPokemon(species, 5)) end
  end
  rival:setState("IDLE", "new")
  AI.evaluate(rival, self:worldView())
end

-- ------------------------------------------------------------------
-- The intro gauntlet (Oak's lab)
-- ------------------------------------------------------------------
-- On a new game every rival starts in Oak's lab and battles the player IN
-- TURN, once each, before anyone heads out into Kanto.  The player's party
-- is healed between battles, so each fight is the fair starter-vs-starter
-- showdown the moment is supposed to be.
--
-- Rules that keep it honest and removable:
--   * It is a NEW-GAME feature: a save that has no gauntlet bucket (an older
--     save, or one made mid-playthrough) simply plays without one.
--   * Gen 2 has no Oak's lab, so the gate is `does the graph have the map`.
--   * During the gauntlet the world tick is paused: no rival grinds, catches
--     or leaves town until the player has fought them all.
--   * The battles are forced through the talk verb (a plot battle, so the
--     RIVAL DUELS option is not consulted), one rival per turn, in roster
--     order.  A rival the player has not reached yet just says who is next.
--   * The healing is the one vanilla write this mod makes, and it is exactly
--     the engine's own heal (`Pokemon.heal`) applied to the player's party.


-- The rival whose turn it is, or nil when the gauntlet is over/absent.

-- Start the gauntlet: put every rival in the lab with its starter.  Returns
-- false (and leaves normal seeding to the caller) when the game has no lab
-- or the roster is empty.

-- True once the vanilla lab rival (Blue) has been fought.  AI rivals only
-- start their walk-up after this beat so they do not interrupt Oak/Blue.


-- Keep every rival parked in the lab until the intro gauntlet is finished.

-- The engine's own heal, applied to the player's party.  This is the one
-- vanilla write the mod makes, and it is scoped to the gauntlet only.

-- A gauntlet line, with {NAME} rewritten to be the rival the player must
-- battle NEXT (the speaker in these buckets is the one waiting).

-- The talk-verb answer while the gauntlet is active.  The current rival
-- forces a battle (refusing only while the player has no Pokemon yet); every
-- other rival just names who is next.

-- A gauntlet battle is over: heal the player, advance the turn, and when the
-- last rival has been fought, let everyone leave the lab and start living.

-- Scatter destinations so the four do not all stack on one tile.
--
-- 2.10.0: version-keyed. These were Kanto-only, and Gold's map table contains
-- every Kanto map, so on Gold the four were released straight into postgame
-- content the player cannot reach for another forty hours. Johto's opening
-- corridor is the equivalent: New Bark -> Route 29 -> Cherrygrove -> Route 30,
-- ending at Violet, whose Gym is the first on the Johto ladder in data/gyms.
--
-- A map this game does not have is dropped by the caller, exactly as an
-- unknown Gen 1 map already was, so a conversion shipping neither set simply
-- keeps its rivals where the gauntlet left them.
local POST_LAB_STARTS_BY_KEY = {
  default = {
    { map = "ROUTE_1",       dest = "VIRIDIAN_CITY" },
    { map = "VIRIDIAN_CITY", dest = "ROUTE_2" },
    { map = "ROUTE_2",       dest = "PEWTER_CITY" },
    { map = "PALLET_TOWN",   dest = "ROUTE_1" },
  },
  gen2 = {
    { map = "ROUTE_29",        dest = "CHERRYGROVE_CITY" },
    { map = "CHERRYGROVE_CITY", dest = "ROUTE_30" },
    { map = "ROUTE_30",        dest = "VIOLET_CITY" },
    { map = "NEW_BARK_TOWN",   dest = "ROUTE_29" },
  },
}

local function postLabStarts()
  local key = M and M.versionKey
  return POST_LAB_STARTS_BY_KEY[key or "default"]
    or POST_LAB_STARTS_BY_KEY.default
end

-- Release rivals into the world: remove lab NPCs, send them onto Kanto
-- routes, and start the normal AI (train / heal / gym).

-- Character creation and recovery use the same durable path. Skipping awards
-- no wins, badges, money or story flags; it only retires the optional intro
-- sequence and places the untouched rivals at their legal world starts.

-- How far (Manhattan tiles) the current rival will notice the player and
-- begin the walk-up. Lab interiors are small; 10 still covers the whole room
-- and any larger converted labs.
local GAUNTLET_DETECT = 10
-- Tiles that count as "in the player's face" and ready to battle.
local GAUNTLET_ENGAGE = 1
-- Seconds between each one-tile step (walking cadence).
local GAUNTLET_STEP_S = 0.18

-- Move only the rival object. Companions use FOLLOWERS_EX's entity movement
-- fields, letting NPC:update animate the step without the shared script queue.
-- Other movement retains the compatibility facade used by autonomous rivals.
function M:moveRivalNpc(rival, x, y, facing, onDone)
  rival.map = rival.map or gauntletLabId()
  local mapId = rival.map
  local npcId = self.spawned and self.spawned[rival.id]
  if rival.walking then return false end
  local handle
  pcall(function()
    if mod.world and mod.world.npc then
      handle = mod.world:npc(mapId, npcId or ("AIR_" .. tostring(rival.id)))
    end
  end)
  local entity = self.companionId == rival.id and self:liveRivalEntity(rival)
  local ex = entity and math.abs((entity.cellX or rival.x or x) - x) or 0
  local ey = entity and math.abs((entity.cellY or rival.y or y) - y) or 0
  if entity and facing and ex + ey == 1 then
    rival.walking, rival.walkAge, rival.facing = true, 0, facing
    entity.facing, entity.hopStep = facing, nil
    entity.targetX, entity.targetY = x, y
    local ow = self:activeMap()
    local p = ow and ow.player
    entity.stepFrames = (p and (p.stepFramesCur or p.stepFrames)) or 16
    entity.moving, entity.progress = true, 0
    rival.walkTarget = { x = x, y = y, onDone = onDone }
    return true
  end
  local localMove = handle and (handle.setPosition or handle.teleport)
  if localMove then
    local ok, moved = pcall(localMove, handle, x, y, facing)
    if ok and moved ~= false then
      rival.x, rival.y, rival.facing = x, y, facing or rival.facing
      rival.spawnedAt = { x, y }
      rival.walking = false
      if onDone then pcall(onDone) end
      return true
    end
  end

  -- Engines exposing only the global scripted queue keep the existing
  -- interactable object in place; input responsiveness takes priority over a
  -- cosmetic step, and the follower retries on a later map/pulse.
  rival.walking = false
  return false
end

-- One tile toward the player. Returns true when within engage range.
function M:labWalkGrid()
  local overview
  pcall(function()
    if mod.world and mod.world.mapOverview then
      overview = mod.world:mapOverview()
    end
  end)
  local grid = Pathfinder.grid(overview)
  if grid and grid.w and grid.h and grid.w >= 3 then return grid end
  -- Synthetic lab: walkable center aisle between bookcase blocks.
  -- '.' walkable, ' ' blocked (shelves / walls).
  local rows = {
    "          ",
    "  ......  ",
    "  ......  ",
    "  ......  ",
    "  ......  ",
    "  ......  ",
    "  ......  ",
    "  ......  ",
  }
  return Pathfinder.grid({ rows = rows, width = 10, mapId = "OAKS_LAB" })
end

-- One tile toward the player along a walkable path (aisles, not shelves).


-- Queue the challenge dialogue + trainer battle for the current rival.
function M:getOverworld()
  local game = self.game
  if not game then return nil end

  -- Gold / Game2 owns one persistent World at game.world. It is not a stack
  -- state and does not carry Gen 1's isOverworld marker. Deferred interaction
  -- handoffs (dialogue -> rival menu, battle -> result UI, etc.) still need
  -- the live world so they can observe its textbox/runner becoming idle.
  if game.world and game.world.map then
    return game.world
  end

  -- Red / Blue / Yellow.
  if game.overworld and game.overworld.isOverworld then
    return game.overworld
  end
  local stack = game.stack and game.stack.states
  if type(stack) == "table" then
    for i = #stack, 1, -1 do
      if stack[i].isOverworld then return stack[i] end
    end
  end
  return nil
end

-- True when Oak/text/cutscenes are done and a new script may run.
function M:overworldIdle()
  local ow = self:getOverworld()
  if not ow then return false end
  if ow.transitioning or ow.mapSetup then return false end
  if ow.runner and ow.runner.isRunning and ow.runner:isRunning() then
    return false
  end
  if ow.scriptMoves and #ow.scriptMoves > 0 then return false end

  -- Gold keeps dialogue/choices directly on World instead of pushing the
  -- overworld underneath a textbox state.
  if ow.textbox or ow.choicebox then return false end

  -- Gen 1: a text/menu state stacked over the world means "not yet".
  local game = self.game
  local stack = game and game.stack
  if stack and stack.top and game and game.world ~= ow and stack:top() ~= ow then
    return false
  end
  return true
end

-- Some iOS stack implementations keep a closing ListMenu as stack:top() for
-- several frames. This weaker check is safe for deferred UI handoffs: scripts
-- and transitions must be idle, but stale stack identity cannot brick input.
function M:overworldRunnerIdle()
  local ow = self:getOverworld()
  if not ow or ow.transitioning or ow.mapSetup then return false end
  if ow.runner and ow.runner.isRunning and ow.runner:isRunning() then return false end
  if ow.scriptMoves and #ow.scriptMoves > 0 then return false end
  if ow.textbox or ow.choicebox then return false end
  return true
end

-- 7.3.7: one authoritative gate for EVERY runtime-NPC mutation.
-- Yellow's follower/Pikachu setup can continue for a few frames after the
-- logical map id has changed. Merely waiting for map.entered is insufficient:
-- simulation arrival, stale-handle repair, Rocket/Ranger refresh and companion
-- repair could all call spawnFor independently. No subsystem may materialise
-- an AI actor until the new overworld is genuinely settled.
function M:runtimeObjectsSafe(mapId)
  local ow = self:getOverworld()
  if not ow then return false end
  if ow.transitioning or ow.mapSetup then return false end

  local game = self.game
  if game and game.transition then return false end

  local world = self:worldView()
  if not world or not world.playerMap then return false end
  if mapId and world.playerMap ~= mapId then return false end
  if self.mapAllowsRuntimeActors and not self:mapAllowsRuntimeActors(mapId or world.playerMap) then
    return false
  end

  -- The transition/follower code owns the player's motion state. Waiting for
  -- the first stationary frame avoids editing the people list while Yellow is
  -- transferring Pikachu across the Pallet/Route 1 seam.
  if world.playerMoving then return false end
  if self.connectionYieldActive then return false end
  if self.playerNearConnectionSeam and self:playerNearConnectionSeam(world) then
    return false
  end


-- 7.4.1 stability policy: seamless connected maps own a live neighbour/object
-- graph. Runtime NPC injection/removal in that graph has proven unsafe on
-- mobile builds (Yellow Pallet/Route 1 and Route 1/Viridian hard exits).
-- Live runtime injection remains disabled on seamless connected maps.
-- 7.4.2 restores visible rivals through map-owned static slots prepared
-- before setMap builds the engine's people list.
function M:mapAllowsRuntimeActors(mapId)
  if not mapId then return false end
  local data = self.data or (self.game and self.game.data)
  if type(data) ~= "table" then return false end
  local maps = data.gen2Maps or data.maps
  local def = maps and maps[mapId]
  if type(def) ~= "table" then return false end
  local conns = def.connections
  if type(conns) == "table" then
    for _, conn in pairs(conns) do
      if conn then return false end
    end
  end
  return true
end

  if ow.textbox or ow.choicebox then return false end
  if ow.runner and ow.runner.isRunning and ow.runner:isRunning() then return false end
  return true
end


-- 7.4.0: universal connection buffer. Dynamic NPCs must not survive close
-- enough to a connected-map edge that the engine can re-root the map while
-- their runtime objects are still present. This is deliberately map-agnostic:
-- every route/town/city connection in every supported game uses the same rule.
function M:playerNearConnectionSeam(world)
  world = world or self:worldView()
  if not (world and world.playerMap and world.playerX and world.playerY) then
    return false
  end

  local overview
  pcall(function()
    if mod.world and mod.world.mapOverview then
      overview = mod.world:mapOverview()
    end
  end)
  local grid = overview and Pathfinder.grid(overview)
  if not grid then return false end

  local maps = self.data and (self.data.gen2Maps or self.data.maps)
  local def = maps and maps[world.playerMap]
  local conns = def and def.connections
  if type(conns) ~= "table" then return false end

  local x, y = world.playerX, world.playerY
  local w, h = grid.w or grid.width or 0, grid.h or grid.height or 0
  if w < 2 or h < 2 then return false end

  -- Three cells gives the runtime layer at least one full update before the
  -- player's next held-direction step can cross the seam.
  local margin = 3
  for dir, conn in pairs(conns) do
    if conn then
      local d = tostring(dir):lower()
      if (d == "north" or d == "up") and y <= margin then return true end
      if (d == "south" or d == "down") and y >= h - 1 - margin then return true end
      if (d == "west" or d == "left") and x <= margin then return true end
      if (d == "east" or d == "right") and x >= w - 1 - margin then return true end
    end
  end
  return false
end

function M:updateConnectionYield(world)
  self.connectionYieldActive = false
  self.connectionYieldMap = nil
  return false
end

-- Queue the challenge. Prefer OverworldState:queueScript (FIFO drain when
-- idle) -- WorldAPI:queueScript refuses while Oak is still talking.


------------------------------------------------------------------------
-- Persistence
------------------------------------------------------------------------
-- Everything lives under this mod's own namespaced bucket, which the engine
-- routes into save.modData.  Removing the mod leaves an unread bucket behind
-- and nothing else: no vanilla flag, badge, item or party slot is touched by
-- any code in this mod, which is what makes it removable.





-- GEN 2: the class records are the live-party seam.  Trainers.party builds the
-- battle mons out of the class member's `party` rows at battle start, so the
-- rows are written through every time the rival's team can have changed and
-- the party the player fights is always this rival's actual team.  Gen 1's
-- trainer.party hook does the same job on the other side of the build.
function M:gen2ClassId(rival)
  return GEN2_CLASS[rival and rival.id]
end



-- Version handling for future formats.  A bucket from a newer version than we
-- understand is left alone and the rivals re-seed, which loses their progress
-- but never corrupts the save; a bucket from an older one is migrated here.
mod.migrations:add("0.0.0", function(save)
  local bucket = save and save.modData and save.modData.ai_rivals
  if type(bucket) ~= "table" then return end
  local state = bucket.state
  if type(state) == "table" and state.version == nil then
    state.version = SAVE_VERSION
  end
end)

------------------------------------------------------------------------
-- Player progression
------------------------------------------------------------------------
-- AI rivals are allowed to keep pace with the player's gym journey, but they
-- cannot race several badges ahead while the player is still in Pewter. The
-- engine save exposes the player's badge case as save.badges; the fallback
-- shapes below keep this mod tolerant of compatible builds that wrap it.
function M:playerBadgeCount()
  local save = self.game and self.game.save
  if type(save) ~= "table" then return 0 end

  local candidates = {
    save.badges,
    save.inventory and save.inventory.badges,
    save.trainer and save.trainer.badges,
  }
  for _, badges in ipairs(candidates) do
    if type(badges) == "table" then
      local n = 0
      local order = self.gyms and self.gyms.order or {}
      for _, id in ipairs(order) do
        if badges[id] == true or badges[id] == 1 then n = n + 1 end
      end
      if n > 0 then return n end
      -- Some builds expose an ordered boolean array instead of badge ids.
      for i = 1, #order do
        if badges[i] == true or badges[i] == 1 then n = n + 1 end
      end
      if n > 0 then return n end
    elseif type(badges) == "number" then
      local n, value = 0, badges
      for _ = 1, #(self.gyms and self.gyms.order or {}) do
        if value % 2 == 1 then n = n + 1 end
        value = math.floor(value / 2)
      end
      return n
    end
  end
  return 0
end

-- The single gate for the whole relationship system.  Read into the world
-- view once per tick rather than probed at each call site, so turning bonds
-- off costs nothing and cannot leave one subsystem recording while another
-- has stopped.
function M:relationshipsEnabled()
  return mod.options:get("relationships") ~= false
end

-- The world's life-path seed (§3, §32).
--
-- Created ONCE, on first use, and saved. It is derived from data that already
-- differs between saves rather than from a clock, so two saves made in the
-- same second still diverge, and a given save always answers identically --
-- which is what makes eligibility unrerollable rather than merely hidden.
-- THE WORLD SEED (2.6.0).
--
-- One number, created ONCE per save and persisted, from which every
-- per-playthrough choice is derived: which rival is dealt which starter, and
-- which rival (if any) has an alternative destiny.
--
-- It replaces a derivation that had no entropy at all. The previous seed was
-- built from the generation, the rival ids and their starters -- all of them
-- fixed data -- so EVERY save produced the identical number, and therefore the
-- identical life-path eligibility. §3's 85/12/3 distribution was correct in
-- the model and unreachable in practice, because the roll never varied.
--
-- Creation may be random; only STABILITY is required (§32), and persistence is
-- what provides it. Entropy is gathered from several weak sources because no
-- single one is guaranteed present in every host: a sandbox may have no
-- `os`, and `math.random` may be unseeded.
function M:worldSeed()
  if self.seedValue then return self.seedValue end
  local parts = { tostring(self.generation or "?") }
  if type(os) == "table" then
    if type(os.time) == "function" then parts[#parts + 1] = tostring(os.time()) end
    if type(os.clock) == "function" then parts[#parts + 1] = tostring(os.clock()) end
  end
  if type(math.random) == "function" then
    parts[#parts + 1] = tostring(math.random(1, 2 ^ 30))
  end
  -- a fresh table's address differs per allocation on every host this runs on
  parts[#parts + 1] = tostring({})
  for _, rival in ipairs(self.rivals or {}) do
    parts[#parts + 1] = tostring(rival.id)
  end
  local text = table.concat(parts, ":")
  local seed = 0
  for i = 1, #text do seed = (seed * 33 + text:byte(i)) % 4294967296 end
  if seed == 0 then seed = 1 end
  self.seedValue = seed
  return seed
end

-- Existing saves keep the seed they were already playing under, so upgrading
-- never reassigns a destiny a player has already been living with.
function M:lifePathSeed()
  if self.pathSeed then return self.pathSeed end
  self.pathSeed = self:worldSeed()
  return self.pathSeed
end

-- The starter deal reads the same world seed, and the roster's pools.
function M:starterOpts(versionKey, pokemon, allows, personality)
  return {
    seed = self:worldSeed(),
    roster = ROSTER,
    pokemon = pokemon or (self.rivalContext and self.rivalContext.data and self.rivalContext.data.pokemon),
    allows = allows,
    weatherFx = self.compat and self.compat:present("weather") or false,
    personality = personality,
  }
end

function M:lifePathsEnabled()
  return mod.options:get("life_paths") ~= false
end

function M:lifePathEligible(rival)
  if not self:lifePathsEnabled() then return false end
  local ids = {}
  for _, other in ipairs(self.rivals or {}) do ids[#ids + 1] = other.id end
  return LifePath.isEligible(self:lifePathSeed(), rival.id, ids)
end

-- The one door for a divergence. Every guard the brief asks for lives here so
-- no caller can skip one: the option, eligibility from the seed, the derived
-- pressure, and the model's own lock.
function M:considerLifePath(rival)
  if not rival or not rival.ensureLifePath then return false end
  local record = rival:ensureLifePath()
  if record.locked then return false end
  if not self:lifePathEligible(rival) then return false end
  local pressure = rival:lifePathPressure()
  if LifePath.stage(pressure, false) ~= "TRANSITIONING" then return false end
  local candidates = rival:lifePathCandidates(3)
  if #candidates == 0 then return false end
  -- WHICH of the plausible paths is decided by the seed, not by a live roll:
  -- §33 forbids a decision that can be rerolled by reloading. The candidate
  -- list comes from the rival's history, so the seed only breaks the tie
  -- between lives it has actually earned.
  local roll = LifePath.roll(self:lifePathSeed(), "choice:" .. rival.id)
  local total = 0
  for _, entry in ipairs(candidates) do total = total + entry.score end
  local pick, cursor = candidates[1].path, roll * total
  for _, entry in ipairs(candidates) do
    cursor = cursor - entry.score
    if cursor <= 0 then pick = entry.path break end
  end
  if not LifePath.commit(record, pick, self.sim and self.sim.tick or 0,
                         "pressure") then
    return false
  end
  self:addNews(rival, { kind = "life_path", path = pick })
  if rival.rememberEvent then
    rival:rememberEvent({ tick = self.sim and self.sim.tick or 0,
                          type = "LIFE_PATH", target = pick })
  end
  return true, pick
end

-- §19/§28/§29: the arcs that continue AFTER a divergence.
--
-- Checked on the same slow cadence as the divergence itself, and guarded the
-- same way: the edge must exist, the tenure must have been served, and the
-- doubt must be real. Nothing here can be reached by reloading.
function M:considerTransition(rival)
  if not rival or not rival.ensureLifePath then return false end
  if not self:lifePathsEnabled() then return false end
  local record = rival:ensureLifePath()
  local tick = self.sim and self.sim.tick or 0
  if not LifePath.mayTransition(record, tick) then return false end
  local facts = rival:lifePathFacts()
  facts.careerLevel = rival.careerLevel and rival:careerLevel() or 1
  facts.warmToPlayer = rival:relationshipTo("player") == "RESPECT"
    or rival:relationshipTo("player") == "FRIENDLY"
    or rival:relationshipTo("player") == "ALLIED"
  facts.careerFailures = (rival:ensureCareer() or {}).failures or 0
  if LifePath.doubt(record.path, facts) < LifePath.TRANSITION_PRESSURE then
    return false
  end
  local targets = LifePath.transitionTargets(record.path)
  if #targets == 0 then return false end
  -- Which life it lands in comes from the SEED, as the original choice did:
  -- §19 says redemption is not guaranteed and §33 says nothing may be
  -- rerolled, so the destination must be fixed for this save.
  local roll = LifePath.roll(self:lifePathSeed(), "transition:" .. rival.id)
  local from = record.path
  local pick = targets[math.min(#targets, math.floor(roll * #targets) + 1)]
  local to = LifePath.transition(record, pick, tick)
  if not to then return false end
  rival.career = Career.newProgress(to)
  rival.careerHomeMap, rival.careerHomeFor = nil, nil
  self:applyPathRelationships(rival, from, to)
  self:addNews(rival, { kind = "life_transition", from = from, to = to })
  if rival.rememberEvent then
    rival:rememberEvent({ tick = tick, type = "LIFE_PATH", target = to })
  end
  return true, to
end

-- §20: a life-path change moves how everyone feels about this rival -- the
-- other rivals AND the player. Routed through the 1.33 causes so the change is
-- an ordinary, explicable relationship event rather than a special case.
function M:applyPathRelationships(rival, from, to)
  local cause
  if to == "TEAM_ROCKET" then cause = "TURNED_ROCKET"
  elseif from == "TEAM_ROCKET" then cause = "LEFT_ROCKET"
  elseif to == LifePath.GYM_CHALLENGE then cause = "CAME_BACK"
  else cause = "CHANGED_PATH" end
  local tick = self.sim and self.sim.tick or 0
  for _, other in ipairs(self.rivals) do
    if other.id ~= rival.id then
      self:recordBond(other, rival.id, cause, { tick = tick })
    end
  end
  -- and the rival's own view of the player, which is the relationship the
  -- player will actually feel
  self:recordBond(rival, "player", cause, { tick = tick })
end

function M:sightingsEnabled()
  return mod.options:get("sightings") ~= false
end

-- 1.36.0 §13: what the player could plausibly have noticed, once per world
-- tick. This is an OBSERVER -- it reads rival state and writes only the
-- presence log -- so it can never change where a rival goes or what it does.
--
-- Adjacency is asked of the map graph rather than assumed, because "the next
-- route over" is a different set of maps in Kanto, in Johto, and in whatever
-- a total conversion ships.
function M:observePresence(playerMap, world)
  if not self:sightingsEnabled() then return nil end
  if not playerMap then return nil end
  self.presence = self.presence or Presence.new()
  local tick = self.sim and self.sim.tick or 0
  local adjacent = {}
  if self.graph and self.graph.neighbours then
    -- MapGraph:neighbours returns EDGE records, not map ids. Keying the set
    -- on the edge table would make every adjacency lookup miss silently.
    for _, edge in ipairs(self.graph:neighbours(playerMap) or {}) do
      local id = type(edge) == "table" and edge.to or edge
      if type(id) == "string" then adjacent[id] = true end
    end
  end
  -- Ask in LEAST-RECENTLY-SEEN order, not roster order.
  --
  -- The global cooldown means at most one rival is noticed per tick, so a
  -- fixed iteration order hands every sighting to whoever comes first in the
  -- roster: with four rivals parked on the player's map, the fourth was never
  -- noticed at all. Sorting by when each was last seen makes the choice fair
  -- and still deterministic (ties break on the id, never on table order), and
  -- it reads correctly too -- you notice the one you have not seen in a while.
  local order = {}
  for _, rival in ipairs(self.rivals) do
    local sameMap = rival.map == playerMap
    if sameMap or adjacent[rival.map] then order[#order + 1] = rival end
  end
  table.sort(order, function(a, b)
    local ta = self.presence.byRival[a.id] or -1
    local tb = self.presence.byRival[b.id] or -1
    if ta ~= tb then return ta < tb end
    return tostring(a.id) < tostring(b.id)
  end)

  for _, rival in ipairs(order) do
    local sameMap = rival.map == playerMap
    do
      local sighting = Presence.observe(self.presence, {
        id = rival.id,
        name = rival.name,
        map = rival.map,
        mapLabel = Util.spaced(rival.map or ""),
        state = rival.state,
        objective = rival.objective,
        camping = (rival.campTicks or 0) > 0,
        hunting = rival.huntTarget ~= nil,
        huntTarget = rival.huntTarget,
        travelling = rival.destination ~= nil and rival.destination ~= rival.map,
        direction = rival.lastDirection,
        sameMap = sameMap,
        adjacent = adjacent[rival.map] == true,
        -- a rival you are already talking to or fighting is not "spotted"
        engaged = (self.companionId == rival.id)
          or self.worldChallenge == true
          or self:gauntletActive(),
      }, tick)
      if sighting then
        self:addNews(rival, { kind = "sighting", note = sighting.note })
        return sighting
      end
    end
  end
  return nil
end

-- The map the player is actually standing on, or nil. Same probe worldView
-- uses; factored out so the menu can ask without building a whole world view.
function M:playerMapId()
  local where
  pcall(function()
    if self.game and mod.world and mod.world.current then
      where = mod.world:current()
    end
  end)
  return where and where.mapId or nil
end

function M:worldView()
  local where
  pcall(function()
    if self.game and mod.world and mod.world.current then
      where = mod.world:current()
    end
  end)
  local party
  pcall(function()
    party = self.game and self.game.save and self.game.save.party
  end)
  return {
    playerMap = where and where.mapId or nil,
    playerX = where and where.x, playerY = where and where.y,
    playerParty = party,
    playerBadges = self:playerBadgeCount(),
    compat = self.compat,
    rivals = self.rivals,
    companionId = self.companionId,
    relationships = self:relationshipsEnabled(),
    -- 4.6.0: a title held by the PLAYER is not something the simulation may
    -- settle on its own. Simulation.tryTitleMatch reads this and stands down,
    -- leaving the challenge to the in-person path the player can actually
    -- fight (M:startRivalChallenge's titleChallenge arm).
    playerChampion = self.playerChampion == true,
    tick = self.sim and self.sim.tick or 0,
    log = self.log,
    -- 5.2.0: the same live population the encounter hooks read. Present on
    -- BOTH this view and Simulation's per-tick ctx, deliberately -- 3.2.0's
    -- bug was a field that existed on one and not the other.
    ecology = self:ecologyFor(),
    ecologyEnv = self:ecologyEnv(),
    worldState = self.worldState,
  }
end

------------------------------------------------------------------------
-- Materialization
------------------------------------------------------------------------
-- Near the player a rival is a real NPC with real collision.  Far away it is
-- a table row.  This is the whole reason the mod is usable on a phone: at
-- most a handful of objects exist at once no matter how big the roster gets.



-- FOLLOWERS_EX pattern: drive the already-live NPC entity directly. This is
-- the ordinary NPC update path (targetX/targetY/moving/progress), not the
-- shared script queue, so it animates without locking player input.

-- Authoritative terrain collision from the live Map. Unlike a visual tile or
-- a guessed coordinate, this is the same walkable-cell test used for walls,
-- trees and building facades by the player controller.



-- Remove a bad live object and let the normal placement code rebuild it on a
-- proven-free tile. This is deliberately recoverable: the rival's party,
-- progress, destination and goal are untouched.

-- Where on this map the rival should stand.  A rival arriving from elsewhere
-- has no coordinates yet, so it materializes on a walkable cell that is not
-- the player's and not immediately adjacent to them -- a rival that appeared
-- in your face would read as a teleport, which is exactly the failure mode
-- the brief calls out.



-- Fixed cells inside OAKS_LAB (5x6 interior). Used when mapOverview is
-- missing or the walkability scan finds nothing -- common on first enter.
-- Upper lab area near Oak / side tables -- NOT the south exit row.
-- Exit is typically along the bottom; keep rivals clear of it so Blue's
-- script and the player can move freely until the gauntlet starts.
local LAB_SLOTS = {
  { 2, 2 }, { 3, 2 }, { 4, 2 }, { 2, 3 }, { 4, 3 }, { 3, 4 },
}

-- Sprite ids are resolved against the CURRENT merged runtime data.  AI Rivals
-- never owns or rewrites the art behind those ids, so any player/trainer/NPC
-- sprite replacement mod remains authoritative regardless of load order.
M.GAUNTLET_MAX = 4

local RIVAL_SPRITE_PREFER = {
  chris   = { "SPRITE_BLUE", "SPRITE_COOLTRAINER_M", "SPRITE_RED", "SPRITE_CHRIS" },
  dyanari = { "SPRITE_LASS", "SPRITE_COOLTRAINER_F", "SPRITE_BRUNETTE_GIRL", "SPRITE_GIRL", "SPRITE_KRIS" },
  matt    = { "SPRITE_SUPER_NERD", "SPRITE_BUG_CATCHER", "SPRITE_YOUNGSTER", "SPRITE_ROCKER" },
  larissa = { "SPRITE_COOLTRAINER_F", "SPRITE_BRUNETTE_GIRL", "SPRITE_LASS", "SPRITE_GIRL", "SPRITE_KRIS" },
}





-- Facing at spawn. `range` (spawn-time, engine schema) and `rival.facing`
-- (this mod's own live-entity field, set only transiently by moveRivalNpc
-- during a gauntlet/companion step) use different cases for the same four
-- directions -- "DOWN" vs "down" -- because they come from two different
-- systems. This table bridges them so a rival mid-step keeps the direction
-- it was already facing instead of spawning turned to face something else.
local SPAWN_FACINGS = { "DOWN", "UP", "LEFT", "RIGHT" }
local FACING_TO_RANGE = { down = "DOWN", up = "UP", left = "LEFT", right = "RIGHT" }


-- Resolve the tile a rival must physically reach before its next map hop.

-- Seconds a player must stand still, pressed against a spawned rival, before
-- that rival is nudged aside. Long enough that ordinary talking/menu use
-- next to a rival never triggers it; short enough to read as "give way", not
-- "wait forever".
local PATH_BLOCK_STALL_S = 2.5

-- self.pathNudgeDone debounces this to once per stall episode: it is cleared
-- the moment the player's cell changes (playerIdleSeconds resets to 0 in
-- RuntimePolicy), so leaving and returning to the same spot can trigger it
-- again, but standing there after the first nudge does not repeat it.

-- Animate every visible rival one legal tile at a time. Strategic travel has
-- priority; a rival working at its destination paces within a safe area.
-- Rivals stop beside doors/seams and change only their own abstract map state;
-- they never enter a live transition tile or invoke the player's fade.



------------------------------------------------------------------------
-- Talking and battling
------------------------------------------------------------------------

-- The Elite Four's final trainer is selected when its party is requested.
-- BLUE keeps the vanilla party; the four AI rivals bring their actual teams.
  -- Selection is deliberately persisted so a retry/reload cannot reroll the
  -- Champion mid-battle. A vacant title remains with vanilla Blue.
function M:selectEliteChampion()
  -- A reigning AI Champion owns the next title defence.
  for _, rival in ipairs(self.rivals) do
    local earned = rival.earnedChampionTitle and rival:earnedChampionTitle()
    if earned then
      self.eliteChampionId = rival.id
      -- A reigning rival is now a League resident. The engine's final vanilla
      -- Champion object remains the safe script anchor; trainer.party below
      -- replaces that encounter with this rival's live team. Keeping the
      -- abstract location at Indigo prevents the simulator from also spawning
      -- the Champion on an unrelated route while the player climbs the Elite Four.
      local league = self.gyms and self.gyms.league
      rival.map = (league and (league.map or league.city)) or rival.map
      rival.state, rival.stateReason = "CHAMPION", "defending the Pokemon League title"
      return rival
    end
  end
  -- Blue is a persistent Gen 1 title holder, not merely a fallback party.
  if not (self.data and self.data.gen2Trainers) and not self.playerChampion then
    local blue=BlueChampion.ensure(self)
    if blue.champion~=false then
      blue.champion=true
      self.eliteChampionId="blue"
      return nil
    end
  end
  self.eliteChampionId=self.playerChampion and "player" or "blue"
  return nil
end

function M:eliteChampion()
  if self.eliteChampionId ~= nil then
    if self.eliteChampionId == "blue" then return nil end
    return self.byId[self.eliteChampionId]
  end
  return self:selectEliteChampion()
end

-- Keep this narrow and defensive because engine revisions expose the player's
-- bag in slightly different shapes.  A failed grant leaves the rival's item
-- untouched rather than deleting a reward into thin air.
function M:givePlayerItem(item)
  local save = self.game and self.game.save
  local bag = save and save.inventory
  if type(bag) ~= "table" then return false end
  for _, method in ipairs({ "add", "addItem", "give" }) do
    if type(bag[method]) == "function" then
      local ok, result = pcall(bag[method], bag, item, 1)
      if ok then return result ~= false end
    end
  end
  local items = type(bag.items) == "table" and bag.items or bag
  if type(items[item]) == "number" then
    items[item] = items[item] + 1
    return true
  end
  -- Plain keyed bags commonly omit zero-count entries.  Only create a key
  -- for an item present in the live item registry.
  if self.data and self.data.items and self.data.items[item] then
    items[item] = 1
    return true
  end
  return false
end

function M:takePlayerItem(item)
  local save = self.game and self.game.save
  local bag = save and save.inventory
  if type(bag) ~= "table" then return false end
  for _, method in ipairs({ "remove", "removeItem", "take" }) do
    if type(bag[method]) == "function" then
      local ok, result = pcall(bag[method], bag, item, 1)
      if ok then return result ~= false end
    end
  end
  local items = type(bag.items) == "table" and bag.items or bag
  if type(items[item]) == "number" and items[item] > 0 then
    items[item] = items[item] - 1
    return true
  end
  return false
end

-- Every player-facing relationship cause goes through here: one option gate,
-- one tick source, one news path for a derived transition.  Callers name what
-- happened and nothing else.
-- 4.7.0: bounded tournament prize-money award.
M.MAX_PRIZE_MONEY = 9000

-- 4.7.0: prize money. Written the same way givePlayerItem reads the bag --
-- try the save's own accessors first, fall back to the plain field -- and it
-- reports whether it actually landed, so a tournament cannot announce a purse
-- the player never received. Capped per award: no single event may hand over
-- more than a hard ceiling, whatever the multiplier works out to.
M.MAX_PRIZE_MONEY = 9000

function M:givePlayerMoney(amount)
  amount = math.max(0, math.floor(tonumber(amount) or 0))
  if amount <= 0 then return false end
  amount = math.min(M.MAX_PRIZE_MONEY, amount)
  local save = self.game and self.game.save
  if type(save) ~= "table" then return false end
  for _, method in ipairs({ "addMoney", "giveMoney", "earn" }) do
    if type(save[method]) == "function" then
      local ok, result = pcall(save[method], save, amount)
      if ok and result ~= false then return true end
    end
  end
  if type(save.money) == "number" then
    -- The engine's own ceiling; going past it is how a save ends up with a
    -- number the UI cannot draw.
    save.money = math.min(999999, save.money + amount)
    return true
  end
  return false
end

function M:recordBond(rival, id, code, opts)
  if not (rival and rival.recordRelationship) then return false end
  if not self:relationshipsEnabled() then return false end
  opts = opts or {}
  opts.tick = opts.tick or (self.sim and self.sim.tick or 0)
  local _, _, after, changed = rival:recordRelationship(id, code, opts)
  if changed then
    self:addNews(rival, { kind = "relationship", with = id, state = after })
  end
  return changed == true, after
end

function M:recordBondBattle(rival, id, won, opts)
  if not (rival and rival.recordRelationshipBattle) then return false end
  if not self:relationshipsEnabled() then return false end
  opts = opts or {}
  opts.tick = opts.tick or (self.sim and self.sim.tick or 0)
  local _, _, after, changed = rival:recordRelationshipBattle(id, won, opts)
  if changed then
    self:addNews(rival, { kind = "relationship", with = id, state = after })
  end
  return changed == true, after
end

function M:helpRequest(rival)
  if not rival then return false, "No request." end
  -- Prefer fulfilling an active GIVE_ITEM quest for this rival.
  local questItem
  if self.quests then
    for _, q in ipairs(self.quests.offers or {}) do
      if q.status == "ACTIVE" and q.kind == "GIVE_ITEM" and q.giverId == rival.id then
        questItem = q.item
        break
      end
    end
  end
  local item = questItem
    or (rival:itemCount("POKE_BALL") == 0 and "POKE_BALL")
    or (rival:healthFraction() < 0.55 and "POTION" or nil)
  if not item then return false, rival.name .. " does not need help right now." end
  if not self:takePlayerItem(item) then
    return false, "You do not have a " .. Util.spaced(item) .. "."
  end
  rival:addItem(item, 1)
  -- The item genuinely left the player's bag and entered the rival's, which
  -- is what makes this a cause rather than a gesture.
  self:recordBond(rival, "player", "HELPED")
  if self.quests and self.quests.onItemGiven then
    pcall(function() self.quests:onItemGiven(rival.id, item) end)
  end
  local line = "You helped " .. rival.name .. " with a " .. Util.spaced(item) .. "."
  self:addNews(rival, { kind = "news", text = line })
  return true, line
end

local function playerSlotData(mon)
  if type(mon) ~= "table" then return nil end
  local species = mon.species or mon.speciesId or mon.id
  if type(species) == "table" then species = species.id or species.name end
  if type(species) ~= "string" then return nil end
  local moves = {}
  for _, move in ipairs(mon.moves or {}) do
    local id = type(move) == "table" and (move.id or move.move or move.name) or move
    if type(id) == "string" then moves[#moves + 1] = id end
  end
  return { species = species, level = tonumber(mon.level) or 5, moves = moves }
end

-- Adapt persistent move IDs to whichever Pokémon move representation this
-- engine build uses. Desktop builds commonly store IDs; some iOS/revision
-- builds expose move records carrying their own PP.
local function applyPersistentMoves(mon, slot, data)
  if type(mon) ~= "table" or type(slot) ~= "table"
     or type(slot.moves) ~= "table" or #slot.moves == 0 then return end
  local current = type(mon.moves) == "table" and mon.moves or {}
  local recordShape = type(current[1]) == "table"
  if not recordShape then
    mon.moves = Util.copy(slot.moves)
    return
  end
  local byId = {}
  for _, move in ipairs(current) do
    local id = type(move) == "table" and (move.id or move.move or move.name)
    if type(id) == "string" then byId[id] = move end
  end
  local converted = {}
  for _, id in ipairs(slot.moves) do
    local record = byId[id] and Util.copy(byId[id])
      or (data and data.moves and data.moves[id] and Util.copy(data.moves[id]))
    if type(record) == "table" then
      record.id = record.id or id
      local pp = slot.movePp and slot.movePp[id]
      if tonumber(pp) then record.pp = tonumber(pp) end
      converted[#converted + 1] = record
    else
      converted[#converted + 1] = id
    end
  end
  mon.moves = converted
end

-- Build through the loaded engine and validate before touching either party.
function M:buildPlayerPokemon(slot)
  local ok, Pokemon = pcall(require, "src.pokemon.Pokemon")
  if not ok or type(Pokemon) ~= "table" or type(Pokemon.new) ~= "function" then return nil end
  local def = self.data and self.data.pokemon and self.data.pokemon[slot.species]
  local attempts = {
    function() return Pokemon.new(def, slot.level) end,
    function() return Pokemon.new(slot.species, slot.level) end,
    function() return Pokemon.new(self.data, slot.species, slot.level) end,
  }
  for _, make in ipairs(attempts) do
    local made, mon = pcall(make)
    local built = made and playerSlotData(mon) or nil
    if built and built.species == slot.species then
      return mon
    end
  end
  return nil
end

function M:tradeOffer(rival)
  local party = self.game and self.game.save and self.game.save.party
  if not (rival and type(party) == "table" and #party >= 2) then
    return false, "You need at least two Pokemon to trade."
  end
  local offered, offeredBox, offeredIndex
  local counts = {}
  for _, slot in ipairs(rival.party or {}) do counts[slot.species] = (counts[slot.species] or 0) + 1 end
  for _, box in ipairs(rival.pcBoxes or {}) do
    for _, slot in ipairs(box) do counts[slot.species] = (counts[slot.species] or 0) + 1 end
  end
  for _, box in ipairs(rival.pcBoxes or {}) do
    for i, slot in ipairs(box) do
      if (counts[slot.species] or 0) > 1 then
        offered, offeredBox, offeredIndex = slot, box, i
        break
      end
    end
    if offered then break end
  end
  if not offered then return false, rival.name .. " has no duplicate to offer." end
  local outgoing = playerSlotData(party[#party])
  if not outgoing or not rival:speciesDef(outgoing.species) then
    return false, "That Pokemon cannot be represented in the rival collection."
  end
  local incoming = self:buildPlayerPokemon(offered)
  if not incoming then return false, "Trading is unavailable in this game build." end
  -- Commit only after both sides have been validated and constructed.
  party[#party] = incoming
  table.remove(offeredBox, offeredIndex)
  rival:storePokemon(outgoing)
  rival:registerDex(outgoing.species)
  self:recordBond(rival, "player", "TRADED")
  pcall(function() Happiness.noteTrade(rival,incoming and incoming.species or outgoing.species) end)
  if self.quests and self.quests.onSpeciesTraded then
    pcall(function() self.quests:onSpeciesTraded(rival.id, outgoing.species) end)
  end
  local line = "You traded " .. Util.spaced(outgoing.species) .. " with "
    .. rival.name .. " for " .. Util.spaced(offered.species) .. "."
  self:addNews(rival, { kind = "news", text = line })
  return true, line
end

function M:startHmRecovery(rival, move)
  if not (rival and move) then return false end
  rival.hmGoal = move
  rival.hmGoalForced = true
  local species, mapId
  if rival.pickHmHuntTarget then species, mapId = rival:pickHmHuntTarget(move) end
  rival.objective = "TRAIN"
  if species and mapId then
    rival:setState("TRAVELLING", "finding an HM user")
    rival:setDestination(mapId)
    rival.travelReason = "Hunting " .. Util.spaced(species)
      .. " for " .. Util.spaced(move)
    self:addNews(rival, { kind = "hm_hunt", move = move, species = species })
  else
    rival:setState("TRAINING", "needs a compatible HM user")
    rival.destination, rival.route = nil, nil
    rival.travelReason = "Needs a Pokémon that can learn " .. Util.spaced(move)
  end
  return true
end

function M:setCompanion(rival)
  if rival and self.companionId ~= rival.id then
    local world = self:worldView()
    local missing = world and world.playerMap and rival.missingHMForMap
      and rival:missingHMForMap(world.playerMap)
    if missing then
      self:startHmRecovery(rival, missing)
      return false, rival.name .. " cannot join here without " .. Util.spaced(missing) .. "."
    end
    -- Switching companions dismisses the old one cleanly instead of leaving
    -- two rivals carrying an "accompanying" state while only one is registered
    -- as the battle ally.
    local previous = self.byId[self.companionId]
    if previous and previous ~= rival then
      previous.travelReason = "Resuming an independent journey"
      pcall(AI.evaluate, previous, self:worldView())
    end
    self.companionId = rival.id
    self.companionYieldMap = nil
    self.companionTrailHead, self.companionTrailGoal = nil, nil
    rival.destination, rival.route, rival.localWalkGoal = nil, nil, nil
    rival.walking, rival.blockedWalkPulses = false, 0
    rival:setState("IDLE", "accompanying the player")
    rival.travelReason = "Accompanying the player"
    if world and world.playerMap then
      rival.map, rival.x, rival.y = world.playerMap, nil, nil

      -- Materialise the companion immediately.  Previously this relied entirely
      -- on spawnFor() finding a valid tile after the NPC had been despawned.
      -- On maps with incomplete/strict collision data that could silently leave
      -- the companion abstract, making "ACCOMPANY" appear to do nothing.
      local overview
      pcall(function()
        if mod.world and mod.world.mapOverview then
          overview = mod.world:mapOverview()
        end
      end)
      if overview and world.playerX and world.playerY then
        local candidates = {
          { world.playerX, world.playerY + 1 },
          { world.playerX - 1, world.playerY },
          { world.playerX + 1, world.playerY },
          { world.playerX, world.playerY - 1 },
        }
        for _, cell in ipairs(candidates) do
          if self:validRivalCell(rival, overview, cell[1], cell[2], false)
             and not (cell[1] == world.playerX and cell[2] == world.playerY) then
            rival.x, rival.y = cell[1], cell[2]
            break
          end
        end
      end

      self:despawnAll()
      local spawned = 0
      local ok, result = pcall(function()
        return self:spawnFor(world.playerMap)
      end)
      if ok then spawned = tonumber(result) or 0 end

      -- If the preferred adjacent tile was not available, give the normal
      -- placement code one more chance from a clean coordinate state.
      if spawned == 0 and not self.spawned[rival.id] then
        rival.x, rival.y = nil, nil
        pcall(function() self:spawnFor(world.playerMap) end)
      end
    end
    self:addNews(rival, { kind = "news", text = rival.name .. " joined the player." })
    if self.spawned[rival.id] then
      return true, rival.name .. " is now accompanying you."
    end
    return true, rival.name .. " is now accompanying you. They will appear on the next map refresh."
  end
  local leaving = rival or self.byId[self.companionId]
  self.companionId = nil
  self.companionTrailHead, self.companionTrailGoal = nil, nil
  if leaving then
    leaving.travelReason = "Resuming an independent journey"
    pcall(AI.evaluate, leaving, self:worldView())
  end
  return true, leaving and (leaving.name .. " resumed travelling alone.")
    or "No rival is accompanying you."
end

mod.exports.registerAllySource({
  id = "ai_rivals_companion",
  priority = 1,
  provide = function(game, battle)
    local rival = M.byId[M.companionId]
    if not rival then return nil end
    local slot
    for _, candidate in ipairs(rival.party or {}) do
      if (tonumber(candidate.hp) or rival:maxHpOf(candidate)) > 0 then slot = candidate break end
    end
    if not slot then return nil end
    local mon = M:buildPlayerPokemon(slot)
    if not mon then return nil end
    -- Carry the rival's actual persistent battle state into the temporary
    -- engine Pokémon instead of reverting to constructor-default moves.
    applyPersistentMoves(mon, slot, M.data)
    if tonumber(slot.exp) then mon.exp = tonumber(slot.exp) end
    if slot.status ~= nil then mon.status = slot.status end
    if type(slot.pp) == "table" then mon.pp = Util.copy(slot.pp) end
    if type(slot.movePp) == "table" then mon.movePp = Util.copy(slot.movePp) end
    if mon.stats and mon.stats.hp then
      mon.hp = math.min(mon.stats.hp, tonumber(slot.hp) or mon.stats.hp)
    end
    M.companionBattleSlot, M.companionBattleMon = slot, mon
    return mon, true
  end,
})
mod.exports.companionActive = function()
  local rival = M.byId[M.companionId]
  if not rival then return false end
  for _, slot in ipairs(rival.party or {}) do
    if (tonumber(slot.hp) or rival:maxHpOf(slot)) > 0 then return true end
  end
  return false
end

function M:restoreCompanionBattle(battle)
  local slot, mon = M.companionBattleSlot, M.companionBattleMon
  if not (slot and mon) then return false end
  if battle and not battle.__dbExternalAlly then
    -- The provider was queried but the battle refused/failed to construct the
    -- external battler. Discard the untouched temporary object immediately.
    M.companionBattleSlot, M.companionBattleMon = nil, nil
    return false
  end
  M.companionBattleSlot, M.companionBattleMon = nil, nil
  slot.hp = math.max(0, tonumber(mon.hp) or slot.hp or 0)
  local snapshot = playerSlotData(mon)
  if snapshot then
    slot.species = snapshot.species or slot.species
    slot.level = snapshot.level or slot.level
    if snapshot.moves and #snapshot.moves > 0 then slot.moves = snapshot.moves end
  else
    slot.level = tonumber(mon.level) or slot.level
  end
  slot.exp = tonumber(mon.exp) or slot.exp
  slot.status = mon.status
  if type(mon.pp) == "table" then slot.pp = Util.copy(mon.pp) end
  if type(mon.movePp) == "table" then slot.movePp = Util.copy(mon.movePp) end
  local movePp = {}
  for _, move in ipairs(mon.moves or {}) do
    if type(move) == "table" then
      local id = move.id or move.move or move.name
      if type(id) == "string" and tonumber(move.pp) then movePp[id] = tonumber(move.pp) end
    end
  end
  slot.movePp = next(movePp) and movePp or slot.movePp
  local rival = M.byId[M.companionId]
  if rival and rival:isFainted() then
    -- A wiped companion blacks out like every other rival. Dismiss first so
    -- the follow director cannot pull them straight back onto the player map.
    M.companionId = nil
    local npcId = M.spawned[rival.id]
    if npcId then pcall(function() mod.world:removeNpc(npcId) end) end
    M.spawned[rival.id] = nil
    if not (rival.warpToLastPokemonCenter and rival:warpToLastPokemonCenter()) then
      rival.travelReason = "Companion team fainted; needs healing"
    end
    pcall(function() M:save() end)
  end
  return true
end

mod.events:on("battle.ended", function(ev)
  if M.pendingRocket then
    local member = M.pendingRocket
    local won = ev and (ev.playerWon == true or ev.winner == "player")
    if M.rocket and member then
      if won then
        member.failures = (member.failures or 0) + 1
        local defeatedMap = member.map
        pcall(function() M.rocket:onPlayerDefeated(member) end)
        if M.quests then pcall(function() M.quests:onRocketDefeated(member, defeatedMap) end) end
      else
        member.successes = (member.successes or 0) + 1
        M.rocket.playerAmbushCooldown = math.max(tonumber(M.rocket.playerAmbushCooldown) or 0, 12)
      end
      member.battles = (member.battles or 0) + 1
      -- 5.0.8: what this Rocket says the NEXT time the player talks to them
      -- now depends on how this went. Nothing else on a member records it --
      -- successes/failures also move on operations the player never saw.
      if type(M.rocket.noteBattleOutcome) == "function" then
        pcall(function() M.rocket:noteBattleOutcome(member, won) end)
      end
      if M.factions then
        if won then
          M.factions:adjust("rocket", -4, "beat_rocket")
          M.factions:adjust("rangers", 3, "beat_rocket")
          if M.doubleAgent then M.doubleAgent:record("BEAT_ROCKET",{map=defeatedMap,target=member.id}) end
        else
          M.factions:adjust("rocket", 2, "lost_to_rocket")
          if M.doubleAgent then M.doubleAgent:record("LOST_TO_ROCKET",{map=member.map,target=member.id}) end
        end
      end
      if M.rocket.log then M.rocket:log(member.name .. (won and " lost an ambush battle." or " defeated the player in an ambush."), "ambush") end
    end
    M.pendingRocket=nil
    M.pendingRocketBattleLaunch=nil
    M.rivalBattleSequenceActive=false
    M.rivalBattleActiveRivalId=nil
    return
  end
  M:restoreCompanionBattle(ev and ev.battle)
end)

mod.events:on("world.blacked_out", function(ev)
  -- Some builds emit blackout before (or instead of) battle.ended. The
  -- restore function consumes its snapshot once, so both events are safe.
  M:restoreCompanionBattle(ev and ev.battle)
end)

function M:awardRivalLoot(rival)
  if not rival or not rival.ensureInventory then return nil end
  rival:ensureInventory()

  -- The Master Ball is a League-completion reward, not ordinary rival
  -- inventory. Roll exactly once per player victory and never debit the
  -- rival when it succeeds.
  local badges = self:playerBadgeCount()
  if badges >= 8 and rival.rng:chance(0.15) then
    if self:givePlayerItem("MASTER_BALL") then return "MASTER_BALL" end
  end

  local choices = {}
  for item, count in pairs(rival.inventory or {}) do
    if tonumber(count) and count > 0 and self:rivalGiftAllowed(item, badges) then
      choices[#choices + 1] = item
    end
  end
  if #choices == 0 then return nil end
  local item = choices[rival.rng:int(1, #choices)]
  if self:givePlayerItem(item) and rival:takeItem(item) then return item end
  return nil
end

-- Rival gifts unlock alongside the player's badge case. Before Brock is
-- defeated the only possible gifts are Potions and ordinary Poké Balls.
-- MASTER_BALL is deliberately absent: awardRivalLoot owns its single 15%
-- post-eight-badge roll.
local RIVAL_GIFT_BADGES = {
  POTION = 0, POKE_BALL = 0,
  ANTIDOTE = 1, PARLYZ_HEAL = 1, AWAKENING = 1,
  BURN_HEAL = 1, ICE_HEAL = 1, REPEL = 1,
  GREAT_BALL = 2, SUPER_POTION = 2,
  ULTRA_BALL = 3, HYPER_POTION = 3,
  RARE_CANDY = 5,
}

function M:rivalGiftAllowed(item, badgeCount)
  local required = RIVAL_GIFT_BADGES[tostring(item or "")]
  return required ~= nil and math.max(0, tonumber(badgeCount) or 0) >= required
end

function M:rivalAtNpc(npcId)
  local key = tostring(npcId or "")
  local direct = key:match("^AIR_(.+)$")
  if direct and self.byId and self.byId[direct] then return self.byId[direct] end

  for id, spawnedId in pairs(self.spawned) do
    local rival = self.byId[id]
    local spawnedKey = spawnedId
    if type(spawnedId) == "table" then
      spawnedKey = spawnedId.id or spawnedId.name
        or (spawnedId.def and spawnedId.def.name)
    end
    if spawnedId == npcId or spawnedKey == npcId
       or tostring(spawnedKey) == tostring(npcId)
       or tostring(npcId) == "AIR_" .. tostring(id) then return rival end
  end
  return nil
end

function M:rivalHealthyCount(rival)
  if not rival then return 0 end
  local n = 0
  for _, slot in ipairs(rival.party or {}) do
    if (tonumber(slot.hp) or rival:maxHpOf(slot)) > 0 then n = n + 1 end
  end
  return n
end

function M:playerHealthyCount()
  local party = self.game and self.game.save and self.game.save.party
  if type(party) ~= "table" then return 0 end
  local n = 0
  for _, slot in ipairs(party) do
    if (tonumber(slot.hp) or 1) > 0 then n = n + 1 end
  end
  return n
end

function M:rivalDetailItems(rival)
  if not rival then return {} end
  local rivalMons = self:rivalHealthyCount(rival)
  local doubleRight = rivalMons >= 2 and "2V2" or "1 MON"
  local items = {
    { label = "CHALLENGE 1V1", right = "SINGLE", value = "_challenge_single" },
    { label = "CHALLENGE 2V2", right = doubleRight, value = "_challenge_double" },
    { label = M.companionId == rival.id and "STOP FOLLOW" or "ACCOMPANY",
      right = M.companionId == rival.id and "ON" or "JOIN", value = "_accompany" },
    { label = "TRADE", value = "_trade" },
    { label = "GIVE HELP", right = rival:itemCount("POKE_BALL") == 0 and "BALL"
        or (rival:healthFraction() < 0.55 and "POTION" or "--"), value = "_help" },
    -- Re-added on the talk interaction menu (also still under RIVAL INFO).
    { label = "MOVE TO SAFE TILE", right = "MOVE", value = "_repair" },
  }
  for _, row in ipairs(self:rivalQuestItems(rival) or {}) do
    items[#items + 1] = row
  end
  items[#items + 1] = { label = "RIVAL INFO", value = "_info" }
  items[#items + 1] = { label = "GOODBYE", value = "_goodbye" }
  return items
end

function M:rivalInfoItems(rival)
  if not rival then return {} end
  local detail = {
    { label = "MOVE TO SAFE TILE", right = "MOVE", value = "_repair" },
  }
  do
    if rival.moodLabel then
      detail[#detail + 1] = {
        label = "MOOD", right = rival:moodLabel():upper():sub(1, 18), value = "_line" }
      detail[#detail + 1] = {
        label = "CHAPTER", right = rival:chapterLabel():upper():sub(1, 18), value = "_line" }
      local story = rival:ensureStory()
      detail[#detail + 1] = {
        label = "MILESTONES",
        right = Story.unlockedCount(story) .. "/" .. Story.milestoneCount(),
        value = "_story",
      }
    end
    local ace = rival.favouriteSpecies and rival:favouriteSpecies()
    detail[#detail + 1] = {
      label = "TEAM STYLE",
      right = (rival.teamStyleLabel and rival:teamStyleLabel() or "?"):upper():sub(1, 18),
      value = "_line",
    }
    detail[#detail + 1] = {
      label = "BATTLE STYLE",
      right = (rival.battleStyle and rival:battleStyle() or "?"):upper():sub(1, 18),
      value = "_line",
    }
    -- §22: the player is shown WHAT a rival is doing, never the machinery.
    -- A rival still on the Gym Challenge shows nothing at all here, so the
    -- screen cannot leak who has an alternative destiny waiting.
    if rival.onGymChallenge and not rival:onGymChallenge() then
      detail[#detail + 1] = {
        label = "NOW",
        right = LifePath.label(rival:lifePathId()):upper():sub(1, 18),
        value = "_line",
      }
      local rank = rival.careerRank and rival:careerRank()
      if rank then
        detail[#detail + 1] = {
          label = "RANK", right = rank:upper():sub(1, 18), value = "_line" }
      end
    end
    if rival.spendingProfile then
      local profile = rival:spendingProfile()
      local best, bestShare = nil, 0
      for _, category in ipairs(Economy.CATEGORIES) do
        if (profile[category] or 0) > bestShare then
          best, bestShare = category, profile[category]
        end
      end
      if best then
        detail[#detail + 1] = {
          label = "SPENDS ON",
          right = (best:lower() .. " " .. math.floor(bestShare * 100 + 0.5) .. "%"):upper(),
          value = "_line",
        }
      end
    end
    local sky = rival.currentWeatherId and rival:currentWeatherId()
    if sky then
      detail[#detail + 1] = {
        label = "SKY", right = Weather.label(sky):upper():sub(1, 18), value = "_line" }
      local focus = rival:weatherFocusType()
      if focus then
        detail[#detail + 1] = {
          label = "SKY FAVOURS", right = tostring(focus):sub(1, 18), value = "_line" }
      end
    end
    local preferred = rival.preferredTypes and rival:preferredTypes(2) or {}
    if #preferred > 0 then
      detail[#detail + 1] = {
        label = "PREFERRED TYPE",
        right = table.concat(preferred, "/"):sub(1, 18),
        value = "_line",
      }
    end
    if ace then
      detail[#detail + 1] = {
        label = "FAVOURITE",
        right = Util.spaced(ace):sub(1, 18),
        value = "_line",
      }
    end
  end
  if self:relationshipsEnabled() then
    local tick = self.sim and self.sim.tick or 0
    local bond = rival:bondWith("player", tick)
    detail[#detail + 1] = {
      label = "TOWARD YOU",
      right = (Relationships.label(Relationships.state(bond)):upper()
        .. " " .. tostring(bond.wins or 0) .. "-" .. tostring(bond.losses or 0)):sub(1, 18),
      value = "_line",
    }
    for _, other in ipairs(self.rivals) do
      if other.id ~= rival.id then
        detail[#detail + 1] = {
          label = ("TOWARD " .. tostring(other.name)):sub(1, 16),
          right = Relationships.label(rival:relationshipTo(other.id, tick)):upper(),
          value = "_line",
        }
      end
    end
  end
  return detail
end

function M:rivalBattleMode(rival, requested)
  if not rival then return "UNAVAILABLE" end
  -- Accompanying no longer blocks challenges: the fight is allowed and the
  -- companion state is cleared when the challenge actually starts.
  local ow = self:getOverworld()
  local canQueue = ow and type(ow.queueScript) == "function"
  local canRun = ow and ow.runner and type(ow.runner.run) == "function"
  if not (canQueue or canRun) then return "UNAVAILABLE" end
  local playerParty = self.game and self.game.save and self.game.save.party
  if type(playerParty) ~= "table" or #playerParty == 0 then return "UNAVAILABLE" end
  local rivalHealthy, playerHealthy = 0, 0
  for _, slot in ipairs(rival.party or {}) do
    if (tonumber(slot.hp) or rival:maxHpOf(slot)) > 0 then rivalHealthy = rivalHealthy + 1 end
  end
  for _, slot in ipairs(playerParty) do
    if (tonumber(slot.hp) or 1) > 0 then playerHealthy = playerHealthy + 1 end
  end
  if rivalHealthy == 0 then return "FAINTED" end
  local wanted = requested or (self.challengeModes and self.challengeModes[rival.id]) or "SINGLE"
  if wanted == "DOUBLE" and rivalHealthy >= 2 and playerHealthy >= 2 then return "DOUBLE" end
  return "SINGLE"
end

-- Phone menus sit above the overworld, so the normal rivalBattleMode() cannot
-- truthfully test queueScript/runner availability until the Pokégear closes.
-- This checks only the conditions that are meaningful while actually on the
-- call; queueRivalAction stages the launch for the next idle overworld frame.
function M:phoneRivalBattleMode(rival, requested)
  -- Phone challenges are always available while the rival and player both
  -- have healthy Pokémon. Accompanying the rival no longer blocks a call
  -- challenge (the fight simply starts once the Pokégear closes).
  if not rival then return "UNAVAILABLE" end
  local playerParty = self.game and self.game.save and self.game.save.party
  if type(playerParty) ~= "table" or #playerParty == 0 then return "UNAVAILABLE" end
  local rh, ph = 0, 0
  for _, slot in ipairs(rival.party or {}) do
    if (tonumber(slot.hp) or rival:maxHpOf(slot)) > 0 then rh = rh + 1 end
  end
  for _, slot in ipairs(playerParty) do
    if (tonumber(slot.hp) or 1) > 0 then ph = ph + 1 end
  end
  if rh == 0 then return "FAINTED" end
  if ph == 0 then return "UNAVAILABLE" end
  local wanted = requested or (self.challengeModes and self.challengeModes[rival.id]) or "SINGLE"
  if wanted == "DOUBLE" and rh >= 2 and ph >= 2 then return "DOUBLE" end
  return "SINGLE"
end

function M:canToggleChallengeDouble(rival)
  if not rival then return false end
  local rh, ph = 0, 0
  for _, slot in ipairs(rival.party or {}) do
    if (tonumber(slot.hp) or rival:maxHpOf(slot)) > 0 then rh = rh + 1 end
  end
  for _, slot in ipairs((self.game and self.game.save and self.game.save.party) or {}) do
    if (tonumber(slot.hp) or 1) > 0 then ph = ph + 1 end
  end
  return rh >= 2 and ph >= 2
end

-- Construct and push a manual Gen 1 rival battle without relying on the
-- queued script `start_battle` verb. Some Android builds accept that queue
-- but never drain the battle row, producing a truthful-looking acceptance
-- message followed by nothing. The pending rival is already set, so the
-- trainer.party hook below supplies its live team during construction.
-- 3.1.0 -- GOLD TRAINER BATTLES, ENTIRELY INSIDE THE MOD.
--
-- We shipped patches/0001-gen2-mod-trainer-battle.patch for this. An engine
-- patch is not acceptable: a mod has to work on a stock install, and a player
-- who cannot patch their engine had a feature that silently did nothing.
--
-- The supported route was there the whole time, and the engine's own source
-- names it twice:
--
--   * src/mods/Gen2Compat.lua marks BattleState.newTrainer ABSENT with the
--     reason "Gold has no factory that returns an unpushed battle, and
--     World:startBattle constructs and pushes in one call." So the Gen 1 path
--     below cannot work on Gold -- but startBattle can.
--   * src/world/gen2/WorldAPI.lua refuses `start_battle "trainer"` because
--     "the trainer arm needs a party out of the extracted trainer table and an
--     OPP_CLASS the mod cannot name". That is a limit of the SCRIPT VERB, not
--     of World:startBattle, which takes `opts.trainer` directly
--     (src/world/gen2/World.lua:5822).
--   * src/battle/gen2/Battle.lua:273-288 then calls the `trainer.party` hook
--     with the class and member id, and says outright: "a mod that hands back
--     rows it built itself keeps them, because nothing here rewrites what the
--     hook returned."
--
-- That hook is the one our rivals have fought through since 1.1. So Gold needs
-- no party out of the extracted table and no OPP_CLASS we cannot name: we pass
-- the trainer shell, our own hook answers with the rival's real live team, and
-- the battle is ours.
function M:pushGen2RivalBattle(rival)
  if not rival then return false, "no rival" end
  local world = mod.world
  if not (world and type(world.overworld) == "function") then
    return false, "no Gen 2 world facade"
  end
  local ok, result = pcall(function()
    local ow = world:overworld()
    if not (ow and type(ow.startBattle) == "function") then
      error("this world cannot start battles directly")
    end
    local classId = rival.def and rival.def.trainerClass
    if not classId then error("rival has no trainer class") end
    -- The shell only. `party = {}` is deliberate: an empty roster is what
    -- makes the trainer.party hook the single source of the team, so a Gold
    -- battle and a Gen 1 battle fight the SAME persistent party rather than
    -- two rosters that can drift apart.
    ow:startBattle({
      trainer = {
        name = rival.name,
        class = classId,
        classId = classId,
        index = 1,
        memberId = 1,
        party = {},
      },
    }, function()
      -- No completion work here on purpose. The mod already settles a rival
      -- battle from the `battle.ended` event (see the handler that records the
      -- result, the relationship, the service credit and the story beat), and
      -- Gold raises that event under the same name. Doing it again in this
      -- callback would double-count every battle -- two memory rows, two
      -- relationship swings, two career credits.
      --
      -- An earlier draft called M:onRivalBattleFinished here. No such function
      -- exists; it would have raised inside a pcall on every Gold battle and
      -- silently eaten the outcome.
    end)
    return true
  end)
  if ok and result == true then return true end
  Util.lastError = "gen2 rival battle: " .. tostring(result)
  return false, Util.lastError
end

function M:pushManualRivalBattle(rival, ow)
  -- Gold first: its BattleState facade marks newTrainer absent, so the Gen 1
  -- construction below cannot succeed there and trying it first would only
  -- produce a misleading error.
  if self.versionKey == "gen2" then
    local done, line = self:pushGen2RivalBattle(rival)
    if done then return true end
    Util.lastError = line or Util.lastError
    return false, Util.lastError
  end
  local ok, result = pcall(function()
    local Game = self.game
    if not Game then error("game unavailable") end
    local controller = (Game and Game.overworld) or ow
    if not (controller and type(controller.pushBattle) == "function") then
      error("overworld cannot push battles")
    end
    local BattleState = requireBattleState()
    local classId = rival and rival.def and rival.def.trainerClass
    if not classId then error("rival has no trainer class") end
    local battle = BattleState.newTrainer(Game, classId, 1)
    if not battle or battle.dead then error("trainer battle was refused") end
    if not battle.onFinish then
      battle.onFinish = function(value)
        if controller.afterBattle then controller:afterBattle(value, battle) end
      end
    end
    controller:pushBattle(battle)
    return true
  end)
  if ok and result == true then return true end
  Util.lastError = "manual rival battle launch: " .. tostring(result)
  return false, Util.lastError
end

function M:updatePendingRivalBattle(dt)
  local launch = self.pendingRivalBattleLaunch
  if not launch then return false end
  launch.age = (tonumber(launch.age) or 0) + (tonumber(dt) or 0)
  -- Let the dialogue screen leave the stack before pushing BattleState.
  local ready = self:overworldIdle()
    or (launch.age >= 0.35 and self:overworldRunnerIdle())
  if launch.age < 0.08 or not ready then return true end
  self.pendingRivalBattleLaunch = nil
  -- A stale delayed callback must never resurrect an old battle after another
  -- sequence has begun.
  if not self.rivalBattleSequenceActive
      or self.rivalBattleActiveRivalId ~= launch.rivalId then
    return true
  end
  local rival = self.byId[launch.rivalId]
  local ow = self:getOverworld()
  local ok, line = self:pushManualRivalBattle(rival, ow)
  if not ok then
    -- Last-resort engine-owned execution for an iOS revision that refuses
    -- direct BattleState construction. Unlike the broken queueScript path,
    -- runner:run executes this single row immediately at an idle boundary.
    local ran, accepted = false, false
    if ow and ow.runner and type(ow.runner.run) == "function" and rival then
      ran, accepted = pcall(function()
        return ow.runner:run({ { "start_battle", "trainer",
          rival.def.trainerClass, 1 } }, {})
      end)
    end
    if ran and accepted ~= false then return true end
    self.pending, self.pendingChampion = nil, nil
    -- A failed launch must release the lock, or the mod is wedged for the rest
    -- of the session.
    self.rivalBattleSequenceActive = false
    self.rivalBattleActiveRivalId = nil
    self.worldChallenge = false
    if rival then pcall(function() rival:setState("IDLE", "challenge launch failed") end) end
    self.ticker = { text = "NOTICE  •  " .. tostring(line), age = 0,
      duration = 8, offset = 0 }
  end
  return true
end

-- One exit for the complete challenge transaction. The old release lived only
-- in world.blacked_out, so an ordinary win/clean loss left this lock set for
-- the rest of the session and every later challenge reported "already in
-- progress".
function M:releaseRivalBattleSequence(rivalId)
  return BattleFlow.release(self, rivalId)
end

function M:startRivalChallenge(rival, requestedMode, tournamentMatch)
  -- Checked BEFORE any state mutation: a refused second request must leave the
  -- first transaction exactly as it found it.
  if self.rivalBattleSequenceActive then
    return false, "A rival battle is already in progress."
  end
  if self.pendingRivalBattleLaunch then
    return false, "A rival battle is already being prepared."
  end
  -- Explicit double request when the rival only has one healthy Pokémon.
  if requestedMode == "DOUBLE" and self:rivalHealthyCount(rival) < 2 then
    local line = "Sorry, I only have one Pokémon with me."
    return false, line
  end
  local mode = self:rivalBattleMode(rival, requestedMode)
  if mode == "UNAVAILABLE" then
    return false, "A battle is unavailable right now."
  end
  if mode == "FAINTED" then return false, rival.name .. " has no healthy Pokémon." end
  -- If they asked for doubles but the mode fell back to single because the
  -- rival cannot field two, surface the same spoken refusal.
  if requestedMode == "DOUBLE" and mode ~= "DOUBLE" then
    return false, "Sorry, I only have one Pokémon with me."
  end
  local ow = self:getOverworld()
  if not ow then
    return false, "Battle cannot start on this screen."
  end
  -- If they were accompanying the player, step out of companion mode first
  -- so the challenge is a real fight rather than an ally battle.
  if rival and rival.id == self.companionId then
    pcall(function() self:setCompanion(nil) end)
  end
  -- A direct player challenge is immediate: never withdraw from the PC, teach
  -- a TM or walk away to prepare after the player has pressed CHALLENGE.
  self.pending = rival
  self.pendingTournamentMatch = tournamentMatch == true
  self.tournamentExpActive = tournamentMatch == true
  self.rivalBattleSequenceId = (tonumber(self.rivalBattleSequenceId) or 0) + 1
  self.rivalBattleSequenceActive = true
  self.rivalBattleActiveRivalId = rival.id
  rival._rivalBattleSequenceId = self.rivalBattleSequenceId
  rival:setState("CHALLENGING_PLAYER", "accepted a direct challenge")
  if mode == "DOUBLE" and type(mod.exports.allowNextScriptedDouble) == "function" then
    pcall(mod.exports.allowNextScriptedDouble)
  end
  -- 1.39.0 §30: a title shot is EARNED, not owed.
  --
  -- This used to fire on eight badges alone, so a rival could challenge the
  -- player for the Championship without ever having beaten the Elite Four --
  -- an entitlement the player does not have, and §38 requires the AI to play
  -- by the same rules. It now additionally requires a qualifying run: the
  -- rival must have CLEARED the Elite Four since it last held the title.
  local titleChallenge = self.playerChampion == true
    and rival.nextBadge and rival:nextBadge() == nil and rival.champion ~= true
    and rival.mayChallengeTitle and rival:mayChallengeTitle()
  if titleChallenge then self.pendingChampion = rival end
  local line = titleChallenge and self.dialogue:championChallenge(rival)
    or self.dialogue:challenge(rival)
  local rows = {
    { "show_text", line },
    { "start_battle", "trainer", rival.def.trainerClass, 1 },
  }
  local ok, accepted
  -- Every Gen 1 host, including iOS: run dialogue only, then push BattleState
  -- after its completion callback. iOS was previously left on queueScript,
  -- but field reports confirm that it too can accept start_battle without
  -- ever executing it. The delayed push happens only after the text/UI stack
  -- is clear, which is the portability condition the old iOS branch lacked.
  if self.generation ~= 2
      and ow.runner and type(ow.runner.run) == "function" then
    ok, accepted = pcall(function()
      return ow.runner:run({ { "show_text", line } }, {
        onDone = function()
          self.pendingRivalBattleLaunch = { rivalId = rival.id, age = 0 }
        end,
      })
    end)
  elseif type(ow.queueScript) == "function" then
    ok, accepted = pcall(function() return ow:queueScript(rows) end)
  elseif ow.runner and type(ow.runner.run) == "function" then
    ok, accepted = pcall(function() return ow.runner:run(rows, {}) end)
  else
    ok, accepted = false, "no trainer script path"
  end
  if not ok or accepted == false then
    self.pending, self.pendingChampion, self.pendingRivalBattleLaunch = nil, nil, nil
    self.tournamentExpActive = false
    self.rivalBattleSequenceActive = false
    self.rivalBattleActiveRivalId = nil
    self.worldChallenge = false
    rival:setState("IDLE", "challenge could not start")
    return false, "Battle queue failed: " .. tostring(accepted)
  end
  return true, mode .. " battle accepted."
end

-- Execute choices after the menu closes, when the overworld is active again.
function M:queueRivalAction(rival, value)
  if type(value) == "table" then value = value.value or value.id end
  if value == "_story" and rival and self.game then
    mod.ui.push(self.game, SCREEN .. "Story", { rival = rival })
    return true
  end
  -- Touch/iOS list menus may return the selected row rather than its value.
  -- Normalise both forms here so every caller gets the same behaviour.
  if type(value) == "table" then value = value.value or value.id end
  local valid = value == "_help" or value == "_trade" or value == "_repair"
    or value == "_accompany" or value == "_challenge"
    or value == "_challenge_single" or value == "_challenge_double"
    or (type(value) == "string" and (value:sub(1, 9) == "_qaccept:"
        or value:sub(1, 8) == "_qclaim:"))
  if not (rival and rival.id and valid) then return false end
  self.pendingRivalAction = { rivalId = rival.id, value = value, age = 0 }
  return true
end

function M:performRivalAction(rival, value)
  if not rival then return false, "That rival is no longer available." end
  if type(value) == "string" and value:sub(1, 9) == "_qaccept:" then
    local id = value:sub(10)
    if self.quests then return self.quests:accept(id) end
    return false, "No quests."
  end
  if type(value) == "string" and value:sub(1, 8) == "_qclaim:" then
    local id = value:sub(9)
    if self.quests then
      local ok, msg = self.quests:claim(id)
      if ok and self.factions then self.factions:adjust("gym", 2, "quest_claim") end
      return ok, msg
    end
    return false, "No quests."
  end
  if value == "_help" then return self:helpRequest(rival)
  elseif value == "_trade" then return self:tradeOffer(rival)
  elseif value == "_repair" then return self:repairRivalPosition(rival, "manual repair")
  elseif value == "_accompany" then
    if self.companionId == rival.id then return self:setCompanion(nil) end
    return self:setCompanion(rival)
  elseif value == "_challenge_single" then
    self.challengeModes = self.challengeModes or {}
    self.challengeModes[rival.id] = "SINGLE"
    return self:startRivalChallenge(rival, "SINGLE")
  elseif value == "_challenge_double" then
    self.challengeModes = self.challengeModes or {}
    self.challengeModes[rival.id] = "DOUBLE"
    return self:startRivalChallenge(rival, "DOUBLE")
  elseif value == "_challenge" then
    return self:startRivalChallenge(rival, (self.challengeModes or {})[rival.id])
  end
  return false, "Unknown rival action."
end

-- ------------------------------------------------------------------
-- The Pokegear conversation (4.5.0)
-- ------------------------------------------------------------------

-- Which rival is on the other end of this contact?  syncRivalComms stamps
-- record.rivalId, but a save written before that did not, so fall back to the
-- contact id the rival contacts have always been keyed by rather than
-- returning nil and telling the player their rival is an ordinary trainer.

-- What this caller can honestly say about that rival.  The model is in
-- src/Scout.lua and is derived on every open: a report is never stored, so it
-- cannot contradict the world it describes.  A nil caller is an ordinary
-- trainer, who holds no head-to-head record and answers at rumour level.
function M:scoutReport(caller, subject)
  if not subject then return nil end
  local tick = self.sim and self.sim.tick or 0
  local ok, report = pcall(Scout.report, caller, subject, tick)
  if ok and type(report) == "table" then return report end
  return { level = "NONE", headline = "NO ANSWER", rows = {},
    line = "I can't help with that." }
end

-- ------------------------------------------------------------------
-- Trainer rankings and records (4.6.0)
-- ------------------------------------------------------------------
-- The rankings table and every trainer record are DERIVED on open. Nothing
-- about an achievement is stored: "Defeated Brock" is the badge case joined to
-- the gym table, the Elite Four line is the League record, the rivalries are
-- the bonds. A screen built this way cannot drift from the world, and a save
-- edit that removes a badge removes the sentence about it too.

-- 4.7.0 title presentation accessors. Titles are derived from live rival state,
-- so every UI/reporting caller agrees on the same spoken name.
function M:titleOf(rival)
  local ok, title = pcall(Titles.of, rival, self.data)
  return ok and title or nil
end

function M:spokenNameOf(rival)
  local title = self:titleOf(rival)
  if title then return title end
  return rival and rival.name or "?"
end

function M:fullNameOf(rival)
  local ok, full = pcall(Titles.full, rival, self.data)
  if ok and full then return full end
  return rival and rival.name or "?"
end

function M:playerFacts()
  local name
  pcall(function()
    local save = self.game and self.game.save
    name = save and (save.playerName or (save.trainer and save.trainer.name))
  end)
  if type(name) ~= "string" or name == "" then name = "Player" end
  local party = {}
  pcall(function()
    party = (self.game and self.game.save and self.game.save.party) or {}
  end)
  return {
    name = name,
    badges = self:playerBadgeCount(),
    caught = #party,
    champion = self.playerChampion == true,
  }
end

function M:trainerRankings()
  local ok, rows = pcall(Rankings.build, self.rivals, self:playerFacts())
  if ok and type(rows) == "table" then return rows end
  return {}
end

-- The names the record screen needs to say who a rivalry is WITH. Built from
-- the live roster rather than stored with the bond: a bond holds an id, and
-- the id resolves to whatever that rival is called now.
function M:rivalNames()
  local names = {}
  for _, rival in ipairs(self.rivals or {}) do
    if rival and rival.id then names[rival.id] = rival.name end
  end
  return names
end

function M:trainerRecord(rivalId, isPlayer)
  if isPlayer then
    -- The player's own row. The mod knows the badge case and the title and
    -- nothing else about them, and it says so rather than inventing a career:
    -- the player's Pokemon, rivalries and history are the GAME's business, not
    -- this mod's, and a screen that guessed at them would be making things up.
    local facts = self:playerFacts()
    return {
      name = facts.name, badges = facts.badges,
      eliteFour = facts.champion and "Defeated" or "Not yet",
      champion = facts.champion, defences = 0,
      career = facts.champion and "Trainer -> Champion" or "Trainer",
      rivalries = {}, highlights = {},
    }
  end
  local rival = rivalId and self.byId and self.byId[rivalId] or nil
  if not rival then return nil end
  local ok, record = pcall(Achievements.record, rival, {
    gyms = self.gyms,
    notable = NOTABLE,
    names = self:rivalNames(),
    playerName = self:playerFacts().name,
    tick = self.sim and self.sim.tick or 0,
    -- Rival has no label accessor of its own; LifePath owns the vocabulary,
    -- so ask it rather than writing a second copy of the mapping here.
    lifePathLabel = rival.lifePathId and LifePath.label(rival:lifePathId()) or nil,
    careerRank = rival.careerRank and rival:careerRank() or nil,
  })
  if not (ok and type(record) == "table") then return nil end
  -- The relationship LABEL is presentation, so it is resolved here rather than
  -- in the pure module: Relationships owns the vocabulary and nothing else
  -- restates it (lesson 19).
  for _, row in ipairs(record.rivalries or {}) do
    row.label = Relationships.label(row.state)
  end
  return record
end

-- A call the player placed is still a call: it belongs in the history the
-- CALL HISTORY screen reads.  Comms.record refuses any reason outside its
-- closed set, so an unknown reason is dropped rather than invented.
function M:noteCall(contactId, reason)
  if not (self.comms and contactId) then return false end
  local entry = Comms.record(self.comms, contactId, reason,
    self.sim and self.sim.tick or 0, { incoming = false })
  if entry then pcall(function() self:save() end) end
  return entry ~= nil
end

function M:tournamentLimits(mode)
  if not self.tournaments then return 0 end
  return self.tournaments:maxPlayerRivals(mode == "DOUBLE" and "DOUBLE" or "SINGLE")
end

function M:arrangeTournament(hostRivalId, count, mode, venueMap)
  if not self.tournaments then self.tournaments = Tournaments.new(self) end
  local world = self:worldView() or {}
  venueMap = venueMap or world.playerMap
  if not venueMap then return false, "You cannot arrange a tournament here." end
  local ok, line = self.tournaments:startPlayer(hostRivalId, count, mode, venueMap)
  if ok and hostRivalId then
    self:noteCall("PHONE_AIR_" .. string.upper(tostring(hostRivalId)), "TOURNAMENT")
  end
  return ok, line
end

function M:openRivalMenu(rival)
  if not (rival and self.game) then return false end
  mod.ui.push(self.game, SCREEN .. "Detail", {
    rival = rival, items = self:rivalDetailItems(rival),
  })
  return true
end

function M:interactWithRival(rival, npc)
  -- Direct-call compatibility path. Spoken dialogue belongs in a TextBox, not
  -- in the WORLD NEWS ticker. Queue the exact same show_text row used by the
  -- authoritative talk handler, then let the normal idle-frame menu opener run.
  if not rival or self.rivalInteractionOpen then return false end
  self.rivalInteractionOpen = true
  local line = self.pendingLine or (self.dialogue and self.dialogue:greeting(rival)) or (rival.name .. ".")
  self.pendingLine = nil
  local ow = self:getOverworld()
  local rows = { { "show_text", tostring(line) } }
  local accepted = false
  if ow and ow.runner and type(ow.runner.run) == "function" then
    local ok, result = pcall(function()
      return ow.runner:run(rows, {
        npc = npc,
        onDone = function() self.pendingRivalMenu = rival.id end,
      })
    end)
    accepted = ok and result ~= false
  end
  if not accepted and ow and type(ow.queueScript) == "function" then
    local ok, result = pcall(function() return ow:queueScript(rows) end)
    accepted = ok and result ~= false
  end
  -- Even if a conversion has no usable text runner, do not misuse the news
  -- ticker. The interaction menu still remains available.
  self.pendingRivalMenu = rival.id
  return true
end

-- Which rival is the player facing?  The talk script runs with the overworld's
-- own notion of the talked-to object, so we resolve by position: the rival
-- standing on the cell the player is facing.
function M:facedRival()
  local where
  pcall(function()
    where = mod.world and mod.world.current and mod.world:current()
  end)
  if not where then return nil end
  local dx, dy = 0, 0
  local facing = where.facing
  -- Gold wrappers may expose the player's facing on the live entity rather
  -- than WorldAPI.current(). Preserve current() as the first choice.
  if not facing then
    pcall(function()
      local ow = self:getOverworld()
      facing = ow and ow.player and ow.player.facing
    end)
  end
  if facing == "up" then dy = -1
  elseif facing == "down" then dy = 1
  elseif facing == "left" then dx = -1
  elseif facing == "right" then dx = 1 end
  local fx, fy = (where.x or 0) + dx, (where.y or 0) + dy
  local best, bestDist
  local currentMap = where.mapId or where.map
  for _, rival in ipairs(self.rivals) do
    if rival.map == currentMap then
      local rx, ry = rival.x, rival.y
      if rx == fx and ry == fy then return rival end
      if rx and ry then
        local d = math.abs(rx - fx) + math.abs(ry - fy)
        if d <= 1 and (not bestDist or d < bestDist) then
          best, bestDist = rival, d
        end
      end
    end
  end
  if best then return best end
  -- Fallback: any rival on this map (lab gauntlet)
  if where.mapId == gauntletLabId() then
    for _, rival in ipairs(self.rivals) do
      if rival.map == where.mapId then return rival end
    end
  end
  return nil
end

-- The script verb our talk rows call.  Registered through mod.commands, which
-- is the one script extension point that works on BOTH generations.
mod.commands:register("ai_rivals:talk", function(ctx)
  local rival = M:facedRival()
  if not rival then return end
  -- the intro gauntlet owns talking while it is active
  if M:gauntletActive() then
    return M:talkGauntlet(rival)
  end
  -- Talking is allowed during a battle sequence -- refusing it would leave a
  -- rival unresponsive for the whole transaction -- but it must never launch a
  -- second battle from the same frame or from an intro callback.
  if M.rivalBattleSequenceActive or M.pendingRivalBattleLaunch then
    return { { "show_text", M.dialogue:greeting(rival) } }
  end
  local wantsFight = mod.options:get("encounters")
    and AI.wantsToChallenge(rival, M:worldView())

  if wantsFight then
    M.rivalBattleSequenceId = (tonumber(M.rivalBattleSequenceId) or 0) + 1
    M.rivalBattleSequenceActive = true
    M.rivalBattleActiveRivalId = rival.id
    rival._rivalBattleSequenceId = M.rivalBattleSequenceId
    M.pending = rival
    local titleChallenge = M.playerChampion == true
      and rival.nextBadge and rival:nextBadge() == nil
      and rival.champion ~= true
    if titleChallenge then M.pendingChampion = rival end
    rival:setState("CHALLENGING_PLAYER", "talked to")
    return {
      { "show_text", titleChallenge and M.dialogue:championChallenge(rival)
          or M.dialogue:challenge(rival) },
      { "start_battle", "trainer", rival.def.trainerClass, 1 },
    }
  end
  return { { "show_text", M.dialogue:greeting(rival) } }
end)



mod.commands:register("ai_rivals:rocket_talk", function(ctx)
  if not M.rocket then return end
  local where
  pcall(function() where = mod.world and mod.world.current and mod.world:current() end)
  local npc = ctx and (ctx.npc or ctx.target or ctx.object)
  local npcId = ctx and (ctx.npcId or ctx.id)
  local npcName
  pcall(function() npcName = npc and (npc.name or (npc.def and npc.def.name)) end)
  local member = M.rocket:memberAtNpc(npcId, npcName)
  if not member and where then member = M.rocket:memberAtNpc(nil, "AIR_ROCKET_"..tostring(ctx and ctx.memberId or "")) end
  if not member then return end
  local class=M.rocket:classForMember(member)
  M.pendingRocket=member
  M.rivalBattleSequenceActive=true
  M.rivalBattleActiveRivalId=nil
  return {{"show_text", M.rocket:dialogueFor(member, "challenge")},{"start_battle","trainer",class,1}}
end)

-- TEAM ROCKET PLAYER INTERACTION / AMBUSH
-- Rocket NPCs use the same trainer battle seam as rivals, but their state lives
-- entirely in src/Rocket.lua. This keeps the opposing simulation independent.
function M:rocketAmbush(member)
  if not (member and M.rocket and self.game) then return false end
  if self.rivalBattleSequenceActive then return false end
  local class = M.rocket:classForMember(member)
  if not class then return false end
  self.pendingRocket = member
  self.rivalBattleSequenceId = (tonumber(self.rivalBattleSequenceId) or 0) + 1
  self.rivalBattleSequenceActive = true
  self.rivalBattleActiveRivalId = nil
  local line = M.rocket:dialogueFor(member, "sight")
  local ow = self:getOverworld()
  local rows = { { "show_text", line }, { "start_battle", "trainer", class, 1 } }
  local ok, accepted = pcall(function()
    if ow and ow.runner and type(ow.runner.run) == "function" then
      return ow.runner:run({ { "show_text", line } }, {
        onDone=function() self.pendingRocketBattleLaunch={ memberId=member.id, age=0 } end,
      })
    elseif ow and type(ow.queueScript) == "function" then
      return ow:queueScript(rows)
    end
    return false
  end)
  if not ok or accepted == false then
    self.pendingRocket=nil; self.pendingRocketBattleLaunch=nil
    self.rivalBattleSequenceActive=false
    self.rivalBattleActiveRivalId=nil
    return false
  end
  return true
end

function M:rocketNews()
  return self.rocket and self.rocket.news or {}
end

-- THE PARTY SWAP.  This is what makes a rival battle real: the registry
-- record is a placeholder, and this hook replaces it with the rival's live
-- team the instant a battle against that class is built.  Everything the
-- engine does downstream -- stats, DVs, AI class, exp award, the payout --
-- is the vanilla trainer path, untouched.
--
-- GEN 2 passes the class NAME (or its numeric constant) and the member id;
-- the rival matches its own class, the story class it shadows, or the class
-- constant its overworld object carries.  The battle mons are built from the
-- class member's `party` rows (M:syncGen2Party keeps them live), so the
-- vanilla roster already IS the rival's team and the hook returns it after
-- refreshing the rows.


mod.hooks:wrap("trainer.party", function(next, oppClass, partyIndex, party)
  local vanilla = next(oppClass, partyIndex, party)
  -- Capture a fallback contact for scripted trainer battles that do not emit
  -- world.interacted. The exact NPC identity is used when available; otherwise
  -- class+map remains stable and deterministic.
  if not M.byTrainerClass or not M.byTrainerClass[oppClass] then
    local contact = M:contactForTrainerBattle(oppClass, partyIndex)
    if contact then M.pendingTrainerContact = contact end
  end
  -- The final Gen 1 League rival is normally OPP_RIVAL3. Replace only its
  -- party; its vanilla map/script still starts the battle safely.
  if oppClass == "OPP_RIVAL3" then
    local champion = M:eliteChampion()
    if champion then
      M.pending = champion
      M.pendingChampion = champion
      if champion.prepareForBattle then champion:prepareForBattle() end
      return champion:battleParty()
    end
  end
  if M.rocket then
    local rocketParty = M.rocket:partyForClass(oppClass)
    if rocketParty then
      M.pendingRocket = M.rocket:memberForClass(oppClass)
      return rocketParty
    end
  end
  if M.rangers then
    local rangerParty = M.rangers:partyForClass(oppClass)
    if rangerParty then
      M.pendingRanger = M.rangers:memberForClass(oppClass)
      return rangerParty
    end
  end
  for _, rival in ipairs(M.rivals) do
    local match = rival.def.trainerClass == oppClass
      or (rival.def.gen2Shadow and rival.def.gen2Shadow == oppClass)
      or (type(oppClass) == "number" and M:gen2ClassId(rival) == oppClass)
    if match then
      M.pending = rival
      if M.generation == 2 then
        M:syncGen2Party(rival)
        return vanilla
      end
      return rival:battleParty()
    end
  end
  return vanilla
end)

-- GEN 2's engagement seam: fires the moment a trainer's sight cone or an A
-- press picks a trainer object, BEFORE the battle script builds its party, so
-- the class rows are fresh for this fight.  Gen 1 has no single equivalent;
-- its bookkeeping happens in trainer.party and battle.ended instead.

-- ------------------------------------------------------------------------
-- Pokégear trainer network
-- ------------------------------------------------------------------------











-- A Gen 1 trainer battle does not have one universal "trainer engaged" event,
-- so remember the most recent trainer object the player interacted with. The
-- battle-ended path then turns that exact NPC into a phone contact.
mod.events:on("world.interacted", function(ev)
  if not ev or ev.kind ~= "trainer" or not ev.target then return end
  local mapId = ev.mapId
  if Comms.isGymMap(mapId) then return end
  local contact = Comms.trainerFromObject(ev.target, mapId)
  if contact then
    M.pendingTrainerContact = contact
  end
end)

mod.events:on("world.trainer_engaged", function(ev)
  -- Engagement events can be emitted again while the first battle's intro is
  -- still unwinding. Ignore them until the active transaction ends.
  if M.rivalBattleSequenceActive then return end
  if M.generation ~= 2 then return end
  if not ev or not ev.trainerClass then return end
  -- the payload's trainerClass is the numeric class constant the overworld
  -- object carried (record.class), so match against the stored one
  local engaged = tonumber(ev.trainerClass) or ev.trainerClass
  local ordinary = M:contactForTrainerBattle(engaged, ev.memberId or ev.partyIndex or ev.index)
  if ordinary and Comms.isOrdinaryTrainer(ordinary.trainerClass, ordinary.name, ordinary.map) then
    M.pendingTrainerContact = ordinary
  end
  for _, rival in ipairs(M.rivals) do
    if M:gen2ClassId(rival) == engaged then
      M.pendingTrainerContact = nil
      M.pending = rival
      M:syncGen2Party(rival)
      return
    end
  end
end)

mod.events:on("battle.started", function(ev)
  local save=M.game and M.game.save
  M.classBattleMoneyBefore=save and tonumber(save.money) or nil
  M.classBattlePartyBefore,M.classBattleBoxBefore=classStorageCounts(save)
  M.playerMovesSeen = {}
  local party = M.game and M.game.save and M.game.save.party or {}
  local lead = party[1] and (party[1].species or party[1].speciesId)
  M.playerBattleObservation = { lead = lead, location = M:worldView().playerMap }
end)

-- The absorbed double engine can identify moves the player actually selected.
-- Single-battle builds that expose no equivalent event simply reveal no move;
-- they never fall back to reading the complete save-party moveset.
mod.events:on("mod.ai_rivals.player_move_revealed", function(ev)
  local species, move = ev and ev.species, ev and ev.move
  if type(species) ~= "string" or type(move) ~= "string" then return end
  M.playerMovesSeen = M.playerMovesSeen or {}
  M.playerMovesSeen[species] = M.playerMovesSeen[species] or {}
  M.playerMovesSeen[species][move] = true
end)

local function applyRevealedPlayerMoves(rival)
  if not (rival and rival.rememberRevealedMove) then return end
  for species, moves in pairs(M.playerMovesSeen or {}) do
    for move in pairs(moves) do
      rival:rememberRevealedMove("player", species, move)
    end
  end
end

mod.events:on("battle.ended", function(ev)
  local save=M.game and M.game.save
  local before=tonumber(M.classBattleMoneyBefore); local after=save and tonumber(save.money)
  if before and after and after>before and ev and ev.result=="win" then
    local delta=after-before; local mult=TrainerClasses.moneyMultiplier(M.playerClassId)
    save.money=math.max(0,after+math.floor(delta*(mult-1)))
  end
  applyPlayerClassDVsAfterBattle()
  M.classBattleMoneyBefore=nil; M.classBattlePartyBefore=nil; M.classBattleBoxBefore=nil
  M.worldChallenge = nil
  -- Ordinary Kanto trainers outside gyms join the phone network after a
  -- successful battle. The contact is created once and never duplicated.
  local trainerContact = M.pendingTrainerContact
  local phoneBattle = M.pendingPhoneTrainer
  if trainerContact and not phoneBattle then
    local playerWon = (ev and ev.result) == "win"
    if playerWon and not Comms.isGymMap(trainerContact.map) then
      M:offerTrainerPhone(trainerContact)
    end
  end
  M.pendingTrainerContact = nil
  M._gauntletStarting = false
  M._gauntletQueued = false
  local battle = ev and ev.battle
  local oppClass = battle and (battle.oppClass
    or (battle.trainer and battle.trainer.classId))
  if M.pendingPhoneTrainer and
     (not oppClass or tostring(oppClass) == tostring(M.pendingPhoneTrainer.trainerClass)) then
    M.pendingPhoneTrainer = nil
  end
  -- Vanilla lab rival (Blue / OPP_RIVAL1): unlock the AI gauntlet walk-up
  if oppClass == "OPP_RIVAL1" or oppClass == "RIVAL1"
     or oppClass == "OPP_RIVAL" or tostring(oppClass):match("RIVAL1") then
    M.blueBattled = true
    -- Kick the AI gauntlet the moment Blue's fight ends
    if M.gauntlet and M.gauntlet.active and not M:gauntletDone() then
      M.gauntlet.phase = "approach"
      M.gauntlet.phaseT = 0
      M.gauntlet.approachAge = 0
      M.gauntlet.challenging = false
    end
  end
  -- Also accept the flag if the engine set it during the battle script
  pcall(function()
    if M:blueLabBattled() then M.blueBattled = true end
  end)

  local rival, activeId = BattleFlow.endedRival(M)
  if not rival then
    -- A completed locked battle with a lost pending pointer must still unlock.
    if activeId then M:releaseRivalBattleSequence(activeId) end
    return
  end
  local championBattle = M.pendingChampion == rival
  if oppClass then
    local matched = BattleFlow.matches(M, rival, activeId, oppClass,
                                       championBattle)
    if not matched then return end
  end
  M.pending = nil
  M.pendingChampion = nil
  if championBattle then M.eliteChampionId = nil end

  -- ev.result is from the PLAYER's side, so a player win is a rival loss
  local playerWon = (ev and ev.result) == "win"
  pcall(function()
    Happiness.noteRivalBattle(rival,not playerWon,"PLAYER")
    Happiness.noteFaints(rival)
  end)
  Util.guard("battle.ended", function()
    rival:recordPlayerBattle(not playerWon, M.sim and M.sim.tick or 0)
    if rival.rememberOpponent then
      local playerParty = M.game and M.game.save and M.game.save.party
      rival:rememberOpponent("player", playerParty, not playerWon,
        M.sim and M.sim.tick or 0, false)
      applyRevealedPlayerMoves(rival)
    end
    -- 1.33.0: the battle the player just fought is the strongest cause there
    -- is.  Recorded from the RIVAL's side (it won or it lost), with the badge
    -- gap so a rival far ahead of the player can become a MENTOR rather than
    -- simply a repeated winner.
    M:recordBondBattle(rival, "player", not playerWon,
      { lead = rival:badgeCount() - M:playerBadgeCount() })
    -- 1.34.0: a battle the player fought counts toward the rival's team
    -- service record exactly as a simulated one does, and repeated defeats at
    -- the player's hands are evidence for building specifically against them.
    if rival.creditLeadBattle then rival:creditLeadBattle(not playerWon) end
    -- 1.35.0: §4's arc begins here. Losing to the player opens a setback the
    -- rival has to answer; beating the player later closes it, and the chapter
    -- turns from SETBACK through REBUILDING to RESURGENT as it does.
    if playerWon and rival.noteDefeat then
      rival:noteDefeat("player", M.sim and M.sim.tick or 0)
    elseif not playerWon and rival.noteVictory then
      rival:noteVictory("player", M.sim and M.sim.tick or 0)
    end
    if rival.advanceStory then
      local ok, gained, chapter, chapterChanged, _, notable =
        pcall(rival.advanceStory, rival, M.sim and M.sim.tick or 0)
      if ok then
        for _, milestone in ipairs(gained or {}) do
          M:addNews(rival, { kind = "milestone", milestone = milestone.id,
                             notable = milestone.news == true })
        end
        if chapterChanged and notable then
          M:addNews(rival, { kind = "chapter", chapter = chapter })
        end
      end
    end
    if playerWon and rival.observeTeamEvidence then
      rival:observeTeamEvidence("PLAYER_PROBLEM")
      local _, after, changed = rival:observeTeamEvidence("BEATEN_BADLY")
      if changed then
        M:addNews(rival, { kind = "team_style", style = after })
      end
    elseif not playerWon and rival.observeTeamEvidence then
      local _, after, changed = rival:observeTeamEvidence("WON_QUICKLY")
      if changed then
        M:addNews(rival, { kind = "team_style", style = after })
      end
    end
    if rival.rememberPlayerBattle then
      local observation = M.playerBattleObservation or {}
      observation.rivalWon = not playerWon
      observation.tick = M.sim and M.sim.tick or 0
      observation.species, observation.moves = {}, {}
      for _, slot in ipairs((M.game and M.game.save and M.game.save.party) or {}) do
        local species = slot and (slot.species or slot.speciesId)
        if type(species) == "string" then observation.species[#observation.species + 1] = species end
      end
      for _, moves in pairs(M.playerMovesSeen or {}) do
        for move in pairs(moves) do observation.moves[#observation.moves + 1] = move end
      end
      rival:rememberPlayerBattle(observation)
    end
    if championBattle and playerWon then
      rival.champion = false
      if rival.ensureLeague then League.endReign(rival:ensureLeague(), rival.ticks) end
      if rival.leaveChampionLifePath then rival:leaveChampionLifePath("dethroned by the player") end
      M.playerChampion = true
      M.eliteChampionId = "player"
      if M.blueChampion then M.blueChampion.champion=false end
      M:recordBond(rival, "player", "TITLE_LOST")
      M:addNews(rival, { kind = "news",
        text = "The player dethroned " .. tostring(rival.name) .. "." })
    elseif championBattle and not playerWon and M.playerChampion then
      for _, other in ipairs(M.rivals) do other.champion = false end
      rival.champion = true
      if rival.ensureLeague then League.beginReign(rival:ensureLeague(), rival.ticks) end
      if rival.assumeChampionLifePath then rival:assumeChampionLifePath("dethroned the player") end
      M.playerChampion = false
      M.eliteChampionId = rival.id
      M:recordBond(rival, "player", "TITLE_TAKEN")
      rival.newsPending = "CHAMPION"
      M:addNews(rival, { kind = "news",
        text = tostring(rival.name) .. " dethroned the player." })
    end
    if playerWon then
      if M.quests and M.quests.onRivalDefeated then
        pcall(function() M.quests:onRivalDefeated(rival.id) end)
      end
      -- Engine trainer battles use a defensive party copy, so the rival's
      -- saved HP was previously still full here and AI.evaluate could never
      -- detect a blackout. A player victory is a full defeat: faint the saved
      -- party, warp to the nearest Center, then let the normal HEALING tick
      -- restore it.
      rival:setState("DEFEATED", "lost to the player")
      if rival.blackoutToNearestPokemonCenter then
        rival:blackoutToNearestPokemonCenter("lost to the player", true)
      else
        for _, slot in ipairs(rival.party or {}) do slot.hp = 0 end
        AI.evaluate(rival, M:worldView())
      end
      local loot = M:awardRivalLoot(rival)
      if loot then
        M.pendingLootLine = string.format("%s handed over\na %s!", rival.name, tostring(loot):gsub("_", " "))
      end
      -- 1.15.0: a beaten rival may also part with a small healing item as a
      -- consolation.  It is a real item out of its bag, into the player's.
      if rival.pickGiftItem and rival.rng:chance(0.4) then
        -- Transfer first and debit last: a full/unknown player bag must not
        -- delete an item from the rival's persistent inventory.
        rival:ensureInventory()
        local gifts = {}
        local badges = M:playerBadgeCount()
        for item, count in pairs(rival.inventory or {}) do
          if tonumber(count) and count > 0
             and M:rivalGiftAllowed(item, badges) then
            gifts[#gifts + 1] = item
          end
        end
        local gift = #gifts > 0 and gifts[rival.rng:int(1, #gifts)] or nil
        if gift and M:givePlayerItem(gift) and rival:takeItem(gift) then
          local text = string.format("%s gives you a %s.", rival.name,
                                     tostring(gift):gsub("_", " "))
          M.pendingGiftLine = text
          M:addNews(rival, { kind = "news", text = text })
        end
      end
    end
    local line = championBattle and M.dialogue:championChallenge(rival)
      or M.dialogue:afterBattle(rival, not playerWon)
    if M.pendingLootLine then
      line = (line or "") .. "\f" .. M.pendingLootLine
      M.pendingLootLine = nil
    end
    if M.pendingGiftLine then
      line = (line or "") .. "\f" .. M.pendingGiftLine
      M.pendingGiftLine = nil
    end
    if line then M.pendingLine = line end
  end)

  -- the intro gauntlet: win OR loss -- advance the turn / leave the lab
  M:endGauntletBattle(rival)
  -- If the player blacked out mid-sequence, ensure rivals still depart
  if M.gauntlet and M.gauntlet.active and M.gauntlet.index > #(M.gauntlet.order or {}) then
    M:finishGauntlet()
  end
  if M.pendingTournamentMatch and M.tournaments then
    M.pendingTournamentMatch = nil
    pcall(function() M.tournaments:onPlayerBattleResult(rival.id, playerWon) end)
  end
  M.tournamentExpActive = false
  -- Release after bookkeeping and gauntlet progression, on every normal
  -- battle result (not only blackout).
  M:releaseRivalBattleSequence(rival.id)
end)

-- The post-battle line rides the next talk rather than fighting the engine's
-- own victory text for the same box.

-- Player blackout (loss): still end the gauntlet fight turn and, if that was
-- the last rival (or any lab fight), release them into the world the same as
-- a win.  win/loss is already recorded on battle.ended when it fires; on pure
-- blackout without a clean battle.ended we still finish the lab sequence.
mod.events:on("world.blacked_out", function(ev)
  local blackoutRival = M.pending
    or (M.rivalBattleActiveRivalId and M.byId[M.rivalBattleActiveRivalId])
  pcall(function()
    if not M:gauntletActive() then return end
    local rival = blackoutRival or M:gauntletRival()
    if rival then
      -- Rival won this bout
      pcall(function()
        rival:recordPlayerBattle(true, M.sim and M.sim.tick or 0)
        if rival.rememberOpponent then
          local playerParty = M.game and M.game.save and M.game.save.party
          rival:rememberOpponent("player", playerParty, true,
            M.sim and M.sim.tick or 0, false)
          applyRevealedPlayerMoves(rival)
        end
      end)
      M:endGauntletBattle(rival)
    else
      -- No current rival pointer -- still release the lab
      M:finishGauntlet()
    end
    -- Force full release if somehow still stuck in lab after a loss
    if M:gauntletActive() then
      M:finishGauntlet()
    end
  end)

  -- Release only after ALL battle bookkeeping and gauntlet progression have
  -- completed. Releasing earlier is what left the re-entrancy window open: an
  -- intro callback or a nearby rival could start the same battle again while
  -- the first was still settling its memory, relationship and career credit.
  --
  -- Guarded on identity so a battle that is NOT the locked one cannot release
  -- somebody else's transaction.
  M:releaseRivalBattleSequence(blackoutRival and blackoutRival.id or nil)
end)

mod.events:on("world.interacted", function(ev)
  if not ev then M.pendingLine = nil return end
  local kind = ev.kind and tostring(ev.kind):lower() or nil
  if kind and kind ~= "npc" then M.pendingLine = nil return end
  if M:gauntletActive() then return end -- opening lab talk owns progression
  local npc = ev.npc or ev.target or ev.object
  local npcId = ev.npcId or ev.id
  if not npcId and npc then
    pcall(function() npcId = npc.id or npc.name or (npc.def and npc.def.name) end)
  end
  local npcName
  pcall(function() npcName = npc and (npc.name or (npc.def and npc.def.name)) end)
  -- 6.2.0: after the Pokemon Tower rescue, the first conversation with Mr. Fuji
  -- in his Lavender house awards the disguise. The Poke Flute proves the
  -- vanilla Fuji sequence is complete, so no quest can appear prematurely.
  if M.rocketDisguise and M.game and M.rocketDisguise:fujiEligible(M.game) then
    local w=M:worldView(); local map=w and tostring(w.playerMap or "") or ""
    local name=string.upper(tostring(npcName or npcId or ""))
    if M.rocketDisguise:isFujiInteraction(M.game,map,name) then
      if M.rocketDisguise:grantFromFuji(M.game) then
        ev.handled,ev.cancelled=true,true
        local rows={{"show_text","MR. FUJI: Team Rocket left this behind. If you wear it, they may mistake you for one of their own."},{"show_text","You received the ROCKET UNIFORM and 5 ROCKET BALLS!"}}
        local ow=M.game.overworld
        if ow and ow.runner and ow.runner.run then pcall(function() ow.runner:run(rows,{npc=npc}) end) elseif ow and ow.queueScript then pcall(function() ow:queueScript(rows) end) end
        return
      end
    end
  end
  local rival = M:rivalAtNpc(npcId) or M:rivalAtNpc(npcName) or M:facedRival()
  if rival then
    ev.handled, ev.cancelled = true, true
    Util.guard("interact:" .. tostring(rival.id), function()
      M:interactWithRival(rival, npc)
    end)
    return
  end
  -- Rangers: talk for heal / challenge / quest.
  if M.rangers then
    local ranger = M.rangers:memberAtNpc(npcId, npcName)
    if ranger then
      ev.handled, ev.cancelled = true, true
      Util.guard("interact:ranger:" .. tostring(ranger.id), function()
        M:interactWithRanger(ranger, npc)
      end)
    end
  end
end)

function M:interactWithRanger(ranger, npc)
  if not (ranger and self.rangers) then return end
  local items = self.rangers:interactItems(ranger)
  local game = self.game
  if not game then return end
  pcall(function()
    local Menu = require("src.ui.Menu")
    local rows = {}
    for _, it in ipairs(items) do
      rows[#rows + 1] = {
        label = it.label,
        right = it.right,
        onSelect = function()
          local ok, line = self.rangers:performAction(ranger, it.value)
          if line then
            self.ticker = {
              text = "RANGER  •  " .. tostring(line),
              age = 0, duration = 6, offset = 0,
            }
          end
        end,
      }
    end
    -- Prefer the same air menu used elsewhere when available.
    if mod.ui and mod.ui.push then
      mod.ui.push(game, "AIR_Status", {})
    end
    -- Queue dialogue + simple action via pending action path.
    self.pendingRangerInteract = { memberId = ranger.id, items = items }
    local line = self.rangers:dialogueFor(ranger, "hello")
    local ow = self.getOverworld and self:getOverworld()
    if ow and ow.runner and type(ow.runner.run) == "function" then
      ow.runner:run({ { "show_text", line } }, {
        onDone = function()
          -- Open a minimal choice through Status/AIR if possible; otherwise
          -- default to heal on A-press follow-up is handled by pending.
          self.pendingRivalAction = {
            kind = "ranger",
            memberId = ranger.id,
            value = "_heal",
          }
        end,
      })
    end
  end)
end

------------------------------------------------------------------------
-- Gen 1 connection safety
------------------------------------------------------------------------

-- 7.3.8: Yellow crash video showed the process exiting on the exact
-- PALLET_TOWN -> ROUTE_1 connection frame, before ROUTE_1 rendered. That means
-- post-enter spawning cannot be the cause. Gen 1 keeps connected-map NPC
-- instances alive across the seam, including runtime objects. Remove every
-- AI-owned physical object immediately BEFORE the engine re-roots the
-- connection. Persistent rival/Rocket/Ranger state is untouched.
local GEN1_CONNECTION_SENTINEL = "__airGen1ConnectionYieldV739"
local GEN2_CONNECTION_SENTINEL = "__airGen2ConnectionYieldV739"

local function yieldPhysicalActorsBeforeConnection()
  -- Persistent simulation state is deliberately untouched. Only the live
  -- runtime representations are removed before the engine re-roots the map.
  pcall(function() M:despawnAll() end)
  pcall(function()
    if M.rocket and M.rocket.despawnAll then M.rocket:despawnAll() end
  end)
  pcall(function()
    if M.rangers and M.rangers.despawnAll then M.rangers:despawnAll() end
  end)

  M.walkMapCache = nil
  M.pendingMapMaterialize = nil
  M.companionTrailHead, M.companionTrailGoal = nil, nil
end

local function installConnectionYield()
  local generation = detectGeneration(M.data)

  if generation == 2 then
    -- Gold's real player path calls World:tryConnection directly. The
    -- OverworldController facade's crossConnection/checkEdgeExit helpers are
    -- for mod compatibility and are not authoritative for engine movement.
    local ok, World2 = pcall(require, "src.world.gen2.World")
    if not ok or type(World2) ~= "table" then return false end
    if World2[GEN2_CONNECTION_SENTINEL] then return true end

    local previous = World2.tryConnection
    if type(previous) ~= "function" then return false end

    World2.tryConnection = function(world, dir, ...)
      -- Only yield when an actual connection exists in the attempted
      -- direction. Ordinary bumps/steps must not despawn the map population.
      local conn
      pcall(function()
        local map = world and world.map
        if map and type(map.connection) == "function" then
          local compass = {
            up = "north", down = "south", left = "west", right = "east",
          }
          conn = map:connection(compass[dir] or dir)
        end
      end)

      if conn then yieldPhysicalActorsBeforeConnection() end
      return previous(world, dir, ...)
    end

    World2[GEN2_CONNECTION_SENTINEL] = true
    return true
  end

  -- Red / Blue / Yellow: the engine crosses connected maps through
  -- OverworldController.crossConnection.
  local ok, OW = pcall(require, "src.world.OverworldController")
  if not ok or type(OW) ~= "table" then return false end
  if OW[GEN1_CONNECTION_SENTINEL] then return true end

  local previous = OW.crossConnection
  if type(previous) ~= "function" then return false end

  OW.crossConnection = function(self, ...)
    yieldPhysicalActorsBeforeConnection()
    return previous(self, ...)
  end

  OW[GEN1_CONNECTION_SENTINEL] = true
  return true
end

------------------------------------------------------------------------
-- Engine seams
------------------------------------------------------------------------

-- Boot order in gen1recomp (src/core/Game.lua):
--   first load:  save.created  →  game.ready
--   title NEW GAME:  game.ready already happened  →  save.created
-- So save.created can fire BOTH before ready (boot skeleton) and after
-- (actual New Game).  We defer the first case and always run the second.

local function startOrSeedRivals()
  if not M.ready then
    M.pendingGauntlet = true
    return
  end
  M.pendingGauntlet = false
  -- Restore first so a finished playthrough is not treated as New Game
  pcall(function() M:load() end)
  if M:gauntletDone() then
    -- Already completed intro: keep restored world positions
    for _, rival in ipairs(M.rivals) do
      if not rival.map or rival.map == "" then
        pcall(function() M:seed(rival) end)
      end
    end
  elseif not M:gauntletActive() then
    if not M:beginGauntlet() then
      for _, rival in ipairs(M.rivals) do M:seed(rival) end
    end
  end
  M:syncGen2Parties()
  M.sprites:resolve(M.data, true)
  local world = M:worldView()
  if world and world.playerMap then
    if M:runtimeObjectsSafe(world.playerMap) then
      Util.guard("spawn:start", function() M:spawnFor(world.playerMap) end)
    else
      M.pendingMapMaterialize = {
        mapId = world.playerMap, age = 0, labRetry = false,
      }
    end
  end
end

mod.events:on("game.ready", function(ev)
  M.game = ev.game
  M.playerOpeningOutdoorSafe = false
  M.playerOpeningOutdoorMap = nil
  M.rivalInteractionOpen = false
  Util.guard("compat:kanto-potion", function()
    if KantoCompat.install(M.compat) then
      mod.log:info("AI Rivals installed Kanto Reforged Potion compatibility")
    end
  end)
  M:build(ev.game.data)
  M:load()
  M:loadPlayerClass()
  Util.guard("blue-champion", function()
    if M.data and not M.data.gen2Trainers then BlueChampion.ensure(M) end
  end)
  Util.guard("static-rivals", function()
    StaticRivals.install(mod, M)
  end)
  -- Re-register trainers/talk/onEnter against the REAL merged data.  The
  -- entry-chunk registration often sees nil boot data and skips maps.
  Util.guard("register:ready", function()
    registerTrainers(ev.game.data)
    registerTalkScripts(ev.game.data)
  end)
  pcall(function() M.sprites:resolve(M.data, true) end)
  if M.pendingGauntlet then
    startOrSeedRivals()
  end
end)

mod.events:on("save.loaded", function()
  if not M.ready then return end
  M:load()
  M:loadPlayerClass()
  pcall(function()
    local party=M.game and M.game.save and M.game.save.party
    local world=M:worldView()
    if type(party)=="table" and #party>0 and world and world.playerMap then
      local maps=M.data and (M.data.gen2Maps or M.data.maps)
      local def=maps and maps[world.playerMap]
      local connected=false
      if def and type(def.connections)=="table" then
        for _,c in pairs(def.connections) do if c then connected=true break end end
      end
      if connected then
        M.playerOpeningOutdoorSafe=true
        M.playerOpeningOutdoorMap=world.playerMap
      end
    end
  end)
  M.sprites:resolve(M.data, true)
  M:despawnAll()
  if M.rocket then pcall(function() M.rocket:despawnAll() end) end
end)

mod.events:on("save.created", function()
  startOrSeedRivals()
end)

-- save.write is a veto hook: capture our state into the bucket BEFORE the
-- engine serializes, then always call next so a normal save proceeds.
mod.hooks:wrap("save.write", function(next, game)
  -- 7.6.2 fail-open save safeguard: AI Rivals state is secondary to the
  -- player's native save. No mod serialization failure may veto saving.
  pcall(function() M:save() end)
  return next(game)
end)

mod.events:on("map.entered", function(ev)
  if not M.ready then return end
  M.walkMapCache = nil
  local mapId = ev and ev.mapId
  -- Prefer the live overworld id when the event is sparse
  if not mapId and mod.world and mod.world.current then
    local ok, cur = pcall(function() return mod.world:current() end)
    if ok and cur then mapId = cur.mapId end
  end
  if not mapId then return end
  M.companionTrailHead, M.companionTrailGoal = nil, nil

  local companion = M.byId[M.companionId]
  if companion and M:gauntletDone() then
    local missing = companion.missingHMForMap
      and companion:missingHMForMap(mapId)
    if missing then
      -- Do not teleport a companion through a field obstacle it cannot clear.
      -- It remains on its previous map and resumes its own HM recovery goal.
      M.companionId = nil
      M.companionYieldMap = nil
      local line = companion.name .. " stayed behind to find a Pokémon for "
        .. Util.spaced(missing) .. "."
      M:addNews(companion, { kind = "news", text = line })
      M:startHmRecovery(companion, missing)
    else
      if companion.useHMsForMap then companion:useHMsForMap(mapId) end
      companion.map, companion.x, companion.y = mapId, nil, nil
      if companion.visitMap then companion:visitMap(mapId) end
      companion.destination, companion.route = nil, nil
      companion.travelReason = "Accompanying the player"
      M.companionYieldMap = nil
    end
  end

  local lab = resolveGauntletLab(M.graph)
  -- Entering the lab: force the gauntlet ONLY if it has never been completed.
  -- Once gauntletFinished is set the sequence is permanently closed.
  if lab and mapId == lab and not M:gauntletDone() then
    Util.guard("gauntlet:enter", function()
      M:beginGauntlet()
      for _, r in ipairs(M.rivals) do
        r.map = mapId
        if #r.party == 0 then
          local species = Rival.firstAvailableStarter(r.def, M.versionKey,
                                                      M.data and M.data.pokemon,
                                                      nil, M:starterOpts(nil, nil, nil, r.personality))
          if species then r:addPokemon(species, 5) end
        end
      end
    end)
  end

  -- 7.3.6: never mutate the runtime object layer from inside map.entered.
  -- Yellow finishes follower/Pikachu setup during the same transition; adding
  -- runtime NPCs re-entrantly here can invalidate the people/object pass just
  -- as Route 1 is being finalised. Defer all AI materialisation to the first
  -- idle overworld frame after the transition.
  M:despawnAll()
  M.connectionYieldActive = false
  M.connectionYieldMap = nil
  if M:mapAllowsRuntimeActors(mapId) then
    M.pendingMapMaterialize = {
      mapId = mapId,
      age = 0,
      labRetry = lab and mapId == lab or false,
    }
  else
    -- Connected routes/towns/cities stay abstract. No runtime object mutation
    -- means the engine's seamless connection/follower machinery owns the map.
    M.pendingMapMaterialize = nil
  end

  -- 7.5.3: Yellow's first lab -> Pallet load with Pikachu remains quarantined
  -- even though the party already exists. Only after that connected outdoor
  -- map has completely entered do future connected-map loads become eligible
  -- for static rival slots. We never rebuild the CURRENT map live.
  if not M.playerOpeningOutdoorSafe then
    local party=M.game and M.game.save and M.game.save.party
    if type(party)=="table" and #party>0 then
      local maps=M.data and (M.data.gen2Maps or M.data.maps)
      local def=maps and maps[mapId]
      local connected=false
      if def and type(def.connections)=="table" then
        for _,c in pairs(def.connections) do
          if c then connected=true break end
        end
      end
      if connected then
        M.playerOpeningOutdoorSafe=true
        M.playerOpeningOutdoorMap=mapId
      end
    end
  end
end)

-- The Choose Your Hero answers arrive here (now from our own intro steps) as
-- the player gives them; this is the authoritative signal for which
-- character-creation walkers are going spare.
mod.events:on("intro.oak_speech.answered", function(ev)
  -- 5.0.6: intro answers can arrive before the manager has finished building
  -- its rivalContext on some Gen1Recomp builds. The old single guarded block
  -- mixed save writes and live roster mutation; a transient save/API failure
  -- therefore surfaced only as the unhelpful "intro.answer" last error and
  -- could abort the rest of the answer handling.
  if not (ev and ev.saveKey) then return end

  if ev.saveKey=="world_weather_enabled"
     or ev.saveKey=="world_weather_intensity"
     or ev.saveKey=="world_weather_quality"
     or ev.saveKey=="world_wx_pokemon_enabled"
     or ev.saveKey=="world_ai_trainers_enabled"
     or ev.saveKey=="world_content_scope"
     or ev.saveKey=="world_abilities_enabled"
     or ev.saveKey=="world_held_items_enabled"
     or ev.saveKey=="world_modern_moves_enabled" then
    pcall(function() mod.save:set(ev.saveKey,ev.value) end)
    pcall(function()
      if type(mod.options.set)=="function" then
        local optionKeys = {
          world_weather_enabled      = "worldWeather",
          world_weather_intensity    = "intensity",
          world_weather_quality      = "quality",
          world_wx_pokemon_enabled   = "weatherVariants",
          world_ai_trainers_enabled  = "worldAI",
          world_content_scope        = "worldContentScope",
          world_abilities_enabled    = "worldAbilities",
          world_held_items_enabled   = "worldHeldItems",
          world_modern_moves_enabled = "worldModernMoves",
        }
        local optionKey = optionKeys[ev.saveKey]
        if optionKey then mod.options:set(optionKey,ev.value) end
      end
    end)
    return
  end

  if ev.saveKey == "ai_rivals_player_class" then
    M:setPlayerClass(tostring(ev.value or "TRAINER"))
    return
  end
  if ev.saveKey == "ai_rivals_count" then
    local raw = tonumber(ev.value)
    local ordinary = RosterPolicy.ordinaryCount(ROSTER)
    local count = RosterPolicy.clamp(raw, ordinary, math.min(4, ordinary))

    -- Saving the preference is best-effort during Oak speech. The live answer
    -- must still be honoured even if this exact frame's save backend is busy.
    pcall(function() mod.save:set("aiRivalCount", count) end)

    if M.ready and M.rivalContext then
      local ok, err = pcall(function() return M:setRivalCount(count) end)
      if not ok then
        -- Retry from core.update after intro state has settled instead of
        -- leaving a sticky "intro.a" error in the diagnostics.
        M.pendingIntroRivalCount = count
        Util.recordError("intro.roster.retry", err)
      else
        M.pendingIntroRivalCount = nil
      end
    else
      M.pendingIntroRivalCount = count
    end
    return
  end

  if ev.saveKey == "ai_rivals_gauntlet" then
    local mode = ev.value == "skip" and "skip" or "play"
    pcall(function() mod.save:set("gauntletMode", mode) end)
    if M.ready then
      if mode == "skip" then
        local ok, err = pcall(function()
          return M:skipGauntlet("chosen at character creation")
        end)
        if not ok then
          M.pendingIntroGauntletMode = mode
          Util.recordError("intro.gauntlet.retry", err)
        else
          M.pendingIntroGauntletMode = nil
        end
      else
        M.pendingIntroGauntletMode = nil
      end
    else
      M.pendingIntroGauntletMode = mode
    end
    return
  end
end)

-- THE TICK.  One accumulator, gated inside Simulation:update, bounded per
-- tick.  next() is always called: a mod that skipped it would pause the game.
-- ------------------------------------------------------------------
-- THE ECOLOGY SEAM (5.2.0)
-- ------------------------------------------------------------------
-- encounter.roll and encounter.species are the only two places the wild
-- population can actually reach the player, and both exist on Gen 1 AND Gen 2
-- with the same names, order and { species, level } shape -- verified in
-- src/world/OverworldController.lua and src/world/gen2/World.lua rather than
-- assumed (§1).
--
-- ROLL scales the encounter RATE by the map's health: a route swept bare has
-- FEWER encounters, not merely different ones. SPECIES re-picks which animal
-- turned up from the live abundance table.
--
-- The ecology never draws from the engine's RNG. §13: adding a draw to a
-- shared stream retroactively changes every existing save's encounter
-- sequence. It carries its own stream, seeded from the world seed.
local ecoRng
local function ecoRoll()
  -- A private LCG. Deliberately not love.math.random and deliberately not
  -- ctx.rng: both are the engine's stream.
  ecoRng = ((ecoRng or (M:worldSeed() % 2147483647)) * 1103515245 + 12345) % 2147483648
  return ecoRng / 2147483648
end

-- The sky and the month the population is living under. Gen 1 has no in-game
-- clock, so the season is device date -- the same source DateTime already
-- uses for the Pokegear clock, not a second opinion.
function M:ecologyEnv(mapId)
  local weather
  pcall(function()
    weather = self.weather and self.weather.currentId and self.weather:currentId()
  end)
  local month
  pcall(function() month = tonumber(os.date("*t").month) end)
  local world
  if mapId and self.worldState and self.worldState.routeEcology then
    world = self.worldState:routeEcology(mapId)
  end
  return {
    weather = weather,
    season = Ecology.seasonFor(month),
    now = self.tick or 0,
    world = world,
  }
end

function M:ecologyFor()
  if not self.ecology then
    self.ecology = Ecology.new({ seed = self:worldSeed(), graph = self.graph, data = self.data })
  end
  self.ecology.ctx = self.ecology.ctx or {}
  self.ecology.ctx.graph, self.ecology.ctx.data = self.graph, self.data
  return self.ecology
end

mod.hooks:wrap("encounter.roll", function(next, encDef, ctx)
  local enc = next(encDef, ctx)
  if not (enc and M.ready and ctx and ctx.mapId) then return enc end
  local ok, result = pcall(function()
    local eco = M:ecologyFor()
    local data = (ctx.data) or (M.data)
    local _, health = eco:abundance(ctx.mapId, data, M:ecologyEnv(ctx.mapId))
    -- Health 1 leaves vanilla exactly alone. Below it, a share of encounters
    -- simply do not happen -- which is what "hunted out" should feel like.
    if health >= 1 then return enc end
    if ecoRoll() > health then return nil end
    return enc
  end)
  if not ok then return enc end
  return result
end)

mod.hooks:wrap("encounter.species", function(next, enc, ctx)
  enc = next(enc, ctx)
  if not (enc and enc.species and M.ready and ctx and ctx.mapId) then return enc end
  local ok, result = pcall(function()
    local eco = M:ecologyFor()
    local data = (ctx.data) or (M.data)
    local env = M:ecologyEnv(ctx.mapId)
    local shares = eco:abundance(ctx.mapId, data, env)
    if not shares then return enc end

    local species = Ecology.pickFrom(shares, ecoRoll()) or enc.species
    eco:observeEnvironment(ctx.mapId, species, env)
    local out = { species = species, level = enc.level }

    -- A THRIVING population throws up unusual individuals. Never a
    -- manufactured species: either a variant id this boot genuinely has, or
    -- an unusually large ordinary one.
    if ecoRoll() < eco:variantChance(ctx.mapId, species, data, env) then
      local localType = eco:ecotype(ctx.mapId, species)
      local salt = tostring(ctx.mapId) .. ":" .. tostring(localType and localType.driver or "wild")
      local variant = Ecology.variantSpecies(species, data, eco.seed, salt)
      if variant then
        out.species = variant
      elseif out.level then
        out.level = out.level + Ecology.VARIANT_LEVEL_BONUS + (localType and 1 or 0)
      end
    end

    -- TRAINER HUNTING PRESSURE. The player meeting an animal is itself a
    -- disturbance, and it is the one signal available on BOTH generations --
    -- battle.catch_exp has no Gen 2 adapter, and a door that silently closes
    -- on Gold is exactly §8.
    eco:record(ctx.mapId,out.species,"encounter",env.now)
    out=TrainerClasses.modifyEncounter(M.playerClassId,data,out,ctx)
    return out
  end)
  if not ok then return enc end
  return result or enc
end)

mod.hooks:wrap("core.update", function(next, game, dt)
  local result = next(game, dt)
  -- Never touch rival logic during Oak speech / naming / title.
  if not M.ready then return result end

  -- 5.0.6: finish any character-creation choice that arrived one frame before
  -- manager initialization. This deliberately happens only after M.ready.
  if M.pendingIntroRivalCount and M.rivalContext then
    local pendingCount = M.pendingIntroRivalCount
    local ok = pcall(function() M:setRivalCount(pendingCount) end)
    if ok then
      M.pendingIntroRivalCount = nil
      pcall(function() mod.save:set("aiRivalCount", pendingCount) end)
    end
  end
  if M.pendingIntroGauntletMode then
    local pendingMode = M.pendingIntroGauntletMode
    if pendingMode == "skip" then
      local ok = pcall(function()
        M:skipGauntlet("chosen at character creation")
      end)
      if ok then M.pendingIntroGauntletMode = nil end
    else
      M.pendingIntroGauntletMode = nil
    end
  end
  if M.pendingIntroCustomNames and M.nameAssignments then
    local custom = M.pendingIntroCustomNames
    if type(custom) == "table" then
      for id, name in pairs(custom) do
        if type(id) == "string" and type(name) == "string" and name ~= "" then
          M.nameAssignments[id] = name
          local rival = M.byId and M.byId[id]
          if rival then rival.name = name end
        end
      end
      pcall(function() mod.save:set("ai_rival_custom_names", custom) end)
      pcall(function() M:syncTrainerNames() end)
    end
    M.pendingIntroCustomNames = nil
  end

  -- Whole-body timer for the FRAME row (PERFORMANCE screen). SIM/WALK below
  -- only see their own regions; this is the one number that sees F1/F2/F4-F7
  -- from docs/performance.md too. Every branch below funnels back to the
  -- unconditional `return result` after the pcall (an early `return result`
  -- inside just ends the pcall'd closure -- pcall still returns normally and
  -- execution reaches the same place), so one measurement here covers them
  -- all without instrumenting each branch.
  local frameStarted = performanceClockMs()
  local ok, err = pcall(function()
  if M.perf and (M.perf.autoLowSeconds or 0) > 0 then
    M.perf.autoLowSeconds = math.max(0,
      M.perf.autoLowSeconds - (tonumber(dt) or 0))
  end
  local world = M:worldView()
  local playerMap = world and world.playerMap

  -- 7.5.2: record when the opening player setup has genuinely completed.
  -- Static outdoor rival slots use the real party as their gate; never rebuild
  -- the current map in-place when this flips.
  if not M.playerOpeningReady then
    local party=M.game and M.game.save and M.game.save.party
    if type(party)=="table" and #party>0 then
      M.playerOpeningReady=true
    end
  end

  -- 7.4.0: yield physical AI actors before ANY connected-map seam. This runs
  -- before simulation, walking, Rocket/Ranger refresh or materialisation.
  if playerMap then
    pcall(function() M:updateConnectionYield(world) end)
  end
  -- A simulation tick can include route planning, PC management and a full
  -- headless battle. Running that synchronously every 1.5 seconds produced a
  -- regular hitch after roughly four player steps. Detect tile motion and let
  -- simulation time advance only after the player has naturally paused.
  RuntimePolicy.trackPlayerMotion(M, world, dt)
  if M.ticker and M.ticker.text then
    M.ticker.age = (M.ticker.age or 0) + (tonumber(dt) or 0)
    M.ticker.offset = (M.ticker.offset or 0) + 32 * (tonumber(dt) or 0)
    if M.ticker.age >= (M.ticker.duration or 8) then
      local nextHeadline = M.tickerQueue and table.remove(M.tickerQueue, 1)
      if nextHeadline then
        M.ticker = { text = nextHeadline, age = 0, duration = 8, offset = 0 }
      else
        M.ticker.text = nil
      end
    end
  end
  -- No overworld yet (naming / intro, etc.)
  if not playerMap then return end

  -- Dialogue-complete manual challenges own this frame. Launching before
  -- background simulation prevents the rival from walking away or changing
  -- state between accepting the fight and BattleState construction.
  if M:updatePendingRivalBattle(dt) then return result end

  if M.pendingPhoneOffer and M:overworldIdle() then
    mod.ui.push(game, "AIR_RivalGearOffer", { contact = M.pendingPhoneOffer })
    M.pendingPhoneOffer = nil
    return result
  end

  if M.pendingPhoneTrainer and M.pendingPhoneTrainer.ready and M:overworldIdle() then
    local contact = M.pendingPhoneTrainer
    M.pendingPhoneTrainer.ready = false
    local ok, err = M:pushPhoneTrainerBattle(contact)
    if not ok then
      M.pendingPhoneTrainer = nil
      M.ticker = { text = "NOTICE  • " .. tostring(err),
        age = 0, duration = 8, offset = 0 }
    end
    return result
  end

  if M.pendingRocketBattleLaunch then
    local pending = M.pendingRocketBattleLaunch
    pending.age = (tonumber(pending.age) or 0) + (tonumber(dt) or 0)
    if M:overworldIdle() or (pending.age >= 0.25 and M:overworldRunnerIdle()) then
      local member = M.rocket and M.rocket:memberById(pending.memberId)
      local class = member and M.rocket:classForMember(member)
      M.pendingRocketBattleLaunch = nil
      if class then
        local ow = M:getOverworld()
        local launched = false
        pcall(function()
          if ow and type(ow.queueScript) == "function" then
            launched = ow:queueScript({{ "start_battle", "trainer", class, 1 }}) ~= false
          elseif ow and ow.runner and type(ow.runner.run) == "function" then
            launched = ow.runner:run({{ "start_battle", "trainer", class, 1 }}, {}) ~= false
          end
        end)
        if not launched then
          M.rivalBattleSequenceActive=false
          M.pendingRocket=nil
        end
      else
        M.rivalBattleSequenceActive=false
        M.pendingRocket=nil
      end
    end
    return result
  end

  -- Close the menu before changing overworld state. This keeps all choices
  -- responsive on desktop and touch builds and prevents actions targeting the
  -- menu screen instead of the active map.
  if M.pendingRivalAction then
    local action = M.pendingRivalAction
    action.age = (tonumber(action.age) or 0) + (tonumber(dt) or 0)
    local strict = M:overworldIdle()
    local fallback = M:overworldRunnerIdle() and (
      (action.value ~= "_challenge" and action.age >= 0.08)
      or action.age >= 0.35)
    if strict or fallback then
      M.pendingRivalAction = nil
      local rival = M.byId[action.rivalId]
      local called, ok, line = pcall(M.performRivalAction, M, rival, action.value)
      if not called then
        ok, line = false, "Rival action failed: " .. tostring(ok)
        Util.lastError = tostring(line)
      end
      M.ticker = { text = (ok and "RIVAL LINK  •  " or "NOTICE  •  ")
        .. tostring(line or "Nothing happened."), age = 0, duration = 8, offset = 0 }
    end
    return result
  end

  -- 7.3.6: physical NPC rebuilds requested by map.entered happen only after
  -- the new overworld has reached an idle frame. This is especially important
  -- on Yellow, where follower setup is still touching the object layer during
  -- the map-entered event itself.
  if M.pendingMapMaterialize and not M.connectionYieldActive then
    local pending = M.pendingMapMaterialize
    pending.age = (tonumber(pending.age) or 0) + (tonumber(dt) or 0)
    local current = M:worldView()
    local currentMap = current and current.playerMap
    if currentMap and currentMap ~= pending.mapId then
      -- Another transition won the race. Drop the stale request; the newer
      -- map.entered event owns materialisation.
      M.pendingMapMaterialize = nil
    elseif currentMap == pending.mapId
       and (M:overworldIdle()
         or (pending.age >= 0.20 and M:overworldRunnerIdle())) then
      M.pendingMapMaterialize = nil
      local n = 0
      local okSpawn, result = pcall(function() return M:spawnFor(pending.mapId) end)
      if okSpawn then n = result or 0
      else Util.lastError = "spawn:" .. tostring(result) end

      if M:runtimeObjectsSafe(pending.mapId) then
        if M.rocket then
          pcall(function() M.rocket:spawnFor(pending.mapId, M:worldView()) end)
        end
        if M.rangers then
          pcall(function() M.rangers:spawnFor(pending.mapId, M:worldView()) end)
        end
      end

      if pending.labRetry and n == 0 then
        for _, r in ipairs(M.rivals) do
          if r.map == pending.mapId then M.spawned[r.id] = nil end
        end
        pcall(function() M:spawnFor(pending.mapId) end)
      end
    end
    -- Do not run simulation on the exact frame we rebuild the map object layer.
    return result
  end

  -- Defer the menu push until an idle overworld frame. Always return while it
  -- is pending so background simulation cannot race the UI handoff.
  if M.pendingRivalMenu then
    local pending = M.pendingRivalMenu
    if type(pending) ~= "table" then pending = { rivalId = pending, age = 0 } end
    pending.age = (tonumber(pending.age) or 0) + (tonumber(dt) or 0)
    M.pendingRivalMenu = pending
    if M:overworldIdle() or (pending.age >= 0.25 and M:overworldRunnerIdle()) then
      local rival = M.byId[pending.rivalId]
      M.pendingRivalMenu = nil
      M.rivalInteractionOpen = false
      if rival then
        local opened, err = pcall(function() return M:openRivalMenu(rival) end)
        if not opened then Util.lastError = "rival menu: " .. tostring(err) end
      end
    end
    return result
  end

  -- Intro lock: until the lab gauntlet is finished, keep everyone in the lab
  -- and pause world simulation so they cannot wander to Pewter/Viridian.
  -- Safety: if gauntlet is finished but anyone is still marked in the lab,
  -- push them out once so the world sim can take over.
  if M:gauntletDone() then
    local stuck = false
    for _, r in ipairs(M.rivals) do
      if r.map == gauntletLabId() then stuck = true break end
    end
    if stuck then
      pcall(function() M:finishGauntlet() end)
      -- finish is no-op if already finished; force scatter
      for i, r in ipairs(M.rivals) do
        if r.map == gauntletLabId() then
          -- 2.10.0: same reasoning as postLabStarts -- a Gold rescue must not
          -- drop a stuck rival into Kanto.
          local starts = postLabStarts()
          local start = (starts[i] and starts[i].map)
            or (starts[1] and starts[1].map) or "ROUTE_1"
          r.map = start
          r.x, r.y = nil, nil
          r.destination = "PEWTER_CITY"
          pcall(function() r:setState("TRAVELLING", "forced leave") end)
          pcall(function() AI.evaluate(r, M:worldView()) end)
        end
      end
      pcall(function() M:despawnAll() end)
    end
  end

  -- Normal/non-skip migration brake. SKIP no longer sets this flag: choosing
  -- SKIP deliberately releases the rival simulation before the player starter.
  -- Keep this block for old/incomplete normal-intro states only.
  if M.worldStartPending then
    local party = M.game and M.game.save and M.game.save.party
    local hasStarter = type(party) == "table" and #party > 0
    if hasStarter and M:blueLabBattled() then
      M.worldStartPending = false
      pcall(function() M:save() end)
    else
      return result
    end
  end

  if not M:gauntletDone() then
    if playerMap == gauntletLabId() then
      for _, r in ipairs(M.rivals) do
        r.map = playerMap
        r.destination = nil
        r.route = nil
      end
      if not M:gauntletDone() and (not M.gauntlet or not M.gauntlet.active) then
        local ok, err = pcall(function() return M:beginGauntlet() end)
        if not ok then
          Util.lastError = "beginGauntlet: " .. tostring(err)
        end
        -- Do NOT invent an active gauntlet that clears gauntletFinished
      end
      local need = false
      for _, r in ipairs(M.rivals) do
        if not M.spawned[r.id] then need = true break end
      end
      if need then
        pcall(function() M:despawnAll() end)
        local ok, err = pcall(function() return M:spawnFor(playerMap) end)
        if not ok then
          Util.lastError = "spawn: " .. tostring(err)
        end
      end
      -- Auto walk-up + challenge in roster order, but never spend an A* search
      -- in the same frame as player movement.
      if not (world and world.playerMoving) then
        pcall(function() M:gauntletDirector(dt) end)
      end
    end
    return result
  end

  -- Simulation time belongs to the world, not to the player's feet. Visible
  -- rivals are already protected by ctx.near inside Simulation.tickRival, so
  -- keep off-screen rivals moving/healing while the player walks.
  if M.sim then
    Util.guard("tick", function()
      -- Options may be changed from the Mods menu during an existing save;
      -- apply the selected profile without requiring a restart.
      local performance = mod.options:get("performance") or "balanced"
      RuntimePolicy.configure(M.sim, performance,
        PACE[mod.options:get("pace")] or PACE.normal)
      if M.rivalContext then
        M.rivalContext.relationships = M:relationshipsEnabled()
      end
      local ran = false
      local alreadyHere = {}
      if playerMap then
        for _, rival in ipairs(M.rivals) do
          if rival.map == playerMap then alreadyHere[rival.id] = true end
        end
      end
      local perfStarted = performanceClockMs()
      local ok, err = pcall(function()
        ran = M.sim:update(dt, M.rivals, world)
      end)
      M:recordPerformance("simulation", perfStarted)
      if not ok then
        Util.lastError = "tick:" .. tostring(err):gsub("%s+", " "):sub(1, 80)
      end
      if ran and M.tournaments then
        pcall(function() M.tournaments:maybeAutonomous(M.sim and M.sim.tick or 0) end)
      end
      if ran and playerMap then
        -- Training, evolution and headless battles alter only rival data. Do
        -- not re-run runtime-NPC materialisation after every world tick: on
        -- some engine builds rebuilding the live object layer invokes the
        -- screen transition/fade. Materialise only a rival that genuinely
        -- crossed onto the player's map during this tick.
        local arrived = false
        for _, rival in ipairs(M.rivals) do
          if rival.map == playerMap and not alreadyHere[rival.id]
             and not M.spawned[rival.id] then arrived = true break end
        end
        if arrived and M:runtimeObjectsSafe(playerMap) then
          pcall(function() M:spawnFor(playerMap) end)
        end
      end
    end)
  end

  if worldAIEnabled() and M.rocket and not (world and world.playerMoving) then
    Util.guard("rocket", function() M.rocket:update(dt, world) end)
    if M.rangers then
      Util.guard("rangers", function() M.rangers:update(dt, world) end)
      if world and world.playerMap and M:runtimeObjectsSafe(world.playerMap) then
        pcall(function() M.rangers:spawnFor(world.playerMap, world) end)
      end
      if M.rivalWars then Util.guard("rival wars", function() M.rivalWars:update(dt, world) end) end
    end
    pcall(function() M:updateScheduledTournaments() end)
  end
  if worldAIEnabled() and M.rocket and world and world.playerMap
     and M:runtimeObjectsSafe(world.playerMap) then
    pcall(function() M.rocket:spawnFor(world.playerMap, world) end)
  end
  if M.quests and world and world.playerMap then
    Util.guard("quests", function()
      M.quests:observe(world)
      M.quests:refresh(false)
    end)
  end
  if M.worldState and world then
    Util.guard("world-state", function() M.worldState:observe(world) end)
  end

  -- 4.5.0: the same door every other overworld effect goes through. A
  -- tournament is arranged from inside the Pokegear, so without this gate the
  -- first match could construct itself while four menus were still stacked
  -- over the map -- dialogue running under a list the player is still reading.
  if M.tournaments and not (world and world.playerMoving) and M:overworldIdle() then
    pcall(function() M.tournaments:updatePending() end)
  end

  -- 1.36.0 §13: what the player noticed this tick. Read-only with respect to
  -- every rival, and rate-limited inside Presence, so it costs a handful of
  -- comparisons per tick and cannot spam the news channel.
  if playerMap and not (world and world.playerMoving) then
    Util.guard("presence", function() M:observePresence(playerMap, world) end)
  end

  if M.phone then
    Util.guard("phone", function() M.phone:update(dt, M.rivals, world) end)
  end
  Util.guard("trainer phone", function() M:updateTrainerPhoneCalls() end)

  -- 2.1.0: a life-path decision is checked rarely and only for the rival whose
  -- turn it is, because at most two rivals in a save can ever take one and the
  -- pressure that drives it moves over hours, not ticks. One rival per sweep
  -- keeps this off the per-tick budget entirely (§34).
  if M.sim and M.lifePathsEnabled and M:lifePathsEnabled()
     and (M.sim.tick or 0) % 240 == 0 and #M.rivals > 0 then
    Util.guard("lifepath", function()
      local index = ((M.sim.tick / 240) % #M.rivals) + 1
      local rival = M.rivals[math.floor(index)]
      -- A rival still on the Gym Challenge may diverge; one already living
      -- another life may move ALONG its arc. Never both in the same sweep.
      if rival and rival.onGymChallenge and rival:onGymChallenge() then
        M:considerLifePath(rival)
      else
        M:considerTransition(rival)
      end
    end)
  end

  -- Autonomous presentation stays idle during player motion; the companion's
  -- lightweight entity trail is allowed to advance alongside the player.
  local walkingStarted = performanceClockMs()
  pcall(function() M:worldWalkDirector(dt, world) end)
  M:recordPerformance("walking", walkingStarted)

  -- Rivals already spawn passable/through (see the objDef in spawnFor), but
  -- a rival occasionally still ends up somewhere the player cannot get past
  -- it -- a doorway, a one-tile corridor. Rather than depend on understanding
  -- exactly which case that is, relieve it directly: standing still, pressed
  -- against a spawned rival, for a few real seconds nudges that ONE rival to
  -- a free neighbouring tile instead of leaving the player stuck.
  pcall(function() M:relievePathBlock(world) end)

  -- World duels: sometimes a nearby rival walks up and challenges you.
  local playerPartyForChallenge = M.game and M.game.save and M.game.save.party
  local playerHasBattleMon = type(playerPartyForChallenge) == "table"
    and #playerPartyForChallenge > 0
  if playerHasBattleMon and mod.options:get("encounters") and playerMap and world
     and not M:gauntletActive() and not M.worldChallenge then
    Util.guard("worldDuel", function()
      local px, py = world.playerX, world.playerY
      if not px then return end
      for _, rival in ipairs(M.rivals) do
        if rival.map == playerMap and rival.x and rival.y
           and #rival.party > 0 then
          local dist = math.abs(rival.x - px) + math.abs(rival.y - py)
          if dist <= 2 and AI.wantsToChallenge(rival, world) then
            local accepted = M:startRivalChallenge(rival)
            if accepted then
              M.worldChallenge = true
              rival.stateReason = "world duel"
              break
            end
          end
        end
      end
    end)
  end
  end) -- pcall core.update body
  if not ok then
    Util.lastError = "tick: " .. tostring(err)
  end
  -- Deliberately not M:recordPerformance -- that function feeds slowStrikes /
  -- autoLowSeconds, and adding a measurement must not change when the mod
  -- decides it is struggling. Same average/maximum math, no side effects.
  local frameFinished = performanceClockMs()
  if frameStarted and frameFinished and M.perf and M.perf.frame then
    local row = M.perf.frame
    local elapsed = math.max(0, frameFinished - frameStarted)
    row.samples = (row.samples or 0) + 1
    row.average = row.samples == 1 and elapsed
      or (row.average * 0.9 + elapsed * 0.1)
    row.maximum = math.max(row.maximum or 0, elapsed)
  end
  return result
end)

-- Screen-space world-news ticker. render.hud runs after the completed game
-- frame, so the headline remains readable without pausing or opening a menu.
mod.hooks:wrap("render.hud", function(next, game, viewport)
  local result = next(game, viewport)
  if mod.options:get("news_ticker") == false then return result end
  local ticker = M.ticker
  local top = game and game.stack and game.stack.top and game.stack:top()
  if not (ticker and ticker.text and top and top.isOverworld
          and love and love.graphics) then return result end
  local g = love.graphics
  local ww = g.getWidth and g.getWidth() or 160
  local font = g.getFont and g.getFont()
  local fh = font and font:getHeight() or 8
  local h = math.max(18, fh + 8)
  local alpha = 0.88
  local left = math.max(0, (ticker.duration or 8) - (ticker.age or 0))
  if left < 1 then alpha = alpha * left end
  -- love.graphics state is global.  push()/pop() without the "all" argument
  -- preserves only the transform on older LÖVE builds, so the ticker's fading
  -- alpha used to leak into the next game frame and fade the entire screen.
  -- Save and restore every state value changed here explicitly for compatibility
  -- with both the original engine and newer runtimes.
  local oldR, oldG, oldB, oldA = g.getColor()
  local oldSX, oldSY, oldSW, oldSH = g.getScissor()
  g.push()
  g.setColor(0.02, 0.04, 0.08, alpha)
  g.rectangle("fill", 0, 0, ww, h)
  g.setColor(0.25, 0.75, 1.0, alpha)
  g.rectangle("fill", 0, h - 2, ww, 2)
  g.setScissor(5, 0, math.max(1, ww - 10), h)
  local textW = font and font:getWidth(ticker.text) or #ticker.text * 6
  local x = 8
  if textW > ww - 16 then
    local cycle = textW + ww
    x = ww - ((ticker.offset or 0) % cycle)
  end
  g.setColor(1, 1, 1, alpha)
  g.print(ticker.text, math.floor(x), math.floor((h - fh) / 2))
  g.pop()
  if oldSX ~= nil then
    g.setScissor(oldSX, oldSY, oldSW, oldSH)
  else
    g.setScissor()
  end
  g.setColor(oldR, oldG, oldB, oldA)
  return result
end)

------------------------------------------------------------------------
-- Status screens and debug verbs
------------------------------------------------------------------------
-- Both were extracted in 4.6.1: ~760 lines of presentation and console verbs
-- that only ever read the manager through its public methods. They install
-- HERE, not at the bottom of the file, because hook registration order is
-- observable -- Status installs a `ui.start_menu.items` wrap that must still
-- run before the one Pokegear installs from installIntro() below.

Status.install(mod, M, SCREEN)
Commands.install(mod, M)
------------------------------------------------------------------------
-- Manager subsystem context
------------------------------------------------------------------------
-- Extracted manager modules receive the live manager and this narrow context
-- table for the former module-scope helpers/constants. There is no duplicate
-- world state here.
M._ctx = {
  GAUNTLET_LAB_CANDIDATES = GAUNTLET_LAB_CANDIDATES,
  GAUNTLET_DETECT = GAUNTLET_DETECT,
  GAUNTLET_ENGAGE = GAUNTLET_ENGAGE,
  GAUNTLET_STEP_S = GAUNTLET_STEP_S,
  POST_LAB_STARTS_BY_KEY = POST_LAB_STARTS_BY_KEY,
  LAB_SLOTS = LAB_SLOTS,
  RIVAL_SPRITE_PREFER = RIVAL_SPRITE_PREFER,
  FACING_TO_RANGE = FACING_TO_RANGE,
  PATH_BLOCK_STALL_S = PATH_BLOCK_STALL_S,
  SPAWN_FACINGS = SPAWN_FACINGS,
  SAVE_VERSION = SAVE_VERSION,
  TALK_TEXT = TALK_TEXT,
  ROCKET_TALK_TEXT = ROCKET_TALK_TEXT,
  ROSTER = ROSTER,
  mapExists = mapExists,
  resolveGauntletLab = resolveGauntletLab,
  gauntletLabId = gauntletLabId,
  postLabStarts = postLabStarts,
  runningOnIOS = runningOnIOS,
  homeMapsFor = homeMapsFor,
  activeRoster = activeRoster,
}

local GauntletManager = req("src/manager/Gauntlet")
local MaterializeManager = req("src/manager/Materialize")
local PersistenceManager = req("src/manager/Persistence")
local CommsManager = req("src/manager/Comms")
GauntletManager.install(mod, M)
MaterializeManager.install(mod, M)
PersistenceManager.install(mod, M)
CommsManager.install(mod, M)


------------------------------------------------------------------------
-- Load-time work
------------------------------------------------------------------------
-- Order matters: capture the vanilla walkers BEFORE the Choose Your Hero
-- intro swap rewrites SPRITE_RED/SPRITE_BLUE at game.ready, or the art the
-- rivals borrow would be whatever the player picked rather than what they
-- did not.

-- Trainers/talk/sprites registered on game.ready only (avoids New Game crashes)
--
-- NO INFORMATION MUST MEAN ZERO, NOT A DEFAULT.  At the entry chunk `mod.game`
-- is frequently not up yet, so `bootData` is nil -- and `detectGeneration(nil)`
-- answers 1, because its question is "does this dataset look like Gold" and an
-- absent dataset does not.  Registering on that answer put Gen 1 map_scripts
-- onto a Gold boot, which the loader reports as "the map_scripts registry has
-- no Gen 2 target" in the mod manager's error feed on every single launch.
--
-- An unknown generation is not Gen 1; it is unknown.  Skip, and let game.ready
-- register against the REAL merged data, which it already does unconditionally
-- a few lines further down.  Nothing is lost by waiting: the comment above has
-- always said game.ready is the authoritative registration.
local bootData = mod.game and mod.game.data
local bootKnown = bootData ~= nil
  and (bootData.maps ~= nil or bootData.gen2Maps ~= nil
       or bootData.gen2Trainers ~= nil)
if bootKnown then
  pcall(function() registerTrainers(bootData) end)
  pcall(function() registerTalkScripts(bootData) end)
else
  mod.log:info("boot data not up yet; trainers/talk register at game.ready")
end

-- Character selection is intentionally not installed. The vanilla rival naming
-- screen remains, and sprite selection is derived from the chosen rival name.
local compat = Compat.new(mod)
M.compat = compat
pcall(function() WonderTrade.install(mod, M) end)
pcall(function() WeatherResearch.install(mod, M) end)




------------------------------------------------------------------------
-- Intro additions. Character/gender/sprite selection is intentionally absent.
-- Steps are inserted AFTER the vanilla rival (Blue/Gary) is named so the
-- speech asks one question, waits for the answer, then continues in order.
-- After count + gauntlet, the player may name each AI rival in turn, or
-- randomise one / all remaining.
------------------------------------------------------------------------
do
  local function installIntro()
    if not (mod.hooks and mod.hooks.wrap) then
      print("[ai_rivals] no mod.hooks.wrap")
      return
    end
    if not (mod.ui and mod.ui.insertStepBefore and mod.ui.insertStepAfter) then
      print("[ai_rivals] no mod.ui step helpers")
      return
    end
    mod.hooks:wrap("intro.oak_speech.build", function(next, steps, speech)
      steps = next(steps, speech)
      if type(steps) ~= "table" then return steps end

      -- Anchor after the vanilla rival is fully named and confirmed so the
      -- AI questions never interleave with player/rival naming.
      local anchor = "confirm_rival_name"
      local function hasStep(id)
        for _, s in ipairs(steps) do
          if s.id == id then return true end
        end
        return false
      end
      if not hasStep(anchor) then
        if hasStep("name_rival") then anchor = "name_rival"
        elseif hasStep("ask_rival_name") then anchor = "ask_rival_name"
        else anchor = "ask_player_name"
        end
      end

      mod.ui.insertStepAfter(steps,anchor,{
        id="choose_player_trainer_class",
        kind="fn",
        run=function(speechObj,done)
          local Menu=require("src.ui.Menu")
          local selectedIndex=1

          -- Restore the cursor to a previously previewed class when NO sends
          -- the player back from the confirmation screen.
          local function openClassMenu(cursorIndex)
            selectedIndex=math.max(1,math.min(#TrainerClasses.ORDER,
              tonumber(cursorIndex) or selectedIndex or 1))

            local items={}
            for i,classId in ipairs(TrainerClasses.ORDER) do
              local rowIndex=i
              local rowId=classId
              items[#items+1]={
                label=TrainerClasses.label(rowId),
                onSelect=function()
                  selectedIndex=rowIndex

                  -- Selection is only a PREVIEW. Nothing is written to the
                  -- save until YES is chosen on this screen.
                  local detail=TrainerClasses.confirmationText(rowId)
                  speechObj:sayText(detail,nil,{
                    defaultNo=true,
                    choice=function(yes)
                      if yes then
                        local step={
                          id="choose_player_trainer_class",
                          saveKey="ai_rivals_player_class",
                        }
                        speechObj:recordAnswer(step,rowIndex,
                          TrainerClasses.label(rowId),rowId)
                        done()
                      else
                        -- NO loops back to the same scrollable list and keeps
                        -- the previously selected class under the cursor.
                        openClassMenu(selectedIndex)
                      end
                    end,
                  })
                end,
              }
            end

            local menu=Menu.new(speechObj.game,items,{
              cancelable=false,
              tx=1,ty=0,tw=18,
              maxVisible=6,
            })
            menu.index=selectedIndex
            if menu.clampScroll then menu:clampScroll() end
            speechObj.game.stack:push(menu)
          end

          speechObj:sayText("WHAT KIND OF TRAINER ARE YOU?",function()
            openClassMenu(selectedIndex)
          end)
        end,
      })
      anchor="choose_player_trainer_class"

      mod.ui.insertStepAfter(steps,anchor,{
        id="choose_world_ai_trainers",kind="choice",
        text="USE AI TRAINERS?",
        saveKey="world_ai_trainers_enabled",
        choices={"AI TRAINERS","NO AI TRAINERS"},
        values={"on","off"},
        tx=2,ty=3,tw=16,
      })
      anchor="choose_world_ai_trainers"

      -- 7.6.3: use the same scrollable Menu widget as Trainer Classes.
      -- RosterPolicy still defines the legal ordinary-rival choices; the UI
      -- merely presents them in a compact six-row scrolling window.
      local choices, values = RosterPolicy.creationChoices(
        RosterPolicy.ordinaryCount(ROSTER))
      if #choices > 1 then
        mod.ui.insertStepAfter(steps,anchor,{
          id="choose_ai_rivals_count",
          kind="fn",
          run=function(speechObj,done)
            if speechObj.answers and speechObj.answers["world_ai_trainers_enabled"]=="off" then
              speechObj:recordAnswer({id="choose_ai_rivals_count",saveKey="ai_rivals_count"},1,"ZERO","0")
              done()
              return
            end
            local Menu=require("src.ui.Menu")
            local selectedIndex=1

            local function openRivalCountMenu(cursorIndex)
              selectedIndex=math.max(1,math.min(#values,
                tonumber(cursorIndex) or selectedIndex or 1))

              local items={}
              for i,value in ipairs(values) do
                local rowIndex=i
                local rowValue=value
                items[#items+1]={
                  label=tostring(choices[i]),
                  onSelect=function()
                    selectedIndex=rowIndex
                    local step={
                      id="choose_ai_rivals_count",
                      saveKey="ai_rivals_count",
                    }
                    speechObj:recordAnswer(step,rowIndex,
                      tostring(choices[rowIndex]),rowValue)
                    done()
                  end,
                }
              end

              local menu=Menu.new(speechObj.game,items,{
                cancelable=false,
                tx=2,ty=1,tw=16,
                maxVisible=6,
              })
              menu.index=selectedIndex
              if menu.clampScroll then menu:clampScroll() end
              speechObj.game.stack:push(menu)
            end

            speechObj:sayText("HOW MANY AI RIVALS?",function()
              openRivalCountMenu(selectedIndex)
            end)
          end,
        })
        anchor="choose_ai_rivals_count"
      end

      mod.ui.insertStepAfter(steps,anchor,{
        id="choose_world_weather",kind="choice",
        text="USE DYNAMIC WEATHER?",
        saveKey="world_weather_enabled",
        choices={"WEATHER","NO WEATHER"},values={"on","off"},
        tx=3,ty=4,tw=14,
      })
      anchor="choose_world_weather"

      mod.ui.insertStepAfter(steps,anchor,{
        id="choose_world_wx_pokemon",kind="choice",
        text="ALLOW WX POKEMON?",
        saveKey="world_wx_pokemon_enabled",
        choices={"WX POKEMON","NO WX POKEMON"},
        values={"on","off"},
        tx=2,ty=3,tw=16,
      })
      anchor="choose_world_wx_pokemon"

      mod.ui.insertStepAfter(steps,anchor,{
        id="choose_world_content_scope",kind="choice",
        text="WHICH POKEMON GENERATIONS?",
        saveKey="world_content_scope",
        choices={"GEN 1","GEN 1 + GEN 2","GEN 1 + GEN 2 + GEN 3"},
        values={"gen1","gen1_gen2","gen1_gen2_gen3"},
        tx=1,ty=2,tw=18,
      })
      anchor="choose_world_content_scope"

      mod.ui.insertStepAfter(steps,anchor,{
        id="choose_world_abilities",kind="choice",
        text="USE POKEMON ABILITIES?",
        saveKey="world_abilities_enabled",
        choices={"ABILITIES ON","ABILITIES OFF"},
        values={"on","off"},
        tx=2,ty=3,tw=16,
      })
      anchor="choose_world_abilities"

      mod.ui.insertStepAfter(steps,anchor,{
        id="choose_world_held_items",kind="choice",
        text="USE HELD ITEMS?",
        saveKey="world_held_items_enabled",
        choices={"HELD ITEMS ON","HELD ITEMS OFF"},
        values={"on","off"},
        tx=2,ty=3,tw=16,
      })
      anchor="choose_world_held_items"

      mod.ui.insertStepAfter(steps,anchor,{
        id="choose_world_modern_moves",kind="choice",
        text="USE GEN 2 AND 3 MOVES?",
        saveKey="world_modern_moves_enabled",
        choices={"MOVES ON","MOVES OFF"},
        values={"on","off"},
        tx=2,ty=3,tw=16,
      })
      anchor="choose_world_modern_moves"

      mod.ui.insertStepAfter(steps,anchor,{
        id="choose_world_weather_intensity",kind="fn",
        run=function(speechObj,done)
          if speechObj.answers and speechObj.answers["world_weather_enabled"]=="off" then
            pcall(function() mod.save:set("world_weather_intensity","normal") end)
            done(); return
          end
          local Menu=require("src.ui.Menu")
          local labels={"SOFT","NORMAL","HEAVY","AUTO"}
          local values={"soft","normal","heavy","auto"}
          local items={}
          for i,v in ipairs(values) do
            local ri,rv=i,v
            items[#items+1]={label=labels[i],onSelect=function()
              speechObj:recordAnswer({id="choose_world_weather_intensity",
                saveKey="world_weather_intensity"},ri,labels[ri],rv)
              done()
            end}
          end
          speechObj:sayText("WEATHER INTENSITY?",function()
            speechObj.game.stack:push(Menu.new(speechObj.game,items,{
              cancelable=false,tx=3,ty=3,tw=14,maxVisible=4}))
          end)
        end,
      })
      anchor="choose_world_weather_intensity"

      mod.ui.insertStepAfter(steps,anchor,{
        id="choose_world_weather_quality",kind="fn",
        run=function(speechObj,done)
          if speechObj.answers and speechObj.answers["world_weather_enabled"]=="off" then
            pcall(function() mod.save:set("world_weather_quality","auto") end)
            done(); return
          end
          local Menu=require("src.ui.Menu")
          local labels={"AUTO","HIGH","MEDIUM","LOW"}
          local values={"auto","high","medium","low"}
          local items={}
          for i,v in ipairs(values) do
            local ri,rv=i,v
            items[#items+1]={label=labels[i],onSelect=function()
              speechObj:recordAnswer({id="choose_world_weather_quality",
                saveKey="world_weather_quality"},ri,labels[ri],rv)
              done()
            end}
          end
          speechObj:sayText("WEATHER QUALITY?",function()
            speechObj.game.stack:push(Menu.new(speechObj.game,items,{
              cancelable=false,tx=3,ty=3,tw=14,maxVisible=4}))
          end)
        end,
      })
      anchor="choose_world_weather_quality"

      local labId = M:gauntletLab()
      if labId then
        mod.ui.insertStepAfter(steps, anchor, {
          id = "choose_ai_rivals_gauntlet",
          kind = "choice",
          text = "Battle the AI rivals\nin " .. M:labLabel(labId) .. "?",
          saveKey = "ai_rivals_gauntlet",
          choices = { "PLAY", "SKIP" },
          values = { "play", "skip" },
          tx = 5, ty = 5, tw = 10,
        })
        anchor = "choose_ai_rivals_gauntlet"
      end

      -- Sequential per-rival naming. Runs after count is known (from the
      -- previous step's answer). For each active ordinary rival the player
      -- can name them, randomise that one, or randomise all remaining.
      mod.ui.insertStepAfter(steps, anchor, {
        id = "name_ai_rivals",
        kind = "fn",
        run = function(speechObj, done)
          local ordinary = RosterPolicy.ordinary(ROSTER)
          local rawCount = speechObj.answers and speechObj.answers["ai_rivals_count"]
          local count = RosterPolicy.clamp(rawCount, #ordinary, math.min(4, #ordinary))
          if count < 1 or #ordinary < 1 then
            done()
            return
          end

          local custom = {}
          local seed = (M.worldSeed and M:worldSeed()) or 1
          -- Pre-roll the seed-based defaults so "randomise one" is stable.
          local defaults = Names.assign(seed, ordinary)

          local function ordinalLabel(i)
            if i == 1 then return "One"
            elseif i == 2 then return "Two"
            elseif i == 3 then return "Three"
            elseif i == 4 then return "Four"
            else return tostring(i)
            end
          end

          local function saveCustom()
            pcall(function()
              mod.save:set("ai_rival_custom_names", custom)
            end)
            if M.nameAssignments then
              for id, name in pairs(custom) do
                M.nameAssignments[id] = name
              end
            end
            M.pendingIntroCustomNames = custom
          end

          local function randomNameFor(def, used)
            local preferred = defaults[def.id]
            if preferred and not used[preferred] then
              used[preferred] = true
              return preferred
            end
            local gender = tostring(def.gender or ""):lower()
            local pool = gender == "female" and Names.GIRLS or Names.BOYS
            for _, candidate in ipairs(pool) do
              if not used[candidate] then
                used[candidate] = true
                return candidate
              end
            end
            return preferred or (pool[1] or def.name or "RIVAL")
          end

          local function finishAll()
            saveCustom()
            done()
          end

          local used = {}
          local function nameRivalAt(index)
            if index > count then
              finishAll()
              return
            end
            local def = ordinary[index]
            if not def then
              finishAll()
              return
            end
            local ord = ordinalLabel(index)
            local text = "Name Rival " .. ord .. "?"
            local Menu = require("src.ui.Menu")
            local function openChoice()
              local items = {
                {
                  label = "Name Rival " .. ord,
                  onSelect = function()
                    require("src.ui.Screens").push(speechObj.game, "NamingScreen", {
                      title = "RIVAL " .. string.upper(ord) .. "'S NAME?",
                      maxLen = speechObj.nameLen or 7,
                      onDone = function(name)
                        if type(name) == "string" and name ~= "" then
                          custom[def.id] = name
                          used[name] = true
                        else
                          custom[def.id] = randomNameFor(def, used)
                        end
                        nameRivalAt(index + 1)
                      end,
                    })
                  end,
                },
                {
                  label = "Randomise Name For Rival " .. ord,
                  onSelect = function()
                    custom[def.id] = randomNameFor(def, used)
                    nameRivalAt(index + 1)
                  end,
                },
                {
                  label = "Randomise All Remaining Rival Names",
                  onSelect = function()
                    for i = index, count do
                      local d = ordinary[i]
                      if d then
                        custom[d.id] = randomNameFor(d, used)
                      end
                    end
                    finishAll()
                  end,
                },
              }
              speechObj.game.stack:push(Menu.new(speechObj.game, items, {
                cancelable = false,
                tx = 1, ty = 1, tw = 18, th = 8,
              }))
            end
            -- Ask, then wait for the choice (same pacing as a choice step).
            speechObj:sayText(text, openChoice)
          end

          nameRivalAt(1)
        end,
      })
      return steps
    end, 100)
    print("[ai_rivals] intro.oak_speech.build wrapped")
  end

  RivalGear.init(mod, M, Comms)
  installIntro()
end


------------------------------------------------------------------------
-- Exports, for tests and for other mods
------------------------------------------------------------------------

mod.exports.manager = M
mod.exports.compat = compat
mod.exports.modules = {
  Util = Util, MapGraph = MapGraph, Pathfinder = Pathfinder,
  BattleSim = BattleSim, Rival = Rival, AI = AI,
  Simulation = Simulation, Sprites = Sprites, Dialogue = Dialogue,
  Version = Version, Compat = Compat,
  Relationships = Relationships, TeamPlan = TeamPlan, Story = Story,
  Presence = Presence, Weather = Weather, Economy = Economy,
  League = League, LifePath = LifePath, Career = Career, Phone = Phone,
  TrainerClasses = TrainerClasses,
  Happiness = Happiness,
  Comms = Comms, Scout = Scout,
  RivalGear = RivalGear,
  WonderTrade = WonderTrade,
  WeatherResearch = WeatherResearch,
  FeatureParity = FeatureParity,
  KantoCompat = KantoCompat,
  Memory = Memory,
  BattleFlow = BattleFlow, RuntimePolicy = RuntimePolicy,
  Gen2Talk = Gen2Talk,
  RosterPolicy = RosterPolicy,
  Titles = Titles,
  Gauntlet = GauntletManager,
  Materialize = MaterializeManager,
  Persistence = PersistenceManager,
  ManagerComms = CommsManager,
}
mod.exports.data = { roster = ROSTER, personalities = PERSONALITIES,
                     gyms = GYMS, dialogue = LINES }
mod.exports.rivals = function() return M.rivals end

end
