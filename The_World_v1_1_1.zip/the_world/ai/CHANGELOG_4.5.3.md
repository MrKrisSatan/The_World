# AI Rivals 4.5.3

- Trimmed the face-to-face rival interaction menu to six compact actions so fixed-width ListMenu rows no longer overlap.
- Moved mood, story, team/battle style, career, weather, preferences and relationship details into a dedicated **Rival Info** submenu.
- Kept Move to Safe Tile under Rival Info as a repair/debug utility instead of crowding the primary conversation menu.
- Tournament setup now selects participant count first, then opens an explicit **Battle Mode** screen with **STANDARD** and **DOUBLE** choices.
- Double tournaments clearly show unavailable if the player lacks two healthy Pokémon or fewer than the chosen number of rivals can field two Pokémon.
- Removed the hidden tournament format toggle from the participant-count screen; Standard/Double is now an explicit selection.
