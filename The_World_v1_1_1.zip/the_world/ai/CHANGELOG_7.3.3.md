# AI Rivals 7.3.3

- Fixed Gold rival interaction routing again using both supported Gen 2 seams:
  `OverworldController.interact` and `OverworldController.talkTo`.
- The early router explicitly scans the facing cell and does not reject
  passable AI-rival runtime NPCs.
- Gold rival dialogue now uses the live Gen 2 World's native `showText`
  callback instead of relying on the Gen 1 runner lifecycle.
- Fixed `rivalInteractionOpen` becoming permanently stuck after a failed Gold
  conversation.
- Versioned the router sentinel so an older installed router cannot block the
  corrected implementation during a mod reload.
- Red/Blue/Yellow retain their existing map-script interaction path.
