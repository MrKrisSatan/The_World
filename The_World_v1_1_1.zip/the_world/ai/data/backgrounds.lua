-- 5.0.1 hidden social backgrounds. Exactly 250 save-stable records.
return {{
  id = "BG_001",
  origin = "MARKET_RUNNER",
  circumstance = "CHIP_ON_SHOULDER",
  description = "grew up carrying parcels and learning who could be trusted, chip on shoulder",
  money = 186,
  items = {
    POKE_BALL = 1,
    POTION = 2,
  },
  disposition = {
    player = -0.15,
    rival = -0.05,
    rocket = -0.1,
  },
  temper = "hostile",
  personalityBias = {
    EXPLORER = 0.04,
    TRADER = 0.06,
  },
  pathBias = {
    EXPLORER = 0.04,
    TRADER = 0.06,
  },
  careerBias = {
    EXPLORER = 0.036,
    TRADER = 0.054,
  },
}, {
  id = "BG_002",
  origin = "MARKET_RUNNER",
  circumstance = "SHARES_SUPPLIES",
  description = "grew up carrying parcels and learning who could be trusted, shares supplies",
  money = 278,
  items = {
    POKE_BALL = 1,
    POTION = 2,
  },
  disposition = {
    player = 0.08,
    rival = 0.12,
    rocket = -0.05,
  },
  temper = "kind",
  personalityBias = {
    EXPLORER = 0.04,
    TRADER = 0.06,
  },
  pathBias = {
    EXPLORER = 0.04,
    TRADER = 0.06,
  },
  careerBias = {
    EXPLORER = 0.036,
    TRADER = 0.054,
  },
}, {
  id = "BG_003",
  origin = "MARKET_RUNNER",
  circumstance = "TRUSTS_SLOWLY",
  description = "grew up carrying parcels and learning who could be trusted, trusts slowly",
  money = 270,
  items = {
    POKE_BALL = 1,
    POTION = 1,
    ANTIDOTE = 1,
  },
  disposition = {
    player = -0.05,
    rival = 0.0,
    rocket = -0.12,
  },
  temper = "guarded",
  personalityBias = {
    EXPLORER = 0.04,
    TRADER = 0.06,
  },
  pathBias = {
    EXPLORER = 0.04,
    TRADER = 0.06,
  },
  careerBias = {
    EXPLORER = 0.036,
    TRADER = 0.054,
  },
}, {
  id = "BG_004",
  origin = "MARKET_RUNNER",
  circumstance = "HATES_LOSING",
  description = "grew up carrying parcels and learning who could be trusted, hates losing",
  money = 312,
  items = {
    POKE_BALL = 2,
    POTION = 1,
  },
  disposition = {
    player = 0.0,
    rival = -0.1,
    rocket = -0.04,
  },
  temper = "competitive",
  personalityBias = {
    EXPLORER = 0.04,
    TRADER = 0.06,
  },
  pathBias = {
    EXPLORER = 0.04,
    TRADER = 0.06,
  },
  careerBias = {
    EXPLORER = 0.036,
    TRADER = 0.054,
  },
}, {
  id = "BG_005",
  origin = "MARKET_RUNNER",
  circumstance = "BELIEVES_SECOND_CHANCES",
  description = "grew up carrying parcels and learning who could be trusted, believes second chances",
  money = 364,
  items = {
    POKE_BALL = 1,
    POTION = 2,
  },
  disposition = {
    player = 0.06,
    rival = 0.08,
    rocket = -0.08,
  },
  temper = "hopeful",
  personalityBias = {
    EXPLORER = 0.04,
    TRADER = 0.06,
  },
  pathBias = {
    EXPLORER = 0.04,
    TRADER = 0.06,
  },
  careerBias = {
    EXPLORER = 0.036,
    TRADER = 0.054,
  },
}, {
  id = "BG_006",
  origin = "DOCKHAND",
  circumstance = "CHIP_ON_SHOULDER",
  description = "worked around boats and learned patience from long days, chip on shoulder",
  money = 390,
  items = {
    POKE_BALL = 1,
    ANTIDOTE = 1,
    POTION = 1,
  },
  disposition = {
    player = -0.15,
    rival = -0.05,
    rocket = -0.1,
  },
  temper = "hostile",
  personalityBias = {
    EXPLORER = 0.04,
    TRADER = 0.04,
  },
  pathBias = {
    EXPLORER = 0.04,
    TRADER = 0.04,
  },
  careerBias = {
    EXPLORER = 0.036,
    TRADER = 0.036,
  },
}, {
  id = "BG_007",
  origin = "DOCKHAND",
  circumstance = "SHARES_SUPPLIES",
  description = "worked around boats and learned patience from long days, shares supplies",
  money = 482,
  items = {
    POKE_BALL = 1,
    ANTIDOTE = 1,
    POTION = 1,
  },
  disposition = {
    player = 0.08,
    rival = 0.12,
    rocket = -0.05,
  },
  temper = "kind",
  personalityBias = {
    EXPLORER = 0.04,
    TRADER = 0.04,
  },
  pathBias = {
    EXPLORER = 0.04,
    TRADER = 0.04,
  },
  careerBias = {
    EXPLORER = 0.036,
    TRADER = 0.036,
  },
}, {
  id = "BG_008",
  origin = "DOCKHAND",
  circumstance = "TRUSTS_SLOWLY",
  description = "worked around boats and learned patience from long days, trusts slowly",
  money = 474,
  items = {
    POKE_BALL = 1,
    ANTIDOTE = 2,
  },
  disposition = {
    player = -0.05,
    rival = 0.0,
    rocket = -0.12,
  },
  temper = "guarded",
  personalityBias = {
    EXPLORER = 0.04,
    TRADER = 0.04,
  },
  pathBias = {
    EXPLORER = 0.04,
    TRADER = 0.04,
  },
  careerBias = {
    EXPLORER = 0.036,
    TRADER = 0.036,
  },
}, {
  id = "BG_009",
  origin = "DOCKHAND",
  circumstance = "HATES_LOSING",
  description = "worked around boats and learned patience from long days, hates losing",
  money = 516,
  items = {
    POKE_BALL = 2,
    ANTIDOTE = 1,
  },
  disposition = {
    player = 0.0,
    rival = -0.1,
    rocket = -0.04,
  },
  temper = "competitive",
  personalityBias = {
    EXPLORER = 0.04,
    TRADER = 0.04,
  },
  pathBias = {
    EXPLORER = 0.04,
    TRADER = 0.04,
  },
  careerBias = {
    EXPLORER = 0.036,
    TRADER = 0.036,
  },
}, {
  id = "BG_010",
  origin = "DOCKHAND",
  circumstance = "BELIEVES_SECOND_CHANCES",
  description = "worked around boats and learned patience from long days, believes second chances",
  money = 406,
  items = {
    POKE_BALL = 1,
    ANTIDOTE = 1,
    POTION = 1,
  },
  disposition = {
    player = 0.06,
    rival = 0.08,
    rocket = -0.08,
  },
  temper = "hopeful",
  personalityBias = {
    EXPLORER = 0.04,
    TRADER = 0.04,
  },
  pathBias = {
    EXPLORER = 0.04,
    TRADER = 0.04,
  },
  careerBias = {
    EXPLORER = 0.036,
    TRADER = 0.036,
  },
}, {
  id = "BG_011",
  origin = "STREET_PERFORMER",
  circumstance = "CHIP_ON_SHOULDER",
  description = "learned to read a crowd and make friends quickly, chip on shoulder",
  money = 304,
  items = {
    POKE_BALL = 1,
    AWAKENING = 1,
    POTION = 1,
  },
  disposition = {
    player = -0.15,
    rival = -0.05,
    rocket = -0.1,
  },
  temper = "hostile",
  personalityBias = {
    SHOWBOAT = 0.06,
    EXPLORER = 0.04,
  },
  pathBias = {
    PERFORMER = 0.06,
    EXPLORER = 0.04,
  },
  careerBias = {
    PERFORMER = 0.054,
    EXPLORER = 0.036,
  },
}, {
  id = "BG_012",
  origin = "STREET_PERFORMER",
  circumstance = "SHARES_SUPPLIES",
  description = "learned to read a crowd and make friends quickly, shares supplies",
  money = 396,
  items = {
    POKE_BALL = 1,
    AWAKENING = 1,
    POTION = 1,
  },
  disposition = {
    player = 0.08,
    rival = 0.12,
    rocket = -0.05,
  },
  temper = "kind",
  personalityBias = {
    SHOWBOAT = 0.06,
    EXPLORER = 0.04,
  },
  pathBias = {
    PERFORMER = 0.06,
    EXPLORER = 0.04,
  },
  careerBias = {
    PERFORMER = 0.054,
    EXPLORER = 0.036,
  },
}, {
  id = "BG_013",
  origin = "STREET_PERFORMER",
  circumstance = "TRUSTS_SLOWLY",
  description = "learned to read a crowd and make friends quickly, trusts slowly",
  money = 226,
  items = {
    POKE_BALL = 1,
    AWAKENING = 1,
    ANTIDOTE = 1,
  },
  disposition = {
    player = -0.05,
    rival = 0.0,
    rocket = -0.12,
  },
  temper = "guarded",
  personalityBias = {
    SHOWBOAT = 0.06,
    EXPLORER = 0.04,
  },
  pathBias = {
    PERFORMER = 0.06,
    EXPLORER = 0.04,
  },
  careerBias = {
    PERFORMER = 0.054,
    EXPLORER = 0.036,
  },
}, {
  id = "BG_014",
  origin = "STREET_PERFORMER",
  circumstance = "HATES_LOSING",
  description = "learned to read a crowd and make friends quickly, hates losing",
  money = 268,
  items = {
    POKE_BALL = 2,
    AWAKENING = 1,
  },
  disposition = {
    player = 0.0,
    rival = -0.1,
    rocket = -0.04,
  },
  temper = "competitive",
  personalityBias = {
    SHOWBOAT = 0.06,
    EXPLORER = 0.04,
  },
  pathBias = {
    PERFORMER = 0.06,
    EXPLORER = 0.04,
  },
  careerBias = {
    PERFORMER = 0.054,
    EXPLORER = 0.036,
  },
}, {
  id = "BG_015",
  origin = "STREET_PERFORMER",
  circumstance = "BELIEVES_SECOND_CHANCES",
  description = "learned to read a crowd and make friends quickly, believes second chances",
  money = 320,
  items = {
    POKE_BALL = 1,
    AWAKENING = 1,
    POTION = 1,
  },
  disposition = {
    player = 0.06,
    rival = 0.08,
    rocket = -0.08,
  },
  temper = "hopeful",
  personalityBias = {
    SHOWBOAT = 0.06,
    EXPLORER = 0.04,
  },
  pathBias = {
    PERFORMER = 0.06,
    EXPLORER = 0.04,
  },
  careerBias = {
    PERFORMER = 0.054,
    EXPLORER = 0.036,
  },
}, {
  id = "BG_016",
  origin = "COUNTRY_KID",
  circumstance = "CHIP_ON_SHOULDER",
  description = "was raised close to fields, routes and wild Pokémon, chip on shoulder",
  money = 388,
  items = {
    POKE_BALL = 1,
    POTION = 2,
  },
  disposition = {
    player = -0.15,
    rival = -0.05,
    rocket = -0.1,
  },
  temper = "hostile",
  personalityBias = {
    EXPLORER = 0.06,
    BREEDER = 0.04,
  },
  pathBias = {
    EXPLORER = 0.06,
    BREEDER = 0.04,
  },
  careerBias = {
    EXPLORER = 0.054,
    BREEDER = 0.036,
  },
}, {
  id = "BG_017",
  origin = "COUNTRY_KID",
  circumstance = "SHARES_SUPPLIES",
  description = "was raised close to fields, routes and wild Pokémon, shares supplies",
  money = 318,
  items = {
    POKE_BALL = 1,
    POTION = 2,
  },
  disposition = {
    player = 0.08,
    rival = 0.12,
    rocket = -0.05,
  },
  temper = "kind",
  personalityBias = {
    EXPLORER = 0.06,
    BREEDER = 0.04,
  },
  pathBias = {
    EXPLORER = 0.06,
    BREEDER = 0.04,
  },
  careerBias = {
    EXPLORER = 0.054,
    BREEDER = 0.036,
  },
}, {
  id = "BG_018",
  origin = "COUNTRY_KID",
  circumstance = "TRUSTS_SLOWLY",
  description = "was raised close to fields, routes and wild Pokémon, trusts slowly",
  money = 310,
  items = {
    POKE_BALL = 1,
    POTION = 1,
    ANTIDOTE = 1,
  },
  disposition = {
    player = -0.05,
    rival = 0.0,
    rocket = -0.12,
  },
  temper = "guarded",
  personalityBias = {
    EXPLORER = 0.06,
    BREEDER = 0.04,
  },
  pathBias = {
    EXPLORER = 0.06,
    BREEDER = 0.04,
  },
  careerBias = {
    EXPLORER = 0.054,
    BREEDER = 0.036,
  },
}, {
  id = "BG_019",
  origin = "COUNTRY_KID",
  circumstance = "HATES_LOSING",
  description = "was raised close to fields, routes and wild Pokémon, hates losing",
  money = 352,
  items = {
    POKE_BALL = 2,
    POTION = 1,
  },
  disposition = {
    player = 0.0,
    rival = -0.1,
    rocket = -0.04,
  },
  temper = "competitive",
  personalityBias = {
    EXPLORER = 0.06,
    BREEDER = 0.04,
  },
  pathBias = {
    EXPLORER = 0.06,
    BREEDER = 0.04,
  },
  careerBias = {
    EXPLORER = 0.054,
    BREEDER = 0.036,
  },
}, {
  id = "BG_020",
  origin = "COUNTRY_KID",
  circumstance = "BELIEVES_SECOND_CHANCES",
  description = "was raised close to fields, routes and wild Pokémon, believes second chances",
  money = 404,
  items = {
    POKE_BALL = 1,
    POTION = 2,
  },
  disposition = {
    player = 0.06,
    rival = 0.08,
    rocket = -0.08,
  },
  temper = "hopeful",
  personalityBias = {
    EXPLORER = 0.06,
    BREEDER = 0.04,
  },
  pathBias = {
    EXPLORER = 0.06,
    BREEDER = 0.04,
  },
  careerBias = {
    EXPLORER = 0.054,
    BREEDER = 0.036,
  },
}, {
  id = "BG_021",
  origin = "BOARDING_STUDENT",
  circumstance = "CHIP_ON_SHOULDER",
  description = "spent years away from home learning independence, chip on shoulder",
  money = 410,
  items = {
    POKE_BALL = 1,
    POTION = 2,
  },
  disposition = {
    player = -0.15,
    rival = -0.05,
    rocket = -0.1,
  },
  temper = "hostile",
  personalityBias = {
    SCHOLAR = 0.06,
    RESEARCHER = 0.04,
  },
  pathBias = {
    HISTORIAN = 0.06,
    RESEARCHER = 0.04,
  },
  careerBias = {
    HISTORIAN = 0.054,
    RESEARCHER = 0.036,
  },
}, {
  id = "BG_022",
  origin = "BOARDING_STUDENT",
  circumstance = "SHARES_SUPPLIES",
  description = "spent years away from home learning independence, shares supplies",
  money = 502,
  items = {
    POKE_BALL = 1,
    POTION = 2,
  },
  disposition = {
    player = 0.08,
    rival = 0.12,
    rocket = -0.05,
  },
  temper = "kind",
  personalityBias = {
    SCHOLAR = 0.06,
    RESEARCHER = 0.04,
  },
  pathBias = {
    HISTORIAN = 0.06,
    RESEARCHER = 0.04,
  },
  careerBias = {
    HISTORIAN = 0.054,
    RESEARCHER = 0.036,
  },
}, {
  id = "BG_023",
  origin = "BOARDING_STUDENT",
  circumstance = "TRUSTS_SLOWLY",
  description = "spent years away from home learning independence, trusts slowly",
  money = 494,
  items = {
    POKE_BALL = 1,
    POTION = 1,
    ANTIDOTE = 1,
  },
  disposition = {
    player = -0.05,
    rival = 0.0,
    rocket = -0.12,
  },
  temper = "guarded",
  personalityBias = {
    SCHOLAR = 0.06,
    RESEARCHER = 0.04,
  },
  pathBias = {
    HISTORIAN = 0.06,
    RESEARCHER = 0.04,
  },
  careerBias = {
    HISTORIAN = 0.054,
    RESEARCHER = 0.036,
  },
}, {
  id = "BG_024",
  origin = "BOARDING_STUDENT",
  circumstance = "HATES_LOSING",
  description = "spent years away from home learning independence, hates losing",
  money = 536,
  items = {
    POKE_BALL = 2,
    POTION = 1,
  },
  disposition = {
    player = 0.0,
    rival = -0.1,
    rocket = -0.04,
  },
  temper = "competitive",
  personalityBias = {
    SCHOLAR = 0.06,
    RESEARCHER = 0.04,
  },
  pathBias = {
    HISTORIAN = 0.06,
    RESEARCHER = 0.04,
  },
  careerBias = {
    HISTORIAN = 0.054,
    RESEARCHER = 0.036,
  },
}, {
  id = "BG_025",
  origin = "BOARDING_STUDENT",
  circumstance = "BELIEVES_SECOND_CHANCES",
  description = "spent years away from home learning independence, believes second chances",
  money = 588,
  items = {
    POKE_BALL = 1,
    POTION = 2,
  },
  disposition = {
    player = 0.06,
    rival = 0.08,
    rocket = -0.08,
  },
  temper = "hopeful",
  personalityBias = {
    SCHOLAR = 0.06,
    RESEARCHER = 0.04,
  },
  pathBias = {
    HISTORIAN = 0.06,
    RESEARCHER = 0.04,
  },
  careerBias = {
    HISTORIAN = 0.054,
    RESEARCHER = 0.036,
  },
}, {
  id = "BG_026",
  origin = "GYM_CADET",
  circumstance = "CHIP_ON_SHOULDER",
  description = "trained around a Gym without ever becoming an official challenger, chip on shoulder",
  money = 494,
  items = {
    POKE_BALL = 1,
    SUPER_POTION = 1,
    POTION = 1,
  },
  disposition = {
    player = -0.15,
    rival = -0.05,
    rocket = -0.1,
  },
  temper = "hostile",
  personalityBias = {
    CHALLENGER = 0.06,
    ACE = 0.04,
  },
  pathBias = {
    SWORN_RIVAL = 0.06,
    ELITE_ASPIRANT = 0.04,
  },
  careerBias = {
    SWORN_RIVAL = 0.054,
    ELITE_ASPIRANT = 0.036,
  },
}, {
  id = "BG_027",
  origin = "GYM_CADET",
  circumstance = "SHARES_SUPPLIES",
  description = "trained around a Gym without ever becoming an official challenger, shares supplies",
  money = 586,
  items = {
    POKE_BALL = 1,
    SUPER_POTION = 1,
    POTION = 1,
  },
  disposition = {
    player = 0.08,
    rival = 0.12,
    rocket = -0.05,
  },
  temper = "kind",
  personalityBias = {
    CHALLENGER = 0.06,
    ACE = 0.04,
  },
  pathBias = {
    SWORN_RIVAL = 0.06,
    ELITE_ASPIRANT = 0.04,
  },
  careerBias = {
    SWORN_RIVAL = 0.054,
    ELITE_ASPIRANT = 0.036,
  },
}, {
  id = "BG_028",
  origin = "GYM_CADET",
  circumstance = "TRUSTS_SLOWLY",
  description = "trained around a Gym without ever becoming an official challenger, trusts slowly",
  money = 578,
  items = {
    POKE_BALL = 1,
    SUPER_POTION = 1,
    ANTIDOTE = 1,
  },
  disposition = {
    player = -0.05,
    rival = 0.0,
    rocket = -0.12,
  },
  temper = "guarded",
  personalityBias = {
    CHALLENGER = 0.06,
    ACE = 0.04,
  },
  pathBias = {
    SWORN_RIVAL = 0.06,
    ELITE_ASPIRANT = 0.04,
  },
  careerBias = {
    SWORN_RIVAL = 0.054,
    ELITE_ASPIRANT = 0.036,
  },
}, {
  id = "BG_029",
  origin = "GYM_CADET",
  circumstance = "HATES_LOSING",
  description = "trained around a Gym without ever becoming an official challenger, hates losing",
  money = 620,
  items = {
    POKE_BALL = 2,
    SUPER_POTION = 1,
  },
  disposition = {
    player = 0.0,
    rival = -0.1,
    rocket = -0.04,
  },
  temper = "competitive",
  personalityBias = {
    CHALLENGER = 0.06,
    ACE = 0.04,
  },
  pathBias = {
    SWORN_RIVAL = 0.06,
    ELITE_ASPIRANT = 0.04,
  },
  careerBias = {
    SWORN_RIVAL = 0.054,
    ELITE_ASPIRANT = 0.036,
  },
}, {
  id = "BG_030",
  origin = "GYM_CADET",
  circumstance = "BELIEVES_SECOND_CHANCES",
  description = "trained around a Gym without ever becoming an official challenger, believes second chances",
  money = 672,
  items = {
    POKE_BALL = 1,
    SUPER_POTION = 1,
    POTION = 1,
  },
  disposition = {
    player = 0.06,
    rival = 0.08,
    rocket = -0.08,
  },
  temper = "hopeful",
  personalityBias = {
    CHALLENGER = 0.06,
    ACE = 0.04,
  },
  pathBias = {
    SWORN_RIVAL = 0.06,
    ELITE_ASPIRANT = 0.04,
  },
  careerBias = {
    SWORN_RIVAL = 0.054,
    ELITE_ASPIRANT = 0.036,
  },
}, {
  id = "BG_031",
  origin = "LIBRARY_PAGE",
  circumstance = "CHIP_ON_SHOULDER",
  description = "spent quiet hours organizing books and observing people, chip on shoulder",
  money = 358,
  items = {
    POKE_BALL = 1,
    REPEL = 1,
    POTION = 1,
  },
  disposition = {
    player = -0.15,
    rival = -0.05,
    rocket = -0.1,
  },
  temper = "hostile",
  personalityBias = {
    SCHOLAR = 0.08,
    RESEARCHER = 0.04,
  },
  pathBias = {
    HISTORIAN = 0.08,
    RESEARCHER = 0.04,
  },
  careerBias = {
    HISTORIAN = 0.072,
    RESEARCHER = 0.036,
  },
}, {
  id = "BG_032",
  origin = "LIBRARY_PAGE",
  circumstance = "SHARES_SUPPLIES",
  description = "spent quiet hours organizing books and observing people, shares supplies",
  money = 450,
  items = {
    POKE_BALL = 1,
    REPEL = 1,
    POTION = 1,
  },
  disposition = {
    player = 0.08,
    rival = 0.12,
    rocket = -0.05,
  },
  temper = "kind",
  personalityBias = {
    SCHOLAR = 0.08,
    RESEARCHER = 0.04,
  },
  pathBias = {
    HISTORIAN = 0.08,
    RESEARCHER = 0.04,
  },
  careerBias = {
    HISTORIAN = 0.072,
    RESEARCHER = 0.036,
  },
}, {
  id = "BG_033",
  origin = "LIBRARY_PAGE",
  circumstance = "TRUSTS_SLOWLY",
  description = "spent quiet hours organizing books and observing people, trusts slowly",
  money = 442,
  items = {
    POKE_BALL = 1,
    REPEL = 1,
    ANTIDOTE = 1,
  },
  disposition = {
    player = -0.05,
    rival = 0.0,
    rocket = -0.12,
  },
  temper = "guarded",
  personalityBias = {
    SCHOLAR = 0.08,
    RESEARCHER = 0.04,
  },
  pathBias = {
    HISTORIAN = 0.08,
    RESEARCHER = 0.04,
  },
  careerBias = {
    HISTORIAN = 0.072,
    RESEARCHER = 0.036,
  },
}, {
  id = "BG_034",
  origin = "LIBRARY_PAGE",
  circumstance = "HATES_LOSING",
  description = "spent quiet hours organizing books and observing people, hates losing",
  money = 322,
  items = {
    POKE_BALL = 2,
    REPEL = 1,
  },
  disposition = {
    player = 0.0,
    rival = -0.1,
    rocket = -0.04,
  },
  temper = "competitive",
  personalityBias = {
    SCHOLAR = 0.08,
    RESEARCHER = 0.04,
  },
  pathBias = {
    HISTORIAN = 0.08,
    RESEARCHER = 0.04,
  },
  careerBias = {
    HISTORIAN = 0.072,
    RESEARCHER = 0.036,
  },
}, {
  id = "BG_035",
  origin = "LIBRARY_PAGE",
  circumstance = "BELIEVES_SECOND_CHANCES",
  description = "spent quiet hours organizing books and observing people, believes second chances",
  money = 374,
  items = {
    POKE_BALL = 1,
    REPEL = 1,
    POTION = 1,
  },
  disposition = {
    player = 0.06,
    rival = 0.08,
    rocket = -0.08,
  },
  temper = "hopeful",
  personalityBias = {
    SCHOLAR = 0.08,
    RESEARCHER = 0.04,
  },
  pathBias = {
    HISTORIAN = 0.08,
    RESEARCHER = 0.04,
  },
  careerBias = {
    HISTORIAN = 0.072,
    RESEARCHER = 0.036,
  },
}, {
  id = "BG_036",
  origin = "COURIER",
  circumstance = "CHIP_ON_SHOULDER",
  description = "knows Kanto's roads and shortcuts better than most, chip on shoulder",
  money = 462,
  items = {
    POKE_BALL = 1,
    REPEL = 1,
    POTION = 1,
  },
  disposition = {
    player = -0.15,
    rival = -0.05,
    rocket = -0.1,
  },
  temper = "hostile",
  personalityBias = {
    EXPLORER = 0.06,
    COURIER = 0.08,
  },
  pathBias = {
    EXPLORER = 0.06,
    COURIER = 0.08,
  },
  careerBias = {
    EXPLORER = 0.054,
    COURIER = 0.072,
  },
}, {
  id = "BG_037",
  origin = "COURIER",
  circumstance = "SHARES_SUPPLIES",
  description = "knows Kanto's roads and shortcuts better than most, shares supplies",
  money = 554,
  items = {
    POKE_BALL = 1,
    REPEL = 1,
    POTION = 1,
  },
  disposition = {
    player = 0.08,
    rival = 0.12,
    rocket = -0.05,
  },
  temper = "kind",
  personalityBias = {
    EXPLORER = 0.06,
    COURIER = 0.08,
  },
  pathBias = {
    EXPLORER = 0.06,
    COURIER = 0.08,
  },
  careerBias = {
    EXPLORER = 0.054,
    COURIER = 0.072,
  },
}, {
  id = "BG_038",
  origin = "COURIER",
  circumstance = "TRUSTS_SLOWLY",
  description = "knows Kanto's roads and shortcuts better than most, trusts slowly",
  money = 384,
  items = {
    POKE_BALL = 1,
    REPEL = 1,
    ANTIDOTE = 1,
  },
  disposition = {
    player = -0.05,
    rival = 0.0,
    rocket = -0.12,
  },
  temper = "guarded",
  personalityBias = {
    EXPLORER = 0.06,
    COURIER = 0.08,
  },
  pathBias = {
    EXPLORER = 0.06,
    COURIER = 0.08,
  },
  careerBias = {
    EXPLORER = 0.054,
    COURIER = 0.072,
  },
}, {
  id = "BG_039",
  origin = "COURIER",
  circumstance = "HATES_LOSING",
  description = "knows Kanto's roads and shortcuts better than most, hates losing",
  money = 426,
  items = {
    POKE_BALL = 2,
    REPEL = 1,
  },
  disposition = {
    player = 0.0,
    rival = -0.1,
    rocket = -0.04,
  },
  temper = "competitive",
  personalityBias = {
    EXPLORER = 0.06,
    COURIER = 0.08,
  },
  pathBias = {
    EXPLORER = 0.06,
    COURIER = 0.08,
  },
  careerBias = {
    EXPLORER = 0.054,
    COURIER = 0.072,
  },
}, {
  id = "BG_040",
  origin = "COURIER",
  circumstance = "BELIEVES_SECOND_CHANCES",
  description = "knows Kanto's roads and shortcuts better than most, believes second chances",
  money = 478,
  items = {
    POKE_BALL = 1,
    REPEL = 1,
    POTION = 1,
  },
  disposition = {
    player = 0.06,
    rival = 0.08,
    rocket = -0.08,
  },
  temper = "hopeful",
  personalityBias = {
    EXPLORER = 0.06,
    COURIER = 0.08,
  },
  pathBias = {
    EXPLORER = 0.06,
    COURIER = 0.08,
  },
  careerBias = {
    EXPLORER = 0.054,
    COURIER = 0.072,
  },
}, {
  id = "BG_041",
  origin = "MECHANIC_APPRENTICE",
  circumstance = "CHIP_ON_SHOULDER",
  description = "learned to fix broken machines instead of throwing them away, chip on shoulder",
  money = 364,
  items = {
    POKE_BALL = 1,
    POTION = 2,
  },
  disposition = {
    player = -0.15,
    rival = -0.05,
    rocket = -0.1,
  },
  temper = "hostile",
  personalityBias = {
    TRADER = 0.04,
    TECHNICIAN = 0.08,
  },
  pathBias = {
    TRADER = 0.04,
    MECHANIC = 0.08,
  },
  careerBias = {
    TRADER = 0.036,
    MECHANIC = 0.072,
  },
}, {
  id = "BG_042",
  origin = "MECHANIC_APPRENTICE",
  circumstance = "SHARES_SUPPLIES",
  description = "learned to fix broken machines instead of throwing them away, shares supplies",
  money = 456,
  items = {
    POKE_BALL = 1,
    POTION = 2,
  },
  disposition = {
    player = 0.08,
    rival = 0.12,
    rocket = -0.05,
  },
  temper = "kind",
  personalityBias = {
    TRADER = 0.04,
    TECHNICIAN = 0.08,
  },
  pathBias = {
    TRADER = 0.04,
    MECHANIC = 0.08,
  },
  careerBias = {
    TRADER = 0.036,
    MECHANIC = 0.072,
  },
}, {
  id = "BG_043",
  origin = "MECHANIC_APPRENTICE",
  circumstance = "TRUSTS_SLOWLY",
  description = "learned to fix broken machines instead of throwing them away, trusts slowly",
  money = 448,
  items = {
    POKE_BALL = 1,
    POTION = 1,
    ANTIDOTE = 1,
  },
  disposition = {
    player = -0.05,
    rival = 0.0,
    rocket = -0.12,
  },
  temper = "guarded",
  personalityBias = {
    TRADER = 0.04,
    TECHNICIAN = 0.08,
  },
  pathBias = {
    TRADER = 0.04,
    MECHANIC = 0.08,
  },
  careerBias = {
    TRADER = 0.036,
    MECHANIC = 0.072,
  },
}, {
  id = "BG_044",
  origin = "MECHANIC_APPRENTICE",
  circumstance = "HATES_LOSING",
  description = "learned to fix broken machines instead of throwing them away, hates losing",
  money = 490,
  items = {
    POKE_BALL = 2,
    POTION = 1,
  },
  disposition = {
    player = 0.0,
    rival = -0.1,
    rocket = -0.04,
  },
  temper = "competitive",
  personalityBias = {
    TRADER = 0.04,
    TECHNICIAN = 0.08,
  },
  pathBias = {
    TRADER = 0.04,
    MECHANIC = 0.08,
  },
  careerBias = {
    TRADER = 0.036,
    MECHANIC = 0.072,
  },
}, {
  id = "BG_045",
  origin = "MECHANIC_APPRENTICE",
  circumstance = "BELIEVES_SECOND_CHANCES",
  description = "learned to fix broken machines instead of throwing them away, believes second chances",
  money = 542,
  items = {
    POKE_BALL = 1,
    POTION = 2,
  },
  disposition = {
    player = 0.06,
    rival = 0.08,
    rocket = -0.08,
  },
  temper = "hopeful",
  personalityBias = {
    TRADER = 0.04,
    TECHNICIAN = 0.08,
  },
  pathBias = {
    TRADER = 0.04,
    MECHANIC = 0.08,
  },
  careerBias = {
    TRADER = 0.036,
    MECHANIC = 0.072,
  },
}, {
  id = "BG_046",
  origin = "FISHING_FAMILY",
  circumstance = "CHIP_ON_SHOULDER",
  description = "grew up around anglers, boats and patient competition, chip on shoulder",
  money = 248,
  items = {
    POKE_BALL = 1,
    ANTIDOTE = 1,
    POTION = 1,
  },
  disposition = {
    player = -0.15,
    rival = -0.05,
    rocket = -0.1,
  },
  temper = "hostile",
  personalityBias = {
    EXPLORER = 0.04,
    TRADER = 0.04,
  },
  pathBias = {
    EXPLORER = 0.04,
    TRADER = 0.04,
  },
  careerBias = {
    EXPLORER = 0.036,
    TRADER = 0.036,
  },
}, {
  id = "BG_047",
  origin = "FISHING_FAMILY",
  circumstance = "SHARES_SUPPLIES",
  description = "grew up around anglers, boats and patient competition, shares supplies",
  money = 340,
  items = {
    POKE_BALL = 1,
    ANTIDOTE = 1,
    POTION = 1,
  },
  disposition = {
    player = 0.08,
    rival = 0.12,
    rocket = -0.05,
  },
  temper = "kind",
  personalityBias = {
    EXPLORER = 0.04,
    TRADER = 0.04,
  },
  pathBias = {
    EXPLORER = 0.04,
    TRADER = 0.04,
  },
  careerBias = {
    EXPLORER = 0.036,
    TRADER = 0.036,
  },
}, {
  id = "BG_048",
  origin = "FISHING_FAMILY",
  circumstance = "TRUSTS_SLOWLY",
  description = "grew up around anglers, boats and patient competition, trusts slowly",
  money = 332,
  items = {
    POKE_BALL = 1,
    ANTIDOTE = 2,
  },
  disposition = {
    player = -0.05,
    rival = 0.0,
    rocket = -0.12,
  },
  temper = "guarded",
  personalityBias = {
    EXPLORER = 0.04,
    TRADER = 0.04,
  },
  pathBias = {
    EXPLORER = 0.04,
    TRADER = 0.04,
  },
  careerBias = {
    EXPLORER = 0.036,
    TRADER = 0.036,
  },
}, {
  id = "BG_049",
  origin = "FISHING_FAMILY",
  circumstance = "HATES_LOSING",
  description = "grew up around anglers, boats and patient competition, hates losing",
  money = 374,
  items = {
    POKE_BALL = 2,
    ANTIDOTE = 1,
  },
  disposition = {
    player = 0.0,
    rival = -0.1,
    rocket = -0.04,
  },
  temper = "competitive",
  personalityBias = {
    EXPLORER = 0.04,
    TRADER = 0.04,
  },
  pathBias = {
    EXPLORER = 0.04,
    TRADER = 0.04,
  },
  careerBias = {
    EXPLORER = 0.036,
    TRADER = 0.036,
  },
}, {
  id = "BG_050",
  origin = "FISHING_FAMILY",
  circumstance = "BELIEVES_SECOND_CHANCES",
  description = "grew up around anglers, boats and patient competition, believes second chances",
  money = 426,
  items = {
    POKE_BALL = 1,
    ANTIDOTE = 1,
    POTION = 1,
  },
  disposition = {
    player = 0.06,
    rival = 0.08,
    rocket = -0.08,
  },
  temper = "hopeful",
  personalityBias = {
    EXPLORER = 0.04,
    TRADER = 0.04,
  },
  pathBias = {
    EXPLORER = 0.04,
    TRADER = 0.04,
  },
  careerBias = {
    EXPLORER = 0.036,
    TRADER = 0.036,
  },
}, {
  id = "BG_051",
  origin = "RANCH_HAND",
  circumstance = "CHIP_ON_SHOULDER",
  description = "learned responsibility by caring for living things, chip on shoulder",
  money = 272,
  items = {
    POKE_BALL = 1,
    POTION = 2,
  },
  disposition = {
    player = -0.15,
    rival = -0.05,
    rocket = -0.1,
  },
  temper = "hostile",
  personalityBias = {
    BREEDER = 0.08,
    PROTECTOR = 0.06,
  },
  pathBias = {
    BREEDER = 0.08,
    PROTECTOR = 0.06,
  },
  careerBias = {
    BREEDER = 0.072,
    PROTECTOR = 0.054,
  },
}, {
  id = "BG_052",
  origin = "RANCH_HAND",
  circumstance = "SHARES_SUPPLIES",
  description = "learned responsibility by caring for living things, shares supplies",
  money = 364,
  items = {
    POKE_BALL = 1,
    POTION = 2,
  },
  disposition = {
    player = 0.08,
    rival = 0.12,
    rocket = -0.05,
  },
  temper = "kind",
  personalityBias = {
    BREEDER = 0.08,
    PROTECTOR = 0.06,
  },
  pathBias = {
    BREEDER = 0.08,
    PROTECTOR = 0.06,
  },
  careerBias = {
    BREEDER = 0.072,
    PROTECTOR = 0.054,
  },
}, {
  id = "BG_053",
  origin = "RANCH_HAND",
  circumstance = "TRUSTS_SLOWLY",
  description = "learned responsibility by caring for living things, trusts slowly",
  money = 356,
  items = {
    POKE_BALL = 1,
    POTION = 1,
    ANTIDOTE = 1,
  },
  disposition = {
    player = -0.05,
    rival = 0.0,
    rocket = -0.12,
  },
  temper = "guarded",
  personalityBias = {
    BREEDER = 0.08,
    PROTECTOR = 0.06,
  },
  pathBias = {
    BREEDER = 0.08,
    PROTECTOR = 0.06,
  },
  careerBias = {
    BREEDER = 0.072,
    PROTECTOR = 0.054,
  },
}, {
  id = "BG_054",
  origin = "RANCH_HAND",
  circumstance = "HATES_LOSING",
  description = "learned responsibility by caring for living things, hates losing",
  money = 398,
  items = {
    POKE_BALL = 2,
    POTION = 1,
  },
  disposition = {
    player = 0.0,
    rival = -0.1,
    rocket = -0.04,
  },
  temper = "competitive",
  personalityBias = {
    BREEDER = 0.08,
    PROTECTOR = 0.06,
  },
  pathBias = {
    BREEDER = 0.08,
    PROTECTOR = 0.06,
  },
  careerBias = {
    BREEDER = 0.072,
    PROTECTOR = 0.054,
  },
}, {
  id = "BG_055",
  origin = "RANCH_HAND",
  circumstance = "BELIEVES_SECOND_CHANCES",
  description = "learned responsibility by caring for living things, believes second chances",
  money = 450,
  items = {
    POKE_BALL = 1,
    POTION = 2,
  },
  disposition = {
    player = 0.06,
    rival = 0.08,
    rocket = -0.08,
  },
  temper = "hopeful",
  personalityBias = {
    BREEDER = 0.08,
    PROTECTOR = 0.06,
  },
  pathBias = {
    BREEDER = 0.08,
    PROTECTOR = 0.06,
  },
  careerBias = {
    BREEDER = 0.072,
    PROTECTOR = 0.054,
  },
}, {
  id = "BG_056",
  origin = "FLOWER_SHOP_HELPER",
  circumstance = "CHIP_ON_SHOULDER",
  description = "learned that small acts of care can change a day, chip on shoulder",
  money = 346,
  items = {
    POKE_BALL = 1,
    POTION = 2,
  },
  disposition = {
    player = -0.15,
    rival = -0.05,
    rocket = -0.1,
  },
  temper = "hostile",
  personalityBias = {
    BREEDER = 0.06,
    PROTECTOR = 0.08,
  },
  pathBias = {
    BREEDER = 0.06,
    PROTECTOR = 0.08,
  },
  careerBias = {
    BREEDER = 0.054,
    PROTECTOR = 0.072,
  },
}, {
  id = "BG_057",
  origin = "FLOWER_SHOP_HELPER",
  circumstance = "SHARES_SUPPLIES",
  description = "learned that small acts of care can change a day, shares supplies",
  money = 438,
  items = {
    POKE_BALL = 1,
    POTION = 2,
  },
  disposition = {
    player = 0.08,
    rival = 0.12,
    rocket = -0.05,
  },
  temper = "kind",
  personalityBias = {
    BREEDER = 0.06,
    PROTECTOR = 0.08,
  },
  pathBias = {
    BREEDER = 0.06,
    PROTECTOR = 0.08,
  },
  careerBias = {
    BREEDER = 0.054,
    PROTECTOR = 0.072,
  },
}, {
  id = "BG_058",
  origin = "FLOWER_SHOP_HELPER",
  circumstance = "TRUSTS_SLOWLY",
  description = "learned that small acts of care can change a day, trusts slowly",
  money = 430,
  items = {
    POKE_BALL = 1,
    POTION = 1,
    ANTIDOTE = 1,
  },
  disposition = {
    player = -0.05,
    rival = 0.0,
    rocket = -0.12,
  },
  temper = "guarded",
  personalityBias = {
    BREEDER = 0.06,
    PROTECTOR = 0.08,
  },
  pathBias = {
    BREEDER = 0.06,
    PROTECTOR = 0.08,
  },
  careerBias = {
    BREEDER = 0.054,
    PROTECTOR = 0.072,
  },
}, {
  id = "BG_059",
  origin = "FLOWER_SHOP_HELPER",
  circumstance = "HATES_LOSING",
  description = "learned that small acts of care can change a day, hates losing",
  money = 310,
  items = {
    POKE_BALL = 2,
    POTION = 1,
  },
  disposition = {
    player = 0.0,
    rival = -0.1,
    rocket = -0.04,
  },
  temper = "competitive",
  personalityBias = {
    BREEDER = 0.06,
    PROTECTOR = 0.08,
  },
  pathBias = {
    BREEDER = 0.06,
    PROTECTOR = 0.08,
  },
  careerBias = {
    BREEDER = 0.054,
    PROTECTOR = 0.072,
  },
}, {
  id = "BG_060",
  origin = "FLOWER_SHOP_HELPER",
  circumstance = "BELIEVES_SECOND_CHANCES",
  description = "learned that small acts of care can change a day, believes second chances",
  money = 362,
  items = {
    POKE_BALL = 1,
    POTION = 2,
  },
  disposition = {
    player = 0.06,
    rival = 0.08,
    rocket = -0.08,
  },
  temper = "hopeful",
  personalityBias = {
    BREEDER = 0.06,
    PROTECTOR = 0.08,
  },
  pathBias = {
    BREEDER = 0.06,
    PROTECTOR = 0.08,
  },
  careerBias = {
    BREEDER = 0.054,
    PROTECTOR = 0.072,
  },
}, {
  id = "BG_061",
  origin = "NIGHT_CLERK",
  circumstance = "CHIP_ON_SHOULDER",
  description = "worked late shifts and learned to stay calm around strangers, chip on shoulder",
  money = 420,
  items = {
    POKE_BALL = 1,
    AWAKENING = 1,
    POTION = 1,
  },
  disposition = {
    player = -0.15,
    rival = -0.05,
    rocket = -0.1,
  },
  temper = "hostile",
  personalityBias = {
    SURVIVALIST = 0.06,
    EXPLORER = 0.04,
  },
  pathBias = {
    MOUNTAINEER = 0.06,
    EXPLORER = 0.04,
  },
  careerBias = {
    MOUNTAINEER = 0.054,
    EXPLORER = 0.036,
  },
}, {
  id = "BG_062",
  origin = "NIGHT_CLERK",
  circumstance = "SHARES_SUPPLIES",
  description = "worked late shifts and learned to stay calm around strangers, shares supplies",
  money = 350,
  items = {
    POKE_BALL = 1,
    AWAKENING = 1,
    POTION = 1,
  },
  disposition = {
    player = 0.08,
    rival = 0.12,
    rocket = -0.05,
  },
  temper = "kind",
  personalityBias = {
    SURVIVALIST = 0.06,
    EXPLORER = 0.04,
  },
  pathBias = {
    MOUNTAINEER = 0.06,
    EXPLORER = 0.04,
  },
  careerBias = {
    MOUNTAINEER = 0.054,
    EXPLORER = 0.036,
  },
}, {
  id = "BG_063",
  origin = "NIGHT_CLERK",
  circumstance = "TRUSTS_SLOWLY",
  description = "worked late shifts and learned to stay calm around strangers, trusts slowly",
  money = 342,
  items = {
    POKE_BALL = 1,
    AWAKENING = 1,
    ANTIDOTE = 1,
  },
  disposition = {
    player = -0.05,
    rival = 0.0,
    rocket = -0.12,
  },
  temper = "guarded",
  personalityBias = {
    SURVIVALIST = 0.06,
    EXPLORER = 0.04,
  },
  pathBias = {
    MOUNTAINEER = 0.06,
    EXPLORER = 0.04,
  },
  careerBias = {
    MOUNTAINEER = 0.054,
    EXPLORER = 0.036,
  },
}, {
  id = "BG_064",
  origin = "NIGHT_CLERK",
  circumstance = "HATES_LOSING",
  description = "worked late shifts and learned to stay calm around strangers, hates losing",
  money = 384,
  items = {
    POKE_BALL = 2,
    AWAKENING = 1,
  },
  disposition = {
    player = 0.0,
    rival = -0.1,
    rocket = -0.04,
  },
  temper = "competitive",
  personalityBias = {
    SURVIVALIST = 0.06,
    EXPLORER = 0.04,
  },
  pathBias = {
    MOUNTAINEER = 0.06,
    EXPLORER = 0.04,
  },
  careerBias = {
    MOUNTAINEER = 0.054,
    EXPLORER = 0.036,
  },
}, {
  id = "BG_065",
  origin = "NIGHT_CLERK",
  circumstance = "BELIEVES_SECOND_CHANCES",
  description = "worked late shifts and learned to stay calm around strangers, believes second chances",
  money = 436,
  items = {
    POKE_BALL = 1,
    AWAKENING = 1,
    POTION = 1,
  },
  disposition = {
    player = 0.06,
    rival = 0.08,
    rocket = -0.08,
  },
  temper = "hopeful",
  personalityBias = {
    SURVIVALIST = 0.06,
    EXPLORER = 0.04,
  },
  pathBias = {
    MOUNTAINEER = 0.06,
    EXPLORER = 0.04,
  },
  careerBias = {
    MOUNTAINEER = 0.054,
    EXPLORER = 0.036,
  },
}, {
  id = "BG_066",
  origin = "CASINO_REGULAR",
  circumstance = "CHIP_ON_SHOULDER",
  description = "grew comfortable with risk, odds and sudden reversals, chip on shoulder",
  money = 542,
  items = {
    POKE_BALL = 1,
    REPEL = 1,
    POTION = 1,
  },
  disposition = {
    player = -0.15,
    rival = -0.05,
    rocket = -0.1,
  },
  temper = "hostile",
  personalityBias = {
    TRADER = 0.08,
    CHALLENGER = 0.04,
  },
  pathBias = {
    TRADER = 0.08,
    SWORN_RIVAL = 0.04,
  },
  careerBias = {
    TRADER = 0.072,
    SWORN_RIVAL = 0.036,
  },
}, {
  id = "BG_067",
  origin = "CASINO_REGULAR",
  circumstance = "SHARES_SUPPLIES",
  description = "grew comfortable with risk, odds and sudden reversals, shares supplies",
  money = 634,
  items = {
    POKE_BALL = 1,
    REPEL = 1,
    POTION = 1,
  },
  disposition = {
    player = 0.08,
    rival = 0.12,
    rocket = -0.05,
  },
  temper = "kind",
  personalityBias = {
    TRADER = 0.08,
    CHALLENGER = 0.04,
  },
  pathBias = {
    TRADER = 0.08,
    SWORN_RIVAL = 0.04,
  },
  careerBias = {
    TRADER = 0.072,
    SWORN_RIVAL = 0.036,
  },
}, {
  id = "BG_068",
  origin = "CASINO_REGULAR",
  circumstance = "TRUSTS_SLOWLY",
  description = "grew comfortable with risk, odds and sudden reversals, trusts slowly",
  money = 626,
  items = {
    POKE_BALL = 1,
    REPEL = 1,
    ANTIDOTE = 1,
  },
  disposition = {
    player = -0.05,
    rival = 0.0,
    rocket = -0.12,
  },
  temper = "guarded",
  personalityBias = {
    TRADER = 0.08,
    CHALLENGER = 0.04,
  },
  pathBias = {
    TRADER = 0.08,
    SWORN_RIVAL = 0.04,
  },
  careerBias = {
    TRADER = 0.072,
    SWORN_RIVAL = 0.036,
  },
}, {
  id = "BG_069",
  origin = "CASINO_REGULAR",
  circumstance = "HATES_LOSING",
  description = "grew comfortable with risk, odds and sudden reversals, hates losing",
  money = 668,
  items = {
    POKE_BALL = 2,
    REPEL = 1,
  },
  disposition = {
    player = 0.0,
    rival = -0.1,
    rocket = -0.04,
  },
  temper = "competitive",
  personalityBias = {
    TRADER = 0.08,
    CHALLENGER = 0.04,
  },
  pathBias = {
    TRADER = 0.08,
    SWORN_RIVAL = 0.04,
  },
  careerBias = {
    TRADER = 0.072,
    SWORN_RIVAL = 0.036,
  },
}, {
  id = "BG_070",
  origin = "CASINO_REGULAR",
  circumstance = "BELIEVES_SECOND_CHANCES",
  description = "grew comfortable with risk, odds and sudden reversals, believes second chances",
  money = 720,
  items = {
    POKE_BALL = 1,
    REPEL = 1,
    POTION = 1,
  },
  disposition = {
    player = 0.06,
    rival = 0.08,
    rocket = -0.08,
  },
  temper = "hopeful",
  personalityBias = {
    TRADER = 0.08,
    CHALLENGER = 0.04,
  },
  pathBias = {
    TRADER = 0.08,
    SWORN_RIVAL = 0.04,
  },
  careerBias = {
    TRADER = 0.072,
    SWORN_RIVAL = 0.036,
  },
}, {
  id = "BG_071",
  origin = "TRAVELING_VENDOR",
  circumstance = "CHIP_ON_SHOULDER",
  description = "learned to bargain with nearly everyone they met, chip on shoulder",
  money = 626,
  items = {
    POKE_BALL = 1,
    SUPER_POTION = 1,
    POTION = 1,
  },
  disposition = {
    player = -0.15,
    rival = -0.05,
    rocket = -0.1,
  },
  temper = "hostile",
  personalityBias = {
    TRADER = 0.1,
    EXPLORER = 0.04,
  },
  pathBias = {
    TRADER = 0.1,
    EXPLORER = 0.04,
  },
  careerBias = {
    TRADER = 0.09,
    EXPLORER = 0.036,
  },
}, {
  id = "BG_072",
  origin = "TRAVELING_VENDOR",
  circumstance = "SHARES_SUPPLIES",
  description = "learned to bargain with nearly everyone they met, shares supplies",
  money = 718,
  items = {
    POKE_BALL = 1,
    SUPER_POTION = 1,
    POTION = 1,
  },
  disposition = {
    player = 0.08,
    rival = 0.12,
    rocket = -0.05,
  },
  temper = "kind",
  personalityBias = {
    TRADER = 0.1,
    EXPLORER = 0.04,
  },
  pathBias = {
    TRADER = 0.1,
    EXPLORER = 0.04,
  },
  careerBias = {
    TRADER = 0.09,
    EXPLORER = 0.036,
  },
}, {
  id = "BG_073",
  origin = "TRAVELING_VENDOR",
  circumstance = "TRUSTS_SLOWLY",
  description = "learned to bargain with nearly everyone they met, trusts slowly",
  money = 710,
  items = {
    POKE_BALL = 1,
    SUPER_POTION = 1,
    ANTIDOTE = 1,
  },
  disposition = {
    player = -0.05,
    rival = 0.0,
    rocket = -0.12,
  },
  temper = "guarded",
  personalityBias = {
    TRADER = 0.1,
    EXPLORER = 0.04,
  },
  pathBias = {
    TRADER = 0.1,
    EXPLORER = 0.04,
  },
  careerBias = {
    TRADER = 0.09,
    EXPLORER = 0.036,
  },
}, {
  id = "BG_074",
  origin = "TRAVELING_VENDOR",
  circumstance = "HATES_LOSING",
  description = "learned to bargain with nearly everyone they met, hates losing",
  money = 752,
  items = {
    POKE_BALL = 2,
    SUPER_POTION = 1,
  },
  disposition = {
    player = 0.0,
    rival = -0.1,
    rocket = -0.04,
  },
  temper = "competitive",
  personalityBias = {
    TRADER = 0.1,
    EXPLORER = 0.04,
  },
  pathBias = {
    TRADER = 0.1,
    EXPLORER = 0.04,
  },
  careerBias = {
    TRADER = 0.09,
    EXPLORER = 0.036,
  },
}, {
  id = "BG_075",
  origin = "TRAVELING_VENDOR",
  circumstance = "BELIEVES_SECOND_CHANCES",
  description = "learned to bargain with nearly everyone they met, believes second chances",
  money = 804,
  items = {
    POKE_BALL = 1,
    SUPER_POTION = 1,
    POTION = 1,
  },
  disposition = {
    player = 0.06,
    rival = 0.08,
    rocket = -0.08,
  },
  temper = "hopeful",
  personalityBias = {
    TRADER = 0.1,
    EXPLORER = 0.04,
  },
  pathBias = {
    TRADER = 0.1,
    EXPLORER = 0.04,
  },
  careerBias = {
    TRADER = 0.09,
    EXPLORER = 0.036,
  },
}, {
  id = "BG_076",
  origin = "CENTER_VOLUNTEER",
  circumstance = "CHIP_ON_SHOULDER",
  description = "spent time helping tired trainers recover, chip on shoulder",
  money = 380,
  items = {
    POTION = 2,
    ANTIDOTE = 1,
  },
  disposition = {
    player = -0.15,
    rival = -0.05,
    rocket = -0.1,
  },
  temper = "hostile",
  personalityBias = {
    PROTECTOR = 0.1,
    MENTOR = 0.06,
  },
  pathBias = {
    PROTECTOR = 0.1,
    MENTOR_PATH = 0.06,
  },
  careerBias = {
    PROTECTOR = 0.09,
    MENTOR_PATH = 0.054,
  },
}, {
  id = "BG_077",
  origin = "CENTER_VOLUNTEER",
  circumstance = "SHARES_SUPPLIES",
  description = "spent time helping tired trainers recover, shares supplies",
  money = 472,
  items = {
    POTION = 2,
    ANTIDOTE = 1,
  },
  disposition = {
    player = 0.08,
    rival = 0.12,
    rocket = -0.05,
  },
  temper = "kind",
  personalityBias = {
    PROTECTOR = 0.1,
    MENTOR = 0.06,
  },
  pathBias = {
    PROTECTOR = 0.1,
    MENTOR_PATH = 0.06,
  },
  careerBias = {
    PROTECTOR = 0.09,
    MENTOR_PATH = 0.054,
  },
}, {
  id = "BG_078",
  origin = "CENTER_VOLUNTEER",
  circumstance = "TRUSTS_SLOWLY",
  description = "spent time helping tired trainers recover, trusts slowly",
  money = 464,
  items = {
    POTION = 1,
    ANTIDOTE = 2,
  },
  disposition = {
    player = -0.05,
    rival = 0.0,
    rocket = -0.12,
  },
  temper = "guarded",
  personalityBias = {
    PROTECTOR = 0.1,
    MENTOR = 0.06,
  },
  pathBias = {
    PROTECTOR = 0.1,
    MENTOR_PATH = 0.06,
  },
  careerBias = {
    PROTECTOR = 0.09,
    MENTOR_PATH = 0.054,
  },
}, {
  id = "BG_079",
  origin = "CENTER_VOLUNTEER",
  circumstance = "HATES_LOSING",
  description = "spent time helping tired trainers recover, hates losing",
  money = 506,
  items = {
    POTION = 1,
    ANTIDOTE = 1,
    POKE_BALL = 1,
  },
  disposition = {
    player = 0.0,
    rival = -0.1,
    rocket = -0.04,
  },
  temper = "competitive",
  personalityBias = {
    PROTECTOR = 0.1,
    MENTOR = 0.06,
  },
  pathBias = {
    PROTECTOR = 0.1,
    MENTOR_PATH = 0.06,
  },
  careerBias = {
    PROTECTOR = 0.09,
    MENTOR_PATH = 0.054,
  },
}, {
  id = "BG_080",
  origin = "CENTER_VOLUNTEER",
  circumstance = "BELIEVES_SECOND_CHANCES",
  description = "spent time helping tired trainers recover, believes second chances",
  money = 396,
  items = {
    POTION = 2,
    ANTIDOTE = 1,
  },
  disposition = {
    player = 0.06,
    rival = 0.08,
    rocket = -0.08,
  },
  temper = "hopeful",
  personalityBias = {
    PROTECTOR = 0.1,
    MENTOR = 0.06,
  },
  pathBias = {
    PROTECTOR = 0.1,
    MENTOR_PATH = 0.06,
  },
  careerBias = {
    PROTECTOR = 0.09,
    MENTOR_PATH = 0.054,
  },
}, {
  id = "BG_081",
  origin = "BUG_CLUB_VETERAN",
  circumstance = "CHIP_ON_SHOULDER",
  description = "learned patience by searching every patch of grass, chip on shoulder",
  money = 294,
  items = {
    POKE_BALL = 1,
    REPEL = 1,
    POTION = 1,
  },
  disposition = {
    player = -0.15,
    rival = -0.05,
    rocket = -0.1,
  },
  temper = "hostile",
  personalityBias = {
    COLLECTOR = 0.08,
    EXPLORER = 0.06,
  },
  pathBias = {
    DEX_COMPLETIONIST = 0.08,
    EXPLORER = 0.06,
  },
  careerBias = {
    DEX_COMPLETIONIST = 0.072,
    EXPLORER = 0.054,
  },
}, {
  id = "BG_082",
  origin = "BUG_CLUB_VETERAN",
  circumstance = "SHARES_SUPPLIES",
  description = "learned patience by searching every patch of grass, shares supplies",
  money = 386,
  items = {
    POKE_BALL = 1,
    REPEL = 1,
    POTION = 1,
  },
  disposition = {
    player = 0.08,
    rival = 0.12,
    rocket = -0.05,
  },
  temper = "kind",
  personalityBias = {
    COLLECTOR = 0.08,
    EXPLORER = 0.06,
  },
  pathBias = {
    DEX_COMPLETIONIST = 0.08,
    EXPLORER = 0.06,
  },
  careerBias = {
    DEX_COMPLETIONIST = 0.072,
    EXPLORER = 0.054,
  },
}, {
  id = "BG_083",
  origin = "BUG_CLUB_VETERAN",
  circumstance = "TRUSTS_SLOWLY",
  description = "learned patience by searching every patch of grass, trusts slowly",
  money = 378,
  items = {
    POKE_BALL = 1,
    REPEL = 1,
    ANTIDOTE = 1,
  },
  disposition = {
    player = -0.05,
    rival = 0.0,
    rocket = -0.12,
  },
  temper = "guarded",
  personalityBias = {
    COLLECTOR = 0.08,
    EXPLORER = 0.06,
  },
  pathBias = {
    DEX_COMPLETIONIST = 0.08,
    EXPLORER = 0.06,
  },
  careerBias = {
    DEX_COMPLETIONIST = 0.072,
    EXPLORER = 0.054,
  },
}, {
  id = "BG_084",
  origin = "BUG_CLUB_VETERAN",
  circumstance = "HATES_LOSING",
  description = "learned patience by searching every patch of grass, hates losing",
  money = 258,
  items = {
    POKE_BALL = 2,
    REPEL = 1,
  },
  disposition = {
    player = 0.0,
    rival = -0.1,
    rocket = -0.04,
  },
  temper = "competitive",
  personalityBias = {
    COLLECTOR = 0.08,
    EXPLORER = 0.06,
  },
  pathBias = {
    DEX_COMPLETIONIST = 0.08,
    EXPLORER = 0.06,
  },
  careerBias = {
    DEX_COMPLETIONIST = 0.072,
    EXPLORER = 0.054,
  },
}, {
  id = "BG_085",
  origin = "BUG_CLUB_VETERAN",
  circumstance = "BELIEVES_SECOND_CHANCES",
  description = "learned patience by searching every patch of grass, believes second chances",
  money = 310,
  items = {
    POKE_BALL = 1,
    REPEL = 1,
    POTION = 1,
  },
  disposition = {
    player = 0.06,
    rival = 0.08,
    rocket = -0.08,
  },
  temper = "hopeful",
  personalityBias = {
    COLLECTOR = 0.08,
    EXPLORER = 0.06,
  },
  pathBias = {
    DEX_COMPLETIONIST = 0.08,
    EXPLORER = 0.06,
  },
  careerBias = {
    DEX_COMPLETIONIST = 0.072,
    EXPLORER = 0.054,
  },
}, {
  id = "BG_086",
  origin = "AMATEUR_BREEDER",
  circumstance = "CHIP_ON_SHOULDER",
  description = "kept careful notes on Pokémon care and habits, chip on shoulder",
  money = 548,
  items = {
    POKE_BALL = 1,
    POTION = 2,
  },
  disposition = {
    player = -0.15,
    rival = -0.05,
    rocket = -0.1,
  },
  temper = "hostile",
  personalityBias = {
    BREEDER = 0.1,
    MENTOR = 0.04,
  },
  pathBias = {
    BREEDER = 0.1,
    MENTOR_PATH = 0.04,
  },
  careerBias = {
    BREEDER = 0.09,
    MENTOR_PATH = 0.036,
  },
}, {
  id = "BG_087",
  origin = "AMATEUR_BREEDER",
  circumstance = "SHARES_SUPPLIES",
  description = "kept careful notes on Pokémon care and habits, shares supplies",
  money = 478,
  items = {
    POKE_BALL = 1,
    POTION = 2,
  },
  disposition = {
    player = 0.08,
    rival = 0.12,
    rocket = -0.05,
  },
  temper = "kind",
  personalityBias = {
    BREEDER = 0.1,
    MENTOR = 0.04,
  },
  pathBias = {
    BREEDER = 0.1,
    MENTOR_PATH = 0.04,
  },
  careerBias = {
    BREEDER = 0.09,
    MENTOR_PATH = 0.036,
  },
}, {
  id = "BG_088",
  origin = "AMATEUR_BREEDER",
  circumstance = "TRUSTS_SLOWLY",
  description = "kept careful notes on Pokémon care and habits, trusts slowly",
  money = 470,
  items = {
    POKE_BALL = 1,
    POTION = 1,
    ANTIDOTE = 1,
  },
  disposition = {
    player = -0.05,
    rival = 0.0,
    rocket = -0.12,
  },
  temper = "guarded",
  personalityBias = {
    BREEDER = 0.1,
    MENTOR = 0.04,
  },
  pathBias = {
    BREEDER = 0.1,
    MENTOR_PATH = 0.04,
  },
  careerBias = {
    BREEDER = 0.09,
    MENTOR_PATH = 0.036,
  },
}, {
  id = "BG_089",
  origin = "AMATEUR_BREEDER",
  circumstance = "HATES_LOSING",
  description = "kept careful notes on Pokémon care and habits, hates losing",
  money = 512,
  items = {
    POKE_BALL = 2,
    POTION = 1,
  },
  disposition = {
    player = 0.0,
    rival = -0.1,
    rocket = -0.04,
  },
  temper = "competitive",
  personalityBias = {
    BREEDER = 0.1,
    MENTOR = 0.04,
  },
  pathBias = {
    BREEDER = 0.1,
    MENTOR_PATH = 0.04,
  },
  careerBias = {
    BREEDER = 0.09,
    MENTOR_PATH = 0.036,
  },
}, {
  id = "BG_090",
  origin = "AMATEUR_BREEDER",
  circumstance = "BELIEVES_SECOND_CHANCES",
  description = "kept careful notes on Pokémon care and habits, believes second chances",
  money = 564,
  items = {
    POKE_BALL = 1,
    POTION = 2,
  },
  disposition = {
    player = 0.06,
    rival = 0.08,
    rocket = -0.08,
  },
  temper = "hopeful",
  personalityBias = {
    BREEDER = 0.1,
    MENTOR = 0.04,
  },
  pathBias = {
    BREEDER = 0.1,
    MENTOR_PATH = 0.04,
  },
  careerBias = {
    BREEDER = 0.09,
    MENTOR_PATH = 0.036,
  },
}, {
  id = "BG_091",
  origin = "AMATEUR_RESEARCHER",
  circumstance = "CHIP_ON_SHOULDER",
  description = "wanted answers more than applause, chip on shoulder",
  money = 480,
  items = {
    POKE_BALL = 1,
    REPEL = 1,
    POTION = 1,
  },
  disposition = {
    player = -0.15,
    rival = -0.05,
    rocket = -0.1,
  },
  temper = "hostile",
  personalityBias = {
    RESEARCHER = 0.1,
    SCHOLAR = 0.06,
  },
  pathBias = {
    RESEARCHER = 0.1,
    HISTORIAN = 0.06,
  },
  careerBias = {
    RESEARCHER = 0.09,
    HISTORIAN = 0.054,
  },
}, {
  id = "BG_092",
  origin = "AMATEUR_RESEARCHER",
  circumstance = "SHARES_SUPPLIES",
  description = "wanted answers more than applause, shares supplies",
  money = 572,
  items = {
    POKE_BALL = 1,
    REPEL = 1,
    POTION = 1,
  },
  disposition = {
    player = 0.08,
    rival = 0.12,
    rocket = -0.05,
  },
  temper = "kind",
  personalityBias = {
    RESEARCHER = 0.1,
    SCHOLAR = 0.06,
  },
  pathBias = {
    RESEARCHER = 0.1,
    HISTORIAN = 0.06,
  },
  careerBias = {
    RESEARCHER = 0.09,
    HISTORIAN = 0.054,
  },
}, {
  id = "BG_093",
  origin = "AMATEUR_RESEARCHER",
  circumstance = "TRUSTS_SLOWLY",
  description = "wanted answers more than applause, trusts slowly",
  money = 564,
  items = {
    POKE_BALL = 1,
    REPEL = 1,
    ANTIDOTE = 1,
  },
  disposition = {
    player = -0.05,
    rival = 0.0,
    rocket = -0.12,
  },
  temper = "guarded",
  personalityBias = {
    RESEARCHER = 0.1,
    SCHOLAR = 0.06,
  },
  pathBias = {
    RESEARCHER = 0.1,
    HISTORIAN = 0.06,
  },
  careerBias = {
    RESEARCHER = 0.09,
    HISTORIAN = 0.054,
  },
}, {
  id = "BG_094",
  origin = "AMATEUR_RESEARCHER",
  circumstance = "HATES_LOSING",
  description = "wanted answers more than applause, hates losing",
  money = 606,
  items = {
    POKE_BALL = 2,
    REPEL = 1,
  },
  disposition = {
    player = 0.0,
    rival = -0.1,
    rocket = -0.04,
  },
  temper = "competitive",
  personalityBias = {
    RESEARCHER = 0.1,
    SCHOLAR = 0.06,
  },
  pathBias = {
    RESEARCHER = 0.1,
    HISTORIAN = 0.06,
  },
  careerBias = {
    RESEARCHER = 0.09,
    HISTORIAN = 0.054,
  },
}, {
  id = "BG_095",
  origin = "AMATEUR_RESEARCHER",
  circumstance = "BELIEVES_SECOND_CHANCES",
  description = "wanted answers more than applause, believes second chances",
  money = 658,
  items = {
    POKE_BALL = 1,
    REPEL = 1,
    POTION = 1,
  },
  disposition = {
    player = 0.06,
    rival = 0.08,
    rocket = -0.08,
  },
  temper = "hopeful",
  personalityBias = {
    RESEARCHER = 0.1,
    SCHOLAR = 0.06,
  },
  pathBias = {
    RESEARCHER = 0.1,
    HISTORIAN = 0.06,
  },
  careerBias = {
    RESEARCHER = 0.09,
    HISTORIAN = 0.054,
  },
}, {
  id = "BG_096",
  origin = "MOUNTAIN_GUIDE",
  circumstance = "CHIP_ON_SHOULDER",
  description = "learned caution from difficult trails, chip on shoulder",
  money = 394,
  items = {
    POKE_BALL = 1,
    SUPER_POTION = 1,
    POTION = 1,
  },
  disposition = {
    player = -0.15,
    rival = -0.05,
    rocket = -0.1,
  },
  temper = "hostile",
  personalityBias = {
    SURVIVALIST = 0.1,
    EXPLORER = 0.06,
  },
  pathBias = {
    MOUNTAINEER = 0.1,
    EXPLORER = 0.06,
  },
  careerBias = {
    MOUNTAINEER = 0.09,
    EXPLORER = 0.054,
  },
}, {
  id = "BG_097",
  origin = "MOUNTAIN_GUIDE",
  circumstance = "SHARES_SUPPLIES",
  description = "learned caution from difficult trails, shares supplies",
  money = 486,
  items = {
    POKE_BALL = 1,
    SUPER_POTION = 1,
    POTION = 1,
  },
  disposition = {
    player = 0.08,
    rival = 0.12,
    rocket = -0.05,
  },
  temper = "kind",
  personalityBias = {
    SURVIVALIST = 0.1,
    EXPLORER = 0.06,
  },
  pathBias = {
    MOUNTAINEER = 0.1,
    EXPLORER = 0.06,
  },
  careerBias = {
    MOUNTAINEER = 0.09,
    EXPLORER = 0.054,
  },
}, {
  id = "BG_098",
  origin = "MOUNTAIN_GUIDE",
  circumstance = "TRUSTS_SLOWLY",
  description = "learned caution from difficult trails, trusts slowly",
  money = 478,
  items = {
    POKE_BALL = 1,
    SUPER_POTION = 1,
    ANTIDOTE = 1,
  },
  disposition = {
    player = -0.05,
    rival = 0.0,
    rocket = -0.12,
  },
  temper = "guarded",
  personalityBias = {
    SURVIVALIST = 0.1,
    EXPLORER = 0.06,
  },
  pathBias = {
    MOUNTAINEER = 0.1,
    EXPLORER = 0.06,
  },
  careerBias = {
    MOUNTAINEER = 0.09,
    EXPLORER = 0.054,
  },
}, {
  id = "BG_099",
  origin = "MOUNTAIN_GUIDE",
  circumstance = "HATES_LOSING",
  description = "learned caution from difficult trails, hates losing",
  money = 520,
  items = {
    POKE_BALL = 2,
    SUPER_POTION = 1,
  },
  disposition = {
    player = 0.0,
    rival = -0.1,
    rocket = -0.04,
  },
  temper = "competitive",
  personalityBias = {
    SURVIVALIST = 0.1,
    EXPLORER = 0.06,
  },
  pathBias = {
    MOUNTAINEER = 0.1,
    EXPLORER = 0.06,
  },
  careerBias = {
    MOUNTAINEER = 0.09,
    EXPLORER = 0.054,
  },
}, {
  id = "BG_100",
  origin = "MOUNTAIN_GUIDE",
  circumstance = "BELIEVES_SECOND_CHANCES",
  description = "learned caution from difficult trails, believes second chances",
  money = 572,
  items = {
    POKE_BALL = 1,
    SUPER_POTION = 1,
    POTION = 1,
  },
  disposition = {
    player = 0.06,
    rival = 0.08,
    rocket = -0.08,
  },
  temper = "hopeful",
  personalityBias = {
    SURVIVALIST = 0.1,
    EXPLORER = 0.06,
  },
  pathBias = {
    MOUNTAINEER = 0.1,
    EXPLORER = 0.06,
  },
  careerBias = {
    MOUNTAINEER = 0.09,
    EXPLORER = 0.054,
  },
}, {
  id = "BG_101",
  origin = "CAVE_GUIDE",
  circumstance = "CHIP_ON_SHOULDER",
  description = "learned to keep a cool head when the path disappears, chip on shoulder",
  money = 408,
  items = {
    POKE_BALL = 1,
    REPEL = 1,
    POTION = 1,
  },
  disposition = {
    player = -0.15,
    rival = -0.05,
    rocket = -0.1,
  },
  temper = "hostile",
  personalityBias = {
    SURVIVALIST = 0.1,
    EXPLORER = 0.04,
  },
  pathBias = {
    MOUNTAINEER = 0.1,
    EXPLORER = 0.04,
  },
  careerBias = {
    MOUNTAINEER = 0.09,
    EXPLORER = 0.036,
  },
}, {
  id = "BG_102",
  origin = "CAVE_GUIDE",
  circumstance = "SHARES_SUPPLIES",
  description = "learned to keep a cool head when the path disappears, shares supplies",
  money = 500,
  items = {
    POKE_BALL = 1,
    REPEL = 1,
    POTION = 1,
  },
  disposition = {
    player = 0.08,
    rival = 0.12,
    rocket = -0.05,
  },
  temper = "kind",
  personalityBias = {
    SURVIVALIST = 0.1,
    EXPLORER = 0.04,
  },
  pathBias = {
    MOUNTAINEER = 0.1,
    EXPLORER = 0.04,
  },
  careerBias = {
    MOUNTAINEER = 0.09,
    EXPLORER = 0.036,
  },
}, {
  id = "BG_103",
  origin = "CAVE_GUIDE",
  circumstance = "TRUSTS_SLOWLY",
  description = "learned to keep a cool head when the path disappears, trusts slowly",
  money = 492,
  items = {
    POKE_BALL = 1,
    REPEL = 1,
    ANTIDOTE = 1,
  },
  disposition = {
    player = -0.05,
    rival = 0.0,
    rocket = -0.12,
  },
  temper = "guarded",
  personalityBias = {
    SURVIVALIST = 0.1,
    EXPLORER = 0.04,
  },
  pathBias = {
    MOUNTAINEER = 0.1,
    EXPLORER = 0.04,
  },
  careerBias = {
    MOUNTAINEER = 0.09,
    EXPLORER = 0.036,
  },
}, {
  id = "BG_104",
  origin = "CAVE_GUIDE",
  circumstance = "HATES_LOSING",
  description = "learned to keep a cool head when the path disappears, hates losing",
  money = 534,
  items = {
    POKE_BALL = 2,
    REPEL = 1,
  },
  disposition = {
    player = 0.0,
    rival = -0.1,
    rocket = -0.04,
  },
  temper = "competitive",
  personalityBias = {
    SURVIVALIST = 0.1,
    EXPLORER = 0.04,
  },
  pathBias = {
    MOUNTAINEER = 0.1,
    EXPLORER = 0.04,
  },
  careerBias = {
    MOUNTAINEER = 0.09,
    EXPLORER = 0.036,
  },
}, {
  id = "BG_105",
  origin = "CAVE_GUIDE",
  circumstance = "BELIEVES_SECOND_CHANCES",
  description = "learned to keep a cool head when the path disappears, believes second chances",
  money = 424,
  items = {
    POKE_BALL = 1,
    REPEL = 1,
    POTION = 1,
  },
  disposition = {
    player = 0.06,
    rival = 0.08,
    rocket = -0.08,
  },
  temper = "hopeful",
  personalityBias = {
    SURVIVALIST = 0.1,
    EXPLORER = 0.04,
  },
  pathBias = {
    MOUNTAINEER = 0.1,
    EXPLORER = 0.04,
  },
  careerBias = {
    MOUNTAINEER = 0.09,
    EXPLORER = 0.036,
  },
}, {
  id = "BG_106",
  origin = "SAILOR_FAMILY",
  circumstance = "CHIP_ON_SHOULDER",
  description = "was raised on stories of distant ports, chip on shoulder",
  money = 502,
  items = {
    POKE_BALL = 1,
    ANTIDOTE = 1,
    POTION = 1,
  },
  disposition = {
    player = -0.15,
    rival = -0.05,
    rocket = -0.1,
  },
  temper = "hostile",
  personalityBias = {
    EXPLORER = 0.08,
    TRADER = 0.04,
  },
  pathBias = {
    EXPLORER = 0.08,
    TRADER = 0.04,
  },
  careerBias = {
    EXPLORER = 0.072,
    TRADER = 0.036,
  },
}, {
  id = "BG_107",
  origin = "SAILOR_FAMILY",
  circumstance = "SHARES_SUPPLIES",
  description = "was raised on stories of distant ports, shares supplies",
  money = 594,
  items = {
    POKE_BALL = 1,
    ANTIDOTE = 1,
    POTION = 1,
  },
  disposition = {
    player = 0.08,
    rival = 0.12,
    rocket = -0.05,
  },
  temper = "kind",
  personalityBias = {
    EXPLORER = 0.08,
    TRADER = 0.04,
  },
  pathBias = {
    EXPLORER = 0.08,
    TRADER = 0.04,
  },
  careerBias = {
    EXPLORER = 0.072,
    TRADER = 0.036,
  },
}, {
  id = "BG_108",
  origin = "SAILOR_FAMILY",
  circumstance = "TRUSTS_SLOWLY",
  description = "was raised on stories of distant ports, trusts slowly",
  money = 424,
  items = {
    POKE_BALL = 1,
    ANTIDOTE = 2,
  },
  disposition = {
    player = -0.05,
    rival = 0.0,
    rocket = -0.12,
  },
  temper = "guarded",
  personalityBias = {
    EXPLORER = 0.08,
    TRADER = 0.04,
  },
  pathBias = {
    EXPLORER = 0.08,
    TRADER = 0.04,
  },
  careerBias = {
    EXPLORER = 0.072,
    TRADER = 0.036,
  },
}, {
  id = "BG_109",
  origin = "SAILOR_FAMILY",
  circumstance = "HATES_LOSING",
  description = "was raised on stories of distant ports, hates losing",
  money = 466,
  items = {
    POKE_BALL = 2,
    ANTIDOTE = 1,
  },
  disposition = {
    player = 0.0,
    rival = -0.1,
    rocket = -0.04,
  },
  temper = "competitive",
  personalityBias = {
    EXPLORER = 0.08,
    TRADER = 0.04,
  },
  pathBias = {
    EXPLORER = 0.08,
    TRADER = 0.04,
  },
  careerBias = {
    EXPLORER = 0.072,
    TRADER = 0.036,
  },
}, {
  id = "BG_110",
  origin = "SAILOR_FAMILY",
  circumstance = "BELIEVES_SECOND_CHANCES",
  description = "was raised on stories of distant ports, believes second chances",
  money = 518,
  items = {
    POKE_BALL = 1,
    ANTIDOTE = 1,
    POTION = 1,
  },
  disposition = {
    player = 0.06,
    rival = 0.08,
    rocket = -0.08,
  },
  temper = "hopeful",
  personalityBias = {
    EXPLORER = 0.08,
    TRADER = 0.04,
  },
  pathBias = {
    EXPLORER = 0.08,
    TRADER = 0.04,
  },
  careerBias = {
    EXPLORER = 0.072,
    TRADER = 0.036,
  },
}, {
  id = "BG_111",
  origin = "FOSSIL_HUNTER",
  circumstance = "CHIP_ON_SHOULDER",
  description = "loved old mysteries and forgotten Pokémon, chip on shoulder",
  money = 656,
  items = {
    POKE_BALL = 1,
    REPEL = 1,
    POTION = 1,
  },
  disposition = {
    player = -0.15,
    rival = -0.05,
    rocket = -0.1,
  },
  temper = "hostile",
  personalityBias = {
    RESEARCHER = 0.08,
    COLLECTOR = 0.08,
  },
  pathBias = {
    RESEARCHER = 0.08,
    DEX_COMPLETIONIST = 0.08,
  },
  careerBias = {
    RESEARCHER = 0.072,
    DEX_COMPLETIONIST = 0.072,
  },
}, {
  id = "BG_112",
  origin = "FOSSIL_HUNTER",
  circumstance = "SHARES_SUPPLIES",
  description = "loved old mysteries and forgotten Pokémon, shares supplies",
  money = 586,
  items = {
    POKE_BALL = 1,
    REPEL = 1,
    POTION = 1,
  },
  disposition = {
    player = 0.08,
    rival = 0.12,
    rocket = -0.05,
  },
  temper = "kind",
  personalityBias = {
    RESEARCHER = 0.08,
    COLLECTOR = 0.08,
  },
  pathBias = {
    RESEARCHER = 0.08,
    DEX_COMPLETIONIST = 0.08,
  },
  careerBias = {
    RESEARCHER = 0.072,
    DEX_COMPLETIONIST = 0.072,
  },
}, {
  id = "BG_113",
  origin = "FOSSIL_HUNTER",
  circumstance = "TRUSTS_SLOWLY",
  description = "loved old mysteries and forgotten Pokémon, trusts slowly",
  money = 578,
  items = {
    POKE_BALL = 1,
    REPEL = 1,
    ANTIDOTE = 1,
  },
  disposition = {
    player = -0.05,
    rival = 0.0,
    rocket = -0.12,
  },
  temper = "guarded",
  personalityBias = {
    RESEARCHER = 0.08,
    COLLECTOR = 0.08,
  },
  pathBias = {
    RESEARCHER = 0.08,
    DEX_COMPLETIONIST = 0.08,
  },
  careerBias = {
    RESEARCHER = 0.072,
    DEX_COMPLETIONIST = 0.072,
  },
}, {
  id = "BG_114",
  origin = "FOSSIL_HUNTER",
  circumstance = "HATES_LOSING",
  description = "loved old mysteries and forgotten Pokémon, hates losing",
  money = 620,
  items = {
    POKE_BALL = 2,
    REPEL = 1,
  },
  disposition = {
    player = 0.0,
    rival = -0.1,
    rocket = -0.04,
  },
  temper = "competitive",
  personalityBias = {
    RESEARCHER = 0.08,
    COLLECTOR = 0.08,
  },
  pathBias = {
    RESEARCHER = 0.08,
    DEX_COMPLETIONIST = 0.08,
  },
  careerBias = {
    RESEARCHER = 0.072,
    DEX_COMPLETIONIST = 0.072,
  },
}, {
  id = "BG_115",
  origin = "FOSSIL_HUNTER",
  circumstance = "BELIEVES_SECOND_CHANCES",
  description = "loved old mysteries and forgotten Pokémon, believes second chances",
  money = 672,
  items = {
    POKE_BALL = 1,
    REPEL = 1,
    POTION = 1,
  },
  disposition = {
    player = 0.06,
    rival = 0.08,
    rocket = -0.08,
  },
  temper = "hopeful",
  personalityBias = {
    RESEARCHER = 0.08,
    COLLECTOR = 0.08,
  },
  pathBias = {
    RESEARCHER = 0.08,
    DEX_COMPLETIONIST = 0.08,
  },
  careerBias = {
    RESEARCHER = 0.072,
    DEX_COMPLETIONIST = 0.072,
  },
}, {
  id = "BG_116",
  origin = "PHOTOGRAPHER",
  circumstance = "CHIP_ON_SHOULDER",
  description = "learned to wait for the right moment, chip on shoulder",
  money = 338,
  items = {
    POKE_BALL = 1,
    REPEL = 1,
    POTION = 1,
  },
  disposition = {
    player = -0.15,
    rival = -0.05,
    rocket = -0.1,
  },
  temper = "hostile",
  personalityBias = {
    EXPLORER = 0.08,
    SCHOLAR = 0.04,
  },
  pathBias = {
    EXPLORER = 0.08,
    HISTORIAN = 0.04,
  },
  careerBias = {
    EXPLORER = 0.072,
    HISTORIAN = 0.036,
  },
}, {
  id = "BG_117",
  origin = "PHOTOGRAPHER",
  circumstance = "SHARES_SUPPLIES",
  description = "learned to wait for the right moment, shares supplies",
  money = 430,
  items = {
    POKE_BALL = 1,
    REPEL = 1,
    POTION = 1,
  },
  disposition = {
    player = 0.08,
    rival = 0.12,
    rocket = -0.05,
  },
  temper = "kind",
  personalityBias = {
    EXPLORER = 0.08,
    SCHOLAR = 0.04,
  },
  pathBias = {
    EXPLORER = 0.08,
    HISTORIAN = 0.04,
  },
  careerBias = {
    EXPLORER = 0.072,
    HISTORIAN = 0.036,
  },
}, {
  id = "BG_118",
  origin = "PHOTOGRAPHER",
  circumstance = "TRUSTS_SLOWLY",
  description = "learned to wait for the right moment, trusts slowly",
  money = 422,
  items = {
    POKE_BALL = 1,
    REPEL = 1,
    ANTIDOTE = 1,
  },
  disposition = {
    player = -0.05,
    rival = 0.0,
    rocket = -0.12,
  },
  temper = "guarded",
  personalityBias = {
    EXPLORER = 0.08,
    SCHOLAR = 0.04,
  },
  pathBias = {
    EXPLORER = 0.08,
    HISTORIAN = 0.04,
  },
  careerBias = {
    EXPLORER = 0.072,
    HISTORIAN = 0.036,
  },
}, {
  id = "BG_119",
  origin = "PHOTOGRAPHER",
  circumstance = "HATES_LOSING",
  description = "learned to wait for the right moment, hates losing",
  money = 464,
  items = {
    POKE_BALL = 2,
    REPEL = 1,
  },
  disposition = {
    player = 0.0,
    rival = -0.1,
    rocket = -0.04,
  },
  temper = "competitive",
  personalityBias = {
    EXPLORER = 0.08,
    SCHOLAR = 0.04,
  },
  pathBias = {
    EXPLORER = 0.08,
    HISTORIAN = 0.04,
  },
  careerBias = {
    EXPLORER = 0.072,
    HISTORIAN = 0.036,
  },
}, {
  id = "BG_120",
  origin = "PHOTOGRAPHER",
  circumstance = "BELIEVES_SECOND_CHANCES",
  description = "learned to wait for the right moment, believes second chances",
  money = 516,
  items = {
    POKE_BALL = 1,
    REPEL = 1,
    POTION = 1,
  },
  disposition = {
    player = 0.06,
    rival = 0.08,
    rocket = -0.08,
  },
  temper = "hopeful",
  personalityBias = {
    EXPLORER = 0.08,
    SCHOLAR = 0.04,
  },
  pathBias = {
    EXPLORER = 0.08,
    HISTORIAN = 0.04,
  },
  careerBias = {
    EXPLORER = 0.072,
    HISTORIAN = 0.036,
  },
}, {
  id = "BG_121",
  origin = "STREET_BATTLER",
  circumstance = "CHIP_ON_SHOULDER",
  description = "learned competition before learning formal etiquette, chip on shoulder",
  money = 222,
  items = {
    POKE_BALL = 1,
    POTION = 2,
  },
  disposition = {
    player = -0.15,
    rival = -0.05,
    rocket = -0.1,
  },
  temper = "hostile",
  personalityBias = {
    CHALLENGER = 0.1,
    ACE = 0.06,
  },
  pathBias = {
    SWORN_RIVAL = 0.1,
    ELITE_ASPIRANT = 0.06,
  },
  careerBias = {
    SWORN_RIVAL = 0.09,
    ELITE_ASPIRANT = 0.054,
  },
}, {
  id = "BG_122",
  origin = "STREET_BATTLER",
  circumstance = "SHARES_SUPPLIES",
  description = "learned competition before learning formal etiquette, shares supplies",
  money = 314,
  items = {
    POKE_BALL = 1,
    POTION = 2,
  },
  disposition = {
    player = 0.08,
    rival = 0.12,
    rocket = -0.05,
  },
  temper = "kind",
  personalityBias = {
    CHALLENGER = 0.1,
    ACE = 0.06,
  },
  pathBias = {
    SWORN_RIVAL = 0.1,
    ELITE_ASPIRANT = 0.06,
  },
  careerBias = {
    SWORN_RIVAL = 0.09,
    ELITE_ASPIRANT = 0.054,
  },
}, {
  id = "BG_123",
  origin = "STREET_BATTLER",
  circumstance = "TRUSTS_SLOWLY",
  description = "learned competition before learning formal etiquette, trusts slowly",
  money = 306,
  items = {
    POKE_BALL = 1,
    POTION = 1,
    ANTIDOTE = 1,
  },
  disposition = {
    player = -0.05,
    rival = 0.0,
    rocket = -0.12,
  },
  temper = "guarded",
  personalityBias = {
    CHALLENGER = 0.1,
    ACE = 0.06,
  },
  pathBias = {
    SWORN_RIVAL = 0.1,
    ELITE_ASPIRANT = 0.06,
  },
  careerBias = {
    SWORN_RIVAL = 0.09,
    ELITE_ASPIRANT = 0.054,
  },
}, {
  id = "BG_124",
  origin = "STREET_BATTLER",
  circumstance = "HATES_LOSING",
  description = "learned competition before learning formal etiquette, hates losing",
  money = 348,
  items = {
    POKE_BALL = 2,
    POTION = 1,
  },
  disposition = {
    player = 0.0,
    rival = -0.1,
    rocket = -0.04,
  },
  temper = "competitive",
  personalityBias = {
    CHALLENGER = 0.1,
    ACE = 0.06,
  },
  pathBias = {
    SWORN_RIVAL = 0.1,
    ELITE_ASPIRANT = 0.06,
  },
  careerBias = {
    SWORN_RIVAL = 0.09,
    ELITE_ASPIRANT = 0.054,
  },
}, {
  id = "BG_125",
  origin = "STREET_BATTLER",
  circumstance = "BELIEVES_SECOND_CHANCES",
  description = "learned competition before learning formal etiquette, believes second chances",
  money = 400,
  items = {
    POKE_BALL = 1,
    POTION = 2,
  },
  disposition = {
    player = 0.06,
    rival = 0.08,
    rocket = -0.08,
  },
  temper = "hopeful",
  personalityBias = {
    CHALLENGER = 0.1,
    ACE = 0.06,
  },
  pathBias = {
    SWORN_RIVAL = 0.1,
    ELITE_ASPIRANT = 0.06,
  },
  careerBias = {
    SWORN_RIVAL = 0.09,
    ELITE_ASPIRANT = 0.054,
  },
}, {
  id = "BG_126",
  origin = "RUNAWAY_HEIRESS",
  circumstance = "CHIP_ON_SHOULDER",
  description = "left a sheltered life to prove they could stand alone, chip on shoulder",
  money = 876,
  items = {
    GREAT_BALL = 1,
    SUPER_POTION = 1,
    POTION = 1,
  },
  disposition = {
    player = -0.15,
    rival = -0.05,
    rocket = -0.1,
  },
  temper = "hostile",
  personalityBias = {
    EXPLORER = 0.06,
    CHALLENGER = 0.06,
  },
  pathBias = {
    EXPLORER = 0.06,
    SWORN_RIVAL = 0.06,
  },
  careerBias = {
    EXPLORER = 0.054,
    SWORN_RIVAL = 0.054,
  },
}, {
  id = "BG_127",
  origin = "RUNAWAY_HEIRESS",
  circumstance = "SHARES_SUPPLIES",
  description = "left a sheltered life to prove they could stand alone, shares supplies",
  money = 968,
  items = {
    GREAT_BALL = 1,
    SUPER_POTION = 1,
    POTION = 1,
  },
  disposition = {
    player = 0.08,
    rival = 0.12,
    rocket = -0.05,
  },
  temper = "kind",
  personalityBias = {
    EXPLORER = 0.06,
    CHALLENGER = 0.06,
  },
  pathBias = {
    EXPLORER = 0.06,
    SWORN_RIVAL = 0.06,
  },
  careerBias = {
    EXPLORER = 0.054,
    SWORN_RIVAL = 0.054,
  },
}, {
  id = "BG_128",
  origin = "RUNAWAY_HEIRESS",
  circumstance = "TRUSTS_SLOWLY",
  description = "left a sheltered life to prove they could stand alone, trusts slowly",
  money = 960,
  items = {
    GREAT_BALL = 1,
    SUPER_POTION = 1,
    ANTIDOTE = 1,
  },
  disposition = {
    player = -0.05,
    rival = 0.0,
    rocket = -0.12,
  },
  temper = "guarded",
  personalityBias = {
    EXPLORER = 0.06,
    CHALLENGER = 0.06,
  },
  pathBias = {
    EXPLORER = 0.06,
    SWORN_RIVAL = 0.06,
  },
  careerBias = {
    EXPLORER = 0.054,
    SWORN_RIVAL = 0.054,
  },
}, {
  id = "BG_129",
  origin = "RUNAWAY_HEIRESS",
  circumstance = "HATES_LOSING",
  description = "left a sheltered life to prove they could stand alone, hates losing",
  money = 840,
  items = {
    GREAT_BALL = 1,
    SUPER_POTION = 1,
    POKE_BALL = 1,
  },
  disposition = {
    player = 0.0,
    rival = -0.1,
    rocket = -0.04,
  },
  temper = "competitive",
  personalityBias = {
    EXPLORER = 0.06,
    CHALLENGER = 0.06,
  },
  pathBias = {
    EXPLORER = 0.06,
    SWORN_RIVAL = 0.06,
  },
  careerBias = {
    EXPLORER = 0.054,
    SWORN_RIVAL = 0.054,
  },
}, {
  id = "BG_130",
  origin = "RUNAWAY_HEIRESS",
  circumstance = "BELIEVES_SECOND_CHANCES",
  description = "left a sheltered life to prove they could stand alone, believes second chances",
  money = 892,
  items = {
    GREAT_BALL = 1,
    SUPER_POTION = 1,
    POTION = 1,
  },
  disposition = {
    player = 0.06,
    rival = 0.08,
    rocket = -0.08,
  },
  temper = "hopeful",
  personalityBias = {
    EXPLORER = 0.06,
    CHALLENGER = 0.06,
  },
  pathBias = {
    EXPLORER = 0.06,
    SWORN_RIVAL = 0.06,
  },
  careerBias = {
    EXPLORER = 0.054,
    SWORN_RIVAL = 0.054,
  },
}, {
  id = "BG_131",
  origin = "ORPHANED_TRAINER",
  circumstance = "CHIP_ON_SHOULDER",
  description = "learned to rely on chosen friends, chip on shoulder",
  money = 210,
  items = {
    POKE_BALL = 1,
    POTION = 2,
  },
  disposition = {
    player = -0.15,
    rival = -0.05,
    rocket = -0.1,
  },
  temper = "hostile",
  personalityBias = {
    PROTECTOR = 0.1,
    MENTOR = 0.04,
  },
  pathBias = {
    PROTECTOR = 0.1,
    MENTOR_PATH = 0.04,
  },
  careerBias = {
    PROTECTOR = 0.09,
    MENTOR_PATH = 0.036,
  },
}, {
  id = "BG_132",
  origin = "ORPHANED_TRAINER",
  circumstance = "SHARES_SUPPLIES",
  description = "learned to rely on chosen friends, shares supplies",
  money = 302,
  items = {
    POKE_BALL = 1,
    POTION = 2,
  },
  disposition = {
    player = 0.08,
    rival = 0.12,
    rocket = -0.05,
  },
  temper = "kind",
  personalityBias = {
    PROTECTOR = 0.1,
    MENTOR = 0.04,
  },
  pathBias = {
    PROTECTOR = 0.1,
    MENTOR_PATH = 0.04,
  },
  careerBias = {
    PROTECTOR = 0.09,
    MENTOR_PATH = 0.036,
  },
}, {
  id = "BG_133",
  origin = "ORPHANED_TRAINER",
  circumstance = "TRUSTS_SLOWLY",
  description = "learned to rely on chosen friends, trusts slowly",
  money = 132,
  items = {
    POKE_BALL = 1,
    POTION = 1,
    ANTIDOTE = 1,
  },
  disposition = {
    player = -0.05,
    rival = 0.0,
    rocket = -0.12,
  },
  temper = "guarded",
  personalityBias = {
    PROTECTOR = 0.1,
    MENTOR = 0.04,
  },
  pathBias = {
    PROTECTOR = 0.1,
    MENTOR_PATH = 0.04,
  },
  careerBias = {
    PROTECTOR = 0.09,
    MENTOR_PATH = 0.036,
  },
}, {
  id = "BG_134",
  origin = "ORPHANED_TRAINER",
  circumstance = "HATES_LOSING",
  description = "learned to rely on chosen friends, hates losing",
  money = 174,
  items = {
    POKE_BALL = 2,
    POTION = 1,
  },
  disposition = {
    player = 0.0,
    rival = -0.1,
    rocket = -0.04,
  },
  temper = "competitive",
  personalityBias = {
    PROTECTOR = 0.1,
    MENTOR = 0.04,
  },
  pathBias = {
    PROTECTOR = 0.1,
    MENTOR_PATH = 0.04,
  },
  careerBias = {
    PROTECTOR = 0.09,
    MENTOR_PATH = 0.036,
  },
}, {
  id = "BG_135",
  origin = "ORPHANED_TRAINER",
  circumstance = "BELIEVES_SECOND_CHANCES",
  description = "learned to rely on chosen friends, believes second chances",
  money = 226,
  items = {
    POKE_BALL = 1,
    POTION = 2,
  },
  disposition = {
    player = 0.06,
    rival = 0.08,
    rocket = -0.08,
  },
  temper = "hopeful",
  personalityBias = {
    PROTECTOR = 0.1,
    MENTOR = 0.04,
  },
  pathBias = {
    PROTECTOR = 0.1,
    MENTOR_PATH = 0.04,
  },
  careerBias = {
    PROTECTOR = 0.09,
    MENTOR_PATH = 0.036,
  },
}, {
  id = "BG_136",
  origin = "LOCAL_HERO",
  circumstance = "CHIP_ON_SHOULDER",
  description = "once helped their town through a small crisis, chip on shoulder",
  money = 332,
  items = {
    POKE_BALL = 1,
    SUPER_POTION = 1,
    POTION = 1,
  },
  disposition = {
    player = -0.15,
    rival = -0.05,
    rocket = -0.1,
  },
  temper = "hostile",
  personalityBias = {
    PROTECTOR = 0.1,
    MENTOR = 0.06,
  },
  pathBias = {
    PROTECTOR = 0.1,
    MENTOR_PATH = 0.06,
  },
  careerBias = {
    PROTECTOR = 0.09,
    MENTOR_PATH = 0.054,
  },
}, {
  id = "BG_137",
  origin = "LOCAL_HERO",
  circumstance = "SHARES_SUPPLIES",
  description = "once helped their town through a small crisis, shares supplies",
  money = 424,
  items = {
    POKE_BALL = 1,
    SUPER_POTION = 1,
    POTION = 1,
  },
  disposition = {
    player = 0.08,
    rival = 0.12,
    rocket = -0.05,
  },
  temper = "kind",
  personalityBias = {
    PROTECTOR = 0.1,
    MENTOR = 0.06,
  },
  pathBias = {
    PROTECTOR = 0.1,
    MENTOR_PATH = 0.06,
  },
  careerBias = {
    PROTECTOR = 0.09,
    MENTOR_PATH = 0.054,
  },
}, {
  id = "BG_138",
  origin = "LOCAL_HERO",
  circumstance = "TRUSTS_SLOWLY",
  description = "once helped their town through a small crisis, trusts slowly",
  money = 416,
  items = {
    POKE_BALL = 1,
    SUPER_POTION = 1,
    ANTIDOTE = 1,
  },
  disposition = {
    player = -0.05,
    rival = 0.0,
    rocket = -0.12,
  },
  temper = "guarded",
  personalityBias = {
    PROTECTOR = 0.1,
    MENTOR = 0.06,
  },
  pathBias = {
    PROTECTOR = 0.1,
    MENTOR_PATH = 0.06,
  },
  careerBias = {
    PROTECTOR = 0.09,
    MENTOR_PATH = 0.054,
  },
}, {
  id = "BG_139",
  origin = "LOCAL_HERO",
  circumstance = "HATES_LOSING",
  description = "once helped their town through a small crisis, hates losing",
  money = 458,
  items = {
    POKE_BALL = 2,
    SUPER_POTION = 1,
  },
  disposition = {
    player = 0.0,
    rival = -0.1,
    rocket = -0.04,
  },
  temper = "competitive",
  personalityBias = {
    PROTECTOR = 0.1,
    MENTOR = 0.06,
  },
  pathBias = {
    PROTECTOR = 0.1,
    MENTOR_PATH = 0.06,
  },
  careerBias = {
    PROTECTOR = 0.09,
    MENTOR_PATH = 0.054,
  },
}, {
  id = "BG_140",
  origin = "LOCAL_HERO",
  circumstance = "BELIEVES_SECOND_CHANCES",
  description = "once helped their town through a small crisis, believes second chances",
  money = 510,
  items = {
    POKE_BALL = 1,
    SUPER_POTION = 1,
    POTION = 1,
  },
  disposition = {
    player = 0.06,
    rival = 0.08,
    rocket = -0.08,
  },
  temper = "hopeful",
  personalityBias = {
    PROTECTOR = 0.1,
    MENTOR = 0.06,
  },
  pathBias = {
    PROTECTOR = 0.1,
    MENTOR_PATH = 0.06,
  },
  careerBias = {
    PROTECTOR = 0.09,
    MENTOR_PATH = 0.054,
  },
}, {
  id = "BG_141",
  origin = "FORMER_BULLY",
  circumstance = "CHIP_ON_SHOULDER",
  description = "is trying to become someone better than their old reputation, chip on shoulder",
  money = 216,
  items = {
    POKE_BALL = 1,
    POTION = 2,
  },
  disposition = {
    player = -0.15,
    rival = -0.05,
    rocket = -0.1,
  },
  temper = "hostile",
  personalityBias = {
    REDEEMED = 0.1,
    CHALLENGER = 0.04,
  },
  pathBias = {
    ROCKET_DEFECTOR = 0.1,
    SWORN_RIVAL = 0.04,
  },
  careerBias = {
    ROCKET_DEFECTOR = 0.09,
    SWORN_RIVAL = 0.036,
  },
}, {
  id = "BG_142",
  origin = "FORMER_BULLY",
  circumstance = "SHARES_SUPPLIES",
  description = "is trying to become someone better than their old reputation, shares supplies",
  money = 308,
  items = {
    POKE_BALL = 1,
    POTION = 2,
  },
  disposition = {
    player = 0.08,
    rival = 0.12,
    rocket = -0.05,
  },
  temper = "kind",
  personalityBias = {
    REDEEMED = 0.1,
    CHALLENGER = 0.04,
  },
  pathBias = {
    ROCKET_DEFECTOR = 0.1,
    SWORN_RIVAL = 0.04,
  },
  careerBias = {
    ROCKET_DEFECTOR = 0.09,
    SWORN_RIVAL = 0.036,
  },
}, {
  id = "BG_143",
  origin = "FORMER_BULLY",
  circumstance = "TRUSTS_SLOWLY",
  description = "is trying to become someone better than their old reputation, trusts slowly",
  money = 300,
  items = {
    POKE_BALL = 1,
    POTION = 1,
    ANTIDOTE = 1,
  },
  disposition = {
    player = -0.05,
    rival = 0.0,
    rocket = -0.12,
  },
  temper = "guarded",
  personalityBias = {
    REDEEMED = 0.1,
    CHALLENGER = 0.04,
  },
  pathBias = {
    ROCKET_DEFECTOR = 0.1,
    SWORN_RIVAL = 0.04,
  },
  careerBias = {
    ROCKET_DEFECTOR = 0.09,
    SWORN_RIVAL = 0.036,
  },
}, {
  id = "BG_144",
  origin = "FORMER_BULLY",
  circumstance = "HATES_LOSING",
  description = "is trying to become someone better than their old reputation, hates losing",
  money = 342,
  items = {
    POKE_BALL = 2,
    POTION = 1,
  },
  disposition = {
    player = 0.0,
    rival = -0.1,
    rocket = -0.04,
  },
  temper = "competitive",
  personalityBias = {
    REDEEMED = 0.1,
    CHALLENGER = 0.04,
  },
  pathBias = {
    ROCKET_DEFECTOR = 0.1,
    SWORN_RIVAL = 0.04,
  },
  careerBias = {
    ROCKET_DEFECTOR = 0.09,
    SWORN_RIVAL = 0.036,
  },
}, {
  id = "BG_145",
  origin = "FORMER_BULLY",
  circumstance = "BELIEVES_SECOND_CHANCES",
  description = "is trying to become someone better than their old reputation, believes second chances",
  money = 394,
  items = {
    POKE_BALL = 1,
    POTION = 2,
  },
  disposition = {
    player = 0.06,
    rival = 0.08,
    rocket = -0.08,
  },
  temper = "hopeful",
  personalityBias = {
    REDEEMED = 0.1,
    CHALLENGER = 0.04,
  },
  pathBias = {
    ROCKET_DEFECTOR = 0.1,
    SWORN_RIVAL = 0.04,
  },
  careerBias = {
    ROCKET_DEFECTOR = 0.09,
    SWORN_RIVAL = 0.036,
  },
}, {
  id = "BG_146",
  origin = "FORMER_VICTIM",
  circumstance = "CHIP_ON_SHOULDER",
  description = "learned to recognize unfairness quickly, chip on shoulder",
  money = 210,
  items = {
    POKE_BALL = 1,
    ANTIDOTE = 1,
    POTION = 1,
  },
  disposition = {
    player = -0.15,
    rival = -0.05,
    rocket = -0.1,
  },
  temper = "hostile",
  personalityBias = {
    AVENGER = 0.08,
    PROTECTOR = 0.06,
  },
  pathBias = {
    AVENGER = 0.08,
    PROTECTOR = 0.06,
  },
  careerBias = {
    AVENGER = 0.072,
    PROTECTOR = 0.054,
  },
}, {
  id = "BG_147",
  origin = "FORMER_VICTIM",
  circumstance = "SHARES_SUPPLIES",
  description = "learned to recognize unfairness quickly, shares supplies",
  money = 302,
  items = {
    POKE_BALL = 1,
    ANTIDOTE = 1,
    POTION = 1,
  },
  disposition = {
    player = 0.08,
    rival = 0.12,
    rocket = -0.05,
  },
  temper = "kind",
  personalityBias = {
    AVENGER = 0.08,
    PROTECTOR = 0.06,
  },
  pathBias = {
    AVENGER = 0.08,
    PROTECTOR = 0.06,
  },
  careerBias = {
    AVENGER = 0.072,
    PROTECTOR = 0.054,
  },
}, {
  id = "BG_148",
  origin = "FORMER_VICTIM",
  circumstance = "TRUSTS_SLOWLY",
  description = "learned to recognize unfairness quickly, trusts slowly",
  money = 294,
  items = {
    POKE_BALL = 1,
    ANTIDOTE = 2,
  },
  disposition = {
    player = -0.05,
    rival = 0.0,
    rocket = -0.12,
  },
  temper = "guarded",
  personalityBias = {
    AVENGER = 0.08,
    PROTECTOR = 0.06,
  },
  pathBias = {
    AVENGER = 0.08,
    PROTECTOR = 0.06,
  },
  careerBias = {
    AVENGER = 0.072,
    PROTECTOR = 0.054,
  },
}, {
  id = "BG_149",
  origin = "FORMER_VICTIM",
  circumstance = "HATES_LOSING",
  description = "learned to recognize unfairness quickly, hates losing",
  money = 336,
  items = {
    POKE_BALL = 2,
    ANTIDOTE = 1,
  },
  disposition = {
    player = 0.0,
    rival = -0.1,
    rocket = -0.04,
  },
  temper = "competitive",
  personalityBias = {
    AVENGER = 0.08,
    PROTECTOR = 0.06,
  },
  pathBias = {
    AVENGER = 0.08,
    PROTECTOR = 0.06,
  },
  careerBias = {
    AVENGER = 0.072,
    PROTECTOR = 0.054,
  },
}, {
  id = "BG_150",
  origin = "FORMER_VICTIM",
  circumstance = "BELIEVES_SECOND_CHANCES",
  description = "learned to recognize unfairness quickly, believes second chances",
  money = 388,
  items = {
    POKE_BALL = 1,
    ANTIDOTE = 1,
    POTION = 1,
  },
  disposition = {
    player = 0.06,
    rival = 0.08,
    rocket = -0.08,
  },
  temper = "hopeful",
  personalityBias = {
    AVENGER = 0.08,
    PROTECTOR = 0.06,
  },
  pathBias = {
    AVENGER = 0.08,
    PROTECTOR = 0.06,
  },
  careerBias = {
    AVENGER = 0.072,
    PROTECTOR = 0.054,
  },
}, {
  id = "BG_151",
  origin = "ASPIRING_ACTOR",
  circumstance = "CHIP_ON_SHOULDER",
  description = "dreams of being remembered for something remarkable, chip on shoulder",
  money = 584,
  items = {
    POKE_BALL = 1,
    AWAKENING = 1,
    POTION = 1,
  },
  disposition = {
    player = -0.15,
    rival = -0.05,
    rocket = -0.1,
  },
  temper = "hostile",
  personalityBias = {
    SHOWBOAT = 0.1,
    CHALLENGER = 0.04,
  },
  pathBias = {
    PERFORMER = 0.1,
    SWORN_RIVAL = 0.04,
  },
  careerBias = {
    PERFORMER = 0.09,
    SWORN_RIVAL = 0.036,
  },
}, {
  id = "BG_152",
  origin = "ASPIRING_ACTOR",
  circumstance = "SHARES_SUPPLIES",
  description = "dreams of being remembered for something remarkable, shares supplies",
  money = 676,
  items = {
    POKE_BALL = 1,
    AWAKENING = 1,
    POTION = 1,
  },
  disposition = {
    player = 0.08,
    rival = 0.12,
    rocket = -0.05,
  },
  temper = "kind",
  personalityBias = {
    SHOWBOAT = 0.1,
    CHALLENGER = 0.04,
  },
  pathBias = {
    PERFORMER = 0.1,
    SWORN_RIVAL = 0.04,
  },
  careerBias = {
    PERFORMER = 0.09,
    SWORN_RIVAL = 0.036,
  },
}, {
  id = "BG_153",
  origin = "ASPIRING_ACTOR",
  circumstance = "TRUSTS_SLOWLY",
  description = "dreams of being remembered for something remarkable, trusts slowly",
  money = 668,
  items = {
    POKE_BALL = 1,
    AWAKENING = 1,
    ANTIDOTE = 1,
  },
  disposition = {
    player = -0.05,
    rival = 0.0,
    rocket = -0.12,
  },
  temper = "guarded",
  personalityBias = {
    SHOWBOAT = 0.1,
    CHALLENGER = 0.04,
  },
  pathBias = {
    PERFORMER = 0.1,
    SWORN_RIVAL = 0.04,
  },
  careerBias = {
    PERFORMER = 0.09,
    SWORN_RIVAL = 0.036,
  },
}, {
  id = "BG_154",
  origin = "ASPIRING_ACTOR",
  circumstance = "HATES_LOSING",
  description = "dreams of being remembered for something remarkable, hates losing",
  money = 548,
  items = {
    POKE_BALL = 2,
    AWAKENING = 1,
  },
  disposition = {
    player = 0.0,
    rival = -0.1,
    rocket = -0.04,
  },
  temper = "competitive",
  personalityBias = {
    SHOWBOAT = 0.1,
    CHALLENGER = 0.04,
  },
  pathBias = {
    PERFORMER = 0.1,
    SWORN_RIVAL = 0.04,
  },
  careerBias = {
    PERFORMER = 0.09,
    SWORN_RIVAL = 0.036,
  },
}, {
  id = "BG_155",
  origin = "ASPIRING_ACTOR",
  circumstance = "BELIEVES_SECOND_CHANCES",
  description = "dreams of being remembered for something remarkable, believes second chances",
  money = 600,
  items = {
    POKE_BALL = 1,
    AWAKENING = 1,
    POTION = 1,
  },
  disposition = {
    player = 0.06,
    rival = 0.08,
    rocket = -0.08,
  },
  temper = "hopeful",
  personalityBias = {
    SHOWBOAT = 0.1,
    CHALLENGER = 0.04,
  },
  pathBias = {
    PERFORMER = 0.1,
    SWORN_RIVAL = 0.04,
  },
  careerBias = {
    PERFORMER = 0.09,
    SWORN_RIVAL = 0.036,
  },
}, {
  id = "BG_156",
  origin = "MUSICIAN",
  circumstance = "CHIP_ON_SHOULDER",
  description = "learned discipline through endless rehearsal, chip on shoulder",
  money = 488,
  items = {
    POKE_BALL = 1,
    POTION = 2,
  },
  disposition = {
    player = -0.15,
    rival = -0.05,
    rocket = -0.1,
  },
  temper = "hostile",
  personalityBias = {
    MENTOR = 0.06,
    SHOWBOAT = 0.04,
  },
  pathBias = {
    MENTOR_PATH = 0.06,
    PERFORMER = 0.04,
  },
  careerBias = {
    MENTOR_PATH = 0.054,
    PERFORMER = 0.036,
  },
}, {
  id = "BG_157",
  origin = "MUSICIAN",
  circumstance = "SHARES_SUPPLIES",
  description = "learned discipline through endless rehearsal, shares supplies",
  money = 580,
  items = {
    POKE_BALL = 1,
    POTION = 2,
  },
  disposition = {
    player = 0.08,
    rival = 0.12,
    rocket = -0.05,
  },
  temper = "kind",
  personalityBias = {
    MENTOR = 0.06,
    SHOWBOAT = 0.04,
  },
  pathBias = {
    MENTOR_PATH = 0.06,
    PERFORMER = 0.04,
  },
  careerBias = {
    MENTOR_PATH = 0.054,
    PERFORMER = 0.036,
  },
}, {
  id = "BG_158",
  origin = "MUSICIAN",
  circumstance = "TRUSTS_SLOWLY",
  description = "learned discipline through endless rehearsal, trusts slowly",
  money = 410,
  items = {
    POKE_BALL = 1,
    POTION = 1,
    ANTIDOTE = 1,
  },
  disposition = {
    player = -0.05,
    rival = 0.0,
    rocket = -0.12,
  },
  temper = "guarded",
  personalityBias = {
    MENTOR = 0.06,
    SHOWBOAT = 0.04,
  },
  pathBias = {
    MENTOR_PATH = 0.06,
    PERFORMER = 0.04,
  },
  careerBias = {
    MENTOR_PATH = 0.054,
    PERFORMER = 0.036,
  },
}, {
  id = "BG_159",
  origin = "MUSICIAN",
  circumstance = "HATES_LOSING",
  description = "learned discipline through endless rehearsal, hates losing",
  money = 452,
  items = {
    POKE_BALL = 2,
    POTION = 1,
  },
  disposition = {
    player = 0.0,
    rival = -0.1,
    rocket = -0.04,
  },
  temper = "competitive",
  personalityBias = {
    MENTOR = 0.06,
    SHOWBOAT = 0.04,
  },
  pathBias = {
    MENTOR_PATH = 0.06,
    PERFORMER = 0.04,
  },
  careerBias = {
    MENTOR_PATH = 0.054,
    PERFORMER = 0.036,
  },
}, {
  id = "BG_160",
  origin = "MUSICIAN",
  circumstance = "BELIEVES_SECOND_CHANCES",
  description = "learned discipline through endless rehearsal, believes second chances",
  money = 504,
  items = {
    POKE_BALL = 1,
    POTION = 2,
  },
  disposition = {
    player = 0.06,
    rival = 0.08,
    rocket = -0.08,
  },
  temper = "hopeful",
  personalityBias = {
    MENTOR = 0.06,
    SHOWBOAT = 0.04,
  },
  pathBias = {
    MENTOR_PATH = 0.06,
    PERFORMER = 0.04,
  },
  careerBias = {
    MENTOR_PATH = 0.054,
    PERFORMER = 0.036,
  },
}, {
  id = "BG_161",
  origin = "CRAFT_WORKER",
  circumstance = "CHIP_ON_SHOULDER",
  description = "takes pride in improving something one step at a time, chip on shoulder",
  money = 280,
  items = {
    POKE_BALL = 1,
    POTION = 2,
  },
  disposition = {
    player = -0.15,
    rival = -0.05,
    rocket = -0.1,
  },
  temper = "hostile",
  personalityBias = {
    SCHOLAR = 0.06,
    TRADER = 0.04,
  },
  pathBias = {
    HISTORIAN = 0.06,
    TRADER = 0.04,
  },
  careerBias = {
    HISTORIAN = 0.054,
    TRADER = 0.036,
  },
}, {
  id = "BG_162",
  origin = "CRAFT_WORKER",
  circumstance = "SHARES_SUPPLIES",
  description = "takes pride in improving something one step at a time, shares supplies",
  money = 372,
  items = {
    POKE_BALL = 1,
    POTION = 2,
  },
  disposition = {
    player = 0.08,
    rival = 0.12,
    rocket = -0.05,
  },
  temper = "kind",
  personalityBias = {
    SCHOLAR = 0.06,
    TRADER = 0.04,
  },
  pathBias = {
    HISTORIAN = 0.06,
    TRADER = 0.04,
  },
  careerBias = {
    HISTORIAN = 0.054,
    TRADER = 0.036,
  },
}, {
  id = "BG_163",
  origin = "CRAFT_WORKER",
  circumstance = "TRUSTS_SLOWLY",
  description = "takes pride in improving something one step at a time, trusts slowly",
  money = 364,
  items = {
    POKE_BALL = 1,
    POTION = 1,
    ANTIDOTE = 1,
  },
  disposition = {
    player = -0.05,
    rival = 0.0,
    rocket = -0.12,
  },
  temper = "guarded",
  personalityBias = {
    SCHOLAR = 0.06,
    TRADER = 0.04,
  },
  pathBias = {
    HISTORIAN = 0.06,
    TRADER = 0.04,
  },
  careerBias = {
    HISTORIAN = 0.054,
    TRADER = 0.036,
  },
}, {
  id = "BG_164",
  origin = "CRAFT_WORKER",
  circumstance = "HATES_LOSING",
  description = "takes pride in improving something one step at a time, hates losing",
  money = 406,
  items = {
    POKE_BALL = 2,
    POTION = 1,
  },
  disposition = {
    player = 0.0,
    rival = -0.1,
    rocket = -0.04,
  },
  temper = "competitive",
  personalityBias = {
    SCHOLAR = 0.06,
    TRADER = 0.04,
  },
  pathBias = {
    HISTORIAN = 0.06,
    TRADER = 0.04,
  },
  careerBias = {
    HISTORIAN = 0.054,
    TRADER = 0.036,
  },
}, {
  id = "BG_165",
  origin = "CRAFT_WORKER",
  circumstance = "BELIEVES_SECOND_CHANCES",
  description = "takes pride in improving something one step at a time, believes second chances",
  money = 458,
  items = {
    POKE_BALL = 1,
    POTION = 2,
  },
  disposition = {
    player = 0.06,
    rival = 0.08,
    rocket = -0.08,
  },
  temper = "hopeful",
  personalityBias = {
    SCHOLAR = 0.06,
    TRADER = 0.04,
  },
  pathBias = {
    HISTORIAN = 0.06,
    TRADER = 0.04,
  },
  careerBias = {
    HISTORIAN = 0.054,
    TRADER = 0.036,
  },
}, {
  id = "BG_166",
  origin = "POTION_BREWER",
  circumstance = "CHIP_ON_SHOULDER",
  description = "grew up around careful measurements and practical remedies, chip on shoulder",
  money = 434,
  items = {
    POKE_BALL = 1,
    ANTIDOTE = 1,
    POTION = 1,
  },
  disposition = {
    player = -0.15,
    rival = -0.05,
    rocket = -0.1,
  },
  temper = "hostile",
  personalityBias = {
    RESEARCHER = 0.06,
    PROTECTOR = 0.06,
  },
  pathBias = {
    RESEARCHER = 0.06,
    PROTECTOR = 0.06,
  },
  careerBias = {
    RESEARCHER = 0.054,
    PROTECTOR = 0.054,
  },
}, {
  id = "BG_167",
  origin = "POTION_BREWER",
  circumstance = "SHARES_SUPPLIES",
  description = "grew up around careful measurements and practical remedies, shares supplies",
  money = 526,
  items = {
    POKE_BALL = 1,
    ANTIDOTE = 1,
    POTION = 1,
  },
  disposition = {
    player = 0.08,
    rival = 0.12,
    rocket = -0.05,
  },
  temper = "kind",
  personalityBias = {
    RESEARCHER = 0.06,
    PROTECTOR = 0.06,
  },
  pathBias = {
    RESEARCHER = 0.06,
    PROTECTOR = 0.06,
  },
  careerBias = {
    RESEARCHER = 0.054,
    PROTECTOR = 0.054,
  },
}, {
  id = "BG_168",
  origin = "POTION_BREWER",
  circumstance = "TRUSTS_SLOWLY",
  description = "grew up around careful measurements and practical remedies, trusts slowly",
  money = 518,
  items = {
    POKE_BALL = 1,
    ANTIDOTE = 2,
  },
  disposition = {
    player = -0.05,
    rival = 0.0,
    rocket = -0.12,
  },
  temper = "guarded",
  personalityBias = {
    RESEARCHER = 0.06,
    PROTECTOR = 0.06,
  },
  pathBias = {
    RESEARCHER = 0.06,
    PROTECTOR = 0.06,
  },
  careerBias = {
    RESEARCHER = 0.054,
    PROTECTOR = 0.054,
  },
}, {
  id = "BG_169",
  origin = "POTION_BREWER",
  circumstance = "HATES_LOSING",
  description = "grew up around careful measurements and practical remedies, hates losing",
  money = 560,
  items = {
    POKE_BALL = 2,
    ANTIDOTE = 1,
  },
  disposition = {
    player = 0.0,
    rival = -0.1,
    rocket = -0.04,
  },
  temper = "competitive",
  personalityBias = {
    RESEARCHER = 0.06,
    PROTECTOR = 0.06,
  },
  pathBias = {
    RESEARCHER = 0.06,
    PROTECTOR = 0.06,
  },
  careerBias = {
    RESEARCHER = 0.054,
    PROTECTOR = 0.054,
  },
}, {
  id = "BG_170",
  origin = "POTION_BREWER",
  circumstance = "BELIEVES_SECOND_CHANCES",
  description = "grew up around careful measurements and practical remedies, believes second chances",
  money = 612,
  items = {
    POKE_BALL = 1,
    ANTIDOTE = 1,
    POTION = 1,
  },
  disposition = {
    player = 0.06,
    rival = 0.08,
    rocket = -0.08,
  },
  temper = "hopeful",
  personalityBias = {
    RESEARCHER = 0.06,
    PROTECTOR = 0.06,
  },
  pathBias = {
    RESEARCHER = 0.06,
    PROTECTOR = 0.06,
  },
  careerBias = {
    RESEARCHER = 0.054,
    PROTECTOR = 0.054,
  },
}, {
  id = "BG_171",
  origin = "HERBALIST_FAMILY",
  circumstance = "CHIP_ON_SHOULDER",
  description = "knows local plants and traditional remedies, chip on shoulder",
  money = 328,
  items = {
    POKE_BALL = 1,
    ANTIDOTE = 1,
    POTION = 1,
  },
  disposition = {
    player = -0.15,
    rival = -0.05,
    rocket = -0.1,
  },
  temper = "hostile",
  personalityBias = {
    PROTECTOR = 0.08,
    RESEARCHER = 0.06,
  },
  pathBias = {
    PROTECTOR = 0.08,
    RESEARCHER = 0.06,
  },
  careerBias = {
    PROTECTOR = 0.072,
    RESEARCHER = 0.054,
  },
}, {
  id = "BG_172",
  origin = "HERBALIST_FAMILY",
  circumstance = "SHARES_SUPPLIES",
  description = "knows local plants and traditional remedies, shares supplies",
  money = 420,
  items = {
    POKE_BALL = 1,
    ANTIDOTE = 1,
    POTION = 1,
  },
  disposition = {
    player = 0.08,
    rival = 0.12,
    rocket = -0.05,
  },
  temper = "kind",
  personalityBias = {
    PROTECTOR = 0.08,
    RESEARCHER = 0.06,
  },
  pathBias = {
    PROTECTOR = 0.08,
    RESEARCHER = 0.06,
  },
  careerBias = {
    PROTECTOR = 0.072,
    RESEARCHER = 0.054,
  },
}, {
  id = "BG_173",
  origin = "HERBALIST_FAMILY",
  circumstance = "TRUSTS_SLOWLY",
  description = "knows local plants and traditional remedies, trusts slowly",
  money = 412,
  items = {
    POKE_BALL = 1,
    ANTIDOTE = 2,
  },
  disposition = {
    player = -0.05,
    rival = 0.0,
    rocket = -0.12,
  },
  temper = "guarded",
  personalityBias = {
    PROTECTOR = 0.08,
    RESEARCHER = 0.06,
  },
  pathBias = {
    PROTECTOR = 0.08,
    RESEARCHER = 0.06,
  },
  careerBias = {
    PROTECTOR = 0.072,
    RESEARCHER = 0.054,
  },
}, {
  id = "BG_174",
  origin = "HERBALIST_FAMILY",
  circumstance = "HATES_LOSING",
  description = "knows local plants and traditional remedies, hates losing",
  money = 454,
  items = {
    POKE_BALL = 2,
    ANTIDOTE = 1,
  },
  disposition = {
    player = 0.0,
    rival = -0.1,
    rocket = -0.04,
  },
  temper = "competitive",
  personalityBias = {
    PROTECTOR = 0.08,
    RESEARCHER = 0.06,
  },
  pathBias = {
    PROTECTOR = 0.08,
    RESEARCHER = 0.06,
  },
  careerBias = {
    PROTECTOR = 0.072,
    RESEARCHER = 0.054,
  },
}, {
  id = "BG_175",
  origin = "HERBALIST_FAMILY",
  circumstance = "BELIEVES_SECOND_CHANCES",
  description = "knows local plants and traditional remedies, believes second chances",
  money = 344,
  items = {
    POKE_BALL = 1,
    ANTIDOTE = 1,
    POTION = 1,
  },
  disposition = {
    player = 0.06,
    rival = 0.08,
    rocket = -0.08,
  },
  temper = "hopeful",
  personalityBias = {
    PROTECTOR = 0.08,
    RESEARCHER = 0.06,
  },
  pathBias = {
    PROTECTOR = 0.08,
    RESEARCHER = 0.06,
  },
  careerBias = {
    PROTECTOR = 0.072,
    RESEARCHER = 0.054,
  },
}, {
  id = "BG_176",
  origin = "BIKE_COURIER",
  circumstance = "CHIP_ON_SHOULDER",
  description = "learned speed, stamina and route planning, chip on shoulder",
  money = 332,
  items = {
    POKE_BALL = 1,
    REPEL = 1,
    POTION = 1,
  },
  disposition = {
    player = -0.15,
    rival = -0.05,
    rocket = -0.1,
  },
  temper = "hostile",
  personalityBias = {
    SPEEDRUNNER = 0.08,
    EXPLORER = 0.06,
  },
  pathBias = {
    SPEEDRUNNER_PATH = 0.08,
    EXPLORER = 0.06,
  },
  careerBias = {
    SPEEDRUNNER_PATH = 0.072,
    EXPLORER = 0.054,
  },
}, {
  id = "BG_177",
  origin = "BIKE_COURIER",
  circumstance = "SHARES_SUPPLIES",
  description = "learned speed, stamina and route planning, shares supplies",
  money = 424,
  items = {
    POKE_BALL = 1,
    REPEL = 1,
    POTION = 1,
  },
  disposition = {
    player = 0.08,
    rival = 0.12,
    rocket = -0.05,
  },
  temper = "kind",
  personalityBias = {
    SPEEDRUNNER = 0.08,
    EXPLORER = 0.06,
  },
  pathBias = {
    SPEEDRUNNER_PATH = 0.08,
    EXPLORER = 0.06,
  },
  careerBias = {
    SPEEDRUNNER_PATH = 0.072,
    EXPLORER = 0.054,
  },
}, {
  id = "BG_178",
  origin = "BIKE_COURIER",
  circumstance = "TRUSTS_SLOWLY",
  description = "learned speed, stamina and route planning, trusts slowly",
  money = 416,
  items = {
    POKE_BALL = 1,
    REPEL = 1,
    ANTIDOTE = 1,
  },
  disposition = {
    player = -0.05,
    rival = 0.0,
    rocket = -0.12,
  },
  temper = "guarded",
  personalityBias = {
    SPEEDRUNNER = 0.08,
    EXPLORER = 0.06,
  },
  pathBias = {
    SPEEDRUNNER_PATH = 0.08,
    EXPLORER = 0.06,
  },
  careerBias = {
    SPEEDRUNNER_PATH = 0.072,
    EXPLORER = 0.054,
  },
}, {
  id = "BG_179",
  origin = "BIKE_COURIER",
  circumstance = "HATES_LOSING",
  description = "learned speed, stamina and route planning, hates losing",
  money = 296,
  items = {
    POKE_BALL = 2,
    REPEL = 1,
  },
  disposition = {
    player = 0.0,
    rival = -0.1,
    rocket = -0.04,
  },
  temper = "competitive",
  personalityBias = {
    SPEEDRUNNER = 0.08,
    EXPLORER = 0.06,
  },
  pathBias = {
    SPEEDRUNNER_PATH = 0.08,
    EXPLORER = 0.06,
  },
  careerBias = {
    SPEEDRUNNER_PATH = 0.072,
    EXPLORER = 0.054,
  },
}, {
  id = "BG_180",
  origin = "BIKE_COURIER",
  circumstance = "BELIEVES_SECOND_CHANCES",
  description = "learned speed, stamina and route planning, believes second chances",
  money = 348,
  items = {
    POKE_BALL = 1,
    REPEL = 1,
    POTION = 1,
  },
  disposition = {
    player = 0.06,
    rival = 0.08,
    rocket = -0.08,
  },
  temper = "hopeful",
  personalityBias = {
    SPEEDRUNNER = 0.08,
    EXPLORER = 0.06,
  },
  pathBias = {
    SPEEDRUNNER_PATH = 0.08,
    EXPLORER = 0.06,
  },
  careerBias = {
    SPEEDRUNNER_PATH = 0.072,
    EXPLORER = 0.054,
  },
}, {
  id = "BG_181",
  origin = "FORMER_THIEF",
  circumstance = "CHIP_ON_SHOULDER",
  description = "knows what it means to be given a second chance, chip on shoulder",
  money = 266,
  items = {
    POKE_BALL = 1,
    POKE_BALL = 1,
    POTION = 1,
  },
  disposition = {
    player = -0.15,
    rival = -0.05,
    rocket = -0.1,
  },
  temper = "hostile",
  personalityBias = {
    REDEEMED = 0.1,
    ROCKET = 0.06,
  },
  pathBias = {
    ROCKET_DEFECTOR = 0.1,
    TEAM_ROCKET = 0.06,
  },
  careerBias = {
    ROCKET_DEFECTOR = 0.09,
    TEAM_ROCKET = 0.054,
  },
}, {
  id = "BG_182",
  origin = "FORMER_THIEF",
  circumstance = "SHARES_SUPPLIES",
  description = "knows what it means to be given a second chance, shares supplies",
  money = 196,
  items = {
    POKE_BALL = 1,
    POKE_BALL = 1,
    POTION = 1,
  },
  disposition = {
    player = 0.08,
    rival = 0.12,
    rocket = -0.05,
  },
  temper = "kind",
  personalityBias = {
    REDEEMED = 0.1,
    ROCKET = 0.06,
  },
  pathBias = {
    ROCKET_DEFECTOR = 0.1,
    TEAM_ROCKET = 0.06,
  },
  careerBias = {
    ROCKET_DEFECTOR = 0.09,
    TEAM_ROCKET = 0.054,
  },
}, {
  id = "BG_183",
  origin = "FORMER_THIEF",
  circumstance = "TRUSTS_SLOWLY",
  description = "knows what it means to be given a second chance, trusts slowly",
  money = 188,
  items = {
    POKE_BALL = 1,
    POKE_BALL = 1,
    ANTIDOTE = 1,
  },
  disposition = {
    player = -0.05,
    rival = 0.0,
    rocket = -0.12,
  },
  temper = "guarded",
  personalityBias = {
    REDEEMED = 0.1,
    ROCKET = 0.06,
  },
  pathBias = {
    ROCKET_DEFECTOR = 0.1,
    TEAM_ROCKET = 0.06,
  },
  careerBias = {
    ROCKET_DEFECTOR = 0.09,
    TEAM_ROCKET = 0.054,
  },
}, {
  id = "BG_184",
  origin = "FORMER_THIEF",
  circumstance = "HATES_LOSING",
  description = "knows what it means to be given a second chance, hates losing",
  money = 230,
  items = {
    POKE_BALL = 2,
    POKE_BALL = 1,
  },
  disposition = {
    player = 0.0,
    rival = -0.1,
    rocket = -0.04,
  },
  temper = "competitive",
  personalityBias = {
    REDEEMED = 0.1,
    ROCKET = 0.06,
  },
  pathBias = {
    ROCKET_DEFECTOR = 0.1,
    TEAM_ROCKET = 0.06,
  },
  careerBias = {
    ROCKET_DEFECTOR = 0.09,
    TEAM_ROCKET = 0.054,
  },
}, {
  id = "BG_185",
  origin = "FORMER_THIEF",
  circumstance = "BELIEVES_SECOND_CHANCES",
  description = "knows what it means to be given a second chance, believes second chances",
  money = 282,
  items = {
    POKE_BALL = 1,
    POKE_BALL = 1,
    POTION = 1,
  },
  disposition = {
    player = 0.06,
    rival = 0.08,
    rocket = -0.08,
  },
  temper = "hopeful",
  personalityBias = {
    REDEEMED = 0.1,
    ROCKET = 0.06,
  },
  pathBias = {
    ROCKET_DEFECTOR = 0.1,
    TEAM_ROCKET = 0.06,
  },
  careerBias = {
    ROCKET_DEFECTOR = 0.09,
    TEAM_ROCKET = 0.054,
  },
}, {
  id = "BG_186",
  origin = "PICKPOCKET_SURVIVOR",
  circumstance = "CHIP_ON_SHOULDER",
  description = "learned to protect what little they had, chip on shoulder",
  money = 158,
  items = {
    POKE_BALL = 1,
    ANTIDOTE = 1,
    POTION = 1,
  },
  disposition = {
    player = -0.15,
    rival = -0.05,
    rocket = -0.1,
  },
  temper = "hostile",
  personalityBias = {
    SURVIVALIST = 0.08,
    PROTECTOR = 0.08,
  },
  pathBias = {
    MOUNTAINEER = 0.08,
    PROTECTOR = 0.08,
  },
  careerBias = {
    MOUNTAINEER = 0.072,
    PROTECTOR = 0.072,
  },
}, {
  id = "BG_187",
  origin = "PICKPOCKET_SURVIVOR",
  circumstance = "SHARES_SUPPLIES",
  description = "learned to protect what little they had, shares supplies",
  money = 250,
  items = {
    POKE_BALL = 1,
    ANTIDOTE = 1,
    POTION = 1,
  },
  disposition = {
    player = 0.08,
    rival = 0.12,
    rocket = -0.05,
  },
  temper = "kind",
  personalityBias = {
    SURVIVALIST = 0.08,
    PROTECTOR = 0.08,
  },
  pathBias = {
    MOUNTAINEER = 0.08,
    PROTECTOR = 0.08,
  },
  careerBias = {
    MOUNTAINEER = 0.072,
    PROTECTOR = 0.072,
  },
}, {
  id = "BG_188",
  origin = "PICKPOCKET_SURVIVOR",
  circumstance = "TRUSTS_SLOWLY",
  description = "learned to protect what little they had, trusts slowly",
  money = 242,
  items = {
    POKE_BALL = 1,
    ANTIDOTE = 2,
  },
  disposition = {
    player = -0.05,
    rival = 0.0,
    rocket = -0.12,
  },
  temper = "guarded",
  personalityBias = {
    SURVIVALIST = 0.08,
    PROTECTOR = 0.08,
  },
  pathBias = {
    MOUNTAINEER = 0.08,
    PROTECTOR = 0.08,
  },
  careerBias = {
    MOUNTAINEER = 0.072,
    PROTECTOR = 0.072,
  },
}, {
  id = "BG_189",
  origin = "PICKPOCKET_SURVIVOR",
  circumstance = "HATES_LOSING",
  description = "learned to protect what little they had, hates losing",
  money = 284,
  items = {
    POKE_BALL = 2,
    ANTIDOTE = 1,
  },
  disposition = {
    player = 0.0,
    rival = -0.1,
    rocket = -0.04,
  },
  temper = "competitive",
  personalityBias = {
    SURVIVALIST = 0.08,
    PROTECTOR = 0.08,
  },
  pathBias = {
    MOUNTAINEER = 0.08,
    PROTECTOR = 0.08,
  },
  careerBias = {
    MOUNTAINEER = 0.072,
    PROTECTOR = 0.072,
  },
}, {
  id = "BG_190",
  origin = "PICKPOCKET_SURVIVOR",
  circumstance = "BELIEVES_SECOND_CHANCES",
  description = "learned to protect what little they had, believes second chances",
  money = 336,
  items = {
    POKE_BALL = 1,
    ANTIDOTE = 1,
    POTION = 1,
  },
  disposition = {
    player = 0.06,
    rival = 0.08,
    rocket = -0.08,
  },
  temper = "hopeful",
  personalityBias = {
    SURVIVALIST = 0.08,
    PROTECTOR = 0.08,
  },
  pathBias = {
    MOUNTAINEER = 0.08,
    PROTECTOR = 0.08,
  },
  careerBias = {
    MOUNTAINEER = 0.072,
    PROTECTOR = 0.072,
  },
}, {
  id = "BG_191",
  origin = "SMALL_TIME_GAMBLER",
  circumstance = "CHIP_ON_SHOULDER",
  description = "likes bold choices but hates being controlled, chip on shoulder",
  money = 452,
  items = {
    POKE_BALL = 1,
    GREAT_BALL = 1,
    POTION = 1,
  },
  disposition = {
    player = -0.15,
    rival = -0.05,
    rocket = -0.1,
  },
  temper = "hostile",
  personalityBias = {
    TRADER = 0.08,
    CHALLENGER = 0.06,
  },
  pathBias = {
    TRADER = 0.08,
    SWORN_RIVAL = 0.06,
  },
  careerBias = {
    TRADER = 0.072,
    SWORN_RIVAL = 0.054,
  },
}, {
  id = "BG_192",
  origin = "SMALL_TIME_GAMBLER",
  circumstance = "SHARES_SUPPLIES",
  description = "likes bold choices but hates being controlled, shares supplies",
  money = 544,
  items = {
    POKE_BALL = 1,
    GREAT_BALL = 1,
    POTION = 1,
  },
  disposition = {
    player = 0.08,
    rival = 0.12,
    rocket = -0.05,
  },
  temper = "kind",
  personalityBias = {
    TRADER = 0.08,
    CHALLENGER = 0.06,
  },
  pathBias = {
    TRADER = 0.08,
    SWORN_RIVAL = 0.06,
  },
  careerBias = {
    TRADER = 0.072,
    SWORN_RIVAL = 0.054,
  },
}, {
  id = "BG_193",
  origin = "SMALL_TIME_GAMBLER",
  circumstance = "TRUSTS_SLOWLY",
  description = "likes bold choices but hates being controlled, trusts slowly",
  money = 536,
  items = {
    POKE_BALL = 1,
    GREAT_BALL = 1,
    ANTIDOTE = 1,
  },
  disposition = {
    player = -0.05,
    rival = 0.0,
    rocket = -0.12,
  },
  temper = "guarded",
  personalityBias = {
    TRADER = 0.08,
    CHALLENGER = 0.06,
  },
  pathBias = {
    TRADER = 0.08,
    SWORN_RIVAL = 0.06,
  },
  careerBias = {
    TRADER = 0.072,
    SWORN_RIVAL = 0.054,
  },
}, {
  id = "BG_194",
  origin = "SMALL_TIME_GAMBLER",
  circumstance = "HATES_LOSING",
  description = "likes bold choices but hates being controlled, hates losing",
  money = 578,
  items = {
    POKE_BALL = 2,
    GREAT_BALL = 1,
  },
  disposition = {
    player = 0.0,
    rival = -0.1,
    rocket = -0.04,
  },
  temper = "competitive",
  personalityBias = {
    TRADER = 0.08,
    CHALLENGER = 0.06,
  },
  pathBias = {
    TRADER = 0.08,
    SWORN_RIVAL = 0.06,
  },
  careerBias = {
    TRADER = 0.072,
    SWORN_RIVAL = 0.054,
  },
}, {
  id = "BG_195",
  origin = "SMALL_TIME_GAMBLER",
  circumstance = "BELIEVES_SECOND_CHANCES",
  description = "likes bold choices but hates being controlled, believes second chances",
  money = 630,
  items = {
    POKE_BALL = 1,
    GREAT_BALL = 1,
    POTION = 1,
  },
  disposition = {
    player = 0.06,
    rival = 0.08,
    rocket = -0.08,
  },
  temper = "hopeful",
  personalityBias = {
    TRADER = 0.08,
    CHALLENGER = 0.06,
  },
  pathBias = {
    TRADER = 0.08,
    SWORN_RIVAL = 0.06,
  },
  careerBias = {
    TRADER = 0.072,
    SWORN_RIVAL = 0.054,
  },
}, {
  id = "BG_196",
  origin = "FAILED_CONTESTANT",
  circumstance = "CHIP_ON_SHOULDER",
  description = "learned that losing in public does not have to end the story, chip on shoulder",
  money = 376,
  items = {
    POKE_BALL = 1,
    POTION = 2,
  },
  disposition = {
    player = -0.15,
    rival = -0.05,
    rocket = -0.1,
  },
  temper = "hostile",
  personalityBias = {
    REDEEMED = 0.06,
    SHOWBOAT = 0.06,
  },
  pathBias = {
    ROCKET_DEFECTOR = 0.06,
    PERFORMER = 0.06,
  },
  careerBias = {
    ROCKET_DEFECTOR = 0.054,
    PERFORMER = 0.054,
  },
}, {
  id = "BG_197",
  origin = "FAILED_CONTESTANT",
  circumstance = "SHARES_SUPPLIES",
  description = "learned that losing in public does not have to end the story, shares supplies",
  money = 468,
  items = {
    POKE_BALL = 1,
    POTION = 2,
  },
  disposition = {
    player = 0.08,
    rival = 0.12,
    rocket = -0.05,
  },
  temper = "kind",
  personalityBias = {
    REDEEMED = 0.06,
    SHOWBOAT = 0.06,
  },
  pathBias = {
    ROCKET_DEFECTOR = 0.06,
    PERFORMER = 0.06,
  },
  careerBias = {
    ROCKET_DEFECTOR = 0.054,
    PERFORMER = 0.054,
  },
}, {
  id = "BG_198",
  origin = "FAILED_CONTESTANT",
  circumstance = "TRUSTS_SLOWLY",
  description = "learned that losing in public does not have to end the story, trusts slowly",
  money = 460,
  items = {
    POKE_BALL = 1,
    POTION = 1,
    ANTIDOTE = 1,
  },
  disposition = {
    player = -0.05,
    rival = 0.0,
    rocket = -0.12,
  },
  temper = "guarded",
  personalityBias = {
    REDEEMED = 0.06,
    SHOWBOAT = 0.06,
  },
  pathBias = {
    ROCKET_DEFECTOR = 0.06,
    PERFORMER = 0.06,
  },
  careerBias = {
    ROCKET_DEFECTOR = 0.054,
    PERFORMER = 0.054,
  },
}, {
  id = "BG_199",
  origin = "FAILED_CONTESTANT",
  circumstance = "HATES_LOSING",
  description = "learned that losing in public does not have to end the story, hates losing",
  money = 502,
  items = {
    POKE_BALL = 2,
    POTION = 1,
  },
  disposition = {
    player = 0.0,
    rival = -0.1,
    rocket = -0.04,
  },
  temper = "competitive",
  personalityBias = {
    REDEEMED = 0.06,
    SHOWBOAT = 0.06,
  },
  pathBias = {
    ROCKET_DEFECTOR = 0.06,
    PERFORMER = 0.06,
  },
  careerBias = {
    ROCKET_DEFECTOR = 0.054,
    PERFORMER = 0.054,
  },
}, {
  id = "BG_200",
  origin = "FAILED_CONTESTANT",
  circumstance = "BELIEVES_SECOND_CHANCES",
  description = "learned that losing in public does not have to end the story, believes second chances",
  money = 392,
  items = {
    POKE_BALL = 1,
    POTION = 2,
  },
  disposition = {
    player = 0.06,
    rival = 0.08,
    rocket = -0.08,
  },
  temper = "hopeful",
  personalityBias = {
    REDEEMED = 0.06,
    SHOWBOAT = 0.06,
  },
  pathBias = {
    ROCKET_DEFECTOR = 0.06,
    PERFORMER = 0.06,
  },
  careerBias = {
    ROCKET_DEFECTOR = 0.054,
    PERFORMER = 0.054,
  },
}, {
  id = "BG_201",
  origin = "RETIRED_TRAINER_PARENT",
  circumstance = "CHIP_ON_SHOULDER",
  description = "grew up hearing practical advice from an experienced trainer, chip on shoulder",
  money = 550,
  items = {
    POKE_BALL = 1,
    SUPER_POTION = 1,
    POTION = 1,
  },
  disposition = {
    player = -0.15,
    rival = -0.05,
    rocket = -0.1,
  },
  temper = "hostile",
  personalityBias = {
    MENTOR = 0.1,
    CHALLENGER = 0.04,
  },
  pathBias = {
    MENTOR_PATH = 0.1,
    SWORN_RIVAL = 0.04,
  },
  careerBias = {
    MENTOR_PATH = 0.09,
    SWORN_RIVAL = 0.036,
  },
}, {
  id = "BG_202",
  origin = "RETIRED_TRAINER_PARENT",
  circumstance = "SHARES_SUPPLIES",
  description = "grew up hearing practical advice from an experienced trainer, shares supplies",
  money = 642,
  items = {
    POKE_BALL = 1,
    SUPER_POTION = 1,
    POTION = 1,
  },
  disposition = {
    player = 0.08,
    rival = 0.12,
    rocket = -0.05,
  },
  temper = "kind",
  personalityBias = {
    MENTOR = 0.1,
    CHALLENGER = 0.04,
  },
  pathBias = {
    MENTOR_PATH = 0.1,
    SWORN_RIVAL = 0.04,
  },
  careerBias = {
    MENTOR_PATH = 0.09,
    SWORN_RIVAL = 0.036,
  },
}, {
  id = "BG_203",
  origin = "RETIRED_TRAINER_PARENT",
  circumstance = "TRUSTS_SLOWLY",
  description = "grew up hearing practical advice from an experienced trainer, trusts slowly",
  money = 472,
  items = {
    POKE_BALL = 1,
    SUPER_POTION = 1,
    ANTIDOTE = 1,
  },
  disposition = {
    player = -0.05,
    rival = 0.0,
    rocket = -0.12,
  },
  temper = "guarded",
  personalityBias = {
    MENTOR = 0.1,
    CHALLENGER = 0.04,
  },
  pathBias = {
    MENTOR_PATH = 0.1,
    SWORN_RIVAL = 0.04,
  },
  careerBias = {
    MENTOR_PATH = 0.09,
    SWORN_RIVAL = 0.036,
  },
}, {
  id = "BG_204",
  origin = "RETIRED_TRAINER_PARENT",
  circumstance = "HATES_LOSING",
  description = "grew up hearing practical advice from an experienced trainer, hates losing",
  money = 514,
  items = {
    POKE_BALL = 2,
    SUPER_POTION = 1,
  },
  disposition = {
    player = 0.0,
    rival = -0.1,
    rocket = -0.04,
  },
  temper = "competitive",
  personalityBias = {
    MENTOR = 0.1,
    CHALLENGER = 0.04,
  },
  pathBias = {
    MENTOR_PATH = 0.1,
    SWORN_RIVAL = 0.04,
  },
  careerBias = {
    MENTOR_PATH = 0.09,
    SWORN_RIVAL = 0.036,
  },
}, {
  id = "BG_205",
  origin = "RETIRED_TRAINER_PARENT",
  circumstance = "BELIEVES_SECOND_CHANCES",
  description = "grew up hearing practical advice from an experienced trainer, believes second chances",
  money = 566,
  items = {
    POKE_BALL = 1,
    SUPER_POTION = 1,
    POTION = 1,
  },
  disposition = {
    player = 0.06,
    rival = 0.08,
    rocket = -0.08,
  },
  temper = "hopeful",
  personalityBias = {
    MENTOR = 0.1,
    CHALLENGER = 0.04,
  },
  pathBias = {
    MENTOR_PATH = 0.1,
    SWORN_RIVAL = 0.04,
  },
  careerBias = {
    MENTOR_PATH = 0.09,
    SWORN_RIVAL = 0.036,
  },
}, {
  id = "BG_206",
  origin = "SIBLING_PROTECTOR",
  circumstance = "CHIP_ON_SHOULDER",
  description = "learned early that strength means looking after others, chip on shoulder",
  money = 354,
  items = {
    POKE_BALL = 1,
    POTION = 2,
  },
  disposition = {
    player = -0.15,
    rival = -0.05,
    rocket = -0.1,
  },
  temper = "hostile",
  personalityBias = {
    PROTECTOR = 0.12,
    MENTOR = 0.04,
  },
  pathBias = {
    PROTECTOR = 0.12,
    MENTOR_PATH = 0.04,
  },
  careerBias = {
    PROTECTOR = 0.108,
    MENTOR_PATH = 0.036,
  },
}, {
  id = "BG_207",
  origin = "SIBLING_PROTECTOR",
  circumstance = "SHARES_SUPPLIES",
  description = "learned early that strength means looking after others, shares supplies",
  money = 284,
  items = {
    POKE_BALL = 1,
    POTION = 2,
  },
  disposition = {
    player = 0.08,
    rival = 0.12,
    rocket = -0.05,
  },
  temper = "kind",
  personalityBias = {
    PROTECTOR = 0.12,
    MENTOR = 0.04,
  },
  pathBias = {
    PROTECTOR = 0.12,
    MENTOR_PATH = 0.04,
  },
  careerBias = {
    PROTECTOR = 0.108,
    MENTOR_PATH = 0.036,
  },
}, {
  id = "BG_208",
  origin = "SIBLING_PROTECTOR",
  circumstance = "TRUSTS_SLOWLY",
  description = "learned early that strength means looking after others, trusts slowly",
  money = 276,
  items = {
    POKE_BALL = 1,
    POTION = 1,
    ANTIDOTE = 1,
  },
  disposition = {
    player = -0.05,
    rival = 0.0,
    rocket = -0.12,
  },
  temper = "guarded",
  personalityBias = {
    PROTECTOR = 0.12,
    MENTOR = 0.04,
  },
  pathBias = {
    PROTECTOR = 0.12,
    MENTOR_PATH = 0.04,
  },
  careerBias = {
    PROTECTOR = 0.108,
    MENTOR_PATH = 0.036,
  },
}, {
  id = "BG_209",
  origin = "SIBLING_PROTECTOR",
  circumstance = "HATES_LOSING",
  description = "learned early that strength means looking after others, hates losing",
  money = 318,
  items = {
    POKE_BALL = 2,
    POTION = 1,
  },
  disposition = {
    player = 0.0,
    rival = -0.1,
    rocket = -0.04,
  },
  temper = "competitive",
  personalityBias = {
    PROTECTOR = 0.12,
    MENTOR = 0.04,
  },
  pathBias = {
    PROTECTOR = 0.12,
    MENTOR_PATH = 0.04,
  },
  careerBias = {
    PROTECTOR = 0.108,
    MENTOR_PATH = 0.036,
  },
}, {
  id = "BG_210",
  origin = "SIBLING_PROTECTOR",
  circumstance = "BELIEVES_SECOND_CHANCES",
  description = "learned early that strength means looking after others, believes second chances",
  money = 370,
  items = {
    POKE_BALL = 1,
    POTION = 2,
  },
  disposition = {
    player = 0.06,
    rival = 0.08,
    rocket = -0.08,
  },
  temper = "hopeful",
  personalityBias = {
    PROTECTOR = 0.12,
    MENTOR = 0.04,
  },
  pathBias = {
    PROTECTOR = 0.12,
    MENTOR_PATH = 0.04,
  },
  careerBias = {
    PROTECTOR = 0.108,
    MENTOR_PATH = 0.036,
  },
}, {
  id = "BG_211",
  origin = "RIVAL_FAN",
  circumstance = "CHIP_ON_SHOULDER",
  description = "studied famous trainers and wants to forge a name of their own, chip on shoulder",
  money = 366,
  items = {
    POKE_BALL = 1,
    SUPER_POTION = 1,
    POTION = 1,
  },
  disposition = {
    player = -0.15,
    rival = -0.05,
    rocket = -0.1,
  },
  temper = "hostile",
  personalityBias = {
    CHALLENGER = 0.08,
    SHOWBOAT = 0.04,
  },
  pathBias = {
    SWORN_RIVAL = 0.08,
    PERFORMER = 0.04,
  },
  careerBias = {
    SWORN_RIVAL = 0.072,
    PERFORMER = 0.036,
  },
}, {
  id = "BG_212",
  origin = "RIVAL_FAN",
  circumstance = "SHARES_SUPPLIES",
  description = "studied famous trainers and wants to forge a name of their own, shares supplies",
  money = 458,
  items = {
    POKE_BALL = 1,
    SUPER_POTION = 1,
    POTION = 1,
  },
  disposition = {
    player = 0.08,
    rival = 0.12,
    rocket = -0.05,
  },
  temper = "kind",
  personalityBias = {
    CHALLENGER = 0.08,
    SHOWBOAT = 0.04,
  },
  pathBias = {
    SWORN_RIVAL = 0.08,
    PERFORMER = 0.04,
  },
  careerBias = {
    SWORN_RIVAL = 0.072,
    PERFORMER = 0.036,
  },
}, {
  id = "BG_213",
  origin = "RIVAL_FAN",
  circumstance = "TRUSTS_SLOWLY",
  description = "studied famous trainers and wants to forge a name of their own, trusts slowly",
  money = 450,
  items = {
    POKE_BALL = 1,
    SUPER_POTION = 1,
    ANTIDOTE = 1,
  },
  disposition = {
    player = -0.05,
    rival = 0.0,
    rocket = -0.12,
  },
  temper = "guarded",
  personalityBias = {
    CHALLENGER = 0.08,
    SHOWBOAT = 0.04,
  },
  pathBias = {
    SWORN_RIVAL = 0.08,
    PERFORMER = 0.04,
  },
  careerBias = {
    SWORN_RIVAL = 0.072,
    PERFORMER = 0.036,
  },
}, {
  id = "BG_214",
  origin = "RIVAL_FAN",
  circumstance = "HATES_LOSING",
  description = "studied famous trainers and wants to forge a name of their own, hates losing",
  money = 492,
  items = {
    POKE_BALL = 2,
    SUPER_POTION = 1,
  },
  disposition = {
    player = 0.0,
    rival = -0.1,
    rocket = -0.04,
  },
  temper = "competitive",
  personalityBias = {
    CHALLENGER = 0.08,
    SHOWBOAT = 0.04,
  },
  pathBias = {
    SWORN_RIVAL = 0.08,
    PERFORMER = 0.04,
  },
  careerBias = {
    SWORN_RIVAL = 0.072,
    PERFORMER = 0.036,
  },
}, {
  id = "BG_215",
  origin = "RIVAL_FAN",
  circumstance = "BELIEVES_SECOND_CHANCES",
  description = "studied famous trainers and wants to forge a name of their own, believes second chances",
  money = 544,
  items = {
    POKE_BALL = 1,
    SUPER_POTION = 1,
    POTION = 1,
  },
  disposition = {
    player = 0.06,
    rival = 0.08,
    rocket = -0.08,
  },
  temper = "hopeful",
  personalityBias = {
    CHALLENGER = 0.08,
    SHOWBOAT = 0.04,
  },
  pathBias = {
    SWORN_RIVAL = 0.08,
    PERFORMER = 0.04,
  },
  careerBias = {
    SWORN_RIVAL = 0.072,
    PERFORMER = 0.036,
  },
}, {
  id = "BG_216",
  origin = "GYM_WANNABE",
  circumstance = "CHIP_ON_SHOULDER",
  description = "spent years imagining what it would be like to wear a Gym badge, chip on shoulder",
  money = 320,
  items = {
    POKE_BALL = 1,
    POTION = 2,
  },
  disposition = {
    player = -0.15,
    rival = -0.05,
    rocket = -0.1,
  },
  temper = "hostile",
  personalityBias = {
    CHALLENGER = 0.1,
    ACE = 0.04,
  },
  pathBias = {
    SWORN_RIVAL = 0.1,
    ELITE_ASPIRANT = 0.04,
  },
  careerBias = {
    SWORN_RIVAL = 0.09,
    ELITE_ASPIRANT = 0.036,
  },
}, {
  id = "BG_217",
  origin = "GYM_WANNABE",
  circumstance = "SHARES_SUPPLIES",
  description = "spent years imagining what it would be like to wear a Gym badge, shares supplies",
  money = 412,
  items = {
    POKE_BALL = 1,
    POTION = 2,
  },
  disposition = {
    player = 0.08,
    rival = 0.12,
    rocket = -0.05,
  },
  temper = "kind",
  personalityBias = {
    CHALLENGER = 0.1,
    ACE = 0.04,
  },
  pathBias = {
    SWORN_RIVAL = 0.1,
    ELITE_ASPIRANT = 0.04,
  },
  careerBias = {
    SWORN_RIVAL = 0.09,
    ELITE_ASPIRANT = 0.036,
  },
}, {
  id = "BG_218",
  origin = "GYM_WANNABE",
  circumstance = "TRUSTS_SLOWLY",
  description = "spent years imagining what it would be like to wear a Gym badge, trusts slowly",
  money = 404,
  items = {
    POKE_BALL = 1,
    POTION = 1,
    ANTIDOTE = 1,
  },
  disposition = {
    player = -0.05,
    rival = 0.0,
    rocket = -0.12,
  },
  temper = "guarded",
  personalityBias = {
    CHALLENGER = 0.1,
    ACE = 0.04,
  },
  pathBias = {
    SWORN_RIVAL = 0.1,
    ELITE_ASPIRANT = 0.04,
  },
  careerBias = {
    SWORN_RIVAL = 0.09,
    ELITE_ASPIRANT = 0.036,
  },
}, {
  id = "BG_219",
  origin = "GYM_WANNABE",
  circumstance = "HATES_LOSING",
  description = "spent years imagining what it would be like to wear a Gym badge, hates losing",
  money = 446,
  items = {
    POKE_BALL = 2,
    POTION = 1,
  },
  disposition = {
    player = 0.0,
    rival = -0.1,
    rocket = -0.04,
  },
  temper = "competitive",
  personalityBias = {
    CHALLENGER = 0.1,
    ACE = 0.04,
  },
  pathBias = {
    SWORN_RIVAL = 0.1,
    ELITE_ASPIRANT = 0.04,
  },
  careerBias = {
    SWORN_RIVAL = 0.09,
    ELITE_ASPIRANT = 0.036,
  },
}, {
  id = "BG_220",
  origin = "GYM_WANNABE",
  circumstance = "BELIEVES_SECOND_CHANCES",
  description = "spent years imagining what it would be like to wear a Gym badge, believes second chances",
  money = 498,
  items = {
    POKE_BALL = 1,
    POTION = 2,
  },
  disposition = {
    player = 0.06,
    rival = 0.08,
    rocket = -0.08,
  },
  temper = "hopeful",
  personalityBias = {
    CHALLENGER = 0.1,
    ACE = 0.04,
  },
  pathBias = {
    SWORN_RIVAL = 0.1,
    ELITE_ASPIRANT = 0.04,
  },
  careerBias = {
    SWORN_RIVAL = 0.09,
    ELITE_ASPIRANT = 0.036,
  },
}, {
  id = "BG_221",
  origin = "PROFESSOR_FAMILY",
  circumstance = "CHIP_ON_SHOULDER",
  description = "grew up surrounded by Pokémon research, chip on shoulder",
  money = 574,
  items = {
    POKE_BALL = 1,
    REPEL = 1,
    POTION = 1,
  },
  disposition = {
    player = -0.15,
    rival = -0.05,
    rocket = -0.1,
  },
  temper = "hostile",
  personalityBias = {
    RESEARCHER = 0.12,
    SCHOLAR = 0.06,
  },
  pathBias = {
    RESEARCHER = 0.12,
    HISTORIAN = 0.06,
  },
  careerBias = {
    RESEARCHER = 0.108,
    HISTORIAN = 0.054,
  },
}, {
  id = "BG_222",
  origin = "PROFESSOR_FAMILY",
  circumstance = "SHARES_SUPPLIES",
  description = "grew up surrounded by Pokémon research, shares supplies",
  money = 666,
  items = {
    POKE_BALL = 1,
    REPEL = 1,
    POTION = 1,
  },
  disposition = {
    player = 0.08,
    rival = 0.12,
    rocket = -0.05,
  },
  temper = "kind",
  personalityBias = {
    RESEARCHER = 0.12,
    SCHOLAR = 0.06,
  },
  pathBias = {
    RESEARCHER = 0.12,
    HISTORIAN = 0.06,
  },
  careerBias = {
    RESEARCHER = 0.108,
    HISTORIAN = 0.054,
  },
}, {
  id = "BG_223",
  origin = "PROFESSOR_FAMILY",
  circumstance = "TRUSTS_SLOWLY",
  description = "grew up surrounded by Pokémon research, trusts slowly",
  money = 658,
  items = {
    POKE_BALL = 1,
    REPEL = 1,
    ANTIDOTE = 1,
  },
  disposition = {
    player = -0.05,
    rival = 0.0,
    rocket = -0.12,
  },
  temper = "guarded",
  personalityBias = {
    RESEARCHER = 0.12,
    SCHOLAR = 0.06,
  },
  pathBias = {
    RESEARCHER = 0.12,
    HISTORIAN = 0.06,
  },
  careerBias = {
    RESEARCHER = 0.108,
    HISTORIAN = 0.054,
  },
}, {
  id = "BG_224",
  origin = "PROFESSOR_FAMILY",
  circumstance = "HATES_LOSING",
  description = "grew up surrounded by Pokémon research, hates losing",
  money = 700,
  items = {
    POKE_BALL = 2,
    REPEL = 1,
  },
  disposition = {
    player = 0.0,
    rival = -0.1,
    rocket = -0.04,
  },
  temper = "competitive",
  personalityBias = {
    RESEARCHER = 0.12,
    SCHOLAR = 0.06,
  },
  pathBias = {
    RESEARCHER = 0.12,
    HISTORIAN = 0.06,
  },
  careerBias = {
    RESEARCHER = 0.108,
    HISTORIAN = 0.054,
  },
}, {
  id = "BG_225",
  origin = "PROFESSOR_FAMILY",
  circumstance = "BELIEVES_SECOND_CHANCES",
  description = "grew up surrounded by Pokémon research, believes second chances",
  money = 590,
  items = {
    POKE_BALL = 1,
    REPEL = 1,
    POTION = 1,
  },
  disposition = {
    player = 0.06,
    rival = 0.08,
    rocket = -0.08,
  },
  temper = "hopeful",
  personalityBias = {
    RESEARCHER = 0.12,
    SCHOLAR = 0.06,
  },
  pathBias = {
    RESEARCHER = 0.12,
    HISTORIAN = 0.06,
  },
  careerBias = {
    RESEARCHER = 0.108,
    HISTORIAN = 0.054,
  },
}, {
  id = "BG_226",
  origin = "LAB_RUNNER",
  circumstance = "CHIP_ON_SHOULDER",
  description = "learned precision while carrying delicate research supplies, chip on shoulder",
  money = 438,
  items = {
    POKE_BALL = 1,
    REPEL = 1,
    POTION = 1,
  },
  disposition = {
    player = -0.15,
    rival = -0.05,
    rocket = -0.1,
  },
  temper = "hostile",
  personalityBias = {
    RESEARCHER = 0.08,
    COURIER = 0.06,
  },
  pathBias = {
    RESEARCHER = 0.08,
    COURIER = 0.06,
  },
  careerBias = {
    RESEARCHER = 0.072,
    COURIER = 0.054,
  },
}, {
  id = "BG_227",
  origin = "LAB_RUNNER",
  circumstance = "SHARES_SUPPLIES",
  description = "learned precision while carrying delicate research supplies, shares supplies",
  money = 530,
  items = {
    POKE_BALL = 1,
    REPEL = 1,
    POTION = 1,
  },
  disposition = {
    player = 0.08,
    rival = 0.12,
    rocket = -0.05,
  },
  temper = "kind",
  personalityBias = {
    RESEARCHER = 0.08,
    COURIER = 0.06,
  },
  pathBias = {
    RESEARCHER = 0.08,
    COURIER = 0.06,
  },
  careerBias = {
    RESEARCHER = 0.072,
    COURIER = 0.054,
  },
}, {
  id = "BG_228",
  origin = "LAB_RUNNER",
  circumstance = "TRUSTS_SLOWLY",
  description = "learned precision while carrying delicate research supplies, trusts slowly",
  money = 360,
  items = {
    POKE_BALL = 1,
    REPEL = 1,
    ANTIDOTE = 1,
  },
  disposition = {
    player = -0.05,
    rival = 0.0,
    rocket = -0.12,
  },
  temper = "guarded",
  personalityBias = {
    RESEARCHER = 0.08,
    COURIER = 0.06,
  },
  pathBias = {
    RESEARCHER = 0.08,
    COURIER = 0.06,
  },
  careerBias = {
    RESEARCHER = 0.072,
    COURIER = 0.054,
  },
}, {
  id = "BG_229",
  origin = "LAB_RUNNER",
  circumstance = "HATES_LOSING",
  description = "learned precision while carrying delicate research supplies, hates losing",
  money = 402,
  items = {
    POKE_BALL = 2,
    REPEL = 1,
  },
  disposition = {
    player = 0.0,
    rival = -0.1,
    rocket = -0.04,
  },
  temper = "competitive",
  personalityBias = {
    RESEARCHER = 0.08,
    COURIER = 0.06,
  },
  pathBias = {
    RESEARCHER = 0.08,
    COURIER = 0.06,
  },
  careerBias = {
    RESEARCHER = 0.072,
    COURIER = 0.054,
  },
}, {
  id = "BG_230",
  origin = "LAB_RUNNER",
  circumstance = "BELIEVES_SECOND_CHANCES",
  description = "learned precision while carrying delicate research supplies, believes second chances",
  money = 454,
  items = {
    POKE_BALL = 1,
    REPEL = 1,
    POTION = 1,
  },
  disposition = {
    player = 0.06,
    rival = 0.08,
    rocket = -0.08,
  },
  temper = "hopeful",
  personalityBias = {
    RESEARCHER = 0.08,
    COURIER = 0.06,
  },
  pathBias = {
    RESEARCHER = 0.08,
    COURIER = 0.06,
  },
  careerBias = {
    RESEARCHER = 0.072,
    COURIER = 0.054,
  },
}, {
  id = "BG_231",
  origin = "BACK_ALLEY_FIXER",
  circumstance = "CHIP_ON_SHOULDER",
  description = "knows how to make things work with limited resources, chip on shoulder",
  money = 190,
  items = {
    POKE_BALL = 1,
    ANTIDOTE = 1,
    POTION = 1,
  },
  disposition = {
    player = -0.15,
    rival = -0.05,
    rocket = -0.1,
  },
  temper = "hostile",
  personalityBias = {
    SURVIVALIST = 0.08,
    ROCKET = 0.08,
  },
  pathBias = {
    MOUNTAINEER = 0.08,
    TEAM_ROCKET = 0.08,
  },
  careerBias = {
    MOUNTAINEER = 0.072,
    TEAM_ROCKET = 0.072,
  },
}, {
  id = "BG_232",
  origin = "BACK_ALLEY_FIXER",
  circumstance = "SHARES_SUPPLIES",
  description = "knows how to make things work with limited resources, shares supplies",
  money = 282,
  items = {
    POKE_BALL = 1,
    ANTIDOTE = 1,
    POTION = 1,
  },
  disposition = {
    player = 0.08,
    rival = 0.12,
    rocket = -0.05,
  },
  temper = "kind",
  personalityBias = {
    SURVIVALIST = 0.08,
    ROCKET = 0.08,
  },
  pathBias = {
    MOUNTAINEER = 0.08,
    TEAM_ROCKET = 0.08,
  },
  careerBias = {
    MOUNTAINEER = 0.072,
    TEAM_ROCKET = 0.072,
  },
}, {
  id = "BG_233",
  origin = "BACK_ALLEY_FIXER",
  circumstance = "TRUSTS_SLOWLY",
  description = "knows how to make things work with limited resources, trusts slowly",
  money = 274,
  items = {
    POKE_BALL = 1,
    ANTIDOTE = 2,
  },
  disposition = {
    player = -0.05,
    rival = 0.0,
    rocket = -0.12,
  },
  temper = "guarded",
  personalityBias = {
    SURVIVALIST = 0.08,
    ROCKET = 0.08,
  },
  pathBias = {
    MOUNTAINEER = 0.08,
    TEAM_ROCKET = 0.08,
  },
  careerBias = {
    MOUNTAINEER = 0.072,
    TEAM_ROCKET = 0.072,
  },
}, {
  id = "BG_234",
  origin = "BACK_ALLEY_FIXER",
  circumstance = "HATES_LOSING",
  description = "knows how to make things work with limited resources, hates losing",
  money = 316,
  items = {
    POKE_BALL = 2,
    ANTIDOTE = 1,
  },
  disposition = {
    player = 0.0,
    rival = -0.1,
    rocket = -0.04,
  },
  temper = "competitive",
  personalityBias = {
    SURVIVALIST = 0.08,
    ROCKET = 0.08,
  },
  pathBias = {
    MOUNTAINEER = 0.08,
    TEAM_ROCKET = 0.08,
  },
  careerBias = {
    MOUNTAINEER = 0.072,
    TEAM_ROCKET = 0.072,
  },
}, {
  id = "BG_235",
  origin = "BACK_ALLEY_FIXER",
  circumstance = "BELIEVES_SECOND_CHANCES",
  description = "knows how to make things work with limited resources, believes second chances",
  money = 368,
  items = {
    POKE_BALL = 1,
    ANTIDOTE = 1,
    POTION = 1,
  },
  disposition = {
    player = 0.06,
    rival = 0.08,
    rocket = -0.08,
  },
  temper = "hopeful",
  personalityBias = {
    SURVIVALIST = 0.08,
    ROCKET = 0.08,
  },
  pathBias = {
    MOUNTAINEER = 0.08,
    TEAM_ROCKET = 0.08,
  },
  careerBias = {
    MOUNTAINEER = 0.072,
    TEAM_ROCKET = 0.072,
  },
}, {
  id = "BG_236",
  origin = "TEMPLE_CARETAKER",
  circumstance = "CHIP_ON_SHOULDER",
  description = "learned quiet discipline and respect for old places, chip on shoulder",
  money = 254,
  items = {
    POKE_BALL = 1,
    AWAKENING = 1,
    POTION = 1,
  },
  disposition = {
    player = -0.15,
    rival = -0.05,
    rocket = -0.1,
  },
  temper = "hostile",
  personalityBias = {
    MENTOR = 0.08,
    SCHOLAR = 0.06,
  },
  pathBias = {
    MENTOR_PATH = 0.08,
    HISTORIAN = 0.06,
  },
  careerBias = {
    MENTOR_PATH = 0.072,
    HISTORIAN = 0.054,
  },
}, {
  id = "BG_237",
  origin = "TEMPLE_CARETAKER",
  circumstance = "SHARES_SUPPLIES",
  description = "learned quiet discipline and respect for old places, shares supplies",
  money = 346,
  items = {
    POKE_BALL = 1,
    AWAKENING = 1,
    POTION = 1,
  },
  disposition = {
    player = 0.08,
    rival = 0.12,
    rocket = -0.05,
  },
  temper = "kind",
  personalityBias = {
    MENTOR = 0.08,
    SCHOLAR = 0.06,
  },
  pathBias = {
    MENTOR_PATH = 0.08,
    HISTORIAN = 0.06,
  },
  careerBias = {
    MENTOR_PATH = 0.072,
    HISTORIAN = 0.054,
  },
}, {
  id = "BG_238",
  origin = "TEMPLE_CARETAKER",
  circumstance = "TRUSTS_SLOWLY",
  description = "learned quiet discipline and respect for old places, trusts slowly",
  money = 338,
  items = {
    POKE_BALL = 1,
    AWAKENING = 1,
    ANTIDOTE = 1,
  },
  disposition = {
    player = -0.05,
    rival = 0.0,
    rocket = -0.12,
  },
  temper = "guarded",
  personalityBias = {
    MENTOR = 0.08,
    SCHOLAR = 0.06,
  },
  pathBias = {
    MENTOR_PATH = 0.08,
    HISTORIAN = 0.06,
  },
  careerBias = {
    MENTOR_PATH = 0.072,
    HISTORIAN = 0.054,
  },
}, {
  id = "BG_239",
  origin = "TEMPLE_CARETAKER",
  circumstance = "HATES_LOSING",
  description = "learned quiet discipline and respect for old places, hates losing",
  money = 380,
  items = {
    POKE_BALL = 2,
    AWAKENING = 1,
  },
  disposition = {
    player = 0.0,
    rival = -0.1,
    rocket = -0.04,
  },
  temper = "competitive",
  personalityBias = {
    MENTOR = 0.08,
    SCHOLAR = 0.06,
  },
  pathBias = {
    MENTOR_PATH = 0.08,
    HISTORIAN = 0.06,
  },
  careerBias = {
    MENTOR_PATH = 0.072,
    HISTORIAN = 0.054,
  },
}, {
  id = "BG_240",
  origin = "TEMPLE_CARETAKER",
  circumstance = "BELIEVES_SECOND_CHANCES",
  description = "learned quiet discipline and respect for old places, believes second chances",
  money = 432,
  items = {
    POKE_BALL = 1,
    AWAKENING = 1,
    POTION = 1,
  },
  disposition = {
    player = 0.06,
    rival = 0.08,
    rocket = -0.08,
  },
  temper = "hopeful",
  personalityBias = {
    MENTOR = 0.08,
    SCHOLAR = 0.06,
  },
  pathBias = {
    MENTOR_PATH = 0.08,
    HISTORIAN = 0.06,
  },
  careerBias = {
    MENTOR_PATH = 0.072,
    HISTORIAN = 0.054,
  },
}, {
  id = "BG_241",
  origin = "FESTIVAL_WORKER",
  circumstance = "CHIP_ON_SHOULDER",
  description = "learned to manage crowds and unexpected problems, chip on shoulder",
  money = 338,
  items = {
    POKE_BALL = 1,
    POTION = 2,
  },
  disposition = {
    player = -0.15,
    rival = -0.05,
    rocket = -0.1,
  },
  temper = "hostile",
  personalityBias = {
    SHOWBOAT = 0.06,
    EXPLORER = 0.06,
  },
  pathBias = {
    PERFORMER = 0.06,
    EXPLORER = 0.06,
  },
  careerBias = {
    PERFORMER = 0.054,
    EXPLORER = 0.054,
  },
}, {
  id = "BG_242",
  origin = "FESTIVAL_WORKER",
  circumstance = "SHARES_SUPPLIES",
  description = "learned to manage crowds and unexpected problems, shares supplies",
  money = 430,
  items = {
    POKE_BALL = 1,
    POTION = 2,
  },
  disposition = {
    player = 0.08,
    rival = 0.12,
    rocket = -0.05,
  },
  temper = "kind",
  personalityBias = {
    SHOWBOAT = 0.06,
    EXPLORER = 0.06,
  },
  pathBias = {
    PERFORMER = 0.06,
    EXPLORER = 0.06,
  },
  careerBias = {
    PERFORMER = 0.054,
    EXPLORER = 0.054,
  },
}, {
  id = "BG_243",
  origin = "FESTIVAL_WORKER",
  circumstance = "TRUSTS_SLOWLY",
  description = "learned to manage crowds and unexpected problems, trusts slowly",
  money = 422,
  items = {
    POKE_BALL = 1,
    POTION = 1,
    ANTIDOTE = 1,
  },
  disposition = {
    player = -0.05,
    rival = 0.0,
    rocket = -0.12,
  },
  temper = "guarded",
  personalityBias = {
    SHOWBOAT = 0.06,
    EXPLORER = 0.06,
  },
  pathBias = {
    PERFORMER = 0.06,
    EXPLORER = 0.06,
  },
  careerBias = {
    PERFORMER = 0.054,
    EXPLORER = 0.054,
  },
}, {
  id = "BG_244",
  origin = "FESTIVAL_WORKER",
  circumstance = "HATES_LOSING",
  description = "learned to manage crowds and unexpected problems, hates losing",
  money = 464,
  items = {
    POKE_BALL = 2,
    POTION = 1,
  },
  disposition = {
    player = 0.0,
    rival = -0.1,
    rocket = -0.04,
  },
  temper = "competitive",
  personalityBias = {
    SHOWBOAT = 0.06,
    EXPLORER = 0.06,
  },
  pathBias = {
    PERFORMER = 0.06,
    EXPLORER = 0.06,
  },
  careerBias = {
    PERFORMER = 0.054,
    EXPLORER = 0.054,
  },
}, {
  id = "BG_245",
  origin = "FESTIVAL_WORKER",
  circumstance = "BELIEVES_SECOND_CHANCES",
  description = "learned to manage crowds and unexpected problems, believes second chances",
  money = 516,
  items = {
    POKE_BALL = 1,
    POTION = 2,
  },
  disposition = {
    player = 0.06,
    rival = 0.08,
    rocket = -0.08,
  },
  temper = "hopeful",
  personalityBias = {
    SHOWBOAT = 0.06,
    EXPLORER = 0.06,
  },
  pathBias = {
    PERFORMER = 0.06,
    EXPLORER = 0.06,
  },
  careerBias = {
    PERFORMER = 0.054,
    EXPLORER = 0.054,
  },
}, {
  id = "BG_246",
  origin = "LOST_ROUTE_GUIDE",
  circumstance = "CHIP_ON_SHOULDER",
  description = "spent years helping travelers who took the wrong road, chip on shoulder",
  money = 392,
  items = {
    POKE_BALL = 1,
    REPEL = 1,
    POTION = 1,
  },
  disposition = {
    player = -0.15,
    rival = -0.05,
    rocket = -0.1,
  },
  temper = "hostile",
  personalityBias = {
    EXPLORER = 0.1,
    PROTECTOR = 0.04,
  },
  pathBias = {
    EXPLORER = 0.1,
    PROTECTOR = 0.04,
  },
  careerBias = {
    EXPLORER = 0.09,
    PROTECTOR = 0.036,
  },
}, {
  id = "BG_247",
  origin = "LOST_ROUTE_GUIDE",
  circumstance = "SHARES_SUPPLIES",
  description = "spent years helping travelers who took the wrong road, shares supplies",
  money = 484,
  items = {
    POKE_BALL = 1,
    REPEL = 1,
    POTION = 1,
  },
  disposition = {
    player = 0.08,
    rival = 0.12,
    rocket = -0.05,
  },
  temper = "kind",
  personalityBias = {
    EXPLORER = 0.1,
    PROTECTOR = 0.04,
  },
  pathBias = {
    EXPLORER = 0.1,
    PROTECTOR = 0.04,
  },
  careerBias = {
    EXPLORER = 0.09,
    PROTECTOR = 0.036,
  },
}, {
  id = "BG_248",
  origin = "LOST_ROUTE_GUIDE",
  circumstance = "TRUSTS_SLOWLY",
  description = "spent years helping travelers who took the wrong road, trusts slowly",
  money = 476,
  items = {
    POKE_BALL = 1,
    REPEL = 1,
    ANTIDOTE = 1,
  },
  disposition = {
    player = -0.05,
    rival = 0.0,
    rocket = -0.12,
  },
  temper = "guarded",
  personalityBias = {
    EXPLORER = 0.1,
    PROTECTOR = 0.04,
  },
  pathBias = {
    EXPLORER = 0.1,
    PROTECTOR = 0.04,
  },
  careerBias = {
    EXPLORER = 0.09,
    PROTECTOR = 0.036,
  },
}, {
  id = "BG_249",
  origin = "LOST_ROUTE_GUIDE",
  circumstance = "HATES_LOSING",
  description = "spent years helping travelers who took the wrong road, hates losing",
  money = 356,
  items = {
    POKE_BALL = 2,
    REPEL = 1,
  },
  disposition = {
    player = 0.0,
    rival = -0.1,
    rocket = -0.04,
  },
  temper = "competitive",
  personalityBias = {
    EXPLORER = 0.1,
    PROTECTOR = 0.04,
  },
  pathBias = {
    EXPLORER = 0.1,
    PROTECTOR = 0.04,
  },
  careerBias = {
    EXPLORER = 0.09,
    PROTECTOR = 0.036,
  },
}, {
  id = "BG_250",
  origin = "LOST_ROUTE_GUIDE",
  circumstance = "BELIEVES_SECOND_CHANCES",
  description = "spent years helping travelers who took the wrong road, believes second chances",
  money = 408,
  items = {
    POKE_BALL = 1,
    REPEL = 1,
    POTION = 1,
  },
  disposition = {
    player = 0.06,
    rival = 0.08,
    rocket = -0.08,
  },
  temper = "hopeful",
  personalityBias = {
    EXPLORER = 0.1,
    PROTECTOR = 0.04,
  },
  pathBias = {
    EXPLORER = 0.1,
    PROTECTOR = 0.04,
  },
  careerBias = {
    EXPLORER = 0.09,
    PROTECTOR = 0.036,
  },
}}
