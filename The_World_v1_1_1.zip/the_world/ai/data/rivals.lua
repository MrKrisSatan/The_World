-- The roster.  Adding a fifth rival is an entry here and nothing else: the
-- manager builds one Rival per row, registers one `trainers` record and one
-- `sprites` record per row, and the AI reads its behaviour out of
-- data/personalities.lua.
--
-- SPRITE SLOTS AND CHOOSE YOUR HERO
-- ---------------------------------
-- Choose Your Hero is built into this mod (src/ChooseYourHero.lua): the
-- player picks RED or GREEN, and their story rival BLUE or YELLOW.  Exactly
-- one of each pair goes unused every playthrough, so those two walkers are
-- sitting there fully animated and unreferenced.  `spriteSlot` claims one:
--
--   player_male    the RED walker      -- free when the player chose GREEN
--   player_female  the GREEN walker    -- free when the player chose RED
--   rival_male     the BLUE walker     -- free when the rival is YELLOW
--   rival_female   the YELLOW walker   -- free when the rival is BLUE
--
-- One male and one female rival therefore always wear character-creation art,
-- and which two it is flips with the player's own choices.  A rival whose slot
-- is taken (or whose answers are not recorded yet) falls back to
-- `fallbackSprite`, which is a vanilla walker and always present.  See
-- src/Sprites.lua.
--
-- `trainerClass` is this rival's OWN entry in the trainers registry -- a new
-- id, never a vanilla one, so registering it cannot collide with or reshape
-- the class the game already ships.  `basePic` and `aiClass` DO name vanilla
-- classes: the rival borrows that class's portrait and its battle AI rather
-- than shipping art or reinventing item/switch behaviour.
--
-- STARTERS ARE PER VERSION.
--
-- Each rival has exactly ONE intended starter. `starters` remains a tiny
-- version-keyed table so the same roster works in Red/Blue/Yellow and the
-- optional Gen 2 path without giving a rival a second starter by accident.
-- Rival.starterChain still performs the compatibility lookup, but each chain
-- now contains one deliberate species only.

-- Only Shawn keeps an authored personality. Every other rival draws one
-- ordinary personality from this pool using the save seed, so the cast is not
-- just the same character wearing a new name.

local PERSONALITY_POOL = {
  "CHALLENGER", "SPEEDRUNNER", "COLLECTOR", "STRATEGIST", "EXPLORER",
  "MENTOR", "ACE", "SURVIVALIST", "SHOWBOAT", "SCHOLAR", "TRADER",
  "SPECIALIST",
  "NORTHERN_LOYALIST", "COURT_SCHEMER", "DRAGON_HEIR", "QUIET_SPY",
  "OATHBOUND_KNIGHT", "IRON_COMMISSAR", "MACHINE_ADEPT",
  "INQUISITIVE_PURIFIER", "VOID_VETERAN", "GLORY_REAVER",
  "CYBER_OPERATIVE", "SECTION_CHIEF", "HEAVY_OPERATIVE", "GHOST_HACKER",
  "SOLAR_IDEALIST", "MIDNIGHT_TACTICIAN", "WINGED_GUARDIAN",
  "REALITY_ENGINEER", "STREET_MERC", "NETRUNNER", "CORPORATE_FIXER",
  "NOMAD", "ROCKER_REBEL", "EDGERUNNER", "CRUSADER",
}

local ROSTER = {
  {
    id = "chris",
    -- Deal order for the shared starter pool (see ROSTER.pools below).
    slot = 1,
    trainerClass = "OPP_AIR_CHRIS",
    name = "CHRIS",
    gender = "male",
    personalities = PERSONALITY_POOL,
    gen2Shadow = "RIVAL1",
    spriteSlot = "name_inferred",
    fallbackSprite = "SPRITE_COOLTRAINER_M",
    basePic = "OPP_COOLTRAINER_M",
    aiClass = "OPP_COOLTRAINER_M",
    baseMoney = 50,
    homeMaps = {
      default = {
    "PALLET_TOWN", "VIRIDIAN_CITY", "ROUTE_1", "EEVEE", "CLEFAIRY", "PIKACHU",
  },
      gen2    = {
    "NEW_BARK_TOWN", "ROUTE_29", "CHERRYGROVE_CITY", "EEVEE", "CLEFAIRY", "PIKACHU",
  },
    },
    seed = 0x4C48,
  },
  {
    id = "dyanari",
    -- Deal order for the shared starter pool (see ROSTER.pools below).
    slot = 2,
    trainerClass = "OPP_AIR_DYANARI",
    name = "DYANARI",
    gender = "female",
    personalities = PERSONALITY_POOL,
    gen2Shadow = "RIVAL2",
    spriteSlot = "name_inferred",
    fallbackSprite = "SPRITE_LASS",
    basePic = "OPP_LASS",
    aiClass = "OPP_LASS",
    baseMoney = 40,
    homeMaps = {
      default = { "VIRIDIAN_CITY", "ROUTE_2", "PALLET_TOWN" },
      gen2    = { "CHERRYGROVE_CITY", "ROUTE_30", "NEW_BARK_TOWN" },
    },
    seed = 0x4459,
  },
  {
    id = "matt",
    -- Deal order for the shared starter pool (see ROSTER.pools below).
    slot = 3,
    trainerClass = "OPP_AIR_MATT",
    name = "MATT",
    gender = "male",
    personalities = PERSONALITY_POOL,
    spriteSlot = "name_inferred",
    fallbackSprite = "SPRITE_SUPER_NERD",
    basePic = "OPP_SUPER_NERD",
    aiClass = "OPP_SUPER_NERD",
    baseMoney = 45,
    homeMaps = {
      default = { "ROUTE_1", "PALLET_TOWN", "VIRIDIAN_CITY" },
      gen2    = { "ROUTE_29", "NEW_BARK_TOWN", "CHERRYGROVE_CITY" },
    },
    seed = 0x4D54,
  },
  {
    id = "larissa",
    -- Deal order for the shared starter pool (see ROSTER.pools below).
    slot = 4,
    trainerClass = "OPP_AIR_LARISSA",
    name = "LARISSA",
    gender = "female",
    personalities = PERSONALITY_POOL,
    spriteSlot = "name_inferred",
    fallbackSprite = "SPRITE_COOLTRAINER_F",
    basePic = "OPP_COOLTRAINER_F",
    aiClass = "OPP_COOLTRAINER_F",
    baseMoney = 55,
    homeMaps = {
      default = { "VIRIDIAN_CITY", "PALLET_TOWN", "ROUTE_2" },
      gen2    = { "ROUTE_30", "CHERRYGROVE_CITY", "VIOLET_CITY" },
    },
    seed = 0x4C52,
  },
  {
    id = "shawn",
    slot = 5,
    trainerClass = "OPP_AIR_SHAWN",
    name = "SHAWN",
    gender = "male",
    personality = "HEARTBREAK_KID",
    fallbackSprite = "SPRITE_COOLTRAINER_M",
    basePic = "OPP_COOLTRAINER_M",
    aiClass = "OPP_COOLTRAINER_M",
    baseMoney = 60,
    homeMaps = {
      default = { "VIRIDIAN_CITY", "ROUTE_2", "PEWTER_CITY" },
      gen2    = { "GOLDENROD_CITY", "ROUTE_34", "VIOLET_CITY" },
    },
    seed = 0x48424B,
  },
}

-- The roster identity is now stable by ID, but the displayed given name is
-- assigned by src/data/names.lua when a new save is built. Keeping the IDs
-- stable means saves, trainer classes, relationships and phone contacts remain
-- compatible while the visible cast changes from one new game to the next.
--
-- There are no generated surnames. Rivals are assigned one given name from
-- the 400-name male/female pools, with Shawn retaining his authored identity.
-- This deliberately prevents concatenation bugs such as "Ash Ash" or
-- "Kelly Ash".
--
-- Extra roster rows remain available to the existing rival-count system. They
-- use the same name/personalities machinery as the authored rows.

-- Slots 6..100 remain available to the existing roster-size system. Their
-- displayed names are supplied by data/names.lua, not by this file.
local MALE_SPRITES = { "SPRITE_COOLTRAINER_M", "SPRITE_SUPER_NERD" }
local FEMALE_SPRITES = { "SPRITE_COOLTRAINER_F", "SPRITE_LASS" }

for slot = 6, 100 do
  local female = slot % 2 == 0
  local fallback = female and FEMALE_SPRITES[(slot % #FEMALE_SPRITES) + 1]
    or MALE_SPRITES[(slot % #MALE_SPRITES) + 1]
  ROSTER[#ROSTER + 1] = {
    id = ("rival_%03d"):format(slot),
    slot = slot,
    trainerClass = ("OPP_AIR_%03d"):format(slot),
    name = ("RIVAL %03d"):format(slot),
    gender = female and "female" or "male",
    personalities = PERSONALITY_POOL,
    -- 5.1.0: NO fallbackSprite on generated rows. This field is authored
    -- intent (Guts is a Blackbelt), and setting it here from slot parity meant
    -- all 95 generated rivals shared two overworld sprites between them. With
    -- it absent, Sprites:assignWalker deals each row one sprite from its full
    -- gender pool as a pure function of the world seed -- 18 distinct walkers
    -- across the roster instead of 4, measured. `fallback` is still used just
    -- below for the BATTLE picture, which has a much smaller vocabulary.
    basePic = fallback == "SPRITE_LASS" and "OPP_LASS"
      or (female and "OPP_COOLTRAINER_F" or "OPP_COOLTRAINER_M"),
    aiClass = female and "OPP_COOLTRAINER_F" or "OPP_COOLTRAINER_M",
    baseMoney = 35 + (slot % 6) * 5,
    homeMaps = {
      default = slot % 2 == 0
        and { "VIRIDIAN_CITY", "ROUTE_2", "PALLET_TOWN" }
        or { "ROUTE_1", "PALLET_TOWN", "VIRIDIAN_CITY" },
      gen2 = slot % 2 == 0
        and { "CHERRYGROVE_CITY", "ROUTE_30", "NEW_BARK_TOWN" }
        or { "ROUTE_29", "NEW_BARK_TOWN", "CHERRYGROVE_CITY" },
    },
    seed = 0x5000 + slot * 977,
  }
end

-- 4.7.0 family relationships remain supported by the relationship system.
-- Kin is declared by roster ID, never inferred from the randomly assigned
-- display name. Random names therefore cannot accidentally create a family.
do
  local a, b = ROSTER[6], ROSTER[7]
  if a and b then
    a.kin, b.kin = { b.id }, { a.id }
  end
end

-- STARTER POOLS
-- ------------------------------------------------------------------
-- Rivals no longer own a fixed starter. Each new game deals them one at
-- random from the pool for the loaded game.
--
-- RANDOM BETWEEN SAVES, FIXED WITHIN ONE. The deal is a pure function of the
-- world seed and the rival's `slot`, and that seed is generated ONCE at new
-- game and persisted -- so two playthroughs differ, and reloading never
-- changes who has what. Rerolling on load would be worse than a fixed roster:
-- a rival's ace, its team identity and half its story are downstream of the
-- Pokemon it started with.
--
-- Dealt WITHOUT replacement while the pool is big enough, so four rivals do
-- not open with four Pikachu. Both pools comfortably exceed the roster.
ROSTER.pools = {
  -- Red, Blue and Yellow. Yellow carries all six in its species table even
  -- though it hands the PLAYER a Pikachu, so it needs no separate arm -- and
  -- a boot missing any of them simply deals from the rest.
  default = { "BULBASAUR", "CHARMANDER", "SQUIRTLE", "PIKACHU", "EEVEE",
              "CLEFAIRY" },
  yellow  = {
    "BULBASAUR", "CHARMANDER", "SQUIRTLE", "PIKACHU", "EEVEE", "CLEFAIRY",
  },
  -- Gold adds the Johto trio to the same six.
  gen2    = { "BULBASAUR", "CHARMANDER", "SQUIRTLE", "PIKACHU", "EEVEE",
              "CLEFAIRY", "CHIKORITA", "CYNDAQUIL", "TOTODILE" },
}

-- Last-resort species if a boot carries none of the pool at all. Kept out of
-- the pool proper so it is never dealt to a rival in an ordinary game.
ROSTER.fallbackStarters = { "RATTATA", "PIDGEY", "PIKACHU" }

return ROSTER
