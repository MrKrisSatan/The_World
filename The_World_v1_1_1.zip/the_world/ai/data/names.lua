-- 4.7.1 rival name pools.
--
-- New games assign one unique given name to each active rival from a
-- gender-specific pool. The assignment is deterministic from the saved world
-- seed, so a reload never renames anyone, while a fresh save gets a different
-- cast. Names are intentionally given names only: no generated surname is
-- ever combined with another given name, preventing results such as "Ash Ash"
-- or "Kelly Ash".
--
-- DYANARI and LARISSA are intentionally present in the girls' pool as requested.
-- Shawn is the sole authored personality/name identity and is never renamed.

local Names = {}

Names.BOYS = {"OLIVER", "GEORGE", "ARTHUR", "NOAH", "MUHAMMAD", "LEO", "OSCAR", "THEODORE", "ARCHIE", "HENRY", "HARRY", "CHARLIE", "FREDDIE", "JACK", "ALFIE", "JACOB", "FINLEY", "THEO", "WILLIAM", "ISAAC", "THOMAS", "JOSHUA", "ALEXANDER", "JAMES", "EDWARD", "LUCAS", "LIAM", "BENJAMIN", "ARLO", "ELVIS", "SEBASTIAN", "HUGO", "ETHAN", "SAMUEL", "MAX", "DANIEL", "ADAM", "JOSEPH", "DAVID", "TOMMY", "REUBEN", "REGGIE", "LOUIS", "FRANKIE", "TEDDY", "FINLAY", "RORY", "OAKLEY", "JAXON", "ROMAN", "LUCA", "MASON", "HARRISON", "LOGAN", "DYLAN", "RILEY", "JUDE", "EZRA", "HARVEY", "LOUIE", "SONNY", "RONNIE", "BOBBY", "ALBIE", "ALBERT", "CHARLES", "JENSON", "HUDSON", "CHESTER", "RALPH", "OTIS", "STANLEY", "RUPERT", "FRANKLIN", "ALFRED", "FELIX", "MATTHEW", "MICHAEL", "CHRISTOPHER", "ANDREW", "RYAN", "TYLER", "KYLE", "KIERAN", "CONNOR", "CALLUM", "CAMERON", "LEWIS", "NATHAN", "ELLIOT", "ELLIOTT", "ELIJAH", "ELIAS", "EVAN", "OWEN", "RHYS", "REECE", "REESE", "ZACHARY", "ZAC", "ZACKARY", "ZANE", "ZAYN", "ZION", "XAVIER", "XANDER", "XAVIEN", "YUSUF", "YOUSSEF", "YAHYA", "YAKUB", "IBRAHIM", "ISMAIL", "IDRIS", "OMAR", "ALI", "AMIR", "HAMZA", "HASAN", "HASSAN", "HARIS", "HARRIS", "ARMAAN", "ARHAM", "AYAAN", "RAYYAN", "RAYAN", "REHAN", "ZAIN", "BILAL", "FARIS", "FAISAL", "IMRAN", "IRFAN", "SAMEER", "SAMI", "AYAN", "KIAN", "KIYAN", "KABIR", "ROHAN", "ARYAN", "ARJUN", "AARAV", "VIHAAN", "REYANSH", "ISHAAN", "DHRUV", "DEV", "KRISH", "RISHI", "ROHIT", "RAHUL", "RAVI", "SANJAY", "AJAY", "VIJAY", "ANIL", "AMIT", "NEEL", "NEIL", "NIKHIL", "ADIL", "ASAD", "DANISH", "EHSAN", "ADEEL", "SAIF", "SHAHID", "TOBY", "TOBIAS", "MILES", "MILO", "ROWAN", "FINN", "FLYNN", "FINNEGAN", "CALLAN", "CIAN", "CILLIAN", "CONAN", "RONAN", "EWAN", "EUAN", "ALISTAIR", "ALASTAIR", "ANGUS", "HAMISH", "FRASER", "FERGUS", "DOUGAL", "DUNCAN", "LACHLAN", "BRODIE", "BRODY", "BLAIR", "BLAKE", "BRYCE", "COLE", "CODY", "COREY", "CASEY", "DALE", "DEAN", "DARREN", "DEREK", "DESMOND", "DOMINIC", "DONOVAN", "DOUGLAS", "EMMETT", "EMERSON", "ELLIS", "EMRYS", "IWAN", "IOAN", "GARETH", "GETHIN", "GRIFFIN", "GRAYSON", "GREYSON", "GREY", "GRAHAM", "GRANT", "GORDON", "HAYDEN", "HUNTER", "HARLEY", "HEATH", "HECTOR", "HUGH", "IAN", "IAIN", "IVOR", "IVAN", "IRVING", "JACKSON", "JADEN", "JAY", "JAYDEN", "JESSE", "JOEY", "JOEL", "JONAH", "JONAS", "JONATHAN", "JORDAN", "JOSIAH", "JULIAN", "JULIUS", "KAI", "KAIRO", "KADEN", "KADE", "KINGSTON", "KNOX", "KOBE", "KOBI", "KODY", "LANDON", "LANE", "LAWRENCE", "LAURIE", "LEON", "LEONARD", "LENNON", "LENNOX", "LEVI", "LINCOLN", "LLOYD", "LORCAN", "LORENZO", "LUKE", "LUKA", "MARCUS", "MARK", "MARTIN", "MAXWELL", "MARLEY", "MARSHALL", "MARIUS", "MARLON", "MATTHIAS", "MAURICE", "MICAH", "MICKEY", "MILAN", "MITCHELL", "MOHAMED", "MOHAMMED", "MO", "MOSES", "MUSTAFA", "MYLES", "MYLO", "NATHANIEL", "NELSON", "NICHOLAS", "NICO", "NIKOLAI", "NIALL", "NOEL", "NOLAN", "NORMAN", "ODIN", "OLLIE", "ORLANDO", "OSIAN", "OZZY", "PATRICK", "PAUL", "PAXTON", "PERCY", "PETER", "PHILIP", "PHOENIX", "PIERCE", "PRESTON", "QUENTIN", "QUINN", "RAFAEL", "RAPHAEL", "REMI", "REMY", "REX", "RHYSON", "RICHARD", "RICKY", "RIVER", "ROBERT", "ROBIN", "ROBBIE", "ROCKY", "ROGER", "ROSS", "ROY", "RUSSELL", "RYDER", "RYLAN", "SAM", "SAMSON", "SANTIAGO", "SAUL", "SCOTT", "SEAN", "SHAUN", "SHANE", "SHAWN", "SIDNEY", "SIMON", "SPENCER", "STEFAN", "STEPHEN", "STEVEN", "SULLIVAN", "SOREN", "STUART", "SYLVESTER", "TARIQ", "TARON", "TAYLOR", "TERRY", "THIAGO", "TODD", "TRISTAN", "TROY", "TYSON", "VALENTIN", "VICTOR", "VINCENT", "WADE", "WALKER", "WALTER", "WARREN", "WESLEY", "WESTLEY", "WILSON", "WINSTON", "WYATT", "ZAK", "ZACH", "ZANDER", "ZAVIER", "ZEPHYR", "ZEKE", "AIDAN", "AARON", "BRADLEY", "BRANDON", "BRAYDEN", "DECLAN", "ERIC", "JASON", "KEVIN", "KEITH", "KENNETH", "AVERY", "CARTER", "CALVIN", "AIDEN"}
Names.GIRLS = {"OLIVIA", "AMELIA", "ISLA", "LILY", "AVA", "IVY", "FREYA", "FLORENCE", "ISABELLA", "SOPHIA", "MIA", "POPPY", "ELLA", "EMILY", "GRACE", "EVIE", "CHARLOTTE", "WILLOW", "ROSIE", "MATILDA", "DAISY", "SIENNA", "PHOEBE", "ELSIE", "RUBY", "SOPHIE", "EVELYN", "HARPER", "LUNA", "ALICE", "CHLOE", "ISABELLE", "LAYLA", "MAYA", "MILLIE", "EMILIA", "JESSICA", "ELLIE", "ELIZABETH", "PENELOPE", "MAISIE", "ESME", "SOFIA", "EVA", "ARIA", "MILA", "IRIS", "AYLA", "ADA", "ELIZA", "ELODIE", "HANNAH", "ABIGAIL", "LUCY", "ERIN", "EMMA", "ANNA", "ANNIE", "ELEANOR", "HARRIET", "SCARLETT", "IMOGEN", "MOLLY", "HOLLY", "KATIE", "KIERA", "KEIRA", "KIRA", "LOTTIE", "LOLA", "LIBBY", "LEXI", "LEXIE", "LILLIE", "LILLIAN", "ROSE", "REBECCA", "REBEKAH", "RACHEL", "RACHAEL", "ROBYN", "RHIANNON", "RHIAN", "RHEA", "RIA", "ZOE", "ZOEY", "ZARA", "ZARAH", "ZOYA", "ZAINAB", "ZAHRA", "YASMIN", "YASMINE", "YARA", "XANTHE", "XENA", "WENDY", "WREN", "VICTORIA", "VIOLET", "VERA", "VANESSA", "VALERIE", "VALENTINA", "SKYE", "SKYLA", "SIERRA", "SELENA", "SERENA", "SELINA", "SAVANNAH", "SADIE", "SARAH", "SARA", "SAMANTHA", "SAMIRA", "SABRINA", "SAFIYA", "SAFFRON", "SAGE", "SANDRA", "SAOIRSE", "SCARLET", "SASHA", "SASKIA", "SYLVIA", "SYLVIE", "SUSAN", "SUSANNAH", "SUZANNE", "STELLA", "STEPHANIE", "STACEY", "STACY", "TALIA", "TAHLIA", "TANIA", "TANYA", "TARA", "TARYN", "TEAGAN", "TEGAN", "TESSA", "TESS", "THEA", "THERESA", "TIFFANY", "TILLIE", "TILLY", "TINA", "TRINITY", "TYRA", "UMA", "UNA", "VALERIA", "VERONICA", "VIVIENNE", "VIVIAN", "WILLA", "WINIFRED", "WINNIE", "WHITNEY", "YVETTE", "YVONNE", "ZELDA", "ADDISON", "ADELAIDE", "ADELINE", "ADRIANA", "ADRIANNA", "AIMEE", "AISHA", "ALANA", "ALEXANDRA", "ALEXANDRIA", "ALICIA", "ALINA", "ALISON", "ALISHA", "ALYSSA", "AMANDA", "AMBER", "AMELIE", "AMARA", "AMAYA", "ANASTASIA", "ANDREA", "ANGELA", "ANGELINA", "ANITA", "ANNABELLE", "ANNE", "ANNABEL", "ARABELLA", "ARIANNA", "ARIANA", "ARIEL", "ARIELLA", "ASHLEY", "ASPEN", "ASTRID", "ATHENA", "AUDREY", "AUBREY", "AURORA", "AUTUMN", "BAILEY", "BEATRICE", "BEATRIX", "BELLA", "BELLE", "BETH", "BETHANY", "BIANCA", "BILLIE", "BONNIE", "BRIA", "BRIANNA", "BRIDGET", "BRIELLE", "BROOKE", "BRYN", "BRYONY", "CAITLIN", "CAITLYN", "CALLIE", "CAMILA", "CAMILLE", "CARA", "CARLA", "CARMEN", "CAROLINA", "CAROLINE", "CASSANDRA", "CASSIE", "CATHERINE", "CATHY", "CATRIN", "CECELIA", "CECILIA", "CELESTE", "CELINE", "CERYS", "CHARITY", "CHELSEA", "CHELSIE", "CHER", "CHRISTINA", "CHRISTINE", "CLAIRE", "CLARA", "CLARISSA", "CLAUDIA", "CLEO", "COLETTE", "CONNIE", "CORA", "CORAL", "CORDELIA", "COURTNEY", "DAHLIA", "DANA", "DANIELLE", "DANIELLA", "DAPHNE", "DARCY", "DARIA", "DARLENE", "DAWN", "DELIA", "DELILAH", "DEMI", "DENISE", "DESIREE", "DIANA", "DIANE", "DINA", "DOMINIQUE", "DORA", "DOROTHY", "EDEN", "EDITH", "EILEEN", "ELAINE", "ELENA", "ELIANA", "ELISA", "ELISE", "ELLE", "ELLEN", "ELOISE", "ELSA", "ELSPETH", "ELYSE", "EMMIE", "ESTELLE", "ESTHER", "ETTA", "EUDORA", "EVE", "FAITH", "FALLON", "FARAH", "FATIMA", "FAYE", "FELICITY", "FERN", "FIONA", "FRANCES", "FRANCESCA", "GABRIELLA", "GABRIELLE", "GEMMA", "GEORGIA", "GEORGINA", "GERALDINE", "GIA", "GIANNA", "GIGI", "GINA", "GISELLE", "GLORIA", "GRACIE", "GRETA", "GWEN", "GWENDOLYN", "HADLEY", "HAILEY", "HALEY", "HALLIE", "HATTIE", "HAZEL", "HEATHER", "HEIDI", "HELEN", "HELENA", "HOLLIE", "HOPE", "INDIA", "INDIE", "INGRID", "IRENE", "ISABEL", "ISOBEL", "JACQUELINE", "JADE", "JAIMIE", "JAMIE", "JANE", "JASMINE", "JAYLA", "JEAN", "JENNA", "JENNIFER", "JENNY", "JILLIAN", "JOANNA", "JOCELYN", "JODIE", "JOLENE", "JOSEPHINE", "JOSIE", "JOY", "JUDITH", "JULIA", "JULIANA", "JULIE", "JULIET", "JUNE", "JUNO", "KAITLYN", "KARA", "KAREN", "KARINA", "KARLA", "KASSANDRA", "KATE", "KATHERINE", "KATHLEEN", "KATHRYN", "KAYLA", "KELSEY", "KIMBERLY", "KIRSTEN", "KIRSTY", "KITTY", "KIARA", "LACEY", "DYANARI", "LARISSA", "ANNALISE", "ANNALIESE", "ELIN", "FFION", "SEREN", "NIA", "NESSA", "ORLA", "AISLING"}

local function hash(seed, text)
  local h = 2166136261
  local s = tostring(seed or 1) .. "|" .. tostring(text or "")
  for i = 1, #s do
    h = (h + s:byte(i) * 16777619) % 4294967296
    h = (h * 31 + 7) % 4294967296
  end
  return h
end

local function ranked(pool, seed)
  local rows = {}
  for _, name in ipairs(pool) do
    rows[#rows + 1] = { name = name, key = hash(seed, name) }
  end
  table.sort(rows, function(a, b)
    if a.key ~= b.key then return a.key < b.key end
    return a.name < b.name
  end)
  return rows
end

-- Return the stable gender ordinal of a roster row. Slot order is used rather
-- than the order pairs() happens to enumerate a table.
local function genderOrdinal(def, roster)
  local gender = tostring(def and def.gender or ""):lower()
  local slot = tonumber(def and def.slot) or 0
  local ordinal = 0
  for _, row in ipairs(roster or {}) do
    if tostring(row.gender or ""):lower() == gender
       and (tonumber(row.slot) or 0) <= slot then
      ordinal = ordinal + 1
    end
  end
  return math.max(1, ordinal)
end

function Names.forDef(def, seed, roster)
  if not def then return nil end
  -- Shawn is deliberately the only rival whose authored identity survives
  -- the random-name system.
  if tostring(def.id):lower() == "shawn" then return "SHAWN" end

  local gender = tostring(def.gender or ""):lower()
  local pool = gender == "female" and Names.GIRLS or Names.BOYS
  local rows = ranked(pool, seed)
  if #rows == 0 then return nil end

  local ordinal = genderOrdinal(def, roster)
  local row = rows[((ordinal - 1) % #rows) + 1]
  return row and row.name or nil
end

function Names.assign(seed, roster)
  local out = {}
  for _, def in ipairs(roster or {}) do
    out[def.id] = Names.forDef(def, seed, roster)
  end
  return out
end

function Names.isValidPool()
  local function valid(pool)
    if #pool ~= 400 then return false end
    local seen = {}
    for _, name in ipairs(pool) do
      if type(name) ~= "string" or name == "" then return false end
      if seen[name] then return false end
      seen[name] = true
    end
    return true
  end
  return valid(Names.BOYS) and valid(Names.GIRLS)
end

return Names
