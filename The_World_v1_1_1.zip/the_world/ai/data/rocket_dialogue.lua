local req, mod = ...
local BoxFit = req("src/BoxFit")

-- TEAM ROCKET DIALOGUE (5.0.8)
-- ==================================================================
-- Before 5.0.8 the whole organisation shared twenty-seven strings held in a
-- local table inside src/Rocket.lua. Rank was in the name prefix and nowhere
-- else, so a Leader running a Silph raid and a Grunt loitering on Route 3
-- said the same sentence -- and the Quartermaster, Scientist and Recruiter
-- roles that data/rocket.lua has always assigned were never once audible.
--
-- Same shape as data/dialogue_extra.lua, for the same reason: a cross product
-- of authored banks rather than a shipped wall of strings.
--
--     SITUATIONS[context]   what this Rocket is doing right now
--     RANKS[rank]           how far up the ladder they are
--     ROLES[role]           what the organisation actually uses them for
--
-- Every line is <situation> + <one attitude clause>, and the attitude clause
-- is drawn from the union of the speaker's rank bank and their role bank --
-- which is what makes a Grunt Thief sound like neither a Grunt Enforcer nor
-- an Executive Thief.
--
-- The rank ladder is live: src/Rocket.lua promotes on four successes and
-- demotes on four failures, so the same member's voice moves up and down the
-- rank banks over a long save. That is worth more than static flavour.
--
-- TONE. Rocket reads as organised crime with a chain of command rather than
-- as cartoon villainy -- Warhammer's grinding hierarchy for the rank banks,
-- Star Wars' underworld for the roles. Original text throughout.

local RD = {}

-- ------------------------------------------------------------------
-- SITUATIONS -- one bank per context that src/Rocket.lua can ask for.
-- ------------------------------------------------------------------

RD.situations = {

  -- Spoken as the battle starts.
  challenge = {
    "You are standing in Team Rocket's way.",
    "Wrong road, wrong day.",
    "You saw the operation. Now you fight me.",
    "Orders are orders. Hand them over.",
    "Team Rocket owns this stretch.",
    "Step aside or go through me.",
    "Nice team. We could use it.",
    "This is Rocket business and you are in it.",
    "Nobody walks past a live operation.",
    "You should have taken the other route.",
    "Last chance to turn around. No? Fine.",
    "You have made yourself my problem.",
  },

  -- Spoken when a Rocket spots the player before any battle.
  sight = {
    "Hey! You there!",
    "Stop right where you are.",
    "Team Rocket does not allow witnesses.",
    "You are interfering with Rocket business.",
    "A trainer. Out here. Convenient.",
    "Hold it.",
    "You picked the wrong route to wander onto.",
    "Do not move.",
    "You were not supposed to see that.",
    "I saw you first. Remember that.",
    "Turn around and forget this.",
    "That is close enough.",
  },

  -- On the road to an operation.
  travelling = {
    "Orders came down from Celadon.",
    "I am still on the road.",
    "Long walk. Bad assignment.",
    "The hideout sends us everywhere.",
    "Routes, caves, cities. It never ends.",
    "I am on a mission. Stay out of it.",
    "Somewhere ahead there is a job with my name on it.",
    "Moving. Do not ask where.",
    "Half of this work is walking.",
    "I have another three routes before I sleep.",
    "The assignment is not local. Obviously.",
    "I go where the boss points.",
  },

  -- Heading back to the hideout with a result.
  returning = {
    "The job is done. I am heading back.",
    "Back to Celadon. Finally.",
    "Report first, rest later.",
    "The boss wants this in person.",
    "I have something worth carrying home.",
    "The hideout is expecting me.",
    "Long way back. Worth it.",
    "I do not discuss results on the road.",
    "Whatever happened out there is written up already.",
    "Home, and then whatever comes next.",
    "I am carrying the outcome, not the story.",
    "Debrief, then a bed. Maybe.",
  },

  -- Standing around between orders.
  idle = {
    "Keep moving. You did not see anything.",
    "Team Rocket has business everywhere.",
    "I am waiting on new orders.",
    "You ask too many questions.",
    "The boss always has another job.",
    "Nothing is happening here. Obviously.",
    "I am exactly where I was told to be.",
    "This is a quiet posting. For now.",
    "Do not stand near me.",
    "There is no operation here. None at all.",
    "I have been at this corner for hours.",
    "Somebody has to watch this road.",
  },

  -- After the player beat them. 5.0.8 wires src/Rocket.lua to route "talk"
  -- here for a while, so beating a Rocket changes what they say next.
  beaten = {
    "You already put me down once.",
    "I filed a report about you.",
    "That loss cost me.",
    "The boss heard about you. From me.",
    "I am not doing that again today.",
    "You are on a list now. Congratulations.",
    "I remember you. Unfortunately.",
    "That went in my record, not yours.",
    "Do not enjoy it too much.",
    "I have been demoted for less.",
    "You caught me on a bad operation.",
    "Next time I am not alone.",
  },

  -- After they beat the player.
  won = {
    "I already beat you once.",
    "You came back. Bold.",
    "That went in my file as a success.",
    "The last one did not go your way.",
    "I got a commendation out of you.",
    "You are the reason I am still on this route.",
    "Do you want another one?",
    "I remember how that ended.",
    "You have not improved enough. I would know.",
    "That win bought me a promotion hearing.",
    "Twice would be embarrassing. For you.",
    "I am still here. You noticed.",
  },
}

-- ------------------------------------------------------------------
-- RANK -- position on the ladder. Live: src/Rocket.lua promotes and demotes.
-- ------------------------------------------------------------------

RD.ranks = {
  Grunt = {
    "I do not get told why.",
    "I just need this to go quietly.",
    "Somebody above me wants this done.",
    "I am not paid to think about it.",
    "One more clean job and I move up.",
    "Do you know what happens to Grunts who fail?",
    "I have a quota, same as everyone.",
    "The uniform was not my first choice.",
    "I am nobody. That is the point.",
    "Talk to my Executive. If you can find them.",
    "This is a job. It pays.",
    "I keep my head down and my hands full.",
  },
  Executive = {
    "I answer to one person and it is not you.",
    "I run this operation.",
    "The Grunts do the walking. I do the deciding.",
    "I earned this rank the slow way.",
    "I have people under me. Consider that.",
    "My reports get read.",
    "I do not need permission for this.",
    "Failure at my level is not survivable.",
    "I was where those Grunts are. I remember.",
    "This is my operation and my name on it.",
    "I choose which orders get followed carefully.",
    "There are three people above me. Not many.",
  },
  Leader = {
    "I do not explain myself.",
    "Everything on this route reports to me eventually.",
    "I have been with Rocket longer than you have been a trainer.",
    "I decide what the boss hears.",
    "I have buried better operations than this.",
    "Every Grunt you have met works for me.",
    "I do not attend failures. I cause them.",
    "There is very little above me.",
    "I built this branch out of nothing.",
    "You are speaking to the top of this region.",
    "Ambition got me here. It keeps me here.",
    "I have not taken an order in years.",
  },
}

-- ------------------------------------------------------------------
-- ROLE -- what the organisation actually uses this member for. Every one of
-- these is assigned by data/rocket.lua and, until 5.0.8, none was audible.
-- ------------------------------------------------------------------

RD.roles = {
  Scout = {
    "I watch. That is the whole job.",
    "I have been counting trainers on this road all week.",
    "Somebody has to know what is out here.",
    "I map routes before anyone walks them.",
    "I saw you long before you saw me.",
    "My reports decide where the others go.",
    "I do not fight much. I notice.",
    "There is nothing on this route I have not logged.",
    "Reconnaissance first. Always.",
    "I know which trainers are worth robbing.",
    "I get paid for what I see, not what I take.",
    "Every operation starts with me standing here.",
  },
  Enforcer = {
    "I am the part they send when talking failed.",
    "I settle things.",
    "People pay when I arrive.",
    "I do not negotiate. I collect.",
    "My job is to be the consequence.",
    "I have never needed a second visit.",
    "They send me because I finish things.",
    "I am not here to frighten you. That is a side effect.",
    "Discussion is somebody else's department.",
    "I break what needs breaking.",
    "You would rather have met the Scout.",
    "I do the ugly half of the work.",
  },
  Thief = {
    "I take things. It is not complicated.",
    "Everything you own is temporarily yours.",
    "I have never bought a Pokemon in my life.",
    "Locks are a suggestion.",
    "You will not notice until later.",
    "I work quietly. Usually.",
    "Your belt looks heavy. Let me help.",
    "I only steal what somebody else wants.",
    "I have emptied better bags than yours.",
    "Possession is a temporary condition.",
    "The best theft has no witness.",
    "I take. I do not keep.",
  },
  Smuggler = {
    "I move things that should not move.",
    "Every crate on this road is mine.",
    "I know six ways out of this region.",
    "Customs is a state of mind.",
    "I do not ask what is in the box.",
    "The routes matter more than the cargo.",
    "I have shipped worse through here.",
    "Nothing I carry has papers.",
    "Water routes, mostly. Fewer eyes.",
    "I deliver. What happens after is not mine.",
    "There is a boat waiting somewhere for this.",
    "I am the reason it gets where it is going.",
  },
  Scientist = {
    "The research matters more than the operation.",
    "Every specimen teaches us something.",
    "I am not here for the fighting.",
    "The lab wants results. It always wants results.",
    "I have papers nobody will ever read.",
    "This is data collection with a uniform.",
    "Rocket funds work nobody else will.",
    "I am interested in your team professionally.",
    "Ethics were a hiring conversation. Briefly.",
    "I need three more samples this week.",
    "The equipment costs more than all of us.",
    "I would explain, but you would not follow.",
  },
  Recruiter = {
    "I am always looking for talent.",
    "You would do well with us.",
    "Everyone has a price. I find it.",
    "Half the Grunts here were my idea.",
    "I do not recruit the desperate. They break.",
    "A trainer like you is wasted out here.",
    "I make offers. Some get accepted.",
    "There is a place for you if you want it.",
    "I have talked better people into worse things.",
    "The uniform fits more people than you would think.",
    "I read trainers for a living.",
    "Think about it. I will ask again.",
  },
  Quartermaster = {
    "Nothing moves without my signature.",
    "I count everything twice.",
    "The whole operation runs on my inventory.",
    "Somebody has to know where the supplies went.",
    "I have a ledger for every hideout in Kanto.",
    "Balls, potions, uniforms. All mine.",
    "An operation fails on logistics, not on courage.",
    "I know exactly what we can afford to lose.",
    "The Executives forget who equips them.",
    "Requisition it properly or go without.",
    "I have never lost a crate. Once.",
    "Supply is the only thing holding this together.",
  },
}

-- ------------------------------------------------------------------
-- Composition
-- ------------------------------------------------------------------
-- Same coprime stride as the rival banks: walking the two lists in order
-- would give the first dozen lines of a cell one shared opening clause.

-- src/ClauseMix.lua owns the cross-product walk; see the comment at the top
-- of it. The cap is what holds the organisation near ten thousand lines
-- rather than the ~48,000 the banks could produce.
local ClauseMix = req("src/ClauseMix")

local CAP = 58

local function composeCell(situations, attitudes)
  return ClauseMix.cross(situations, attitudes, CAP)
end

-- Built once at load. `lines[context][rank][role]` is a flat list of
-- unwrapped sentences; src/Rocket.lua fits the speaker label and the box
-- around them at speaking time, because the label depends on the member.
function RD.build()
  local lines, count = {}, 0
  for context, situations in pairs(RD.situations) do
    lines[context] = {}
    for rank, rankBank in pairs(RD.ranks) do
      lines[context][rank] = {}
      for role, roleBank in pairs(RD.roles) do
        local attitudes = {}
        for _, c in ipairs(rankBank) do attitudes[#attitudes + 1] = c end
        for _, c in ipairs(roleBank) do attitudes[#attitudes + 1] = c end
        local cell = composeCell(situations, attitudes)
        lines[context][rank][role] = cell
        count = count + #cell
      end
      -- A member whose role is unset, or set to something a third-party
      -- data/rocket.lua added, still speaks -- in their rank's voice alone.
      -- §7: the fallback exists because the thing genuinely may not exist.
      local cell = composeCell(situations, rankBank)
      lines[context][rank].default = cell
      count = count + #cell
    end
    -- And a rank nobody wrote a bank for.
    lines[context].default = composeCell(situations, RD.ranks.Grunt)
    count = count + #lines[context].default
  end
  lines.count = count
  return lines
end

RD.BoxFit = BoxFit

return RD
