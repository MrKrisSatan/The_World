-- Team Rocket procedural world data. These are candidate operations and maps,
-- resolved against the loaded game's actual map graph at runtime.
return {
  starterPokemon = {
    "ZUBAT", "KOFFING", "RATTATA", "EKANS", "NIDORAN_M", "NIDORAN_F",
    "MEOWTH", "HOUNDOUR", "MAGIKARP", "TENTACOOL",
  },
  foodSources = {
    "berries", "wild honey", "fallen fruit", "pond algae", "grain stores",
    "flower nectar", "tree sap", "mineral-rich moss", "urban refuse",
    "river insects", "cave fungi", "seaweed",
  },
  ranks = { "Grunt", "Grunt", "Grunt", "Executive", "Executive", "Leader" },
  doctrines = { "EXPANSIONIST", "POACHER", "RECRUITER", "SCIENTIFIC", "COVERT" },
  roles = { "Scout", "Enforcer", "Thief", "Smuggler", "Scientist", "Recruiter", "Quartermaster" },
  backgrounds = { "street hustler", "failed trainer", "dock runner", "petty thief", "ex-trainer", "lab assistant", "smuggler", "ambitious recruit", "former Ranger", "family business" },
  goals = { "build influence", "prove loyalty", "steal rare Pokemon", "earn promotion", "find a rival worth recruiting", "expand the operation", "avoid demotion", "escape Rocket", "redeem past mistakes" },
  operations = {
    { id="SCOUT", label="Scout trainers", weight=18, danger=1, target="TRAINER" },
    { id="RECRUIT", label="Recruit a rival", weight=15, danger=2, target="RIVAL" },
    { id="POKEMON_HEIST", label="Steal Pokémon", weight=14, danger=3, target="RIVAL" },
    { id="SMUGGLE", label="Smuggle Pokémon", weight=12, danger=2, target="ROUTE" },
    { id="SHAKE_DOWN", label="Shake down trainers", weight=12, danger=2, target="TRAINER" },
    { id="SILPH_RAID", label="Raid a Silph facility", weight=7, danger=5, target="SILPH" },
    { id="SAFARI_SEIZURE", label="Seize the Safari Zone", weight=5, danger=6, target="SAFARI" },
    { id="HIDEOUT", label="Expand a hideout", weight=9, danger=1, target="CITY" },
    { id="PROPAGANDA", label="Spread Rocket propaganda", weight=8, danger=1, target="CITY" },
    -- ECOLOGY OPERATIONS: targets are resolved from the loaded encounter
    -- tables, so every route/species in a conversion can become a mission.
    { id="SPECIES_SWEEP", label="Sweep a species from the route", weight=12, danger=3, target="ECOLOGY" },
    { id="SPECIES_POACH", label="Poach a local population", weight=10, danger=3, target="ECOLOGY" },
    { id="DRIVE_MIGRATION", label="Drive a species onto another route", weight=9, danger=3, target="ECOLOGY" },
    { id="FOOD_SOURCE_EXPERIMENT", label="Alter a species' food source", weight=8, danger=2, target="ECOLOGY" },
    { id="HABITAT_STRIP", label="Strip a habitat for profit", weight=8, danger=3, target="ECOLOGY" },
    { id="BREEDING_SITE", label="Capture a breeding population", weight=7, danger=4, target="ECOLOGY" },
  },
  locations = {
    "CELADON_CITY", "SAFARI_ZONE", "FUCHSIA_CITY", "SILPH_CO", "ROUTE_16",
    "ROUTE_17", "ROUTE_18", "ROUTE_15", "ROUTE_14", "ROUTE_13", "ROUTE_12",
    "ROUTE_8", "ROUTE_7", "ROUTE_6", "ROUTE_5", "ROUTE_4", "ROUTE_3",
    "ROUTE_2", "ROUTE_1", "VIRIDIAN_CITY", "PEWTER_CITY", "CERULEAN_CITY",
    "VERMILION_CITY", "LAVENDER_TOWN", "SS_ANNE", "ROCKET_HIDEOUT",
  },
  leaderNames = {
    "Vance", "Marlowe", "Silas", "Rhea", "Dorian", "Nyx", "Cassian", "Mara",
    "Victor", "Selene", "Blaine", "Iris", "Ronan", "Vesper", "Lucian", "Talia",
  },
}
