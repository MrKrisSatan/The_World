-- Dialogue is a lookup, never a branch in the AI.  RivalDialogue picks a
-- bucket from (situation, personality) and then one line from it with the
-- rival's own deterministic RNG, so the same rival in the same state says the
-- same thing until its state moves.
--
-- Tokens expanded by src/Dialogue.lua before the line reaches a text box:
--   {NAME}    the rival's name          {BADGES}  their badge count
--   {NEXT}    next gym leader's name    {CITY}    that gym's city, spaced
--   {LAST}    the leader they just beat {MON}     their strongest species
--   {N}       badge count as a word     {PLAYER}  left for the engine
--
-- A bucket may carry a `girl` arm: a list the rivals say to a girl playing
-- WITH the Girl-mode mod installed (src/Dialogue.lua:isGirl gates it).  It
-- is this mod's own copy -- a small feminine-voice set, not Girl-mode's
-- text, which that mod owns and this one never touches.
--
-- \n is a line break inside a box, \f is a page break.  Keep lines to two
-- rows of about 17 characters; the engine does not wrap.

local req = ...

local D = {}

-- ------------------------------------------------------------------
-- Greeting: talked to, no battle.  Keyed by state, then personality,
-- with a `default` arm so a new personality never falls off a cliff.
-- ------------------------------------------------------------------

D.greeting = {
  IDLE = {
    default = { "{NAME}: Taking a\nminute to plan." },
    CHALLENGER = {
      "{NAME}: Don't get\ncomfortable. I'm\vstill after you.",
      "{NAME}: Next time,\nI win. Simple.",
      "{NAME}: My team is\nitching to fight.",
    },
    SPEEDRUNNER = {
      "{NAME}: Route set.\nNo wasted steps.",
      "{NAME}: Resting is\npart of the split.",
      "{NAME}: Talk fast.\nI'm losing time.",
    },
    COLLECTOR = {
      "{NAME}: I wonder\nwhat lives nearby?",
      "{NAME}: Every ball\nholds a new story.",
      "{NAME}: Want to see\nmy latest catch?",
    },
    STRATEGIST = {
      "{NAME}: Reviewing\nmatchups. Again.",
      "{NAME}: A quiet\nturn can win a\vbattle later.",
      "{NAME}: I have three\nplans for you.",
    },
    HEARTBREAK_KID = {
      "{NAME}:\nI'm your frenemy.",
      "{NAME}: The Heartbreak\nKid is ready to\vsteal the show.",
      "{NAME}: Every battle\nneeds a showstopper.",
    },
  },
  TRAVELLING = {
    default    = { "{NAME}: On my way\nto {CITY}." },
    CHALLENGER = { "{NAME}: Out of my\nway. {NEXT} is\vwaiting.", "{NAME}: The road\nends in a win." },
    SPEEDRUNNER = { "{NAME}: {CITY}.\nNo detours.", "{NAME}: Best route.\nKeep moving." },
    COLLECTOR  = { "{NAME}: Taking the\nlong way round.\vBetter scenery.", "{NAME}: New road,\nnew Pokemon!" },
    STRATEGIST = { "{NAME}: {CITY} next.\nI've read up on\v{NEXT} already.", "{NAME}: This route\nhas the safest\vcoverage." },
    HEARTBREAK_KID = { "{NAME}: The main\nevent is in {CITY}." },
    girl       = { "{NAME}: A girl\ntrainer, huh?\vOn my way to\n{CITY}." },
  },
  TRAINING = {
    default    = { "{NAME}: Training.\nCome back later." },
    CHALLENGER = { "{NAME}: My {MON} is\ngetting mean.", "{NAME}: One more\nlevel. Then fight." },
    SPEEDRUNNER = { "{NAME}: I hate\ngrinding. Two more\vlevels and I'm out.", "{NAME}: Fast reps.\nFast results." },
    COLLECTOR  = { "{NAME}: Look what\nI found out here!", "{NAME}: Training\nevery friend fairly." },
    STRATEGIST = { "{NAME}: Numbers\nfirst. Battles\vafter.", "{NAME}: Fixing one\nweak matchup." },
    HEARTBREAK_KID = { "{NAME}: Tuning up\nfor the main event." },
  },
  SEEKING_GYM = {
    default    = { "{NAME}: {NEXT}'s GYM\nis just ahead." },
    CHALLENGER = { "{NAME}: {NEXT} won't\nstop me." },
    SPEEDRUNNER = { "{NAME}: Badge {N}.\nWatch me.", "{NAME}: In, win, out.\nThat's the plan." },
    COLLECTOR = { "{NAME}: A badge and\nnew Pokemon nearby!" },
    STRATEGIST = { "{NAME}: {NEXT}'s lead\nis accounted for." },
    HEARTBREAK_KID = { "{NAME}: {NEXT} gets\nSweet Chin Music." },
  },
  HEALING = {
    default = { "{NAME}: My team's\nbeat up. Give me\va minute." },
    CHALLENGER = { "{NAME}: Patch them\nup. I want a rematch." },
    SPEEDRUNNER = { "{NAME}: Quick heal.\nThen back out." },
    COLLECTOR = { "{NAME}: Everyone\ndeserves a rest." },
    STRATEGIST = { "{NAME}: Restoring HP\nand adjusting moves." },
    HEARTBREAK_KID = { "{NAME}: Even the\nshowstopper needs\va breather." },
  },
  EXPLORING = {
    default    = { "{NAME}: Just\nlooking around." },
    CHALLENGER = { "{NAME}: Looking for\na tougher fight." },
    SPEEDRUNNER = { "{NAME}: Checking a\npossible shortcut." },
    COLLECTOR  = { "{NAME}: Kanto's\nbigger than the\vbadge list, y'know.", "{NAME}: Somewhere\nhere is a new friend." },
    STRATEGIST = { "{NAME}: Mapping exits\nand encounter odds." },
    HEARTBREAK_KID = { "{NAME}: Looking for\nmy next main event." },
  },
  DEFEATED = {
    default    = { "{NAME}: ...I lost.\nI'll be back." },
    CHALLENGER = { "{NAME}: Enjoy it.\nIt won't happen twice." },
    SPEEDRUNNER = { "{NAME}: Bad split.\nReset and move." },
    COLLECTOR = { "{NAME}: We lost, but\nwe learned a lot!" },
    STRATEGIST = { "{NAME}: Failure found.\nCountermeasure next." },
    HEARTBREAK_KID = { "{NAME}: You can't\nkeep the Heartbreak\vKid down." },
  },
  LEAGUE_READY = {
    default    = { "{NAME}: Eight badges.\nNo more excuses.\fLet's see who\nreaches the LEAGUE\vfirst." },
    CHALLENGER = { "{NAME}: The LEAGUE is\nnext. Don't slow\vme down." },
    SPEEDRUNNER = { "{NAME}: Eight. Done.\nElite Four, then\vhome." },
    COLLECTOR  = { "{NAME}: I've seen a\nlot of Kanto.\nTime for the\vLEAGUE." },
    STRATEGIST = { "{NAME}: Prep is\nover. The LEAGUE\vis just math now." },
    HEARTBREAK_KID = { "{NAME}: The LEAGUE\nis my main event." },
  },
  -- 1.7.0: after a successful simulated League run
  CHAMPION = {
    default    = { "{NAME}: I cleared\nthe LEAGUE.\nChampion of this\vregion." },
    CHALLENGER = { "{NAME}: Champion.\nCome take the\vtitle if you can." },
    SPEEDRUNNER = { "{NAME}: League\ncleared. Next." },
    COLLECTOR  = { "{NAME}: I did it!\nThe LEAGUE! Wait\vtill you see my\nteam." },
    STRATEGIST = { "{NAME}: Calculated.\nExecuted. Champion." },
    HEARTBREAK_KID = { "{NAME}: Champion\nand showstopper.\vJust like I said." },
  },
}

-- ------------------------------------------------------------------
-- The line shown as the rival challenges the player (engine prints it,
-- then starts the battle).
-- ------------------------------------------------------------------

D.scoreRemind = {
  default = {
    "{NAME}: Remember?\nI'm {WINS}-{LOSSES}\vagainst you!",
    "{NAME}: Score's\n{WINS} wins to your\v{LOSSES}. Don't\vforget!",
    "{NAME}: {WINS}-{LOSSES}.\nI keep track.",
  },
  CHALLENGER = {
    "{NAME}: {WINS} wins,\n{LOSSES} losses.\vYou're next!",
    "{NAME}: Still\n{WINS}-{LOSSES}.\vI'll make it worse!",
  },
  SPEEDRUNNER = {
    "{NAME}: {WINS}-{LOSSES}.\nMake this fast.",
  },
  COLLECTOR = {
    "{NAME}: Our record\nis {WINS}-{LOSSES}!\vShow me more!",
  },
  STRATEGIST = {
    "{NAME}: Data says\n{WINS}-{LOSSES}.\vPatterns don't lie.",
  },
  HEARTBREAK_KID = {
    "{NAME}: Your frenemy\nis {WINS}-{LOSSES}.\vReady for an encore?",
  },
}

D.challenge = {
  default = {
    "{NAME}: Hey! You!\nLet's see what\vyou've got!",
    "{NAME}: Perfect\ntiming. Battle me.",
    "{NAME}: No running.\nThis is happening.",
    "{NAME}: I challenge\nyou! Ready or not!",
  },
  CHALLENGER = {
    "{NAME}: There you\nare. I've been\vlooking for you.",
    "{NAME}: {BADGES} badges\nsays I beat you.",
    "{NAME}: Don't blink.\nI'm taking this.",
    "{NAME}: Finally!\nShow me your best!",
    "{NAME}: Step up.\nNo holding back.",
  },
  SPEEDRUNNER = {
    "{NAME}: You're in\nmy way. Fine.\vMake it quick.",
    "{NAME}: Battle.\nThen I'm gone.",
    "{NAME}: Sixty\nseconds. Go!",
  },
  COLLECTOR = {
    "{NAME}: Oh, it's\nyou! Show me your\vteam!",
    "{NAME}: I want to\nsee every mon\vyou've got!",
    "{NAME}: A friendly\nbattle? Yes!",
  },
  STRATEGIST = {
    "{NAME}: I've run\nthe numbers on\vyou. Let's test\vthem.",
    "{NAME}: Type match-\nups favour me.\vProve me wrong.",
    "{NAME}: Calculated\nrisk. Accept it.",
  },
  HEARTBREAK_KID = {
    "{NAME}: Your frenemy\nwants the main event!",
    "{NAME}: Ring the bell.\nThe showstopper's\vhere!",
    "{NAME}: Get ready for\nSweet Chin Music!",
  },
  girl = {
    "{NAME}: Hey there,\ngirl! Battle me.",
    "{NAME}: Come on,\n{PLAYER}. Let's\vsee that team.",
  },
}

-- The final Elite Four battle. BLUE retains the game's vanilla speech; each
-- AI champion has a distinct line keyed to the personality it actually uses.
D.eliteChampion = {
  CHALLENGER = { "{NAME}: The title is\nmine. Come take\vit from me." },
  SPEEDRUNNER = { "{NAME}: Champion\nrun complete.\nYour turn. Fast." },
  COLLECTOR = { "{NAME}: Every friend\nI met brought me\nhere. Let's go!" },
  STRATEGIST = { "{NAME}: The final\ncalculation says\nyour odds are low." },
  HEARTBREAK_KID = { "{NAME}: Welcome to\nthe main event.\vI'm the showstopper!" },
}

-- ------------------------------------------------------------------
-- After a battle with the player.  `won` is from the RIVAL's side.
-- ------------------------------------------------------------------

D.afterWin = {
  default    = {
    "{NAME}: That's\nanother win.",
    "{NAME}: Good fight.\nI still won.",
  },
  CHALLENGER = {
    "{NAME}: Told you.\nMaybe I'm finally\vready for the\vLEAGUE.",
    "{NAME}: Too easy.\nTrain harder.",
  },
  SPEEDRUNNER = {
    "{NAME}: Good. Now\nI'm going.",
    "{NAME}: Done. Next.",
  },
  COLLECTOR  = {
    "{NAME}: Fun! Your\n{MON} was tough.",
    "{NAME}: What a match!\nThanks!",
  },
  STRATEGIST = {
    "{NAME}: As\ncalculated.",
    "{NAME}: Model held.\nExpected.",
  },
  HEARTBREAK_KID = {
    "{NAME}: That's why\nthey call me the\vHeartbreak Kid.",
    "{NAME}: Your frenemy\nstole the show!",
  },
  girl       = { "{NAME}: Sorry,\ngirl. Nothing\vpersonal." },
}

D.afterLoss = {
  default    = {
    "{NAME}: I need\nbetter coverage.\vBack to training.",
    "{NAME}: Ouch. That\nhurt.",
  },
  CHALLENGER = {
    "{NAME}: Lucky.\nThat's all that\vwas. Luck.",
    "{NAME}: I'll be back.\nCount on it.",
  },
  SPEEDRUNNER = {
    "{NAME}: Whatever.\nBadges are the\vonly score.",
    "{NAME}: Waste of\ntime. Moving on.",
  },
  COLLECTOR  = {
    "{NAME}: Ha! Worth\nit just to see\vthat.",
    "{NAME}: You got me!\nNice team.",
  },
  STRATEGIST = {
    "{NAME}: My model\nwas wrong. I'll\vfix it.",
    "{NAME}: Data point\nlogged. Rematch\vlater.",
  },
  HEARTBREAK_KID = {
    "{NAME}: The show\nisn't over. I want\van encore!",
    "{NAME}: You stopped\nthe show tonight.",
  },
  girl       = { "{NAME}: Lost to a\ngirl. Back to\vtraining." },
}

-- Oak's-lab gauntlet lines.  Spoken only while the intro gauntlet is active
-- (main.lua talkGauntlet).  In these buckets {NAME} is the rival the player
-- must battle NEXT, not the speaker -- the speaker is the one waiting.
D.gauntletWait = {
  default     = {
    "{NAME} is up\nfirst. I'll go\vafter them.",
    "Patience. {NAME}\nfights next.",
  },
  CHALLENGER  = {
    "Beat {NAME}\nfirst. I want\vyou warmed up.",
    "Don't look at\nme. Face {NAME}.",
  },
  SPEEDRUNNER = {
    "{NAME}.\nNow. Go.",
    "Hurry up with\n{NAME}.",
  },
  COLLECTOR   = {
    "Say hi to\n{NAME} first.",
    "{NAME}'s excited.\nGo on!",
  },
  STRATEGIST  = {
    "You should\nhandle {NAME}\vfirst.",
    "Order matters.\n{NAME}, then me.",
  },
}
D.gauntletNeedStarter = {
  default = { "Talk to Oak and\nget your Pokemon\nfirst." },
}

D.gauntletChallenge = {
  default = {
    "{NAME}: My turn!\nLet's battle!",
    "{NAME}: You beat\nBlue. Now try me!",
    "{NAME}: Stand and\nfight!",
  },
  CHALLENGER = {
    "{NAME}: Out of the\nway, Oak. This is\vmine!",
    "{NAME}: Blue was\nwarm-up. I'm next!",
    "{NAME}: Don't hold\nback. I won't!",
  },
  SPEEDRUNNER = {
    "{NAME}: Fast fight.\nThen I'm out.",
    "{NAME}: Clock's\nticking. Battle!",
  },
  COLLECTOR = {
    "{NAME}: One more\nbattle before the\vroad!",
    "{NAME}: Show me that\nstarter!",
  },
  STRATEGIST = {
    "{NAME}: Lab data\nsays I win. Test.",
    "{NAME}: Starter vs\nstarter. Simple.",
  },
}

D.badgeNews = {
  [1] = { "{NAME}: Beat {LAST}.\nOne badge down." },
  [2] = { "{NAME}: That's two\nbadges. You're\vfalling behind." },
  [3] = { "{NAME}: Three. {LAST}\nwasn't even close." },
  [4] = { "{NAME}: Halfway.\nFour badges." },
  [5] = { "{NAME}: Five. I can\nsee the LEAGUE\vfrom here." },
  [6] = { "{NAME}: Six badges.\nHow many have\vyou got?" },
  [7] = { "{NAME}: Seven. One\nleft. {NEXT} is\vall that's between\vme and the LEAGUE." },
  [8] = { "{NAME}: Eight badges.\nI'm going to the\vLEAGUE. Try to\vkeep up." },
}

D.gymLoss = {
  default = { "{NAME}: {LAST} wiped\nme out. I'm going\vback to train." },
}

-- ------------------------------------------------------------------
-- Status screen strings.
-- ------------------------------------------------------------------

-- ------------------------------------------------------------------
-- Relationship flavour (1.33.0).  Keyed by the DERIVED state, then by
-- personality with a `default` arm, so a state nobody wrote a personality
-- line for still speaks.  NEUTRAL has no bucket on purpose: neutral is the
-- absence of a relationship, and a line about it would be noise.
--
-- These are prefixes offered to the greeting, never replacements for it.
-- ------------------------------------------------------------------

D.relationship = {
  FRIENDLY = {
    default = { "{NAME}: Good to see\na friendly face." },
    CHALLENGER = { "{NAME}: You're all\nright, you know\vthat?" },
    SPEEDRUNNER = { "{NAME}: I always\nhave a minute\vfor you." },
    COLLECTOR = { "{NAME}: My favourite\nperson to run\vinto out here!" },
    STRATEGIST = { "{NAME}: I enjoy our\nconversations." },
    HEARTBREAK_KID = { "{NAME}: I'm your\nfrenemy. That's a\vgood thing." },
  },
  COMPETITIVE = {
    default = { "{NAME}: I've been\nlooking forward\vto this." },
    CHALLENGER = { "{NAME}: I'm catching\nup to you." },
    SPEEDRUNNER = { "{NAME}: You're on my\nsplits now." },
    COLLECTOR = { "{NAME}: You push me\nharder than the\vGyms do." },
    STRATEGIST = { "{NAME}: I've started\nplanning around\vyou specifically." },
    HEARTBREAK_KID = { "{NAME}: Frenemies\nmake the best\vmain events." },
  },
  RIVALRY = {
    default = { "{NAME}: You and me.\nThis isn't over." },
    CHALLENGER = { "{NAME}: Every time I\nclose my eyes I\vsee that loss." },
    SPEEDRUNNER = { "{NAME}: You cost me\nmy run. I don't\vforget that." },
    COLLECTOR = { "{NAME}: I don't lose\nmy temper often.\vYou manage it." },
    STRATEGIST = { "{NAME}: I have three\nplans and all of\vthem end with you." },
  },
  RESPECT = {
    default = { "{NAME}: You earned\nthat. Really." },
    CHALLENGER = { "{NAME}: I hated\nlosing to you.\vI learned from it." },
    SPEEDRUNNER = { "{NAME}: You're fast.\nI'll give you\vthat much." },
    COLLECTOR = { "{NAME}: Your team\nfights like they\vtrust you." },
    STRATEGIST = { "{NAME}: I ran the\nnumbers. You're\vgood." },
  },
  HOSTILE = {
    default = { "{NAME}: I have\nnothing to say\vto you." },
    CHALLENGER = { "{NAME}: Don't. Just\ndon't." },
    SPEEDRUNNER = { "{NAME}: Move." },
    COLLECTOR = { "{NAME}: I'd rather\ntalk to the\vPokemon." },
    STRATEGIST = { "{NAME}: I've factored\nyou out of my\vplans." },
  },
  MENTOR = {
    default = { "{NAME}: Keep at it.\nYou'll get there." },
    CHALLENGER = { "{NAME}: You've got\nthe fire. Now get\vthe team." },
    SPEEDRUNNER = { "{NAME}: Cut the\ndetours. That's\vfree time." },
    COLLECTOR = { "{NAME}: Catch more.\nYou'll thank me\vat the League." },
    STRATEGIST = { "{NAME}: Watch your\nswitches. That's\vwhere you lose." },
  },
  ALLIED = {
    default = { "{NAME}: Say the word\nand I'm with you." },
    CHALLENGER = { "{NAME}: Anyone gives\nyou trouble, you\vcome find me." },
    SPEEDRUNNER = { "{NAME}: You're on my\nteam. That's rare." },
    COLLECTOR = { "{NAME}: Travelling\ntogether beats\vtravelling alone!" },
    STRATEGIST = { "{NAME}: Our teams\ncover each other\vwell. Remember that." },
  },
  -- 4.6.0's states. The suite reads R.STATES out of the model and demands a
  -- bucket for each, which is exactly why adding five states failed five
  -- checks the moment they existed: a state a rival cannot SAY anything about
  -- is a label in a menu, not a relationship. Every arm is written from the
  -- rival's side, about a specific person, because that is what the state is.
  DEVOTED = {
    default = { "{NAME}: There's\nnowhere I'd\vrather be." },
    CHALLENGER = { "{NAME}: I fight\nbetter knowing\vyou're nearby." },
    SPEEDRUNNER = { "{NAME}: I've stopped\nrushing. You're\vwhy." },
    COLLECTOR = { "{NAME}: Everything\nI've caught, I\vshowed you first." },
    STRATEGIST = { "{NAME}: I stopped\nplanning around\vyou. Now I plan\vwith you." },
    HEARTBREAK_KID = { "{NAME}: Don't tell\nanyone I said\vany of this." },
  },
  NEMESIS = {
    default = { "{NAME}: One of us\nhas to stop.\vIt won't be me." },
    CHALLENGER = { "{NAME}: I train for\nexactly one\vperson now." },
    SPEEDRUNNER = { "{NAME}: You've cost\nme more than\vtime." },
    COLLECTOR = { "{NAME}: I don't hate\nanyone. I made\van exception." },
    STRATEGIST = { "{NAME}: I know your\nteam better than\vyou do." },
  },
  PROTEGE = {
    default = { "{NAME}: Teach me\nthat one again?" },
    CHALLENGER = { "{NAME}: I lose to\nyou and I learn\vsomething. Again." },
    SPEEDRUNNER = { "{NAME}: Show me your\nroute. I'll keep\vup." },
    COLLECTOR = { "{NAME}: You always\nknow where the\vgood ones are." },
    STRATEGIST = { "{NAME}: I copied your\nswitch pattern.\vIt works." },
  },
  ADMIRER = {
    default = { "{NAME}: You're the\nbar. I'm still\vreaching." },
    CHALLENGER = { "{NAME}: Beat me again.\nI'll get closer\veach time." },
    SPEEDRUNNER = { "{NAME}: I've watched\nhow you move.\vIt's clean." },
    COLLECTOR = { "{NAME}: Your team is\nwhat mine wants\vto be." },
    STRATEGIST = { "{NAME}: I've studied\nevery loss. All\vof them are yours." },
  },
  BETRAYED = {
    default = { "{NAME}: I trusted them.\nThat was the\vmistake." },
    CHALLENGER = { "{NAME}: They stood next\nto me. Then they\vdidn't." },
    SPEEDRUNNER = { "{NAME}: I don't have\ntime for people\vlike that twice." },
    COLLECTOR = { "{NAME}: I'd have given\nthem anything.\vThey knew that." },
    STRATEGIST = { "{NAME}: I account for\nthem now. Like\vweather." },
  },
  JEALOUS = {
    default = { "{NAME}: We started at\nthe same place." },
    CHALLENGER = { "{NAME}: They're not\nbetter. They're\vjust ahead." },
    SPEEDRUNNER = { "{NAME}: Same route.\nSomehow they're\vtwo towns up." },
    COLLECTOR = { "{NAME}: Everything I\nwanted, they got\vfirst." },
    STRATEGIST = { "{NAME}: I've checked the\nnumbers twice. I\vhate them." },
  },
  FEARFUL = {
    default = { "{NAME}: I'd rather not\nrun into them." },
    CHALLENGER = { "{NAME}: I'll fight\nanyone. Ask me\vtomorrow." },
    SPEEDRUNNER = { "{NAME}: I route around\nwhere they are\vnow." },
    COLLECTOR = { "{NAME}: I keep the good\nones in the box\vwhen they're near." },
    STRATEGIST = { "{NAME}: There's no line\nthat wins. I've\vlooked." },
  },
  FAMILY = {
    default = { "{NAME}: They're family.\nThat's the whole\vanswer." },
    CHALLENGER = { "{NAME}: I'll batter them\nand then buy them\vlunch." },
    SPEEDRUNNER = { "{NAME}: I wait for them.\nOnly them." },
    COLLECTOR = { "{NAME}: Half of what I\nhave was theirs\vfirst." },
    STRATEGIST = { "{NAME}: I don't plan\naround family. I\vjust turn up." },
  },
  ESTRANGED = {
    default = { "{NAME}: We used to\ntalk more." },
    CHALLENGER = { "{NAME}: Something\nchanged. I know\vwhen. Not why." },
    SPEEDRUNNER = { "{NAME}: We were\ntravelling the\vsame way once." },
    COLLECTOR = { "{NAME}: I still have\nthe one you\vtraded me." },
    STRATEGIST = { "{NAME}: I took you\nout of my plans.\vIt was quiet." },
  },
}

-- ------------------------------------------------------------------
-- Mood flavour (1.35.0). Keyed by the DERIVED mood, then personality with a
-- `default` arm. CONTENT has no bucket on purpose: it is the absence of a mood
-- worth remarking on, and a line about it would be noise.
-- ------------------------------------------------------------------

D.mood = {
  CONFIDENT = {
    default = { "{NAME}: Everything's\ngoing my way." },
    CHALLENGER = { "{NAME}: I'm on a roll.\nDon't stop me now." },
    SPEEDRUNNER = { "{NAME}: Ahead of\nschedule. Finally." },
    COLLECTOR = { "{NAME}: Great week!\nGreat catches!" },
    STRATEGIST = { "{NAME}: The plan is\nworking. Naturally." },
  },
  DETERMINED = {
    default = { "{NAME}: I'm working\non something." },
    CHALLENGER = { "{NAME}: I lost. So\nI'm training.\vSimple as that." },
    SPEEDRUNNER = { "{NAME}: Bad split.\nI'm making it\vback up." },
    COLLECTOR = { "{NAME}: I'll be\nready next time.\vYou'll see." },
    STRATEGIST = { "{NAME}: I found the\nflaw. I'm fixing\vit." },
  },
  FRUSTRATED = {
    default = { "{NAME}: Nothing is\ngoing right." },
    CHALLENGER = { "{NAME}: I don't want\nto talk about it." },
    SPEEDRUNNER = { "{NAME}: This run is\nruined." },
    COLLECTOR = { "{NAME}: Rough patch.\nIt happens." },
    STRATEGIST = { "{NAME}: My numbers\nwere wrong. I hate\vthat." },
  },
  HUMBLED = {
    default = { "{NAME}: I had that\ncoming." },
    CHALLENGER = { "{NAME}: Alright.\nYou were better." },
    SPEEDRUNNER = { "{NAME}: I rushed it.\nMy own fault." },
    COLLECTOR = { "{NAME}: I got ahead\nof myself." },
    STRATEGIST = { "{NAME}: I planned for\neverything except\vthat." },
  },
  FOCUSED = {
    default = { "{NAME}: I'm in the\nmiddle of something." },
    CHALLENGER = { "{NAME}: Busy. Come\nback after." },
    SPEEDRUNNER = { "{NAME}: On the clock.\nTalk later." },
    COLLECTOR = { "{NAME}: I'm tracking\nsomething. Quiet!" },
    STRATEGIST = { "{NAME}: Mid-plan.\nDon't distract me." },
  },
  TRIUMPHANT = {
    default = { "{NAME}: I did it!" },
    CHALLENGER = { "{NAME}: Told you I'd\nget there!" },
    SPEEDRUNNER = { "{NAME}: New personal\nbest. Beat that." },
    COLLECTOR = { "{NAME}: Every one of\nthem got me here!" },
    STRATEGIST = { "{NAME}: Exactly as\ncalculated." },
  },
  RESTLESS = {
    default = { "{NAME}: I need\nsomething to do." },
    CHALLENGER = { "{NAME}: Somebody\nfight me." },
    SPEEDRUNNER = { "{NAME}: Dead time.\nI hate dead time." },
    COLLECTOR = { "{NAME}: Where to\nnext, I wonder?" },
    STRATEGIST = { "{NAME}: No plan\nrunning. Odd\vfeeling." },
  },
}

-- ------------------------------------------------------------------
-- Career flavour (2.2.0). Keyed by life path, then personality with a
-- `default` arm. Only rivals who have actually left the Gym Challenge have a
-- bucket here, so an ordinary rival can never speak a line that hints at a
-- destiny it has not taken (§22).
-- ------------------------------------------------------------------

D.career = {
  -- 4.7.0: a default line for each of the new lives. The originals keep their
  -- per-personality arms, which are better writing than a formula; these say
  -- the one thing that has to be said -- what this rival does now -- in the
  -- rival's own voice, built from the row's blurb so the sentence and the life
  -- can never disagree.
  LEGENDARY_HUNTER = {
    default = { "{NAME}: I'm chasing legends\nnow. It suits me\vbetter than badges." },
  },
  CELEBI_AGENT = {
    default = { "{NAME}: I'm keeping the shrine's watch\nnow. It suits me\vbetter than badges." },
  },
  ARCEUS_AMBASSADOR = {
    default = { "{NAME}: I'm carrying a creed across Kanto\nnow. It suits me\vbetter than badges." },
  },
  LEAGUE_CHAMPION = {
    default = { "{NAME}: I'm defending the title\nnow. It suits me\vbetter than badges." },
  },
  ELITE_ASPIRANT = {
    default = { "{NAME}: I'm training for the Elite Four\nnow. It suits me\vbetter than badges." },
  },
  TOURNAMENT_CIRCUIT = {
    default = { "{NAME}: Living on the tournament circuit\nis what I do now." },
  },
  DUELIST = {
    default = { "{NAME}: I'm answering every challenge\nnow. It suits me\vbetter than badges." },
  },
  GYM_LEADER_HOPEFUL = {
    default = { "{NAME}: I'm building a Gym of their own\nnow. It suits me\vbetter than badges." },
  },
  REMATCH_HUNTER = {
    default = { "{NAME}: Chasing every trainer who beat them\nis what I do now." },
  },
  UNDERDOG = {
    default = { "{NAME}: I'm winning with less\nnow. It suits me\vbetter than badges." },
  },
  SPARRING_PARTNER = {
    default = { "{NAME}: I'm making other trainers better\nnow. It suits me\vbetter than badges." },
  },
  MONO_TYPE_PURIST = {
    default = { "{NAME}: Running one type and nothing else\nis what I do now." },
  },
  STRATEGIST = {
    default = { "{NAME}: I'm solving battles on paper\nnow. It suits me\vbetter than badges." },
  },
  SPEEDRUNNER_PATH = {
    default = { "{NAME}: I'm doing it all faster\nnow. It suits me\vbetter than badges." },
  },
  SHINY_HUNTER = {
    default = { "{NAME}: I'm hunting for shinies\nnow. It suits me\vbetter than badges." },
  },
  SAFARI_WARDEN = {
    default = { "{NAME}: I'm working the Safari Zone\nnow. It suits me\vbetter than badges." },
  },
  DAYCARE_KEEPER = {
    default = { "{NAME}: Minding other trainers' Pokemon\nis what I do now." },
  },
  FOSSIL_REVIVER = {
    default = { "{NAME}: I'm bringing back the long dead\nnow. It suits me\vbetter than badges." },
  },
  EEVEE_SPECIALIST = {
    default = { "{NAME}: Following every branch of one line\nis what I do now." },
  },
  BUG_CATCHER_LIFE = {
    default = { "{NAME}: Never growing out of bug catching\nis what I do now." },
  },
  FISHERMAN = {
    default = { "{NAME}: I'm fishing every water in Kanto\nnow. It suits me\vbetter than badges." },
  },
  SURFER = {
    default = { "{NAME}: I'm living on the water\nnow. It suits me\vbetter than badges." },
  },
  MOUNTAINEER = {
    default = { "{NAME}: Climbing what others walk around\nis what I do now." },
  },
  CAVE_DWELLER = {
    default = { "{NAME}: I'm living underground\nnow. It suits me\vbetter than badges." },
  },
  NIGHT_WALKER = {
    default = { "{NAME}: I'm travelling only after dark\nnow. It suits me\vbetter than badges." },
  },
  DEX_COMPLETIONIST = {
    default = { "{NAME}: I'm filling every last entry\nnow. It suits me\vbetter than badges." },
  },
  TYPE_THEORIST = {
    default = { "{NAME}: I'm working out what beats what\nnow. It suits me\vbetter than badges." },
  },
  MOVE_TUTOR = {
    default = { "{NAME}: I'm teaching moves for a living\nnow. It suits me\vbetter than badges." },
  },
  BREEDING_THEORIST = {
    default = { "{NAME}: I'm studying inheritance\nnow. It suits me\vbetter than badges." },
  },
  WEATHER_WATCHER = {
    default = { "{NAME}: I'm following the weather\nnow. It suits me\vbetter than badges." },
  },
  CARTOGRAPHER = {
    default = { "{NAME}: I'm mapping every road\nnow. It suits me\vbetter than badges." },
  },
  HISTORIAN = {
    default = { "{NAME}: I'm writing down what happened\nnow. It suits me\vbetter than badges." },
  },
  ARCHIVIST = {
    default = { "{NAME}: I'm keeping the League's records\nnow. It suits me\vbetter than badges." },
  },
  STATISTICIAN = {
    default = { "{NAME}: Counting what everyone else guesses\nis what I do now." },
  },
  MERCHANT = {
    default = { "{NAME}: I'm selling from town to town\nnow. It suits me\vbetter than badges." },
  },
  AUCTIONEER = {
    default = { "{NAME}: I'm running the auction block\nnow. It suits me\vbetter than badges." },
  },
  TRADER = {
    default = { "{NAME}: I'm trading with anyone, anywhere\nnow. It suits me\vbetter than badges." },
  },
  ITEM_MAKER = {
    default = { "{NAME}: I'm making things by hand\nnow. It suits me\vbetter than badges." },
  },
  HERBALIST = {
    default = { "{NAME}: I'm brewing bitter medicine\nnow. It suits me\vbetter than badges." },
  },
  NURSE = {
    default = { "{NAME}: I'm healing whoever walks in\nnow. It suits me\vbetter than badges." },
  },
  MECHANIC = {
    default = { "{NAME}: I'm keeping Kanto moving\nnow. It suits me\vbetter than badges." },
  },
  SAILOR = {
    default = { "{NAME}: I'm working the boats\nnow. It suits me\vbetter than badges." },
  },
  PILOT = {
    default = { "{NAME}: I'm carrying urgent mail by air\nnow. It suits me\vbetter than badges." },
  },
  PERFORMER = {
    default = { "{NAME}: I'm putting on a show\nnow. It suits me\vbetter than badges." },
  },
  IDOL = {
    default = { "{NAME}: I'm being adored\nnow. It suits me\vbetter than badges." },
  },
  COMMENTATOR = {
    default = { "{NAME}: I'm calling other people's fights\nnow. It suits me\vbetter than badges." },
  },
  JOURNALIST = {
    default = { "{NAME}: I'm chasing the story\nnow. It suits me\vbetter than badges." },
  },
  STORYTELLER = {
    default = { "{NAME}: Telling it better than it happened\nis what I do now." },
  },
  MUSICIAN = {
    default = { "{NAME}: I'm playing for whoever listens\nnow. It suits me\vbetter than badges." },
  },
  ARTIST = {
    default = { "{NAME}: I'm painting what they see\nnow. It suits me\vbetter than badges." },
  },
  CHEF = {
    default = { "{NAME}: Feeding trainers and Pokemon alike\nis what I do now." },
  },
  OFFICER = {
    default = { "{NAME}: I'm keeping the peace\nnow. It suits me\vbetter than badges." },
  },
  DETECTIVE = {
    default = { "{NAME}: I'm following what does not add up\nnow. It suits me\vbetter than badges." },
  },
  BODYGUARD = {
    default = { "{NAME}: Standing between trouble and someone else\nis what I do now." },
  },
  BOUNTY_HUNTER = {
    default = { "{NAME}: Collecting on other people's debts\nis what I do now." },
  },
  SMUGGLER = {
    default = { "{NAME}: I'm moving what should not move\nnow. It suits me\vbetter than badges." },
  },
  ROCKET_EXECUTIVE = {
    default = { "{NAME}: I'm running Rocket operations\nnow. It suits me\vbetter than badges." },
  },
  ROCKET_DEFECTOR = {
    default = { "{NAME}: I'm living down what they did\nnow. It suits me\vbetter than badges." },
  },
  VIGILANTE = {
    default = { "{NAME}: Doing what the officers will not\nis what I do now." },
  },
  SWORN_RIVAL = {
    default = { "{NAME}: I'm living to beat one person\nnow. It suits me\vbetter than badges." },
  },
  AVENGER = {
    default = { "{NAME}: I'm paying somebody back\nnow. It suits me\vbetter than badges." },
  },
  RECLUSE = {
    default = { "{NAME}: I'm keeping away from everyone\nnow. It suits me\vbetter than badges." },
  },
  PROTECTOR = {
    default = { "{NAME}: I'm keeping one person safe\nnow. It suits me\vbetter than badges." },
  },
  FAMILY_TRAINER = {
    default = { "{NAME}: I'm training alongside family\nnow. It suits me\vbetter than badges." },
  },
  MENTOR_PATH = {
    default = { "{NAME}: I'm raising the next one up\nnow. It suits me\vbetter than badges." },
  },
  DISCIPLE = {
    default = { "{NAME}: I'm following someone better\nnow. It suits me\vbetter than badges." },
  },
  DEVOTED_PARTNER = {
    default = { "{NAME}: Travelling with the one they love\nis what I do now." },
  },
  PEACEMAKER = {
    default = { "{NAME}: I'm talking other people down\nnow. It suits me\vbetter than badges." },
  },
  LONER = {
    default = { "{NAME}: I'm needing nobody\nnow. It suits me\vbetter than badges." },
  },
  SHRINE_KEEPER = {
    default = { "{NAME}: I'm tending an old shrine\nnow. It suits me\vbetter than badges." },
  },
  SPIRIT_MEDIUM = {
    default = { "{NAME}: I'm speaking for the dead\nnow. It suits me\vbetter than badges." },
  },
  CULTIST = {
    default = { "{NAME}: Believing something the rest do not\nis what I do now." },
  },
  PROPHET = {
    default = { "{NAME}: I'm warning anyone who listens\nnow. It suits me\vbetter than badges." },
  },
  MOON_WATCHER = {
    default = { "{NAME}: I'm waiting on Mt Moon\nnow. It suits me\vbetter than badges." },
  },
  RUIN_SEEKER = {
    default = { "{NAME}: I'm reading walls nobody else can\nnow. It suits me\vbetter than badges." },
  },
  DRAGON_SEEKER = {
    default = { "{NAME}: I'm looking for dragons\nnow. It suits me\vbetter than badges." },
  },
  BEAST_TRACKER = {
    default = { "{NAME}: I'm tracking the three that run\nnow. It suits me\vbetter than badges." },
  },
  FARMER = {
    default = { "{NAME}: Growing what everyone else buys\nis what I do now." },
  },
  INNKEEPER = {
    default = { "{NAME}: I'm keeping a room ready\nnow. It suits me\vbetter than badges." },
  },
  TEACHER = {
    default = { "{NAME}: Teaching children before they set out\nis what I do now." },
  },
  LIGHTHOUSE_KEEPER = {
    default = { "{NAME}: I'm keeping a light on\nnow. It suits me\vbetter than badges." },
  },
  GARDENER = {
    default = { "{NAME}: I'm keeping things growing\nnow. It suits me\vbetter than badges." },
  },
  HERMIT = {
    default = { "{NAME}: I'm living apart on purpose\nnow. It suits me\vbetter than badges." },
  },
  PILGRIM = {
    default = { "{NAME}: I'm walking to every holy place\nnow. It suits me\vbetter than badges." },
  },
  COLLECTOR_OF_ODDITIES = {
    default = { "{NAME}: I'm collecting the strange\nnow. It suits me\vbetter than badges." },
  },
  GAMBLER = {
    default = { "{NAME}: Living on the Game Corner floor\nis what I do now." },
  },
  SCAVENGER = {
    default = { "{NAME}: I'm living off what others drop\nnow. It suits me\vbetter than badges." },
  },
  VOLUNTEER = {
    default = { "{NAME}: I'm helping wherever it is needed\nnow. It suits me\vbetter than badges." },
  },
  APPRENTICE_SMITH = {
    default = { "{NAME}: I'm learning a trade with fire\nnow. It suits me\vbetter than badges." },
  },
  TEAM_ROCKET = {
    default = { "{NAME}: Don't look at\nme like that. They\vpay, and nobody else\vwas offering." },
    CHALLENGER = { "{NAME}: I lost enough\nfair fights. I stopped\vhaving fair fights." },
    SPEEDRUNNER = { "{NAME}: Shortest route\nto the top. You\vtaught me that." },
    COLLECTOR = { "{NAME}: They let me\nkeep whatever I take.\vThat's the deal." },
    STRATEGIST = { "{NAME}: I did the sums.\nThis was the winning\vline." },
  },
  BREEDER = {
    default = { "{NAME}: I realised I\nenjoy raising Pokemon\vfar more than beating\vGym Leaders." },
    CHALLENGER = { "{NAME}: Badges stopped\nmeaning anything.\vThese two didn't." },
    SPEEDRUNNER = { "{NAME}: Turns out the\nrace wasn't the\vpoint after all." },
    COLLECTOR = { "{NAME}: Every one of\nthem is somebody's\vfavourite. Even mine." },
    STRATEGIST = { "{NAME}: Raising them\nproperly is a much\vharder problem." },
  },
  RESEARCHER = {
    default = { "{NAME}: I'd rather\nunderstand them than\vbeat them." },
    CHALLENGER = { "{NAME}: Don't laugh.\nThe notes are\vgetting good." },
    SPEEDRUNNER = { "{NAME}: I stopped\nrushing and started\vlooking." },
    COLLECTOR = { "{NAME}: Catching was\nnever the interesting\vpart." },
    STRATEGIST = { "{NAME}: Finally, work\nwhere being right\vmatters." },
  },
  EXPLORER = {
    default = { "{NAME}: Kanto's bigger\nthan eight Gyms." },
    CHALLENGER = { "{NAME}: There's nothing\nleft to prove on\vthat road." },
    SPEEDRUNNER = { "{NAME}: No route. No\nsplits. It's better\vthis way." },
    COLLECTOR = { "{NAME}: I want to see\nwhere they all\vactually live." },
    STRATEGIST = { "{NAME}: The map has\ngaps. I'm filling\vthem in." },
  },
  RETIRED = {
    default = { "{NAME}: I don't do\nthe Gym thing\vanymore." },
    CHALLENGER = { "{NAME}: I gave it\neverything. It\vwasn't enough." },
    SPEEDRUNNER = { "{NAME}: I was always\nin a hurry. Not\vsure why now." },
    COLLECTOR = { "{NAME}: Just these few\nnow. That's plenty." },
    STRATEGIST = { "{NAME}: I ran out of\nplans. It's quite\vrestful." },
  },
  OAK_ASSISTANT = {
    default = { "{NAME}: The Professor\nneeds the data more\vthan I needed a badge." },
    CHALLENGER = { "{NAME}: Turns out I'm\nbetter at the\vquestions than the\vfights." },
    SPEEDRUNNER = { "{NAME}: Research is\nslow. I'm learning\vto like that." },
    COLLECTOR = { "{NAME}: Every entry I\nfill in is one nobody\vhad before!" },
    STRATEGIST = { "{NAME}: Finally, work\nwhere the answer is\vcheckable." },
  },
  TOWER_CARETAKER = {
    default = { "{NAME}: Someone should\nlook after them.\vIt may as well be me." },
    CHALLENGER = { "{NAME}: I came here\nangry. I stayed for\va different reason." },
    SPEEDRUNNER = { "{NAME}: Nobody here is\nin a hurry. It took\vme a while." },
    COLLECTOR = { "{NAME}: They were all\nsomebody's favourite\vonce." },
    STRATEGIST = { "{NAME}: There's no\nstrategy here. That's\vrather the point." },
  },
  GHOST_RESEARCHER = {
    default = { "{NAME}: There's more\nin this tower than\vgrief." },
    CHALLENGER = { "{NAME}: You can't\nintimidate something\vthat's already gone." },
    SPEEDRUNNER = { "{NAME}: They don't\nmove on a timer.\vI had to slow down." },
    COLLECTOR = { "{NAME}: Hardest things\nin Kanto to get a\vgood look at." },
    STRATEGIST = { "{NAME}: Half my notes\ncontradict the other\vhalf. Wonderful." },
  },
  GYM_ASSISTANT = {
    default = { "{NAME}: Maybe I don't\nwant to beat the Gym\vLeaders. Maybe I want\vto become one." },
    CHALLENGER = { "{NAME}: I'm on the\nother side of the\vdoor now." },
    SPEEDRUNNER = { "{NAME}: I've seen a\nthousand challengers\vmake my old mistakes." },
    COLLECTOR = { "{NAME}: One type, done\nproperly. It's a\vdifferent hobby." },
    STRATEGIST = { "{NAME}: Designing the\ntest beats sitting\vit." },
  },
  CENTER_ASSISTANT = {
    default = { "{NAME}: Someone has to\npatch them up after\vall that." },
    CHALLENGER = { "{NAME}: I hurt enough\nof them learning.\vThis balances it." },
    SPEEDRUNNER = { "{NAME}: Everyone's in\na rush when they come\vthrough that door." },
    COLLECTOR = { "{NAME}: I get to meet\nevery Pokemon in\vKanto eventually!" },
    STRATEGIST = { "{NAME}: Triage is just\nprioritisation with\vstakes." },
  },
  MART_WORKER = {
    default = { "{NAME}: It's a job.\nIt's honest. I sleep\vfine." },
    CHALLENGER = { "{NAME}: Don't. I know\nwhat you're thinking." },
    SPEEDRUNNER = { "{NAME}: Shift starts\nat nine. Some\vschedules are fine." },
    COLLECTOR = { "{NAME}: I know exactly\nwhat every ball is\vworth now." },
    STRATEGIST = { "{NAME}: You'd be\namazed what stock\vdata tells you." },
  },
  BATTLE_COACH = {
    default = { "{NAME}: Winning is good.\nTeaching someone why\vthey won is better." },
  },
  RANGER = {
    default = { "{NAME}: The routes need\nlooking after more\vthan the trophy room." },
  },
  COURIER = {
    default = { "{NAME}: I know every\nshortcut between here\vand the next town." },
  },
  PHOTOGRAPHER = {
    default = { "{NAME}: Some Pokemon\nshould be captured in\va picture, not a ball." },
  },
  TYPE_SPECIALIST = {
    default = { "{NAME}: One type is not\na limitation. It's a\vlifetime of depth." },
  },
}

-- ------------------------------------------------------------------
-- After the arc (2.4.0 -- §19, §28, §29). Keyed by what the rival WAS, not by
-- what it is now, because the interesting thing about a redeemed Rocket or a
-- returning explorer is where they have been.
-- ------------------------------------------------------------------

D.formerly = {
  TEAM_ROCKET = {
    default = { "{NAME}: I was with them.\nI'm not anymore.\vThat's all I'll say." },
    CHALLENGER = { "{NAME}: I'd rather lose\nhonestly than win\vthat way again." },
    SPEEDRUNNER = { "{NAME}: Fastest route\nisn't always the one\vyou can live with." },
    COLLECTOR = { "{NAME}: I gave back what\nI could. Not all of\vit was mine to give." },
    STRATEGIST = { "{NAME}: My reasoning was\nsound. My premises\vwere rotten." },
  },
  RETURNED = {
    default = { "{NAME}: I'm back on the\nladder. Different\vteam, though." },
    CHALLENGER = { "{NAME}: Miss me? The\nbadges aren't going\vto win themselves." },
    SPEEDRUNNER = { "{NAME}: Late start. I\nwork well under\vpressure." },
    COLLECTOR = { "{NAME}: I found what I\nwas looking for. Now\vfor the rest." },
    STRATEGIST = { "{NAME}: New plan. It\naccounts for the last\vone failing." },
  },
}

D.states = {
  IDLE = "Idle",
  TRAVELLING = "Travelling",
  TRAINING = "Training",
  SEEKING_GYM = "Seeking Gym",
  CHALLENGING_GYM = "At Gym",
  RETURNING_FROM_GYM = "Leaving Gym",
  SEEKING_PLAYER = "Looking for you",
  CHALLENGING_PLAYER = "Challenging you",
  HEALING = "Healing",
  EXPLORING = "Exploring",
  DEFEATED = "Beaten",
  LEAGUE_READY = "League bound",
}


-- 5.0.5 dialogue expansion. Appended instead of replacing older buckets so
-- personality/state-specific writing from previous versions remains available.
local function append(bucket, key, rows)
  if type(bucket) ~= "table" then return end
  bucket[key] = bucket[key] or {}
  for _, line in ipairs(rows) do bucket[key][#bucket[key] + 1] = line end
end

append(D.greeting.IDLE, "default", {
  "{NAME}: Been a while.\nHow's your team?",
  "{NAME}: Kanto feels\nbigger every day.",
  "{NAME}: I needed a\nquiet minute.",
  "{NAME}: Heard anything\ninteresting lately?",
})
append(D.greeting.IDLE, "CHALLENGER", {
  "{NAME}: Don't think\nI've forgotten our\vlast battle.",
  "{NAME}: I'm getting\nstronger. Are you?",
  "{NAME}: One good fight\ncan change a lot.",
})
append(D.greeting.IDLE, "SPEEDRUNNER", {
  "{NAME}: Lost twelve\nseconds on that\vlast route.",
  "{NAME}: I found a\ncleaner line east.",
  "{NAME}: Rest stop.\nVery temporary.",
})
append(D.greeting.IDLE, "COLLECTOR", {
  "{NAME}: My boxes are\ngetting crowded!",
  "{NAME}: I saw something\nrare nearby.",
  "{NAME}: Every route has\none surprise.",
})
append(D.greeting.IDLE, "STRATEGIST", {
  "{NAME}: Your lead is\nstill hard to read.",
  "{NAME}: I've changed\nthree moves since\vwe last fought.",
  "{NAME}: Coverage first.\nConfidence second.",
})
append(D.greeting.TRAVELLING, "default", {
  "{NAME}: Long road ahead.\nGood thing I packed.",
  "{NAME}: I'm following\nthe route properly.",
  "{NAME}: Next stop,\n{CITY}. Eventually.",
})
append(D.greeting.TRAINING, "default", {
  "{NAME}: One more set.\nThen we move on.",
  "{NAME}: This team still\nhas room to grow.",
  "{NAME}: Training isn't\nglamorous. It works.",
})
append(D.greeting.EXPLORING, "default", {
  "{NAME}: Found a path\nI missed before.",
  "{NAME}: I'm checking\nevery corner.",
  "{NAME}: You never know\nwhat's off the road.",
})
append(D.challenge, "default", {
  "{NAME}: You look ready.\nProve it.",
  "{NAME}: I've got time\nfor one battle.",
  "{NAME}: No excuses.\nLet's battle.",
  "{NAME}: Let's make this\none worth remembering.",
})
append(D.challenge, "CHALLENGER", {
  "{NAME}: I came looking\nfor a real fight.",
  "{NAME}: This time I\nfinish it.",
  "{NAME}: Let's settle\nwho improved more.",
})
append(D.challenge, "COLLECTOR", {
  "{NAME}: I caught someone\nnew. Want to meet\vthem?",
  "{NAME}: My latest catch\nneeds a proper test.",
})
append(D.challenge, "STRATEGIST", {
  "{NAME}: New plan.\nSame opponent.",
  "{NAME}: I fixed the hole\nyou found last time.",
})
append(D.afterWin, "default", {
  "{NAME}: That was close.\nGood battle.",
  "{NAME}: Keep training.\nI expect a rematch.",
  "{NAME}: My team earned\nthat one.",
})
append(D.afterLoss, "default", {
  "{NAME}: Fair enough.\nYou earned it.",
  "{NAME}: I know exactly\nwhat to fix now.",
  "{NAME}: Next time will\nbe different.",
})
append(D.afterWin, "COLLECTOR", {
  "{NAME}: They did great!\nI'm proud of them.",
})
append(D.afterLoss, "COLLECTOR", {
  "{NAME}: Still proud of\nmy team. Good fight!",
})
append(D.afterWin, "STRATEGIST", {
  "{NAME}: Adjustment\nconfirmed.",
})
append(D.afterLoss, "STRATEGIST", {
  "{NAME}: Back to the\nnotebook.",
})

-- 5.0.8: the generated expansion. Kept in its own file because it is a
-- COMPOSER over two clause banks rather than a list of strings, and because
-- appending it here rather than editing the buckets above means nothing
-- written by hand before 5.0.8 can be displaced by it.
req("data/dialogue_extra")(D)

return D
