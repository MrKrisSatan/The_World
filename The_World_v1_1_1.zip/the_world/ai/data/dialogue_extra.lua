local req = ...
local VOICES = req("data/voices")

-- GENERATED DIALOGUE (5.0.8)
-- ==================================================================
-- Every rival except Shawn used to share four or five authored lines per
-- (state, personality) cell, and the twelve personalities added after 1.x had
-- no arms at all -- they fell through to `default` and therefore all spoke in
-- the same voice. That is why only Shawn read as a person.
--
-- The fix is a CROSS PRODUCT of two authored banks, not a template:
--
--     SITUATIONS[bucket][key]   what is happening -- owns every {TOKEN}
--     VOICES[personality][reg]  who it is happening to -- owns the attitude
--
-- A cell's line list is situations x voices, capped. Ten situations against
-- ten voice clauses is a hundred distinct sentences for one cell; the caps
-- below are what keep the total near ten thousand instead of near a hundred
-- thousand.
--
-- WHY GENERATE RATHER THAN SHIP THE STRINGS
-- Shipping ten thousand expanded strings is about 1.4 MB of Lua source to
-- parse at every boot, on a mobile budget, for exactly the same table this
-- file builds from 40 KB. It is also unreviewable: nobody diffs ten thousand
-- lines, so a bad clause hides forever. Here a bad clause is one line in one
-- bank.
--
-- APPEND, NEVER REPLACE. Everything authored before 5.0.8 stays at the front
-- of its list. Nothing here can silence a line somebody wrote by hand.
--
-- §36 (dead content is the failure mode of adding content): tests/
-- dialogue_volume_test.lua counts what this file actually materialises and
-- fails if any cell is empty, if the total falls under 10,000, or if two
-- cells came out identical -- so "we added ten thousand lines" is a measured
-- claim rather than a hopeful one.

local X = {}

-- ------------------------------------------------------------------
-- Text-box fitting
-- ------------------------------------------------------------------
-- src/BoxFit.lua owns the column budgets and the \n / \v / \f rules. It is
-- shared with data/rocket_dialogue.lua so the two banks cannot drift apart on
-- what fits in a box.

local BoxFit = req("src/BoxFit")
local wrap = function(text, named)
  return BoxFit.join(BoxFit.rows(text, named and BoxFit.ROW_NAMED or BoxFit.ROW))
end
local rewrap = BoxFit.rewrap

-- ------------------------------------------------------------------
-- Composition
-- ------------------------------------------------------------------
-- src/ClauseMix.lua owns the cross-product walk. Read the comment at the top
-- of it before changing anything here: the first version of this pairing
-- delivered a third of the lines it claimed and nothing failed.

local ClauseMix = req("src/ClauseMix")

local function compose(situations, voices, cap, named)
  return ClauseMix.cross(situations, voices, cap, function(s, v)
    return (named and "{NAME}: " or "") .. wrap(s .. " " .. v, named)
  end)
end

-- ------------------------------------------------------------------
-- SITUATIONS -- what the rival is doing. These own the tokens.
-- ------------------------------------------------------------------

X.greeting = {
  IDLE = {
    "Standing still for a moment.",
    "Nothing pressing right now.",
    "Taking stock before the next move.",
    "Between things, if you must know.",
    "I have a minute. Not many.",
    "Just thinking about {NEXT}.",
    "Catching my breath.",
    "Working out what comes next.",
    "{MON} is dozing. I am not.",
    "Holding position.",
  },
  TRAVELLING = {
    "On the road to {CITY}.",
    "{CITY} next, if the routes behave.",
    "Halfway to {CITY}.",
    "{NEXT} is waiting in {CITY}.",
    "Walking. It is mostly walking.",
    "A long stretch ahead before {CITY}.",
    "Moving. Do not slow me down.",
    "The road to {CITY} is longer than the map says.",
    "Two routes out from {CITY}.",
    "{MON} walks beside me the whole way.",
  },
  TRAINING = {
    "Training. {MON} is doing the hard part.",
    "Grinding out a few more levels.",
    "Drilling the same matchup again.",
    "Working {MON} up to where I need it.",
    "Levels first, {NEXT} after.",
    "This is the boring part. It is also the important part.",
    "Reps until it is automatic.",
    "{MON} is nearly there.",
    "Fixing what {NEXT} would punish.",
    "Training. Come back when I am sharper.",
  },
  SEEKING_GYM = {
    "{NEXT}'s Gym is just ahead.",
    "Badge number {N} is in {CITY}.",
    "I am walking into {NEXT}'s Gym today.",
    "{CITY}'s Gym, then whatever comes after.",
    "{NEXT} has had a long enough run.",
    "That badge has my name on it.",
    "{NEXT} is the last thing between me and {N} badges.",
    "Gym doors, straight ahead.",
    "I have {BADGES}. {NEXT} makes it more.",
    "{CITY} first. Then the rest of Kanto.",
  },
  HEALING = {
    "My team is beaten up.",
    "{MON} took the worst of it.",
    "Give me a minute at the Centre.",
    "Everybody needs patching.",
    "We are all still standing. Barely.",
    "Healing. Then back out.",
    "{MON} earned this rest.",
    "Bad fight. Good recovery.",
    "Nobody battles on empty.",
    "Ten minutes and we go again.",
  },
  EXPLORING = {
    "Just looking around.",
    "There is more here than the route markers say.",
    "Checking a corner I skipped.",
    "I found something off the path.",
    "Wandering, deliberately.",
    "Kanto hides things badly.",
    "Nothing on the map for this bit.",
    "Following a hunch and a hedge.",
    "Off the road for a while.",
    "This detour is going somewhere.",
  },
  DEFEATED = {
    "I lost.",
    "That did not go my way.",
    "Beaten, and I know why.",
    "{MON} gave everything. It was not enough.",
    "You had my number today.",
    "Down, and taking notes.",
    "That one hurt.",
    "I do not enjoy saying it. I lost.",
    "Not my day.",
    "You beat me fairly.",
  },
  LEAGUE_READY = {
    "Eight badges. All of them.",
    "I am League bound.",
    "No Gym left to beat.",
    "Indigo Plateau is next.",
    "The Elite Four, and then whoever is left.",
    "Eight badges and a full team.",
    "I have run out of Gyms.",
    "Everything since Pallet was for this.",
    "The badge case is full.",
    "Nothing between me and the LEAGUE now.",
  },
  CHAMPION = {
    "I cleared the LEAGUE.",
    "Champion. That is the word for it.",
    "The Elite Four are behind me.",
    "I hold the title.",
    "Four battles and a crown.",
    "I sat in that chair. It fits.",
    "The LEAGUE is beaten.",
    "Champion of this region.",
    "Nobody is left above me.",
    "I went all the way.",
  },
}

X.challenge = {
  "Battle me.",
  "You. Me. Right now.",
  "I have been looking for you.",
  "Let's settle this.",
  "Perfect timing. Fight me.",
  "Six of mine against six of yours.",
  "No running this time.",
  "I want a real match.",
  "Send out your best.",
  "I challenge you.",
  "Enough talking. Battle.",
  "Right here. Right now.",
}

X.scoreRemind = {
  "I am {WINS}-{LOSSES} against you.",
  "The record says {RECORD}. Mine.",
  "{WINS} wins to your {LOSSES}.",
  "I keep count. {RECORD}.",
  "You are {LOSSES} up on me. For now.",
  "Our record stands at {RECORD}.",
  "{WINS} times I have beaten you.",
  "Do not make me recite it. {RECORD}.",
  "We are {WINS}-{LOSSES} and I remember every one.",
  "The scoreline is {RECORD}.",
}

X.eliteChampion = {
  "You are looking at the Champion.",
  "The title is mine. Come and take it.",
  "I beat the Elite Four to stand here.",
  "This is the last battle in Kanto.",
  "Everyone who came before you lost here.",
  "The crown is heavier than it looks.",
  "You made it to the top. Now beat the top.",
  "Champion's seat. Champion's rules.",
  "One battle decides the region.",
  "I am not giving this up quietly.",
}

X.afterWin = {
  "That is another win.",
  "Good fight. I still took it.",
  "Beaten, and beaten properly.",
  "My team earned that.",
  "Closer than the scoreline.",
  "That is how I wanted it to go.",
  "You made me work. Not enough.",
  "Win recorded.",
  "{MON} closed that out.",
  "I will take it.",
  "You lasted. That counts for something.",
  "Done.",
}

X.afterLoss = {
  "You win.",
  "Fair. You were better today.",
  "I have no complaints.",
  "Beaten straight up.",
  "You found the gap.",
  "That is a loss. I will own it.",
  "{MON} did what it could.",
  "You earned every bit of that.",
  "I got outplayed.",
  "Take the win.",
  "Not close, in the end.",
  "You were the better trainer today.",
}

X.gymLoss = {
  "{LAST} wiped me out.",
  "{LAST}'s Gym beat me.",
  "I lost at {LAST}'s Gym.",
  "{LAST} was ready for everything I had.",
  "Beaten at the Gym. Going back to train.",
  "{LAST} did not even look worried.",
  "That Gym cost me the day.",
  "I was underlevelled for {LAST}.",
  "Badge {N} is going to take another attempt.",
  "{LAST} sent me home.",
}

-- No {NAME}: prefix. src/manager/Gauntlet.lua rebinds {NAME} to the rival who
-- is UP NEXT, not to the speaker -- so a name prefix here would put somebody
-- else's name in front of this rival's sentence.
X.gauntletWait = {
  "{NAME} is up first.",
  "Face {NAME} before you get to me.",
  "Wait your turn. {NAME} is next.",
  "{NAME} goes ahead of me.",
  "Patience. {NAME} fights first.",
  "Order is order. {NAME}, then me.",
  "{NAME} has been waiting longer.",
  "You get to me after {NAME}.",
}

X.gauntletChallenge = {
  "My turn.",
  "You beat the others. Now try me.",
  "Stand and fight.",
  "I am next in line.",
  "Step up. I am waiting.",
  "That was the warm-up. I am not.",
  "My turn at last.",
  "Do not stop now.",
}

-- Per BADGE COUNT, not one shared bank. A shared bank is what the first draft
-- of this file had, and it made every cell of badgeNews[1..8] byte-identical:
-- eight milestones, one sentence, the tokens doing all the work. The eighth
-- badge is the biggest moment a rival has before the LEAGUE and it should not
-- read like the first.
X.badgeNews = {
  [1] = {
    "First badge. {LAST} went down.",
    "One badge. It starts here.",
    "{LAST} is beaten. That is one.",
    "The badge case is not empty anymore.",
    "One down, seven to go.",
    "My first. I will remember {LAST}.",
    "That is badge one, and it counts.",
    "I have started properly now.",
  },
  [2] = {
    "Two badges. {LAST} made it two.",
    "That is two. The pattern is holding.",
    "{LAST} lasted longer than the first.",
    "Two badges, and I am not slowing.",
    "Second badge. You are falling behind.",
    "Two down. Six left.",
    "{LAST} is beaten. Two in the case.",
    "Badge two, and {NEXT} is already on my mind.",
  },
  [3] = {
    "Three badges now.",
    "{LAST} was not even close.",
    "Three. This is starting to feel real.",
    "Badge three. The easy ones are over.",
    "{LAST} beaten, three in hand.",
    "Three down, and the road gets harder.",
    "That is three. Keep counting.",
    "Three badges, and {NEXT} is next.",
  },
  [4] = {
    "Halfway. Four badges.",
    "Four. That is the midpoint.",
    "{LAST} made it four.",
    "Four badges, four to go.",
    "Half the case is full.",
    "Badge four. No turning back now.",
    "That is the halfway mark passed.",
    "Four down. The back half starts here.",
  },
  [5] = {
    "Five. I can see the LEAGUE from here.",
    "Badge five. The end is in view.",
    "{LAST} handed over the fifth.",
    "Five badges. Three between me and Indigo.",
    "Five, and the Gyms are getting serious.",
    "That is five. Not many left.",
    "Fifth badge. I am past the hard part.",
    "Five in the case. {NEXT} is sixth.",
  },
  [6] = {
    "Six badges. How many have you got?",
    "That is six. {LAST} tried.",
    "Six down. Two left.",
    "Badge six. Almost through.",
    "Six, and the Elite Four are real now.",
    "{LAST} beaten. Six in hand.",
    "Six badges. The last two are the hardest.",
    "Sixth. I am nearly there.",
  },
  [7] = {
    "Seven. One left.",
    "{NEXT} is all that stands between me and the LEAGUE.",
    "Badge seven. One more door.",
    "Seven down. One to go.",
    "{LAST} was the seventh.",
    "Seven badges and a single Gym left.",
    "One badge from Indigo Plateau.",
    "Seventh. Do not blink.",
  },
  [8] = {
    "Eight badges. All of them.",
    "That is the set. The LEAGUE is next.",
    "{LAST} was the last Gym in Kanto.",
    "Eight. Nothing left to earn out here.",
    "The badge case is full.",
    "Eight badges. I am going to Indigo Plateau.",
    "Every Gym in the region. Beaten.",
    "That is all eight. Try to keep up.",
  },
}

-- src/Simulation.lua sets newsPending = "QUALIFIED" and no bucket existed for
-- it, so a rival qualifying for the LEAGUE said nothing at all. 5.0.8 gives it
-- one.
X.qualified = {
  "I have qualified for the LEAGUE.",
  "My name is on the Indigo list.",
  "I earned my place at the Plateau.",
  "Qualified. The Elite Four are next.",
  "They accepted my challenge.",
  "I am in. The rest is battles.",
  "Registration done. Now the hard part.",
  "The Plateau has my name on file.",
}

X.formerly = {
  TEAM_ROCKET = {
    "I wore that uniform once.",
    "I was with them. I am not now.",
    "There is a stretch of my past I do not discuss.",
    "I took orders I should have refused.",
    "I left Rocket. It has not left me.",
    "I gave back what I could.",
  },
  RETURNED = {
    "I am back on the Gym Challenge.",
    "I walked away once. I came back.",
    "Different team, same ladder.",
    "I took a detour. It is over.",
    "The badge case is open again.",
    "I am late to my own journey.",
  },
}

X.relationship = {
  FRIENDLY = {
    "It is good to see you.",
    "You are decent company.",
    "I like running into you.",
    "No hard feelings between us.",
    "You are one of the good ones.",
    "I am glad our roads cross.",
  },
  COMPETITIVE = {
    "You keep pushing me.",
    "I measure myself against you.",
    "We are close. Too close.",
    "Every time I improve, so do you.",
    "You are the benchmark.",
    "I do not enjoy being second to you.",
  },
  RIVALRY = {
    "You and I are not done.",
    "This has been building for a while.",
    "My rival. Properly.",
    "One of us has to be ahead.",
    "Nobody else gets under my skin.",
    "We have history.",
  },
  RESPECT = {
    "You are worth beating.",
    "I do not say this often. You are good.",
    "I take you seriously.",
    "You have earned my attention.",
    "There is nothing cheap about you.",
    "I respect what you have built.",
  },
  HOSTILE = {
    "I do not like you.",
    "Stay out of my way.",
    "Nothing between us is friendly.",
    "I have no patience for you.",
    "You have made an enemy.",
    "Do not expect civility.",
  },
  MENTOR = {
    "You are still learning. Keep learning.",
    "I have things to teach you.",
    "I have watched you improve.",
    "You listen. That is rare.",
    "Consider me a teacher.",
    "I want you better than you are.",
  },
  ALLIED = {
    "We are on the same side.",
    "I would fight beside you.",
    "You have my support.",
    "Allies. It has been useful.",
    "Call on me if you need to.",
    "We do better together.",
  },
  DEVOTED = {
    "You matter to me.",
    "I would go a long way for you.",
    "There is nobody I would rather travel with.",
    "You have all of my loyalty.",
    "I do not give this to many people.",
    "Wherever you go, I am not far.",
  },
  NEMESIS = {
    "You are the reason I train.",
    "I will not stop until you lose.",
    "Everything I do points at you.",
    "You are my one obsession.",
    "I have thought about this too much.",
    "Nothing ends until you do.",
  },
  PROTEGE = {
    "You taught me most of this.",
    "I owe you more than a battle.",
    "I learned this from you.",
    "I am trying to be worth your time.",
    "Everything good in my team started with you.",
    "Watch what you made.",
  },
  ADMIRER = {
    "I have followed everything you do.",
    "You are the reason I started.",
    "I have wanted this match for ages.",
    "You do not know what you mean out here.",
    "I have your record memorised.",
    "Meeting you was the point.",
  },
  BETRAYED = {
    "You broke something between us.",
    "I trusted you once.",
    "I do not forget what you did.",
    "You had my back until you did not.",
    "That is not something you take back.",
    "I gave you everything and got this.",
  },
  JEALOUS = {
    "You make it look easy. I hate that.",
    "Everything I work for, you already have.",
    "I am tired of being behind you.",
    "It should have been me.",
    "You get what I earn.",
    "I notice every one of your wins.",
  },
  FEARFUL = {
    "I would rather not fight you.",
    "You worry me.",
    "I know what you can do. That is the problem.",
    "Give me some distance.",
    "Every time we battle I remember why I avoid it.",
    "I am not ready for you.",
  },
  FAMILY = {
    "We are family. That does not change.",
    "Family before badges.",
    "You are stuck with me.",
    "I will still be here after the LEAGUE.",
    "Family fights. Family stays.",
    "Nobody knows me like you do.",
  },
  ESTRANGED = {
    "We used to be closer.",
    "There is distance between us now.",
    "I do not know what to call you anymore.",
    "Something cooled between us.",
    "We are not what we were.",
    "I have not spoken to you properly in a while.",
  },
}

X.mood = {
  CONFIDENT = {
    "I feel unstoppable today.",
    "Everything is landing right now.",
    "I like my chances.",
    "Nothing has gone wrong yet.",
    "I am on a good run.",
    "Try to dent this.",
  },
  DETERMINED = {
    "I am not backing off.",
    "I decided how this goes.",
    "Nothing shifts me right now.",
    "I have my jaw set.",
    "One direction. Forward.",
    "I do not know how to quit today.",
  },
  FRUSTRATED = {
    "Nothing is going my way.",
    "I am sick of this week.",
    "Everything is half a step off.",
    "I have had enough of losing.",
    "My patience ran out an hour ago.",
    "Do not test me right now.",
  },
  HUMBLED = {
    "I got ahead of myself.",
    "I have been reminded of my limits.",
    "I needed that knocked out of me.",
    "I was arrogant. Not anymore.",
    "Something took me down a peg.",
    "I am quieter than I was.",
  },
  FOCUSED = {
    "Everything else is noise.",
    "I am locked on.",
    "One thing at a time.",
    "Nothing outside this matters.",
    "I can see it very clearly today.",
    "Do not break my concentration.",
  },
  TRIUMPHANT = {
    "This has been a very good day.",
    "Everything is going right.",
    "I am riding high.",
    "Nothing can touch me this week.",
    "I have earned this feeling.",
    "Let me enjoy this.",
  },
  RESTLESS = {
    "I cannot sit still.",
    "Something needs to happen.",
    "I have too much energy.",
    "Waiting is the worst part.",
    "I need to be moving.",
    "Give me something to do.",
  },
}

-- ------------------------------------------------------------------
-- Which voice register each situation borrows
-- ------------------------------------------------------------------

local REGISTER = {
  ["greeting.IDLE"] = "DRIVE",
  ["greeting.TRAVELLING"] = "DRIVE",
  ["greeting.TRAINING"] = "DRIVE",
  ["greeting.SEEKING_GYM"] = "EDGE",
  ["greeting.HEALING"] = "DOWN",
  ["greeting.EXPLORING"] = "DRIVE",
  ["greeting.DEFEATED"] = "DOWN",
  ["greeting.LEAGUE_READY"] = "UP",
  ["greeting.CHAMPION"] = "UP",
  challenge = "EDGE",
  scoreRemind = "EDGE",
  eliteChampion = "UP",
  afterWin = "UP",
  afterLoss = "DOWN",
  gymLoss = "DOWN",
  gauntletWait = "DRIVE",
  gauntletChallenge = "EDGE",
  badgeNews = "UP",
  qualified = "UP",
  relationship = "EDGE",
  mood = "DRIVE",
  formerly = "DOWN",
  career = "DRIVE",
}

local CAP = {
  greeting = 15,
  challenge = 16,
  scoreRemind = 10,
  eliteChampion = 10,
  afterWin = 12,
  afterLoss = 12,
  gymLoss = 10,
  gauntletWait = 8,
  gauntletChallenge = 8,
  badgeNews = 6,
  qualified = 8,
  relationship = 6,
  mood = 6,
  formerly = 6,
  career = 2,
}

-- ------------------------------------------------------------------
-- Installation
-- ------------------------------------------------------------------

local function personalities()
  local out = {}
  for id in pairs(VOICES) do out[#out + 1] = id end
  table.sort(out)   -- iteration order must not depend on hash order
  return out
end

local function appendAll(target, rows)
  for _, line in ipairs(rows) do target[#target + 1] = line end
end

-- A bucket whose [1] is a string is a FLAT LIST as far as
-- src/Dialogue.lua:resolveBucket is concerned, and it returns that list
-- before it ever looks at a personality key. Adding arms to such a bucket
-- would ship content nobody could ever hear (§36), so the flat rows move
-- down into `default` first.
local function ensureKeyed(bucket)
  if type(bucket) ~= "table" then return nil end
  if type(bucket[1]) == "string" then
    local flat = {}
    for i = 1, #bucket do flat[i] = bucket[i]; bucket[i] = nil end
    bucket.default = bucket.default or {}
    appendAll(bucket.default, flat)
  end
  bucket.default = bucket.default or {}
  return bucket
end

local function fill(bucket, situations, register, cap, named)
  bucket = ensureKeyed(bucket)
  if not bucket then return 0 end
  local added = 0
  for _, pid in ipairs(personalities()) do
    local voice = (VOICES[pid] or {})[register]
    if voice then
      bucket[pid] = bucket[pid] or {}
      local rows = compose(situations, voice, cap, named)
      appendAll(bucket[pid], rows)
      added = added + #rows
    end
  end
  -- `default` catches a personality that exists in data/personalities.lua but
  -- has no voice pack yet, and every third-party personality after it. It is
  -- the one arm that must never be empty.
  local anyVoice = (VOICES.CHALLENGER or {})[register]
  if anyVoice then
    local rows = compose(situations, anyVoice, cap, named)
    appendAll(bucket.default, rows)
    added = added + #rows
  end
  return added
end

-- Re-flow every hand-written line that does not fit the box.
--
-- 65 lines from before 5.0.8 overflow -- mostly continuation rows a couple of
-- columns past 18, and the 4.7.0 career formula which reaches 51. They are
-- rewrapped rather than rewritten: the WORDS are Christopher's and stay
-- exactly as written, only the break positions move. Idempotent, so a line
-- that already fits comes back unchanged.
--
-- This runs BEFORE anything is generated, so the career seeds picked up below
-- are already fitted.
local REFLOW = {
  "greeting", "challenge", "scoreRemind", "eliteChampion", "afterWin",
  "afterLoss", "gymLoss", "gauntletWait", "gauntletChallenge",
  "gauntletNeedStarter", "badgeNews", "relationship", "mood", "formerly",
  "career",
}

local function reflow(node)
  if type(node) ~= "table" then return 0 end
  local n = 0
  if type(node[1]) == "string" then
    for i = 1, #node do
      local fitted = rewrap(node[i])
      if fitted ~= node[i] then n = n + 1 end
      node[i] = fitted
    end
    return n
  end
  for _, child in pairs(node) do n = n + reflow(child) end
  return n
end

return function(D)
  local count = 0
  D.reflowedLineCount = 0
  for _, key in ipairs(REFLOW) do
    D.reflowedLineCount = D.reflowedLineCount + reflow(D[key])
  end

  D.greeting = D.greeting or {}
  for state, situations in pairs(X.greeting) do
    D.greeting[state] = D.greeting[state] or {}
    count = count + fill(D.greeting[state], situations,
      REGISTER["greeting." .. state], CAP.greeting, true)
  end

  local simple = {
    { "challenge",        X.challenge,        true  },
    { "scoreRemind",      X.scoreRemind,      true  },
    { "eliteChampion",    X.eliteChampion,    true  },
    { "afterWin",         X.afterWin,         true  },
    { "afterLoss",        X.afterLoss,        true  },
    { "gymLoss",          X.gymLoss,          true  },
    { "gauntletWait",     X.gauntletWait,     false },
    { "gauntletChallenge",X.gauntletChallenge,true  },
  }
  for _, row in ipairs(simple) do
    local key, situations, named = row[1], row[2], row[3]
    D[key] = D[key] or {}
    count = count + fill(D[key], situations, REGISTER[key], CAP[key], named)
  end

  D.badgeNews = D.badgeNews or {}
  for n = 1, 8 do
    D.badgeNews[n] = D.badgeNews[n] or {}
    count = count + fill(D.badgeNews[n], X.badgeNews[n],
      REGISTER.badgeNews, CAP.badgeNews, true)
  end
  D.badgeNews.QUALIFIED = D.badgeNews.QUALIFIED or {}
  count = count + fill(D.badgeNews.QUALIFIED, X.qualified,
    REGISTER.qualified, CAP.qualified, true)

  D.relationship = D.relationship or {}
  for state, situations in pairs(X.relationship) do
    D.relationship[state] = D.relationship[state] or {}
    count = count + fill(D.relationship[state], situations,
      REGISTER.relationship, CAP.relationship, true)
  end

  D.mood = D.mood or {}
  for state, situations in pairs(X.mood) do
    D.mood[state] = D.mood[state] or {}
    count = count + fill(D.mood[state], situations,
      REGISTER.mood, CAP.mood, true)
  end

  D.formerly = D.formerly or {}
  for key, situations in pairs(X.formerly) do
    D.formerly[key] = D.formerly[key] or {}
    count = count + fill(D.formerly[key], situations,
      REGISTER.formerly, CAP.formerly, true)
  end

  -- CAREERS ARE DIFFERENT. A life path's own sentence already exists and is
  -- specific ("I'm chasing legends now"); a generated replacement would be
  -- vaguer than what it replaced. So the authored line is kept whole as the
  -- FIRST page and a voice clause is added as a second, which is how a
  -- Scholar and a Black Angel end up describing the same life differently
  -- without either of them losing the life.
  D.career = D.career or {}
  for path, bucket in pairs(D.career) do
    if type(bucket) == "table" then
      local base = ensureKeyed(bucket)
      -- The 4.7.0 career defaults were written unwrapped -- several run past
      -- 40 columns in an 18-column box. Rewrapping the seed before reusing it
      -- fixes the page this file builds; rewrapCareerDefaults() below fixes
      -- the originals, which have been overflowing since 4.7.0.
      -- The seed is already fitted: the reflow pass above rewrapped every
      -- pre-5.0.8 line, including the 4.7.0 career formula, which ran to 51
      -- columns in an 18-column box.
      local seed = base.default and base.default[1]
      if seed then
        for _, pid in ipairs(personalities()) do
          local voice = (VOICES[pid] or {})[REGISTER.career]
          if voice then
            base[pid] = base[pid] or {}
            local n = 0
            local step = 0
            while n < CAP.career and step < #voice do
              local clause = voice[((step * 5) % #voice) + 1]
              base[pid][#base[pid] + 1] =
                seed .. "\f{NAME}: " .. wrap(clause, true)
              n = n + 1
              step = step + 1
            end
            count = count + n
          end
        end
      end
    end
  end

  D.generatedLineCount = count
  return count
end
