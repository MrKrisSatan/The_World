-- Species whose capture is worth a line on a trainer's record.
--
-- This is DATA, not a judgement made at runtime: which Pokemon are legendary
-- in Red/Blue/Yellow and Gold is a fixed fact about those games, and the
-- alternative -- inferring "impressive" from base stats or evolution stages --
-- would quietly invent achievements on any conversion that shifted a number.
--
-- Membership is the ONLY thing that qualifies a species here (a shiny catch
-- qualifies separately, on the slot's own flag). A boot that ships none of
-- these simply produces no capture highlights, which is the correct answer for
-- a game where nobody has caught anything notable.
--
-- Kept as one flat list on purpose: a Gold save can hold Kanto species and a
-- Kanto save cannot hold Johto ones, so splitting by generation would only
-- create a second place to be wrong.

return {
  -- Kanto
  "ARTICUNO", "ZAPDOS", "MOLTRES", "MEWTWO", "MEW",
  -- Johto
  "RAIKOU", "ENTEI", "SUICUNE", "LUGIA", "HO_OH", "HOOH", "CELEBI",
  -- The two Kanto pseudo-legendaries a trainer is genuinely known for owning
  "DRAGONITE", "SNORLAX",
  -- Johto's equivalent
  "TYRANITAR",
}
