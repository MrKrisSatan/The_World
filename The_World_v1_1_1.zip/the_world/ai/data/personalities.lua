-- Personalities are pure data.  Every behavioural difference between two
-- rivals is a number or an ordered priority list in this file; RivalAI reads
-- them and never branches on a rival id.  Adding a fifth personality is a
-- table entry, not a code change.
--
-- Priority lists are consulted top-down by AI.chooseObjective: the first
-- entry whose precondition holds becomes the objective.  A personality that
-- omits an entry simply never chooses it.
--
-- The numeric fields:
--   gymConfidence   relative party strength (rival/gym, 1.0 == even) the
--                   rival wants before it will walk into a Gym at all
--   retryPatience   ticks it sulks/trains after losing a Gym before retrying
--   challengeChance probability per detection roll of approaching the player
--   playerConfidence relative strength vs the player's party required before
--                   the rival is willing to challenge (nil == does not care)
--   trainRate       exp multiplier while TRAINING; the speedrunner trains
--                   less efficiently because it trains less deliberately
--   wanderChance    probability of a detour into EXPLORING per objective pick
--   catchChance     probability per training tick of adding a caught mon
--   partyTarget     how large a party it wants before it stops catching
--   healAt          fraction of party HP below which HEALING outranks all
--   ghostChance     probability per objective tick of detouring to a silph
--                   ghost (silph-scope interop; needs that mod present)
--   rivalFightChance probability per tick that this rival will pick a fight
--                   with another rival sharing its map (added in 1.7.0)
--   duelChance      probability per objective tick of seeking out another
--                   rival across Kanto to fight it for money (added 1.11.0)
--   trainerBattleChance probability per training tick of taking on a local
--                   trainer for money, which is what buys its Poké Balls

return {
  CHALLENGER = {
    label = "CHALLENGER",
    -- levels this rival likes to be AHEAD of the gym it is chasing;
    -- the Speedrunner arrives underlevelled and the Strategist overprepares
    levelMargin = 2,
    blurb = "Aggressive and competitive.",
    priorities = { "HEAL", "CHALLENGE_PLAYER", "GYM", "SEEK_GHOST", "RIVAL_DUEL", "TRAIN", "EXPLORE" },
    gymConfidence = 0.82,
    retryPatience = 6,
    challengeChance = 0.72,
    playerConfidence = nil,
    trainRate = 1.10,
    wanderChance = 0.10,
    catchChance = 0.10,
    partyTarget = 4,
    healAt = 0.30,
    ghostChance = 0.25,
    rivalFightChance = 0.18,
    duelChance = 0.16,
    trainerBattleChance = 0.10,
    teamPlan = "aggressive",
  },

  SPEEDRUNNER = {
    label = "SPEEDRUNNER",
    -- levels this rival likes to be AHEAD of the gym it is chasing;
    -- the Speedrunner arrives underlevelled and the Strategist overprepares
    levelMargin = 2,
    blurb = "Obsessed with badges. Everything else is a detour.",
    priorities = { "HEAL", "GYM", "TRAIN", "CHALLENGE_PLAYER", "SEEK_GHOST", "RIVAL_DUEL", "EXPLORE" },
    -- walks into gyms underlevelled, which is why it loses more often
    gymConfidence = 0.68,
    retryPatience = 3,
    challengeChance = 0.40,
    playerConfidence = 1.25,
    trainRate = 0.85,
    wanderChance = 0.02,
    catchChance = 0.02,
    partyTarget = 3,
    healAt = 0.25,
    ghostChance = 0.04,
    rivalFightChance = 0.04,
    duelChance = 0.03,
    trainerBattleChance = 0.03,
    teamPlan = "coverage",
  },

  COLLECTOR = {
    label = "COLLECTOR",
    -- levels this rival likes to be AHEAD of the gym it is chasing;
    -- the Speedrunner arrives underlevelled and the Strategist overprepares
    levelMargin = 2,
    blurb = "Out to see Kanto and meet its Pokemon.",
    priorities = { "HEAL", "TRAIN", "SEEK_GHOST", "RIVAL_DUEL", "GYM", "CHALLENGE_PLAYER", "EXPLORE" },
    gymConfidence = 0.95,
    retryPatience = 8,
    challengeChance = 0.48,
    playerConfidence = 0.90,
    trainRate = 1.00,
    wanderChance = 0.45,
    catchChance = 0.32,
    partyTarget = 6,
    healAt = 0.40,
    ghostChance = 0.45,
    rivalFightChance = 0.08,
    duelChance = 0.08,
    trainerBattleChance = 0.08,
    teamPlan = "varied",
  },

  STRATEGIST = {
    label = "STRATEGIST",
    -- levels this rival likes to be AHEAD of the gym it is chasing;
    -- the Speedrunner arrives underlevelled and the Strategist overprepares
    levelMargin = 2,
    blurb = "Careful. Will not fight a battle it has not already won.",
    priorities = { "HEAL", "TRAIN", "GYM", "CHALLENGE_PLAYER", "SEEK_GHOST", "RIVAL_DUEL", "EXPLORE" },
    gymConfidence = 1.10,
    retryPatience = 10,
    challengeChance = 0.55,
    playerConfidence = 1.00,
    trainRate = 1.20,
    wanderChance = 0.08,
    catchChance = 0.15,
    partyTarget = 5,
    healAt = 0.55,
    ghostChance = 0.12,
    rivalFightChance = 0.10,
    duelChance = 0.06,
    trainerBattleChance = 0.06,
    teamPlan = "balanced",
  },

  EXPLORER = {
    label = "EXPLORER", blurb = "Always looking beyond the next route.",
    priorities = { "HEAL", "EXPLORE", "SEEK_GHOST", "TRAIN", "GYM", "RIVAL_DUEL", "CHALLENGE_PLAYER" },
    gymConfidence = 0.90, retryPatience = 7, challengeChance = 0.32,
    playerConfidence = 0.90, trainRate = 0.95, wanderChance = 0.62,
    catchChance = 0.22, partyTarget = 5, healAt = 0.38,
    ghostChance = 0.30, rivalFightChance = 0.06, duelChance = 0.05,
    trainerBattleChance = 0.07, levelMargin = 1, teamPlan = "varied",
  },
  MENTOR = {
    label = "MENTOR", blurb = "Tests others so everyone improves.",
    priorities = { "HEAL", "CHALLENGE_PLAYER", "TRAIN", "GYM", "RIVAL_DUEL", "EXPLORE" },
    gymConfidence = 1.00, retryPatience = 6, challengeChance = 0.62,
    playerConfidence = 0.82, trainRate = 1.05, wanderChance = 0.12,
    catchChance = 0.12, partyTarget = 4, healAt = 0.42,
    ghostChance = 0.10, rivalFightChance = 0.12, duelChance = 0.10,
    trainerBattleChance = 0.10, levelMargin = 1, teamPlan = "balanced",
  },
  ACE = {
    label = "ACE", blurb = "Lives for difficult, clean victories.",
    priorities = { "HEAL", "GYM", "RIVAL_DUEL", "TRAIN", "CHALLENGE_PLAYER", "EXPLORE" },
    gymConfidence = 0.92, retryPatience = 4, challengeChance = 0.58,
    playerConfidence = 1.02, trainRate = 1.18, wanderChance = 0.06,
    catchChance = 0.10, partyTarget = 5, healAt = 0.34,
    ghostChance = 0.08, rivalFightChance = 0.16, duelChance = 0.18,
    trainerBattleChance = 0.13, levelMargin = 2, teamPlan = "aggressive",
  },
  SURVIVALIST = {
    label = "SURVIVALIST", blurb = "Conserves supplies and endures long routes.",
    priorities = { "HEAL", "TRAIN", "EXPLORE", "GYM", "RIVAL_DUEL", "CHALLENGE_PLAYER" },
    gymConfidence = 1.02, retryPatience = 9, challengeChance = 0.28,
    playerConfidence = 1.05, trainRate = 1.08, wanderChance = 0.35,
    catchChance = 0.16, partyTarget = 4, healAt = 0.62,
    ghostChance = 0.16, rivalFightChance = 0.07, duelChance = 0.06,
    trainerBattleChance = 0.08, levelMargin = 2, teamPlan = "balanced",
  },
  SHOWBOAT = {
    label = "SHOWBOAT", blurb = "Chases attention as eagerly as badges.",
    priorities = { "HEAL", "CHALLENGE_PLAYER", "RIVAL_DUEL", "GYM", "TRAIN", "EXPLORE" },
    gymConfidence = 0.78, retryPatience = 4, challengeChance = 0.82,
    playerConfidence = nil, trainRate = 0.96, wanderChance = 0.18,
    catchChance = 0.13, partyTarget = 5, healAt = 0.28,
    ghostChance = 0.10, rivalFightChance = 0.22, duelChance = 0.20,
    trainerBattleChance = 0.12, levelMargin = 1, teamPlan = "aggressive",
  },
  SCHOLAR = {
    label = "SCHOLAR", blurb = "Studies every matchup before committing.",
    priorities = { "HEAL", "TRAIN", "SEEK_GHOST", "GYM", "EXPLORE", "CHALLENGE_PLAYER" },
    gymConfidence = 1.08, retryPatience = 9, challengeChance = 0.30,
    playerConfidence = 1.08, trainRate = 1.15, wanderChance = 0.20,
    catchChance = 0.18, partyTarget = 5, healAt = 0.48,
    ghostChance = 0.35, rivalFightChance = 0.05, duelChance = 0.04,
    trainerBattleChance = 0.07, levelMargin = 2, teamPlan = "coverage",
  },
  TRADER = {
    label = "TRADER", blurb = "Builds teams through travel and exchange.",
    priorities = { "HEAL", "EXPLORE", "TRAIN", "GYM", "RIVAL_DUEL", "CHALLENGE_PLAYER" },
    gymConfidence = 0.94, retryPatience = 7, challengeChance = 0.38,
    playerConfidence = 0.92, trainRate = 1.00, wanderChance = 0.42,
    catchChance = 0.30, partyTarget = 6, healAt = 0.40,
    ghostChance = 0.18, rivalFightChance = 0.08, duelChance = 0.07,
    trainerBattleChance = 0.11, levelMargin = 1, teamPlan = "varied",
  },
  SPECIALIST = {
    label = "SPECIALIST", blurb = "Refines one battle philosophy relentlessly.",
    priorities = { "HEAL", "TRAIN", "GYM", "RIVAL_DUEL", "CHALLENGE_PLAYER", "EXPLORE" },
    gymConfidence = 1.04, retryPatience = 8, challengeChance = 0.46,
    playerConfidence = 1.00, trainRate = 1.22, wanderChance = 0.05,
    catchChance = 0.20, partyTarget = 6, healAt = 0.44,
    ghostChance = 0.12, rivalFightChance = 0.13, duelChance = 0.11,
    trainerBattleChance = 0.09, levelMargin = 2, teamPlan = "balanced",
  },
  BLACK_ANGEL = {
    label = "BLACK ANGEL",
    blurb = "A relentless, protective fighter who values endurance, loyalty and facing overwhelming odds without giving up.",
    priorities = { "HEAL", "CHALLENGE_PLAYER", "RIVAL_DUEL", "GYM", "TRAIN", "EXPLORE" },
    gymConfidence = 1.12, retryPatience = 2, challengeChance = 0.78,
    playerConfidence = 0.82, trainRate = 1.25, wanderChance = 0.10,
    catchChance = 0.08, partyTarget = 5, healAt = 0.36,
    ghostChance = 0.10, rivalFightChance = 0.20, duelChance = 0.18,
    trainerBattleChance = 0.14, levelMargin = 2, teamPlan = "aggressive",
  },
  HAWKSWORD = {
    label = "HAWKSWORD",
    blurb = "A disciplined, courageous trainer who protects companions and refuses to be defined by anyone else's ambitions.",
    priorities = { "HEAL", "GYM", "CHALLENGE_PLAYER", "TRAIN", "RIVAL_DUEL", "EXPLORE" },
    gymConfidence = 1.08, retryPatience = 6, challengeChance = 0.62,
    playerConfidence = 0.94, trainRate = 1.18, wanderChance = 0.12,
    catchChance = 0.14, partyTarget = 5, healAt = 0.42,
    ghostChance = 0.08, rivalFightChance = 0.12, duelChance = 0.10,
    trainerBattleChance = 0.10, levelMargin = 2, teamPlan = "balanced",
  },
  WHITE_HAWK = {
    label = "WHITE HAWK",
    blurb = "A charismatic strategist who inspires followers, plans several steps ahead and quietly pursues a grand personal goal.",
    priorities = { "HEAL", "TRAIN", "GYM", "RIVAL_DUEL", "CHALLENGE_PLAYER", "EXPLORE" },
    gymConfidence = 1.18, retryPatience = 10, challengeChance = 0.58,
    playerConfidence = 1.00, trainRate = 1.28, wanderChance = 0.08,
    catchChance = 0.20, partyTarget = 6, healAt = 0.50,
    ghostChance = 0.06, rivalFightChance = 0.10, duelChance = 0.14,
    trainerBattleChance = 0.12, levelMargin = 3, teamPlan = "coverage",
  },
  -- 5.1.0. A wide-eyed innocent who cannot believe his luck and keeps having
  -- it, then losing it, then not much minding. Everything about him is
  -- unearned optimism: he catches almost anything, trains almost nothing,
  -- battles because it seems friendly, and heals late because it does not
  -- occur to him that anyone is really in danger.
  --
  -- The numbers are the character. Highest catchChance in the file and the
  -- lowest trainRate, because he accumulates without improving; a huge
  -- wanderChance because he has no plan; gymConfidence far below anyone
  -- else's because he genuinely has no idea whether he can win.
  WIDE_EYED = {
    label = "WIDE EYED",
    blurb = "A cheerful innocent who fell into all this by accident and is having a wonderful time.",
    -- No CATCH objective exists -- catching is driven by catchChance, not by
    -- a priority -- and EXPLORE/TRAIN are always-available fallbacks, so
    -- anything listed after them is unreachable. Both traps were in the first
    -- draft of this row.
    priorities = { "HEAL", "SEEK_GHOST", "CHALLENGE_PLAYER", "GYM",
                   "RIVAL_DUEL", "TRAIN", "EXPLORE" },
    gymConfidence = 0.34,
    retryPatience = 8,
    challengeChance = 0.62,
    playerConfidence = nil,
    trainRate = 0.72,
    wanderChance = 0.46,
    catchChance = 0.40,
    partyTarget = 6,
    healAt = 0.18,
    ghostChance = 0.20,
    rivalFightChance = 0.10,
    duelChance = 0.08,
    trainerBattleChance = 0.26,
    levelMargin = 0,
    teamPlan = "balanced",
  },

  HEARTBREAK_KID = {
    label = "HEARTBREAK KID",
    blurb = "A charismatic showstopper who treats every battle like a main event.",
    priorities = { "HEAL", "CHALLENGE_PLAYER", "RIVAL_DUEL", "GYM",
                   "TRAIN", "EXPLORE" },
    gymConfidence = 0.84,
    retryPatience = 4,
    challengeChance = 0.88,
    playerConfidence = nil,
    trainRate = 1.08,
    wanderChance = 0.14,
    catchChance = 0.12,
    partyTarget = 5,
    healAt = 0.30,
    ghostChance = 0.08,
    rivalFightChance = 0.24,
    duelChance = 0.22,
    trainerBattleChance = 0.14,
    levelMargin = 1,
    teamPlan = "aggressive",
  },

  -- 7.1.0: expanded personality pool inspired by political fantasy, grimdark
  -- military science fiction, cybernetic thrillers, revisionist superhero
  -- teams and neon dystopian RPGs. These are original archetypes, not direct
  -- copies of named characters. They stay data-only so every generation uses
  -- exactly the same AI code paths.
  NORTHERN_LOYALIST = {
    label = "NORTHERN LOYALIST", blurb = "Duty first. Slow to trust, almost impossible to turn once loyalty is earned.",
    priorities = { "HEAL", "TRAIN", "GYM", "RIVAL_DUEL", "CHALLENGE_PLAYER", "EXPLORE" },
    gymConfidence = 1.08, retryPatience = 8, challengeChance = 0.36,
    playerConfidence = 1.02, trainRate = 1.14, wanderChance = 0.08,
    catchChance = 0.12, partyTarget = 5, healAt = 0.52,
    ghostChance = 0.10, rivalFightChance = 0.11, duelChance = 0.09,
    trainerBattleChance = 0.09, levelMargin = 2, teamPlan = "balanced",
  },
  COURT_SCHEMER = {
    label = "COURT SCHEMER", blurb = "Prefers leverage, preparation and useful friendships to fair fights.",
    priorities = { "HEAL", "TRAIN", "EXPLORE", "GYM", "RIVAL_DUEL", "CHALLENGE_PLAYER" },
    gymConfidence = 1.16, retryPatience = 11, challengeChance = 0.24,
    playerConfidence = 1.16, trainRate = 1.16, wanderChance = 0.22,
    catchChance = 0.18, partyTarget = 6, healAt = 0.58,
    ghostChance = 0.18, rivalFightChance = 0.07, duelChance = 0.12,
    trainerBattleChance = 0.12, levelMargin = 2, teamPlan = "coverage",
  },
  DRAGON_HEIR = {
    label = "DRAGON HEIR", blurb = "Charismatic, proud and convinced that greatness is something to be claimed.",
    priorities = { "HEAL", "GYM", "CHALLENGE_PLAYER", "RIVAL_DUEL", "TRAIN", "EXPLORE" },
    gymConfidence = 0.90, retryPatience = 4, challengeChance = 0.74,
    playerConfidence = nil, trainRate = 1.10, wanderChance = 0.12,
    catchChance = 0.16, partyTarget = 6, healAt = 0.34,
    ghostChance = 0.08, rivalFightChance = 0.20, duelChance = 0.20,
    trainerBattleChance = 0.13, levelMargin = 2, teamPlan = "aggressive",
  },
  QUIET_SPY = {
    label = "QUIET SPY", blurb = "Collects information, avoids unnecessary risk and rarely reveals the whole plan.",
    priorities = { "HEAL", "EXPLORE", "TRAIN", "SEEK_GHOST", "GYM", "CHALLENGE_PLAYER" },
    gymConfidence = 1.06, retryPatience = 9, challengeChance = 0.22,
    playerConfidence = 1.12, trainRate = 1.04, wanderChance = 0.40,
    catchChance = 0.14, partyTarget = 4, healAt = 0.50,
    ghostChance = 0.34, rivalFightChance = 0.05, duelChance = 0.05,
    trainerBattleChance = 0.10, levelMargin = 1, teamPlan = "coverage",
  },
  OATHBOUND_KNIGHT = {
    label = "OATHBOUND KNIGHT", blurb = "Honour, promises and protecting weaker trainers matter more than efficiency.",
    priorities = { "HEAL", "CHALLENGE_PLAYER", "GYM", "TRAIN", "RIVAL_DUEL", "EXPLORE" },
    gymConfidence = 1.02, retryPatience = 7, challengeChance = 0.52,
    playerConfidence = 0.94, trainRate = 1.10, wanderChance = 0.10,
    catchChance = 0.10, partyTarget = 5, healAt = 0.50,
    ghostChance = 0.08, rivalFightChance = 0.10, duelChance = 0.08,
    trainerBattleChance = 0.08, levelMargin = 2, teamPlan = "balanced",
  },

  IRON_COMMISSAR = {
    label = "IRON COMMISSAR", blurb = "Relentless discipline, decisive battles and no patience for hesitation.",
    priorities = { "HEAL", "GYM", "RIVAL_DUEL", "CHALLENGE_PLAYER", "TRAIN", "EXPLORE" },
    gymConfidence = 0.88, retryPatience = 3, challengeChance = 0.70,
    playerConfidence = 0.90, trainRate = 1.18, wanderChance = 0.04,
    catchChance = 0.07, partyTarget = 4, healAt = 0.32,
    ghostChance = 0.04, rivalFightChance = 0.22, duelChance = 0.20,
    trainerBattleChance = 0.16, levelMargin = 1, teamPlan = "aggressive",
  },
  MACHINE_ADEPT = {
    label = "MACHINE ADEPT", blurb = "Treats team building as engineering: test, optimise, replace, repeat.",
    priorities = { "HEAL", "TRAIN", "GYM", "EXPLORE", "RIVAL_DUEL", "CHALLENGE_PLAYER" },
    gymConfidence = 1.14, retryPatience = 8, challengeChance = 0.30,
    playerConfidence = 1.10, trainRate = 1.28, wanderChance = 0.16,
    catchChance = 0.24, partyTarget = 6, healAt = 0.52,
    ghostChance = 0.12, rivalFightChance = 0.06, duelChance = 0.06,
    trainerBattleChance = 0.10, levelMargin = 2, teamPlan = "coverage",
  },
  INQUISITIVE_PURIFIER = {
    label = "PURIFIER", blurb = "Suspicious of corruption and willing to pursue threats far beyond the usual route.",
    priorities = { "HEAL", "SEEK_GHOST", "RIVAL_DUEL", "TRAIN", "GYM", "CHALLENGE_PLAYER", "EXPLORE" },
    gymConfidence = 1.04, retryPatience = 7, challengeChance = 0.44,
    playerConfidence = 1.00, trainRate = 1.12, wanderChance = 0.18,
    catchChance = 0.10, partyTarget = 5, healAt = 0.48,
    ghostChance = 0.62, rivalFightChance = 0.17, duelChance = 0.15,
    trainerBattleChance = 0.11, levelMargin = 2, teamPlan = "balanced",
  },
  VOID_VETERAN = {
    label = "VOID VETERAN", blurb = "Calm under pressure, conservative with resources and dangerous when cornered.",
    priorities = { "HEAL", "TRAIN", "GYM", "RIVAL_DUEL", "EXPLORE", "CHALLENGE_PLAYER" },
    gymConfidence = 1.10, retryPatience = 8, challengeChance = 0.34,
    playerConfidence = 1.04, trainRate = 1.16, wanderChance = 0.14,
    catchChance = 0.10, partyTarget = 5, healAt = 0.60,
    ghostChance = 0.16, rivalFightChance = 0.11, duelChance = 0.10,
    trainerBattleChance = 0.10, levelMargin = 2, teamPlan = "balanced",
  },
  GLORY_REAVER = {
    label = "GLORY REAVER", blurb = "Seeks the biggest fight available and mistakes restraint for cowardice.",
    priorities = { "HEAL", "RIVAL_DUEL", "CHALLENGE_PLAYER", "GYM", "TRAIN", "EXPLORE" },
    gymConfidence = 0.74, retryPatience = 2, challengeChance = 0.86,
    playerConfidence = nil, trainRate = 1.00, wanderChance = 0.16,
    catchChance = 0.09, partyTarget = 5, healAt = 0.24,
    ghostChance = 0.06, rivalFightChance = 0.30, duelChance = 0.28,
    trainerBattleChance = 0.18, levelMargin = 1, teamPlan = "aggressive",
  },

  CYBER_OPERATIVE = {
    label = "CYBER OPERATIVE", blurb = "Adaptive, observant and more interested in information than spectacle.",
    priorities = { "HEAL", "EXPLORE", "TRAIN", "GYM", "RIVAL_DUEL", "CHALLENGE_PLAYER" },
    gymConfidence = 1.08, retryPatience = 7, challengeChance = 0.32,
    playerConfidence = 1.08, trainRate = 1.18, wanderChance = 0.34,
    catchChance = 0.18, partyTarget = 5, healAt = 0.48,
    ghostChance = 0.30, rivalFightChance = 0.08, duelChance = 0.07,
    trainerBattleChance = 0.09, levelMargin = 2, teamPlan = "coverage",
  },
  SECTION_CHIEF = {
    label = "SECTION CHIEF", blurb = "Patient leadership, strong judgement and a preference for winning through coordination.",
    priorities = { "HEAL", "TRAIN", "GYM", "CHALLENGE_PLAYER", "RIVAL_DUEL", "EXPLORE" },
    gymConfidence = 1.12, retryPatience = 8, challengeChance = 0.42,
    playerConfidence = 1.02, trainRate = 1.20, wanderChance = 0.12,
    catchChance = 0.14, partyTarget = 5, healAt = 0.54,
    ghostChance = 0.16, rivalFightChance = 0.09, duelChance = 0.07,
    trainerBattleChance = 0.10, levelMargin = 2, teamPlan = "balanced",
  },
  HEAVY_OPERATIVE = {
    label = "HEAVY OPERATIVE", blurb = "Direct, loyal and built around dependable force rather than elaborate tricks.",
    priorities = { "HEAL", "TRAIN", "CHALLENGE_PLAYER", "GYM", "RIVAL_DUEL", "EXPLORE" },
    gymConfidence = 1.00, retryPatience = 5, challengeChance = 0.60,
    playerConfidence = 0.94, trainRate = 1.16, wanderChance = 0.08,
    catchChance = 0.08, partyTarget = 4, healAt = 0.44,
    ghostChance = 0.08, rivalFightChance = 0.16, duelChance = 0.13,
    trainerBattleChance = 0.13, levelMargin = 2, teamPlan = "aggressive",
  },
  GHOST_HACKER = {
    label = "GHOST HACKER", blurb = "Curious, elusive and drawn toward strange signals, hidden systems and anomalies.",
    priorities = { "HEAL", "SEEK_GHOST", "EXPLORE", "TRAIN", "GYM", "CHALLENGE_PLAYER", "RIVAL_DUEL" },
    gymConfidence = 1.00, retryPatience = 8, challengeChance = 0.24,
    playerConfidence = 1.12, trainRate = 1.06, wanderChance = 0.52,
    catchChance = 0.22, partyTarget = 5, healAt = 0.46,
    ghostChance = 0.70, rivalFightChance = 0.04, duelChance = 0.04,
    trainerBattleChance = 0.08, levelMargin = 1, teamPlan = "varied",
  },

  SOLAR_IDEALIST = {
    label = "SOLAR IDEALIST", blurb = "Powerful, confident and convinced overwhelming strength should be used to improve the world.",
    priorities = { "HEAL", "GYM", "CHALLENGE_PLAYER", "TRAIN", "RIVAL_DUEL", "EXPLORE" },
    gymConfidence = 0.94, retryPatience = 4, challengeChance = 0.68,
    playerConfidence = 0.90, trainRate = 1.20, wanderChance = 0.16,
    catchChance = 0.12, partyTarget = 5, healAt = 0.36,
    ghostChance = 0.08, rivalFightChance = 0.14, duelChance = 0.12,
    trainerBattleChance = 0.12, levelMargin = 2, teamPlan = "aggressive",
  },
  MIDNIGHT_TACTICIAN = {
    label = "MIDNIGHT TACTICIAN", blurb = "Clinical preparation, precise counters and almost no appetite for improvisational risk.",
    priorities = { "HEAL", "TRAIN", "GYM", "RIVAL_DUEL", "CHALLENGE_PLAYER", "EXPLORE" },
    gymConfidence = 1.22, retryPatience = 10, challengeChance = 0.36,
    playerConfidence = 1.18, trainRate = 1.26, wanderChance = 0.04,
    catchChance = 0.14, partyTarget = 6, healAt = 0.58,
    ghostChance = 0.10, rivalFightChance = 0.12, duelChance = 0.16,
    trainerBattleChance = 0.10, levelMargin = 2, teamPlan = "coverage",
  },
  WINGED_GUARDIAN = {
    label = "WINGED GUARDIAN", blurb = "Protective and mobile, always ready to leave the main path to help someone else.",
    priorities = { "HEAL", "EXPLORE", "CHALLENGE_PLAYER", "GYM", "TRAIN", "RIVAL_DUEL" },
    gymConfidence = 0.98, retryPatience = 6, challengeChance = 0.48,
    playerConfidence = 0.94, trainRate = 1.08, wanderChance = 0.50,
    catchChance = 0.12, partyTarget = 5, healAt = 0.50,
    ghostChance = 0.16, rivalFightChance = 0.08, duelChance = 0.06,
    trainerBattleChance = 0.08, levelMargin = 1, teamPlan = "balanced",
  },
  REALITY_ENGINEER = {
    label = "REALITY ENGINEER", blurb = "Treats conventional rules as suggestions and constantly rebuilds the team around new possibilities.",
    priorities = { "HEAL", "TRAIN", "EXPLORE", "SEEK_GHOST", "GYM", "CHALLENGE_PLAYER", "RIVAL_DUEL" },
    gymConfidence = 1.10, retryPatience = 7, challengeChance = 0.34,
    playerConfidence = 1.04, trainRate = 1.22, wanderChance = 0.32,
    catchChance = 0.28, partyTarget = 6, healAt = 0.48,
    ghostChance = 0.42, rivalFightChance = 0.06, duelChance = 0.05,
    trainerBattleChance = 0.09, levelMargin = 2, teamPlan = "varied",
  },

  STREET_MERC = {
    label = "STREET MERC", blurb = "Practical, ambitious and always balancing survival against the next profitable fight.",
    priorities = { "HEAL", "TRAIN", "RIVAL_DUEL", "GYM", "CHALLENGE_PLAYER", "EXPLORE" },
    gymConfidence = 0.94, retryPatience = 5, challengeChance = 0.58,
    playerConfidence = 0.96, trainRate = 1.12, wanderChance = 0.18,
    catchChance = 0.14, partyTarget = 5, healAt = 0.44,
    ghostChance = 0.10, rivalFightChance = 0.17, duelChance = 0.16,
    trainerBattleChance = 0.20, levelMargin = 1, teamPlan = "aggressive",
  },
  NETRUNNER = {
    label = "NETRUNNER", blurb = "Avoids brute force when scouting, information and an unexpected angle will do.",
    priorities = { "HEAL", "EXPLORE", "SEEK_GHOST", "TRAIN", "GYM", "CHALLENGE_PLAYER", "RIVAL_DUEL" },
    gymConfidence = 1.04, retryPatience = 8, challengeChance = 0.26,
    playerConfidence = 1.12, trainRate = 1.08, wanderChance = 0.48,
    catchChance = 0.20, partyTarget = 5, healAt = 0.46,
    ghostChance = 0.58, rivalFightChance = 0.05, duelChance = 0.05,
    trainerBattleChance = 0.09, levelMargin = 1, teamPlan = "coverage",
  },
  CORPORATE_FIXER = {
    label = "CORPORATE FIXER", blurb = "Polished, transactional and frighteningly good at turning preparation into advantage.",
    priorities = { "HEAL", "TRAIN", "GYM", "EXPLORE", "RIVAL_DUEL", "CHALLENGE_PLAYER" },
    gymConfidence = 1.18, retryPatience = 10, challengeChance = 0.30,
    playerConfidence = 1.14, trainRate = 1.18, wanderChance = 0.16,
    catchChance = 0.20, partyTarget = 6, healAt = 0.56,
    ghostChance = 0.12, rivalFightChance = 0.07, duelChance = 0.10,
    trainerBattleChance = 0.18, levelMargin = 2, teamPlan = "coverage",
  },
  NOMAD = {
    label = "NOMAD", blurb = "Values freedom, mobility and a dependable team more than badges or status.",
    priorities = { "HEAL", "EXPLORE", "TRAIN", "GYM", "CHALLENGE_PLAYER", "RIVAL_DUEL" },
    gymConfidence = 0.92, retryPatience = 7, challengeChance = 0.34,
    playerConfidence = 0.96, trainRate = 1.04, wanderChance = 0.68,
    catchChance = 0.22, partyTarget = 5, healAt = 0.50,
    ghostChance = 0.18, rivalFightChance = 0.06, duelChance = 0.05,
    trainerBattleChance = 0.10, levelMargin = 1, teamPlan = "varied",
  },
  ROCKER_REBEL = {
    label = "ROCKER REBEL", blurb = "Loud, defiant and happiest when challenging whoever claims to be in charge.",
    priorities = { "HEAL", "CHALLENGE_PLAYER", "RIVAL_DUEL", "GYM", "EXPLORE", "TRAIN" },
    gymConfidence = 0.80, retryPatience = 3, challengeChance = 0.84,
    playerConfidence = nil, trainRate = 0.98, wanderChance = 0.30,
    catchChance = 0.12, partyTarget = 5, healAt = 0.28,
    ghostChance = 0.12, rivalFightChance = 0.24, duelChance = 0.23,
    trainerBattleChance = 0.16, levelMargin = 1, teamPlan = "aggressive",
  },
  EDGERUNNER = {
    label = "EDGERUNNER", blurb = "Lives fast, overcommits often and can become terrifying when momentum is on their side.",
    priorities = { "HEAL", "GYM", "CHALLENGE_PLAYER", "RIVAL_DUEL", "TRAIN", "EXPLORE" },
    gymConfidence = 0.70, retryPatience = 2, challengeChance = 0.78,
    playerConfidence = 0.84, trainRate = 1.00, wanderChance = 0.14,
    catchChance = 0.10, partyTarget = 4, healAt = 0.22,
    ghostChance = 0.08, rivalFightChance = 0.25, duelChance = 0.22,
    trainerBattleChance = 0.18, levelMargin = 1, teamPlan = "aggressive",
  },


  CRUSADER = {
    label = "CRUSADER",
    blurb = "Fervently religious, incorruptible and uncompromising. Treats battles as righteous trials and Team Rocket as an evil to be broken.",
    priorities = { "HEAL", "CHALLENGE_PLAYER", "RIVAL_DUEL", "GYM", "TRAIN", "EXPLORE" },
    gymConfidence = 0.72,
    retryPatience = 2,
    challengeChance = 0.96,
    playerConfidence = nil,
    trainRate = 1.18,
    wanderChance = 0.06,
    catchChance = 0.10,
    partyTarget = 5,
    healAt = 0.18,
    ghostChance = 0.10,
    rivalFightChance = 0.38,
    duelChance = 0.34,
    trainerBattleChance = 0.24,
    levelMargin = 2,
    teamPlan = "aggressive",
    incorruptibleRocket = true,
    religious = true,
    weatherStarterBias = { "HOLY", "SUN", "FIRE", "LIGHT", "ELECTRIC", "STEEL", "FIGHT" },
  },

}
