AI Rivals Pokégear Custom Music

Place your own .ogg, .mp3, .wav or .flac music files here.
You may also create subfolders here (for example custom_music/My Playlist/) and select that folder from POKEGEAR > RADIO > CUSTOM MUSIC.

Gen1Recomp API 2 sandboxes mods, so AI Rivals intentionally does not read arbitrary absolute folders elsewhere on your computer. This keeps the feature compatible with the mod security model.
