# AI Rivals 7.2.7

- Fixed repeated Team Rocket trainer registration errors such as `AIR_ROCKET_ROCKET_9`.
- Rocket trainer registration is now idempotent across repeated `register:ready` and reload passes.
- Applied the same duplicate-registration protection to Pokémon Ranger trainer classes.
- Added a broader static audit for stale Pokegear identifiers, malformed colon-method checks, duplicate literal registrations and registration-time variable mistakes.
- Keeps RivalGear and all 7.2.x starter changes.
