# Pokégear + Kanto Trainer Phone Network — Feasibility Report

Brief §1 asks for an architecture audit before any code, and §2 for this report
before implementation. Everything below is read from the engine source
(`bryanthaboi/gen1recomp`, cloned) and from this mod, not inferred.

---

## The finding that shapes the whole design

`src/mods/Schemas.lua` (lines 620–639) states outright which Gen 2 registries
have **no Gen 1 home**:

```lua
--   phone_contacts  no Pokegear, no phone
--   landmarks       Red's town map is a Gen 1 town-map table, not the
--                   LANDMARK_* index space the Pokegear and the #DEX AREA
--                   page share
--   radio_channels  no radio
Schemas.GEN1 = {
  held_items = false, phone_contacts = false, decorations = false,
  apricorns = false, landmarks = false, radio_channels = false,
}
```

`false` means **the write is dropped and reported**. The comment above it is
explicit that this is not a spelling difference: *"the systems themselves are
absent from Red rather than spelled differently there."*

So the three registries this feature would most obviously want —
`phone_contacts`, `radio_channels`, `landmarks` — **do not exist on Red, Blue
or Yellow**. Nor is `src/ui/gen2/Pokegear.lua` reachable: `Gen2Compat` adapts
exactly fifteen module names and Pokegear is not among them.

**Consequence:** the Gen 1 Pokégear cannot be a thin wrapper over Gold's. It
must be a mod-owned subsystem that *targets* the engine's Gen 2 registries when
they exist and carries its own state when they do not. That is the same shape
`src/Phone.lua` already uses (Pokégear contact registration on Gold, news
ticker on Gen 1), so the pattern is proven here rather than novel.

---

## A — Implementable entirely as a mod

| | Why |
| --- | --- |
| **Phone/contact model, numbers, relationships, call history, missed calls, scheduler** | Pure mod state in `mod.save`. No engine seam needed. |
| **Pokégear UI (Clock / Map / Radio / Phone)** | `screens` is one of the registries that *works on both generations* (Schemas line 617). This mod already registers 7 screens and wraps `ui.start_menu.items`. |
| **Trainer phone network** | `data.trainers` is readable; contacts are our records keyed by trainer id. |
| **Rematches** | The `trainer.party` hook already returns a live party at battle time — this is how rivals fight with their real teams today. A rematch team is the same seam. |
| **Rival summoning** | Our AI already has objectives, destinations and a routed hop clock. §26 ("must not permanently overwrite their Life Path") is satisfied by a temporary high-priority objective, exactly as `CAREER_HOME` was added in 2.3. |
| **Broadcast/news content** | The 1.33–1.39 news channel and `Presence` already exist. §42 says reuse it, and we should. |
| **Weather / swarm reports** | `src/Weather.lua` reads Weather FX's live catalogue. §41's "never report a swarm that isn't real" is a data question we can already answer. |

## B — Needs an engine hook we already have

Deferral (§39: never interrupt battles, menus, cutscenes, saves) is served by
`core.update` plus the existing state probes. No new hook is required; the
scheduler simply refuses to fire unless the world is idle, which is the same
gate `observePresence` already uses.

## C — Needs Gen1Recomp core changes
**Nothing.** Everything in this brief is reachable from inside the mod.

1. **~~Trainer battles on Gold.~~ NONE — resolved in 3.1 with no engine
   change.** `queueScript` refuses `start_battle "trainer"`, but that is a limit
   of the *script verb*, not of the engine. `World:startBattle` takes
   `opts.trainer` directly, and `src/battle/gen2/Battle.lua:273-288` then calls
   the **`trainer.party` hook** — the same one our rivals have fought through
   since 1.1 — and states outright that "a mod that hands back rows it built
   itself keeps them". So the mod passes a trainer shell with an empty party
   and its own hook supplies the team. Nothing outside the mod changes.
2. **Radio audio.** `radio_channels` is Gen 2-only. Registering a *station list*
   on Gen 1 has no target. Playing music does — `audio`/`music` work on both.
   So a Gen 1 radio is feasible as **our own station model driving the shared
   music registry**, not as a `radio_channels` write.

## D — Existing systems to reuse (§1: do not duplicate)

`src/Phone.lua` (574 lines, absorbed in 2.5) — numbers, offers, cooldowns,
per-rival call reasons. **This is the contact system; it gets generalised, not
replaced** (§18, §46).
`src/Presence.lua` — the rate limiter and "what could the player notice"
observer. Calls are the same budgeting problem.
`src/Relationships.lua` — §17 asks for a trainer relationship scale. We have a
three-axis model with derived states. Trainers become subjects in the existing
bond store rather than a second scale.
`src/LifePath.lua` / `src/Career.lua` — §21 and §25 availability answers.
`src/AI.lua` objectives + `src/League.lua` escalation — summon travel and cooldowns.
`src/Weather.lua`, the news channel, `src/Version.lua` — reports and per-game routing.

## E — Gen 2 functionality adaptable

`gen2PhoneContacts` registration already works (`Phone:registerContacts`).
Gold's landmark index (`LANDMARK_*`) exists for the map. Neither is reachable
from Gen 1, so the Gen 1 map must be built from `Data.maps` and the mod's own
landmark list — which `Presence.PLACES` already approximates.

## F — Needs a new abstraction

A **CommunicationSystem** owning contacts, a call scheduler with priorities and
cooldowns, and a summon controller. §33 (no hard-coded numbers) and §30
(reusable event scheduler) both point at one registry-shaped model, and §29
warns it must be built so ordinary trainers can be summoned later without a
rewrite — so contacts are a *type field*, not a class hierarchy.

## G — Limitations, stated plainly

- **Radio**: no `radio_channels` on Gen 1; no ROM audio may ship (`modkit pack`
  refuses ROM-derived bytes). A Gen 1 radio drives existing music ids.
- **Clock**: `src/core/DateTime.lua` is generation-neutral and device-time
  based; Gold has a real in-game clock, Gen 1 does not. Weather FX exports
  `timeOfDay()` when present. So the Gen 1 clock is *device time + Weather FX
  time-of-day when installed*, and must never feed game timing (§5).
- **Map**: no `landmarks` on Gen 1; built from `Data.maps` instead.
- **NPC movement**: summoning must route through `canEnterMap`/`routeTo` like
  every other journey (§22's "never spawn inside walls" is the existing
  safe-placement path, and 2.5 already made an unknown sprite fail closed).
- **Background simulation**: the tick budget is real. §28's cooldowns are not
  only flavour — they are what keeps this affordable, exactly as the sighting
  budget is.
- **Save data**: schema is 6; all of this is additive with migration.

---

## Recommended staging

| | |
| --- | --- |
| **3.0** | `src/Comms.lua` — contact model generalised from `Phone.lua` (rival + trainer + professor + special), deterministic per-save numbers, call scheduler with priorities/cooldowns, call history and missed calls. No UI yet. |
| **3.1** | Pokégear screen shell: Clock + Phone pages, both generations, existing input abstraction. |
| **3.2** | Kanto trainer network: number offers after defeat, personalities, trainer call events. |
| **3.3** | Rematches with team progression that preserves trainer identity (§15). |
| **3.4** | Rival summoning: temporary objective, availability from Life Path, meeting locations. |
| **3.5** | Map page, then Radio as a station model over the shared music registry. |

**§53 of the brief is truncated mid-word** ("53. TRAINER CAL"), as the v2.x
brief was. Sections 1–52 are covered above; anything after is unread.
