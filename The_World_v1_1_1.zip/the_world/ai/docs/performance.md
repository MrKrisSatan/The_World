# Performance

A survey of what AI Rivals costs per frame, written against 4.6.0. Nothing
here has been applied — this is the costing, so the changes that land can be
argued about before they exist.

## What this is not about

There are two different performance complaints and they have nothing to do
with each other.

**Spikes** are one frame that takes 30 ms because the world tick it landed on
happened to run a headless battle. The mod already has machinery for these:
`Simulation.budget` caps rivals per tick (1 / 2 / 4 by profile), a gym battle
is one per tick (`ctx.allowGymBattle`), skirmish / title match / trade are
mutually exclusive, `recordPerformance` watches an EWMA and trips a 20-second
AUTO LOW after three samples over 12 ms, and `RuntimePolicy.trackPlayerMotion`
holds simulation time back until the player's feet stop.

**Steady state** is the work that happens on *every* frame whether or not a
tick runs. That is what this document is about, because it is almost entirely
waste, and it is what makes the spike land on an already-loaded frame.

`main.lua`'s header says "Nothing in this mod runs per frame." That was true
of the *simulation*. It is not true of `core.update`, which by 4.6.0 walks the
roster up to four separate times per frame before any tick is due.

## How to measure

MODS → AI RIVALS → PERFORMANCE (`SCREEN .. "Performance"`, main.lua:5908):

| Row | Means |
| --- | --- |
| SIM AVERAGE / MAXIMUM | Time inside `sim:update`, EWMA and worst ever. |
| WALK AVERAGE / MAXIMUM | Time inside `worldWalkDirector`. |
| AUTO FALLBACK | Seconds left on the emergency profile. Nonzero means the mod caught itself being slow. |
| SAFE REPAIRS | Rival positions rebuilt after a bad placement. |

Both counters were wall-clock around one call, so **neither saw any of the
findings below** — F1 to F7 all live in `core.update` *outside* those two
instrumented regions. A FRAME AVG / FRAME MAX row was added to this screen
(whole-hook timer, observational only — see main.lua:5427-5438 and
main.lua:5724-5736) so an actual before/after could be measured instead of
guessed. See Measured, below.

Roster size is the multiplier on everything here: `data/rivals.lua` authors
five rivals and generates slots 6–100, so `#M.rivals` is 5 in a default save
and can legitimately be 100.

## Measured — 2026-08-19, 50-rival save

Before any of F1–F7 were implemented, the new FRAME row was used to check
whether they were worth implementing at all. Fresh save, roster pushed to 50
at the Oak intro, standing in one spot for ~2 minutes after RESET METRICS:

| Row | Reading |
| --- | --- |
| FRAME AVERAGE | 0.53 ms |
| FRAME MAXIMUM | 8.04 ms |
| SIM MAXIMUM | 3.25 ms |
| WALK MAXIMUM | 4.83 ms |

Two things this settles:

- **The steady-state average is already small.** 0.53 ms is ~3% of a 60 fps
  frame budget. F1–F7 would cut a fraction of that — real, but not enough to
  be felt on desktop hardware.
- **The worst frame is fully accounted for by SIM + WALK.** 3.25 + 4.83 =
  8.08 ms, matching the 8.04 ms FRAME MAXIMUM with nothing left over. F1–F7
  live outside SIM/WALK — this arithmetic is what rules them out as the source
  of the spike, rather than confirming or denying it by guesswork.

**Conclusion: none of F1–F7 are recommended for implementation at this roster
size.** The waste they describe is real as a code-reading exercise, but it
isn't large enough, or in the right place, to justify the risk of touching
seven spots in `main.lua` for a saving that doesn't show up in measurement.
Revisit only if: the roster grows well past 50, the target shifts to
weaker/mobile hardware where the same relative saving would matter more
against a tighter budget, or a future FRAME MAXIMUM shows up that SIM+WALK
can no longer account for — which would mean the untested region has started
contributing after all.

The FRAME AVG/MAX rows are left in place either way: cheap, harmless, and the
instrument to reach for if any of the above changes.

## Findings

Ranked by (waste × how often it runs × how it scales with roster).

### F1 — `gauntletLabId()` called once per rival per frame

main.lua:5523

```lua
if M:gauntletDone() then
  local stuck = false
  for _, r in ipairs(M.rivals) do
    if r.map == gauntletLabId() then stuck = true break end
  end
```

`gauntletLabId()` is not a constant lookup. It calls `resolveGauntletLab`,
which walks four candidate map ids and calls `mapExists` on each, and
`mapExists` opens with `pcall(g.has, g, id)` — a protected call per candidate.
`resolveGauntletLab` then makes a *second* `pcall(graph.has, ...)` in its own
body for the same id.

The call is inside the loop, so the answer is recomputed for every rival, on
every frame, for the entire game after the intro — the branch is guarded by
`gauntletDone()`, which is true from the lab onwards. Best case (OAKS_LAB
matches first) that is one pcall per rival per frame: 300/second on the
authored roster, **6,000/second on a 100-rival save**, to recompute something
that cannot change while the game is running.

The scan itself is also near-dead: `r.map` can only equal the lab while the
gauntlet is staging, which is exactly when this branch is not taken.

**Change.** Hoist the call out of the loop, and memoise `resolveGauntletLab`
on the manager (invalidate where `M.graph` is rebuilt, i.e. `game.ready`).
Two lines, no behaviour change.

**Verify.** The gauntlet still runs on a New Game, and a save with a rival
forced into the lab still gets scattered.

### F2 — `observePresence` pays its whole cost to reach a guaranteed `nil`

main.lua:5656 → main.lua:2486

Runs on every frame the player is not moving. Per call it builds an `adjacent`
set, builds an `order` list, runs `table.sort` with a fresh comparator closure,
and then for each candidate rival allocates a sixteen-field view table
containing `Util.spaced(rival.map)` — a `gsub`, so a new string — before
`Presence.observe` is even entered.

`Presence.observe` then applies the gates that decide the answer:

```lua
if tick - state.lastTick < Presence.GLOBAL_COOLDOWN then return nil end
local last = state.byRival[id]
if last and tick - last < Presence.SIGHTING_COOLDOWN then return nil end
```

`GLOBAL_COOLDOWN` is 90 ticks and a tick is 1.5 s at NORMAL pace, so after any
sighting **the next 135 seconds of frames cannot produce another one** —
roughly 8,000 frames, each allocating five-plus tables, sorting a list and
building N strings on the way to a return value that was decided before it
started. `SIGHTING_COOLDOWN` is 240 ticks (six minutes) per rival on top.

The comment at the call site says it "costs a handful of comparisons per tick
and cannot spam the news channel". The second half is true. The first half
describes a gate that sits downstream of the cost.

**Change.** Two independent guards, either of which fixes it:

1. Early-return from `M:observePresence` when
   `tick - self.presence.lastTick < Presence.GLOBAL_COOLDOWN`. Same answer,
   none of the allocation.
2. Run the body at most once per world tick (`if self.presenceTick == tick then
   return end; self.presenceTick = tick`). Every input it reads — `tick`,
   `rival.map`, `rival.state`, `rival.objective` — is quantised to the tick,
   so a second look inside the same tick is definitionally the same look.

Do both: (1) is the correctness-shaped one, (2) is the general one. ~90× less
work in the common case, identical sightings.

**Verify.** There is no presence soak in `tests/`; the observable check is that
sightings still appear in the ticker at the same cadence over a long walk.

### F3 — the phone's clock is the frame counter

main.lua:5660 → `src/Phone.lua`

`Phone:update` is called every frame and opens with
`self.tick = (self.tick or 0) + 1`. Every phone deadline is denominated in that
unit: `rival.nextCallTime`, `rival.callCooldown = 40`, and the
`alreadyReported` windows of 300 / 400 / 500.

So **call frequency scales with frame rate**. At 60 fps a contact's 300-frame
report window is five seconds; on a 30 fps phone it is ten. The tuning done on
a desktop is not the tuning a handheld gets, and nothing in the save records
which one produced the stored `nextCallTime`.

The per-frame cost on top: the roster is walked in full (`ensureRival` for
each), and every rival that is not yet a contact runs `maybeOffer`, which calls
`LifePaths.phoneBias` and `relationshipScore` and — past the threshold —
allocates two literal string tables. On a 100-rival save with few contacts that
is up to 100 `maybeOffer` calls per frame, 6,000 per second.

**Change.** Give Phone a real clock. Accumulate `dt` and advance `self.tick`
once per elapsed 1/60 s (preserving today's 60 fps tuning exactly while making
it frame-rate independent), or convert the constants to seconds outright.
Either way the body then runs on a budget instead of on every frame.

**Migration.** Stored `nextCallTime` values are in the old unit. They are
absolute, not relative, so a save loaded after the change may skip one call
window or wait through one extra. Acceptable; worth a changelog line rather
than a migration.

**Verify.** `tests/pokegear_call_test.lua` drives the manager, not this clock —
a new case should assert that N seconds of `dt` produce the same number of call
attempts at 30 fps and at 60 fps.

### F4 — five call sites rebuild the collision grid; one caches it

`Pathfinder.grid` is built at main.lua:1506, 2711, 2851, 3051 and 3075. Only
the walk director caches (`walkMapCache`, main.lua:3148), and its comment
already states the invariant that licenses caching everywhere:

> Static terrain does not change while the player remains on a map.

A build is `mod.world:mapOverview()` plus W×H `string:sub` calls plus H row
tables. Route 12 is 20×72: ~1,440 sub-calls and 1,441 tables per build.
`chooseHopTarget` (3051 and 3075) can build two of them in one call, and
`placementFor` (2710) builds one per placement attempt.

**Change.** One `M:terrainGrid()` returning the memo the walk director already
keeps, with all five sites routed through it. Invalidation already exists in
both places it is needed (`map.entered` at main.lua:5329,
`repairRivalPosition` at main.lua:2680).

**Risk.** Low, but real: any site passing a *different* overview than the live
map's would now silently get the live one. All five read
`mod.world:mapOverview()` for the current map, so this is a rename rather than
a change — worth re-checking each one before landing.

### F5 — two pcalls and an NPC rescan per candidate cell

`validRivalCell` (main.lua:2661) calls `liveTerrainWalkable` and
`liveCellOccupied`; each independently calls `self:activeMap()`, which
allocates a closure and runs a `pcall`. `liveCellOccupied` then walks `ow.npcs`
in full.

`placementFor` evaluates that over a ring of candidate cells, so placing one
rival is O(cells × npcs) with two protected calls per cell. It runs on spawn,
on map entry and on every repair.

**Change.** Resolve the overworld once per placement and pass it down; build
one occupancy set (`"x,y" -> true`) instead of rescanning `ow.npcs` per cell.

### F6 — per-frame roster walks that could be per-tick

Three more full-roster loops run inside `core.update`:

- main.lua:5695 — the world-duel proximity scan, every frame, over every
  rival, whenever RIVAL DUELS is on and no challenge is live.
- main.lua:5613 / 5635 — `alreadyHere` and `arrived`, per tick (fine).
- `Simulation:runTick`'s three maintenance loops — per tick (fine).

The duel scan is the odd one out: it reads `rival.x`/`rival.y`, which only
change on a walk pulse (0.24–0.6 s), and `AI.wantsToChallenge`, which is
tick-shaped. Running it at the walk-pulse cadence changes nothing a player can
see.

### F7 — closures allocated to feed a guard that takes varargs

`Util.guard(label, fn, ...)` forwards varargs, but nearly every call site wraps
in a closure anyway:

```lua
Util.guard("presence", function() M:observePresence(playerMap, world) end)
```

Five of these per frame in `core.update`, plus `pcall(function() ... end)` at
main.lua:5686. `Util.guard("presence", M.observePresence, M, playerMap, world)`
is the same call with no allocation. Trivial individually; listed because it is
free and it is on the hottest path in the mod.

## Suggested order

Not current guidance — see Measured, above, which found none of this worth
doing at the tested scale. Kept as the order to reach for if that changes.

1. **F1** — smallest diff, largest constant-factor win, zero behaviour risk.
2. **F2** — largest total win, no behaviour change if both guards go in.
3. **F4** — contained, but re-read the five sites first.
4. **F7** — free, do it while `core.update` is open for F1/F2.
5. **F6** — needs a judgement call on duel responsiveness.
6. **F5** — most code, least frequent path.
7. **F3** — last, because it is the only one that changes what the player
   experiences, and it wants a test and a changelog line.

Before any of it: add the FRAME row to the PERFORMANCE screen, so that "this
got faster" is something the mod can show rather than something the diff
asserts.
