# Splitting main.lua — design pass

Written after the 4.6.1 phase-1 extraction (`src/ui/Status.lua`,
`src/debug/Commands.lua`, −750 lines). This is the map for the rest: which
module owns which shared state, and what breaks if it is guessed at instead.

No code has been moved for anything below.

## Where main.lua actually stands

5,928 lines. It is not an unstructured pile — `src/` already holds ~30
modules and main.lua is the *coordination layer* over them: one manager
object `M` with **119 methods**, plus every hook, event and screen
registration. So this is not "break up a monolith", it is "cut one very large
object along its seams", which is a different and fiddlier job.

The 19 module-scope privates left in main.lua are the seams. Each one is a
question: which file owns it, and who has to be handed it afterwards.

## The finding that changes the plan

**The proposed seven-file split misses the largest natural module in the
file, and would tear it into three pieces.**

The intro gauntlet is a ~1,000-line subsystem: 21 methods
(`beginGauntlet`, `gauntletDirector`, `talkGauntlet`, `endGauntletBattle`,
`finishGauntlet`, `skipGauntlet`, `gauntletStepTowardPlayer`,
`labWalkGrid`, `healPlayerParty`, …), its own constants
(`GAUNTLET_LAB_CANDIDATES`, `GAUNTLET_DETECT/ENGAGE/STEP_S`, `LAB_LABELS`,
`POST_LAB_STARTS_BY_KEY`) and its own private helpers (`mapExists`,
`resolveGauntletLab`, `gauntletLabId`, `postLabStarts`). It occupies roughly
lines 450–520 and 996–1960, nearly contiguously.

Under the proposed split it has no home, so it would be smeared across
Materialize (`moveRivalNpc`, `labWalkGrid`), Encounters (`talkGauntlet`,
`gauntletStartChallenge`) and Seams (`gauntletDirector`) — three files that
would then all need the same five gauntlet constants. That is how shared
mutable state gets duplicated, and duplicated state is the failure mode this
whole exercise is supposed to avoid.

**`src/manager/Gauntlet.lua` should be the first and largest extraction.**
It also resolves most of the contested state below, because those constants
exist *for* the gauntlet — they only look shared because the gauntlet has no
file of its own.

## Revised file plan

Sizes approximate, from method line ranges.

| File | ~Lines | Owns |
| --- | --- | --- |
| `src/manager/Gauntlet.lua` | ~990 | The whole intro sequence, lab resolution, lab labels, post-lab starts |
| `src/manager/Materialize.lua` | ~810 | spawn/despawn, placement, sprites, walk director, live-cell queries |
| `src/manager/Encounters.lua` | ~680 | rival menu, challenge, battle handoff, `ai_rivals:talk` |
| `src/manager/Comms.lua` | ~400 | trainer.party hook, phone contacts, trainer calls |
| `src/manager/Persistence.lua` | ~310 | save / load / migrations / gen2 party sync |
| `src/manager/Roster.lua` | ~250 | build, setRivalCount, seed, affection graph |
| `src/manager/Seams.lua` | ~370 | `core.update`, the event subscriptions |
| `src/ui/Ticker.lua` | ~55 | `render.hud` news ticker (presentation, belongs with Status) |
| `main.lua` | ~400–600 | loader, options, `M` table, boot order, exports |

Note this lands nearer **~500 lines** than the ~300 originally sketched, and
that is the honest floor: the `M` table literal, `mod.options:define`, the
module loader and the boot/exports sections are irreducible.

## The shared state, and who should own it

This is the part that matters. Nineteen module-scope privates; most are
unambiguous, four are not.

### Unambiguous — one caller cluster each

| Private | Call sites | Goes to |
| --- | --- | --- |
| `mapExists`, `resolveGauntletLab`, `gauntletLabId` | gauntlet + 4 outsiders (see below) | Gauntlet |
| `LAB_LABELS`, `GAUNTLET_*`, `POST_LAB_STARTS_BY_KEY`, `postLabStarts` | gauntlet only | Gauntlet |
| `RIVAL_SPRITE_PREFER` | 1 (`spriteForRival`) | Materialize |
| `homeMapsFor` | 3 (seed/build) | Roster |
| `activeRoster` | 2 (build, setRivalCount) | Roster |
| `detectGeneration`, `mapsTable`, `registerGen1Trainers`, `registerGen2Trainers`, `registerTrainers`, `registerTalkScripts`, `rivalTalkHandler` | boot registration | stay in main.lua (boot order) |
| `playerSlotData`, `applyPersistentMoves` | 4 (party construction) | Encounters |
| `applyRevealedPlayerMoves` | 2 (battle events) | Seams |
| `startOrSeedRivals` | 2 (`game.ready`, `save.loaded`) | stay in main.lua (boot order) |
| `performanceClockMs` | 5 (perf instrumentation) | stay in main.lua |
| `runningOnIOS` | 3 (gauntlet script paths) | Gauntlet |
| `SAVE_VERSION` | Persistence | Persistence |
| `TALK_TEXT` | spawn + talk registration | main.lua (both sides need it) |
| `SCREEN` | already resolved in phase 1 | main.lua, passed in |

### Contested — the four that need a decision

**1. `getOverworld` / `overworldIdle` / `overworldRunnerIdle`** — used by
Gauntlet (1616, 1636, 1651, 1667, 1851, 1936), Encounters (4183, 4184, 4014,
4194, 4246), Comms (4872) and `core.update` (5473, 5479, 5497, 5498, 5522,
5663). Three-way shared, and the most-called helpers in the file.

*Decision:* they are not gauntlet helpers, they are **world-state queries**.
They should become manager methods that survive on `M` itself (as they
already are) and simply be called through `M:` from every extracted file —
no new module, no passing. This is the one case where "leave it on the
manager" is the right answer rather than a dodge: every file already holds
`M`.

**2. `moveRivalNpc`** — Gauntlet (1584, 1818) and Materialize (3332).

*Decision:* **Materialize owns it**; it is an NPC-motion primitive, and the
gauntlet is one of its callers. Gauntlet calls `M:moveRivalNpc(...)`. Same
reasoning as above: it stays a manager method, its *implementation* moves to
Materialize.

**3. `LAB_SLOTS`** — Gauntlet (1814) and Materialize (2953, 2958).

*Decision:* **Materialize owns it.** It is a placement table (fixed cells
inside the lab); the gauntlet consumes placement, it does not define it.
Gauntlet needs a small accessor (`M:labSlots()`) rather than the raw table,
so only one file can mutate it.

**4. `gauntletLabId`** — 14 call sites, but only 4 outside the gauntlet:
`setRivalCount` (934), `load` (2154), `facedRival` (4541) and `core.update`
(5541). All four ask exactly one thing: *which map is the lab.*

*Decision:* no sharing needed. `M:gauntletLab()` **already exists** as a
public method wrapping the same resolver. The four outsiders switch to it and
the private stays inside Gauntlet.

## The rule phase 1 established

Registration order is **observable**, not cosmetic. `Status.install` must run
before `Pokegear.init` or the RIVALS row moves in the pause menu. So every
extraction keeps its `install(mod, M, …)` call at the exact line the
registrations used to occupy — never hoisted to the bottom of the file for
tidiness. `tests/modular_main_static.py` now asserts that ordering explicitly
so a future tidy-up cannot silently undo it.

Same file contract each time: `local X = req("path")` at the top, `X.install(mod, M, …)`
in place, `return X` at the bottom, and a static-test entry.

## Suggested order

1. **Gauntlet** — biggest win, and it resolves most of the contested state.
   Do it before Materialize, because deciding `LAB_SLOTS`/`moveRivalNpc`
   ownership is easier when the gauntlet is already isolated.
2. **Persistence** — self-contained, and the easiest to verify (load a save,
   check the rivals came back).
3. **Materialize** — large but coherent; needs `LAB_SLOTS`/`moveRivalNpc`
   settled first.
4. **Comms** and **Encounters** — these two touch each other (phone battles
   route through the challenge path); do them adjacently.
5. **Roster**, **Ticker**, **Seams** — the remainder.

## What I would not do

- **Do not do this in one pass.** Seven files at once has no safe rollback
  point and nothing to bisect when a save misbehaves.
- **Do not chase a ~300-line main.lua.** The boot order is genuinely
  load-order-sensitive; forcing the last 200 lines out would mean inventing
  indirection that makes the sequence harder to read, not easier.
- **Do not extract for performance.** It buys nothing measurable (see
  `docs/performance.md`) — the case for this work is manageability alone.

## Verifying each step without a Lua runtime

There is no standalone Lua on the dev box and the test suite needs the engine
monorepo's `tests.modkit`, so each extraction is checked by:

1. **Block-balance arithmetic** — count `function`+`if`+`do` vs `end` (with
   comments and strings stripped) before and after; the totals must be
   conserved exactly across the files touched. This caught nothing in phase 1
   because phase 1 was clean, but it is what *would* catch a cut made in the
   middle of a construct.
2. **Bidirectional dependency scan** — every module-scope private grepped
   against the new file (does it reach for something that did not come with
   it?) and the new file's identifiers grepped against main.lua (did anything
   left behind still reference what moved?).
3. **A static-test entry** asserting the require, the install call, the
   module return and, where it matters, the install *order*.
4. **In-game confirmation by the player**, which is the only real test:
   phase 1's was "open the RIVALS menu". Each step below should name its
   equivalent before it starts — for Gauntlet it is a New Game through the
   lab sequence; for Persistence it is a save/reload round-trip.
