# AI Rivals

## 4.1.0

**Rivals can be talked to on Gold.** Pressing A at a rival did nothing there.
Gold's `World:interactBody` walks a fixed ladder — trainer flag, strength
boulder, itemball, `npc.def.scriptKey`, bg events, tile events — and a
mod-spawned rival matches none of them: it cannot carry a `scriptKey`, because
that names bytecode in the cart's own extracted script table. The press fell
through to `interacted(..., "none")`. The `world.interacted` fallback could not
rescue it either, because Gold raises the `"npc"` kind only from the scriptKey
arm — so the one event the Gen 1 path listens for is never raised for exactly
the objects this mod spawns.

Rivals now use the seam Gold provides for this: `interactBody` asks
`Gen1Facade.talkToWrapper()` — a mod's replacement of
`OverworldController.talkTo` — before any built-in arm, and a true return
suppresses the built-in path. `talkTo` is a *backed* member of the
OverworldController facade, so this needs no engine patch.

`src/Gen2Talk.lua` owns that field and everything else registers a handler with
it. Wonder Trade's Gold attendant, which previously replaced `talkTo` on its
own, now goes through the same router: two independent replacements of one
mutable engine field made correctness depend on install order and on each
remembering to chain. Handlers run by priority, one that raises is contained
rather than breaking the A button for the whole map, and re-registering an id
replaces it instead of stacking (`game.ready` fires again on a New Game).

**Double battles no longer softlock when a Pokémon faints.**
`__dbExecuteAction` *borrows* the canonical slots — swapping
`battle.enemy`/`enemy2` so the many Gen 1 move effects that read
`battle.enemy` internally reach the right body. A partner that fainted *inside*
that borrow had its replacement written straight to `battle.enemy2`, which
mid-borrow held the real **lead**. The lead was overwritten and lost, the dead
partner stayed in `battle.enemy`, and the restore — guarded on battler identity
— saw a changed pair and skipped, precisely when it mattered most.

From there the fight could never be won: `enemyMonFainted` was unreachable
(`onFaint` saw a stale `__dbSideSlot` on the lead and took the partner arm every
time) and `executeAction` no-ops on a target at 0 HP, so the battle cycled
menu → move → messages → menu with nothing visibly happening.

Fixed by making the borrow explicit and unconditionally reversible, routing
every slot write from a faint path through role-aware accessors, and adding a
hard guard so a battler that *is* the logical lead can never take a partner arm
whatever its stamp says. Slot stamps are re-derived at each turn boundary, and
the `__dbReplaced` chain walk — a mutable map that both faints and switches
write into — is now bounded and cycle-checked.

**No more generation guessing at boot.** Two places decided what to register
before anyone could know which game was running. At the entry chunk `mod.game`
is often not up, and `detectGeneration(nil)` answers 1, so Gen 1 `map_scripts`
were registered onto Gold — reported as *"the map_scripts registry has no Gen 2
target"* in the mod manager's error feed on every launch. Wonder Trade had the
same fall-through, and additionally consulted `src.core.GameVersion`, which is
not one of the fifteen names the Gen 2 adapter serves and therefore reports
generation 1 on Gold. An unknown generation is now unknown: registration waits
for `game.ready` rather than acting on a guess.

**Testing.** `tests/double_faint_test.lua` plays 54 complete double battles
across both formats and asserts that returning to the command menu never leaves
a fainted body in the enemy lead slot; against 4.0.0 it produces 33 failures and
16 desyncs. `tests/gen2_talk_test.lua` covers the router's ordering, chaining,
idempotence and error containment. `tests/ownership_static.py` locks in the two
ownership rules so neither shape can be reintroduced. Two new public exports,
`decorateTrainerDouble` and `decorateTrainerPairBattle`, stage a double battle
without a live overworld — the faint flow had no test because it was
unreachable from one.

## 4.0.0

- Split three high-conflict responsibilities out of `main.lua`:
  `BattleFlow.lua` owns challenge transaction identity and release,
  `RuntimePolicy.lua` owns player-motion timing and simulation profiles, and
  `RosterPolicy.lua` owns live roster counts and creation presets.
- `main.lua` is now the composition root for those policies rather than
  duplicating their decisions inside engine hooks. The modules are exported
  for tests and integrations, allowing contributors to work on battle flow,
  scheduling, and roster UX without editing the same file.

## 3.9.0

- Fixed completed rival challenges leaving the global battle transaction
  locked. Normal `battle.ended`, blackout, failed launch, and failed queue
  paths now share one identity-checked release function; builds that report a
  borrowed trainer class use the active rival id as the authoritative match.
- Rival simulation now advances while the player is walking. Existing `near`
  guards still prevent visible rivals from abstractly moving or training.
- Fainted rivals already at a Pokémon Center are healed in an unbudgeted
  maintenance sweep, so a 100-rival round-robin cannot leave them at zero HP
  while waiting for their scheduled AI turn.

## 3.8.0

- Double battles now retain the two vanilla lead HP boxes and attach one
  native, matching box for the second enemy and ally. The separate four-row
  screen overlay has been removed.
- The doubles Pokémon/target selector is centered over the battlefield.
- Enemy faint handling now rewrites queued targets to the promoted or incoming
  battler, clears stale prompt/action state, synchronizes both side lists, and
  emits the normal switched-battler setup event for replacements.

## 3.7.0

- Added Shawn as a permanent authored rival without increasing the 100-rival
  cap. His exclusive Heartbreak Kid personality is charismatic, aggressive,
  rivalry-driven, and treats battles as main events. Shawn has dedicated
  greetings, challenges, relationship lines, victory and defeat reactions,
  League dialogue, and the line “I'm your frenemy.” A five-rival creation
  preset makes the original quartet plus Shawn directly selectable.

## 3.6.2

- Fixed the four-battler HUD being scaled twice in the final `render.hud`
  pass. Panels now convert their native anchors to screen coordinates exactly
  once and use the active screen font fitted to each compact row.

## 3.6.1

- Rebuilt the double-battle HP display after live wide-layout testing. The
  four readouts now replace the two reserved vanilla status regions with two
  compact rows per side, use the engine font's correct light-background/dark-
  text palette, and render after other HUD mods at the viewport's final scale.
  This removes the opaque black rectangles and prevents modern UI panels from
  painting over half the double HUD.

## 3.6.0

- The selectable roster now supports up to 100 concurrent rivals. The original
  four remain the upgrade default; new games can choose 1, 2, 4, 10, 25, 50,
  or all 100, while the opening gauntlet remains capped at four.
- Eight new personality archetypes join the original four. Slots 5-100 choose
  their personality deterministically from the saved world seed, producing a
  different but reload-stable cast in each playthrough.
- Five complete life paths and careers were added: Battle Coach, Ranger,
  Courier, Photographer, and Type Specialist.
- Career eligibility scales to a deterministic 10-25% of casts larger than
  four, while the original four-rival probability distribution is preserved.

## 3.5.1

- Double battles now keep four compact HP readouts on screen: both enemies,
  the player's active Pokémon, and the active rival companion. The overlay is
  implemented entirely through the mod's battle hook and capability-gates its
  font dependency for builds that do not expose the Gen 1 renderer.

Between one and four AI trainers travel Kanto (and Johto on Gold) on their own
clock. They route across the real map graph, train on routes, heal at Poké Centers, queue
at gym doors, win **and lose** gym battles, keep their own badge case, and
turn up to fight you with whatever party they actually have at that moment.

The design rule behind every decision below: **nothing is faked.** A rival's
badges are won in a simulated battle against the gym leader's real party out
of the merged `trainers` table. Its levels are earned through an exp curve.
Its route is a breadth-first search across the map connections the game
actually ships. If a thing could not be done honestly, it is not done.

---

## What's new in 1.31.2

- Added an AI Rivals-side compatibility shim for Kanto Reforged 1.2.0's
  trainer-battle action wrapper. Potions and other targeted medicine now keep
  the selected player-party Pokémon instead of being redirected to the enemy.
- Kanto Reforged itself is not patched or bundled. The shim activates only
  when that separate mod is installed and restores the Pokémon record after
  every item action, including error paths.

## What's new in 1.31.1

- Rival item gifts now follow the player's badge progress. Before defeating
  Brock, rivals can give only Potions and ordinary Poké Balls; stronger healing,
  status, ball, and rare-item rewards unlock across later badge milestones.
- After all eight badges are earned, each defeated rival has one 15% chance to
  give a Master Ball. This special reward is rolled once and is never selected
  by the ordinary or consolation-gift paths.

## What's new in 1.31.0

- Fixed manual rival challenges on iOS. All Gen 1 hosts now run only the
  dialogue through the script runner, wait for the closing UI to clear, and
  directly push the trainer battle. iOS no longer uses the silently accepted
  `queueScript` battle row that produced “SINGLE battle accepted” with no fight.
- Rivals at Poké Centers now occasionally Wonder Trade a boxed duplicate before
  selling surplus Pokémon. Results are shiny, perfect-DV, level-matched species
  selected from the live merged pool and respect Kanto Reforged scope.
- Rivals can form persistent attachments to Pokémon obtained by catching or
  trading. Shiny status guarantees a bond; rare catch rates, high base-stat
  totals, and Weather FX variant identity increase the chance.
- The strongest bonded Pokémon becomes the rival's ace. Aces are protected
  from sales, PC deposits, and trades, receive a decisive active-team selection
  bonus, carry shiny/DV data into real battles, and persist across save/load.

## What's new in 1.30.0

- Fully absorbed Wonder Trade. An attendant is installed in each supported
  Kanto and Johto Poké Center; the separate `wonder_trade` mod must be removed.
- Rebuilt receiving as an atomic transaction: a random Pokémon is constructed,
  schema-validated, and given perfect DVs/shiny metadata before the selected
  party slot changes. Constructor, event, text, evolution, and UI failures now
  degrade without losing the sent Pokémon or crashing the game.
- The pool is rebuilt from live merged species data for every trade, so Kanto
  Reforged additions and all registered Weather FX variants are eligible.
- Modded string-ID species without a ROM index bypass `TradeAnim`, which indexes
  ROM sprite tables and caused the reported crash when receiving such Pokémon.
  They use a safe text/evolution handoff; ordinary indexed species retain the
  normal animation.
- Pokédex seen/owned/caught state is populated defensively for received species,
  and Kanto Reforged's active regional scope is respected.

## What's new in 1.29.4

- Fixed manual rival challenges on Android/mobile builds that accepted a
  queued `start_battle` command but never executed it. Gen 1 challenges now
  run dialogue through the script runner, wait for the text stack to close,
  and push the trainer `BattleState` directly through the proven gauntlet path.
- Gen 2 and iOS retain the engine-owned queued battle route where direct
  trainer-state construction is not portable.

## What's new in 1.29.3

- Fixed item turns in decorated wild/trainer double battles. Potions and other
  consumed items now retain the engine's messages and HP-bar animation, then
  schedule the companion and both opposing battlers through the normal
  four-battler resolver instead of falling through the vanilla 1v1 shortcut.

## What's new in 1.29.2

- Fixed Weather FX interoperability for off-screen rival battles by adding
  the missing lazy `battleWeather()` capability accessor.
- Psychic weather affinity, residual immunity, and special-category handling
  now accept the engine's canonical `PSYCHIC_TYPE` ID as well as its display
  name. This also supports Weather FX's persistent variant species.

## What's new in 1.29.1

- Double-battle moves now borrow the selected battler into the Gen 1
  engine's canonical target slot for the duration of action execution. This
  fixes attacks and status moves always resolving against the right-hand
  Pokémon after the player selected the left-hand target.
- The same scoped handoff canonicalizes partner users, so companion and enemy
  partner actions retain the correct attacker identity. Slots are restored by
  identity on both success and error paths.

## What's new in 1.29.0

- Rival accompaniment now uses the proven FOLLOWERS_EX trail model: the
  player's previous committed cell becomes the companion's goal, and the live
  NPC animates through normal `targetX`, `targetY`, `moving`, `progress`, and
  `stepFrames` fields.
- Following no longer depends on guessed `walkTo`/`moveTo` facade methods and
  never uses the global scripted-movement queue. It therefore preserves the
  engine's normal walker frames without locking player input.
- Companion trails reset safely on map entry, dismissal, and companion swaps;
  collision/HM/doorway rules from AI Rivals remain authoritative.
- Movement architecture was adapted from the supplied FOLLOWERS_EX 1.0.19
  reference; its party-control, Pokémon sprites, and unrelated hooks are not
  bundled.

## What's new in 1.28.2

- Second-slot battlers now retain side-specific ownership tags, preventing
  simultaneous knockouts from entering the wrong faint/replacement handler.
- Companion following no longer uses the global scripted-movement queue that
  can lock player input. Object-local animation is preferred, with a safe
  collision-checked position fallback for older engine builds.
- Companion battle AI now supports both known battler move layouts and turns
  fallback move IDs into valid battle actions.
- The Rivals start-menu entry now follows the live character-created roster,
  invalid saved companion IDs are cleared, and trainer Pokémon are no longer
  described as wild when they faint in slot two.

## What's new in 1.28.1

- The player now selects actions only for their own Pokémon in accompanied
  double battles. The rival companion independently selects its move and
  target using battle AI.
- Hardened player faint/replacement handling by temporarily separating the
  external companion from the vanilla single-party switch menu. This prevents
  the replacement state from waiting on or selecting a rival-owned Pokémon.
- Companion overworld steps now use the engine's walking animation rather
  than snapping between adjacent tiles. A watchdog releases a follower if an
  older engine fails to fire the movement completion callback.

## What's new in 1.28.0

- Character creation now asks how many AI rivals should inhabit the world:
  one, two, three, or all four. The answer immediately controls the live
  roster, intro gauntlet order, spawning, simulation, interactions, and saves.
- Roster size persists per playthrough. Existing saves without the new answer
  retain their configured legacy roster, and all trainer definitions remain
  registered so changing saves does not invalidate game data.
- Added personality-specific conversation lines across idle time, travelling,
  training, Gym preparation, healing, exploration, and defeat. Chris remains
  combative, Dyanari terse and speed-focused, Matt curious and collection-led,
  and Larissa analytical.

## What's new in 1.27.1

- Fixed rival action menus on touch/iOS and other front ends that return a
  selected menu row instead of its value.
- Added a bounded overworld-idle fallback so stale screen-stack state cannot
  leave Challenge, Accompany, Help, Trade, or Safe Tile queued forever.
- Rivals now remember each Poké Center they actually visit. If their whole
  party faints, they black out directly to the most recently visited Center
  (or the nearest known Center when no visit has been recorded yet).
- A fainted companion is dismissed and blacks out instead of being dragged
  back to the player by companion-follow logic.

## What's new in 1.27.0

- **Challenges use the current team.** Pressing CHALLENGE never sends a rival
  away, withdraws a Pokémon or teaches a TM. The battle starts with whatever
  team and moves the rival has at that moment.
- **Center-only counter preparation.** Losses create a persistent counter goal,
  but PC withdrawals and deliberate TM changes wait for a genuine Poké Center
  visit. Team selection happens before TMs are spent, and only selected party
  members are eligible to receive them.
- **Fair player scouting.** Rivals remember the species and levels they faced
  and moves actually selected in instrumented battles, but no longer read every
  unused move directly from the player's save party.
- **Move-shape compatibility.** Companion move IDs are converted to the engine's
  native string or record representation, preserving PP where supported.
- **Explicit story safety.** Known rival, Gym Leader, Elite Four, Champion and
  scripted boss classes remain single battles even on engine builds that omit
  fixed-format metadata.

## What's new in 1.26.2

- **Eligible trainer doubles restored.** Ordinary script-launched trainers can
  become doubles while accompanied; explicit fixed-format, solo and protected
  story battles remain single.
- **Complete companion synchronization.** HP, level, experience, species,
  learned moves, status and available move PP are copied back from the battle
  Pokémon. The temporary ally also enters with the rival's persistent moves,
  experience and status.
- **Atomic companion switching.** A replacement rival's HM access is validated
  before dismissing the current companion.
- **Accurate Pokédex sightings.** A proposed second foe is marked seen only
  after double-battle construction succeeds.

## What's new in 1.26.1

- **Companion-only doubles.** Wild and trainer battles remain single battles
  unless a healthy rival is actively accompanying the player.
- **No global battle conversion.** The old `TRAINER 2V2`, background wild
  double and solo-side options were removed, so saved option values can no
  longer convert ordinary battles or exclude the accompanying rival.
- **All entry points gated.** Trainer pairs, explicit double-battle commands,
  scripted exceptions and deferred wild partners now verify the companion at
  decoration time. Dismissing a companion restores normal single battles.

## What's new in 1.26.0

- **Opponent scouting.** Rivals persist the species, levels and revealed moves
  they legitimately observe when battling each rival or the player, together
  with their matchup record. They do not inspect an unseen player team.
- **Counter-team selection.** Before rival rematches, both opponents rank their
  active team and PC collection for offensive coverage, defensive resistance,
  level and overall type variety. Both choose simultaneously from the teams
  visible before switching, preventing a second-mover advantage.
- **Matchup-aware TMs.** Owned TMs are evaluated against the scouted opponent
  and can be taught before the rival withdraws its best counter team.
- **Persistent adaptation.** Scouting records and matchup results survive save
  and load, allowing recurring rivalries such as Matt versus Chris to evolve.

## What's new in 1.25.6

- **Fully deferred talk menus.** The primary map-script interaction now waits
  for an idle overworld frame before opening the action menu, matching the
  safe fallback path on desktop and iOS.
- **Truthful battle handoff.** A direct script runner that refuses a challenge
  no longer leaves the rival waiting for a battle that never started.
- **Safe item gifts.** Inventory APIs returning `false` are treated as failed
  grants, so the rival keeps an item the player's bag did not accept.
- **Bounded news ticker.** Consecutive duplicate headlines are suppressed and
  the transient queue retains at most eight recent items.

## What's new in 1.25.5

- **Responsive rival actions.** Challenge, accompany/dismiss, safe-tile repair,
  help and trade now execute after the menu closes and the overworld is active.
- **Reliable manual challenges.** Player-requested battles are no longer blocked
  by the AI's automatic encounter cooldown.
- **Broader battle handoff support.** Challenges work with either the queued
  script API or the direct script runner used by compatible gen1recomp builds.
- **Race-free UI handoff.** Rival simulation pauses while a menu or selected
  action is waiting for an idle overworld frame, preventing ignored inputs and
  stale map targets on desktop and iOS.

## What's new in 1.25.3

- **A real talk action on every Gen 1 map.** Runtime rivals now carry a stable
  object index and `AIR_RIVAL_TALK` text binding. The shared talk handler is
  composed into every supported map script, as required by gen1recomp's dynamic
  NPC contract; `world.interacted` is retained only as a fallback.
- **No unsolicited battle on A.** The authoritative talk script opens the rival
  action menu. It no longer substitutes a greeting or automatic challenge.
- **No visible abstract levelling.** A rival on the player's current map cannot
  receive simulated training EXP. Off-screen training also requires a real wild
  encounter table for that route or cave.
- **Legal skip starts.** Character-creation SKIP uses the fixed early-game
  release positions. Chris starts on Route 1 instead of being reassigned to a
  Pallet Town home beside Oak's Lab.

---

## What's new in 1.25.2

- **Skipping no longer grants a head start.** The rivals are placed in the
  world but their simulation clocks remain frozen until the player owns a
  starter and the normal Oak's Lab battle against Blue has finished. Long Oak
  dialogue therefore cannot train them to Lv13-14 before play begins.
- **iOS interaction menus open reliably.** A rival interaction is resolved by
  runtime handle, numeric ID, or its stable `AIR_<id>` object name, then the
  menu is pushed on the next idle overworld frame instead of from inside the
  iOS touch callback.
- **The start lock persists.** Saving or reloading between choosing SKIP and
  fighting Blue cannot start rival time early.

---

## What's new in 1.25.1

- **Optional lab gauntlet.** Character creation now asks whether to PLAY or
  SKIP the AI-rival gauntlet. SKIP is stored for that playthrough, permanently
  retires the lab sequence, and starts the rivals at legal world locations.
- **iOS-native battle handoff.** On iPhone and iPad the gauntlet uses the
  engine's ordinary queued trainer script instead of constructing and pushing
  an internal BattleState. This preserves touch-controller focus and avoids
  iOS state-stack timing failures between dialogue and battle.
- **Fair skipping.** Skipping awards no wins, badges, money, levels, items, or
  player story flags; rivals enter the world with their normal starter state.
- **Existing-save recovery.** While a gauntlet is active, the Rivals screen
  exposes SKIP GAUNTLET so an older iOS save can leave a broken sequence.

---

## What's new in 1.25.0

- **Direct rival action menu.** Pressing A on a rival now opens a compact menu
  instead of showing the full trainer-card/status page first.
- **Six working actions.** The menu offers CHALLENGE (with SINGLE, DOUBLE,
  FAINTED, or UNAVAILABLE status), ACCOMPANY or STOP ACCOMPANYING, MOVE TO SAFE
  TILE, GIVE HELP, and TRADE.
- **Clean companion switching.** Asking a new rival to accompany you properly
  releases the previous companion back to their independent journey.
- **Reliable challenge feedback.** Cooldowns and missing player parties display
  UNAVAILABLE, and a battle is reported as accepted only when the engine's
  script queue accepts it.

---

## What's new in 1.24.9

- **Rivals stay near the player's level.** Their progression ceiling is now
  also limited to three levels above the player's strongest active Pokémon;
  the existing badge and next-Gym ceiling still applies when it is lower.
- **Training uses encounter time.** Four rival simulation visits now represent
  one completed training encounter. The former one-encounter-per-visit rate
  could compress roughly 100 training battles into five minutes.
- **Existing runaway saves self-correct.** The normal legality pass brings an
  over-levelled rival back inside the player-relative ceiling while preserving
  its species and taught moves.

---

## What's new in 1.24.8

- **Gauntlet conversations are one-shot.** Pressing A or receiving another
  interaction while a rival's automatic introduction is closing can no longer
  queue duplicate dialogue or a duplicate battle.
- **Battle handoffs wait for the overworld.** The gauntlet now launches the
  trainer battle on a later idle frame, after the text screen has actually
  left the state stack. A rejected launch retries the battle only; it never
  repeats the rival's speech.
- **Safe save/load recovery.** Saves made during a gauntlet introduction or
  battle-launch transition resume at a clean challenge boundary rather than
  waiting forever on a callback that cannot be serialized.

---

## What's new in 1.24.7

- **No four-step simulation hitch.** Expensive world ticks no longer run in
  frames where the player is actively walking. Rival time resumes after a
  short natural pause, preventing the 1.5-second simulation cadence from
  interrupting every few player steps.
- **Pathfinding stays off movement frames.** Visible-rival A* work and local
  movement are deferred until the player pauses.
- **No runtime-NPC rebuild loop.** If an older engine offers no independent
  NPC movement operation, that rival stays safely in place until a map reload
  instead of being removed and respawned several times per second.

---

## What's new in 1.24.6

- **Rival movement no longer locks player input.** Rival steps no longer use
  the overworld cutscene movement queue or its shared busy flag. Each visible
  rival now moves through an NPC-local operation, with an isolated runtime-NPC
  fallback for older engines.
- **Rivals cannot imprison the player.** Their visible objects are pass-through
  for player collision while remaining interactable. Rival pathfinding still
  treats the player, terrain and other NPCs as occupied, so rivals continue to
  navigate around them instead of walking through the world.

---

## What's new in 1.24.3

- **Canonical Kanto area gates.** Rivals can no longer wander from Pallet into
  Cerulean, Vermilion, Celadon, Lavender, Fuchsia, Saffron or Cinnabar before
  reaching the corresponding stage of their own badge journey. This models
  story blockers absent from the raw map graph, including Snorlax and Cycling
  Road access.
- **Every map crossing is revalidated.** A stale route cannot carry a rival
  across a Surf route or another badge/HM gate. Existing saves with a rival
  already beyond an illegal gate recover that rival to an accessible home map
  while retaining its party, PC, inventory and progression.

---

## What's new in 1.24.2

- **Ticker rendering no longer affects the game screen.** The world-news
  overlay now restores the engine's colour/opacity and clipping state after
  every frame. Headline fade-outs therefore cannot fade subsequent overworld
  rendering when rivals level up, learn moves, battle or generate other news.

---

## What's new in 1.24.1

- **Headless simulation stays invisible.** Training, evolution and simulated
  rival battles no longer re-run live NPC materialisation on every world tick.
  This removes the object-layer refresh associated with repeated white
  fade-out/fade-in effects on affected engine builds.
- **Arrival-only materialisation.** A runtime NPC is now spawned after a
  simulation tick only when that rival genuinely crossed onto the player's
  current map. Existing rivals are left untouched.

## What's new in 1.24.0

- **Explicit battle actions.** Every rival menu now offers CHALLENGE and TALK
  AGAIN. Challenge displays SINGLE, DOUBLE, FAINTED or UNAVAILABLE before it
  is selected and respects battle cooldowns and companion identity.
- **Scripted-battle protection.** Fixed story and trainer scripts remain
  single battles even with a companion. Only an explicit rival challenge can
  grant a one-use scripted-double exception.
- **Companion battle recovery.** HP, level and experience return to the rival
  after wins, losses, captures and normal exits. Blackout handling consumes
  the same snapshot safely when `battle.ended` is absent or arrives later.
- **Health-aware doubles.** Companion availability requires a healthy active
  Pokémon, and rival challenges require two healthy opponents before being
  labelled DOUBLE.

## What's new in 1.23.0

- **Press-A rival interaction everywhere.** Roaming runtime NPCs are resolved
  through `world.interacted`, so every rival speaks and then opens its own
  action/details menu without registering a script on every game map.
- **Safe map compatibility.** Only Oak's opening lab retains the direct talk
  text id needed for its progression sequence. Ordinary maps no longer need a
  rival talk entry and therefore cannot reproduce the S.S. Anne script error.
- **One consistent rival menu.** Start-menu selection and direct overworld
  interaction now build the same live details and actions.

## What's new in 1.22.0

- **Live performance diagnostics.** The Rivals menu reports rolling and peak
  simulation/pathfinding time, active profile, recovery count and automatic
  fallback status. Metrics can be reset after reproducing a slowdown.
- **Automatic low-cost fallback.** Three repeated slow rival updates suspend
  autonomous visible walking for 20 seconds and reduce polling frequency.
  Companion following remains active, and the selected profile automatically
  resumes after the cooldown.

## What's new in 1.21.2

- **Companions respect HM gates.** A rival cannot be invited while standing
  beyond a field move it cannot use. If the player crosses a new HM gate, an
  unqualified companion stays on the previous map, leaves accompany mode and
  begins searching for a compatible Pokémon rather than teleporting through.
- **Companion HM use is real.** Qualified companions record the field move,
  visit the destination normally and publish their queued HM news even while
  autonomous simulation is paused for accompany mode.

## What's new in 1.21.1

- **HM soft-lock recovery.** A rival blocked from its next Gym or the League
  searches reachable grass encounters for a species compatible with the
  missing HM. Surf-dependent encounters are never used to solve Surf itself.
- **Visible HM motivation.** Rival detail pages show the current HM goal and
  travel reasons name the Pokémon and field move being sought.
- **HM world news.** Obtaining, teaching and using HMs—and beginning a hunt
  for a compatible user—now produce ticker and news-history events.

## What's new in 1.21.0

- **Private HM progression.** Each rival obtains its own HM when it earns the
  corresponding enabling badge and must teach the move to a compatible active
  or boxed Pokémon. Rival HMs and badges never read or change player flags.
- **Real HM route gates.** Rock Tunnel/Dark Cave require Flash; cut-obstructed
  Gyms and Ilex Forest require Cut; water routes and islands require Surf;
  boulder areas require Strength; and Johto's Whirl Islands/Tohjo Falls gates
  require Whirlpool/Waterfall where those moves exist in the loaded game.
- **Persistent HM use.** HM ownership and field-use counts survive saves, HM
  moves are protected from ordinary move replacement, and old saves learn all
  HMs justified by their existing private badges.

## What's new in 1.20.2

- **Trainer registration is idempotent.** Boot and `game.ready` can both see
  merged game data, but each rival trainer class is now registered only once.
  This fixes errors such as `trainers:register:larissa`.
- **No rival-triggered screen fades.** Visible rivals walk to a safe tile
  beside a door or map seam and then update only their own map state. They no
  longer step onto live warp/boundary cells capable of invoking the player's
  transition effect.

## What's new in 1.20.1

- **Bounded background simulation.** LOW updates one distant rival per world
  tick and runs optional rival social events only every fourth tick; BALANCED
  updates two and spaces social work across alternating ticks.
- **Map-pack resilience.** Invalid connections and warps are excluded from the
  route graph. Saves pointing to removed maps or destinations recover to a
  valid home without losing Pokémon, boxes, badges, money or goals.
- **Error history.** The diagnostic screen retains the eight latest guarded
  failures rather than replacing the useful error with the newest warning.

## What's new in 1.20.0

- **Performance profiles.** WALKING COST offers LOW, BALANCED and FULL modes.
  LOW substantially reduces autonomous path searches while companions continue
  to follow. The news ticker can also be disabled independently.
- **Automatic recovery.** Rivals detected in walls, on unattended doorway
  cells, or repeatedly unable to find a route are removed and materialised on
  a verified safe tile without losing their teams, goals or progress.
- **Manual recovery.** Every rival detail page includes MOVE TO SAFE TILE.
- **Readable errors.** Selecting LAST ERR opens the complete error in chunks,
  with an option to clear it after reporting or resolving the problem.

## What's new in 1.19.2

- **S.S. Anne map-script fix.** Direct rival talk is now registered only on
  the opening maps that require it. This prevents incompatible room modules
  such as `SS_Anne_B1F_Rooms` from reporting a map-script error.
- **Faster walking.** Static collision data is cached for the current map,
  autonomous movement is spread over fewer updates, and path-search budgets
  are capped more tightly. Live NPC and wall collision is still checked before
  every animated step.
- **One map-entry path.** Rival materialisation now uses the global
  `map.entered` handler only, avoiding duplicate spawning and map-load work.

## What's new in 1.19.1

- **Doorway yielding.** A companion automatically leaves the solid NPC layer
  when the player approaches a warp or map seam, so Poké Center doors and
  other one-tile entrances cannot be blocked. It reappears safely after the
  transition or after the player walks away.
- **Lower overworld cost.** Collision/path work now runs only when a rival is
  actually materialised, at a lower frequency, with one autonomous walker per
  pulse and a smaller companion search budget.
- **Doubles activation cost.** Absorbed trainer doubles default off when no
  companion is present. Accompaniment still enables eligible trainer 2v2 and
  wild doubles automatically; users can separately enable background doubles.

## What's new in 1.19.0

- **Accompany mode.** Select ACCOMPANY from any rival's detail page to make
  that rival stop its independent simulation, persist as your chosen companion,
  follow on collision-safe tiles, and transition between maps with you. Select
  STOP ACCOMPANYING to return it to autonomous goals.
- **Fully absorbed double battles 0.5.0.** The supplied double-battle runtime,
  targeting, turn order, switching, HUD, animation, spread-move, trainer-pair,
  wide-layout and supported 3D integration code is bundled directly into AI
  Rivals; a second mod installation is not required.
- **Rival battle partners.** A companion's first healthy Pokémon occupies the
  ally slot rather than borrowing a member of the player's party. Remaining HP,
  level and experience are returned to the rival after battle.
- **Companion-triggered doubles.** Wild battles become doubles while accompanied
  and eligible trainer parties use the integrated 2v2 system. With no companion,
  the absorbed engine retains its own configurable double-battle options.
- **Safe ownership boundaries.** External ally fainting never deletes a player
  party member, companion state is saved in the mod bucket, and selecting a
  companion never modifies player badges or story flags.

The absorbed double-battle documentation and original 0.5.0 changelog are in
`docs/double-battles-absorbed.md` and `docs/double-battles-changelog.md`.

## What's new in 1.18.4

- **Player-controlled interactions.** Each rival's detail page now exposes
  explicit HELP REQUEST and TRADE DUPLICATE actions. Nothing transfers merely
  because the player talked to or walked past a rival.
- **Real help transfers.** A rival short of balls or healing can request one
  item. Accepting debits the player's actual bag, credits the rival's saved bag,
  and creates a world-news headline without touching story flags.
- **Atomic Pokémon trades.** A rival may offer a duplicate boxed Pokémon for
  the player's last party member when at least two remain. The received
  Pokémon is constructed by the loaded game's own Pokémon module; unsupported
  engines abort before either collection changes.
- **Private route gates.** Gym interiors, Victory Road, Route 23 and Indigo Plateau
  are routed against each rival's badges. The gated BFS is per-rival and never
  reads or writes the player's story flags.

## What's new in 1.18.3

- **Fair title matches.** Losing an ordinary roadside battle can no longer
  dethrone the player. Only an explicitly announced challenge from a
  League-qualified rival transfers the title, and a vacant AI slot leaves the
  game's vanilla Champion in place.
- **Coverage-aware teams.** PC selection now values new attacking and defensive
  types as each team member is chosen instead of taking six independently
  ranked copies of the same role.
- **Smarter TMs.** Rivals reject unknown compatibility, buy only usable moves,
  favour meaningful new coverage per unit of money, retain a cash reserve, and
  teach the best eligible team or PC member.
- **Real savings.** Better balls are purchased before optional supplies, an
  emergency minimum of ordinary balls is maintained, and money is reserved
  toward the next premium tier.
- **Working Rare Candies.** Owned Rare Candies are consumed on
  the lowest-level active Pokémon without bypassing the next-Gym level ceiling.
- **Non-destructive save repair.** Level clamping for older saves preserves
  taught moves rather than rebuilding and erasing the moveset.

## What's new in 1.18.2

- **Honest League runs.** Rivals must defeat five actual Elite Four/Champion
  parties from the loaded game's trainer data. Missing or converted League
  data blocks the attempt instead of generating opponents or awarding a title.
- **Single Champion authority.** A successful run updates the manager's title
  holder and clears every stale rival Champion flag. A reigning player or AI
  Champion cannot be silently replaced by a background League simulation.
- **Persistent two-sided battle damage.** Rival duels and spontaneous
  skirmishes now carry remaining HP forward for both participants.
- **Trainer-instance persistence.** Each party variant has its own persistent
  identity, exhausted trainer pools stay exhausted, and map metadata is
  respected where the loaded game provides it.
- **Habitat-aware hunts and fair trades.** Hunters route to a real habitat and
  clear their goal on capture. Trades require both rivals to meet on the same
  map and randomly select among eligible pairs.
- **Queued persistent news.** Bursts of headlines wait their turn instead of
  overwriting one another, and the forty-story news history survives saves.

## What's new in 1.18.1

- **Visible simulation repaired.** Rivals keep training, catching and resolving
  Gym or rival battles while visible; only abstract off-screen map hops are
  suppressed while their on-screen walker is active.
- **Complete Poké Center visits.** Center arrival now runs healing, stored-team
  recovery, PC management, shopping, duplicate sales and TM application as one
  workflow instead of returning after the heal.
- **Move memory repaired.** Level-ups and evolutions add natural moves without
  erasing previously taught TM or manually selected moves.
- **Safer return journeys.** Synthetic reverse warps no longer copy coordinates
  from the opposite map, preventing invalid wall and scenery destinations.
- **NPC-aware path planning.** Static trainers, shopkeepers and other live NPCs
  are treated as blocked cells during route planning, so rivals walk around
  them instead of repeatedly trying the same occupied step.
- **Collection-safe duplicate sales.** Rivals sell only surplus boxed Pokémon
  and retain at least one specimen of every species they own.

## What's new in 1.18.0

- **Live news ticker.** New rival events flash across a non-blocking headline
  bar at the top of the overworld. Long headlines scroll and the bar fades
  away automatically; the existing forty-story NEWS screen remains available.
- **Authoritative solid terrain.** Spawn points and every animated step are
  checked against the live map's own bounds and walkability rules, making
  building walls, trees and other solid terrain impassable to rivals.
- **Occupied-cell safety.** Rivals also avoid the player, static NPCs, other
  rivals, warps and route seams when choosing somewhere to stand.
- **Embedded-rival recovery.** Old saves whose coordinates place a rival in
  solid terrain automatically despawn and rematerialize them on a proven safe
  interior cell. Scripted movement reads back the NPC's real final position,
  so a blocked step cannot corrupt its saved coordinates.

## What's new in 1.17.0

- **Real walking animation.** Visible rivals move through the engine's scripted
  NPC movement queue one collision-checked tile at a time, using their actual
  walker frames instead of remove-and-respawn position jumps.
- **No blocked exits.** Warps and connection seams are traversal-only cells.
  Rivals never materialize or idle on them and leave the active map immediately
  after their walking animation reaches the correct door or route boundary.
- **Purposeful travel.** Rivals retain a plain-language reason for every trip;
  the detail screen shows both `GOAL` and `GOING TO`.
- **Portable sprites.** AI rivals use animated walker records already supplied
  by the loaded game, avoiding the runtime sprite-registration failure seen on
  engines that reject image-backed custom walker records.

## What's new in 1.16.0

- **Persistent exploration.** Each rival now saves its own visited-map counts
  and per-map encounter/catch history alongside badges and defeated trainers.
- **Champion continuity fix.** A reigning AI Champion is selected for the next
  title defence instead of allowing the final battle to reroll another rival;
  the player's title and later dethroning by a rival are persisted too.
- **Move and item correctness.** TM compatibility accepts both registry shapes,
  empty move sets are updated correctly, premium-ball-only rivals can catch,
  PC captures enter the Pokédex, and a failed player gift cannot consume stock.

## What's new in 1.15.0

- **Pokédex goals.** Every species a rival holds counts toward its Pokédex;
  crossing 10 / 25 / 50 / 100 / 150 entries makes news. Rivals also pick a
  species to **hunt** from the loaded encounter tables and lean their catch
  attempts toward it.
- **Rivals trade with each other.** Two rivals holding duplicate PC Pokémon
  occasionally swap one each; the news reports who traded what.
- **Rematches.** A League-ready rival occasionally rematches a Gym Leader it
  has beaten, for money and exp, using the leader's real party.
- **Player interaction, kept fair.** A rival you beat may hand over a small
  item from its own bag as a consolation (a real grant into the player's
  bag). Rival trades, hunts and rematches are all visible in the news. As
  ever, nothing here touches the player's story flags.

## What's new in 1.14.1

- **The gauntlet lock is now enforced in code.** Until Oak's Lab is finished
  a rival fields exactly one Pokemon — its starter — and nothing else. A
  second Pokemon is refused even if every seeding, load and spawn path runs,
  which closes the bug where repeated empty-bucket re-seeds stacked a full
  party of starters in the lab. (1.14.0 shipped the feature but not the hard
  gate; the starter stacking is what could put six Charmanders on the player
  during a gauntlet fight.)

## What's new in 1.14.0

- **World news.** Everything the rivals do off-screen — catches, level-ups,
  evolutions, gym wins and losses, duels, trainer battles, League runs — is
  turned into a line of news ("Matt caught a Pikachu", "Larissa beat Misty").
  The freshest line rides the RIVALS menu and a full NEWS screen lists the
  last forty.
- **Move management.** Rivals learn moves (forgetting the weakest when a slot
  is full), buy TMs at marts, find them while training, and teach them to
  whichever of their Pokemon is TM-compatible.
- **Teams, chosen per gym.** Before a gym fight a rival pulls its best six
  from the active party and its PC boxes, ordered by level and type coverage
  against that leader — the right counter walks in, the rest stay boxed.
- **Ball tiers.** Rivals keep buying Poke Balls and, once their winnings are
  healthy, save up for Great and Ultra Balls; the strongest held ball is used
  on a catch and makes it more reliable.
- **Sell duplicates.** At a mart, duplicate species sitting in the PC are sold
  for pocket money instead of hoarded.
- **Repels only where wanted.** A Repel is burned only while travelling a
  route the rival does *not* train on; never on its own training ground.
- **Trainers stay beaten.** A trainer a rival has defeated stays defeated for
  that rival's simulation, and battles never draw a trainer far above the
  rival's current gym ceiling.
- **Champion continuity.** The current champion (a rival or Blue) defends the
  title and keeps improving between defences; a rival that beats the champion
  in a duel takes the title.

## What's new in 1.13.0

- **All unused intro appearances belong to the AI roster.** Character creation
  offers Red, Leaf, Crystal and Luigi for the player and Blue or Yellow for
  the story rival. The four looks left unused are assigned once each to Chris,
  Dyanari, Matt and Larissa. The assignment is deterministic across reloads,
  but changes correctly whenever a different player or story-rival appearance
  is chosen. (Leaf retains the legacy `green` save id for compatibility.)

## What's new in 1.12.0

- **Full rival bags and PC boxes.** Rivals buy Poké Balls, Potions, status
  cures, Repels and (when they can afford one) Rare Candies with battle
  winnings. They use supplies before battles and on routes, keep six active
  Pokémon at most, and send further catches to their own 30-slot PC boxes.
- **The Lab is the only party-size gate.** Each rival keeps its one starter
  until Oak's Lab gauntlet is finished; afterward every rival may build a
  six-Pokémon party regardless of its badges or personality.
- **Victory loot.** Defeating a rival awards its normal trainer money plus a
  random item actually held in that rival's bag, when the player's bag can
  accept it.
- **Variable League champion.** The Elite Four's final battle selects Blue,
  Chris, Matt, Dyanari or Larissa. AI champions use personality-specific
  title-fight dialogue and their persistent live party.

## What's new in 1.11.0

- **The rival economy.** Rivals start with the same ¥3000 pocket money the
  player does and earn more by winning battles — against each other and
  against the world's trainers. Money is spent on the one thing they buy:
  Poké Balls (¥200 each, the mart price), and every catch consumes one.
- **Rivals fight each other on purpose.** Besides the same-map skirmish, a
  rival can now pick the `RIVAL_DUEL` objective and travel across Kanto to
  another rival's map to fight it for money. The loser pays the winner;
  skirmishes and duels are zero-sum between rivals.
- **Rivals fight the world's trainers.** While training, a rival occasionally
  takes on a random ordinary trainer (gym leaders and the rivals' own classes
  are never the opponent) via the same `BattleSim` as gyms. Winning pays a
  level-scaled prize. The real trainer is untouched — the player still meets
  it in the world.
- **Balls are bought, never granted.** Leaving the lab no longer hands out a
  free ball stock; a rival tops up at the first mart / Poké Center it heals
  at, and only as far as its money and its personality's catch appetite allow.
- **Rival fights actually resolve.** The skirmish and League paths handed
  `BattleSim` a bare RNG table that crashed the damage roll; every RNG touch
  now degrades safely, so rival-vs-rival battles really happen.

## What's new in 1.10.0

- **Progression-aware party growth.** Rivals begin with one starter, can only add a second Pokémon before the first badge, then gain one additional party slot per badge until six. Personality targets can reduce that number but never bypass the badge ladder.
- **Catch level safety.** Newly caught Pokémon are capped at the rival's current next-Gym ceiling, so a high-level encounter table cannot create an illegal early-game team.
- **Old-save protection.** Every AI evaluation and simulation tick re-enforces the next-Gym level ceiling, correcting teams created by older releases without allowing them to remain over-levelled.
- **Gauntlet battle identity.** The active Gauntlet battle is now recorded by rival and sequence index, so stale or duplicate battle callbacks cannot advance the sequence twice or trigger another trainer's turn.

## What's new in 1.9.0

- **One starter each.** Every AI rival now has one deliberate starter and cannot accidentally receive an extra starter from the roster fallback chain.
- **Unused intro appearances.** The four AI rivals consume the four looks left unused after the player's and story rival's intro choices, one look per rival.
- **Player-paced progression.** Rivals may not progress more than one gym ahead of the player's badge count.
- **Gym level cap.** A rival's pre-gym ceiling is the next gym leader's highest level +2. Brock's Lv14 ace therefore means Lv16 maximum before the Brock fight.
- **Gauntlet one-shot resolution.** The Lab Gauntlet has durable completion state and protects each battle slot from being resolved twice when battle-end and blackout events overlap.

## What's new in 1.7.1

- **Oak's Lab gauntlet fix.** Rivals wait inside `OAKS_LAB` (lab interior), not
  outdoor `PALLET_TOWN`. Placement is relaxed on small maps so all four can
  stand in the 5×6 lab. On a new game they appear in the lab and battle you
  in turn after you get a starter.
- **Crystal / Luigi.** The intro offers CRYSTAL and LUIGI alongside RED and
  GREEN; their bundled appearances can also be claimed by AI rivals when left
  unused by the player.

## What's new in 1.7.0

- **Rival-vs-rival skirmishes.** When two or more rivals share a map and are
  free (IDLE / TRAINING / EXPLORING / …), there is a personality-gated chance
  they fight each other via the same deterministic `BattleSim` used for gyms.
  One skirmish per world tick maximum. Winner gains confidence + exp; loser
  takes chip damage and may immediately route to a Poké Center.
- **League aspiration.** Once a rival has every badge (`LEAGUE_READY`) it
  periodically attempts a simulated Elite Four + Champion sequence. Success
  sets a persistent `champion` flag (saved), raises confidence, awards a large
  exp burst, and unlocks champion dialogue. Still no invented story flags.
- **Richer dialogue.** New CHAMPION greeting bucket and more LEAGUE_READY
  flavour per personality.
- **Gen 2 hardening.** Placeholder party construction and live-party refresh
  for shadowed RIVAL1/RIVAL2 classes are more defensive against missing
  species in fixtures / total conversions.
- **Collector catch rate** slightly raised (0.30 → 0.32).

All of the original guarantees still hold: Poké Centers are used, gyms are
fought (and can be lost), training and progression use real data, and the
player always fights the rival's live party.

---

## Installation

Copy `ai_rivals/` into the engine's `mods/` directory:

```
mods/
  ai_rivals/
    manifest.json
    main.lua
    assets/  Choose Your Hero art (green/yellow walkers, portraits, fx)
    data/    rivals · personalities · gyms · dialogue
    src/     Rival · AI · Simulation · BattleSim · MapGraph
             Pathfinder · Sprites · ChooseYourHero · Dialogue · Version · Util
    tests/   ai_rivals_test.lua
```

Enable it from the in-game mod manager or the launcher's mod panel. It has no
hard dependencies and no optional ones — **Choose Your Hero is built in**, so
the intro already asks boy/girl, RED/GREEN and BLUE/YELLOW with no second mod.
To remove it, delete the folder — see **Isolation** below for what that leaves
behind (nothing that matters).

If you previously ran the standalone `choose_your_hero` mod alongside an older
AI Rivals, disable and delete it before enabling this package so the two do
not fight over the same intro steps.

**Optional, detected at runtime, never bundled** — see **Interop** below:
Girl-mode, Crystal, Playable Luigi, weather_fx, Kanto-Reforged, silph-scope.
Each is probed lazily and each can be absent without changing anything.

Run the tests from the engine root, with no ROM and no LÖVE:

```sh
lua5.1 mods/ai_rivals/tests/ai_rivals_test.lua
# 1499/1499 checks passed  (ai_rivals)
```

---

## 1.10.0 progression rules

- Each AI rival has exactly one intended starter.
- The four AI rivals consume the four unused character-creation appearances, one appearance per rival.
- Rivals may not advance more than one gym ahead of the player's badge count.
- A rival's absolute pre-gym level ceiling is the next gym leader's highest level plus 2. For Brock (Lv14), that means Lv16 maximum before the Brock fight.
- Party size is progression-aware: 2 slots before the first badge, then +1 slot per badge, capped at 6 and further limited by personality.
- Catches are capped at the same next-Gym ceiling.
- The Oak's Lab Gauntlet is a one-time sequence. Its completion flag is persisted separately, and battle resolution is idempotent so a combined `battle.ended` + blackout event cannot advance the sequence twice.

## Architecture

```
       core.update  (one hook, one accumulator)
             │
             ▼
       Simulation ──── tick every 1.5s, N rivals per tick
             │
      ┌──────┴──────┐
      ▼             ▼
     AI          Rival ─────── party · badges · state · RNG
      │             │
      │             ├── BattleSim   gym battles, off screen
      │             └── serialize   → mod.save
      ▼
   MapGraph ──── BFS across connections + warps
      │
      ▼
  Pathfinder ─── A*, only when the rival is on screen
```

Ten modules, each with one job. `main.lua` owns every engine seam and decides
nothing; the modules decide everything and touch no engine API.

### The module loader

The engine loads one chunk per mod, so `main.lua` brings a 20-line `require`
built on `mod:read`, which works identically from a folder install and a
packed `.modpkg` (`mod:read` handles both). Every module opens with
`local req, mod = ...`.

---

## Rival state

Twelve states, in `src/Rival.lua`:

```
IDLE · TRAVELLING · TRAINING · SEEKING_GYM · CHALLENGING_GYM
RETURNING_FROM_GYM · SEEKING_PLAYER · CHALLENGING_PLAYER
HEALING · EXPLORING · DEFEATED · LEAGUE_READY
```

The machine is deterministic. Every rival owns a 32-bit LCG seeded from a
constant in `data/rivals.lua` and saved with its state, so the same save
replays to the same world — `/rival_simulate` produces identical results twice
in a row, which is what makes the thing debuggable at all.

`AI.evaluate` runs the rival's personality priority list and picks an
objective; `AI.onArrive` decides what reaching the destination means. Splitting
those two is deliberate: arriving must not re-run the whole priority list, or a
rival oscillates on the doorstep.

Each evaluation reads badges, party levels, party health, location, the next
gym, the player's location and party, personality, previous encounters, and
whether the team is strong enough for the gym it is chasing.

### The level ceiling

A rival trains **towards the next gym's level plus a personality margin**, and
`Rival:gainExp` clamps at that ceiling. Without it a rival grinds to L100 with
one badge — the first thing a 6000-tick soak run showed. The ceiling rises with
each badge, so it delays growth rather than capping it.

The Speedrunner's margin is 0 (arrives underlevelled and sometimes loses); the
Strategist's is 7 (overprepares, rarely loses).

---

## Simulation

`Simulation:update` is called from the `core.update` hook. It accumulates `dt`
and runs a tick every **1.5 seconds** — never per frame. A full second of 60fps
frames does zero simulation work, which the test suite asserts directly.

Each tick advances **at most 2 rivals** (`budget`), round-robin from a cursor,
so cost is bounded by the budget and not by roster size. Adding a fifth rival
costs nothing per tick; it only means each rival is visited less often.

A tick does one of: burn a hop clock, move one map, resolve a training step,
attempt a gym, heal, or re-evaluate. **At most one gym battle is resolved per
tick** across the whole roster, so four rivals arriving at gyms together cannot
spike a frame.

A stall (an app suspend, a long load) drops its backlog rather than replaying
it — a 10-minute stall costs one tick, not four hundred.

### Detail by distance

| where the rival is | what it is |
| --- | --- |
| the player's map | a real NPC: sprite, collision, walk animation, talkable |
| anywhere else | a row in a table with a map id and a hop clock |

A rival off screen never runs grid movement, never pathfinds, and never draws.
This is the whole reason the mod is usable on a phone. Materialization happens
on `map.entered` and on the tick after a rival walks onto the player's map.

Placement picks a walkable cell 3–14 tiles from the player: near enough to
meet, far enough that it never reads as a teleport into your face.

---

## Pathfinding

Two layers, because they answer different questions.

**Strategic** (`src/MapGraph.lua`) — which map next? A BFS over a graph built
once from the merged `maps` table: `connections` are seams you walk across,
`warps` are doors. Both cost 1; making doors cheaper had rivals cutting through
buildings.

Two edges are added that the ROM data does not declare, and both were caught by
tests: a **reverse connection** when only one side declares the seam, and a
**reverse warp**, without which a rival routes into Pewter Gym and is stranded
there forever.

Routes are cached per `(from, to)` and dropped wholesale on invalidate.

**Local** (`src/Pathfinder.lua`) — which tile next? A binary-heap A* over the
walkability grid from `mod.world:mapOverview()`, run **only** for a rival the
player can see, and only when the destination changes, the map changes, the
path is invalidated, or the rival is stuck. Never per frame, never for an
off-screen rival.

---

## Gym progression

The badge ladder is the **engine's**, read from `constants.badges` — the same
table the player's trainer card reads. A mod that reorders the gyms reorders
the rivals' ladder too. `data/gyms.lua` adds only what the constant does not
carry: which map, which trainer class, which city, a level hint.

A rival routes to the **city**, then through the **door**, then fights.

`Simulation.attemptGym` is the only place a badge is ever awarded, it awards
exactly one, and only on a win:

```
route to city → route through door → CHALLENGING_GYM
                                          │
                        BattleSim.run(rival party, leader's real party)
                          │                              │
                        win                            lose
                          │                              │
                  award exactly 1 badge          no badge, damage carried
                  gym exp, confidence +          confidence −, cooldown
                          │                              │
                          ▼                              ▼
                  next badge on ladder            back to training
```

**Rivals lose.** Each failed attempt at a badge raises the confidence bar for
the next attempt by 12%. Without that, a rival with an optimistic estimate
re-attempted the same gym on the same reasoning forever — a soak run recorded
90 losses and 1 win before this was added; afterwards, 3 wins and 5 losses.

If the leader's party cannot be read, the attempt is **refused** rather than
rolled. A badge handed out because a table was missing is exactly the fake
progression this mod is not allowed to have.

Rival badges live in `rival.badges` and are never the player's inventory.

---

## Battles

**Against the player: the real engine, always.** Each rival registers its own
`trainers` record (`OPP_AIR_CHRIS`, …) whose party is a placeholder. The
`trainer.party` hook swaps in the rival's live party the instant the battle is
built. Everything downstream — stats, DVs, AI class, exp award, payout,
blackout-on-loss — is the vanilla trainer path, untouched. There is no second
battle engine.

If a rival has Charmeleon L28, Pidgeotto L25 and Kadabra L24, that is what you
fight, because that is what it has.

**Off screen: a deterministic estimator** (`src/BattleSim.lua`), used only for
gym attempts the player never sees. It reads species, level, types, moves, HP,
the loaded type chart (x10 multipliers, floored per row like Gen 1) and party
composition, and runs a turn loop until one side is out. It reproduces no
animation and no message — it produces a result, HP carried out, and a turn
count. Same seed, same battle.

---

## Rival Pokémon

Engine data structures throughout; no parallel Pokémon representation.

- **Exp** on the species' own growth curve, clamped at the ceiling
- **Moves** from the species' real learnset, newest four
- **Evolution** through the species' own evolution rows, level methods only —
  a rival that evolved a Pikachu with no Thunderstone would be inventing
  progress. Both the Gen 1 (`species`) and Gen 2 (`into`) record shapes read.
- **Catching** off the encounter table for the map it is standing on, so a
  Collector on Route 4 catches Route 4 Pokémon. No table, no catch.
- **Healing** at the nearest Poké Center by route

Parties grow. Every rival starts with **one** starter at level 5, exactly like
the player.

### Starters differ by version

`src/Version.lua` decides which set the roster hands out, by sniffing the
loaded dataset rather than reading a version string — a mod that allow-lists
`GameVersion.get() == "red"` excludes itself from Gold by construction, and
requiring the engine's own version module needs `engine_internals` and has no
Gen 2 facade.

| signal | reads as |
| --- | --- |
| `gen2Maps` / `gen2Trainers` present | Gold |
| `SPRITE_SURFING_PIKACHU` **and** a Pikachu | Yellow |
| anything else | Red, Blue, or a conversion on them |

Both Yellow signals are required together: a Pikachu on its own is not Yellow,
because Red and Blue have one too.

**Red and Blue** — every rival starts with one of the starting trio, matched to
its team plan. Four rivals into three starters means one repeat; that is the
trio, not an oversight.

| rival | plan | starter |
| --- | --- | --- |
| CHRIS | aggressive | CHARMANDER |
| DYANARI | efficient coverage | SQUIRTLE |
| MATT | varied | BULBASAUR |
| LARISSA | balanced defensive | BULBASAUR |

**Yellow** — Yellow gives the player Pikachu and the story rival an Eevee, so
an Eevee in someone else's hands is the version-correct thing for a rival to
carry. Three rivals get one. **LARISSA takes a CLEFAIRY instead**: Yellow is
the game where Clefairy is a real starter-shaped option, and a Normal-type
utility mon is what the Strategist's balanced plan actually wants.

| rival | Yellow starter |
| --- | --- |
| CHRIS | EEVEE |
| DYANARI | EEVEE |
| MATT | EEVEE |
| LARISSA | CLEFAIRY |

Moving the odd one out is a one-line change — swap which row in
`data/rivals.lua` carries `CLEFAIRY`.

Each entry is a **chain**, not a single id: the first species the loaded game
actually has wins, so a randomizer or a total conversion that removed the head
of the chain gets the next entry rather than a rival with an empty party. A
game with none of the chain yields nil, and the rival is skipped rather than
handed an invented species.

---

## Player encounters

A rival on your map may keep travelling, wander, train, or challenge you. It
never chases you across Kanto.

`AI.wantsToChallenge` gates on personality `challengeChance`, scaled by the
rival's confidence, then a roll — and refuses outright on cooldown, with an
empty party, or while healing or defeated. Measured over 200 samples in the
suite, the Challenger really does engage more than the Speedrunner.

After a battle, `battle.ended` records the result. A rival that beat you gains
confidence. A rival that lost goes and trains — it does not quietly get
stronger.

---

## Dialogue

Data, never a branch in the AI. `data/dialogue.lua` holds buckets keyed by
situation then personality with a `default` arm, so a new personality with no
lines still speaks. Tokens (`{NAME}`, `{BADGES}`, `{NEXT}`, `{CITY}`, `{LAST}`,
`{MON}`, `{N}`) expand in `src/Dialogue.lua`. `{PLAYER}` and `{RIVAL}` are left
for the engine's own substitution.

A bucket may also carry a `girl` arm, picked when Girl-mode is installed and
the Choose Your Hero answer says the player is a girl — this mod's own
feminine-voice lines, gated at pick time (see **Interop**). A bucket without
one falls back to its plain arms.

Lines are drawn from a stream seeded off the rival's state, not from the
rival's own RNG — talking to someone must not change what they decide to do
next, or the world would drift differently for a player who chats.

A badge is bragged about once, the first time you talk after it is won.

---

## Save format

Everything lives under this mod's namespaced bucket, which the engine routes
into `save.modData.ai_rivals`:

```lua
{ version = 2, tick = 4210,
  gauntlet = { active = true, index = 2, order = { "chris", "dyanari", "matt", "larissa" } },
  rivals = { chris = { state, map, x, y, destination, party, badges,
                       defeatedLeaders, gymAttempts, playerWins,
                       playerLosses, confidence, rngState, … } } }
```

`gauntlet` is present only while the intro gauntlet is active — which rival's
turn it is and in what order — and its absence means a normal playthrough.

Data only — no metatables, no functions, no engine references (asserted
recursively in the suite). Routes, paths and NPC handles are runtime and
rebuilt on load.

A party slot naming a species this boot does not have is **dropped** on
restore, so removing a Pokémon-adding mod between saves costs a slot rather
than crashing a battle. A missing or corrupt bucket re-seeds the roster.
`mod.migrations` carries the version forward.

---

## Isolation

The mod writes **no** vanilla save field — with one deliberate, documented
exception: during the intro gauntlet it heals the player's party between
battles (the engine's own `Pokemon.heal`, and only while the gauntlet is
active). See **The intro gauntlet** above. Everything else holds: the suite
enforces it textually, scanning every source file (comments stripped) for
assignments to `save.badges`, `save.party`, `save.inventory`, `save.flags[…]`,
`save.money` and `save.pokedex`. Reading the player's party to decide whether
to pick a fight is allowed; writing anything is not.

Remove the folder and the base game loads normally: the unknown `modData`
bucket is ignored, no vanilla Pokémon, item, badge or story flag was ever
touched, and the trainer classes were new ids (`OPP_AIR_*`) rather than
reshaped vanilla ones. Vanilla gym progression is untouched — the player's
badges and the rivals' are entirely separate stores.

---

## Choose Your Hero (built in)

Choose Your Hero (TranswarpTechnologies) asks three questions at character
creation — "Are you a boy or a girl?" (answered into the `gender` save key,
which drives the gendered dialogue and the player's name presets), "What do
you look like?" (RED, LEAF, CRYSTAL or LUIGI, answered into the `player` save
key; Leaf keeps the legacy value `green`), and BLUE or YELLOW for the story
rival. Character creation uses exactly two of these six looks, leaving four.
**Each remaining appearance is fully drawn, fully animated, and assigned to
one AI rival for the rest of the playthrough.** The mod ships the questions,
portraits, name presets, battle art and dialogue retargeting in
`src/ChooseYourHero.lua`, and the art lives in this mod's `assets/`.

CRYSTAL and LUIGI are bundled with this mod, so all four player appearances
are always available.

On a save made before the gender question existed, `gender` is inferred from
`player` (RED is a boy, GREEN is a girl).

| slot | art | free when |
| --- | --- | --- |
| all four AI slots | one of RED, LEAF, CRYSTAL, LUIGI, BLUE or YELLOW | it was not selected at character creation |

Exactly four looks are free every playthrough, so **every AI rival wears a
unique unused character-creation appearance**:

| rival | personality | slot | fallback |
| --- | --- | --- | --- |
| CHRIS | Challenger | `player_male` | `SPRITE_COOLTRAINER_M` |
| DYANARI | Speedrunner | `player_female` | `SPRITE_LASS` |
| MATT | Collector | `rival_male` | `SPRITE_SUPER_NERD` |
| LARISSA | Strategist | `rival_female` | `SPRITE_COOLTRAINER_F` |

Female slots go to female rivals and male slots to male rivals; the suite
asserts it.

**How the art is found.** The paths resolve straight through `mod.assets:path`
from this mod's own `assets/` directory — no other mod is consulted. The
answers come from the same `mod.save` bucket Choose Your Hero writes
(`"player"` / `"rival"`; older ai_rivals versions recorded them as
`"cyh_player"` / `"cyh_rival"`, which are still read as a legacy fallback).
`intro.oak_speech.answered` is the authoritative signal on a new game; on an
existing save the live swap Choose Your Hero performs on `SPRITE_RED.image` /
`SPRITE_BLUE.image` is compared against the GREEN/YELLOW paths — a direct read
of what was picked, which also works for a save made before this mod was
installed.

Ordering matters: the vanilla walkers are captured in the **entry chunk**,
because the swap happens at `game.ready`. Capturing later would borrow whatever
the player *did* pick rather than what they did not. And because every mod's
chunk has run by `game.ready`, a second capture (`Sprites:refreshVanilla`)
then re-reads the registry — which is how Crystal's or Playable Luigi's
patched RED walker becomes the AI-rival art when that mod installed it.

Before the intro answers exist (or with no assets API, in a headless test),
nothing is free and all four rivals use vanilla walkers; nothing degrades.

---

## The intro gauntlet (Oak's lab)

On a **new game** every rival starts inside Oak's lab and battles you **in
turn** — one rival per fight, in roster order — before anyone heads out into
Kanto. The world is paused while the gauntlet is active: no rival grinds,
catches, or leaves town until you have fought them all.

- **Starting up.** `save.created` starts the gauntlet and moves every rival to
  Oak's lab (the lab is a room inside `PALLET_TOWN` in Gen 1; a game whose
  graph does not have that map — Gen 2, for example — never starts one and
  plays exactly as before).
- **The fights.** The current rival forces a battle the moment you talk to it
  (a plot battle, so the RIVAL DUELS option is not consulted). A rival whose
  turn has not come just tells you who is next. If you have not received a
  starter yet, the current rival sends you back to Oak first.
- **The heal.** Your party is healed to full between gauntlet battles — the
  engine's own heal applied after each fight — so every duel is the fair
  starter-vs-starter showdown the moment is supposed to be. This is the mod's
  one deliberate write to the player's party, and it happens only while the
  gauntlet is active.
- **Heading out.** After the last rival, the gauntlet clears and everyone
  gets an objective again: the grinding, catching and badge-chasing start
  from where they are standing.
- **Removable and forgiving.** The gauntlet state lives in this mod's own save
  bucket and a save without one (an older save, or one made mid-playthrough)
  simply has no gauntlet. A rival whose starter species the loaded game does
  not have gets none rather than an invented Pokémon.

---

## Interop (optional mods, detected at runtime)

Six other mods are **support**, not dependencies: they are probed for, never
bundled, never forked, never relied on. Install none, some or all of them
alongside AI Rivals and the game is coherent either way. The one rule that
keeps it that way is in `src/Compat.lua`: **ask lazily, cache only a positive
answer, and treat every missing, broken or unknown case as "off".** Nothing
here reads another mod's internals or private files — every integration goes
through the API that mod publishes (`mod.find(...).exports`), or through its
public loader namespace via `require`, each inside a `pcall`.

### Girl-mode — dialogue

When Girl-mode is installed AND the Choose Your Hero answer says the player is
a girl, rivals say small feminine-voice versions of their own lines (a `girl`
arm per bucket in `data/dialogue.lua`). The gate is asked at the moment a line
is picked, so a save that answers the intro question later is heard next time,
not frozen at boot. Girl-mode's own text is that mod's business; this mod
never writes over it.

### Crystal / Playable Luigi — extra looks

When either mod is installed, the Choose Your Hero look question also offers
CRYSTAL or LUIGI (`value` `crystal` / `luigi`). Both mods express themselves as
patches on the RED walker, so "picking" one is really letting that walker stay
as that mod drew it; the un-picked one feeds the AI-rival art through a
post-load re-capture (`Sprites:refreshVanilla`) instead of the vanilla RED.
See **Choose Your Hero** above.

### weather_fx — the sky moves the world

The sky weather_fx paints over the player's map is real to a rival standing
on it, and nowhere else. Weather-fx 4.x gives every sky a **typed weather**
`chipType` — the Gen-1 type it favours and that is immune to its residual
chip — and the interop mirrors that catalogue rather than a hardcoded list:
a SMOG is POISON weather, a DRAGONSTORM is DRAGON, a PSYSTORM is PSYCHIC,
HAUNTED_MIST is GHOST, SWARM is BUG, VERDANT_RAIN is GRASS, and so on.

- **Confidence.** A team whose type matches the sky fights 10% bolder and
  trains harder; a team the sky fights plays 10% safer — either the classic
  weakened type (water under a sun, fire in a rain) or, for the typed
  weathers, any team that does not match the sky's type at all, because the
  residual chip is wearing it down.
- **Battles.** A gym or ghost fight that happens **under the player's sky**
  (the player is in the same gym, or the ghost is on the player's map) runs
  `BattleSim.run` with the battle weather: the classic move-power rows
  (SUNNY/RAINY/HEAVY_RAIN/HARSH_SUN) apply to both sides exactly like
  weather-fx, and a typed sky chips every non-matching battler for 1/16 of
  its own max HP per turn (`canFaint`, like weather-fx's default).

Off the player's map there is no sky to read, so fights and training are
weather-neutral. An unknown sky id is neutral. `weather_fx` absent is neutral.

### Rivals progress after scripted events

The intro gauntlet is the one scripted moment in the mod, and it hands the
world back as soon as the last battle ends: the gauntlet state clears, every
rival gets an objective, the world tick resumes, and they leave the lab to
train, catch and chase badges. The suite pins this — after the gauntlet
completes, the tick advances every rival and they physically leave the lab.

### Kanto-Reforged — the dex scope is respected

When Kanto-Reforged is installed with a dex scope, rivals only ever obtain
species that scope allows. The scope is asked live on every starter choice,
every catch, and every evolution target, and it can only **remove**: any probe
that errors, misses or is ambiguous allows. A hidden evolution target is
skipped rather than reached around; a catch pool is filtered before the draw.

### silph-scope — ghost hunts

When silph-scope is installed, a rival occasionally makes a detour to a
reachable ghost map (`SEEK_GHOST` objective, gated per personality by
`ghostChance`) and fights the ghost headlessly through `BattleSim.run`. The
result is **local**: a win is experience and a little confidence, a loss is
chip damage, and nothing is written into silph's storage — no ghost is moved,
fought twice, or resolved. A ghost with no resolvable party is refused, never
fabricated, exactly like a missing gym-leader party.

---

## Debugging

Developer mode only (`love . --developer` or `POKEPORT_DEV=1`); the console
that reaches these verbs does not exist in a normal build.

| verb | does |
| --- | --- |
| `rivals` | one line each: state, map, destination, badges, lead level, route length, sprite slots |
| `rival_list` | the same, column-aligned |
| `rival_tp <id> <map>` | move a rival |
| `rival_givebadge <id> <badge>` | grant a badge |
| `rival_setstate <id> <state>` | force a state |
| `rival_simulate [n]` | run n ticks immediately (default 50) |
| `rival_reset` | re-seed the roster |

There is also a **RIVALS** row in the START menu showing each rival's badges,
location, status and party — built from `mod.ui.ListMenu`, so it inherits the
engine's own list chrome and needs no engine change.

---

## Options

| row | values | effect |
| --- | --- | --- |
| RIVALS | OFF / TWO / ALL | roster size; OFF also hides the menu row |
| RIVAL DUELS | on / off | whether rivals may challenge you |
| WORLD PACE | SLOW / NORMAL / FAST | 3.0s / 1.5s / 0.6s per tick |
| LK DEBUG | on / off | debug counters |

---

## Cross-platform

Pure Lua 5.1. No shell commands, no native libraries, no OS APIs, no
executables, no Python, no Node, no networking, no HTTP, no threads, no
absolute or platform-shaped paths, no per-frame loops. File access goes through
`mod:read`, which works from a folder and from a packed archive. The mod
functions entirely offline and runs on Windows, Linux, macOS, Android, iOS and
anywhere else the engine runs.

The test suite runs headless under plain `lua5.1` with no ROM, no LÖVE and no
graphics context.

---

## Adding a rival

One entry in `data/rivals.lua`. No new file, no new branch:

```lua
{
  id = "sam",
  trainerClass = "OPP_AIR_SAM",          -- a NEW id, never a vanilla one
  name = "SAM",
  gender = "female",
  personality = "STRATEGIST",           -- a key in data/personalities.lua
  starters = {                          -- per version; first that exists wins
    default = { "EEVEE", "PIKACHU" },
    yellow  = { "EEVEE", "CLEFAIRY" },
  },
  spriteSlot = nil,                     -- the four slots are already claimed
  fallbackSprite = "SPRITE_LASS",
  basePic = "OPP_LASS",                 -- borrows a vanilla portrait
  aiClass = "OPP_LASS",                 -- borrows a vanilla battle AI
  baseMoney = 45,
  homeMaps = { "CELADON_CITY" },
  seed = 0x5341,
}
```

A new personality is one entry in `data/personalities.lua`
(`priorities`, `gymConfidence`, `levelMargin`, `challengeChance`, `trainRate`,
`wanderChance`, `catchChance`, `partyTarget`, `healAt`, `ghostChance`,
`rivalFightChance`, `duelChance`, `trainerBattleChance` — the last three drive
how often it skirmishes, travels to duel another rival, and takes on local
trainers for money). Dialogue falls back to the `default` arm until you write
lines for it.

Two rules the data enforces:

- `trainerClass` must be a **new** id. Registering over a vanilla class would
  reshape a trainer the game already ships.
- Everything a record points at is resolved against the loaded game. A species,
  portrait or AI class the boot does not have is omitted (the engine's default
  covers it) rather than failing the load — which is what lets one roster serve
  Red, Blue, Yellow, a randomizer and a total conversion.

---

## Multi-version support

**Red, Blue and Yellow** are fully supported, and Yellow is not merely
tolerated — it hands out its own starter set (above). Nothing is Red-only: the map
graph is built from whatever `maps` merged, the badge ladder from
`constants.badges`, the type chart from `type_chart`, learnsets and evolutions
from the species records. Yellow's renamed maps drop out of the healing and
training lists automatically because those lists are filtered against the graph
at build time.

**Gold (Gen 2)** — see below. The manifest declares `"games": ["gen1", "gen2"]`.

---

## Gold, and how the player duels work in-mod

Most of this mod already works on Gold: `trainer.party`, `world.trainer_engaged`,
`spawnNpc` / `removeNpc`, `screens`, `ui.start_menu.items`, `mod.save`,
`mod.commands`, `mod.options` and `core.update` all have Gen 2 call sites, and
`trainers`, `maps` and `sprites` all route to Gen 2 tables. The simulation,
the graph, the AI, the battle estimator and the save format are
generation-agnostic by construction.

Since 1.3.0 the one real gap — a mod cannot start a trainer battle on Gold —
is closed **entirely inside the mod**, with no engine patch:

1. **`map_scripts` has no Gen 2 home.** Gold reimplements map scripting without
   reading the registry, so the write is taken, dropped and reported. The talk
   script that fronts a rival conversation is therefore Gen 1 only, and
   `registerTalkScripts` returns immediately on Gen 2.

2. **Player duels ride the vanilla trainer battle.** A rival on Gold is spawned
   as a normal NPC carrying `trainer = { class = <numeric gen2 class
   constant>, member = 1 }` — the exact record the cart's own `trainerbattle`
   opcode builds. Facing that NPC runs Gold's own trainer battle, no mod arms
   involved. The mod guarantees the class it names exists:

   - `RIVAL1` / `RIVAL2` (the cart's story rivals, class ids `21` / `22` in
     stock Gold) are **shadowed**: every member's `party` row is overwritten
     with the live rival team, so every scripted encounter with that class
     fights the rival's actual party. CHRIS shadows `RIVAL1`, DYANARI shadows
     `RIVAL2`.
   - New classes (MATT, LARISSA, and any CYH spare) are registered fresh with
     `maxIndex + 1` sequential numeric ids.

   Live-party refresh happens through Gold's own hooks: `world.trainer_engaged`
   (fired when the cart engages a trainer by class constant) and the
   `trainer.party` wrap (fired when the battle builds the roster) both match
   the numeric class and copy the rival's live team into the class row, so the
   party you fight is the party the mod simulates. `load` and `save.created`
   re-sync the rows too. The gym ladder maps to Gold's real leaders
   (FALKNER, BUGSY, … CLAIR), and gym outcomes are estimated exactly as on
   Gen 1 — Gold's `startBattle` remains wild-only, and no mod invents a battle
   arm to bypass that.

3. **No engine patch is required or shipped.** `patches/0001-...` is retained
   for reference only; 1.3.0 never applies it, and the capability detection
   that looked for it is gone — the in-mod path is unconditional on Gen 2.

---

## Performance notes

Designed for a low-powered Android handheld.

- Tick-based, never per frame; a full second of frames does no work
- Bounded per-tick budget, independent of roster size
- At most one simulated gym battle per tick
- Routes cached per pair; A* only for on-screen rivals, only on invalidation
- No allocation on the `core.update` path when no tick is due
- Off-screen rivals have no grid position, no path and no NPC

`Util.guard` wraps every entry point. A raise costs that rival that tick and is
counted in `Util.errorCount`; it never reaches the player's error feed and
never takes down a frame.

---

## Known limitations

- **League runs are simulated, not story events.** A rival that becomes
  Champion does not displace the player’s Elite Four or rewrite any vanilla
  flag; the `champion` flag lives only in this mod’s save bucket and affects
  dialogue / confidence.
- **Catching needs an encounter table.** No table for a map, no catch — rather
  than inventing a species.
- **Stone and trade evolutions do not happen.** Level evolutions only; a rival
  has no bag and no trade partner.
- **Gym (and League / skirmish) battles the player never sees are estimated.**
  Player-facing battles always use the real engine.
- **Rival-vs-rival fights are off-screen only.** You will not see two AI
  rivals battle each other on the same map; the result (and the money that
  changes hands) is applied and they may then seek a Poké Center or continue.
- The suite is fixture-based, since the engine ships no ROM-derived
  `data/generated/`. It covers logic thoroughly and cannot cover real Kanto
  map geometry.

## 1.32.0 — Rival Memory

- Added compact persistent battle memory for each rival: player battle totals,
  outcomes, last location/result, observed leads, observed party species, and
  moves actually revealed during battle.
- Favourite lead, favourite Pokémon, and common move emerge from observation
  counts rather than hidden player data.
- Important history is capped at 40 events and observation maps retain only
  the 24 strongest entries, preventing unbounded save growth.
- Existing opponent snapshots and Center-based counter-team preparation remain
  the adaptive-rematch engine; memory extends that system rather than replacing it.
- Save schema 5 initializes missing memory safely while preserving old teams,
  PC boxes, badges, economy, Pokédex, ace, and League progress.
## 1.33.0 — Rival Relationships

One bounded, event-driven relationship model (`src/Relationships.lua`), reused
by dialogue, rival battles, cooperation, gifts, trades, and — when it arrives —
double battles. There is deliberately no second opinion table anywhere in the
mod: `Rival.bonds` is the only social store.

### States are derived, never assigned

A bond carries three axes plus the head-to-head record. The eight named states
(`FRIENDLY`, `NEUTRAL`, `COMPETITIVE`, `RIVALRY`, `RESPECT`, `HOSTILE`,
`MENTOR`, `ALLIED`) are the arithmetic consequence of those axes. Nothing in
the mod writes a state directly, and nothing rolls dice to pick one.

| Axis | Range | Meaning |
| --- | --- | --- |
| `regard` | −100…100 | warmth. Falls with defeat, rises with favours and with getting even. |
| `rivalry` | 0…100 | competitive heat. Only ever raised by contests. |
| `respect` | 0…100 | earned esteem. **Never decays** — this is what makes two rivals with identical records end up in different places. |

To move a bond you must name a cause from the closed set in `R.EFFECTS`
(`BATTLE_WIN`, `BATTLE_LOSS`, `HELPED`, `TRADED`, `COOPERATED`,
`REQUEST_DONE`, `TITLE_TAKEN`, `TITLE_LOST`, and so on). An unrecognised code
is refused and writes nothing, so a typo cannot silently move a relationship.
Three causes are *derived* inside the model rather than left to callers, so no
call site can forget them:

- `AVENGED` — winning while still behind head-to-head.
- `REPEAT_LOSS` — the third and later consecutive defeat.
- `WORTHY` — a long head-to-head that is still level.

The canonical arc from the roadmap falls out of the arithmetic: two defeats
reach `COMPETITIVE`, four reach `RIVALRY`, and winning back three times turns
it into `RESPECT`. `tests/relationships_test.lua` pins that sequence.

### Bounded and versioned

Twelve subjects per rival with deterministic least-recently-touched eviction,
six remembered causes per bond. Save schema is now **6**. A pre-1.33 save has
no `bonds` key at all, which yields an empty store reading `NEUTRAL` toward
everyone — the correct migration, because no history is invented for battles
that happened before the system existed. Every 1.32 field is untouched.

### Decay is lazy

A sweep over every bond every tick is exactly the continuous simulation the
performance budget forbids. Instead each bond stores the tick it was last
touched, and `regard`/`rivalry` drift toward rest at *read* time as a pure
function of elapsed ticks. Cost is zero when nobody is looking. Measured at
0.0041 ms/tick for four rivals.

### It changes behaviour, not just labels

- **Duel targeting** (`AI.Destination.RIVAL_DUEL`) weights candidates by fight
  bias, so a feud is two or three times likelier to be picked than an alliance.
- **Same-map skirmishes** gate on the same bias.
- **Player challenges** scale `challengeChance` by the rival's bias toward you.
- **Trading** prefers pairs that both `willCooperate`, without ever making a
  hostile trade impossible.
- **Dialogue** gains a state-keyed `D.relationship` bucket and a `{REL}` token.

Both the duel weighting and the skirmish gate were written specifically to
avoid disturbing the rival's own RNG stream — the weighted list consumes the
same single `rng:int` call, and the skirmish gate draws from a throwaway
stream. Older saves therefore continue to replay identically.

### Configuration and debugging

`RIVAL BONDS` (default on) is a single gate read into the world view once per
tick; turning it off silences recording, weighting and dialogue together.
`/rival_relationship [id]` prints the whole social graph with axes and the last
cause; `/rival_setbond <id> <subject> <cause>` applies one named cause. The
rival detail screen shows the bond toward the player and toward every other
rival.

### Two design bugs the soak caught

Worth recording, because both were invisible to static checks and to short runs:

1. Both battle outcomes originally pushed `regard` down, so **any** sufficiently
   long rivalry decayed into `HOSTILE` regardless of how it went. Fixed by the
   derived `WORTHY` cause.
2. Flat per-event deltas made each axis the lifetime *integral* of everything
   that ever happened, pinning every pair at a clamp after a few hundred
   contests — roadmap §39's homogenisation failure in a different guise. Fixed
   by making the axes **asymptotic**: a change away from rest is damped by the
   headroom remaining, while a change toward rest lands at full strength. An
   axis now approaches its bound without reaching it, and a rival that changes
   how it behaves can always move a relationship back.

`tests/relationship_soak_test.lua` now asserts the spread at both a
100-minute and an 8-hour horizon so neither can regress silently.

### Testing

A Lua interpreter was available for this release, so the relationship work is
covered by runnable suites rather than static contracts alone. All four run
standalone under `lua5.1` from `mods/ai_rivals`, with no engine, no LOVE, no
save and no ROM-derived data:

| Suite | Checks |
| --- | --- |
| `tests/relationships_test.lua` | 49 — the model: arc, bounds, corruption, decay, round trip, closed cause set |
| `tests/rival_relationships_test.lua` | 41 — four real `Rival` objects: directionality, privacy, save/load, pre-1.33 migration |
| `tests/relationship_dialogue_test.lua` | 79 — every state × every personality resolves a line with no unexpanded token |
| `tests/relationship_soak_test.lua` | 16 — cost, divergence and bounds at 4 000 and 20 000 ticks |

`tests/relationships_static.py` guards the structural contracts a static read
can prove: one model rather than several, no direct axis writes outside it, the
option gate reaching every subsystem, and every advertised state reachable from
the derivation.

The older static suites no longer pin a literal version string. A hard pin
breaks at every release and teaches whoever is releasing to edit tests until
they pass; each now asserts the floor at which its feature shipped
(`tests/_version.py`), so a suite fails when a feature regresses rather than
when the number moves.

## 1.34.0 — Team Building

Rivals now build **recognisable** teams. `src/TeamPlan.lua` holds the identity
model; as with relationships, there is one model and every consumer reads it.

### Seeded from data that was already there

`personality.teamPlan` has been declared in `data/personalities.lua` since the
personality system was written and was read by **nothing**. It is the seed
here, so the four shipped rivals start divergent without a new data file:

| Personality | `teamPlan` | Identity |
| --- | --- | --- |
| CHALLENGER | `aggressive` | Hyper Offensive |
| SPEEDRUNNER | `coverage` | Fast |
| COLLECTOR | `varied` | Evolution |
| STRATEGIST | `balanced` | Balanced |

Nine archetypes are available (`BALANCED`, `HYPER_OFFENSIVE`, `DEFENSIVE`,
`STATUS`, `MONO_TYPE`, `FAST`, `EVOLUTION`, `FAVOURITE`, `ANTI_PLAYER`), each a
weight set over traits read from the engine's own species table — offence,
bulk, speed, status inclination, evolution potential. A total conversion with
different stats therefore yields different identities, which is the point.

### The identity is subordinate to the matchup — deliberately

`Rival:teamFor` already picked the best six against a specific opponent by
level, coverage, resistance and move power. That function is *reactive* and it
is correct: a rival walking into Misty should bring what beats Misty. The
identity is an **addend inside that score**, weighted at `fit * 12` against a
level term of `lvl * 2` and coverage worth 14 per new type.

That ratio is the whole design and `tests/teamplan_static.py` pins it. Set the
identity weight high enough to dominate and rivals bring stylish teams to gyms
they then lose — §39 divergence becomes four rivals that are each individually
bad. Set it to zero and all four converge on the same optimum. `fit * 12` means
a rival brings what wins, and chooses between comparable options by what its
team is supposed to look like.

### Preference is earned, never assigned

- **Preferred type** accumulates from the types a rival actually fields, worth
  three on a win and one on turning up. A rival with no dominant type has no
  preference — none is invented for it. Capped at eight tracked types and 60
  credit each.
- **Identity drift** requires sustained evidence pointing one way
  (`DRIFT_LIMIT` = 40, from a closed set of named reasons: `BEATEN_BADLY`,
  `WON_QUICKLY`, `OUTSPED`, `TYPE_MASTERY`, `ACE_BOND`, `PLAYER_PROBLEM`,
  `EVOLVED`). Evidence pointing somewhere new *erodes* the existing case before
  building a new one, so a rival pulled three ways at once stays put. An
  unnamed reason is refused and accumulates nothing.

### The favourite now emerges from service (roadmap §7)

The ace was previously chosen purely by how remarkable a Pokémon is — rarity,
base stats, shininess. That makes the ace a fact about the **species**: two
Collectors who each catch a Lapras end up with the same ace, which is the
opposite of what §7 asks for.

Service record now counts alongside it: battles fought, victories, tenure on
the team, and whether it was the first Pokémon. Those are recorded on the slot
as it earns them, so the scoring stays a pure function of saved data. All four
factors use diminishing returns — without that, a Pokémon with two hundred
battles can never be displaced however long another serves, and the starter
becomes permanent.

A Pokémon with a real service record can become the ace without ever having
been "attached", which is how an ordinary starter grows into the ace it should
have been all along.

### Wired to decisions

- **What to catch** — encounter candidates are weighted by identity fit.
  Weighting only: every legal encounter stays reachable, so a Fire specialist
  standing in water still catches what is actually there.
- **What to field, keep and store** — the identity term inside `teamFor`.
- **What to evolve** — an evolution is evidence toward an evolution-focused
  identity, and unevolved species score higher for a rival building that way.
- **Battle style** — each identity maps to one of the §10 battle personalities
  (Aggressive / Tactical / Defensive / Ace Protector), surfaced on the detail
  screen and available to the battle layer.

Catch weighting consumes the **same single `rng:int` call** as before, with a
single-candidate short-circuit, so pre-1.34 saves replay identically — the same
discipline used for duel targeting in 1.33.

### Configuration and debugging

`/rival_team [id]` prints each rival's identity, where it is drifting and by
how much, its accumulated type credit, and the per-Pokémon service record
behind the favourite. `/rival_setstyle <id> <style>` forces an identity. The
detail screen gains TEAM STYLE, BATTLE STYLE, PREFERRED TYPE and FAVOURITE
rows; dialogue gains `{STYLE}` and `{ACE}` tokens.

### Save compatibility

Schema stays at **6** — the identity is additive and a pre-1.34 save simply has
no `teamPlan` key, so it re-seeds from the rival's personality exactly as a new
game would. No type history and no service record are invented for battles that
happened before the system existed; a rival played for hours simply starts
expressing the identity it always nominally had.

### Testing

| Suite | Checks |
| --- | --- |
| `tests/team_plan_test.lua` | 65 — traits, archetype disagreement, earned preference, drift, service, bounds, determinism |
| `tests/rival_team_test.lua` | 33 — real `Rival` objects: fielding, matchup dominance, emergent favourite, persistence, migration |
| `tests/team_divergence_test.lua` | 13 — roadmap §39, measured directly |
| `tests/teamplan_static.py` | structural contracts, including the identity-weight ratio |

`team_divergence_test.lua` is worth reading before changing any weight. It runs
two phases. The first gives all four rivals an **identical** pool and identical
battle traffic, isolating the identity as the only variable — and correctly
produces the same favourite for all four, because they all did the same things.
The second gives them the different histories their personalities actually
produce, and the teams, favourites and preferred types all come apart. Both
assertions matter: the first proves identity alone changes the team, the second
proves the system does not quietly homogenise once history is involved.

One honest limitation the first phase exposes: with an identical pool at
identical levels, the four rivals differ in team **ordering** but largely agree on
**membership**, because type coverage is worth more per slot than identity fit.
That is the intended trade — see the weight discussion above — and in play the
pools are never identical.

## 1.35.0 — Rival Story Arcs

`src/Story.lua` is deliberately the **thinnest** of the four models, because by
1.35 the mod already contains almost everything a story needs.

The canonical arc from roadmap §4 —

```
CONFIDENT → PLAYER DEFEAT → FRUSTRATED → TRAINING → TEAM CHANGE → REMATCH → RESPECT
```

— is **not** implemented here as a state machine. Every step of it is already a
real event in another system: the defeat is a 1.32 Memory event, the team
change is a 1.34 TeamPlan drift, the respect is a 1.33 Relationships state.
What was missing was a **narrator**: something that reads those systems and
says what shape the rival's journey is currently in.

So mood and chapter are **derived**, in the same discipline as the relationship
states and the team identity. Milestones are the only thing this file stores.

### It reads, it does not duplicate

`Rival:storyFacts` is the entire integration point, and `story_static.py`
asserts that nothing in it is a new counter:

| Fact | Owned by |
| --- | --- |
| recent form (`streak`) | 1.32 `Memory.events` |
| rival head-to-head | 1.33 `Rival.bonds` |
| team rebuilds | 1.34 `TeamPlan.changed` |
| badges, party, collection, dex | existing rival state |

A second copy of "how many battles has this rival won" is a second thing to get
out of step.

### Milestones (§21)

A **fixed, ordered, closed list** of 17. Because the list is fixed, `unlocked`
has a hard ceiling whatever happens in the world — there is no runtime bound to
enforce and none to get wrong. An id this build no longer defines is dropped on
load rather than carried.

Only flagged milestones are news. §31 says do not spam, and "MATT caught his
second Pokémon" is not news.

### Moods and chapters

Eight moods (`CONTENT`, `CONFIDENT`, `DETERMINED`, `FOCUSED`, `FRUSTRATED`,
`HUMBLED`, `TRIUMPHANT`, `RESTLESS`) and seven chapters (`ORIGIN`, `RISING`,
`SETBACK`, `REBUILDING`, `RESURGENT`, `CONTENDER`, `CHAMPION`). Chapters can
move **backwards** — a contender who is badly beaten is in `SETBACK` again —
which is what makes the §30 postgame arcs work without extra machinery.

### Migration is silent

A save played for twenty hours before this system existed has genuinely earned
eight badges. The correct response is to **record** them, not to announce eight
fresh achievements the moment the player loads. `Story.backfill` runs once on
first sight of an unseeded story; from then on the rival behaves normally and a
milestone earned *after* the upgrade is announced as usual. Schema stays at 6 —
the story is additive.

### Two bugs the soak caught

A narrator has two silent failure modes, and short tests catch neither: it can
**go flat** (every rival settles into one chapter forever) or **thrash** (mood
and chapter flip every few ticks, so a player who talks to a rival twice gets
whiplash). Nothing errors in either case.

The first version of the setback logic opened one on any loss and closed it on
any win. Over 24 000 ticks that turned the story into a strobe light: chapters
flipping every ~7 ticks and **6 785 news items**. Two rules fixed it, both
causal rather than damping:

- **Severity** — a defeat is a setback when the rival was riding high and got
  knocked down, or when it is part of a bad run. A defeat by the *player*
  always counts: it is rare, it is the one the player will remember, and it is
  the opening beat of §4's arc. (Using the confidence read alone would have
  made severity depend on whether the caller applied the confidence drop before
  or after reporting the loss — not something correctness should hinge on.)
- **Cooldown** — a rival that has just worked its way out of one setback does
  not fall into the next one the same afternoon.

That brought turns to a healthy ~118 per rival with a mean hold of ~203 ticks,
but news was *still* 461. The second fix separates **a chapter turning** from
**a chapter turn being news**: the majors always are, everything else must have
held the previous chapter long enough to have been a phase at all.

Final: **13 news items** over ten hours of play across four rivals, with the
chapter pacing untouched.

### Surfaces

`/rival_story [id]` prints the derived mood and chapter, the open setback, the
evidence behind them, and the milestone list. The detail screen gains MOOD,
CHAPTER and a MILESTONES row that opens a per-rival achievement screen.
Dialogue gains a `{MOOD}` token and a mood-keyed bucket — offered as a prefix
ahead of the relationship line, with the 1.32 selection underneath untouched.

`Rival:rememberEvent` had existed unused since 1.32; milestones now flow
through it, which is what gives roadmap §32's persistent event history real
content.

### Testing

| Suite | Checks |
| --- | --- |
| `tests/story_test.lua` | 69 — milestones, setbacks, the canonical arc, backwards chapters, corruption, determinism |
| `tests/rival_story_test.lua` | 34 — real `Rival` objects: cross-system reads, the arc end to end, silent migration |
| `tests/mood_dialogue_test.lua` | 104 — every mood × every personality, no unexpanded tokens |
| `tests/story_soak_test.lua` | 22 — flatness and thrashing over 24 000 ticks, plus the news budget |
| `tests/story_static.py` | structural contracts, including "no duplicate counters" |

`story_soak_test.lua` is the one to run before changing any story constant. It
asserts pacing directly: at least three chapters visited, at least two turns,
and a mean hold long enough to be noticed rather than whiplash.

## 1.36.0 — Living Kanto

Every release from 1.32 to 1.35 added **interior** state: memory, relationships,
team identity, story. All of it is real and all of it is invisible unless the
player opens a menu. This is the release that turns the simulation outward, and
its questions are all one question:

> What could the player plausibly have **noticed** about this rival?

`src/Presence.lua` is therefore not another simulation. It is an **observer**:
it reads state the other systems already maintain and decides what, if
anything, the player gets to see. `presence_static.py` enforces that it never
writes through `rival.*`, `self.*` or `view.*` — a sighting cannot change the
world it is reporting on.

### The rate limit is the feature

A sighting system with no budget is a spam system. "You spotted Chris" every
forty seconds stops being atmosphere within ten minutes and becomes noise the
player learns to ignore — which is **worse than having no sightings at all**,
because it takes the relationship, team and story reporting from 1.33–1.35 down
with it. They all share that channel.

So the budget lives inside `Presence.observe`, not at the call sites: a
per-rival cooldown, a world-wide cooldown, a visibility rule (same map or next
door, and never someone you are already engaged with), and a 12-entry log.
Measured worst case — all four rivals parked on the player's map for ten hours,
the observer asked every tick — is **26.6 sightings per hour**. Realistic
wandering gives **6.4**.

### Sightings tell the truth

`Presence.classify` reads the rival's actual objective and map, so a sighting
can never contradict what it is doing: a player who follows up finds exactly
that. The sentences are deliberately **observational** — what a passer-by would
notice. "You spotted Chris heading north" is fair; "Chris is frustrated" is not
something you learn by watching someone cross a bridge, and 1.35 already has a
place to say it (talking to them).

From an adjacent map only transit is visible. You do not see someone shopping
from the next route over.

### Location purpose (§12)

`Presence.PLACES` matches map IDs by **substring**, not exact equality, because
this mod runs on Red/Blue/Yellow, on Gold, on randomizers and on total
conversions — a hardcoded `MT_MOON` table is wrong on three of those. A map
matching nothing simply has no special purpose, which is the correct answer for
Route 3.

### Camps (§14)

A camp is not a new activity — rivals already train. It is a rival choosing to
**stay** somewhere long enough that the player can find it in the same place
twice, which is what makes a world feel inhabited rather than a set of drifting
dots. Camps are only made where training is legal (the same wild-encounter rule
the training branch enforces) and never inside a Center, Mart or Gym.

### Navigation memory (§15)

`visitedMaps` has counted arrivals since 1.14 and been read by nobody. It is
exactly the navigation memory §15 asks for, so this extends it rather than
adding a parallel structure.

**The hard rule, from §15 and §38:** familiarity may only change how *fast* a
rival crosses ground it is already allowed to cross. It must never open a
route. Every gate lives in `Rival:canEnterMap` and `Rival:routeTo`, and
`presence_static.py` asserts that neither function so much as mentions
familiarity — a rival that has crossed Cerulean a hundred times still cannot
pass the Snorlax without the Flute. The saving is capped at 25% and floored at
two ticks per hop.

### Shop visits (§17) — already done, deliberately not rebuilt

Rivals have visibly restocked Poké Balls and bought TMs since 1.14; those
purchases log as `bought_balls` / `tm_bought` and already render. A second
"errand" channel would be duplicate infrastructure reporting the same purchases
twice. I started one and removed it. What 1.36 adds is the other half:
`Presence.place()` classifies a Mart, Center, Gym and Dept. Store, so a rival
standing in one is *sighted doing that* rather than sighted generically.

### Two bugs the soak caught

Both were invisible to short tests and to static checks:

1. **A full atlas could never learn anywhere new.** A first visit scores 1,
   which is always the least familiar entry, so once `visitedMaps` filled, the
   rival evicted the ground it was standing on every single time and
   familiarity froze permanently at whatever it knew when the table filled. The
   map just arrived at is now protected from eviction.
2. **The last rival in roster order was never noticed.** At most one rival is
   sighted per tick, so fixed iteration handed every sighting to whoever came
   first: with four rivals parked on the player's map, the fourth never
   appeared at all. Sightings are now offered in **least-recently-seen** order —
   fair, still deterministic (ties break on the id), and it reads correctly too:
   you notice the one you have not seen in a while.

### Surfaces

`RIVAL SIGHTINGS` (default on) is a single gate. `/rival_where [id]` prints
where every rival is, what it is doing there and why, how much of Kanto it has
learned, whether it is camped, and the recent sighting log — the one verb to
reach for when the world feels empty, because it says whether nothing is
happening or whether things are happening and the player is simply not being
told.

Save schema stays at **6**. The sighting log is world state (it is what the
*player* noticed, not any one rival's data) and a pre-1.36 save gets an empty
one rather than being told about sightings that happened before the system
existed.

### Testing

| Suite | Checks |
| --- | --- |
| `tests/presence_test.lua` | 69 — location purpose, classification honesty, the budget, visibility rules, bounds, corruption |
| `tests/presence_soak_test.lua` | 17 — worst-case and realistic sighting rates over 24 000 ticks, fairness, navigation bounds |
| `tests/presence_static.py` | read-only observer, familiarity-affects-speed-not-access, §17 not duplicated |

## 1.37.0 — Weather Intelligence

Audited against **Weather FX 4.18.6**. The interop surface AI Rivals depends on
is unchanged — `exports.weather()` and `exports.battleWeather()` are both still
there and still shaped the same — but the audit found that our *copies* of
Weather FX's tables had drifted, with a real consequence in battle.

### The bug this release fixes

`exports.battleWeather()` **collapses several overworld weathers into one
battle-field string**, and the chip type is not recoverable from it:

| overworld id | chips | `battleWeather()` |
| --- | --- | --- |
| `RAIN_LIGHT` | WATER | `RAINY` |
| `STORM` | **ELECTRIC** | `RAINY` |
| `GALE` | **FLYING** | `RAINY` |
| `THUNDERSNOW` | **ELECTRIC** | `SNOWY` |
| `ASHFALL` | **FIRE** | `SANDSTORM` |

`BattleSim`'s `CHIP` table was keyed on the battle string, so every `RAINY`
fight resolved to WATER. In a thunderstorm the simulation **chipped an Electric
team that Weather FX would have spared, and spared a Water team it would have
chipped** — quietly wrong results in every off-screen battle fought under a
storm, a gale, thundersnow or ashfall.

Callers now pass `opts.weatherId` and a `chipType` resolved from the
**overworld id**, which is unambiguous. The old table survives only as a last
resort for callers that predate 1.37.

### Stop mirroring, start reading

`src/Weather.lua` reads Weather FX's live catalogue through `exports.types()`
rather than carrying a hand-written copy. Weather FX documents `weather`,
`channel`, `battleWeather` and `timeOfDay` as its stable surface and promises
nothing else, so every row is validated field by field before anything is
trusted, and a host that returns a table with fewer than four usable rows is
treated as **absent** rather than believed — silently accepting an empty
catalogue would disable every weather decision in the mod while reporting
success.

The cache lives on the compat handle, keyed on the host's reported version:
Weather FX can load *after* this mod, and a module-level cache would freeze the
fallback in place for the whole session.

A rival with no Weather FX behaves exactly as it did before weather existed —
every read returns nil or 0.

### The test that would have caught it

`tests/weather_interop_test.lua` compares our fallback catalogue against a real
Weather FX tree, entry by entry:

```
lua5.1 tests/weather_interop_test.lua /path/to/mods/weather_fx
```

Against 4.18.6 it reports **zero drift**. With no path it checks the invariants
instead — including, structurally, that no ambiguous battle string is ever used
to infer a chip — so it is safe in CI where Weather FX is not installed. A
weather Weather FX adds later is a *note*, not a failure: the model reads it
live from the host, and only the offline fallback is behind.

### Behaviour

- **`WEATHER` team archetype** — roadmap §6 listed it and 1.34 omitted it. A
  weather rival focuses on whatever type the sky currently favours, where every
  other focused archetype follows its own accumulated record.
- **Hunting (§19)** — the sky biases what a rival goes looking for, mirroring
  Weather FX's own encounter rule. **Weighting only**: a banned species stays in
  the pool, because the sky can change at any moment and a rival that refused to
  look for Growlithe while it rained would simply stop hunting.
- **Travel (§18)** — a rival the sky is wearing down heads indoors more often;
  one enjoying it lingers outside. Weather FX has no per-map forecast, so this
  deliberately does not pretend to know where the rain is.

Both weightings consume the **same single `rng:int` call** as before, so
pre-1.37 saves replay identically.

### One judgement call worth recording

A mono-Electric team winning in a thunderstorm is evidence for a type
specialist **and** for a weather specialist. Firing both made them cancel under
1.34's contradictory-evidence rule, so the rival that most obviously deserved
the WEATHER identity could never reach it. The two readings are now exclusive:
when the dominant type is exactly what the sky favours, the **sky** is the
better explanation for the wins; when they differ, the record stands on its own.

### Testing

| Suite | Checks |
| --- | --- |
| `tests/weather_test.lua` | 136 — chip resolution, host reading, broken hosts, favoured/banned types, affinity |
| `tests/weather_interop_test.lua` | 12 (18 against a real tree) — drift against installed Weather FX |
| `tests/rival_weather_test.lua` | 27 — no-host inertness, hunting and travel bias, the WEATHER identity |
| `tests/weather_static.py` | structural contracts, including "every battle site resolves the chip from the id" |

## 1.38.0 — Rival Economy

Money, a real 13-item bag and a working mart have existed since 1.14. What had
**never** existed was a reason for two rivals to spend differently.

Before this release every rival walked the same `Rival.SHOP_ORDER` and topped
every item up to the same target. The only divergence in the whole economy was
that a catch-oriented personality carried a few more Poké Balls. Four rivals
with the same money ended a session holding the same bag — roadmap §39's
homogenisation wearing an apron — and it made §16's *"rivals should sometimes
need to make resource decisions"* false, because walking a fixed list in a
fixed order is not a decision.

### One money door

Eight separate sites did `rival.money = rival.money + x` by hand. All money now
moves through three functions:

| | |
| --- | --- |
| `Rival:earn(amount)` | income; records to the ledger |
| `Rival:spend(amount, category)` | **returns 0 and changes nothing if the rival cannot afford it** |
| `Rival:forfeit(amount)` | money taken by a winner; capped at what is actually held, so a loss can never leave a debt |

A caller may not assume a spend succeeded — that is the whole point.
`economy_static.py` asserts that no site outside those three bodies assigns a
purse from an arithmetic expression.

### Budgets, not a shopping list

The purse (after a reserve) is divided between six categories — `BALLS`,
`HEALING`, `STATUS`, `FIELD`, `TRAINING`, `EVOLUTION` — by the rival's spending
profile, and **each category may only spend its own share**. Money spent on
balls is money not available for potions. That is the trade-off §16 asks for.

Shares are floored, so the sum is always ≤ the purse: a rounding error that
handed out more money than the rival had would be an invented resource, which
§38 forbids outright. A malformed profile whose shares exceed one is caught and
zeroed rather than allowed to mint.

Two purchases sit **outside** the budget, deliberately:

- **An emergency pair of Poké Balls** when the bag is empty. A rival with no way
  to catch anything is broken rather than thrifty, so a Speedrunner that has
  decided balls are low priority still ends up owning one.
- **Premium balls**, which cost more than a single category share and so are
  saved for rather than budgeted for.

### The profile is derived, not a new data file

`Economy.profile` reads `catchChance`, `trainRate`, `challengeChance`,
`rivalFightChance` and `wanderChance` — fields `data/personalities.lua` has
carried since the personality system was written. This is the same move 1.34
made with `teamPlan`: the divergence was already described in the data, nothing
was reading it. `economy_static.py` fails if a `data/economy.lua` is ever added.

Because the same number drives both the behaviour and the wallet, a rival's
spending and its conduct cannot disagree — a Collector that catches constantly
cannot be quietly under-funding balls. The 1.34 team identity gets a say too:
an `EVOLUTION` rival funds stones, a `DEFENSIVE` one funds healing.

Measured result, four rivals given an identical ₽12,000:

```
chris    spent 6950   POKE_BALL=5  POTION=4  SUPER_POTION=3  REPEL=1
dyanari  spent 7500   POKE_BALL=4  POTION=5  SUPER_POTION=3  REPEL=2
matt     spent 5750   POKE_BALL=9  POTION=2  SUPER_POTION=1  REPEL=2
larissa  spent 6700   POKE_BALL=7  POTION=3  SUPER_POTION=2  REPEL=2
```

Matt the Collector leaves with nine balls and two potions; Dyanari leaves with
four balls and five potions.

### A bounded ledger

One running total per category plus two scalars (`earned`, `lost`). There is
**no transaction list** — a transaction log over a long game is exactly the
unbounded save table the brief forbids, and `economy_static.py` fails if one
appears. Totals are capped; the row set is rebuilt from the fixed category list
on load, so a corrupt save cannot add rows.

A pre-1.38 save starts with an **empty** ledger rather than one back-filled from
current holdings. The money it spent before this system existed was spent, and
inventing a history for it would be a lie the debug overlay then repeats.

### Testing

| Suite | Checks |
| --- | --- |
| `tests/economy_test.lua` | 250 — categories, profile normalisation, divergence, budgets that cannot mint, ledger bounds and corruption |
| `tests/rival_economy_test.lua` | 438 — the money door, 200 shopping trips, four distinct bags from identical money, a 20 000-tick career |
| `tests/economy_static.py` | one door, no unbounded ledger, no new data file, floored budgets |

`rival_economy_test.lua` checks the purse after **every** transaction across a
long career rather than only at the end, and closes with a books-balance
assertion: everything recorded as spent or lost must equal what actually left
the purse.

## 1.39.0 — Rival League

Simulated League runs have existed since 1.7 and they were honest: the same
`BattleSim`, the game's own Elite Four parties, no scaled substitute, and a
refusal to award the title at all if a conversion has no recognisable League.
What was missing is everything that happens *around* a run.

### The bug this release fixes

The retry gate was a flat 16-tick cooldown and nothing else. A rival that
reached eight badges with a team the Elite Four could beat attempted the League
**1,500 times over ten hours of play**, lost all 1,500, and logged a news item
every time.

This is precisely the bug the Gym path had in the original build — *"a static
gym-confidence gate made a rival attempt Brock 90 times and lose 90 times"* —
and the fix there was that each failed attempt must raise the bar. The Gym path
was fixed. The League path was written from the same template three releases
earlier and never was.

Measured after the fix, over the same 24,000 ticks:

| | attempts |
| --- | --- |
| old flat gate | **1,500** |
| rival that never improves | **19** |
| rival that trains between runs | **80** |

### Getting the escalation right took three attempts

Worth recording, because each intermediate version looked reasonable and the
soak refuted it:

1. **Escalate on every failure, multiplicative strength bar.** Over-corrected to
   *one* attempt in ten hours — "back off and train" became "give up forever".
2. **Add patience** (waiting counts toward the bar). Now the stuck rival got
   *more* attempts than the training one. A multiplicative bar inverts the
   intent: "+12% over what you last failed with" asks a diligent rival at 900
   total levels to find another 540, while a stuck rival at 200 must find 120.
3. **Additive bar** — same real improvement asked of everybody. Both got 27:
   the escalating cooldown had become the only thing that mattered.

The version that works escalates on **unproductive** failures only. A rival that
came back meaningfully stronger and still lost is making progress and its wait
resets to the floor; one getting nowhere is backed off further each time. That
is §28's loop — fail, train, return — as a mechanism rather than a description.

### §30: a title shot is earned, not owed

The title-challenge path fired on eight badges alone, so a rival could challenge
the player for the Championship **without ever having beaten the Elite Four** —
an entitlement the player does not have, and §38 requires the AI to play by the
same rules. It now additionally requires a qualifying run.

Taking the title **spends** that qualification: a deposed champion must clear
the Elite Four again to earn a fresh shot, rather than holding a free rematch
forever.

### Also

- **`bestStage`, `walls`, `clears`, `reigns`, `longestReign`** — §28's league
  statistics, bounded to `MAX_STAGE` rows with corrupt keys dropped on load.
- **§27 standings screen**, reachable from the rivals menu, sorted
  deterministically with a final tie-break on id so it reads the same every time.
- **League news says where a rival fell**, which turns a repeated failure into a
  story rather than a repeated line — affordable now that the gate has cut the
  volume.
- A pre-1.39 save carries its real `leagueAttempts` across but is given **no**
  invented wall history and **no** qualification.

One fallback deliberately removed: the "rival object with no record" branch
originally kept `leagueCooldown = 16`. A fallback that silently restores the
1,500-attempt behaviour is worse than no fallback, because it looks like
defensive coding. It uses the model's floor.

### Testing

| Suite | Checks |
| --- | --- |
| `tests/league_test.lua` | 80 — escalation, the progress case, qualification spend, reigns, bounds, deterministic standings |
| `tests/league_soak_test.lua` | 23 — the regression guard: attempt counts for a stuck, a training and an eventually-winning rival over 24,000 ticks |
| `tests/league_static.py` | the flat 16-tick retry is gone, escalation is driven by unproductive failures, title shots require qualification |

## 2.0.0 — Integration and Acceptance

Eight subsystems were built between 1.32 and 1.39 — memory, relationships, team
identity, story, presence, weather, economy, League — and every one was tested
**alone**. `tests/integration_test.lua` is the first suite that runs all eight
on the same four rivals over a 24 000-tick career, and asks the questions that
only exist at the seams.

It found a real bug in its first run.

### Hostility needs a grievance, not a scoreboard

All four rivals ended `HOSTILE` toward the player **while winning two battles
in three**. Isolated, a rival winning 200 of 300 contests pinned regard at −100.

Every battle result nudges regard down a little, so over hundreds of contests
any long relationship slides to the floor regardless of who is actually
winning. 1.33's `WORTHY` cause counteracts that for a *level* record; a lopsided
one had nothing. No single-system test could see it, because none of them
fights three hundred battles.

Two counterweights were tried and both were worse than the disease:

- A "you do not resent someone you keep beating" bonus **small** enough to
  preserve texture did not reverse the drift.
- **Large** enough to reverse it, the whole social graph went uniformly warm and
  collapsed from four states to two.

The rule that works is a statement about what hostility *means*: **you do not
come to hate someone you comfortably beat.** Battle results alone can no longer
produce `HOSTILE` for a rival that is clearly ahead. That needs real grievance —
a snub, an ignored request, a stolen title — which the existing causes supply
and which erodes regard on its own terms. A dominant rival with low regard reads
as a `RIVALRY`, which is what it is.

`relationships_test.lua` now pins this permanently, including the converse: that
sustained grievance still reaches the floor.

### Save size, measured end to end for the first time

"No unbounded save tables" has been a per-system rule since 1.32. This is the
first measurement of a rival carrying **all eight records at once** across a
long career:

```
serialized scalar count at 4000-tick intervals:
800  804  810  812  820  820
```

Flat. Eight subsystems, ten hours of play, 2.5% growth — and every one of them
has a cap that the suite re-asserts at the end.

### The collective news budget

Each system's news volume was measured on its own channel; they share one
ticker. Together, over ten hours across four rivals:

```
badge=31  chapter=11  league=11  milestone=6  relationship=24  sighting=64
total 147  (~14.7 per hour)
```

An earlier fixture parked all four rivals on the player's tile permanently — the
worst case `presence_soak_test` already measures in isolation — and sightings
were 76% of the ticker. That is worth knowing as a ceiling, but it is not a
world to design the ticker around, so the integration fixture uses realistic
proximity.

### Divergence with everything pulling at once

Four rivals with different starting hands and different luck diverged on **team
identity, favourite Pokémon and wealth** (₽71,600 to ₽259,700 from the same
battles, because four spending profiles draw on the purse differently).

They converged on mood and chapter — all `Confident`, all `Back in it`. That is
correct rather than a defect: mood is a function of recent form, and four rivals
all doing well are all confident. The axes that make them *recognisably
different characters* held.

### The migration nobody had tested

A bare pre-1.32 rival record — no memory, bonds, teamPlan, story, ledger or
League key — now passes through **eight migrations at once**. It keeps every
fact it really had (money, badges, battle record, League attempts) and none of
the eight invents anything: no relationship history, no type credit, no spending
history, no League failures, no memory, and a story that stays silent on its
first tick while recording what was genuinely earned.

### Testing

| Suite | Checks |
| --- | --- |
| `tests/integration_test.lua` | 148 — all eight subsystems together: presence, career soak, collective news budget, save-size growth, joint round trip, eight-way migration, divergence, legality invariants |

Totals across the suite: **1,732 Lua assertions in 21 files, 11 Python static
contracts.**

## 2.1.0 — Rival Life Paths: Foundation

One or occasionally two rivals may permanently abandon the Gym Challenge. This
release is the part that decides **whether** and **which**; the careers
themselves follow in 2.2–2.4.

### The shape the brief asks for

> SAVE SEED → what is *possible*. EXPERIENCE → what actually *happens*. (§2)

That is the same discipline every system since 1.33 has used, so it is built
the same way:

- **Eligibility** is a pure function of `(world seed, rival id)`. Never stored
  as a decision, never rerolled — reloading gives an identical answer because
  it is the same arithmetic on the same seed (§32).
- **Pressure** is *derived* from the rival's own history — League failures, gym
  attempts, badge drought, player defeats, collection size, ghost affinity,
  confidence — exactly as 1.35's mood is. There is no accumulating pressure
  scalar, so there is nothing to drift, nothing to balance and nothing extra to
  save.
- Only the **commitment** is stored, and once stored it is locked (§33).

That division is what makes the outcome feel earned rather than rolled: the
seed says a rival *could* become a breeder; three hundred captures and a string
of gym failures are what make it one.

### The distribution, measured

Over 20,000 seeds:

```
none 85.2%    one 11.8%    two 3.0%
```

Against §3's suggested 85/12/3. **Never all four** is enforced structurally —
the count is capped at `roster - 1` regardless of what the configuration says,
so even a `two = 1.0` configuration cannot empty the Gym Challenge. Eligibility
is also independent of roster order, and no rival is disproportionately singled
out across saves.

### Save-scumming is impossible by construction, not by concealment

Three separate properties, each pinned by test:

1. Eligibility is derived, so reloading cannot change it.
2. *Which* path a diverging rival takes is drawn from the **seed**, not a live
   roll — the candidate list comes from the rival's history, so the seed only
   breaks the tie between lives it has actually earned.
3. A committed record refuses a second commitment. A stored path other than
   `GYM_CHALLENGE` loads **locked whatever the flag said**, so a hand-edited
   save cannot present an active career as still re-decidable.

### The player is never told (§22)

`lifepath_static.py` asserts the detail screen shows a life path only once it is
**active** — never the eligibility, the pressure, the stage or the candidate
list — and that no headline contains a raw identifier. A rival still on the Gym
Challenge shows nothing at all, so the screen cannot leak who has an
alternative destiny waiting.

Everything hidden from the player is visible to the developer via
`/rival_lifepath`, which is a debug verb precisely *because* §22 forbids
exposing it in the game.

### Reuse, not duplication (§35)

The facts snapshot is the whole integration point and `lifepath_static.py`
asserts every field is read from a system that already owns it — badges, the
1.36 navigation atlas, the 1.34 identity, the 1.33 relationship, the 1.39
League wall, the 1.38 purse. It also fails if a duplicate pressure counter ever
appears.

Team Rocket (§17) needs more than a mean streak: hostility toward the player
and financial hardship gate it, so a merely aggressive rival does not drift into
it. Every path keeps a floor, so §4's "allow unexpected outcomes" holds — a
Collector *can* still, rarely, end up in Team Rocket.

### Cost

The decision is checked once every 240 ticks for **one** rival — at most two in
a save can ever take a path, and the pressure driving it moves over hours. That
keeps it off the per-tick budget entirely (§34).

### Testing

| Suite | Checks |
| --- | --- |
| `tests/lifepath_test.lua` | 20,625 — determinism, the distribution over 20,000 seeds, never-all-four, pressure earned not rolled, the state machine, compatibility floors, locking, bounds, presentation |
| `tests/lifepath_static.py` | eligibility derived not stored, seed written once, every guard present in the commit door, no duplicate counters, no §22 leaks |

### Not yet implemented

§39 onward of the brief is **truncated in the source document** ("39. Important
Ba") and has not been implemented. §7–19 (career behaviour), §20 (life-path
relationship shifts), §21 (career event types), §24–27 (world integration,
career goals, progression, milestones) and §28–29 (returning and late return)
are scheduled for 2.2–2.4.

## 2.2.0 — Careers: Breeder, Researcher, Explorer, Retired

2.1 decided *whether* a rival leaves the Gym Challenge and *which* life it
takes. This is what it then does with itself.

### Why these four

Breeder (§7), Researcher (§9), Explorer (§12) and Retired (§16) need **no new
world integration**: every activity they want already exists as an objective the
AI can select. The careers that need a specific building to stand in — Oak's
lab, the Tower, a Gym counter — are 2.3.

### The design, in one line

> A career is a different **priority order** over the objectives that already
> exist, plus a progress record. It is not a second AI.

That is §35's rule and `career_static.py` enforces it: the career model may not
mention `setDestination`, `routeTo`, `canEnterMap`, `nextHop`, `spawnNpc` or
`hopCost`. Writing a bespoke movement loop for a breeder would mean a second set
of the bugs the first loop already fixed — the bidirectional-warp bug, the
destination-is-current-map bug, the always-true-objective bug. A career that
reuses `AI.evaluate` inherits every one of those fixes and cannot drift from
them.

### The test caught me inventing an objective

My first career definitions listed a `HUNT` objective. **There is no such
objective.** `AI.Can` implements exactly `HEAL`, `CHALLENGE_PLAYER`, `GYM`,
`TRAIN`, `EXPLORE`, `SEEK_GHOST` and `RIVAL_DUEL`; hunting is a *target* pursued
during `TRAIN` and `EXPLORE`, not a thing to select.

An invented name sits in the priority list doing nothing at all — the quietest
possible way for a career to be broken, because it looks right and produces no
error. Both `career_test.lua` and `career_static.py` now read the objective
vocabulary out of `AI.lua` and fail on any name it does not implement.

The 1.14 lesson is re-asserted too: `EXPLORE` is always true, so anything placed
after it is dead code. Nothing may follow a fallback objective in any career
list.

### Ordering alone was not enough

With a vocabulary that small, ordering barely separates a breeder from an
explorer. So each career also carries a **catch bias** and a **party target**,
and `career_test.lua` asserts the four differ on at least three of those levers:

| Career | Objectives | Catch bias | Party |
| --- | --- | --- | --- |
| Breeder | HEAL, TRAIN, EXPLORE | ×2.2 | 4 |
| Researcher | HEAL, SEEK_GHOST, EXPLORE, TRAIN | ×1.5 | 4 |
| Explorer | HEAL, EXPLORE, TRAIN | ×1.0 | 3 |
| Retired | HEAL, CHALLENGE_PLAYER, TRAIN | ×0.25 | 2 |

The bias scales the *same* `rng:chance` call rather than adding a second gate,
so personality still sets the baseline and a rival on the Gym Challenge (bias 1)
replays pre-2.2 saves identically.

§7 is respected throughout: **abandoning the Gym Challenge is not abandoning
battles.** Every career keeps a fighting objective, and the static contract
fails if one ever does not. Retired lists `CHALLENGE_PLAYER` precisely because
§16 says it should still battle for fun — the objective's own cooldown and roll
keep that occasional rather than pushy.

### Progress and ranks (§26, §27)

One counter per declared metric and nothing else — no transaction list, and an
**unknown metric is refused rather than added**, so a typo at a call site cannot
quietly grow the save with a column nothing reads. Progress is rebuilt from the
path's own metric list on load, so a career change cannot carry orphan columns
forward. Four ranks per career, derived from total progress; a promotion is
news, the credits leading to it are not.

Every credit comes from an event that **already happens**: an explorer's
discovery is credited off the arrival the navigation atlas already records, a
capture off the existing catch path, an evolution off the existing evolve site.

One thing I caught and fixed while wiring that: I had guarded the promotion log
with `if promoted and ctx and ctx.log`, but `tryCatch(rival)` has no `ctx` in
scope — the branch could never be true. A guard that cannot fire is worse than
no guard, because it reads as though the case is handled. The promotion is now
returned to the caller and drained where a log genuinely exists.

### Unbuilt careers stay inert

`OAK_ASSISTANT`, `TOWER_CARETAKER`, `GHOST_RESEARCHER`, `GYM_ASSISTANT`,
`CENTER_ASSISTANT`, `MART_WORKER` and `TEAM_ROCKET` have **no** career
definition and **no** dialogue. The static contract fails if a half-built one
appears. A rival on an unbuilt path keeps its personality's objective order and
keeps chasing badges — visibly unchanged rather than subtly broken — and §22
holds, because no line exists that could hint at a destiny the game cannot yet
deliver.

### Testing

| Suite | Checks |
| --- | --- |
| `tests/career_test.lua` | 112 — objective vocabulary, fallback ordering, distinguishability, bounded progress, ranks, live rivals, migrations |
| `tests/career_dialogue_test.lua` | 84 — every built career × every personality; no lines for unbuilt paths; no identifier leaks |
| `tests/career_static.py` | not-a-second-AI, objectives verified against `AI.Can`, dead-guard check, unbuilt paths inert |

## 2.3.0 — Located Careers

2.2 built the four careers that need no world integration. This adds the six
that are **about a place** (§8, §10, §11, §13–15): Oak's Assistant, Tower
Caretaker, Ghost Researcher, Gym Assistant, Centre Assistant, Mart Worker.

All ten life-path careers are now built. Only Team Rocket remains inert.

### §24 is the whole constraint

> "Do not simply teleport them to their new location permanently. They should
> use the existing movement/navigation systems where appropriate."

So a located career gets a home **pattern**, not a map id, and **one** new
objective — `CAREER_HOME` — in the AI's existing vocabulary. The rival routes
there through the same graph, the same progression gates and the same hop clock
as every other journey it has ever made.

`career_test.lua` asserts the no-teleport rule directly: after a rival takes the
job, its map is unchanged and the objective that would take it there is merely
*selectable*.

`Can.CAREER_HOME` is deliberately **not** always-true, or it would become the
1.14 dead-code bug — every objective after it in the list would never run:

- a career with **no home in this game** (no lab on Gold, no Tower in a
  conversion) can never select it, and the rival works to the rest of its list;
- a rival **already at its post** does not re-select it, or it would stand in
  the doorway forever;
- and a share of the time it is **out doing fieldwork** (§8's "may occasionally
  leave the lab"), because a career rival that never leaves is scenery rather
  than a character — §10 says a caretaker must remain a real character. The
  Tower Caretaker has the lowest fieldwork share in the mod at 10%; the Ghost
  Researcher, who is there to study rather than to tend, has 40%.

### Workplaces are matched by substring

The same reasoning as `Presence.PLACES` in 1.36: a hardcoded `OAKS_LAB` is wrong
on Gold, on a randomizer and on a total conversion — and being wrong there
should mean "no lab found", not a crash. `Career.findHome` walks the maps the
rival may *legally* enter, in sorted order, and takes the nearest match by
route, so a Centre assistant works at a Centre it can actually reach rather than
one behind a progression gate.

A game with none of the buildings yields `nil`, which is a legitimate answer.

### Three static-test faults, found and fixed

The static contract failed on seven checks and **all seven were the test's own
fault**, which is worth recording because each is a repeat:

1. `canEnterMap` appeared in `Career.lua` — in a **comment** explaining that the
   model must not bypass it. Comment lines are now stripped first. This is the
   third occurrence of that trap (1.37, 2.0, here).
2. The §7 "still battles" check sliced each career body on `},\n  `, which stops
   at the **first nested table** — `home`, `metrics`, `milestones` are all
   nested, so the block being checked could not contain an objective list, and
   every located career failed for a fault it did not have.
3. My replacement helper was named `career_block`, which was already a string
   variable in the dialogue section further up the file.

A static test that fails for the wrong reason is only marginally better than one
that passes for the wrong reason — both mislead about what is actually verified.

### Testing

| Suite | Checks |
| --- | --- |
| `tests/career_test.lua` | 246 — plus workplace resolution, pattern precedence, gated buildings, absent buildings, and the no-teleport rule end to end |
| `tests/career_dialogue_test.lua` | 180 — all ten careers × every personality |
| `tests/career_static.py` | plus: every located career names a pattern, lists `CAREER_HOME`, and has a fieldwork share; the objective respects every gate |

## 2.4.0 — Team Rocket, Redemption and Returns

The last of the life paths, and the arcs that continue after one is taken:
§17–19 (Rocket and defection), §20 (relationship consequences), §28–29
(returning and late return).

**Every declared life path now has a career and dialogue.** The static
contract's inertness rule has inverted into a *completeness* rule: it reads the
path list out of `LifePath.lua` and fails if any path lacks a career definition
or a line, because a rival that took it would behave as though nothing had
happened.

### The tension the brief contains, and how it resolves

§33 says a committed life path is **locked** and must not be re-decidable. §19
says a Rocket rival may defect. §28 says a career may end in a return. Those
look contradictory and they are not:

> The lock exists to stop a player **re-rolling a destiny** by reloading — not
> to stop a character's story continuing.

So `commit` still refuses outright once locked; there is no path back to "pick
again". A **transition** is a separate operation along a *declared edge*, with
its own earned prerequisites:

- the edge must exist in `LifePath.TRANSITIONS`;
- the rival must have **served a tenure** in that life (nobody defects the
  afternoon they join);
- the derived **doubt** must have reached the threshold;
- and the destination is drawn from the **save seed**, so reloading cannot
  change where a defector lands any more than it could change where a rival
  diverged to.

A transition leaves the record **locked**. §33 holds across the whole arc — a
returned rival cannot take a second divergence, and the test pins that.

Nothing may transition *into* Team Rocket. §17 requires it to be committed to
under its own prerequisites, not drifted into from another career, and the
static contract fails if an edge ever points there.

### Doubt is derived, and redemption is not guaranteed

For a Rocket rival, §19's triggers: the player keeps beating them, the
relationship warms, the work is not paying, confidence is low. For every other
career, §28's: the career has been **mastered** and the competitive itch has
returned.

A rival on the Gym Challenge reads **zero** doubt — it has no career to doubt.
The first version fell through to the career branch and produced a small
non-zero reading for an ordinary rival: the same shape as 2.1's
pressure-from-no-facts bug, and the same fix. Absence of a question means zero,
not a default answer.

### §20: a path change moves relationships

Four new causes in the 1.33 model — `TURNED_ROCKET`, `LEFT_ROCKET`,
`CHANGED_PATH`, `CAME_BACK` — applied to every other rival **and** to the
rival's own view of the player. Routing it through the existing causes means a
friend's defection is an ordinary, explicable relationship event that decays,
compounds and shows up in dialogue like anything else, rather than a special
case bolted on beside the model.

### §18: a Rocket rival gains nothing

> "Do not give them illegal Pokémon or impossible resources. They remain bound
> by the same fundamental game rules."

The Rocket career is a priority order, a workplace pattern and a catch bias —
exactly like the other nine. `career_static.py` asserts its definition grants no
money, badges, levels, species or items. What changes is where it goes, who it
fights and what it says.

### Dialogue keyed on the past

`D.formerly` is keyed by what a rival **was**, not what it is: the interesting
thing about a researcher who used to be in Team Rocket is where they have been.
It is offered ahead of the current-career line for that reason.

### The prefix-slicing trap, fourth occurrence

`function LifePath.transition` prefix-matches `transitionTargets`, so the static
contract sliced the wrong body and reported two failures that did not exist.
This is now the fourth time (1.35 `Story.mood`/`moodLabel`, 1.38
`Rival:spend`/`spendBall`, 2.2, here). **Anchor source slices on the full
signature, always.** Every slice in that file now does.

### Testing

| Suite | Checks |
| --- | --- |
| `tests/lifepath_test.lua` | 20,739 — plus declared edges only, tenure, the lock holding across the arc, derived doubt, no path into Rocket, bounded arc history |
| `tests/career_test.lua` | 268 — plus every declared path built |
| `tests/career_dialogue_test.lua` | 196 — all eleven career states × every personality |
| `tests/lifepath_static.py` | transitions cannot bypass the lock; §20 causes exist and reach the player; §18 grants nothing |

## 2.5.0 — Absorbing v1.30.0, and the four-version spawn claim

Two files existed in **v1.30.0** and in no release since: `src/Phone.lua` and
`src/LifePaths.lua`. One was absorbed. One was rejected.

### `Phone.lua` — absorbed (523 lines)

A persistent trainer phone number per rival, contact offers, and calls: on Gold
it registers into the engine's `phone_contacts` registry so contacts appear in
the Pokégear; on Gen 1 there is no Pokégear, so numbers exist for save
compatibility and calls arrive through the news ticker. Nothing built between
1.31 and 2.4 replaced it — the phone had simply been **missing for eight
releases**.

Two things had to change on the way in:

1. **It could not be parsed by the test harness.** Two `goto continue` skips are
   a Lua 5.2 extension. LuaJIT accepts them, so the file was fine on LÖVE — but
   plain 5.1 rejects them, which is why this module had never been covered by a
   single test in its life. Rewritten as a plain guarded block: identical
   behaviour, one fewer host assumption, and now testable.
2. **Its `LifePaths` coupling.** It asked the 1.30 module for a call bias; that
   module is superseded, so the bias now comes from the 2.2 career model — a
   Centre assistant calls more, a Rocket rival calls less. The shim returns the
   same `{ offerBias, weatherReportBias, dark }` **table** the 1.30 call sites
   index; my first attempt returned a bare number and every call site threw. The
   absorbed code is unchanged, so matching the contract is the shim's job.

### `LifePaths.lua` — rejected as superseded

1.30's version re-scored a rival's role on **every** AI evaluate, with a
stickiness term to stop it flickering. That is precisely the design the v2.x
brief opens by forbidding:

> "Do NOT implement: RNG roll → Rival immediately becomes breeder."

It also has no seed (§32), no lock (§33) and no permanence — a role that can
change every tick is a mood, not a life. `src/LifePath.lua` + `src/Career.lua`
supersede it completely. Re-adding it would leave **two systems both claiming to
own a rival's role**, which is worse than either alone;
`absorption_static.py` fails if the file returns or if anything requires it.

Its one genuinely useful idea — per-role multipliers for catching, challenging
and party size — already exists as 2.2's `catchBias` / `partyTarget`.

### "Make sure the AI Rivals spawn in Red, Blue, Yellow and Gold"

That claim has been in the documentation since 1.1 and had **never been
measured**. `tests/version_matrix_test.lua` builds a synthetic dataset shaped
like each of the four boots and walks the whole chain a spawn depends on. It
found three things.

**One test bug (mine).** In a Lua table constructor only the *last* `unpack`
expands; earlier ones are truncated to a single value. My fixture's
`{ "PIKACHU", unpack(JOHTO_TRIO), unpack(KANTO_TRIO) }` silently gave Gold no
Cyndaquil or Totodile, which looked like a mod bug and was not.

**Two real ones:**

- **Yellow had drifted off spec.** Yellow's rivals were being given the Kanto
  starting trio — which Yellow does not hand out — instead of the specified
  Eevee ×3 plus one Clefairy. Now: `EEVEE, EEVEE, EEVEE, CLEFAIRY`.
- **Every starter chain held exactly one species.** A boot lacking that one
  species left that rival with **no starter at all** — on a randomizer, a
  conversion, or any boot whose roster differs. Every chain now has fallbacks,
  and the static contract fails on any single-entry chain.

Verified per boot, per rival: version detected from the data, a starter that
boot really carries, and a sprite that boot really carries.

| Boot | Starters |
| --- | --- |
| RED / BLUE | Charmander, Squirtle, Bulbasaur, Clefairy |
| YELLOW | Eevee, Eevee, Eevee, Clefairy |
| GOLD | Cyndaquil, Totodile, Chikorita, Clefairy |

### Two spawn-chain holes closed

- `safeSprite`'s last resort iterated `pairs()`, so the same save could hand a
  rival a **different sprite on two loads**. Now sorted.
- Its final fallback returned `"SPRITE_BLUE"` — which **Gold does not have**.
  A spawn with an unknown sprite fails outright rather than degrading, so the
  rival would never appear. It now returns `nil` and the spawn site fails
  closed, leaving the rival abstract for a later retry — the same discipline
  already used for an unproven tile.

### Testing

| Suite | Checks |
| --- | --- |
| `tests/version_matrix_test.lua` | 135 — detection, starters and sprites for every rival on Red, Blue, Yellow and Gold, plus a total-conversion boot |
| `tests/phone_test.lua` | 37 — numbers unique and stable across save/load, pre-2.5 migration, Gen 1/Gen 2 registration safety, 6,000-tick run |
| `tests/absorption_static.py` | Phone stays wired and goto-free; 1.30 `LifePaths` cannot return; starter chains keep fallbacks; Yellow never leads with a Kanto starter |

## 2.6.0 — Randomised starters

Rivals no longer own a fixed starter. Each new game deals them one from a pool.

| Pool | Species |
| --- | --- |
| Red / Blue / Yellow | Charmander, Bulbasaur, Squirtle, Eevee, Pikachu, Clefairy |
| Gold | those six plus Chikorita, Cyndaquil, Totodile |

### "Random" has to mean two things at once

**Different between playthroughs. Identical within one.**

That distinction matters more for starters than for anything else in this mod.
A rival's ace, its team identity, its accumulated type credit and half its story
are all *downstream* of the Pokémon it opened with — a starter that rerolled on
load would quietly invalidate five other systems and produce a rival whose
history no longer matched its team.

So the deal is a **pure function of (world seed, rival slot)**, and the seed is
created once at new game and persisted. `absorption_static.py` fails if the deal
ever reaches for `math.random`, `os.time` or `os.clock`.

### The world seed — and the bug it fixed

Life-path eligibility was already seeded, and its seed was derived from the
generation, the rival ids and their starters. **All of those were fixed data**,
so every save produced the identical number, and therefore the identical
eligibility. §3's 85 / 12 / 3 distribution was correct in the model and
unreachable in practice, because the roll never varied.

There is now one world seed, created once from real entropy (`os.time`,
`os.clock`, a `math.random` draw and a fresh table's address — several weak
sources because no single one is guaranteed present in every host), persisted,
and used for both the starter deal and the life-path draw. Creation may be
random; only *stability* is required, and persistence is what provides it.

An existing save keeps the seed it was already playing under, so upgrading never
reassigns a destiny a player has been living with.

### A rotation was not random enough

The first implementation rotated the pool by the seed. That yields only as many
hands as there are species: **400 different saves produced six different hands**,
and the four rivals always held four *consecutive* pool entries. The test caught
it because it counted.

Sorting the pool by a per-species hash of the seed is a real permutation.
**400 saves now produce 164 distinct hands**, and the suite asserts ≥ 60 so a
future rotation cannot creep back.

### Dealt without replacement

Each rival takes its own slot in that permutation, so four rivals never open
with four Pikachu — asserted across 300 seeds. When a boot carries fewer pool
species than the roster the deal degrades to *sharing* rather than to nothing,
and a boot carrying none of the pool falls back to a last-resort list kept
deliberately outside the pool so it is never dealt in an ordinary game.

A roster row that declares its own `starters` still wins outright, legacy
flat-list form included, so a third-party roster keeps working.

### Testing

`tests/version_matrix_test.lua` grows to **508 checks**: stability per seed,
variety across seeds, no duplicates, every pool species reachable, Gold really
dealing the Johto trio, scope filters respected, small and empty pools, and the
whole four-boot spawn chain from 2.5 unchanged.

## 2.7.0 — The intro gauntlet is not in Oak's Lab on Gold

Reported from a real Gold boot: the mod said the rivals were waiting in Oak's
Lab, and character creation offered a battle there. **Gold has no Oak's Lab.**

### The comment described behaviour the code did not have

`main.lua` had carried this since 1.6:

> "Gen 2 has neither under these names, so the gauntlet simply does not start
> there."

The code did not do that. The candidate list held only Kanto maps —
`{ "OAKS_LAB", "PALLET_TOWN" }` — and when neither was found the resolver ended:

```lua
return "OAKS_LAB"
```

So on Gold it returned a map the game does not contain. Everything downstream
believed it: rivals were seeded into that map id, the status screen reported
them there, and the intro prompt offered a battle in a room that cannot be
entered. Twenty-six sites hardcoded the same literal as a fallback or as an
extra `or mapId == "OAKS_LAB"` comparison, so the assumption was load-bearing
in a lot of places at once.

### The fix

- **Gold's rooms are candidates in their own right**, not aliases:
  `OAKS_LAB`, `ELMS_LAB`, `PALLET_TOWN`, `NEW_BARK_TOWN`.
- **The fallback is `nil`.** A boot with none of these genuinely has nowhere to
  hold the gauntlet, and saying so is better than naming a room at random.
  `beginGauntlet` refuses outright rather than arming a sequence pointed at
  nothing.
- **Twenty-six literals became five.** The remaining five are deliberate and
  commented: the candidate list itself, and the two branches (plus the
  synthetic grid they use) that encode the *Kanto* lab's 5×6 interior geometry.
  Elm's lab is a different room, so Gold falls through to the proven
  entry/safe-placement path rather than being placed on cells measured for
  somewhere else. `absorption_static.py` fails if more than four appear in code.
- **The intro prompt names the room this game has** — "Battle the AI rivals in
  Elm's Lab?" on Gold — and where there is no lab at all the step is **not
  inserted**, because offering a choice the mod cannot honour is worse than not
  asking.

### Testing

`tests/version_matrix_test.lua` grows to **531 checks**, reproducing the
resolver and asserting per boot that the gauntlet room **exists in that boot**;
that Gold resolves to Elm's Lab and never to Oak's; that a boot with none of the
candidates yields *no gauntlet* rather than a Kanto map; and that every
candidate has a player-facing name so no screen ever shows a raw map id where a
room name belongs.

## 2.9.0 — HGSS Visual Overhaul compatibility

Reported against **HGSS Visual Overhaul 0.5.9**
(`LucianoNeo/gen1recomp-mods`): *"things revert when speaking to ai in your
mod then go back to HG."*

### What was actually happening

HGSS patches a shared sprite record with two things at once (its `main.lua`
lines 205 and 255):

```lua
mod.content.sprites:patch("SPRITE_" .. shortId, {
  image           = "assets/voxel/frame_layout_6_32.png",  -- proxy sheet
  hgssNativeImage = "overrides/sprites/<file>.png",        -- the real art
  hgssFrameWidth  = 32, hgssFrameHeight = 32,
})
```

It then wraps `SpriteRenderer.new` (line 1979): any def carrying
`hgssNativeImage` gets `self.image` replaced with the HGSS texture at
construction, under a 32px frame contract.

Our `Sprites:registerSlots` wrote `record.image = art.image` straight over the
top **and left the marker in place**. That leaves the record internally
inconsistent — our 16px art, their 32px frame contract, still flagged as
theirs. Whichever path read it next won, so the look flipped depending on
whether a renderer happened to be built through their wrapper. That is the
reported flicker exactly: our art while the talk path rebuilt the entity,
theirs again once the wrapped constructor ran.

### The fix is ownership, not precedence

A record another mod has authored is **theirs**. A visual overhaul exists to
decide how the world looks, and a rival borrowing a vanilla walker id has no
claim on it. So we keep our slot and use the art already on the record — under
HGSS a rival looks like an HGSS trainer, consistently, with nothing to flip
back to.

`Sprites.foreignArt` applies two independent tests:

- **A known marker field** — decisive and cheap. The list names what HGSS 0.5.9
  really writes, and the test fails if it ever stops matching.
- **The art no longer matching the captured vanilla baseline** — which catches
  an overhaul we have never heard of. Our own last write is passed in and
  excluded, so a second pass over a slot we painted does not mistake our work
  for a foreign claim.

The baseline is captured in the entry chunk, for the same reason the
`choose_your_hero` probe is: overhauls patch at merge time, so anything read
later is already somebody's opinion rather than vanilla.

The invariant the test pins is that a record is **never left half-ours**.
Either we own the whole thing (our art, no foreign marker) or we do not touch
it — the mixed state is the bug.

`HGSS_SPRITES` is now declared in `optional_dependencies`.

### Two API mistakes I made getting here

Both caught by running against the real engine source rather than assuming:

- `mod.content.sprites` has **no `all()`**. The id walker is `each()`
  (`Registry.lua:204`), and `items()` covers only ids a mod has written an op
  for — precisely the wrong set, since the baseline we need is the untouched
  record.
- `each()` returns an **iterator** yielding `(id, value)`, not a table of ids.

### Testing

`tests/hgss_compat_test.lua` — 18 checks against HGSS 0.5.9's real record
shape: the marker is decisive with or without a baseline, an untouched record
is still ours to paint, our own art is not mistaken for a foreign claim, a
third mod's is, an unknown overhaul is caught by the baseline, and the
half-ours combination can never be produced.

## 2.10.0 — Gold: Kanto is postgame

Reported: *"In gen 2 gold the rivals are starting in Kanto. That's post game
in gen 2."*

Correct, and there were **two** causes.

### 1. The starting maps were Kanto literals

`POST_LAB_STARTS` and every rival's `homeMaps` named Route 1, Viridian, Route 2
and Pallet Town. Gold's map table **contains every Kanto map** — they are
simply unreachable until the Elite Four is beaten — so nothing failed and
nothing fell back. The four were released straight into postgame content.

Both are now version-keyed, alongside a `homeMapsFor` resolver that still
accepts the flat-list form so a third-party roster keeps working. Johto's
opening corridor is the equivalent: New Bark → Route 29 → Cherrygrove →
Route 30, ending at Violet, whose Gym is already first on the Johto ladder in
`data/gyms.lua`.

| | Homes |
| --- | --- |
| Red / Blue / Yellow | Pallet Town, Viridian, Route 1, Route 2 |
| Gold | New Bark Town, Route 29, Cherrygrove, Route 30 |

### 2. Gold had no progression floors at all

The deeper one. `Rival:canEnterMap` gates the campaign behind:

```lua
if byBadge and byBadge.BOULDERBADGE then
```

`BOULDERBADGE` is the **Kanto** badge table. On a Gold boot `byBadge` is the
Johto table (`ZEPHYR`, `HIVE`, …), so that entire block was skipped and a rival
had **no floor of any kind** — free to walk the raw connection graph anywhere
it liked. Fixing the starting maps alone would have delayed the symptom by
about a minute.

Gold now gets the gate the player has: **Kanto opens when the League is
beaten.** Region is decided by city name plus route *number* — Gold's Johto
routes are 26 and up, Kanto's 25 and down, a clean split needing no per-map
table. `INDIGO_PLATEAU` is deliberately excluded: it is the **Johto** league
too, reached from Route 26, and gating it would wall a rival out of its own
main story.

Gen 1 is untouched, and the test asserts it: a Kanto rival still walks Route 1
from the start, and Cerulean still needs a badge exactly as before.

### Testing

`tests/gen2_region_test.lua` — 71 checks: the region split across 24 real map
ids, the gate through a live rival on a Johto badge table, Kanto opening on
`champion`, Gen 1 completely unaffected, every roster row carrying a Johto home
set that contains no Kanto map, and the four not all starting on one tile.

One static-test fault fixed in passing: the starter-pool contract searched for
`default` / `yellow` / `gen2` keys unanchored, and the new version-keyed
`homeMaps` introduced earlier matches of those names — so it read a home-map
arm and reported Gold's pool as missing the Johto trio. It is now scoped to the
`ROSTER.pools` block.

## 3.0.0 — Communications framework (Pokégear foundation)

The brief's §1 and §2 ask for an architecture audit and a feasibility report
**before** implementation. Both are in `docs/pokegear-feasibility.md`. This
release is step 3.0 of the staging that report recommends: the contact and call
model, no UI.

### The finding that shapes everything

`src/mods/Schemas.lua` (620–639) names the registries with **no Gen 1 home**:

```lua
--   phone_contacts  no Pokegear, no phone
--   landmarks       Red's town map is a Gen 1 town-map table, not the
--                   LANDMARK_* index space the Pokegear ... share
--   radio_channels  no radio
```

Writes to those are **dropped and reported**, and the comment is explicit that
this is not a spelling difference: *"the systems themselves are absent from Red
rather than spelled differently there."* `src/ui/gen2/Pokegear.lua` is also not
one of the fifteen modules `Gen2Compat` adapts.

So a Gen 1 Pokégear **cannot** wrap Gold's. It must own its state and *target*
the Gen 2 registry where one exists — which is exactly what `src/Phone.lua` has
done since 1.30. This generalises that file's contact handling from rivals to
anyone; it does not replace it (§18, §46).

### What 3.0 contains

- **Contacts as a type field**, not a hierarchy. §29 requires that ordinary
  trainers become summonable later *without a rewrite*, and the way to
  guarantee that is for a rival and a fisherman to be one record differing in
  one column.
- **Deterministic numbers** in `(world seed, contact id)` — stable across
  save/load, different between playthroughs, and **never reissued**. The test
  pins that hardest: a saved contact whose number changed would point at
  nobody, which is the one thing a phone book must never do.
- **Offered / accepted / declined as three states** (§11, §36), so a refusal is
  remembered and nobody nags, and the player is never unsure whether a number
  saved.
- **A call budget** — per-contact and world-wide cooldowns, plus a hard refusal
  while the world is busy (§39). Not queued: a queue that fires the instant a
  battle ends is still an interruption. This is the same discipline that keeps
  1.36's sightings from swamping the ticker, and §28 says it is what makes the
  player feel they are contacting a person rather than spawning an NPC.
- **Closed vocabularies** for reasons and types, and §27's interrupt priorities
  as data, so a summon can never outrank a story event.
- **Bounded everything**: 60 contacts, 24 history rows each, 8 missed calls,
  deterministic eviction and listing order.

Contacts are **world state**, not rival state — a phone book belongs to whoever
owns the phone. A pre-3.0 save gets an empty one; no contact is invented for a
trainer the player beat before the network existed.

### Deliberately not in 3.0

No UI, no scheduler that runs itself, no summoning. Keeping the tick out means
this is testable headlessly and **cannot spam anything on its own** — the
scheduler arrives in 3.1 with the screen that shows what it did.

### Known constraints, stated rather than discovered later

- **Radio** has no Gen 1 registry; a Gen 1 radio must drive the shared `music`
  registry, and `modkit pack` refuses ROM-derived bytes.
- **Clock**: `src/core/DateTime.lua` is generation-neutral device time; Gold has
  a real in-game clock and Gen 1 does not. Weather FX exports `timeOfDay()`
  when installed. §5 forbids feeding game timing.
- **Rematches and summoned battles on Gold** still need
  nothing. See 3.1: Gold trainer battles now go through `World:startBattle`
  plus our own `trainer.party` hook, entirely inside the mod.

### Testing

`tests/comms_test.lua` — 90 checks: number stability and collision rate across
400 contacts, the three join states, the budget including the busy gate, closed
vocabularies, bounded history and eviction, corruption repair, deterministic
listing order, priority ordering, and a source scan proving the model is
headless and deterministic.

## 3.1.0 — Gold trainer battles, with no engine patch

We had been shipping `patches/0001-gen2-mod-trainer-battle.patch`. **That was
wrong.** A mod has to work on a stock install; a player who cannot patch their
engine had a headline feature that silently did nothing. The patch is deleted
and `tests/gen2_battle_static.py` fails if it ever returns.

### The supported route was there the whole time

Three places in the engine source say so, and I had read past all of them:

1. `src/world/gen2/WorldAPI.lua` refuses `start_battle "trainer"` because *"the
   trainer arm needs a party out of the extracted trainer table and an
   OPP_CLASS the mod cannot name."* That is a limit of the **script verb**, not
   of the engine.
2. `World:startBattle(opts, onDone)` (`src/world/gen2/World.lua:5822`) takes
   **`opts.trainer` directly**, and `mod.world:overworld()` is a public
   accessor.
3. `src/battle/gen2/Battle.lua:273-288` then calls the **`trainer.party` hook**
   — the same hook our rivals have fought through since 1.1 — and states
   outright: *"a mod that hands back rows it built itself keeps them, because
   nothing here rewrites what the hook returned."*

So the two objections in the refusal both dissolve: we need no party out of the
extracted table (our hook supplies it) and no OPP_CLASS we cannot name (we name
our own `OPP_AIR_*`).

The mod now passes a trainer **shell** with `party = {}` and lets its own hook
answer. That empty party is deliberate and the static test pins it: it makes
the hook the single source of the team, so a Gold battle and a Gen 1 battle
fight the *same persistent party* rather than two rosters that can drift.

Gold takes this route **first**, because `Gen2Compat` marks
`BattleState.newTrainer` **absent** — *"Gold has no factory that returns an
unpushed battle"* — so the Gen 1 construction can only fail there, and trying
it first would produce a misleading error.

### A bug caught while writing it

My first draft called `M:onRivalBattleFinished` from the completion callback.
**No such function exists.** It would have raised inside a `pcall` on every
Gold battle and silently eaten the outcome.

The correct answer is to do nothing there: `battle.ended` already settles a
rival battle — result, relationship, service credit, story beat — and Gold
raises that event under the same name. Doing it again in the callback would
**double-count every battle**: two memory rows, two relationship swings, two
career credits. The static test fails if the call comes back.

### What this changes

`docs/pokegear-feasibility.md` section C ("needs Gen1Recomp core changes") now
reads **nothing**. Every part of the Pokégear brief — rematches, summoned
battles, the whole trainer network — is reachable from inside the mod.

### Testing

`tests/gen2_battle_static.py` — the patch cannot return, no doc may claim one is
needed, Gold must take its own route first, the route must use
`world:overworld():startBattle` with an empty trainer party, it must not reach
for `queueScript` / `newTrainer` / a direct `src.battle.gen2` require, and the
`trainer.party` hook must still exist.

`modkit gen2check` still reports **will load but degrade (8 warnings)** — the
remaining warnings are the version-string and screen-id ones noted in 2.8, two
of which are known false positives.

## 3.2.0 — Rivals stay alongside the player

Reported: rivals running away — *"they should never for example be three gyms
ahead of the player."*

### The cap existed and was silently comparing against zero

`Can.GYM` has capped rivals at one badge ahead since 1.6:

```lua
local playerBadges = tonumber(world and world.playerBadges) or 0
if rival:badgeCount() > playerBadges then return false end
```

`M:worldView()` supplies `playerBadges`. **The per-tick `ctx` that
`Simulation:runTick` builds never did.** So the cap worked when the manager
evaluated a rival and silently compared against `0` on the path that runs most
of the time — and `or 0` meant it failed *quietly* rather than erroring.

Three changes, each closing a different hole:

1. **The tick now carries `playerBadges`.** The missing field.
2. **One decision, not two copies.** `Rival:mayEarnBadge()` is the rule;
   `Can.GYM` and `Simulation.attemptGym` both call it. `pace_static.py` fails if
   either re-implements the comparison inline — two copies disagreeing is
   exactly what happened.
3. **Enforced at the award, not only at selection.** Objective selection is
   advisory: a rival can be halfway to Cerulean when the cap closes, and the
   objective is only re-chosen at a decision point. `attemptGym` now refuses
   **before the battle** — a rival that beats a Gym Leader and receives nothing
   would be a worse bug than one that waits, and the static test asserts the
   check precedes the award.

### An unknown player is not permission

Two places treated "no reading yet" as *no limit*:

- `levelCeiling` returned **100** when the player had no party — so through the
  entire opening, before the player's first Pokémon exists, a rival could grind
  freely and arrive at Brock twenty levels up. It now uses an opening cap of 8.
- The badge reading defaults to **0**, never to unlimited.

Both readings are now **persisted**. Without that, the first tick after every
load had no reading, so reloading granted a free level.

### Routes follow badges — no second mechanism

`Rival:canEnterMap` gates the campaign on the rival's *own* badge count, so
capping badges caps how far across Kanto they roam. A one-badge rival can reach
Cerulean and cannot reach Fuchsia or Cinnabar. That is asserted rather than
assumed, so a future change to either half will show up as a test failure.

### Measured over a full playthrough

The soak gives four rivals a badge opportunity every 200 ticks and free
experience every 50, against a player earning one badge per 2,500 ticks — far
more pressure than real play — and checks the gap on **every tick**, not at the
end:

```
24000 ticks: worst badge lead 1, worst level lead 3
```

And the converse matters too: pacing must not freeze the world. All four rivals
still finished with six or more badges, so they keep up rather than stalling.

### Testing

`tests/pace_test.lua` — 41 checks: the lead cap in both directions (a rival
*behind* is never held back), both gates agreeing, a world object missing
`playerBadges` not unlocking the gym, the level band including the
no-party case, routes following badges, persistence across save/load and the
pre-3.2 migration, and the 24,000-tick soak.

## 3.3.0 — Every rival selectable; gauntlet capped separately

> "Allow the player to select all rivals at character creation, keep the
> gauntlet to 4 but allow all rivals to be in the game at once."

The roster size and the gauntlet size were **the same number by accident**.
They are now two numbers.

### Three places hardcoded four

- the character-creation step (`choices = { "ONE", "TWO", "THREE", "FOUR" }`),
- the answer handler (`math.min(4, ...)`),
- `activeRoster` (`math.min(4, ...)`).

`setRivalCount` was already roster-driven, so a fifth rival added to
`data/rivals.lua` would have been **unreachable**: the creation step could not
offer it and two clamps would have trimmed it away. The mod would have capped
the game below its own content.

All three now read `#ROSTER`. The choices are generated, with the top entry
labelled **ALL** so "give me all of them" is one obvious choice rather than
arithmetic the player has to do — and a one-rival roster skips the step
entirely, because a question with one answer is not worth asking.

### The gauntlet cap trims the queue, not the world

`M.GAUNTLET_MAX = 4`. Every selected rival is seeded into the world; only the
first four queue up in the lab. Four consecutive battles is already a long
opening — eight would be a wall between the player and Route 1.

The cap trims from the **end**, so the order stays stable and the rivals the
player meets first are always the same ones. Those left out are not removed or
delayed; they are in the world alongside the others from the start.

### Tested against a roster larger than the shipped one

That is the case the change exists for, so `roster_size_test.lua` exercises
rosters of 5, 6, 8, 10 and 12 as well as the shipped 4: every count is
selectable, `ALL` really means all, an over-large saved count clamps to the
roster rather than to four, and the gauntlet never exceeds four regardless.

### One thing this does not do

**The shipped roster is still four**, so today "ALL" means four and the gauntlet
cap never binds in a normal game. The plumbing is what changed: adding rivals is
now purely a `data/rivals.lua` edit — a row with a unique `id`, `name`,
`slot` and `trainerClass` — and everything downstream (creation step, starter
deal, gauntlet cap, pacing, sprites) follows automatically. `roster_static.py`
fails if any site starts hardcoding a size again.

Sprites already degrade safely for a larger roster: `spriteForRival` prefers a
per-rival list, then the shared safe list, then any sprite the boot carries,
sorted — so extra rivals get sensible walkers without new art.

### Testing

`tests/roster_size_test.lua` — 96 checks across six roster sizes: choice
generation, the ALL entry, clamping in both directions, the single-rival case,
the gauntlet cap and its trim order, rivals outside the gauntlet still counted,
and roster rows being well formed with unique ids and starter slots.

## 3.4.0 — Gold: the sprite table has a different name

Reported: *"I'm in New Bark Town, it says there is a rival there in the menu
but there isn't a rival there."*

### The cause

Gold's overworld sprites live in **`data.gen2Sprites`**
(`src/world/gen2/World.lua:734` loads it as the `gen2Sprites` data table).
`data.sprites` is the Gen 1 table and is simply not present.

`M:safeSprite` and `M:spriteForRival` read only `data.sprites`. On Gold they
found nothing and returned `nil` — and since 2.5 the spawn **fails closed**
rather than naming a sprite the boot lacks, which is correct: Gold's
`pooledNpc` refuses any object whose sprite it cannot resolve, so a wrong id
would have produced the same invisible rival with an error instead.

So the rival stayed **abstract**: no NPC, but `rival.map` still said
`NEW_BARK_TOWN`. Both halves of the report are the same bug.

`src/Sprites.lua:245` already knew about `gen2Sprites`. These two did not. The
record shape is identical (`id` / `image` / `frames` / `walker`) and the ids use
the same `SPRITE_*` spelling, so reading either table needed no other change —
they now go through one `M:spriteTable()` accessor, and `SAFE_SPRITES` gained
Gold's own walkers so a rival there looks like a Gold trainer rather than
falling through to whatever sorts first.

### The reporting bug underneath it

The rivals menu printed `rival.map` alone — the simulation's position, whether
or not the rival managed to appear. A rival on the **player's own map** that has
not spawned is now marked, so the menu never claims a presence the player can
walk up to and fail to find.

That distinction matters beyond this bug: a spawn can legitimately fail (an
unproven tile, a map with no room), and when it does the player should not be
told somebody is standing next to them.

### The fixture was kinder than the engine

The Gold fixture in `version_matrix_test.lua` put its sprites under
`sprites`, so the whole four-boot spawn chain "passed" against a table Gold
does not have. **A fixture kinder than the engine proves nothing**, and this one
had been proving a chain that could not work since 2.5.

It now uses `gen2Sprites`, and I verified the suite actually catches the
regression rather than trusting that it would: reverting the resolver to the
Gen 1-only lookup produces **12 clean failures**, and the fix produces none.
The resolver also names the missing table instead of raising, because a suite
that dies with "attempt to index nil" tells you far less than one that says
which table is absent.

### Testing

`tests/version_matrix_test.lua` — 544 checks, including a new section asserting
that the Gold fixture has **no** `data.sprites`, that every rival resolves a
sprite from `gen2Sprites`, and that a boot with neither table is named rather
than crashed. `absorption_static.py` fails if either resolver goes back to its
own Gen 1-only lookup, or if the menu drops the presence check.

## 3.5.0 — Battle re-entrancy (from the uploaded 3.4.1 patch)

The uploaded `ai_rivals_v3_4_1_patch` is a **parallel branch, not a superset**.
It is built from a tree that predates 3.2, and its diff *removes* the pacing
work: `Can.GYM` reverts to reading `world.playerBadges` inline,
`Rival:mayEarnBadge` / `BADGE_LEAD` / `OPENING_LEVEL_CAP` are gone, the
`playerBadges` field is dropped from the tick ctx again, and `levelCeiling`
returns to `or 100`.

Adopting it wholesale would have silently reintroduced the "three gyms ahead"
bug and the uncapped opening. So the good work was extracted and ported instead.

### Taken — battle re-entrancy

A rival battle is a **transaction**, not an instant: dialogue, the deferred
launch, the battle, then the bookkeeping and gauntlet progression that follow
`battle.ended`. Every one of those windows could be re-entered, and the second
entrant corrupted the first's state. Now guarded at six points:

| Window | Guard |
| --- | --- |
| a second direct challenge | refused before any state mutation |
| during the launch window | refused on `pendingRivalBattleLaunch` |
| talking in the same frame | talk still allowed, launching a second battle is not |
| duplicate Gen 2 engagement events | ignored while a transaction is active |
| a stale delayed callback | must match the active rival id |
| after the battle | released **only** after bookkeeping and gauntlet progression |

The lock records **whose** battle it is, so one rival cannot release another's
transaction, and it clears on a failed launch and a failed queue — otherwise a
single failure would wedge the mod for the rest of the session.

### Also taken — two real fixes found in the diff

- **`isFainted` read a missing `hp` as zero.** A slot added by `addPokemon`
  before anything stamped its HP made the whole rival read as FAINTED — and a
  FAINTED rival refuses to battle. An absent value means *unknown*, and the
  honest default for unknown HP is full.
- **Healing now happens on arrival at a Pokémon Center**, not on the next
  simulation tick. Between arriving and that tick, a rival standing in the
  Center still read as FAINTED, and anything asking in that window — the menu,
  an interaction, a challenge — got the wrong answer.

### Not taken — the double-battle HUD

The patch also adds a secondary battle HUD to `DoubleBattles.lua`. It is
deliberately left out for two reasons:

1. It is rendering code that **cannot be verified by the headless suites** —
   nothing here can tell a correct HUD from a misplaced one.
2. It calls `require("src.render.Font")` and `require("src.render.HudTiles")`
   inside draw functions. Neither is among the fifteen modules `Gen2Compat`
   adapts, so on Gold those requires land in the boot error feed — the same
   class of problem as the `src.script.Commands` MK402 error fixed in 3.1.

It is a real feature and worth having; it wants a Gen 1-only capability gate
and a live check, which is a separate piece of work rather than something to
fold in blind.

### Housekeeping

Removed `nothing-0.0.3-py2.py3-none-any.whl` — a stray pip artifact of mine that
had been shipping inside the mod since an early session. `lib/dramatic_shape.lua`
is legitimate absorbed content (`DoubleBattles.lua` reads it) and stays.

The patch's `battle_reentrancy_static.py` is kept and rewritten: it was a bare
list of required substrings, so a failure printed strings rather than saying
which window had reopened. It now names each guard, counts the release sites,
and asserts the release happens **after** gauntlet progression — which is the
window the fix exists to close.

## 4.5.0 — The Pokégear call is a conversation

### The symptom and the actual cause

Reported: *"the Pokégear, when pressing call/rematch, does nothing."*

The dispatch was fine. `_call` fired, `M:callContact` ran, and the effect was
staged correctly — a rival was given a `PHONE_SUMMON` objective and a real
route, a trainer got a `pendingPhoneTrainer` rematch. What did not happen was
any of it being **visible**:

1. Every reply was written to `M.ticker`, and the `render.hud` wrap that draws
   the ticker requires `top.isOverworld` (main.lua). Inside the Pokégear the
   player is four screens deep, so the reply is drawn nowhere.
2. `core.update` keeps ageing the ticker while menus are open, so an 8-second
   line had usually expired before the player backed out to the map.
3. The row then called `menu:close()`, which pops exactly one screen. The
   player lands back on the phone list, one press poorer and none the wiser.
4. A staged trainer rematch waits for `M:overworldIdle()`, which is false until
   *every* menu layer is popped — so the visible consequence arrives minutes
   later, after the player has stopped connecting it to the button.

Four independent reasons for the same silence, none of them a broken button.
This is lesson 5 in a new costume: the feedback existed, it was just delivered
to a surface the player could not see from where they were standing.

### The shape of the fix

Answer where the question was asked. `AIR_PokegearCall` is a `ListMenu` with
`messageBox = true`, which is the engine's own bottom text box
(`src/ui/ListMenu.lua:260-275`); every action writes its reply to
`menu.footer`, and the ticker is still fed so the same news is readable again
on the map. The box shows the **last two** of eighteen columns, so spoken lines
are fitted to 36 characters at the point they are built rather than being
silently beheaded at draw time.

`src.render.TextBox` was checked before being relied on, not assumed:
`src/world/gen2/World.lua:61` requires it at module top, so the footer path is
live on Gold as well as Gen 1. That check exists because 3.5.0 rejected an
uploaded HUD for requiring modules Gen 2 does not adapt.

### Knowledge has levels (`src/Scout.lua`)

"Ask about another rival's team" is a question about what somebody *knows*, so
the answer is bounded by the caller's own experience: the head-to-head record
already kept in the relationship bonds. Three or more battles releases the
party, one or two releases the lead and the ace, no battles releases only what
is public, and nothing known says nothing known — `badgesOf` returns `nil`
rather than 0 for a subject nobody can answer for.

Derived on every open, stored nowhere, so a report cannot contradict the world
it describes. Ordinary trainers hold no bonds and therefore reach RUMOUR by
construction rather than by a special case.

### One door for the effect, again

`Tournaments:updatePending()` is now gated on `M:overworldIdle()`. A tournament
is arranged from inside four stacked menus, and the bracket immediately wants
its first player match — without the gate, `startRivalChallenge` could queue
dialogue under a list the player was still reading. Every other overworld
effect in this mod already goes through that door (lesson 26).

### A suite that crashed hid a thousand checks

`ai_rivals_test.lua` had been dying at its Wonder Trade section since roughly
4.2: its fixture builder called `Rival.firstAvailableStarter` in the pre-2.6
shape, which returns nil now that starters are dealt from `ROSTER.pools`, so
every fixture rival was built with an empty party and the first `party[1]` read
killed the process. Two failures were visible; about a thousand checks never
ran at all, and the roster contract inside them had quietly gone on describing
a four-rival mod with per-row starters for three releases.

The lesson is not the call shape. It is that **a suite which crashes reports
almost nothing, and looks quiet while doing it** — the failure count went *up*
when it was fixed, which is the correct direction.

## 4.6.0 — Rankings, records, and a feature that could never fire

### The dead title challenge

§30's "a rival may challenge the Champion" shipped in 1.39. It could never once
have run. Three rules, each defensible alone:

1. `League.mayChallengeTitle` is gated on `record.qualified`.
2. `qualified` is set only by CLEARING the Elite Four (`League.recordAttempt`).
3. `Simulation.attemptLeague` refused outright while anybody held the title.

Together they are a deadlock: the event that creates a champion is the event
that stops anybody from qualifying to face one. Nothing failed, because no test
exercised the three together — each was tested against its own intent.

The fix does not weaken rule 3, it reinterprets it. A held title changes what a
League run is FOR: with the crown vacant, clearing it takes it; with the crown
held, the run stops at the Elite Four and clearing them makes the rival a
CHALLENGER. The title changes hands only in a title match. That is also the
canon behaviour, which is a good sign — the deadlock came from modelling "the
Champion" as a stage in a list rather than as a person sitting in a chair.

**The lesson is about test shape, not about leagues.** Every rule here had a
test. What had no test was the CONJUNCTION, and a feature that is unreachable
looks exactly like a feature that is merely never triggered.

### A threshold cancelled by being met

DEVOTED requires a long shared history, and the first implementation measured
it from `bond.since`. `since` records when the CURRENT STATE began and is reset
every time the derived state moves — so the moment a bond qualified, it changed
state, which reset the clock, which disqualified it on the next read. The state
oscillated in and out and never held.

Bonds now carry `met`, written once at first contact and never moved. The
general shape is worth keeping: **a requirement must not be measured against a
value that the requirement's own satisfaction modifies.** The soak found it
because the soak asks "can the model REACH this state", which is a different
question from "does this state derive correctly" — the unit test was perfectly
happy, because it constructed the bond directly.

### Rarity as a rule, not a ratio

Christopher asked for lovers to be "a very rare outcome". The tempting test is
"DEVOTED appears in under N% of a sample", and it is a bad test: the number
moves whenever the sample does, so it gets retuned until it passes and stops
meaning anything (lesson 12 again — measure what you care about).

The rule that actually produces rarity is structural: devotion needs FAVOURS,
things one rival DID for another, and no history without them may reach it
however long it runs or how warm it gets. That is what the soak asserts, and it
is a statement about the model rather than about this week's fixture.

The same shape governs LOVERS itself: it is a PAIR state requiring both sides
to have independently arrived at DEVOTED. Rarity by conjunction, not by dice —
which matters because nothing else in the relationship model rolls for a state
either, and one exception would have made every derived state suspect.

### Deriving the record

A trainer's achievements are DERIVED on open, never logged. A logged list is a
second copy of the world: it drifts from the badge case, grows unboundedly, and
needs a write at every site that raises an event. The suite pins the difference
by removing a badge and asserting the sentence about it disappears — which a
logged list could not do.

The one number that is stored is `record.defences`, because a title defence
leaves nothing behind in the world to read it off. That is the test for
storing: not "is it convenient" but "is the fact recoverable from what remains".

## 4.7.0 — A hundred lives, and how to tell whether any of them exist

### Dead content is the failure mode of adding content

Going from sixteen life paths to a hundred and five does not crash anything.
The way it fails is quieter: a row uses the same facts as another row with
bigger numbers, scores lower everywhere, and can never be dealt to anybody. It
ships. It reads well in the data file. No player ever sees it.

So reachability is now MEASURED (tests/lifepath_reach_test.lua): forty thousand
random rivals, and the suite fails if any declared path is never offered to one
of them. That measurement found four separate things, and only one of them was
about the new rows:

- **TYPE_SPECIALIST had been dead since 2.4.** Its weights were badges 0.5 and
  fight 0.4; GYM_ASSISTANT's were badges 0.8 and fight 0.4. Strictly dominated
  on both facts, so its score was lower for every possible rival. Five releases
  of a path nobody could ever be given.
- **Three legacy lives died when the newcomers arrived** -- and not because
  their numbers changed. The commit site picks from the top THREE candidates, a
  window sized when there were sixteen paths. At a hundred and five it is a
  keyhole. The window scales with the roster now.
- **Nine of the rows I wrote were the same idea.** "A quiet job in a town",
  written nine times, competing on the same two facts and collectively burying
  the legacy MART_WORKER. The fix was not shaving coefficients until one
  squeaked through: it was making each row say what its life is actually about.
- **My first measurement asked the wrong question.** It counted paths that could
  rank FIRST. The game picks from a window, so a path ranked third is perfectly
  reachable -- the number I was reading described an experience nobody has
  (lesson 12, in its purest form). Asking "can this ever be OFFERED" moved the
  answer from 40/105 to 83/105 before a single weight changed.

### The transcription that nearly shipped

Moving sixteen career definitions into data, I typed them from what I had read
on screen. Twelve were wrong: homes dropped, `fieldwork` shares changed,
promotion thresholds moved, and -- worst -- metrics renamed, which would have
orphaned every saved progress counter in every existing save.

Nothing about the file looked wrong. The suites did not catch it, because the
suites check that a career HAS metrics, not that they are the same metrics as
yesterday. What caught it was a twenty-line script that loads both versions of
Career.lua and diffs every field of every definition.

**When you move data from one representation to another, generate it. If you
cannot generate it, diff it.** Lesson 14 was about not hand-mirroring another
mod's tables; this is the same failure pointed at my own.

### Declared facts versus derived ones

Almost everything in this mod is derived, and the house style says so loudly.
FAMILY is the exception that proves the rule: no sequence of battles makes two
rivals siblings, so it is read off the roster and stamped on the bond at every
read -- which also means a save written before a roster edit agrees with the
roster it is loaded against, rather than remembering a family that no longer
exists.

The test for storing anything remains "is the fact recoverable from what
remains". `bond.betrayals` is stored for exactly that reason: the axes decay,
so a year later there is nothing left in the numbers to distinguish a betrayal
from an ordinary falling-out -- and that distinction is the whole state.

### Titles, and why they are not saved

A title is a reading of the team a rival is carrying right now. Store it and it
outlives its subject: a Princess of Ashes whose last Fire type was traded away
hours ago, still being called that by everyone in Kanto. Derived, the name moves
when the rival does, which is what makes it a name the WORLD gives you rather
than one you picked.

The same reasoning put NORMAL on a higher dominance bar than every other type.
Normal is the default, not a choice -- a balanced team drifts past the 45%
threshold without anybody having specialised in anything, and a title handed out
by accident devalues every title that was earned.


## Team Rocket simulation (5.0.1)

Team Rocket is a separate strategic simulation designed as a dark reflection of the rival system. Its cast, leadership, strengths, careers, operations, movement, rival recruitment, Pokémon theft, promotions, failures and rare redemption outcomes are save-seeded and persisted. Rocket members begin in Celadon City and use the same map graph concept as rivals, advancing one connected map at a time rather than teleporting. Major operations such as a Safari Zone seizure become world incidents that can be surfaced by NPC dialogue, phone/news systems and rival investigations.


## Hidden backgrounds and rare special rivals (5.0.1)

Every active ordinary rival and Team Rocket member receives one of exactly 250 hidden, save-stable backgrounds. A background supplies starting money/items and small hidden dispositions toward the player, peers and Rocket. It also nudges personality behaviour and close Life Path/career decisions without replacing authored personalities or bypassing eligibility gates.

Three independently rare special rivals may appear in a save: Guts, Casca and Griffith. They use family-friendly personalities inspired by the broad character themes of *Berserk*. Guts always has the title **Black Angel**; Griffith always has **White Hawk**. When the optional Weather FX species are present, their preferred starters are Mewtwo Void, Dratini Snowcoil and Primalweather Mew respectively. If those species are absent, the normal fallback starter chain is used.
