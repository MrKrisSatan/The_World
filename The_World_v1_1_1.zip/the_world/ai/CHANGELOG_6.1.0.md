# AI Rivals 6.1.0 - Pokemon Ranger Organisation

## Ranger organisation simulation
- Rangers now persist organisational resources, command doctrine, jurisdictions, intelligence, raids and strategic state.
- Each save receives one of five Ranger command doctrines: Conservation, Enforcement, Intelligence, Community, or Mobile Response.
- Generated Rangers receive persistent service records and patrol jurisdictions.
- Ranger ranks can advance through Volunteer, Ranger, Field Ranger, Senior Ranger and Regional Commander service tiers.
- Existing generated Captains are preserved during old-save migration.

## Rocket intelligence and base raids
- Ranger patrols gather intelligence from real Rocket pressure instead of magically knowing every base.
- Hidden Rocket bases require sufficient intelligence confidence before becoming known.
- Rangers can launch resource-costed raids against confirmed Rocket bases.
- Successful raids reduce Rocket territorial control and damage base levels; non-home outposts can be dismantled completely.
- Failed raids consume resources and reduce confidence, allowing Rocket strongholds to survive and recover.
- Ranger raids and discoveries enter Ranger news and the existing World Chronicle.

## Rival Ranger careers
- Ranger-affiliated AI rivals accumulate mission service and can climb Ranger ranks.
- Team Rocket affiliates remain barred from Ranger missions.
- Ranger missions remain heavily weighted in non-Rocket rival decision-making from 5.9.x.

## Persistence
- Ranger save schema bumped to v2.
- Older Ranger saves load with safe defaults and generate the missing organisation layer deterministically.
