# AI Rivals 5.0.1

## 5.0.1 - Rare Special Rivals + Hidden Backgrounds

### Hidden Background System
- Added exactly **250** save-stable hidden backgrounds shared by ordinary AI Rivals and Team Rocket.
- Backgrounds determine starting money and starting inventory.
- Backgrounds seed a small hidden disposition toward the player, other rivals and Team Rocket.
- Backgrounds provide small personality nudges without replacing authored personalities.
- Backgrounds provide small Life Path and career biases. These influence close decisions but never bypass a Life Path gate.
- Existing saves receive a background migration without being retroactively awarded a new starting purse or inventory.

### Rare Special Rivals
Added three independently rare, save-seeded special characters inspired by the broad themes of *Berserk*, kept family-friendly:

- **Guts**
  - Rare occurrence.
  - Personality: BLACK ANGEL.
  - Always titled **Black Angel**.
  - Potential Team Rocket admin.
  - Weather FX starter: **Mewtwo Void** when the species is present.

- **Casca**
  - Rare occurrence.
  - Personality: HAWKSWORD.
  - Strong, disciplined female trainer with competing loyalties and a strong independent will.
  - Potential Team Rocket admin.
  - Weather FX starter: **Dratini Snowcoil** when the species is present.

- **Griffith**
  - Rarest of the three.
  - Personality: WHITE HAWK.
  - Always titled **White Hawk**.
  - Strategic, charismatic and ambitious.
  - Potential Team Rocket admin.
  - Weather FX starter: **Primalweather Mew** when the species is present.

When Weather FX is absent, each special character falls back through a safe vanilla-compatible starter chain rather than becoming an empty trainer.

### Team Rocket
- Rocket members now also receive hidden 250-background profiles.
- Backgrounds determine Rocket members' starting money, starting items and hidden dispositions.
- Background disposition slightly affects recruitment pressure.
- Rare special rivals recruited by Rocket begin at **Admin** rank rather than ordinary Recruit rank.

### Compatibility
- Ordinary random rival names remain unchanged.
- Shawn remains the only ordinary rival with the HEARTBREAK_KID personality.
- Existing forced titles and derived title behaviour remain intact.
- Optional Weather FX starter species are only selected when the merged game data actually contains them.
- Existing saves retain their names, parties, money and inventory.
