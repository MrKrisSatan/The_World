# AI Rivals 6.9.0 - Rival Wars

- Rivals can form persistent alliances from the existing relationship model.
- Joining Team Rocket can break an alliance and create a remembered betrayal.
- Betrayed, hostile and nemesis rivals can launch revenge hunts and travel after one another.
- Friendly rivals can respond to recent Rocket conflicts and travel to defend an ally.
- Successful defenses strengthen both rivals' relationships; failed defenses become memories.
- Rival Wars state is persisted and remains backwards-compatible with 6.8 saves.
- All new behaviour is generation-neutral and uses the shared simulation layer for Red, Blue, Yellow and Gold.
