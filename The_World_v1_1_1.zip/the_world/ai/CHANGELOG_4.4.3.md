# AI Rivals 4.4.3

- Renamed Pokégear MAP to WEATHER TRACKER.
- Added Pokégear Radio > CUSTOM MUSIC.
- Users can place OGG/MP3/WAV/FLAC files in `custom_music/`, create playlist subfolders, select a folder in-game, browse tracks, play/loop a track, rescan, and stop playback.
- Selected custom-music folder and track are persisted safely.
- Missing folders/files fail softly instead of breaking Pokégear.
- The implementation stays inside Gen1Recomp's API-2 mod sandbox; it does not attempt arbitrary host filesystem access.
