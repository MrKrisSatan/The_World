# AI Rivals 4.4.2

- Fixed player-initiated Pokégear calls being rejected by the incoming-call scheduler.
- `CALL RIVAL` and trainer rematch calls no longer use `Comms.mayCall()`, because the Pokégear menu itself marks the world busy.
- Outgoing calls still write normal call history/cooldown timestamps through `Comms.record()`, preserving inbound-call pacing.
- Existing Red/Blue/Yellow/Gold, tournaments, affection, Weather FX, and sprite replacement compatibility are unchanged.
