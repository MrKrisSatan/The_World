# AI Rivals 7.3.4

- Fixed the Gold rival interaction menu failing to open after dialogue.
- `M:getOverworld()` now resolves Gold's persistent `game.world` instead of
  assuming the Gen 1 stack-based `game.overworld`.
- Deferred UI handoffs can now see Gold become idle after its native textbox
  closes, allowing `pendingRivalMenu` to open normally.
- Gold idle checks now understand `World.textbox`, `World.choicebox`, and
  `World.mapSetup`.
- Red, Blue and Yellow retain their stack-based overworld behaviour.
