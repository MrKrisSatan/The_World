# AI Rivals 4.5.2

- Fixed updater/version loop: packaged manifest now reports 4.5.2 rather than stale 4.5.0.
- Rival Pokégear calls now expose a working CHALLENGE action; availability is checked without falsely requiring the overworld battle runner while the Pokégear is open, then battle launch is staged after the menus close.
- Added `TOURNAMENT HERE` / “Arrange Tournament At My Location” flow from rival calls.
- Player tournaments now require 3–100 rivals, capped by eligible rivals actually present in that save.
- Tournament venue is captured from the player's current map.
- Player tournament battles award 2x EXP.
- Winning a player tournament awards one available rare item from the rare-prize pool.
- Player-created tournaments are limited to one per local calendar day and the used-day marker is persisted to prevent save/reload farming.
- Existing autonomous rival-vs-rival tournaments remain independent of the player's daily tournament limit.
