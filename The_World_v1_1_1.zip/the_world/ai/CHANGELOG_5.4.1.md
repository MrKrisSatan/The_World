# AI Rivals 5.4.1

## Dialogue
- First meetings never quote a win-loss record (no more "0-0" / "0-1").
- {RECORD} expands to "just getting started" until a real battle is fought.
- COMPETITIVE relationship lines that lean on the score are suppressed until a record exists.

## Companion doubles
- While a rival is accompanying you, **every** eligible battle becomes a double:
  - **2v2** when the opponent has a second mon (or a wild partner appears)
  - **2v1** when the opponent only has one healthy Pokémon
- Gym / Elite trainers are no longer forced to stay single just because of the protected list when a companion is active (story one-shots with noDouble / fixedFormat still stay solo).
