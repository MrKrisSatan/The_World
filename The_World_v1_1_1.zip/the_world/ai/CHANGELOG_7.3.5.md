# AI Rivals 7.3.5

- Choosing **SKIP GAUNTLET** now releases the rival simulation immediately.
- Rivals can roam, train, catch wild Pokémon, shop for Poké Balls, fight one another and battle ordinary trainers before the player receives a starter.
- Starterless players are protected from autonomous rival challenges; rivals do not wait for the player, but they also do not attempt an impossible battle against an empty party.
- Migrates older skip-gauntlet saves by clearing the obsolete persisted `worldStartPending` flag.
- Normal non-skipped gauntlet progression is unchanged.
- Applies to Red, Blue, Yellow and Gold.
