# AI Rivals 7.0.0 — Weather Operations & Shared Wonder Trade

- Added Weather Scientist NPCs to Pokémon Centers in Red, Blue, Yellow and Gold.
- Scientist quests are created only when the player talks to a scientist and Weather FX is active.
- Added Weather Field Survey missions that require live readings in the requested weather.
- Added Variant Field Study missions targeting registered Weather FX `WX_*` Pokémon.
- Team Rocket contacts can now offer weather-timed theft jobs and weather-variant procurement jobs while the player is accepted as disguised Rocket.
- Weather/Rocket missions never enter the Pokégear automatically; an NPC interaction is mandatory.
- Added a shared AI Wonder Trade API using the same merged species pool as the player Wonder Trader, including Weather FX variants.
- AI rivals retain their existing Wonder Trade behaviour; Pokémon Rangers and Team Rocket members can now use the Wonder Trader too.
- Rocket stolen Pokémon are explicitly excluded from Wonder Trade so provenance and recovery cases remain intact.
- Ranger and Rocket Wonder Trades are throttled with cooldowns to preserve team identity.
- Full Red/Blue/Yellow/Gold manifest support retained.
