# AI Rivals 7.5.4

## Trainer Class character-creation UI
- Replaced the oversized Trainer Class choice box with a true scrolling menu.
- Six classes are visible at once; UP/DOWN moves through the full class list
  and the engine's normal more-arrow indicates additional rows below.
- Selecting a class now previews it instead of committing immediately.
- The preview displays the class name, all positive traits, all negative traits,
  and then asks: `IS THIS YOUR CLASS?`
- YES records the selected class and proceeds with character creation.
- NO returns to the Trainer Class list.
- Returning from NO restores the cursor to the class that was just previewed
  and scrolls that class back into view.
- TRAINER explicitly displays that it has no positive or negative traits.
- Trait descriptions are now stored centrally in TrainerClasses so future
  classes automatically have one place for player-facing descriptions.
