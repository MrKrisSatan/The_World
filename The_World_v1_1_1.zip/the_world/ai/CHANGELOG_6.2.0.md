# AI Rivals 6.2.0 — Factions & Rocket Infiltration

- Expanded faction reputation beyond Rocket/Rangers/Gyms to researchers, breeders, collectors and local communities.
- Added ROCKET UNIFORM as a non-tossable key item.
- After the Pokemon Tower/Fuji sequence, Mr. Fuji can grant the uniform; POKE FLUTE ownership is used as the durable completion proof.
- The uniform toggles a persistent disguised state when used.
- While disguised, Team Rocket treats the player as friendly and does not ambush them.
- Talking to Rocket while disguised can explicitly offer Rocket work; only the conversation creates the quest-log entry.
- Added ROCKET BALL. While the uniform is worn it can capture an opponent Pokemon from a trainer battle, bypassing the normal trainer-owned catch restriction.
- Rocket theft improves Rocket reputation and is persisted.
- Added save migration for disguise state and expanded faction reputation.
