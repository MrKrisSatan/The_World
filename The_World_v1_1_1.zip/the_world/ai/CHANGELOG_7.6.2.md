# AI Rivals 7.6.2

## Save crash hotfix
- Removed the newly introduced nested Happiness blob from Rival serialization.
- Happiness now persists as a compact serializer-safe scalar subset.
- 7.6.0/7.6.1 nested Happiness records remain load-compatible when present.
- Emotional memory metadata is no longer allowed into persisted snapshots.
- Added per-rival serialization isolation so one malformed rival cannot abort a save.
- Added a fail-open native-save safeguard: AI Rivals state errors can no longer veto the base game's save.
- Happiness runtime behavior remains enabled.
