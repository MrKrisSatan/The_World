# AI Rivals 7.3.1

- Fixed Gold rival A-button interaction when Gen 2 runtime NPC ids differ from the stable `AIR_<rival>` object name.
- Gen2Talk now prefers the spawned object's stable mod-owned `def.name`/name before engine-owned pooled ids.
- Gold rival talk resolution now tries def name, object name, router key, runtime id, and finally the physically faced rival.
- Added Gold-facing/map wrapper fallbacks for interaction resolution.
- Does not change Red, Blue or Yellow's map-script talk path.
