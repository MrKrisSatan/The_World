# AI Rivals 7.4.1

## Connected-map crash containment

Repeated Yellow testing showed hard process exits on multiple seamless
connections (Pallet -> Route 1 and Route 1 -> Viridian) even after pre-seam
despawn and connection-buffer approaches.

7.4.1 removes runtime-AI object injection from seamless connected maps entirely.

- Maps with one or more `connections` keep Rivals, Rocket and Rangers abstract.
- Autonomous simulation, catches, battles, missions, relationships, economy,
  progression and travel continue normally.
- Physical AI actors still materialise on interiors and maps without seamless
  connections.
- Removed active connection-hook/despawn choreography from normal play.
- This policy applies equally to Red, Blue, Yellow and Gold.
- The goal is to let the engine exclusively own its seamless neighbour/NPC
  graph, including Yellow's Pikachu follower handoff and Gold's Gen 2 world.
