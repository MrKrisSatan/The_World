# Credits

AI Rivals bundles code written by other people. Every absorption below was
made with the original author's permission, given directly rather than
inferred from a licence. This file records who wrote what and under what
approval, because an absorption that leaves no trace of its origin reads as
authorship, and the shipped code says otherwise.

## Absorbed mods

### double_battles 0.5.0 — shanehudson

Repository: `shanehudson-gen1recomp-mods/double_battles`

The double-battle runtime absorbed in AI Rivals 1.19.0: targeting, turn
order, switching, the HUD, animation offsets, spread moves, trainer pairs,
the wide layout and the 3D adapter. `src/DoubleBattles.lua` is that work.
The mod's own documentation and its 0.5.0 changelog ship unaltered as
`docs/double-battles-absorbed.md` and `docs/double-battles-changelog.md`.

Used with the author's verbal permission, given to the AI Rivals author.

### wonder_trade — <AUTHOR>

Repository: `<REPO>`

The Wonder Trade attendant, pool construction and trade transaction absorbed
in AI Rivals 1.30.0 and rebuilt as an atomic transaction; `src/WonderTrade.lua`
carries it. Installing AI Rivals replaces the standalone mod, which is why
the two are declared as `conflicts` in the manifest.

Used with the author's verbal permission, given to the AI Rivals author.

## Interoperability, not absorption

These mods are detected and integrated with. None of their code is bundled
here; they are named because the integration is theirs to break or bless.

- **Dramatic Shape** / **BATTLE_ART_VOXEL_FORK** — the 3D battle surface the
  double-battle adapter poses two Pokémon on.
- **Weather FX** — weather identity and variant species, read through
  `src/Compat.lua` for the Weather Tracker and phone reports.
- **Kanto Reforged** and **HGSS_SPRITES** — species and sprite sources the
  roster and Wonder Trade pool merge in when present.
- **wild_skies** — supplies the visible bird a wild double can start against.

## The game

Pokémon is a trademark of Nintendo; the Gen 1 and Gen 2 games are
© Nintendo / Creatures Inc. / GAME FREAK inc. This is an unofficial fan mod.
It ships no ROMs and no copyrighted game content — every sprite, name and
table it uses is read at runtime out of the player's own cartridge dump.
