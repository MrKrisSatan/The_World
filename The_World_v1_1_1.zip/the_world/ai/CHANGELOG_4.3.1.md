# AI Rivals 4.3.1

- Fixed overlapping text on the AI Rivals status menu by fitting left/right content to a safe shared row width.
- Long news/location/status text is clipped before it can draw over the left label.
- Fixed API-2 ListMenu selection dispatch on the AI Rivals status/detail/performance/error screens while retaining old-build compatibility.
