# AI Rivals 5.0.8

## The crash — and the class it belonged to

`intro.gauntlet.retry: .../manager/Persistence.lua:42: attempt to index global
'Util' (a nil value)` was one symptom of a bug introduced by the 5.0.0 modular
split and shipped in three releases.

When method clusters moved out of `main.lua` into `src/manager/*.lua`, the
methods came across and the **locals they closed over did not**. An extracted
chunk gets its own scope, so every one of those names became a read of a nil
global:

| File | Nil globals it was reading |
|---|---|
| `src/manager/Persistence.lua` | `Util`, `Rival`, `Comms` |
| `src/manager/Materialize.lua` | `Util`, `Rival`, `AI` |
| `src/manager/Gauntlet.lua` | `Util`, `Rival`, `AI`, `activeRoster` |

Found by disassembling every Lua file in the mod and listing its global reads,
rather than by chasing the one line in the error. Fixed by requiring the three
modules in each file; `activeRoster` closes over `mod.save`/`mod.options` so it
cannot be required, and now travels through the same `M._ctx` seam every other
`main.lua` value already uses.

**Independent confirmation.** `tests/gen2_talk_test.lua` had been failing on a
Gold boot with `Persistence.lua:113: attempt to index global 'Comms'`. It now
passes. `tests/ai_rivals_test.lua` had been *crashing* at the same fault after
three visible failures, hiding roughly 1,600 unrun checks; it now runs to
completion.

`tests/nil_globals_static.py` is new and forbids the whole class: any file that
writes `Foo.bar` where `Foo` names a module in this mod must declare `Foo`.
Verified by reintroducing the 5.0.7 bug in a scratch tree and confirming the
suite fails **for that reason**.

## `homeMapsFor` was reading the global `M`

`main.lua`'s `homeMapsFor` sits above the manager table and read the nil global
`M` — despite a comment claiming M was declared early "so a closure is never
left holding the global `M` (which would be nil and crash the first gauntlet
resolution)". A comment describing behaviour the code lacks is worse than no
comment. The consequence was silent rather than a crash: the version-keyed arm
of every roster row's `homeMaps` was dead, so Gold rivals fell back to the
Kanto list. Fixed with a real forward declaration; the static suite pins the
ordering so the comment stays true.

## Dialogue: 11,112 rival lines and 10,150 Team Rocket lines

Twelve of the sixteen personalities had **no dialogue arms at all** and fell
through to `default`. That is why only Shawn read as alive: the Explorer, Ace,
Survivalist, Showboat, Scholar, Trader, Specialist, Mentor and the three
Berserk specials were all speaking the Challenger's four lines.

Lines are now a **cross product of two authored banks**, not a template:

- `data/voices.lua` — 16 personalities × 4 registers (DRIVE / EDGE / UP / DOWN)
  × 10 clauses. Written in the registers requested: Warhammer 40K zeal for the
  Challenger, clipped bridge efficiency for the Speedrunner, hobbit warmth for
  the Collector, a science station for the Strategist and Scholar, Ranger
  stoicism for the Survivalist, scoundrel swagger for the Showboat, and Berserk
  for Guts, Casca and Griffith. Original text throughout — the register is the
  influence, the words are this mod's.
- `data/dialogue_extra.lua` — situations, which own every `{TOKEN}`.
- `data/rocket_dialogue.lua` — situation × **rank** × **role** for Team Rocket.
- `src/ClauseMix.lua`, `src/BoxFit.lua` — the walk and the text fitter, each in
  one place so the two banks cannot disagree.

Everything authored before 5.0.8 stays at the front of its list. Nothing
generated can displace a hand-written line.

### Team Rocket

The organisation previously shared 27 strings in a local table, with rank
present only in the name prefix. A Leader running a Silph raid and a Grunt
loitering on Route 3 said the same sentence, and the Scout / Enforcer / Thief /
Smuggler / Scientist / Recruiter / Quartermaster roles that `data/rocket.lua`
has always assigned were **never once audible**.

Rank is live — `promoteDemote` moves members up and down — so the same Rocket's
voice changes over a long save. Two new contexts, `beaten` and `won`, are wired
from `battle.ended` through `Rocket:noteBattleOutcome`: a Rocket you have beaten
says so the next time you talk to them, for a bounded window.

`"Executive Marlowe: "` plus a 44-character sentence used to be concatenated raw
and the tail ran off the box. The label now takes the whole first row.

## Bugs found by measuring the new content

- **`src/ClauseMix.lua` existed because my first pairing was wrong.** Pairing
  `situation[i % ns]` with `attitude[(i * stride) % na]` looks like it wanders
  the grid and does not — both indices are periodic in `i`, so the sequence
  repeats after `lcm(ns, na)`, never `ns * na`. Every cell quietly delivered
  about a third of its cap. Nothing errored, nothing was empty, nothing
  duplicated. Only counting the output found it.
- **`newsPending = "QUALIFIED"` had no bucket.** `src/Simulation.lua` has set it
  since 1.39; `D.badgeNews` had no matching key, so a rival qualifying for the
  LEAGUE said nothing at all. It has one now.
- **The 105 career defaults from 4.7.0 were never fitted to the text box.**
  Several run to 51 columns in an 18-column box, so their tails have been
  falling off screen since 4.7.0. Rewrapped in place.
- **My own first draft made `badgeNews[1..8]` byte-identical.** Eight
  milestones, one shared bank, the tokens doing all the work. Caught by a
  duplicate-cell check and rewritten as eight per-milestone banks — the eighth
  badge no longer reads like the first.
- **`tests/rocket_static.py` had been red since 5.0.2** on a literal
  `manifest['version'] == '5.0.1'` pin at the *bottom* of the file, so none of
  its Rocket assertions had run in six releases. Repointed at the version floor
  helper the repo already ships for exactly this.

`tests/dialogue_volume_test.lua` is new: 614 checks that count what actually
materialises, fail on any empty cell, require every personality to have an arm
in every stateful bucket, require rank and role to change the Rocket voice, and
verify `ClauseMix` covers the full grid.

## Verification

- Python statics: 46 pass / 2 fail. Both failures identical to 5.0.7 (see
  below); `rocket_static.py` repaired from 5.0.7's 45/2.
- Lua suites: 36 pass / 6 fail, against 5.0.7's 34/7. `gen2_talk_test.lua`
  fixed; `dialogue_volume_test.lua` added.
- `ai_rivals_test.lua` is **flaky in both trees** (19–27 failures run to run).
  Compared the *union of failure labels* across 8 runs of each tree instead:
  **zero labels unique to 5.0.8**. Six labels appear only in 5.0.7's runs.
- `modkit validate` ok, `modkit lint` ok (no ROM-derived content),
  `modkit gen2check` 5 errors / 8 warnings — byte-identical to 5.0.7.

## Known, pre-existing, deliberately not changed

`roster_static.py`'s "the answer handler does not clamp to the roster" and the
flaky roster-count failures in `ai_rivals_test.lua` are one bug: a rolled rare
special is appended to `ROSTER`, so `#ROSTER` becomes 101 rather than 100 and
the creation menu's selectable maximum moves with a random roll the player
cannot see. `activeRoster()` then adds the special on top of the chosen count,
which its own comment says is intended, and `Persistence:save()` already
compensates. Fixing the menu ceiling is a small change; deciding whether the
selected count should include specials is a design call, so it is flagged here
rather than made silently.
