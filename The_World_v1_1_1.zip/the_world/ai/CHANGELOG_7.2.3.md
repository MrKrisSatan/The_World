# AI Rivals 7.2.3

- Gold rival starter pool now additionally includes CHIKORITA, CYNDAQUIL and TOTODILE.
- When Weather FX is installed, registered WX variants of those three Johto starters are eligible too.
- The Johto trio is Gold/Gen 2 specific and is not injected into Red, Blue or Yellow's base starter pool.
- Eevee, Clefairy and Pikachu remain universal supplemental starters.
