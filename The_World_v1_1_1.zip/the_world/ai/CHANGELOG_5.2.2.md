# AI Rivals 5.2.2

- Character-creation intro: steps wait in order after naming Blue/Gary; per-rival name / randomise / randomise-all remaining.
- Team Rocket activates only after the Pewter Gym badge and spreads slowly from Celadon.
- Rival quests: trade a species, give an item, defeat another rival, defeat a Rocket member, or accompany them (30–500 steps by affinity).
- Pokégear: always challenge when calling; arrange tournament at player location (3–100 rivals).
- Talk and call menus offer explicit **Challenge 1V1** and **Challenge 2V2**. If the rival has only one healthy Pokémon, they say \"Sorry, I only have one Pokémon with me.\"
