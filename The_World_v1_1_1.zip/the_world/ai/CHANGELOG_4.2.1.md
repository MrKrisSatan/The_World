# AI Rivals 4.2.1

- Fixed a fatal Lua parse error in `src/Pokegear.lua` caused by a duplicated module header beginning with the invalid token `ocal`.
- Kept one cross-generation Pokégear implementation and exposed it from the Start menu in Gen 1 as well as Gen 2.
- Explicitly targets Pokémon Red, Blue, Yellow, and Gold in `manifest.json`.
- Retained `gen2compat: true` for compatibility with Gold-capable Gen1Recomp builds that still honour the legacy flag.
- Added a static regression test that checks Pokégear registration and four-game manifest targeting.
