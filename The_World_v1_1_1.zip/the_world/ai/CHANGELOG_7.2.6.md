# AI Rivals 7.2.6

- Fixed the `register:ready` crash caused by referencing a nonexistent global `rival` while Gen 1/Gen 2 trainer classes were being registered.
- Trainer registration now uses generation-safe starter options before any Rival instance exists.
- Fixed the gauntlet map-enter path to use the correct loop variable (`r.personality`).
- Keeps the RivalGear rename from 7.2.5.
