# AI Rivals 5.2.0

Two of the three things asked for. The third — breeder rivals producing
Pokémon — is **not in this release**; see the end.

## Rivals spread out

Four rivals used to be four copies of one traveller with different dice: one
shared wander roll, one neighbour weighting, one idea of "done with this
route". They clumped.

`src/Travel.lua` adds four styles, derived from the personality rather than
stored or rolled:

| Style | Behaviour | Who |
|---|---|---|
| VANGUARD | pushes to the far edge of what it may reach | Speedrunner, Strategist, White Hawk, Black Angel… |
| WANDERER | detours, prefers maps nobody is on and it hasn't seen | Explorer, Showboat, Survivalist, Heartbreak Kid |
| HARVESTER | stays until it has met most of what lives there | Collector, Trader, Wide Eyed |
| GRINDER | stays and battles until the route is beneath it | Ace, Challenger, Specialist |

7 / 4 / 3 / 3 across the seventeen personalities.

**A style biases position, never pacing.** `Rival.BADGE_LEAD` and the
`playerPaceLevel` ceiling are untouched — a VANGUARD gets further down the
map, not further up the badge list. `ecology_static.py` fails if `Travel.lua`
so much as mentions a pacing symbol.

Crowding is counted over the other rivals — where they stand, and at half
weight where they're heading, because otherwise four rivals pick the same
empty route in the same tick and the spread lasts one hop. It's a weight, never
a ban: a zero would strand a rival whose only legal exit is occupied.

### The style rule had to be rewritten before shipping

My first version was four weighted sums, tuned by eye. **HARVESTER and GRINDER
came out mathematically unreachable** — VANGUARD's term dominated the range the
personalities actually occupy, so no rival could ever have had either style.
Nothing errored. It read fine in the file. It would have been invisible in play.

The rule is now comparative: each style owns one trait, and a personality takes
the style it ranks highest in *across the whole cast*. Self-calibrating, so a
personality added later re-ranks everybody instead of falling into a default.
The reachability check that caught it is in the suite.

## Areas have populations

A route's encounter table is no longer the outcome. It's the **carrying
capacity**, worked over by everything happening to the animals living there.

All eight tracked things, and every one of them measured in the suite:

- **Population size** — capacity × pressure × weather × season × migration,
  clamped between a tenth and triple capacity.
- **Species competition** — shares renormalise across the route.
- **Weather preference** — by primary type. Magikarp is commoner in rain.
- **Seasonal preference** — by primary type, from the device month. Oddish is
  commoner in summer.
- **Migration** — a pure function of (world seed, species, season). Each species
  has exactly one peak season, and in it it *concentrates on some maps and thins
  on others* — a migration that only ever adds is a bonus, not a migration.
- **Rare variants** — only a thriving population throws them up; a hunted one
  produces none.
- **Trainer hunting pressure** — the player's own encounters.
- **Rival hunting pressure** — rival catches, weighted higher, because a
  HARVESTER working a route for an hour thins it whether or not anyone watches.

**The two behaviours asked for are one equation read from either end.** Hunt
Pidgey 40 times and it drops to 43% of what it was; Rattata, which nobody
touched, rises 41% into the space left behind. Nobody did anything to the
Rattata. That's the competition term, and it's the half that's easy to claim
and easy not to actually implement, so it has its own measured check.

Map **health** scales the encounter rate, not just the mix — a swept route falls
below 0.4 and yields fewer encounters, not merely different ones. Pressure
decays on a half-life, so an abandoned route recovers, and never overshoots the
untouched baseline. A species can't be hunted to local extinction: nothing would
ever bring it back.

**Rare variants never manufacture a species.** A variant is either a Weather FX
id this boot genuinely has in `data.pokemon`, or an unusually high level of the
ordinary species. Sniffed from the data, never asked of a version.

The ecology **never draws from the engine's RNG** — a draw added to a shared
stream retroactively changes every existing save's encounter sequence. It
carries its own.

Only the events are stored, never the population: it's fully recoverable from
the static table plus the events, which is the house test. The table is bounded
— decayed rows pruned, 96 maps, 16 species each, least-pressured evicted first.

Wired through `encounter.roll` and `encounter.species`, which exist with the
same names, order and shape on **both** generations — checked in the engine
source, not assumed. `battle.catch_exp` was the obvious signal for player
catches and has no Gen 2 adapter; using it would have been a door that silently
closes on Gold.

### The two systems close the loop on each other

A HARVESTER that has hunted a route into scarcity moves on with its list
unticked — `shouldLinger` reads the live population, not the static table.

## Verification

- Python statics **49 / 0**; Lua **38 / 6** (one new suite).
- `tests/ecology_travel_test.lua` — 204 checks, all behavioural.
- `tests/ecology_static.py` — one door, bounded, derived, both generations,
  no engine RNG, no pacing contact. Verified by adding a second writer in a
  scratch tree and confirming it objects.
- `ai_rivals_test.lua` deterministic across five runs, **zero new failure
  labels** vs 5.1.0.
- One static repointed: `rankings_bonds_static.py` anchored on the literal
  wander-roll expression, which the style bias changed. Contract unchanged,
  anchor moved to the detour's own `setState`.
- `modkit` validate/lint ok, `gen2check` 5 errors / 8 warnings — unchanged.

## Not in this release: breeder rivals

Everything asked for under breeding — requesting Pokémon, breeding rare ones,
offering and gifting eggs, trading offspring, becoming known for a species, and
differing per save — is **not built**. It needs the `breeding.compatibility`
hook, an egg-production model on top of the `BREEDER` life path, and a
Pokégear conversation to carry the requests and offers; that's a release of its
own rather than something to bolt on at the end of this one.

The ecology it would sit on top of is in place, which is the right order: a
breeder known for a species should be a reason that species gets *hunted*, and
the pressure model to receive that already exists.
