# AI Rivals 5.3.0

## Fixes
- Battle banners now match renamed rival names (syncTrainerNames keeps engine trainer records aligned with display names).
- **Move to safe tile** is back on the talk interaction menu.

## Pokémon Rangers
- New neutral faction (max 10 in Kanto), gym-leader strength.
- Patrol after Pewter badge; recruit rivals; arrest Team Rocket members temporarily.
- Player can fight them, take ranger patrol quests, or ignore them; they will heal the player's party when asked.

## Clone Caller (Pokégear)
- Summon +1 / +5 / +10 rivals or remove the same amounts if lagging.
- On summon, choose **Name each** or **Randomise all names**.

## Breeding
- BREEDER life-path rivals periodically add offspring species to their boxes.

## Earlier 5.2.x
- Character-creation naming, Rocket after Pewter, rival quests, single/double challenge choice.
