# AI Rivals 6.7.0 - Rival Wars & Active Recovery

- Rivals proactively track Pokemon stolen from them by Team Rocket.
- Original owners travel toward the current Rocket holder instead of waiting for the player to find them.
- Friendly/allied rivals can join recovery attempts and travel to assist.
- Same-map recovery attempts resolve from rival party strength, badges, helpers, and Rocket strength.
- Successful recovery returns the exact persisted stolen Pokemon asset to its original rival and removes it from Rocket ownership.
- Failed rescues create persistent memories, conflict records, and later retry opportunities.
- Rivals can ask the player to recover a specific Pokemon before Rocket sells it onward.
- Recovery quests are NPC-gated: simulation creates a hidden case, but the Pokegear receives nothing until the original owner actually talks to the player.
- Rival cooperation during rescues feeds the existing relationship system.
- Rival Wars cases and history persist across saves.
- Save compatibility with 6.6.0 retained.
