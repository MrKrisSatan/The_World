# AI Rivals 7.4.6

- Blue is now a persistent Championship participant in Red/Blue/Yellow.
- An AI rival clearing the Elite Four while Blue holds the crown must defeat
  Blue's real Champion party to become Champion.
- A dethroned Blue must clear the real Elite Four again before a title rematch.
- Blue can then challenge the current AI Champion; the winner owns the crown.
- Blue's reigns, losses, qualification, cooldowns and Championship history save.
- League news reports Blue losing, qualifying for, reclaiming or failing to
  reclaim the title.
- The final vanilla Champion script remains the safe battle anchor and swaps in
  the current AI Champion's party when appropriate.
- Player title fights remain in-person and are never auto-resolved.
- Gold is unchanged because its vanilla League Champion is Lance.
