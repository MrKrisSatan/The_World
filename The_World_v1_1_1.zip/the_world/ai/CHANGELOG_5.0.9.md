# AI Rivals 5.0.9

Follow-up to 5.0.8. Everything here came out of one thread: `ai_rivals_test.lua`
had been **flaky**, and a flaky suite is not a suite. Chasing that down turned
up three real gameplay bugs and cleared the last two red static contracts.

The suite is now deterministic — ten consecutive runs, byte-identical results.
Python statics are **48 pass / 0 fail**, the first fully green run in this line.

## A hidden roll was moving the creation menu

`src/Specials.lua` appends a rare Berserk character (Guts, Casca, Griffith) onto
`ROSTER` when the world seed rolls one. `#ROSTER` is therefore 100 on most saves
and 101–103 on the rest — and every site that used `#ROSTER` to mean *"how many
rivals can the player choose"* moved with a roll the player never sees.

The creation menu's **ALL** option read 101 on roughly one save in ten, and the
clamp ceiling let a 101 through.

`src/RosterPolicy.lua` now carries the vocabulary for the distinction —
`isOrdinary`, `ordinary`, `ordinaryCount` — and the three selection sites read
it. Selection also walks the ordinary list rather than `roster[1..count]`, so an
inserted special can never silently consume a selection slot.

**Specials joining the world on top of the chosen count is left exactly as
designed.** That is deliberate, documented in `activeRoster`, and already
compensated for in `Persistence:save`. Only the menu is changed.

## A rare special could open the game holding MEWTWO

The intro gauntlet order was built from the live rival list, specials included.
About one save in ten opened with a Lv5 starter queued against Guts in Oak's
lab.

Both order-building sites now filter to ordinary rivals. The special still joins
the world — that is the whole point of the layer — it simply does not stand in
the opening queue. Same reasoning as 3.3.0's *"the gauntlet is capped, the world
is not."*

This was also the last source of nondeterminism in the suite: the extra rival
made five checks run or not run depending on the roll.

## A rival's gift was not reproducible

`Rival:pickGiftItem` built its candidate list with `pairs()` over the inventory
and then indexed that list with the rival's deterministic RNG. Table order is
not stable across processes, so **the same save could hand over a different item
on different runs** — the one thing this mod's RNG exists to rule out.
`table.sort(choices)` before the draw.

The test that caught it was itself wrong: it demanded `POTION` specifically,
which assumed an empty bag, and bags have not been empty since backgrounds began
seeding a starting inventory. It now checks the invariants that matter — the
gift comes from the bag, leaves it, and two identically seeded rivals gift the
same item.

## Every hand-written line now fits the text box

5.0.8 rewrapped the 4.7.0 career formula. 5.0.9 reflows **everything** written
before 5.0.8: 65 lines overflowed, from continuation rows a couple of columns
past 18 up to the career formula's 51 in an 18-column box.

The words are unchanged — only the break positions move, and the pass is
idempotent, so a line that already fits comes back untouched. It runs before
anything is generated, so the career seeds are already fitted when they are
reused. `tests/dialogue_volume_test.lua` now fails if any row in the bank,
generated or hand-written, exceeds the envelope.

## Static contracts that had been red on correct code

Two suites were restating implementations rather than reading the modules'
vocabulary (lesson 19), so they failed on code that was right:

- `roster_static.py` searched for an inline `math.min(#ROSTER, math.floor(...))`
  expression that stopped existing when the handler was refactored to delegate
  to `RosterPolicy`. Red for several releases. It now asserts the rule.
- `modular_main_static.py` and `roster_100_static.py` anchored on argument text
  I changed here; repointed at the delegation and the default, which are the
  contracts they exist to protect.

`roster_static.py` also gained checks for the two new invariants — specials stay
out of the gauntlet, and `pickGiftItem` sorts before drawing. Verified by
reintroducing each bug in a scratch tree and confirming the suite fails **for
that reason**.

## Verification

| | 5.0.7 | 5.0.8 | 5.0.9 |
|---|---|---|---|
| Python statics | 45 / 2 | 46 / 2 | **48 / 0** |
| Lua suites | 34 / 7 | 36 / 6 | 36 / 6 |
| `ai_rivals_test` | crashed, then flaky | flaky 19–27 | **deterministic, 19** |

- Eight failure labels cleared since 5.0.7; **zero new labels** across the whole
  line.
- `modkit validate` ok, `lint` ok, `gen2check` 5 errors / 8 warnings —
  byte-identical to 5.0.7.
- Dialogue unchanged in volume: 11,112 rival lines, 10,150 Team Rocket lines,
  616 checks passing.

## Still open

The five remaining Lua suite failures (`presence_soak`, `relationship_soak`,
`rival_team`, `story_soak`, `tournaments_titles`) predate 5.0.7 and error out
rather than reporting check failures — they need a look at the harness, not at
the features. The 19 remaining failures inside `ai_rivals_test.lua` are all
pre-5.0.7 and now stable enough to work through one at a time, which was not
true a release ago.
