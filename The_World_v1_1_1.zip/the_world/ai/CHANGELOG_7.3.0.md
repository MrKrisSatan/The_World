# AI Rivals 7.3.0

- Reworked Team Rocket/Ranger trainer registration for Gold's frozen content registry.
- Predeclares 13 Rocket and 10 Ranger trainer slots during normal trainer-content registration, before the registry freezes.
- Save-seeded Rocket/Ranger members now bind their names and parties into existing slots after load instead of registering new trainer classes.
- Removed all post-load `mod.content.trainers:register` calls from Rocket and Rangers.
- Preserves proper Gen 1 and Gen 2 trainer schemas.
- Prevents `trainers content is frozen after load` errors.
