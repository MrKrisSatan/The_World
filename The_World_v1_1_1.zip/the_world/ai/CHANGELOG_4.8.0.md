# AI Rivals 4.8.0

## Team Rocket: the dark reflection

- Added an independent save-seeded Team Rocket simulation.
- Each save generates different Rocket leaders, recruits, strengths, roles, backgrounds, goals, operations, travel destinations, successes and failures.
- Rocket recruits begin in Celadon City.
- Each recruit receives one random Pokémon from the requested Rocket starter pool.
- Rocket members travel through the live MapGraph one map edge at a time. They never teleport directly to an operation.
- Added recruit, steal Pokémon, smuggling, trainer shakedown, hideout, propaganda, Silph raid and Safari Zone seizure operations.
- Added promotion and demotion logic.
- Added rare Rocket redemption state.
- Rivals can be recruited by Rocket in one save and oppose Rocket in another.
- Rocket can attempt to steal a live Pokémon from a rival party.
- Major Rocket incidents are recorded in persistent world news.
- Added random player ambushes using the existing trainer battle seam.
- Added persistent Rocket save state and deterministic RNG continuation.
- Added dynamic Rocket trainer registration and live battle parties.

## Compatibility

- Existing rival saves remain valid.
- Rocket state is absent on pre-4.8.0 saves and is generated on first load.
- The existing 4.7.1 rival name pools remain unchanged.
