# AI Rivals 4.5.1 - progression/blackout/appearance hotfix

- Rivals now purchase a small early-route Poké Ball stock with their own money when released from Oak's Lab, including scatter starts that bypass Viridian Mart.
- Healthy rivals can restock balls while passing through towns/Poké Centers; shopping is no longer accidentally gated behind the HEALING state.
- Before the first badge, rivals will not attempt the first Gym with fewer than three Pokémon and under-sized teams use a stronger (still encounter- and ball-gated) catch attempt rate.
- Defeat by the player now faints the rival's persistent party and blacks them out to the nearest reachable Poké Center. Previously the engine battle used a defensive party copy, leaving saved HP full and preventing blackout logic from triggering.
- Rival-vs-rival skirmish and duel losers now immediately black out to the nearest Poké Center when their party is wiped. Simulated trainer losses use the same rule.
- Female (and male) rival overworld appearance now persists one logical walker id in the save. The mod still never stores or paints image/palette data, preserving compatibility with sprite replacement mods while preventing hair/appearance from flipping between compatible female sprite ids.
