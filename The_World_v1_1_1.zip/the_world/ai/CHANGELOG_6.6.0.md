# AI Rivals 6.6.0 - Rival Wars & Pokémon Recovery

- Rivals recognise their own Pokémon if the disguised player bought that exact stolen Pokémon from Team Rocket.
- Recognition creates an NPC-given recovery request; nothing is silently injected into the Pokégear by world simulation.
- The exact Pokémon can be returned to its original rival without duplication, preserving its moves/nickname/state and provenance.
- Recovery updates rival memory, relationship causes, Rocket asset status, and the World Chronicle.
- Stolen Pokémon provenance survives Rocket-to-Rocket sales and player purchases, allowing the original owner to recognise it after multiple transfers.
- Save persistence added for recognition/recovery history; 6.5 saves load with empty recovery state.
