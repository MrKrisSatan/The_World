# AI Rivals 7.5.1

## Critical loader fix
- Fixed the startup error `module 'src/BattleSim' not found`.
- `BlueChampion.lua` was incorrectly using Lua's global `require()` for
  `src/BattleSim` and `src/League`. AI Rivals is a multi-file sandboxed mod
  and its private modules must be loaded through its `mod:read`-backed `req`.
- Audited the source tree for other global `require()` calls targeting
  AI Rivals' own private modules.
- Removed a latent `mods.ai_rivals.src.RosterPolicy` global require from
  RivalGear. Engine-owned modules such as `src.ui.Screens` remain on the
  engine's normal require path.
- Trainer Classes and all 7.5.0 features are retained unchanged.
