# AI Rivals 5.9.0 - Trainer Life Paths 2.0

## Earned AI Rival Champion
- A rival who genuinely earns the Champion title can occupy the final Pokemon League encounter when the player arrives.
- The final vanilla Champion script remains the safe engine anchor, but its party is replaced by the reigning AI Champion's live team.
- Champion selection now requires League evidence (`reigns` or legacy `clears`) as well as the champion flag. A stray/debug/corrupt boolean cannot place a rival on the throne.
- The reigning Champion is anchored to Indigo Plateau in the abstract simulation while defending the title, preventing them from simultaneously wandering another route.
- Losing the title to the player, another rival, or a simulated title challenger correctly closes the reign.

## Trainer Life Paths 2.0
- `LEAGUE_CHAMPION` is now an earned life state rather than merely a pressure-selected career label.
- Winning the League/title temporarily supersedes the rival's prior life path.
- The previous life path is saved in `preChampionPath` and restored when the rival loses the crown.
- Champion transitions are written into bounded Life Path history, making the career change visible to later dialogue, Chronicle and status systems.
- Existing save records remain compatible; saves without `preChampionPath` simply fall back to the Gym Challenge after a lost title.

## Title continuity
- Rival-vs-rival title transfers now begin/end League reign records correctly.
- Player title battles now begin/end League reign records correctly.
- Champion Life Path state follows the actual crown across all supported title-transfer paths.
