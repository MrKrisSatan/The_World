# AI Rivals 5.4.2

## Team Rocket: Living-World Ecology Missions

- Added six procedural ecological Rocket mission types:
  - **Species Sweep**: capture large numbers of a species from a route.
  - **Species Poaching**: systematically exploit a local population.
  - **Drive Migration**: deliberately push a species toward another connected map.
  - **Food Source Experiment**: alter what a species feeds on, creating adaptation pressure.
  - **Habitat Strip**: damage a habitat and displace its wildlife.
  - **Breeding Site**: target a concentrated breeding population.
- Missions dynamically inspect the loaded Gen 1/Gen 2 encounter tables instead of using a hard-coded species list. Every encounter map and every species that actually exists in the loaded game can therefore become a Rocket target.
- Rocket mission selection is save-seeded and cursor-driven, giving different saves different ecological histories while systematically covering the available encounter pool.
- Added persistent species migration events. A species heavily disturbed on one map can become more abundant on a connected destination route.
- Added persistent ecological adaptation pressure tied to named food sources such as berries, honey, algae, grain, nectar, tree sap, fungi and seaweed.
- Existing Weather FX `WX_*` variants are now more likely to appear when adaptation pressure and thriving populations overlap. No impossible Pokémon IDs are invented.
- Rocket ecological incidents are logged as world news and Pokegear quests, including the affected species, location, food source and migration destination.
- Added backwards-compatible ecology persistence. 5.2.x pressure-only saves continue to load normally.
- Added static regression coverage for the new Rocket ecology system.

