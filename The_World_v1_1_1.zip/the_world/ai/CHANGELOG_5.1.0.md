# AI Rivals 5.1.0

Three requested features, and two latent bugs found while building them.

## Custom music now replaces the game's music

It didn't before. The `music.select` hook forwarded every cue straight back to
the engine, under a comment saying custom audio was *"a separate user stream"*
— so choosing a track gave you your song **and** the map theme at once.

What "replaces" actually needed:

- **Silence the engine's cue.** Every reason except `once` now returns nil.
  `once` is the jingle path (item found, badge earned, evolution fanfare) —
  those are sound effects the engine already ducks the background under, and
  swallowing them would lose feedback rather than music you chose to replace.
- **Stop what's already playing.** Returning nil prevents a *new* cue starting;
  `Music.play` bails before it touches state, so the theme running when you
  picked a track would have carried on forever.
- **Hand the map back on the way out.** Without this the world stayed silent
  until you happened to change map, which reads as "stopping the music broke
  the game."

**Bug found on the way:** the audio source is a live `love.audio` object and
can't be serialised, so a reloaded save came back with `radioEnabled = true`, a
saved track, and no sound — the setting persisted and the music didn't.
`Pokegear.ensureCustomMusic` re-opens the track from what the save says, and is
now the **one door** that opens a source, so the "start a track" and "resume
after load" paths can't disagree about looping or about a file that's since been
deleted. A missing track falls back to the game's own music and clears the
setting rather than leaving you in silence.

## One sprite per rival, by gender, kept for the save

`walkerFor` returns the *first* usable id in preference order — right for "what
should this trainer look like", wrong for a roster. Every male rival without an
authored preference resolved to `SPRITE_COOLTRAINER_M`. `data/rivals.lua` worked
around it by alternating two sprites on slot parity, which is two men instead of
one: **95 generated rivals shared four walkers between them.**

`Sprites:assignWalker` now deals each rival **one** id from its full gender pool
as a pure function of (world seed, rival id). Measured on the shipped roster:
**18 distinct walkers instead of 4**, no female sprite on a male rival or vice
versa, identical across repeated calls, and 95 of 100 rivals redressed by a
different world seed — so two saves don't look the same.

Authored identity still wins. Chris keeps looking like Blue.

**The stamp is now permanent.** `rival.appearanceSprite` already serialised, but
`spriteForRival` re-resolved it whenever `exists()` said no — which is exactly
what a Gold boot does, since the sprite table there is `data.gen2Sprites` with
different ids. A rival came back from a Gen 2 session **wearing a different
face** on the Gen 1 save that created them. The stamp now records intent; a
generation that can't draw it substitutes for display only and never writes
back.

### The latent bug underneath all of it

Both resolvers built their preference chain like this:

```lua
for _, id in ipairs({ def.overworldSprite, def.sprite, def.spriteId,
                      def.fallbackSprite }) do
```

**`ipairs` stops at the first nil.** Every roster row in this mod leaves
`overworldSprite` nil and sets `fallbackSprite`, so the constructor was
`{ nil, nil, nil, "SPRITE_BLACKBELT" }` and the loop yielded *nothing*.

`fallbackSprite` has never been read by `walkerFor` — **Guts has silently been a
Cooltrainer since the day that function was written**, not a Blackbelt. Nothing
errored, and the fallback was plausible enough to look intentional. Found only
because the new assignment path made the specials resolve visibly wrong.

## Navin — the fourth special rival

A wide-eyed innocent who wandered into the Gym Challenge by accident, in the
register of a certain 1979 comedy about a man who stumbles into a fortune and
back out of it without ever losing his good humour. Original character,
original text.

**He starts with a Ditto and nothing else** — the joke made mechanical. Ditto
has no identity of its own and becomes whatever it's standing in front of, which
is the whole of this man's character. It's also a genuinely awful starter
(Transform, no coverage, terrible stats), so he's the one special the player can
plausibly beat early, and the one whose late-game team is entirely whatever he
happened to pick up.

Deliberately **no fallback chain**. Every other special lists three species so a
missing one degrades gracefully; a fallback here would quietly hand him a real
Pokémon on any boot where DITTO is absent.

- Rarest of the four at **0.015**, and the only special with
  `rocketAdminPotential = false` — Rocket recruits ambition, and he has none.
- New `WIDE_EYED` personality: highest `catchChance` in the file and the lowest
  `trainRate`, because he accumulates without improving; a huge `wanderChance`
  because he has no plan; `gymConfidence` far below anyone else's because he
  genuinely has no idea whether he can win.
- Full voice pack (**+637 dialogue lines**, now 11,749 rival lines total). His
  DOWN register barely registers losing as a bad thing, which is the character —
  and is why he needed his own bank rather than borrowing the Collector's
  warmth, which is warm *about* something.

My first draft of his priority list had two of this project's own documented
traps in it: a `CATCH` objective that doesn't exist in `AI.Can`, and `EXPLORE`
listed second, which would have made everything after it unreachable. Both fixed
before shipping, and `tests/appearance_music_test.lua` now checks every
personality's priorities against `AI.Can`'s real vocabulary.

## Verification

- Python statics **48 pass / 0 fail**; Lua **37 pass / 6 fail** (one new suite).
- `ai_rivals_test.lua` deterministic across six runs, **zero new failure labels**
  vs 5.0.9.
- `tests/appearance_music_test.lua` — 351 checks. Both regressions verified by
  reintroducing them in scratch trees and confirming the suite fails *for that
  reason*.
- Two static suites repointed from literals to rules; both had to learn to strip
  Lua comments first, because the fix's own comment quotes the broken pattern it
  documents — lesson 3, for the eighth time.
- `modkit validate` ok, `lint` ok, `gen2check` 5 errors / 8 warnings —
  byte-identical to 5.0.7.
