# AI Rivals 7.2.2

- Added EEVEE, CLEFAIRY and PIKACHU to the universal rival starter pool.
- Registered Weather FX variants of Eevee, Clefairy and Pikachu are eligible as starters when Weather FX is installed.
- WX eligibility remains restricted to variants of valid starter base species.
- Applies consistently to Red, Blue, Yellow and Gold.
