# AI Rivals 5.6.0

## Living World Foundation

- Added a persistent World State ledger shared by Rocket, Rangers, Ecology and AI rivals.
- Routes now accumulate Rocket pressure, Ranger protection, ecological disturbance and a derived reputation.
- Added route states: CALM, PATROLLED, PROTECTED, DISTURBED and DANGEROUS.
- Added a bounded world chronicle recording major Rocket and Ranger events.
- World State is saved and restored with existing saves.
- Exposed World State through `worldView()` so future AI decisions can react to the same world conditions.
- Increased non-Rocket AI preference for Ranger anti-Rocket operations from 80% to 90% when a valid operation is available.
- Rocket-affiliated rivals remain ineligible for Ranger operations.
- Added static regression coverage for World State persistence and route reputation.

## Compatibility

- Save version bumped to 11.
- Existing saves without World State load with an empty ledger and continue normally.
