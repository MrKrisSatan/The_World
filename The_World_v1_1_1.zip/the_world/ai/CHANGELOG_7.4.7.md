# AI Rivals 7.4.7

## Catching hotfix
- Fixed Gold/Gen 2 rival catches validating species against the Gen 1 species table.
- Catching now supports both Gen 1 and Gen 2 species databases.
- Encounter decoding now supports array and keyed slot formats used by conversions.
- Rangers now make real local wild catches while patrolling, use ball stock and store overflow.
- Team Rocket now poaches real local wild Pokemon during operations, uses ball stock and stores overflow.
- Faction catches are logged and Rocket battle parties refresh after successful catches.
