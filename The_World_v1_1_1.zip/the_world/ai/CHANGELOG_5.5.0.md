# AI Rivals 5.5.0

## Pokémon Ranger Anti-Team Rocket Operations

- Added eight procedural Pokémon Ranger mission types focused on stopping Team Rocket.
- Ranger missions include poaching sweeps, species protection, convoy interception, stolen-Pokémon rescue, operation disruption, recruitment suppression, habitat defence, and last-stand patrols.
- Added the example high-pressure mission: defeat **25 Team Rocket members without leaving the affected area**.
- Ranger missions are never inserted into the Pokégear Quest Log automatically. A player must speak to a Ranger and explicitly request a mission, or receive one through an existing AI contact conversation.
- Every generated mission carries dedicated giver dialogue explaining the exact objective, location, count, and any stay-in-area requirement.
- Removed the previous automatic quest refresh behaviour that could silently populate the Quest Log. Opening the Pokégear can now only display quests that were explicitly offered and accepted/recorded.
- Rocket incident news is no longer silently converted into player quests. Team Rocket missions remain Team Rocket-only activities.
- Added a Ranger AI operation layer. Non-Rocket rivals strongly prefer participating in active Ranger anti-Rocket operations, with a 80% selection bias whenever a valid operation is available.
- Rocket-affiliated rivals are explicitly barred from Ranger operations.
- AI Ranger operations route through the real map graph, temporarily suppress a Rocket member, advance mission progress, and persist across saves.
- Added shared Ranger mission persistence and save compatibility.
- Version bumped to 5.5.0.
