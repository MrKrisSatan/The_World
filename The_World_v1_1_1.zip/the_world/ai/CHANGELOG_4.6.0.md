# AI Rivals 4.6.0 — rankings, records, and rivals who have lives of their own

Merged onto the uploaded **4.5.4** fork. That fork is a true descendant of
4.5.0 (it carries `Scout.lua`, the call conversation and its suite), so it was
taken as the base and this release re-applied on top — the opposite of the
3.5.0 upload, which was a parallel branch that would have silently reverted the
pacing work. The conflict surface was small: the fork never touched
`Relationships.lua`, `League.lua`, `Story.lua`, `LifePath.lua` or
`data/gyms.lua`, and its `Simulation.lua` changes (early-game catch floor,
blackout-to-Centre, ball restocking) are textually disjoint from these.

**One repair to the fork:** `pokegear_call_test` fails on 4.5.4. Not a
regression — 4.5.2/4.5.3 deliberately renamed the tournament row and moved the
format onto its own **Battle Mode** screen — but the suite went unrepaired, so
the fork ships a failing test. It now follows whichever shape the build offers
while still checking that the format choice reaches the manager, and it still
fails on 4.4.3, so it has not been softened into agreement. The harness needed
a real fix too: 4.5.3 gates DOUBLE on the player holding two healthy Pokémon,
read from `manager.game`, which the stub did not have — a harness too small to
reach the gate reports a pass that means nothing.

> The fork raised the tournament floor from the 2 rivals you asked for to 3.
> Kept as the fork left it, but flagging it as a change from the brief.

## TRAINER RANKINGS

New Pokégear screen. Every trainer in the save on one table, **the player among
them**, ranked by the same comparison as everybody else:

```
CHAMPION
CHRIS
1. CHRIS        CHAMPION
2. Player       7 Badges
3. MATT         6 Badges
```

The old STANDINGS screen listed the rivals and mentioned the player separately
only when they held the title, so the one question the screen exists to answer
— *am I winning?* — could not be read off it. Ordering reuses
`League.sortStandings` rather than restating it, and is deterministic: the same
world produces the same table however it is fed, so the ranking never
reshuffles under the cursor. A vacant title reports as vacant; a save with no
player facts gets no invented row, because a player with zero badges placed
below everybody is a claim and absence is not a claim.

Selecting any trainer opens their record.

## The record

```
CHRIS
Badges: 8      Elite Four: Defeated     Champion: Yes
Defences: 3    Favourite: CHARIZARD
Career: Trainer -> Champion
Rivalries: MATT (Nemesis), Player (Rivalry)
Highlights: Defeated Brock / Captured Articuno /
            Became Champion / Defended title 3 times
```

**Derived, never logged.** The obvious build is a list of achievement strings
appended as things happen — a second copy of the world that drifts from the
badge case, grows without bound, and needs a matching write at every site that
raises an event. Instead "Defeated Brock" is the badge case joined to the gym
table, the Elite Four line is the League record, the rivalries are the bonds.
The suite pins this by taking a badge away and asserting the sentence about it
goes too; a logged list would still be claiming Brock.

Notable captures come from `data/notable.lua` — data, because which Pokémon are
legendary is a fixed fact about those games, and inferring "impressive" from
base stats would invent achievements on any conversion that shifted a number.
A rookie's record says "Not yet" and lists nothing; the interesting middle case
("Reached 4") is kept, because a rival that keeps falling at Lance has a story
and "Not yet" throws it away.

## Rivals can now challenge the champion — and could never have before

§30's title challenge shipped in **1.39 and could never once have fired**.
`mayChallengeTitle` is gated on `qualified`; `qualified` is set only by clearing
the Elite Four; and `attemptLeague` refused to run at all while anybody held the
title. The event that creates a champion is precisely the event that stops
anybody from qualifying to face one. A dead feature with no failing test,
because nothing tested the two rules together.

A held title now changes what a run is *for* rather than whether it may happen:

- **Crown vacant** — clearing the League takes it, exactly as before.
- **Crown held** — the run stops at the Elite Four and clearing them makes this
  rival a **challenger**. The title only ever changes hands in a title match.
- `Simulation.tryTitleMatch` resolves rival-vs-rival bouts, records the defence
  on one side and the attempt on the other, and puts both on a long cooldown.
  A beaten challenger loses its qualification: one clear buys **one** shot,
  which is the 1500-attempt League lesson applied before it can happen again.
- A title held by the **player** is never settled by the simulation. That
  challenge is fought in person.

Measured both ways: on 4.5.4 the run is refused with *"title already held"* and
the rival never qualifies; on 4.6.0 it runs and qualifies.

## Rivalries and bonds between rivals

Five new one-sided states, each a **strict subset** of the state it refines and
tested *before* it — written the other way round the specific state is
unreachable, which is the "guard that can never be true" failure in a new
costume:

| State | Reached by |
| --- | --- |
| NEMESIS | hatred *with a history* — sustained defeat plus real grievance |
| DEVOTED | near-max affection, high regard, four favours done, respect, and time |
| PROTEGE | the junior half of a mentorship, seen from below |
| ADMIRER | respect earned from well behind |
| ESTRANGED | was close once and is not now |

Your ladder reads as you wrote it: Competition → Rivalry → Friendship →
Hatred, with the labels to match.

**LOVERS is a pair state.** Neither rival can decide it: `R.pairState` returns
it only when *both* have independently reached DEVOTED. That is what makes it
rare — a conjunction hard to satisfy twice, not a die roll; nothing in the
relationship model rolls for a state, and the static contract forbids it.
UNREQUITED names the near miss. FEUD, CLOSE_FRIENDS, ARCH_RIVALS and MENTORSHIP
fill out the rest.

**Lovers actually travel together.** A rival in a mutual LOVERS pair routes to
its partner's map (`STAY_CLOSE`), handled in `AI.evaluate` rather than added to
nine personality priority lists — and gated so that being in love never
interrupts a gym battle, a heal or a League run. A relationship the player can
only read about in a menu is not one the world contains.

**Team Rocket conflict.** §17 gates Rocket behind *grievance*, and the model
could previously only see grievance toward the **player**. A rival who has come
to hate another rival now reads as aggrieved too — the same fact at the same
weight, one more way to earn it, not a second mechanism bolted alongside.

Every new state also got dialogue. The dialogue suite reads `R.STATES` out of
the model and demands a bucket for each, so adding five states failed five
checks the moment they existed — correctly: a state a rival cannot *say*
anything about is a label in a menu, not a relationship.

## Three bugs the new suites found in this release's own code

1. `pairState` answered CLOSE_FRIENDS for a one-sided devotion, because DEVOTED
   is itself a warm state and the general test ran first — the same ordering
   rule written out at length in `R.state` and broken one function later.
2. `Achievements.record` resolved the League record into a local, then
   `highlights()` re-read the unresolved `opts.league` — so a champion silently
   reported no defences and no Elite Four clear.
3. **The devotion clock could never run.** It measured from `since`, which is
   reset every time the derived state moves — so crossing the threshold changed
   the state, which reset the clock, which dropped the bond back below the
   threshold on the next read. A requirement cancelled by being met can never
   be held. Bonds now carry `met`, written once and never moved, with a
   migration path for saves and fixtures that predate it. The soak caught it
   oscillating.

## Verification

- **77 suites.** Every pre-existing failure count is identical to the 4.5.4
  upload. New: `bonds_rankings_test` (64), `title_match_test` (29),
  `bond_spread_soak_test` (11), and `pokegear_call_test` repaired from failing
  to 96.
- 38 static contracts pass, including the new `rankings_bonds_static.py`, which
  pins the *order* of the state tests by source position rather than by prose.
- `modkit validate`: ok. `gen2check`: 24 errors / 11 warnings — byte-identical
  to the fork's error set (only line numbers move). No engine patch.
- The title suite injects a synthetic Elite Four, because the CI fixture ships
  one trainer class and `attemptLeague` correctly refuses to invent a League —
  the same shape as `double_faint_test` injecting a six-mon trainer to reach
  the promote path.
- `bond_spread_soak` reports the spread numerically rather than asserting a
  vibe, and states rarity as a **rule** — no history without favours may reach
  devotion — instead of a percentage that moves whenever the sample does.
