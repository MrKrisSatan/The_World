# AI Rivals 7.6.3

## Scrollable rival-count selection
- The `HOW MANY AI RIVALS?` character-creation menu now uses the same scrolling
  Menu widget as Trainer Class selection.
- Six choices are visible at once.
- UP/DOWN scrolls through the complete legal rival-count list supplied by
  RosterPolicy.
- Selecting a number immediately records it and continues character creation.
- The list is non-cancelable so character creation cannot be left incomplete.
