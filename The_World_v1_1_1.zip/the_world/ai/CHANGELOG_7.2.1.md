# AI Rivals 7.2.1

- Weather FX no longer adds arbitrary WX species to rival starter selection.
- Only WX variants whose base species belongs to the normal starter pool are eligible.
- Personality-based WX weighting remains active inside that restricted pool.
- The same rule applies to Red, Blue, Yellow and Gold.
