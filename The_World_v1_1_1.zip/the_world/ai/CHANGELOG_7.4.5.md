# AI Rivals 7.4.5

## Earned phone numbers
- Red/Blue/Yellow ordinary trainers no longer all behave as eventual phone contacts.
- Each ordinary trainer gets a deterministic per-save phone profile.
- Roughly 58% are willing to exchange numbers at all; the rest never offer.
- Eligible trainers may offer after the first battle or require 1-3 additional
  rematches/repeat battles first.
- The threshold is stable for that NPC in that save and cannot reroll by reloading.
- Trainer familiarity is persisted before the phone number is offered.
- Gold retains its native-style ordinary-trainer phone behaviour.

## Rival numbers
- Rivals now use a similar familiarity system rather than offering immediately
  from relationship score alone.
- Each rival normally requires 1-4 player battles before an offer becomes possible.
- Relationship/life-path affinity still influences when the offer happens.
- Every rival is guaranteed to become willing eventually: after six genuine
  player-v-rival battles, rivalry itself is enough to trigger the offer.
- Declining a rival no longer permanently prevents future offers.
- A declined rival waits for at least two further battles before asking again.
