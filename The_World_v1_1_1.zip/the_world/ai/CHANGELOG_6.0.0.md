# AI Rivals 6.0.0 — Team Rocket 2.0

## Strategic Team Rocket
- Each save now generates a Rocket leadership doctrine: Expansionist, Poacher, Recruiter, Scientific, or Covert.
- Doctrine changes operation weighting, so different saves produce different criminal strategies.
- Rocket now owns a persistent resource pool used by strategic activity.
- Successful operations build territorial influence on the affected map.
- Ranger pressure erodes Rocket influence over time.
- Territory naturally decays unless supported by a Rocket base.
- Hideout operations can establish or upgrade persistent hidden bases away from Celadon.
- Bases protect a minimum amount of local Rocket influence and become part of the world history.
- Major raids, ecology operations, recruitment and ordinary jobs now feed back into the strategic simulation.
- High-danger operations are suppressed when Rocket resources are low.
- Leader-rank members are more likely to be selected for major strategic strikes.

## Compatibility and saves
- Rocket save data is upgraded to version 3.
- Older saves receive default strategic state without discarding existing members, missions, ecology history, promotions or stolen Pokemon.
- Existing Ranger, ecology, quest-dialogue and Champion systems remain intact.
