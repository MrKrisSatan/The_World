# AI Rivals 7.4.3

## Gold Rocket Uniform
- Gold no longer receives the Rocket Uniform from Mr. Fuji.
- The uniform is now found inside the Mahogany Team Rocket Hideout.
- The mod reuses the vanilla `TEAM_ROCKET_BASE_B1F` X Accuracy item-ball slot
  at (21,12), replacing that pickup with the Rocket Uniform.
- Reusing a vanilla item ball keeps Gold's normal object visibility, event flag,
  collision and pickup lifecycle.
- Picking up the item is now enough to establish uniform ownership; old saves
  with the uniform already in inventory are repaired automatically on use.
- Red/Blue/Yellow retain the post-Pokémon-Tower Mr. Fuji route.

## Rival wild-training placement
- Static rival placement now understands real grass tiles in both generations.
- Red/Blue/Yellow use the tileset's native `grassTile`.
- Gold uses Gen 2 `COLL_TALL_GRASS` / `COLL_LONG_GRASS` permissions.
- Rivals in TRAINING, hunting, or catch-oriented states are placed in grass
  whenever the map has a safe available grass cell.
- Non-training rivals prefer non-grass walkable cells, preserving grass space
  for trainers who are visibly working wild encounters.
- Grass placement still avoids warps, connection seams, impassable cells and
  vanilla NPC positions.
- If a training map has no usable grass (for example a cave), placement safely
  falls back to another walkable encounter-area cell.
