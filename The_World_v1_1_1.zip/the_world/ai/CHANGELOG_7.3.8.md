# AI Rivals 7.3.8

- Added a targeted Red/Blue/Yellow connection-seam safety fix based on the
  supplied AYN Thor crash video.
- The video confirms the process exits on the Pallet Town -> Route 1 boundary
  before Route 1 renders, so post-map-entry spawning is not the immediate cause.
- AI Rivals now wraps Gen 1's actual `OverworldController.crossConnection`.
- Immediately before a connected-map crossing, all physical AI-owned Rival,
  Team Rocket and Ranger NPCs are removed from the current runtime object pool.
- Persistent simulation state, teams, locations, relationships and missions are
  not removed; actors rematerialise normally once the destination is settled.
- The hook is Gen 1 only. Gold keeps its separate Gen 2 connection/world path.
