# AI Rivals 7.5.0

## Trainer Classes
- Added one shared Trainer Class framework for the player, AI Rivals, Team Rocket and Pokemon Rangers.
- Character creation now includes Trainer Class selection.
- `TRAINER` has no traits and preserves the vanilla experience.
- Added Ace Trainer, Collector, Breeder, Prodigy, Lucky Trainer, Survivalist,
  Ranger, Rocket, Scientist, Gambler, Underdog, Glass Cannon, Treasure Hunter,
  Weather Chaser, Champion Aspirant, Bug Catcher and Fisher.
- Player class is persistent per save.

## Player traits
- EXP bonuses/penalties are applied through `exp.gain`.
- Catch modifiers are applied through the shared `catch.rate` hook and alter the actual ball roll.
- Damage dealt, damage received and dodge traits are applied through `battle.damage`.
- Prize-money multipliers operate on the money actually awarded by a won trainer battle.
- DV traits affect Pokemon newly added to the party/storage during a battle.
- Rare-encounter traits bias toward real local low-catch-rate species.

## AI classes
- Every Rival receives a deterministic class; personality biases the result.
- Every Rocket member receives a class from a Rocket-weighted pool.
- Every Ranger receives a class from a Ranger-weighted pool.
- Rival class changes organic catch chance, EXP and money earned.
- Rocket/Ranger catch traits modify their legitimate local wild-catching attempts.
- Rival class IDs are persisted in saves.

## Examples
- Lucky Trainer: 70% chance newly caught Pokemon receive maximum DVs, improved rare encounters/catching, reduced prize money.
- Survivalist: 10% battle dodge chance and improved catching, but reduced EXP.
- Glass Cannon: +20% damage dealt and +25% EXP, but +20% damage received.
- Collector: +25% catch rate and +70% relative rare encounter weighting, but -10% battle EXP.
