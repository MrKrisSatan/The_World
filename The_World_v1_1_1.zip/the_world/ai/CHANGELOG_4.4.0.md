# AI Rivals 4.4.0

- Added autonomous rival-only tournaments. Results and eliminations appear in World News.
- Rival phone contacts can arrange player tournaments with 2-100 rivals, capped by the active save roster.
- Tournament setup supports single and double formats. Doubles require eligible two-Pokémon teams.
- The rival detail CHALLENGE row now toggles SINGLE/DOUBLE with Left/Right when both sides can field at least two healthy Pokémon.
- Tournament bracket state persists across saves and safely resumes a pending player match after reload.
