# AI Rivals 6.8.0 — Four-Game Compatibility

- Audited the living-world, Rival Wars, Ranger and Team Rocket layers for Pokémon Red, Blue, Yellow and Gold.
- Rocket Uniform acquisition is now generation-aware. Red/Blue/Yellow still require the Poké Flute earned from the Pokémon Tower/Mr. Fuji rescue; Gold uses the player physically reaching Mr. Fuji in post-League Lavender instead of checking a Gen 1-only item.
- Mr. Fuji detection now accepts Gold Lavender map naming while remaining strict about actually talking to Fuji.
- Stolen Pokémon bought from Team Rocket are now constructed with the correct generation-specific Pokémon object. Gen 1 uses the Gen 1 Pokémon constructor; Gold uses the supported Gen 2 Mon constructor.
- Full-party stolen-Pokémon purchases now use Gold's real 14-box storage model and respect box capacity instead of creating a Gen 1-style `save.box` field.
- Preserved Red/Blue/Yellow behaviour, including Pokémon Tower gating, Rocket Balls, disguise logic, NPC-gated quests and stolen-Pokémon provenance.
- Added a four-game compatibility regression suite covering manifest support, generation detection, Mr. Fuji gates, Gold storage, Gold talk routing and generation-neutral quest provenance.
