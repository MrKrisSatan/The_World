# AI Rivals 7.3.6

- Fixed a Yellow post-gauntlet Route 1 crash path caused by rebuilding dynamic
  AI NPCs from inside the `map.entered` callback.
- Rival, Rocket and Ranger physical NPC materialisation is now deferred until
  the new overworld reaches an idle frame.
- This avoids colliding with Yellow's follower/Pikachu outdoor setup while the
  Route 1 people/object layer is still being finalised.
- Stale materialisation requests are discarded if another map transition wins
  the race.
- Simulation does not run on the exact frame the deferred runtime object layer
  is rebuilt.
- Transient materialisation requests are never persisted across saves.
- Red, Blue, Yellow and Gold all use the safer deferred handoff.
