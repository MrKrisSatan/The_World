# AI Rivals 5.8.0 - Adaptation & Local Evolution

- Added persistent **local ecotypes**: sustained environmental exposure can establish a save-specific adapted population for a species on a particular map.
- Adaptation drivers include repeated rain/wetland conditions, storms, heat, cold, fog, dust, pollution/smog, Rocket-altered food sources, and long-term displacement.
- Exposure pressure decays naturally, but once an ecotype becomes established the ecological history is persistent for that save.
- Established ecotypes receive a modest abundance advantage when their adapted condition is present, so adaptation affects encounters rather than existing only as lore.
- Ecotypes increase the chance of an existing Weather FX variant appearing. The system still never invents an invalid Pokemon species ID.
- Variant selection is now salted with the local ecotype driver, allowing two saves or two routes to favour different existing variants of the same species.
- Migrant populations can adapt to their refuge route after sustained displacement.
- Rocket food-source experiments now contribute toward diet-driven local adaptation.
- Ecology save format upgraded to version 3 with backwards-compatible loading for 5.2-5.7 ecology states.
- The ecology report now exposes established ecotypes for future Pokegear news, Ranger dialogue and World Chronicle integration.
