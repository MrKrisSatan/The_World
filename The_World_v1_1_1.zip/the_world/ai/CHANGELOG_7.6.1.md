# AI Rivals 7.6.1

- Fixed the Trainer Class introduction text rendering as `nTRAINER`.
- The prompt now reads `WHAT KIND OF TRAINER / ARE YOU?` using the game's explicit line break.
