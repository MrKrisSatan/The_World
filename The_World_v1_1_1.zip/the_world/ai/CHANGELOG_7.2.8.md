# AI Rivals 7.2.8

- Fixed Team Rocket dynamic trainer registration on Gold: Rocket classes now use the proper Gen 2 class/member schema (`index`, `trainers[]`, member `party`) instead of Gen 1 `parties`.
- Applied the same Gen 2 schema adapter to Pokémon Ranger trainer classes.
- Reserved separate deterministic dynamic class-index bands for Rocket and Rangers to avoid collisions.
- Removed a Gen 1-shaped fallback trainer registration from the rival rename refresh path on Gold.
- Retained idempotent duplicate-registration protection.
- Added a broader audit for generation-sensitive trainer registrations and earlier 7.2.x failure patterns.
