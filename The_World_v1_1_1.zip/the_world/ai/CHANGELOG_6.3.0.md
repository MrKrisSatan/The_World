# AI Rivals 6.3.0 - Double Agents & Dynamic Requests

- Adds faction trust, suspicion, evidence and belief states: UNKNOWN, TRUSTED, SUSPECTED, INVESTIGATED, EXPOSED and HUNTED.
- Rocket disguise no longer fools Team Rocket once the player is exposed.
- Rocket Ball theft creates Rocket trust and Ranger/community suspicion.
- Completing Ranger or Rocket work changes what both factions believe about the player.
- Player faction actions are recorded in every rival's existing memory log.
- Adds issuer-bound dynamic quest creation. World state may create a need, but only an NPC interaction can create the Pokégear offer.
- Ranger and Rocket offers are explicitly tagged with their faction and NPC source.
- Existing 6.2 saves remain compatible.
