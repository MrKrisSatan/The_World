# AI Rivals 4.5.0 — the Pokégear call is a conversation

## The reported bug: "CALL / REMATCH does nothing"

It was never a dead button. The row fired, `callContact` ran and the action was
staged correctly — but every word of the reply went to `manager.ticker`, and
`main.lua`'s `render.hud` hook draws the ticker **only while the overworld is
the top of the state stack**. Inside the Pokégear the player is four screens
deep, so the answer was invisible; the contact screen then closed one level and
left the player back on the phone list with nothing to show for the press. The
ticker also ages while menus are open, so it had usually expired by the time
the player got back to the map.

## What CALL does now

Choosing CALL opens a real conversation (`AIR_PokegearCall`), using the
engine's own bottom text box, so the other end of the line answers where the
player is looking.

Calling an **AI rival** offers:

- **COME HERE** — the rival routes to the player's current map, as before, and
  now says so on screen. A refusal (already accompanying you, no map) is spoken
  in the call instead of vanishing onto the ticker.
- **TOURNAMENT** — the setup screen, reached from the call as well as from the
  contact row.
- **ASK ABOUT** — pick any other rival and hear what this one actually knows
  about their team.
- **HANG UP**.

Calling an **ordinary trainer** offers REMATCH, ASK ABOUT and HANG UP. A staged
rematch cannot start while a menu owns the screen, so the call now adds a
**CLOSE MENU** row that hands the map back in one press rather than leaving the
player to guess why nothing happened.

## Tournaments

- Size runs from 2 up to 100, capped by the rivals the save can actually field
  in the chosen format; the row shows `chosen/ceiling` rather than a bare
  number.
- **A on the size row jumps through 2 / 4 / 8 / 16 / 32 / 64 / 100** (clamped to
  the ceiling and wrapping); Left/Right still trims by one for an exact count.
- **A on the FORMAT row toggles SINGLE / DOUBLE.** It previously answered only
  Left/Right, which reads as broken to anyone who presses A first — the same
  complaint this release exists to fix.
- The result is reported in the call, and a staged match now waits for
  `M:overworldIdle()` before it constructs itself. Without that gate a
  tournament arranged inside the Pokégear could start its first battle with
  four menus still stacked over the map.

## Asking about a rival's team (`src/Scout.lua`)

A new pure module decides what a caller may honestly say. Knowledge is derived
from the head-to-head record the relationship bonds already hold, never stored:

| Level | Earned by | The caller reports |
| --- | --- | --- |
| KNOWN | 3+ battles with the subject | the whole party, species and levels |
| SEEN | 1–2 battles | the lead and the ace only; the rest stays unknown |
| RUMOUR | no battles, or an ordinary trainer | badges and the area they were seen in |
| NONE | nothing to go on | says so, and reports nothing |

An ordinary trainer holds no bond record, so a trainer can never recite a
rival's party — they pass on the same public gossip the phone already carries.
"No information" means none: a badge count nobody can answer is `nil`, not 0.

## Also in this release

- `Comms.REASONS` gains `TOURNAMENT` and `SCOUT`, so calls the player placed
  appear in CALL HISTORY. The set stays closed — an unknown reason is still
  dropped rather than invented.
- A RIVAL contact now carries its `rivalId` from the moment it is offered.
  The field existed and was stamped afterwards, so one path had it and the
  other silently did not.

## Test-suite repairs (no product change)

Two suites had been asserting a mod that no longer exists, and one of them was
crashing before most of its checks ran:

- `ai_rivals_test.lua` called `Rival.firstAvailableStarter` in its pre-2.6
  shape, so every fixture rival was built with an **empty party** and the suite
  died on the first line that read `party[1]` — taking roughly a thousand
  unexecuted checks with it. It now runs: **1201/1215**.
- The roster contract still asserted four rivals, one `personality` field and a
  per-row starter chain; 4.3 shipped 100 slots, a personality pool and a dealt
  starter. Those checks now read the shipped design.
- `version_matrix_test.lua` asserted that every rival draws a different starter,
  across a 100-rival roster and a six-species pool. Dealing without replacement
  is a promise about the first `#pool` rivals; past that repeats are the only
  possible behaviour. **300 failures → 0.**
- `custom_music_radio_static.py` pinned the literal version string, which fails
  at every release and teaches whoever is releasing to edit tests until they
  pass. It asserts the version floor now, which is what `tests/_version.py`
  exists for.

### Still failing, and why (all pre-existing)

`ai_rivals_test` has 14 remaining failures, none of them regressions and none
of them reachable before this release. Four are fixture gaps — the CI fixture
carries no POTION, ANTIDOTE, REPEL or TM data, so the shopping checks cannot
pass headless. The rest are assertions written before deliberate design
changes: the level-ceiling checks predate 3.2's `OPENING_LEVEL_CAP` (a rival is
capped at 8 while the player has no party — the fixture player has none), the
interaction-menu count predates several rows being added to the rival detail
screen, and the accompanying-rival double-battle check predates the rule that a
companion must stop accompanying before it can be challenged. They are left
visible rather than edited away.

## Verification

- 72 suites run; every pre-existing failure count is byte-identical to the
  4.4.3 upload, with the two repaired suites improved as above.
- New: `tests/pokegear_call_test.lua` (95 checks, driving the real screens
  through a stub of the engine's ListMenu/stack/input semantics),
  `tests/scout_test.lua` (50 checks), `tests/pokegear_call_static.py`.
  The behavioural suite was written and run against **unmodified 4.4.3 first**,
  where CALL left an empty stack and no readable reply.
- `modkit gen2check`: 24 errors / 11 warnings, identical to the 4.4.3 upload.
  No new findings. No engine patch; everything stays inside the mod.
