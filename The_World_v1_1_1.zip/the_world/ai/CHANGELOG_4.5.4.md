# AI Rivals 4.5.4

- Fixed horizontal left/right text collision in the face-to-face rival menu.
- Reserved a wider visual gap between the action label and right-hand status instead of relying on the nominal 16-character ListMenu width.
- Shortened challenge status to 1V1 / 2V2 and companion status to JOIN / ON.
- Removed redundant right-column chevrons from TRADE and RIVAL INFO.
- Shortened POKE BALL help status to BALL.
- Preserved the compact six-row rival menu and explicit Standard/Double tournament selector.
