# AI Rivals 7.6.0

## Rival Happiness, Mood and Emotional Memory
- Every AI Rival now has persistent hidden Happiness from 0-100.
- Happiness starts from a personality-influenced baseline and slowly stabilises
  toward that baseline during uneventful periods.
- Current Mood is derived from long-term happiness but can be overridden by
  recent major events.
- Rivals keep up to 16 emotional memories describing important wins, losses,
  catches, evolutions, thefts, trades, Gym results and breaking points.

## Happy events
- Catching Pokemon increases happiness.
- Winning ordinary trainer battles increases happiness.
- Winning rival battles increases happiness.
- Gym Badges provide a major happiness increase.
- Evolutions and trades provide smaller positive changes.
- Becoming Champion provides a very large happiness increase.
- Recovering a stolen Pokemon has a dedicated major-positive hook.

## Unhappy events
- Ordinary trainer losses lower happiness.
- Rival losses lower happiness.
- Gym losses hurt more, with escalating penalties for repeated failures.
- Repeated fainting is tracked per Pokemon; repeatedly fainting the same team
  member becomes increasingly upsetting.
- Team Rocket stealing a Pokemon is a major emotional event.
- The theft penalty scales with the rival's attachment to that Pokemon, with
  beloved starters/aces capable of causing a severe happiness crash.

## Pokemon attachment
- Every owned Pokemon can build a hidden attachment score.
- Starters and aces begin with stronger attachment.
- Catching, evolving and shared progress increase attachment.
- Repeated fainting can reduce it.
- Attachment determines how devastating a theft is.

## Slumps and breaking points
- Happiness <=20 can place a rival into a Slump.
- Slumps suppress optional aggression/catch-up pressure but never grant or erase
  badges, levels, catches or route progress.
- Major low-happiness events can generate persistent Breaking Points:
  VENGEFUL, BROKEN_DREAM, TEMPTED, RANGER_CALLING, SECOND_WIND, DARK_TURN or WITHDRAWN.
- Crusader personalities remain absolutely incorruptible and respond to severe
  Rocket trauma with VENGEFUL/SECOND_WIND outcomes instead of temptation.
- Vengeful rivals can prioritise hunting Rocket.
- Tempted rivals become much more susceptible to Rocket recruitment.
- Ranger Calling dramatically increases Ranger recruitment likelihood.
- Second Wind pushes a rival back toward determined training.

## Faction integration
- Team Rocket recruitment now scales strongly with rival happiness.
  Miserable rivals are substantially easier to recruit; very happy rivals resist.
- Crusader's hard anti-Rocket veto remains absolute.
- Rangers gain a recruitment bonus for unhappy rivals and a much larger bonus
  for rivals who have developed a Ranger Calling.
- Rival-vs-Rocket skirmish wins/losses now affect happiness.

## Persistence
- Happiness, baseline, mood, memories, Pokemon attachment, streaks, fainting
  history, Breaking Points and emotional traits all persist in save data.
