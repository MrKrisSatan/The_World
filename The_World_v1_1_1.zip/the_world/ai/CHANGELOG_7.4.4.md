# AI Rivals 7.4.4

## Full rival campaign progression
- Rivals may now be up to **three badges ahead** of the player.
- Rivals may also fall up to roughly **three badges behind** before entering a
  catch-up drive that prioritises real campaign progress over leisure wandering.
- Catch-up never grants free badges, levels, Pokémon, map movement or victories.
- Every badge is still earned by physically routing to the next Gym and
  defeating the real Gym Leader party.
- During campaign travel, rivals now clear every ordinary trainer assigned to
  each map before they are allowed to leave that map for the next leg.
- Trainer victories are persistent per rival. A beaten trainer stays beaten for
  that rival and is not silently rerolled.
- Rivals still traverse the route graph one map at a time and obey their own
  badge, HM and field-move gates.
- Training continues to award EXP through simulated battles rather than level
  jumps. Catch-up rivals make additional legitimate catch attempts while
  training, spending their own Poké Balls.
- Existing systems for catches, party building, PC management, move learning,
  TM use, evolution and rival-to-rival trading remain active throughout the
  journey.
- A rival three badges behind suppresses optional exploration until it closes
  the gap, but still has to train, catch, battle trainers, travel and win Gyms.
