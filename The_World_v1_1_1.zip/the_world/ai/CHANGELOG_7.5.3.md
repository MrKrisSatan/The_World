# AI Rivals 7.5.3

## Yellow Pikachu lab-exit crash
- Fixed the remaining opening crash when leaving Oak's Lab with Pikachu.
- 7.5.2 treated "player has a Pokemon" as sufficient proof that outdoor
  AI slots were safe. In Yellow, Pikachu's first follower handoff happens
  after that point, during the lab -> Pallet Town transition.
- The first connected outdoor map load after receiving the starter is now a
  one-time quarantine visit: all AI rival map-owned slots remain off-map.
- Only after that outdoor map has fully completed `map.entered` are future
  connected-map loads allowed to populate static rival models.
- The current map is never rebuilt live when the flag changes.
- Existing loaded saves with a party already standing on an established
  connected outdoor map are marked safe immediately.
- Abstract rival simulation still begins according to the chosen gauntlet
  rules; this delay affects only physical outdoor models.
- Applies to Red, Blue, Yellow and Gold, with Yellow's Pikachu follower being
  the primary reason for the stricter lifecycle gate.
