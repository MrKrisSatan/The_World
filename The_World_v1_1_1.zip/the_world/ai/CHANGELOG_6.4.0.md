# AI Rivals 6.4.0 - Mission Chains & Rocket Black Market

- Added NPC-gated mission chains. Completing a mission may create a hidden follow-up opportunity, but it never appears in the Pokégear until the original issuer speaks to the player again.
- Ranger and Team Rocket issuers can continue multi-stage operations with persistent chain IDs and chapter history.
- Team Rocket members now sell bundles of 5 Rocket Balls while the player is wearing a trusted Rocket Uniform.
- Rocket Ball bundles cost $1000 by default, with discounts for stronger Rocket reputation/trust.
- Exposed or hunted infiltrators cannot buy from the Rocket black market merely by putting the uniform back on.
- Rocket Ball purchases are remembered by the double-agent/faction system.
- Rocket jobs now progress through actual trainer-Pokémon thefts with Rocket Balls, allowing mission chains to connect directly to the infiltration mechanic.
- Rocket shop purchase totals and spending persist in saves.
- Quest reward text now names the actual reward item instead of always saying Rare Candy.
