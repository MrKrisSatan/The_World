# AI Rivals 4.2.0

## Pokégear for Red, Blue, Yellow and Gold

- Added a Pokégear-style menu to the Start menu.
- Gen 1 Red/Blue/Yellow now expose CLOCK, PHONE, MAP and RADIO.
- The same communications UI is available on Gold so rival calling is shared across Gen 1 and Gen 2.
- Phone state is persistent and save-safe.
- Call history and missed-call state are retained by the existing Comms model.
- Rival contacts are synchronized into the common phone book.

## Kanto Trainer Phone Network

- Trainer contacts are discovered from the loaded game's own trainer/object data.
- Gym maps are excluded from the Kanto trainer network.
- Trainer numbers are deterministic and save-stable.
- After defeating an overworld trainer, the trainer can offer their number.
- Accepted trainer contacts expose CALL REMATCH and CALL HISTORY.
- Rematches use the engine's native trainer battle construction rather than scripted battle shortcuts.
- Gen 1 and Gen 2 use their respective supported battle seams.

## Rival Calls

- Calling an AI rival now creates a real travel request to the player's current map.
- The rival routes normally instead of teleporting.
- The summon request temporarily outranks ordinary travel objectives.
- Calls are blocked while the world is busy, preserving battle/cutscene safety.
- Rival calls are recorded in phone history.

## Character Selection Removal

- Removed the Choose Your Hero gender question.
- Removed player/rival sprite selection.
- Removed the injected BLUE/YELLOW appearance choice.
- Removed the bundled character-selection assets and module.
- Rival appearance now follows the rival's name, with the roster gender used only for ambiguous names.
- Male names use male vanilla trainer walkers; female names use female vanilla trainer walkers.

## Compatibility

- Works as a mod for the stock Gen1Recomp mod API rather than requiring an engine patch.
- Does not ship ROM-derived data.
