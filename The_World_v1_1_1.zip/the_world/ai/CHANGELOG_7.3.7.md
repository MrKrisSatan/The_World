# AI Rivals 7.3.7

- Strengthened the Yellow Pallet Town -> Route 1 crash fix.
- Added one central `runtimeObjectsSafe()` gate for all physical AI-NPC
  materialisation, not only the `map.entered` path.
- Rival simulation arrivals, stale-NPC repair, companion repair, Team Rocket
  spawns, Ranger spawns and startup rematerialisation now all wait until the
  overworld is settled.
- Runtime actors are not created while the player is moving through a map seam,
  while a transition/map setup is active, or while dialogue/script runners own
  the overworld.
- `Materialize:spawnFor()` itself fails closed during unsafe post-gauntlet
  transitions, preventing future callers from accidentally bypassing the gate.
- The opening gauntlet remains exempt so its own lab NPCs can function normally.
