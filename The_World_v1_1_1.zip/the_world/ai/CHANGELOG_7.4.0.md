# AI Rivals 7.4.0

- Replaced map-by-map connection hotfixing with a universal connection safety
  system for Red, Blue, Yellow and Gold.
- Every route/town/city connected-map edge now has a three-cell AI runtime
  buffer zone.
- When the player approaches a real map connection, all physical AI Rival,
  Team Rocket and Pokémon Ranger NPCs are removed before the seam is reached.
- Runtime NPC spawning remains disabled while the player is inside the buffer.
- On the destination map, actors remain suppressed until the player has moved
  clear of the arrival connection edge and the overworld is settled.
- The safeguard is driven by each map's actual `connections` table, so it
  automatically applies to all current routes, towns and cities instead of
  hardcoding Pallet Town, Route 1 or Viridian City.
- Persistent simulation state is unaffected; only physical runtime actors yield.
