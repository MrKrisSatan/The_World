# AI Rivals 4.3.0

- Every ordinary non-Gym, non-Team-Rocket NPC trainer discovered from the loaded Red/Blue/Yellow/Gold data is eligible for a Pokégear number.
- Number offers are randomized per save/contact; trainers no longer all ask automatically.
- Contact capacity raised to 200.
- Accepted ordinary trainers can call with rematch requests, gossip, AI-rival sightings/progress, and Weather FX regional weather reports.
- Added persistent 0-100 affection to every rival->player and rival->rival bond, randomly seeded per save.
- Rival number offers now use affection (after actual player interaction) instead of raw battle counters.
- Affection changes through battles, gifts, trades, cooperation, favours, snubs and life-path events.
