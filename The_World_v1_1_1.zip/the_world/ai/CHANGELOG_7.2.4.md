# AI Rivals 7.2.4

- Fixed a Lua syntax error in `main.lua` that prevented the mod from loading.
- Corrected optional phone quest method checks to use field existence checks before method calls.
- Retains the 7.2.3 Gold starter changes and Weather FX starter restrictions.
