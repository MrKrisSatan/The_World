# AI Rivals 4.2.4

- Fixed Pokégear phone-number offers reporting `COULD NOT SAVE NUMBER` after the player accepted.
- The offer screen now passes its own contact record to the accept/decline handlers instead of relying on `pendingPhoneOffer`, which is intentionally cleared as soon as the screen opens.
- Accept/decline handlers also accept a contact id and retain the old pending-slot path as a compatibility fallback.
- Preserved Red, Blue, Yellow, Gold targeting and optional Weather FX map integration.
