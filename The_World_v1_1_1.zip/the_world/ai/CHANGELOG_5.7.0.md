# AI Rivals 5.7.0 — Living Pokémon Ecology

- Displaced Pokémon can now appear on connected routes even when they were not present in the vanilla encounter table.
- Migration destinations are chosen from real neighbouring maps and weighted by habitat suitability derived from resident Pokémon types, with save-seeded variation.
- Ranger patrols now accelerate ecological recovery by reducing accumulated hunting pressure through the Ecology module.
- World State now feeds Rocket pressure, Ranger presence, disturbance and protection into encounter health and abundance.
- Heavily disturbed/Rocket-active routes have fewer wild encounters; protected routes resist some of that damage.
- Migrant populations compete for encounter share with native species instead of existing only as background bookkeeping.
- Migrant populations can participate in the existing Weather FX variant/adaptation system without inventing invalid species IDs.
- Ecology reports now expose whether a population is native or migrant and its migration pressure.
- Fixed the packaged manifest version, which still reported 5.5.0 in the 5.6.0 archive.
- Added 5.7.0 static regression coverage for migration, Ranger recovery and World State ecology wiring.
