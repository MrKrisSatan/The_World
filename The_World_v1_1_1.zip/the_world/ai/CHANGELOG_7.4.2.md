# AI Rivals 7.4.2

- Restores visible rival models on seamless routes, towns and cities using
  predeclared map-owned slots rather than live runtime NPC injection.
- Adds eight stable rival slots to every connected map definition.
- Destination slots are filled before the engine's normal `setMap` builds its
  people list.
- Uses the correct Gen 1 / Gen 2 raw-map collision helpers to choose walkable
  positions away from warps, connection edges and existing NPCs.
- Unused slots stay off-map instead of being added/removed at runtime.
- Slot assignments stay fixed for the player's entire map visit.
- Walking toward a rival cannot despawn or reroll its model.
- Static rivals are excluded from runtime NPC reconciliation/repair.
- `AIR_<rival id>` names resolve directly to the rival interaction system.
- Live runtime injection remains disabled on connected maps, preserving 7.4.1
  transition stability across Red, Blue, Yellow and Gold.
