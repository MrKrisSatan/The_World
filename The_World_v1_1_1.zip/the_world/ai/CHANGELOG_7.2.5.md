# AI Rivals 7.2.5

- Renamed AI Rivals' custom Pokégear-style interface to **RivalGear**.
- Renamed the runtime module from `src/Pokegear.lua` to `src/RivalGear.lua`.
- Renamed all AI Rivals UI screen IDs from `AIR_Pokegear*` to `AIR_RivalGear*`.
- Renamed internal menu-stack marker to `__airRivalGear`.
- Gen 2's native Pokégear remains untouched and distinct.
- RivalGear retains AI Rivals phone contacts, quests, rankings, factions, map, radio, tournaments and related mod functions.
