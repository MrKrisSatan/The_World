# AI Rivals 4.2.3

- Fixed Gen 1 Pokégear menu selection on current Gen1Recomp API 2.
- Pokégear now reads `item.value` from `ListMenu:onChoose(item, menu)` rather than comparing the item table directly to strings.
- Fixed Clock, Phone, Map, Contact/History actions, Phone Offer, and Radio selection dispatch.
- Added a scalar fallback for compatibility with older/community ListMenu callback shapes.
- Preserved Red, Blue, Yellow, Gold targeting and optional Weather FX live-map integration.
