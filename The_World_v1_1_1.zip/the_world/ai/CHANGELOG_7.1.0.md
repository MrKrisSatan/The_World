# AI Rivals 7.1.0 - Four-Game Feature Parity & Expanded Personalities

## Red / Blue / Yellow / Gold parity
- Audited the shared feature stack so core systems are loaded for all four supported games rather than selected by generation at startup.
- Added a regression contract covering Pokégear, phone/comms, Rangers, Team Rocket, factions, double-agent play, Rival Wars, ecology, quests, Weather Research, Wonder Trade, tournaments and simulation adapters.
- Re-asserted the dedicated Gold adapters for dynamic NPC talk, Gen 2 trainer battles, Gen 2 encounter tables, Gen 2 Pokémon construction and 14-box storage.
- Weather Scientist NPCs and Weather FX quest generation retain separate Gen 1 and Gold map/talk adapters while sharing one quest model.
- Rocket Uniform, Rocket Ball and stolen-Pokémon systems remain available on both generations with generation-appropriate progression/storage paths.

## Personality expansion
Added 24 original personality archetypes inspired by the requested genres/settings. They are behavioural homages rather than direct character copies and are available to the ordinary seeded rival pool in every supported game.

New archetypes: Northern Loyalist, Court Schemer, Dragon Heir, Quiet Spy, Oathbound Knight, Iron Commissar, Machine Adept, Purifier, Void Veteran, Glory Reaver, Cyber Operative, Section Chief, Heavy Operative, Ghost Hacker, Solar Idealist, Midnight Tactician, Winged Guardian, Reality Engineer, Street Merc, Netrunner, Corporate Fixer, Nomad, Rocker Rebel and Edgerunner.
