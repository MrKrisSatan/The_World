#!/usr/bin/env python3
"""AI Rivals v4.1: one owner for OverworldController.talkTo, and one door for
double-battle slot writes.

Both fixes in this version are ownership problems, and both are the kind that
come back the moment somebody adds a feature without knowing the history. A
runtime suite proves today's code works; these checks stop the SHAPE that was
wrong from being reintroduced.

  1. GOLD INTERACTION. `OverworldController.talkTo` is a single mutable engine
     field. Two independent replacements make correctness depend on install
     order and on each remembering to chain. src/Gen2Talk.lua owns it; nothing
     else may assign it.

  2. DOUBLE-BATTLE SLOTS. `__dbExecuteAction` borrows battle.enemy/enemy2 (and
     the player pair) for the duration of one action. A slot WRITE made during
     that borrow lands on the wrong body -- which is exactly how a partner
     faint used to overwrite and destroy the lead, leaving a corpse in the lead
     slot and softlocking the battle. Writes from faint paths go through
     logicalSet.

  3. NO GENERATION GUESSING. An absent dataset is not a Gen 1 dataset, and
     src.core.GameVersion is not served by the Gen 2 adapter, so it reports
     generation 1 on Gold. Neither may be used to decide what to register.
"""
import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
failures = []


def check(condition, message):
    if not condition:
        failures.append(message)


def strip_comments(source):
    """Lua line comments only. A file that DOCUMENTS a trap matches the pattern
    for the trap, and this contract is full of such prose."""
    out = []
    for line in source.splitlines():
        stripped = line.lstrip()
        out.append("" if stripped.startswith("--") else line)
    return "\n".join(out)


def read(relative):
    """A missing file is a NAMED contract failure, not a traceback. A static
    test that fails for the wrong reason is barely better than one that passes
    for the wrong reason: the reader has to be told which contract broke."""
    path = ROOT / relative
    if not path.exists():
        failures.append(f"{relative} is missing; this contract requires it")
        return ""
    return strip_comments(path.read_text(encoding="utf-8"))


gen2talk = read("src/Gen2Talk.lua")
doubles = read("src/DoubleBattles.lua")
wonder = read("src/WonderTrade.lua")
main = read("main.lua")

# --- 1. one owner of talkTo ------------------------------------------------

check("OW.talkTo = function" in gen2talk or ".talkTo = function" in gen2talk,
      "Gen2Talk must be the module that assigns OverworldController.talkTo")

for name, source in (("main.lua", main), ("WonderTrade.lua", wonder),
                     ("DoubleBattles.lua", doubles)):
    check(not re.search(r"\.talkTo\s*=", source),
          f"{name} assigns talkTo directly; register with Gen2Talk instead "
          "(two owners of one engine field is the bug this replaced)")

check("Gen2Talk.register" in wonder,
      "WonderTrade must reach the Gold attendant through the talk router")
check("Gen2Talk.register" in main,
      "main.lua must register the rival talk handler with the router")
check('"ai_rivals:rivals"' in main,
      "the rival talk handler must be registered under a stable id")

# the router must chain rather than swallow: a mod that owned the field first
# still has to run
check("local previous = OW.talkTo" in gen2talk,
      "the router must capture and chain to whatever owned talkTo before it")
check("previous(world, npc)" in gen2talk,
      "the router must actually call the previous owner on a fall-through")

# idempotent install: game.ready fires twice on a New Game
check("SENTINEL" in gen2talk and "Gen2Talk.installed" in gen2talk,
      "install must be idempotent (game.ready fires again on New Game)")

# a raising handler must not break the A button for every object on the map
handler_loop = gen2talk[gen2talk.find("for _, handler in ipairs"):]
check("pcall" in handler_loop[:600],
      "a talk handler must be called inside pcall so one bad handler cannot "
      "break interaction for the whole map")

# registration must replace, not stack
check("Gen2Talk.unregister(id)" in gen2talk,
      "register must drop an existing id before inserting, or a reload stacks "
      "duplicate handlers and one press answers twice")

# --- 2. one door for slot writes during a borrow ---------------------------

check("local function logicalSet" in doubles and "local function logicalGet" in doubles,
      "DoubleBattles must expose role-aware slot accessors")
check("self.__dbBorrow = { enemy = swapEnemy, player = swapPlayer }" in doubles,
      "__dbExecuteAction must DECLARE its borrow before calling executeAction, "
      "so a faint dispatched inside it can write through the right field")

# the restore must not be conditional on battler identity: a faint changes the
# pair, which is precisely when the restore matters and precisely when the old
# identity guard skipped it
borrow_body = doubles[doubles.find("battle.__dbExecuteAction = function"):]
borrow_body = borrow_body[:borrow_body.find("\n    end\n")]
check("self.enemy == oldEnemy2" not in borrow_body,
      "the borrow restore must not be guarded on battler identity; a partner "
      "faint changes the pair and the restore was silently skipped")
check(borrow_body.count("self.enemy, self.enemy2 = self.enemy2, self.enemy") == 2,
      "the borrow must be taken and undone by the SAME unconditional swap")

# the faint arms must not write the raw partner fields
faint_start = doubles.find("battle.onFaint = function")
faint_end = doubles.find("battle.enemyMonFainted = function")
check(faint_start != -1 and faint_end > faint_start,
      "the onFaint override is findable in DoubleBattles.lua")
faint_body = doubles[faint_start:faint_end]
check(not re.search(r"self\.enemy2\s*=\s*replacement", faint_body),
      "the enemy partner faint must assign through logicalSet, not self.enemy2 "
      "(mid-borrow that field holds the LEAD)")
check('logicalSet(self, "enemy2", replacement)' in faint_body,
      "the enemy partner replacement must go through logicalSet")
check('logicalSet(self, "player2", nil)' in faint_body,
      "the player partner faint must clear its slot through logicalSet")

# a battler that IS the logical lead must never take a partner arm, whatever
# its __dbSideSlot stamp says -- the stale stamp is what made the desync
# unrecoverable rather than merely wrong for one turn
check("local function isPartner" in doubles,
      "partner/lead resolution must be one named decision, not inline tests")
partner_fn = doubles[doubles.find("local function isPartner"):]
partner_fn = partner_fn[:partner_fn.find("\n    end\n")]
check('logicalGet(self, "enemy1") then return false' in partner_fn,
      "isPartner must rule out the logical LEAD before consulting the stamp")
check('logicalGet(self, "player1") then return false' in partner_fn,
      "isPartner must rule out the logical player lead before the stamp too")
check(faint_body.count('battler.__dbSideSlot == "enemy2"') == 0,
      "onFaint must not test the slot stamp inline; that check belongs behind "
      "the lead guard in isPartner")

# the stamp must be re-derived rather than trusted forever
check("local function resyncSlotStamps" in doubles,
      "slot stamps must be re-derived at a known boundary")
check("resyncSlotStamps(self)" in doubles[doubles.find("battle.endOfTurn = function"):],
      "stamps must be re-derived at the turn boundary so a stale one cannot "
      "survive longer than one turn")

# the replacement chain walk must be bounded: faints and switches both write
# that map, and an unbounded walk over it is a hang waiting for an ordering
chain = doubles[doubles.find("while target and self.__dbReplaced"):]
chain = chain[:400]
check("hops <" in chain and "seen[" in chain,
      "the __dbReplaced chain walk must be bounded and cycle-checked")

# --- 3. no generation guessing ---------------------------------------------

check("return nil" in wonder[wonder.find("local function gen("):wonder.find("local function gen(") + 900],
      "WonderTrade's generation resolver must answer nil when unknown, never "
      "fall back to 1")
check("GameVersion" not in wonder,
      "src.core.GameVersion is not served by the Gen 2 adapter and reports "
      "generation 1 on Gold; it must not be consulted")
check("bootKnown" in main,
      "main.lua must skip entry-chunk registration when the dataset is not up "
      "yet, rather than registering on detectGeneration(nil) == 1")

# --- report ----------------------------------------------------------------

if failures:
    print("FAIL AI Rivals v4.1 ownership contract")
    for f in failures:
        print("  - " + f)
    sys.exit(1)

print("AI Rivals v4.1: one talkTo owner, one door for double-battle slot "
      "writes, no generation guessing PASS")
