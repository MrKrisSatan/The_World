-- Standalone: lua5.1 tests/rival_team_test.lua   (from mods/ai_rivals)
--
-- The 1.34.0 identity through real Rival objects: that it changes which team
-- gets fielded, that the favourite emerges from service rather than rarity,
-- that it persists, and that a pre-1.34 save re-seeds without inventing
-- history.

local cache = {}
local function req(n)
  if cache[n] then return cache[n] end
  local f = assert(loadfile(n .. ".lua")); cache[n] = f(req, {}); return cache[n]
end
local Util, Rival, TeamPlan = req("src/Util"), req("src/Rival"), req("src/TeamPlan")
local PERS, ROSTER = req("data/personalities"), req("data/rivals")

local pass, fail = 0, 0
local function eq(a, b, m) if a == b then pass = pass + 1 else fail = fail + 1
  print(("FAIL %s (got %s want %s)"):format(m, tostring(a), tostring(b))) end end
local function ok(c, m) if c then pass = pass + 1 else fail = fail + 1; print("FAIL " .. m) end end

-- A tiny synthetic species table: one attacker, one wall, one unevolved.
local function stats(hp, atk, def, spd, spc, evo)
  return { baseStats = { hp = hp, attack = atk, defense = def, speed = spd, special = spc },
           types = { "NORMAL" }, evolutions = evo,
           learnset = {}, level1Moves = { "TACKLE" } }
end
local DATA = {
  pokemon = {
    BRUISER = stats(60, 130, 60, 100, 50),
    WALL    = stats(120, 40, 120, 30, 50),
    SPROUT  = stats(45, 49, 49, 45, 65, { { level = 16, species = "BRUISER" } }),
  },
  moves = { TACKLE = { power = 40, type = "NORMAL" }, GROWL = { power = 0, type = "NORMAL" } },
  constants = { fallbackMove = "TACKLE" },
  type_chart = { matchups = {} },
}
local ctx = { data = DATA, personalities = PERS,
              graph = { has = function() return false end },
              gyms = { order = {}, byBadge = {} } }

local function make(defIndex, style)
  local r = Rival.new(ROSTER[defIndex], ctx)
  r.ticks = 0
  r:ensureTeamPlan().style = style
  return r
end

-- 1. Identity is seeded from the personality, and the shipped four diverge.
local seeded = {}
for i = 1, #ROSTER do
  local r = Rival.new(ROSTER[i], ctx)
  ok(TeamPlan.isArchetype(r:teamStyle()), ROSTER[i].id .. " seeds a legal identity")
  seeded[r:teamStyle()] = true
end
local n = 0
for _ in pairs(seeded) do n = n + 1 end
ok(n >= 3, "the shipped roster does not start as four identical builders")

-- 2. Identity changes WHICH Pokemon get fielded, from an identical pool.
local function fieldedFirst(style)
  local r = make(1, style)
  r.party = {}
  for _, sp in ipairs({ "BRUISER", "WALL", "SPROUT" }) do
    local slot = r:addPokemon(sp, 20)
    ok(slot ~= nil, "pool member " .. sp .. " is addable")
  end
  local ordered = r:teamFor({})
  return ordered[1] and ordered[1].species
end
local offensivePick = fieldedFirst("HYPER_OFFENSIVE")
local defensivePick = fieldedFirst("DEFENSIVE")
eq(offensivePick, "BRUISER", "a hyper-offensive rival leads with the attacker")
eq(defensivePick, "WALL", "a defensive rival leads with the wall")
ok(offensivePick ~= defensivePick,
   "two identities field different teams from an identical pool")

-- 3. ...but identity does not override a real matchup. The level term still
--    dominates, so a rival never brings a hopeless team for stylistic reasons.
local r = make(1, "DEFENSIVE")
r.party = {}
r:addPokemon("WALL", 5)
local strong = r:addPokemon("BRUISER", 40)
local ordered = r:teamFor({})
eq(ordered[1].species, "BRUISER",
   "a large level gap still outranks identity preference")
ok(strong ~= nil, "the strong Pokemon was created")

-- 4. The favourite emerges from SERVICE, not from rarity.
local vet = make(2, "BALANCED")
vet.party = {}
local starter = vet:addPokemon("SPROUT", 10)
vet:markStarter(starter)
local newcomer = vet:addPokemon("BRUISER", 10)
vet:refreshAce()
eq(vet:favouriteSpecies(), "SPROUT",
   "the starter is the favourite before anything else has served")
-- the newcomer now does all the fighting for a long time
vet.party = { newcomer, starter }
for i = 1, 60 do
  vet.ticks = i * 20
  vet:creditLeadBattle(i % 2 == 0)
end
vet:refreshAce()
eq(vet:favouriteSpecies(), "BRUISER",
   "a Pokemon that has done the fighting becomes the favourite")
ok((newcomer.battles or 0) == 60, "the lead's battles are recorded")
ok((newcomer.wins or 0) == 30, "the lead's victories are recorded")
ok((starter.battles or 0) == 0, "a benched Pokemon earns no service")

-- 5. Type preference emerges from what it actually fielded.
local preferred = vet:preferredType()
eq(preferred, "NORMAL", "type credit accrues from the types actually fielded")

-- 6. Persistence: identity, type credit and service survive save/load.
local blob = vet:serialize()
local reloaded = Rival.new(ROSTER[2], ctx)
ok(reloaded:restore(blob), "a rival with an identity restores")
reloaded.ticks = vet.ticks
eq(reloaded:teamStyle(), vet:teamStyle(), "the identity survives save/load")
eq(reloaded:preferredType(), preferred, "type credit survives save/load")
eq(reloaded:favouriteSpecies(), "BRUISER", "the favourite survives save/load")
eq(reloaded.party[1].battles, 60, "per-Pokemon service survives save/load")

-- 7. A pre-1.34 save has no teamPlan key: re-seed, invent nothing.
blob.teamPlan = nil
for _, slot in ipairs(blob.party) do
  slot.battles, slot.wins, slot.since = nil, nil, nil
end
local migrated = Rival.new(ROSTER[2], ctx)
ok(migrated:restore(blob), "a pre-1.34 save record still restores")
eq(migrated:teamStyle(),
   TeamPlan.FROM_PLAN[PERS[ROSTER[2].personality].teamPlan],
   "an old save re-seeds the identity from its personality")
eq(migrated:preferredType(), nil, "an old save is given no invented type history")
eq(migrated.party[1].battles, nil, "an old save is given no invented service record")
eq(migrated.playerWins, blob.playerWins, "earlier fields are untouched by the migration")

-- 8. Bounds: nothing a long game does may grow the saved identity forever.
local hoarder = make(3, "MONO_TYPE")
for i = 1, 300 do
  hoarder.ticks = i
  TeamPlan.creditTypes(hoarder.teamPlan, { "T" .. (i % 25) }, true)
end
ok(Util.count(hoarder:serialize().teamPlan.types) <= TeamPlan.TYPE_LIMIT,
   "the saved type credit stays capped")

print(("\n%d passed, %d failed"):format(pass, fail))
os.exit(fail == 0 and 0 or 1)
