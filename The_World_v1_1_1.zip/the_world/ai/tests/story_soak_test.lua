-- Standalone: lua5.1 tests/story_soak_test.lua  (from mods/ai_rivals)
--
-- A narrator has two silent failure modes and short tests catch neither.
--
--   GOING FLAT  -- every rival settles into one chapter forever and the story
--                  stops being a story. Nothing errors; it is just boring.
--   THRASHING   -- mood or chapter flips every few ticks, so a player who
--                  talks to a rival twice gets whiplash and the news spams.
--
-- So this measures movement DIRECTLY across a long run: how many distinct
-- chapters each rival visits, and how long they hold one before moving.

local cache = {}
local function req(n)
  if cache[n] then return cache[n] end
  local f = assert(loadfile(n .. ".lua")); cache[n] = f(req, {}); return cache[n]
end
local Util, Rival, Story = req("src/Util"), req("src/Rival"), req("src/Story")
local PERS, ROSTER = req("data/personalities"), req("data/rivals")

local pass, fail = 0, 0
local function ok(c, m) if c then pass = pass + 1 else fail = fail + 1; print("FAIL " .. m) end end

local DATA = {
  pokemon = { MON = { baseStats = { hp = 60, attack = 80, defense = 60,
    speed = 70, special = 60 }, types = { "NORMAL" },
    level1Moves = { "TACKLE" }, learnset = {} } },
  moves = { TACKLE = { power = 40, type = "NORMAL" } },
  constants = { fallbackMove = "TACKLE" }, type_chart = { matchups = {} },
}
local GYMS = { order = {}, byBadge = {} }
for i = 1, 8 do GYMS.order[i] = "BADGE_" .. i end
local ctx = { data = DATA, personalities = PERS,
              graph = { has = function() return false end }, gyms = GYMS }

local rivals = {}
for i = 1, #ROSTER do
  local r = Rival.new(ROSTER[i], ctx)
  r.ticks = 0
  r.story.seeded = true
  r:addPokemon("MON", 10)
  rivals[#rivals + 1] = r
end

-- A plausible career: battles won and lost, occasional badges, occasional
-- defeats that open setbacks and are later answered.
local seen, holds, flips, newsCount = {}, {}, {}, 0
for i = 1, #rivals do seen[i], holds[i], flips[i] = {}, {}, 0 end
local lastChapter, lastAt = {}, {}

for tick = 1, 24000 do
  for i, r in ipairs(rivals) do
    r.ticks = tick
    local rate = math.max(3, math.floor(1 / (r.personality.rivalFightChance or 0.1)))
    if tick % rate == 0 then
      local won = ((tick / rate) + i) % 3 ~= 0
      r:rememberPlayerBattle({ tick = tick, rivalWon = won, location = "X" })
      r.confidence = Util.clamp((r.confidence or 1) + (won and 0.03 or -0.05), 0.5, 2.0)
      if won then r:noteVictory("player", tick) else r:noteDefeat("player", tick) end
    end
    if tick % 900 == 0 then r:noteTrained(tick) end
    if tick % 3000 == 0 then
      local badge = GYMS.order[math.min(8, math.floor(tick / 3000))]
      if badge then r.badges[badge] = true end
    end
    if tick % 4000 == 0 then
      for _ = 1, 40 do r:observeTeamEvidence("BEATEN_BADLY") end
    end
    local gained, chapter, chapterChanged, _, notable = r:advanceStory(tick)
    for _, g in ipairs(gained or {}) do
      if g.news then newsCount = newsCount + 1 end
    end
    seen[i][chapter] = true
    if chapterChanged then
      if notable then newsCount = newsCount + 1 end
      flips[i] = flips[i] + 1
      if lastAt[i] then holds[i][#holds[i] + 1] = tick - lastAt[i] end
      lastAt[i] = tick
    end
    lastChapter[i] = chapter
  end
end

local function count(t) local n = 0; for _ in pairs(t) do n = n + 1 end; return n end
for i, r in ipairs(rivals) do
  local total, shortest = 0, math.huge
  for _, h in ipairs(holds[i]) do
    total = total + h
    shortest = math.min(shortest, h)
  end
  local mean = #holds[i] > 0 and (total / #holds[i]) or 0
  print(("  %-8s chapters=%d turns=%-3d mean hold=%.0f shortest=%s final=%s/%s")
    :format(r.id, count(seen[i]), flips[i], mean,
      shortest == math.huge and "-" or tostring(shortest),
      r:chapter(), r:mood()))

  ok(count(seen[i]) >= 3, r.id .. " visits at least three chapters over a long game")
  ok(flips[i] >= 2, r.id .. "'s story does not go flat")
  ok(mean >= 30, r.id .. " holds a chapter long enough to be noticed, not whiplash")
  ok(Story.isChapter(r:chapter()) and Story.isMood(r:mood()),
     r.id .. " ends in a legal story state")
  local saved = r:serialize().story
  ok(Util.count(saved.unlocked) <= Story.milestoneCount(),
     r.id .. "'s saved milestones stay inside the fixed list")
end

-- §31: the news channel must not be swamped. Over 24000 ticks (~10 hours of
-- play) across four rivals, story news should be a handful of moments.
print(("  story news items over 24000 ticks x %d rivals: %d"):format(#rivals, newsCount))
ok(newsCount < 200, "the story does not spam the news channel")
ok(newsCount > 4, "but the story does reach the news channel at all")

print(("\n%d passed, %d failed"):format(pass, fail))
os.exit(fail == 0 and 0 or 1)
