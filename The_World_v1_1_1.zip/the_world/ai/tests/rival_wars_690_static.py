from pathlib import Path
s=Path('src/RivalWars.lua').read_text(); manifest=Path('manifest.json').read_text()
for x in ['RIVAL_ALLIANCE_FORMED','RIVAL_BETRAYED','REVENGE_RIVAL','REVENGE_HUNT','DEFEND_RIVAL_FROM_ROCKET','DEFENDED_RIVAL_FROM_ROCKET','updateSocialWars','considerBetrayal','considerAlliance']:
    assert x in s, x
assert 'version=2' in s
assert 'offerFromIssuer' not in s[s.index('function W:update(dt,world)'):s.index('function W:requestLine')]
assert '"version": "6.9.0"' in manifest
print('rival wars 6.9 static: ok')
