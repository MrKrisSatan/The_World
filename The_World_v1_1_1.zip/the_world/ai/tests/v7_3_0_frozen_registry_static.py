from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
main=(ROOT/"main.lua").read_text()
rocket=(ROOT/"src/Rocket.lua").read_text()
rangers=(ROOT/"src/Rangers.lua").read_text()
manifest=(ROOT/"manifest.json").read_text()
assert "registerFactionTrainerSlots(data)" in main
assert 'one("AIR_ROCKET_ROCKET_", i' in main
assert 'one("AIR_RANGER_", i' in main
assert "self.rocket:bindTrainerSlots()" in main
assert "self.rangers:bindTrainerSlots()" in main
assert "mod.content.trainers:register" not in rocket
assert "mod.content.trainers:register" not in rangers
assert "function Rocket:bindTrainerSlots()" in rocket
assert "function Rangers:bindTrainerSlots()" in rangers
assert '"version": "7.3.0"' in manifest
print("7.3.0 frozen-registry checks passed")
