-- ECOLOGY AND TRAVEL (5.2.0)
-- ==================================================================
-- These are behaviours, not shapes, so this suite MEASURES them. §36: a model
-- that runs without erroring and produces no visible difference ships, reads
-- well and nobody sees it. Every claim in the changelog has a number here.
--
-- Run from the MOD directory:  lua5.1 tests/ecology_travel_test.lua

local cache = {}
local function req(name)
  if cache[name] ~= nil then return cache[name] end
  local value = assert(loadfile(name .. ".lua"), "cannot load " .. name)(req, {})
  cache[name] = value
  return value
end

local failures, checks = 0, 0
local function check(ok, label)
  checks = checks + 1
  if not ok then failures = failures + 1; print("FAIL: " .. label) end
  return ok
end
local function near(a, b, tol, label)
  return check(math.abs(a - b) <= tol,
    ("%s (got %.4f, want %.4f +-%.3f)"):format(label, a, b, tol))
end

local Ecology = req("src/Ecology")
local Travel = req("src/Travel")

-- A route with one common species and two rarer ones, plus a type spread so
-- the weather and season terms have something to bite on.
local DATA = {
  encounters = {
    ROUTE_T = { slots = {
      { species = "PIDGEY", level = 4 }, { species = "PIDGEY", level = 5 },
      { species = "PIDGEY", level = 5 }, { species = "PIDGEY", level = 6 },
      { species = "RATTATA", level = 4 }, { species = "RATTATA", level = 5 },
      { species = "ODDISH", level = 5 }, { species = "MAGIKARP", level = 5 },
    } },
  },
  pokemon = {
    PIDGEY = { types = { "FLYING", "NORMAL" } },
    RATTATA = { types = { "NORMAL" } },
    ODDISH = { types = { "GRASS", "POISON" } },
    MAGIKARP = { types = { "WATER" } },
    WX_016_PIDGEY_GALE = { types = { "FLYING" } },
  },
}

local function newEco(seed)
  return Ecology.new({ seed = seed or 777 })
end

-- ------------------------------------------------------------------
-- 1. Capacity is the static table, read as shares
-- ------------------------------------------------------------------
local eco = newEco()
local cap = eco:capacity("ROUTE_T", DATA)
check(cap ~= nil, "the encounter table yields a capacity")
near(cap.PIDGEY, 0.5, 0.001, "PIDGEY holds four of eight slots")
near(cap.RATTATA, 0.25, 0.001, "RATTATA holds two")
near(cap.MAGIKARP, 0.125, 0.001, "MAGIKARP holds one")
local sum = 0
for _, v in pairs(cap) do sum = sum + v end
near(sum, 1, 0.001, "capacity shares sum to one")
check(eco:capacity("NOWHERE", DATA) == nil, "a map with no table has no capacity")

-- ------------------------------------------------------------------
-- 2. THE HEADLINE: hunting a species makes it rarer
-- ------------------------------------------------------------------
local env = { now = 0 }
local before = eco:abundance("ROUTE_T", DATA, env)
local pidgeyBefore, rattataBefore = before.PIDGEY, before.RATTATA

-- Everybody wants PIDGEY. Forty catches over the same route.
for i = 1, 40 do eco:record("ROUTE_T", "PIDGEY", "catch", i) end
local after = eco:abundance("ROUTE_T", DATA, { now = 40 })

check(after.PIDGEY < pidgeyBefore * 0.6,
  ("a heavily hunted species becomes much rarer (%.3f -> %.3f)")
    :format(pidgeyBefore, after.PIDGEY))

-- ...AND the species nobody touched flourishes, without anyone doing
-- anything to it. This is the competition term, and it is the half of the
-- request that is easy to claim and easy not to actually implement.
check(after.RATTATA > rattataBefore * 1.25,
  ("an ignored species flourishes in the space left (%.3f -> %.3f)")
    :format(rattataBefore, after.RATTATA))

local sumAfter = 0
for _, v in pairs(after) do sumAfter = sumAfter + v end
near(sumAfter, 1, 0.001, "abundance is still a share table after pressure")

-- ------------------------------------------------------------------
-- 3. Recovery: pressure decays, so a route left alone comes back
-- ------------------------------------------------------------------
local late = eco:abundance("ROUTE_T", DATA, { now = 40 + Ecology.HALF_LIFE_TICKS * 6 })
check(late.PIDGEY > after.PIDGEY * 1.5,
  ("an abandoned route recovers (%.3f -> %.3f)"):format(after.PIDGEY, late.PIDGEY))
check(late.PIDGEY <= pidgeyBefore + 0.001,
  "recovery does not overshoot the untouched baseline")

-- A species can never be wiped out. Nothing would ever bring it back.
local wipe = newEco()
for i = 1, 4000 do wipe:record("ROUTE_T", "PIDGEY", "rivalCatch", i) end
local wiped = wipe:abundance("ROUTE_T", DATA, { now = 4000 })
check(wiped.PIDGEY > 0, "a species is never hunted to local extinction")

-- ------------------------------------------------------------------
-- 4. Map health scales the encounter RATE, not just the mix
-- ------------------------------------------------------------------
local bare = newEco()
local _, healthFresh = bare:abundance("ROUTE_T", DATA, { now = 0 })
near(healthFresh, 1, 0.001, "an untouched route is at full health")
for _, species in ipairs({ "PIDGEY", "RATTATA", "ODDISH", "MAGIKARP" }) do
  for i = 1, 60 do bare:record("ROUTE_T", species, "rivalCatch", i) end
end
local _, healthBare = bare:abundance("ROUTE_T", DATA, { now = 60 })
check(healthBare < 0.4,
  ("a swept route holds far less life (health %.3f)"):format(healthBare))
check(healthBare > 0, "but is never empty")

-- ------------------------------------------------------------------
-- 5. Weather and season move different types differently
-- ------------------------------------------------------------------
local w = newEco()
local dry = w:abundance("ROUTE_T", DATA, { now = 0, weather = "SUN" })
local wet = w:abundance("ROUTE_T", DATA, { now = 0, weather = "RAIN" })
check(wet.MAGIKARP > dry.MAGIKARP, "a WATER species is commoner in rain")
check(dry.MAGIKARP < wet.MAGIKARP, "and rarer in sun")

local summer = w:abundance("ROUTE_T", DATA, { now = 0, season = "SUMMER" })
local winter = w:abundance("ROUTE_T", DATA, { now = 0, season = "WINTER" })
check(summer.ODDISH > winter.ODDISH, "a GRASS species is commoner in summer")

check(Ecology.seasonFor(1) == "WINTER", "January is winter")
check(Ecology.seasonFor(4) == "SPRING", "April is spring")
check(Ecology.seasonFor(7) == "SUMMER", "July is summer")
check(Ecology.seasonFor(10) == "AUTUMN", "October is autumn")
check(Ecology.seasonFor(nil) == nil, "an unknown month has no season (§5)")

-- ------------------------------------------------------------------
-- 6. Migration is per-save, pure, and both adds AND removes
-- ------------------------------------------------------------------
local a, b = newEco(11), newEco(9999)
local differs = false
for _, season in ipairs({ "SPRING", "SUMMER", "AUTUMN", "WINTER" }) do
  for _, species in ipairs({ "PIDGEY", "RATTATA", "ODDISH", "MAGIKARP" }) do
    if a:migration(species, "ROUTE_T", season) ~= b:migration(species, "ROUTE_T", season) then
      differs = true
    end
  end
end
check(differs, "two saves migrate species differently")

for _ = 1, 3 do
  check(a:migration("PIDGEY", "ROUTE_T", "SPRING") == a:migration("PIDGEY", "ROUTE_T", "SPRING"),
    "migration is a pure function, not a roll")
end

-- A migration that only ever adds is a bonus, not a migration. Checked across
-- the YEAR, because a species only concentrates in its own peak season -- the
-- first version of this scanned one fixed season and failed on a species
-- whose peak was elsewhere (§30: know why a check fails before changing code).
local up, down = 0, 0
for _, season in ipairs({ "SPRING", "SUMMER", "AUTUMN", "WINTER" }) do
  for i = 1, 60 do
    local m = a:migration("PIDGEY", "ROUTE_" .. i, season)
    if m > 1 then up = up + 1 elseif m < 1 then down = down + 1 end
  end
end
check(up > 0 and down > 0, "a migrating species concentrates AND thins out")
-- And it has exactly one peak season, not four.
local peaks = 0
for _, season in ipairs({ "SPRING", "SUMMER", "AUTUMN", "WINTER" }) do
  local anyUp = false
  for i = 1, 60 do
    if a:migration("PIDGEY", "ROUTE_" .. i, season) > 1 then anyUp = true end
  end
  if anyUp then peaks = peaks + 1 end
end
check(peaks == 1, ("a species has one peak season (got %d)"):format(peaks))

-- ------------------------------------------------------------------
-- 7. Rare variants come from health, never from thin air
-- ------------------------------------------------------------------
local v = newEco()
-- Suppress everything except MAGIKARP so its share climbs above capacity.
for _, species in ipairs({ "PIDGEY", "RATTATA", "ODDISH" }) do
  for i = 1, 50 do v:record("ROUTE_T", species, "rivalCatch", i) end
end
local vEnv = { now = 50 }
check(v:variantChance("ROUTE_T", "MAGIKARP", DATA, vEnv) > 0,
  "a thriving population can produce variants")
check(v:variantChance("ROUTE_T", "PIDGEY", DATA, vEnv) == 0,
  "a hunted population produces none")
check(v:variantChance("ROUTE_T", "MAGIKARP", DATA, vEnv) <= 0.12,
  "and the chance is capped")

-- NEVER MANUFACTURES A SPECIES. The id has to already be in data.pokemon.
check(Ecology.variantSpecies("PIDGEY", DATA, 1, "ROUTE_T") == "WX_016_PIDGEY_GALE",
  "a variant id this boot has is used")
check(Ecology.variantSpecies("RATTATA", DATA, 1, "ROUTE_T") == nil,
  "a species with no variant in this boot gets none")
check(Ecology.variantSpecies("PIDGEY", { pokemon = {} }, 1, "X") == nil,
  "a boot without Weather FX gets none at all")

-- ------------------------------------------------------------------
-- 8. The picker is deterministic and honours the shares
-- ------------------------------------------------------------------
local shares = { A = 0.5, B = 0.3, C = 0.2 }
check(Ecology.pickFrom(shares, 0.0) == "A", "the first share owns roll 0")
check(Ecology.pickFrom(shares, 0.99) == "C", "the last owns roll ~1")
for _ = 1, 5 do
  check(Ecology.pickFrom(shares, 0.6) == Ecology.pickFrom(shares, 0.6),
    "pickFrom is deterministic for one roll (§38)")
end
local counts = { A = 0, B = 0, C = 0 }
for i = 0, 999 do
  local id = Ecology.pickFrom(shares, i / 1000)
  counts[id] = (counts[id] or 0) + 1
end
near(counts.A / 1000, 0.5, 0.02, "A is drawn at its share")
near(counts.C / 1000, 0.2, 0.02, "C is drawn at its share")

-- ------------------------------------------------------------------
-- 9. The save stays bounded
-- ------------------------------------------------------------------
local big = newEco()
for m = 1, 400 do
  for sp = 1, 40 do
    big:record("MAP_" .. m, "SP_" .. sp, "encounter", m * 10)
  end
end
big:prune(4000)
local mapCount = 0
for mapId, rows in pairs(big.maps) do
  mapCount = mapCount + 1
  local speciesCount = 0
  for _ in pairs(rows) do speciesCount = speciesCount + 1 end
  check(speciesCount <= Ecology.MAX_SPECIES_PER_MAP,
    ("%s is within the species cap (%d)"):format(mapId, speciesCount))
end
check(mapCount <= Ecology.MAX_MAPS,
  ("the table is within the map cap (got %d)"):format(mapCount))

-- Decayed-to-nothing rows disappear entirely rather than accumulating.
local decayEco = newEco()
decayEco:record("ROUTE_T", "PIDGEY", "encounter", 0)
decayEco:prune(Ecology.HALF_LIFE_TICKS * 40)
check(decayEco.maps.ROUTE_T == nil, "a fully decayed map is pruned")

-- Round trip.
local rt = newEco()
rt:record("ROUTE_T", "PIDGEY", "catch", 10)
rt:record("ROUTE_T", "ODDISH", "rivalCatch", 12)
local blob = rt:serialize(12)
local rt2 = newEco()
rt2:load(blob)
near(rt2:pressure("ROUTE_T", "PIDGEY", 12), rt:pressure("ROUTE_T", "PIDGEY", 12),
  0.0001, "pressure survives a save/load round trip")
rt2:load(nil)
check(next(rt2.maps) == nil, "loading nothing yields nothing, not defaults (§5)")

-- Only the four named kinds may write.
local guard = newEco()
check(guard:record("ROUTE_T", "PIDGEY", "nonsense", 1) == false,
  "an unknown pressure kind is refused")
check(guard:record(nil, "PIDGEY", "catch", 1) == false, "a nil map is refused")
check(guard:record("ROUTE_T", nil, "catch", 1) == false, "a nil species is refused")

-- ------------------------------------------------------------------
-- 10. Reporting -- so the player can SEE it (§35)
-- ------------------------------------------------------------------
local rep = eco:report("ROUTE_T", DATA, { now = 40 })
check(rep ~= nil and #rep.rows > 0, "a route reports its population")
check(rep.rows[1].share >= rep.rows[#rep.rows].share, "rows are ordered by share")
check(Ecology.describe(2.0) == "THRIVING", "a doubled population reads THRIVING")
check(Ecology.describe(1.0) == "STEADY", "an untouched one reads STEADY")
check(Ecology.describe(0.2) == "SCARCE", "a hunted one reads SCARCE")

-- ------------------------------------------------------------------
-- 11. Travel styles
-- ------------------------------------------------------------------
local PERSONALITIES = req("data/personalities")
local styleCount = {}
for id, p in pairs(PERSONALITIES) do
  local style = Travel.styleOf(p)
  check(Travel.BLURB[style] ~= nil, ("%s maps to a real style (%s)"):format(id, style))
  styleCount[style] = (styleCount[style] or 0) + 1
end
-- §36 AGAIN: a style no personality can ever reach is dead content that reads
-- as a feature. This is the check that would have caught it.
for _, style in ipairs(Travel.STYLES) do
  check((styleCount[style] or 0) > 0,
    ("some personality actually reaches %s"):format(style))
end
check(Travel.styleOf(nil) == "WANDERER", "a missing personality still gets a style")

-- Deterministic, and not a roll.
for _ = 1, 4 do
  check(Travel.styleOf(PERSONALITIES.COLLECTOR) == Travel.styleOf(PERSONALITIES.COLLECTOR),
    "styleOf is pure")
end

-- The catcher catalogues, the trainer grinds, the wanderer wanders.
-- Asserted as the RULE against the real cast, not as a hand-written mapping
-- that would drift the moment a personality's numbers change (§19): whoever
-- catches the most IS the harvester, whoever wanders most IS the wanderer.
local function topBy(trait)
  local bestId, bestValue
  local ids = {}
  for id in pairs(PERSONALITIES) do ids[#ids + 1] = id end
  table.sort(ids)
  for _, id in ipairs(ids) do
    local v = tonumber(PERSONALITIES[id][trait])
    if v and (bestValue == nil or v > bestValue) then bestId, bestValue = id, v end
  end
  return bestId
end
-- NOT "the cast's highest trainRate is the grinder": WHITE_HAWK tops both
-- trainRate AND gymConfidence, so no assignment can satisfy that for all four
-- traits at once. The honest invariant is that nobody is given a style they
-- are BELOW AVERAGE at -- a grinder who trains less than most of the cast
-- would be a label, not a behaviour.
-- Nor "everybody is above median at their own style's trait": SPEEDRUNNER is
-- below the cast median on ALL FOUR traits (0.68 / 0.02 / 0.02 / 0.85 -- it is
-- the minimal personality by design), so no assignment can satisfy that
-- either. Its highest RELATIVE standing is gymConfidence, which makes it a
-- VANGUARD, and a speedrunner rushing ahead of everyone is exactly right.
--
-- What is left is what actually matters: the split is not degenerate, and the
-- obvious cases read correctly.
local biggest = 0
for _, style in ipairs(Travel.STYLES) do
  biggest = math.max(biggest, styleCount[style] or 0)
end
local castSize = 0
for _ in pairs(PERSONALITIES) do castSize = castSize + 1 end
check(biggest <= castSize * 0.6,
  ("no style swallows the cast (biggest %d of %d)"):format(biggest, castSize))
check(topBy("catchChance") ~= nil, "the cast has a highest catcher")
check(Travel.styleOf(PERSONALITIES[topBy("catchChance")]) == "HARVESTER",
  "the cast's keenest catcher catalogues routes")
check(Travel.styleOf(PERSONALITIES[topBy("wanderChance")]) == "WANDERER",
  "the cast's biggest wanderer wanders")
check(Travel.styleOf(PERSONALITIES.SPEEDRUNNER) == "VANGUARD",
  "the Speedrunner rushes ahead")
check(Travel.styleOf(PERSONALITIES.COLLECTOR) == "HARVESTER",
  "the Collector catalogues a route")
check(Travel.styleOf(PERSONALITIES.EXPLORER) == "WANDERER",
  "the Explorer wanders")

-- Wander bias changes the threshold, never the number of rolls.
check(Travel.wanderChance("WANDERER", 0.2) > Travel.wanderChance("VANGUARD", 0.2),
  "a wanderer detours more than a vanguard from the same base")
check(Travel.wanderChance("WANDERER", 0) == 0,
  "a personality that never wanders still never wanders")
check(Travel.wanderChance("WANDERER", 1) <= 0.9,
  "and the biased chance is capped below certainty")

-- ------------------------------------------------------------------
-- 12. Spreading out
-- ------------------------------------------------------------------
local rivals = {
  { id = "a", map = "ROUTE_1", destination = "ROUTE_2" },
  { id = "b", map = "ROUTE_1", destination = "ROUTE_1" },
  { id = "c", map = "ROUTE_3", destination = "ROUTE_1" },
}
local crowd = Travel.crowding(rivals, "c")
near(crowd.ROUTE_1, 2, 0.001, "two rivals standing on ROUTE_1 count as two")
near(crowd.ROUTE_2, 0.5, 0.001, "a rival heading somewhere counts half")
check(crowd.ROUTE_3 == nil, "the excluded rival does not crowd itself")

local empty = Travel.weight("WANDERER", "ROUTE_9", { crowding = crowd })
local busy = Travel.weight("WANDERER", "ROUTE_1", { crowding = crowd })
check(busy < empty, "a crowded map is less attractive than an empty one")
check(busy >= Travel.MIN_WEIGHT, "but never a ban (§6)")

local far = Travel.weight("VANGUARD", "FAR", { distanceFromPlayer = { FAR = 6, NEAR = 0 } })
local nearMap = Travel.weight("VANGUARD", "NEAR", { distanceFromPlayer = { FAR = 6, NEAR = 0 } })
check(far > nearMap, "a vanguard pushes away from the player's position")

local seen = Travel.weight("WANDERER", "OLD", { visited = { OLD = true } })
local fresh = Travel.weight("WANDERER", "NEW", { visited = { OLD = true } })
check(fresh > seen, "a wanderer prefers what it has not seen")

-- ------------------------------------------------------------------
-- 13. Staying put
-- ------------------------------------------------------------------
local sharesT = { PIDGEY = 0.5, RATTATA = 0.25, ODDISH = 0.15, MAGIKARP = 0.1 }
check(Travel.shouldLinger({ style = "HARVESTER", shares = sharesT,
  seenHere = { PIDGEY = true }, health = 1 }),
  "a harvester stays while the route is uncatalogued")
check(not Travel.shouldLinger({ style = "HARVESTER", shares = sharesT,
  seenHere = { PIDGEY = true, RATTATA = true, ODDISH = true, MAGIKARP = true },
  health = 1 }),
  "and leaves once it has met everything")

-- The two systems close the loop on each other: a harvester that has hunted
-- a route bare moves on even with the list unticked.
check(not Travel.shouldLinger({ style = "HARVESTER", shares = sharesT,
  seenHere = {}, health = 0.2 }),
  "a harvester abandons a route it has emptied")

check(Travel.shouldLinger({ style = "GRINDER", partyLevel = 10, mapLevel = 12 }),
  "a grinder stays while the route still out-levels it")
check(not Travel.shouldLinger({ style = "GRINDER", partyLevel = 20, mapLevel = 12 }),
  "and leaves once it has outgrown the route")
check(not Travel.shouldLinger({ style = "GRINDER", partyLevel = nil, mapLevel = nil }),
  "no information means no reason to linger, not forever (§5)")
check(not Travel.shouldLinger({ style = "HARVESTER", shares = sharesT, seenHere = {},
  health = 1, lingeredTicks = Travel.LINGER_CAP_TICKS + 1 }),
  "nobody camps past the cap")
check(not Travel.shouldLinger({ style = "VANGUARD" }), "a vanguard never lingers")
check(not Travel.shouldLinger(nil), "a missing info table does not linger")

-- ------------------------------------------------------------------
print(("ecology/travel: %d checks, %d failures"):format(checks, failures))
if failures > 0 then os.exit(1) end
