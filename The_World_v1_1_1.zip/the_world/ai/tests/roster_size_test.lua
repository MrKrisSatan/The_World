-- Standalone: lua5.1 tests/roster_size_test.lua   (from mods/ai_rivals)
--
-- "Allow the player to select all rivals at character creation, keep the
--  gauntlet to 4 but allow all rivals to be in the game at once."
--
-- Two numbers that used to be one. The roster size decides how many rivals
-- live in the world; M.GAUNTLET_MAX decides how many queue up in the lab.
-- Before 3.3 the creation step, the answer handler and activeRoster all
-- hardcoded 4, so a fifth rival added to data/rivals.lua would have been
-- unreachable -- the mod would have capped the game below its own content.
--
-- These are pure-data rules, so they are checked against a SYNTHETIC roster
-- larger than the shipped one: that is the case the change exists for, and
-- testing only against four would prove nothing.

local cache = {}
local function req(n)
  if cache[n] then return cache[n] end
  local f = assert(loadfile(n .. ".lua")); cache[n] = f(req, {}); return cache[n]
end
local Util, ROSTER = req("src/Util"), req("data/rivals")

local pass, fail = 0, 0
local function eq(a, b, m) if a == b then pass = pass + 1 else fail = fail + 1
  print(("FAIL %s (got %s want %s)"):format(m, tostring(a), tostring(b))) end end
local function ok(c, m) if c then pass = pass + 1 else fail = fail + 1; print("FAIL " .. m) end end

-- The three rules as main.lua implements them, reproduced so they can be
-- exercised against any roster size.
local GAUNTLET_MAX = 4
local WORDS = { "ONE", "TWO", "THREE", "FOUR", "FIVE", "SIX",
                "SEVEN", "EIGHT", "NINE", "TEN" }

local function creationChoices(rosterSize)
  local choices, values = {}, {}
  for i = 1, rosterSize do
    choices[#choices + 1] = (i == rosterSize) and "ALL" or (WORDS[i] or tostring(i))
    values[#values + 1] = tostring(i)
  end
  if #choices <= 1 then return nil end
  return choices, values
end

local function clampCount(value, rosterSize)
  return math.max(1, math.min(rosterSize, math.floor(tonumber(value) or rosterSize)))
end

local function gauntletOrder(rivalIds)
  local order = {}
  for _, id in ipairs(rivalIds) do order[#order + 1] = id end
  while #order > GAUNTLET_MAX do table.remove(order) end
  return order
end

-- 1. THE SHIPPED ROSTER still behaves.
ok(#ROSTER >= 1, "the shipped roster is non-empty (" .. #ROSTER .. ")")
local choices, values = creationChoices(#ROSTER)
ok(choices ~= nil, "the shipped roster asks the question")
eq(#choices, #ROSTER, "one choice per rival")
eq(choices[#choices], "ALL", "the top choice is ALL, not arithmetic")
eq(values[#values], tostring(#ROSTER), "and selects every rival")
eq(choices[1], "ONE", "the first choice is still ONE")

-- 2. A BIGGER ROSTER is fully selectable. This is the point of the change.
for _, size in ipairs({ 5, 6, 8, 10 }) do
  local c, v = creationChoices(size)
  eq(#c, size, size .. "-rival roster offers " .. size .. " choices")
  eq(c[#c], "ALL", size .. ": the top choice is ALL")
  eq(v[#v], tostring(size), size .. ": ALL really means every rival")
  eq(clampCount(size, size), size, size .. ": selecting ALL is not trimmed")
  eq(clampCount(99, size), size, size .. ": an over-large saved count clamps to the roster")
  eq(clampCount(0, size), 1, size .. ": zero clamps up to one")
  eq(clampCount(nil, size), size, size .. ": a missing count defaults to ALL")
  eq(clampCount("3", size), 3, size .. ": a stored string count still works")
end
-- the old hardcoded ceiling must be gone
eq(clampCount(6, 6), 6, "a six-rival selection is NOT silently trimmed to four")
eq(clampCount(8, 8), 8, "nor an eight-rival one")

-- a one-rival roster is not a question worth asking
eq(creationChoices(1), nil, "a single-rival roster skips the step entirely")

-- 3. THE GAUNTLET STAYS AT FOUR however many rivals are in the game.
for _, size in ipairs({ 1, 2, 4, 5, 8, 12 }) do
  local ids = {}
  for i = 1, size do ids[i] = "r" .. i end
  local order = gauntletOrder(ids)
  ok(#order <= GAUNTLET_MAX,
     size .. " rivals produce at most " .. GAUNTLET_MAX .. " gauntlet fights (got "
     .. #order .. ")")
  eq(#order, math.min(size, GAUNTLET_MAX), size .. ": and exactly that many")
  -- the cap must trim from the END, so the order is stable and the first
  -- rivals are always the ones the player meets
  eq(order[1], "r1", size .. ": the first rival is always first")
  if size >= 2 then eq(order[2], "r2", size .. ": order is preserved") end
end
eq(#gauntletOrder({}), 0, "an empty roster produces no gauntlet")

-- 4. ...AND EVERY RIVAL IS STILL IN THE GAME. The cap trims the QUEUE, not
--    the world: a rival left out of the gauntlet must still exist.
for _, size in ipairs({ 5, 8, 12 }) do
  local ids = {}
  for i = 1, size do ids[i] = "r" .. i end
  local order = gauntletOrder(ids)
  local inGauntlet = {}
  for _, id in ipairs(order) do inGauntlet[id] = true end
  local left = 0
  for _, id in ipairs(ids) do if not inGauntlet[id] then left = left + 1 end end
  eq(left, size - #order,
     size .. ": the rivals outside the gauntlet are counted, not discarded")
  ok(#ids == size, size .. ": the roster itself is untouched by the cap")
end

-- 5. Every roster row is still well formed at any size -- a bigger roster must
--    not need hand-editing elsewhere to work.
for i, def in ipairs(ROSTER) do
  ok(type(def.id) == "string" and def.id ~= "", "row " .. i .. " has an id")
  ok(type(def.name) == "string" and def.name ~= "", "row " .. i .. " has a name")
  ok(type(def.slot) == "number", "row " .. i .. " has a starter deal slot")
  ok(def.trainerClass ~= nil, "row " .. i .. " has a trainer class")
end
local ids, slots = {}, {}
for _, def in ipairs(ROSTER) do
  ok(not ids[def.id], "roster ids are unique: " .. def.id)
  ids[def.id] = true
  ok(not slots[def.slot], "starter deal slots are unique: " .. tostring(def.slot))
  slots[def.slot] = true
end
eq(Util.count(ids), #ROSTER, "every roster row is distinct")

print(("\n%d passed, %d failed"):format(pass, fail))
os.exit(fail == 0 and 0 or 1)
