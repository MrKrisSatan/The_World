from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
source = (ROOT / "src" / "DoubleBattles.lua").read_text(encoding="utf-8")

required = {
    "enemy partner panel": "panel(battle.enemy2, 0)",
    "ally partner panel": "panel(battle.player2, screenTiles - boxTiles)",
    "current and maximum HP text": 'hp .. "/" .. max',
    "mod-side overlay hook": 'mod.hooks:wrap("battle.overlay"',
    "native attached boxes": "Font.drawBox(bx, 4, boxTiles, 4)",
    "centered target box": "local bx = math.floor((tiles - 12) / 2)",
    "faint reference repair": "replaceFaintReferences(self, battler, replacement)",
    "replacement event": 'Runtime.emit("battle.battler_switched"',
}

for label, needle in required.items():
    assert needle in source, f"missing {label}: {needle}"

assert "src/battle/" not in str(ROOT / "src" / "DoubleBattles.lua")
print("double HUD static checks passed")
