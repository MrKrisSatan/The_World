from pathlib import Path
src = (Path(__file__).parents[1] / "src" / "Pokegear.lua").read_text()
assert 'local function chosenValue(item)' in src
assert 'if type(item) == "table" then return item.value end' in src
# Main menu plus Phone, Contact, Offer and Radio must unwrap API-2 ListMenu items.
assert src.count('local value = chosenValue(item)') >= 5
for target in ('AIR_RivalGearClock', 'AIR_RivalGearPhone', 'AIR_RivalGearMap', 'AIR_RivalGearRadio'):
    assert f'mod.ui.push(game, "{target}"' in src
assert 'return next(game, items)' in src
print("Pokégear ListMenu dispatch checks passed")
