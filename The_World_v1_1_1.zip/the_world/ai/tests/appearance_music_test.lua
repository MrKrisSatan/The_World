-- MUSIC REPLACEMENT, SPRITE ASSIGNMENT AND THE FOURTH SPECIAL (5.1.0)
-- ==================================================================
-- Run from the MOD directory:  lua5.1 tests/appearance_music_test.lua

local cache = {}
local function req(name)
  if cache[name] ~= nil then return cache[name] end
  local chunk = assert(loadfile(name .. ".lua"), "cannot load " .. name)
  local value = chunk(req, {})
  cache[name] = value
  return value
end

local failures, checks = 0, 0
local function check(ok, label)
  checks = checks + 1
  if not ok then failures = failures + 1; print("FAIL: " .. label) end
  return ok
end
local function eq(a, b, label)
  return check(a == b, ("%s (got %s, want %s)"):format(label, tostring(a), tostring(b)))
end

-- ------------------------------------------------------------------
-- 1. Sprites: one per rival, by gender, stable
-- ------------------------------------------------------------------
local Sprites = req("src/Sprites")
local ROSTER = req("data/rivals")
local Specials = req("src/Specials")

local FEMALE = {
  SPRITE_COOLTRAINER_F = true, SPRITE_LASS = true, SPRITE_BRUNETTE_GIRL = true,
  SPRITE_GIRL = true, SPRITE_KRIS = true, SPRITE_TEACHER = true,
}
local MALE = {
  SPRITE_COOLTRAINER_M = true, SPRITE_SUPER_NERD = true, SPRITE_YOUNGSTER = true,
  SPRITE_BUG_CATCHER = true, SPRITE_ROCKER = true, SPRITE_BLUE = true,
  SPRITE_RED = true, SPRITE_CHRIS = true, SPRITE_SILVER = true,
  SPRITE_GENTLEMAN = true, SPRITE_FISHER = true, SPRITE_SUPER_NERD_GEN2 = true,
}

local table_ = {}
for id in pairs(FEMALE) do table_[id] = { id = id, image = "x" } end
for id in pairs(MALE) do table_[id] = { id = id, image = "x" } end
for _, id in ipairs({ "SPRITE_BLACKBELT", "SPRITE_CLERK" }) do
  table_[id] = { id = id, image = "x" }
end
local DATA = { sprites = table_ }

local S = setmetatable({}, { __index = Sprites })
S.table = function(_, data) return data.sprites end

-- A rival gets exactly one sprite and it never wanders.
local first = {}
for _, def in ipairs(ROSTER) do
  first[def.id] = S:assignWalker(def, DATA, 4242)
  check(first[def.id] ~= nil, "every roster row resolves a sprite: " .. def.id)
end
for pass = 1, 3 do
  for _, def in ipairs(ROSTER) do
    if S:assignWalker(def, DATA, 4242) ~= first[def.id] then
      check(false, ("%s changed sprite on pass %d"):format(def.id, pass))
    end
  end
end
check(true, "assignment is stable across repeated calls")

-- Gender is respected in both directions. A female rival must never draw a
-- male walker, which is the thing "based on gender" actually means.
for _, def in ipairs(ROSTER) do
  local id = first[def.id]
  if def.gender == "female" then
    check(not MALE[id] or FEMALE[id],
      ("female rival %s got a male sprite (%s)"):format(def.id, tostring(id)))
  elseif def.gender == "male" then
    check(not FEMALE[id],
      ("male rival %s got a female sprite (%s)"):format(def.id, tostring(id)))
  end
end

-- The point of the change: the roster stops looking like four people.
-- data/rivals.lua used to set fallbackSprite from slot parity, which gave
-- 95 generated rivals two sprites between them.
local distinct = {}
local n = 0
for _, id in pairs(first) do
  if not distinct[id] then distinct[id] = true; n = n + 1 end
end
check(n >= 12,
  ("the roster uses at least 12 distinct walkers (got %d)"):format(n))

-- No generated row may reintroduce the parity shortcut.
for _, def in ipairs(ROSTER) do
  if def.slot and def.slot >= 6 then
    check(def.fallbackSprite == nil,
      ("generated row %s must not name a sprite"):format(def.id))
  end
end

-- A different world seed dresses the roster differently, so two saves do not
-- look identical. Not all of them -- a hash may land twice -- but most.
local moved = 0
for _, def in ipairs(ROSTER) do
  if S:assignWalker(def, DATA, 999999) ~= first[def.id] then moved = moved + 1 end
end
check(moved > #ROSTER * 0.6,
  ("a new world seed redresses most of the roster (got %d of %d)"):format(moved, #ROSTER))

-- AUTHORED IDENTITY BEATS VARIETY. This is the regression guard for the
-- nil-hole bug: `ipairs{ def.overworldSprite, ..., def.fallbackSprite }` stops
-- at the first nil, so fallbackSprite was never read and Guts had silently
-- been a Cooltrainer since walkerFor was written.
for _, def in ipairs(Specials.DEFS) do
  local id, source = S:assignWalker(def, DATA, 4242)
  eq(id, def.fallbackSprite, "special " .. def.id .. " keeps its authored sprite")
  eq(source, "authored", "special " .. def.id .. " resolves as authored")
end
local guts
for _, def in ipairs(Specials.DEFS) do if def.id == "guts" then guts = def end end
check(guts ~= nil, "guts is still in the roster")
if guts then
  eq(S:walkerFor(guts, DATA), "SPRITE_BLACKBELT",
    "walkerFor also reads fallbackSprite now")
end

-- ------------------------------------------------------------------
-- 2. The fourth special: Navin
-- ------------------------------------------------------------------
local navin
for _, def in ipairs(Specials.DEFS) do if def.id == "navin" then navin = def end end
check(navin ~= nil, "navin exists")

if navin then
  eq(navin.rareSpecial, true, "navin is a rare special")
  eq(navin.personality, "WIDE_EYED", "navin has his own personality")
  eq(navin.fixedName, true, "navin's name is not randomised")
  eq(navin.rocketAdminPotential, false,
    "navin is the one special Rocket does not want")
  check((navin.rareChance or 1) < 0.020, "navin is the rarest special")

  -- The whole joke, mechanically: a Ditto and nothing else.
  local Rival = req("src/Rival")
  for _, key in ipairs({ "default", "gen2" }) do
    local chain = Rival.starterChain(navin, key, { seed = 1 })
    eq(#chain, 1, "navin's " .. key .. " starter chain holds exactly one species")
    eq(chain[1], "DITTO", "and it is a Ditto (" .. key .. ")")
  end

  -- Slot and trainer class must not collide with anything already shipped.
  local seenSlot, seenClass, seenId = {}, {}, {}
  for _, def in ipairs(ROSTER) do
    seenSlot[def.slot] = def.id; seenClass[def.trainerClass] = def.id
    seenId[def.id] = true
  end
  for _, def in ipairs(Specials.DEFS) do
    if def ~= navin then
      check(def.slot ~= navin.slot, "navin's slot is free of " .. def.id)
      check(def.trainerClass ~= navin.trainerClass,
        "navin's trainer class is free of " .. def.id)
    end
  end
  check(seenSlot[navin.slot] == nil, "navin's slot does not collide with the roster")
  check(seenClass[navin.trainerClass] == nil, "navin's class does not collide")
  check(seenId[navin.id] == nil, "navin's id does not collide")
end

-- Every special must have a voice, or the rarest characters in the mod are
-- the ones that sound generic (§36).
local VOICES = req("data/voices")
local PERSONALITIES = req("data/personalities")
for _, def in ipairs(Specials.DEFS) do
  check(PERSONALITIES[def.personality] ~= nil,
    ("special %s names a real personality"):format(def.id))
  check(VOICES[def.personality] ~= nil,
    ("special %s has a voice pack"):format(def.id))
end

-- WIDE_EYED's priority list has to name real objectives, with the
-- always-available fallbacks LAST or everything after them is dead code.
local AI = req("src/AI")
local wide = PERSONALITIES.WIDE_EYED
check(wide ~= nil, "WIDE_EYED is defined")
if wide and AI and AI.Can then
  local seenFallback = nil
  for index, objective in ipairs(wide.priorities or {}) do
    check(type(AI.Can[objective]) == "function",
      ("WIDE_EYED objective %s exists in AI.Can"):format(tostring(objective)))
    if objective == "EXPLORE" or objective == "TRAIN" then
      seenFallback = seenFallback or index
    elseif seenFallback then
      check(false, ("WIDE_EYED lists %s after the fallback at %d -- unreachable")
        :format(objective, seenFallback))
    end
  end
end

-- ------------------------------------------------------------------
-- 3. Custom music replaces the game's music
-- ------------------------------------------------------------------
-- Pokegear.lua needs a live mod api to load, so these exercise the two pure
-- predicates plus the source-file contract. The behaviour they guard is the
-- one the old code got wrong: it FORWARDED every cue to the engine, so a
-- chosen track played on top of the map theme rather than instead of it.
local pokegear = io.open("src/RivalGear.lua"):read("*a")

check(pokegear:find("local KEEP_REASONS = { once = true }", 1, true) ~= nil,
  "only one-shot jingles survive custom music")
check(pokegear:find("return nil\n        end", 1, true) ~= nil
   or pokegear:find("silenceEngineMusic", 1, true) ~= nil,
  "the music.select hook silences the engine cue")
check(pokegear:find('-- separate user stream and is stopped explicitly', 1, true) == nil,
  "the old play-alongside path is gone, comment and all")

-- Returning nil stops a NEW cue; it does not stop one already playing, so the
-- theme that was running when the player picked a track has to be stopped
-- explicitly or it never ends.
check(pokegear:find("function Pokegear.customMusicActive", 1, true) ~= nil,
  "there is one predicate for whether custom music owns the audio")
check(pokegear:find("function Pokegear.ensureCustomMusic", 1, true) ~= nil,
  "and one door for opening the source")
check(pokegear:find("restoreEngineMusic", 1, true) ~= nil,
  "switching custom music off hands the map its theme back")

-- The source cannot be serialised, so a reloaded save arrives with the
-- setting on and nothing playing. ensureCustomMusic is what re-opens it.
check(pokegear:find("manager.customMusicTrack = nil", 1, true) ~= nil,
  "leaving custom music forgets the track as well as the source")

-- Only ONE place may call love.audio.newSource, or the "start a track" path
-- and the "resume after load" path will disagree about looping (§26).
local sources = 0
for _ in pokegear:gmatch("love%.audio%.newSource") do sources = sources + 1 end
eq(sources, 1, "exactly one place opens an audio source")

-- ------------------------------------------------------------------
print(("appearance/music: %d distinct roster walkers, %d checks, %d failures")
  :format(n, checks, failures))
if failures > 0 then os.exit(1) end
