from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
st=(ROOT/"src/StaticRivals.lua").read_text()
main=(ROOT/"main.lua").read_text()
mat=(ROOT/"src/manager/Materialize.lua").read_text()
manifest=(ROOT/"manifest.json").read_text()
assert "S.SLOT_COUNT = 8" in st
assert "airStaticRivalSlot" in st
assert "Map.defPassable" in st
assert "nearConnection(def,x,y)" in st
assert 'o.name="AIR_"..tostring(r.id)' in st
assert "o.x,o.y=255,255" in st
assert "World.setMap=function(world,mapId,...)" in st
assert "OW.setMap=function(world,mapId,...)" in st
assert "StaticRivals.install(mod, M)" in main
assert 'key:match("^AIR_(.+)$")' in main
assert "Map-owned static rivals are frozen for this visit" in mat
assert '"version": "7.4.2"' in manifest
print("7.4.2 static rival slot checks passed")
