from pathlib import Path
root=Path(__file__).resolve().parents[1]
rel=(root/'src/Relationships.lua').read_text()
phone=(root/'src/Phone.lua').read_text()
comms=(root/'src/Comms.lua').read_text()
main=(root/'main.lua').read_text()
all_source=main+'\n'+'\n'.join(p.read_text() for p in (root/'src').rglob('*.lua'))
assert 'affectionSeeded' in rel and 'function R.seedAffection' in rel
assert 'return tonumber(bond.affection) or 0' in phone
assert 'storedThreshold < 20' in phone
assert 'Comms.CONTACT_LIMIT = 200' in comms
assert 'function Comms.isOrdinaryTrainer' in comms
assert 'function Comms.isRocketTrainer' in comms
assert 'function Comms.shouldOfferTrainer' in comms
assert 'M:updateTrainerPhoneCalls()' in main
assert 'self:seedAffectionGraph()' in main
assert 'Comms.shouldOfferTrainer' in all_source
print('trainer phone + affection static checks passed')
