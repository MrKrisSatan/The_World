from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
gt=(ROOT/"src/Gen2Talk.lua").read_text()
main=(ROOT/"main.lua").read_text()
manifest=(ROOT/"manifest.json").read_text()

assert '__aiRivalsTalkRouterV733' in gt
assert "local previousInteract = OW.interact" in gt
assert "local previousTalkTo = OW.talkTo" in gt
assert "OW.interact = function(world)" in gt
assert "OW.talkTo = function(world, npc)" in gt
assert "if npc and dispatch(world, npc) then return true end" in gt
assert "if dispatch(world, npc) then return true end" in gt
assert "type(npc.covers) == \"function\"" in gt

assert "local function showGoldDialogue" in main
assert 'type(ow.showText) == "function"' in main
assert "M.rivalInteractionOpen = false" in main
assert '"version": "7.3.3"' in manifest
print("7.3.3 Gold interaction checks passed")
