from pathlib import Path
root = Path(__file__).parents[1]
main = (root/'main.lua').read_text()
all_source = main + '\n' + '\n'.join(p.read_text() for p in (root/'src').rglob('*.lua'))
poke = (root/'src/RivalGear.lua').read_text()
tour = (root/'src/Tournaments.lua').read_text()
assert 'local Tournaments = req("src/Tournaments")' in all_source
assert 'kind == "tournament_eliminated"' in all_source
assert 'kind == "tournament_won"' in all_source
assert 'function M:arrangeTournament' in all_source
assert 'function M:canToggleChallengeDouble' in all_source
assert 'game.input:wasPressed("left") or game.input:wasPressed("right")' in all_source
assert 'M.challengeModes[rival.id] = nextMode' in all_source
assert 'function M:startRivalChallenge(rival, requestedMode, tournamentMatch)' in all_source
assert 'allowNextScriptedDouble' in all_source
assert 'ARRANGE TOURNAMENT AT MY LOCATION' in poke
assert 'AIR_RivalGearTournament' in poke
assert 'label = "RIVALS (3-100)"' in poke
assert 'label = "STANDARD"' in poke and 'label = "DOUBLE"' in poke
assert 'AIR_RivalGearTournamentMode' in poke
assert 'function Tournaments:runAutonomous' in tour
assert 'function Tournaments:startPlayer' in tour
assert 'math.min(100' in tour
assert 'function Tournaments:onPlayerBattleResult' in tour
assert 'function Tournaments:maybeAutonomous' in tour
print('tournaments static PASS')

assert 'lastPlayerTournamentDay' in tour
assert 'doubleExp = true' in tour
assert 'At least three eligible rivals are required.' in tour
assert 'RARE_REWARDS' in tour
assert 'tournamentExpActive' in all_source
