from pathlib import Path
import json
root=Path('.')
m=json.loads((root/'manifest.json').read_text())
assert m['version']=='7.0.0'
assert set(['red','blue','yellow','gold']).issubset(set(m['games']))
q=(root/'src/Quests.lua').read_text()
for token in ['WEATHER_VARIANT','WEATHER_SURVEY','ROCKET_WEATHER_THEFT','ROCKET_VARIANT_PROCURE','scientistWeatherOffer','rocketWeatherOffer','sourceInteraction=true','offeredByNpc=true']:
    assert token in q, token
wr=(root/'src/WeatherResearch.lua').read_text()
assert 'WEATHER_SCIENTIST' in wr and 'Gen2Talk' in wr and 'map_scripts' in wr
wt=(root/'src/WonderTrade.lua').read_text()
assert 'simulateAgent' in wt and 'W.buildPool' in wt
r=(root/'src/Rangers.lua').read_text(); ro=(root/'src/Rocket.lua').read_text(); sim=(root/'src/Simulation.lua').read_text()
assert 'simulateAgent' in r and 'faction="rangers"' in r
assert 'simulateAgent' in ro and 'faction="rocket"' in ro
assert 'wonderTradeDuplicate' in sim
rd=(root/'src/RocketDisguise.lua').read_text()
assert 'rocketWeatherOffer' in rd
# Stolen assets must not be passed to the AI Wonder Trader.
assert 'stolenAssetId' in wt
print('7.0 weather factions + shared wonder trade static: ok')
