from pathlib import Path
root=Path(__file__).resolve().parents[1]
r=(root/'src/RocketDisguise.lua').read_text()
q=(root/'src/Quests.lua').read_text()
d=(root/'src/DoubleAgent.lua').read_text()
m=(root/'main.lua').read_text()
man=(root/'manifest.json').read_text()
assert '"version": "6.4.0"' in man
for x in ['rocketBallPrice','buyRocketBalls','rocketBallsBought','rocketMoneySpent','ai_rivals:buy_rocket_balls']: assert x in r
assert '5 ROCKET BALLS' in m and 'rocketBallPrice' in m
for x in ['queueFollowUp','takePendingFollowUp','pendingFollowUps','chainChapter','sourceInteraction=true','offeredByNpc=true','onRocketTheft']: assert x in q
assert 'ROCKET_PURCHASE' in d
print('mission_chains_640_static: ok')
