#!/usr/bin/env python3
from pathlib import Path
import json
ROOT=Path(__file__).resolve().parents[1]
eco=(ROOT/'src/Ecology.lua').read_text()
main=(ROOT/'main.lua').read_text()
manifest=json.loads((ROOT/'manifest.json').read_text())
checks={
 '5.8 manifest': manifest.get('version')=='5.8.0',
 'persistent ecotypes': 'ecotypes = {}' in eco and 'function Ecology:establishEcotype' in eco,
 'weather exposure': 'function Ecology:observeEnvironment' in eco and 'ADAPTATION_DRIVERS' in eco,
 'diet adaptation': '"DIET:" .. tostring(food):upper()' in eco,
 'displacement adaptation': '"DISPLACED"' in eco,
 'ecotype abundance effect': 'localBias = 1.18' in eco,
 'variant ecotype bonus': 'chance = chance + 0.06' in eco,
 'save format v3': 'version = 3' in eco and 'saved.ecotypes' in eco,
 'encounters observe environment': 'eco:observeEnvironment(ctx.mapId, species, env)' in main,
 'variant salt uses driver': 'localType and localType.driver' in main,
 'report exposes ecotype': 'ecotype = self:ecotype(mapId, species)' in eco,
}
for k,v in checks.items(): print(('PASS ' if v else 'FAIL ')+k)
raise SystemExit(1 if not all(checks.values()) else 0)
