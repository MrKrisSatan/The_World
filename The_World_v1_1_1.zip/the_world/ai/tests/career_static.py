#!/usr/bin/env python3
"""Static contracts for v2.2 careers.

The rule this guards above all others is §35's: a career is a different
priority order over objectives that already exist, NOT a second AI. If a career
ever grows its own movement loop, every bug the original loop fixed comes back
once per career.
"""
import re
import sys
from pathlib import Path

root = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(Path(__file__).resolve().parent))
from _version import at_least

career = (root / "src" / "Career.lua").read_text(encoding="utf-8")
# 4.7.0: the career definitions moved into data/lifepaths.lua, where a path is
# ONE row carrying both its life-path weights and its working life. The checks
# below therefore read the rows; what they assert is unchanged.
rows_src = (root / "data" / "lifepaths.lua").read_text(encoding="utf-8")
rival = (root / "src" / "Rival.lua").read_text(encoding="utf-8")
ai = (root / "src" / "AI.lua").read_text(encoding="utf-8")
sim = (root / "src" / "Simulation.lua").read_text(encoding="utf-8")
main = (root / "main.lua").read_text(encoding="utf-8")
all_source = main + "\n" + "\n".join(p.read_text(encoding="utf-8") for p in (root / "src").rglob("*.lua"))
errors = []

# The declared life paths, read from the model rather than restated here.
lifepath_src = (root / "src" / "LifePath.lua").read_text(encoding="utf-8")
declared = re.findall(r'^\s+"([A-Z_]+)",', lifepath_src[
    lifepath_src.index("LifePath.PATHS = {"):lifepath_src.index("}", lifepath_src.index("LifePath.PATHS = {"))], re.M)


def need(token, blob, label):
    if token not in blob:
        errors.append(label)


# --- §35: a career is not a second AI ---------------------------------------
# Comment lines are stripped first: Career.lua EXPLAINS that it must not
# bypass canEnterMap, and matching prose would fail on the documentation
# rather than on the code. (Third occurrence of this trap -- 1.37, 2.0, here.)
career_code = "\n".join(l for l in career.splitlines()
                        if not l.lstrip().startswith("--"))
for banned in ("setDestination", "routeTo", "canEnterMap", "nextHop",
               "spawnNpc", "hopCost"):
    if banned in career_code:
        errors.append(f"the career model moves rivals itself ({banned}) -- it "
                      f"must only reorder objectives the AI already evaluates")
for banned in ("math.random", "os.time", "os.clock", "love.", "rng:"):
    if banned in career:
        errors.append(f"the career model is not deterministic ({banned})")

# Every objective a career names must be one AI.Can implements. An invented
# name sits in the list doing nothing, which is the quietest way to be broken.
objectives = set(re.findall(r"^function Can\.([A-Z_]+)", ai, re.M))
if not objectives:
    errors.append("could not read the objective vocabulary from AI.lua")
# 4.7.0: scan the ROWS, and scan them PROPERLY. The old version only caught
# four hard-coded fake names, which would not have noticed a typo -- so now
# every objective named in every priority list is checked against the
# vocabulary AI.lua actually implements. That is the check the comment above
# has always claimed to be making, and with a hundred rows written by hand it
# is the one that earns its place.
prio_blocks = re.findall(r"priorities = \{([^}]*)\}", rows_src)
if len(prio_blocks) < 4:
    errors.append("fewer than four careers declare an objective order")
for block in prio_blocks:
    for name in re.findall(r'"([A-Z_]+)"', block):
        if name not in objectives:
            errors.append(f"career priorities name an objective AI.lua does not "
                          f"implement: {name}")
for block in prio_blocks:
    for name in re.findall(r'"([A-Z_]+)"', block):
        if name not in objectives:
            errors.append(f"career objective {name} is not implemented by AI.Can")

# --- the AI consults the career order ---------------------------------------
need("rival.objectivePriorities and rival:objectivePriorities()", ai,
     "AI.evaluate ignores the career objective order")
need("rival.pursuesBadges and not rival:pursuesBadges()", ai,
     "a career rival would still be routed to the League when its ladder ends")
need("function Rival:objectivePriorities", rival, "no objective order accessor")
need("function Rival:pursuesBadges", rival, "no badge-pursuit accessor")

# --- §26: progress is bounded and the column set fixed ----------------------
need("Career.METRIC_MAX", career, "career metrics are uncapped")
newprog = career[career.index("function Career.newProgress"):]
newprog = newprog[:newprog.index("\nend")]
need("for _, metric in ipairs(def.metrics)", newprog,
     "progress is rebuilt from stored keys rather than the declared metric list")
credit = career[career.index("function Career.credit"):]
credit = credit[:credit.index("\nend")]
need("if progress[metric] == nil then return false end", credit,
     "an unknown metric would be ADDED, growing the save with a column "
     "nothing reads")
for banned in ("table.insert", ".log", ".history"):
    if banned in career:
        errors.append(f"the career record keeps an unbounded list ({banned})")

# --- credits come from events that already happen ---------------------------
need('rival:creditCareer("areas", 1)', sim, "an explorer never records a discovery")
need("rival.creditCapture", sim, "a capture never credits a career")
need("function Rival:creditCapture", rival, "no single door for capture credit")
need('self:creditCareer("evolved", 1)', rival, "an evolution never credits a career")
# a guard that can never be true is worse than none
if "promoted and ctx and ctx.log" in sim:
    errors.append("a career promotion is logged behind a guard that cannot be "
                  "true in tryCatch (no ctx in scope) -- silently dead")
need("rival.careerPromotion", sim, "career promotions are never drained to the log")

# --- §7/§12/§16: badges deprioritised, battles NOT abandoned ----------------
need("function Career.pursuesBadges", career, "no badge-pursuit rule")
def career_def_source(path):
    """The source of one path's row in data/lifepaths.lua.

    4.7.0 moved career definitions out of Career.lua and into the rows, so this
    reads a row rather than a table entry. Rows are separated by a blank line
    and the next `add{`, which is a single unambiguous anchor -- unlike the old
    `},\n  ` scan, which stopped at the first nested closing brace and read a
    block that could not contain an objective list.
    """
    start = rows_src.index('add{ id = "' + path + '"')
    nxt = rows_src.find("\nadd{", start)
    return rows_src[start:nxt if nxt != -1 else len(rows_src)]


for path in declared:
    block = career_def_source(path)
    if "TRAIN" not in block and "CHALLENGE_PLAYER" not in block:
        errors.append(f"{path} abandons battling entirely -- §7 forbids it")

# --- unbuilt careers stay inert ---------------------------------------------
# 2.4: every life path is now built. The inertness rule inverts into a
# COMPLETENESS rule -- a path with no career would leave a rival that took it
# behaving as though nothing had happened.
for path in declared:
    if f'add{{ id = "{path}"' not in rows_src:
        errors.append(f"{path} is a declared life path with no row -- a "
                      f"rival that took it would behave as if nothing happened")
    elif "career = {" not in career_def_source(path):
        errors.append(f"{path} has a row but no working life")

# The generated tables must still come FROM the rows: a hand-maintained list of
# ids beside a data file is the drift that cost this release three dead careers
# (COURIER never reached a Mart, PHOTOGRAPHER never sought ghosts,
# TYPE_SPECIALIST never reported to its Gym -- all invisible because the paths
# were missing from the old hand-written Career.IMPLEMENTED).
for token in ("for _, row in ipairs(ROWS) do", "Career.DEFS[row.id] = {",
              "Career.IMPLEMENTED[#Career.IMPLEMENTED + 1] = row.id"):
    need(token, career, f"Career must build itself from the rows ({token})")
if re.search(r"^Career\.IMPLEMENTED = \{\s*\n\s*\"", career, re.M):
    errors.append("Career.IMPLEMENTED is hand-listed again -- it must be derived")

# --- §7 dialogue, §22 no hints ----------------------------------------------
lines = (root / "data" / "dialogue.lua").read_text(encoding="utf-8")
dialogue = (root / "src" / "Dialogue.lua").read_text(encoding="utf-8")
need("D.career = {", lines, "no career dialogue bucket")
need("function Dialogue:careerLine", dialogue, "no career line lookup")
need('if not ok or path == "GYM_CHALLENGE" then return nil end', dialogue,
     "a rival still on the Gym Challenge could speak a career line")
career_block = lines[lines.index("D.career = {"):]
career_block = career_block[:career_block.index("\n}")]

for path in declared:
    if path not in career_block:
        errors.append(f"§7: no dialogue for {path} -- its rival would never "
                      f"speak about the life it took")
# the 1.32-1.35 selection path must still be intact underneath
for token in ("local score = self:scoreLine(rival)", "local mood = self:moodLine(rival)",
              'local relationship = self:relationshipLine(rival, "player")'):
    need(token, dialogue, f"earlier dialogue selection was replaced ({token})")

# --- §24: located careers ROUTE to work, never teleport ----------------------
need("function Career.findHome", career, "no workplace resolution")
need("function Career.isLocated", career, "no located-career predicate")
need("function Career.fieldwork", career, "no fieldwork share")
need("function Can.CAREER_HOME", ai, "no objective takes a rival to its post")
need("function Destination.CAREER_HOME", ai, "the workplace objective has no destination")
# the model must still not move anyone itself -- findHome takes predicates
findhome = career[career.index("function Career.findHome"):]
findhome = findhome[:findhome.index("\nend")]
need("id:upper():find(pattern, 1, true)", findhome,
     "workplaces are matched exactly rather than by substring, which breaks on "
     "Gold, randomizers and total conversions")
need("table.sort(ids)", findhome,
     "the workplace choice depends on map iteration order")
# the objective must respect the same gates as every other journey
canhome = ai[ai.index("function Can.CAREER_HOME"):]
canhome = canhome[:canhome.index("\nend")]
for guard in ("rival:canEnterMap(home)", "rival.ctx.graph:has(home)",
              "if rival.map == home then return false end"):
    if guard not in canhome:
        errors.append(f"Can.CAREER_HOME skips a gate: {guard}")
need("if not home then return false end", canhome,
     "a career whose building does not exist would select the objective anyway")
# and it must not be always-true, or it becomes the 1.14 dead-code bug
if canhome.strip().endswith("return true\nend"):
    pass
need("rival.rng:chance(away)", canhome,
     "a located rival never leaves its building -- §10 says it must remain a "
     "character rather than scenery")
# every located career must list the objective, or it never reports for work
for path in ("OAK_ASSISTANT", "TOWER_CARETAKER", "GHOST_RESEARCHER",
             "GYM_ASSISTANT", "CENTER_ASSISTANT", "MART_WORKER"):
    block = career_def_source(path)
    if "CAREER_HOME" not in block:
        errors.append(f"{path} never reports for work (no CAREER_HOME objective)")
    if "home = {" not in block:
        errors.append(f"{path} is located but names no workplace pattern")
    if "fieldwork" not in block:
        errors.append(f"{path} has no fieldwork share and would become scenery")

# --- surfaces ----------------------------------------------------------------
need('mod.commands:register("rival_career"', all_source, "no career debug verb")
need('kind == "career"', main, "a promotion is not news")
need('label = "RANK"', main, "the detail screen does not show a career rank")
need("Career = Career,", main, "the model is not exported for tests")

# --- preserved ---------------------------------------------------------------
for token in ("KantoCompat", "WonderTrade.install(mod, M)", "rivalGiftAllowed",
              "Relationships.headline", "TeamPlan = TeamPlan", "Story = Story",
              "Presence = Presence", "Weather = Weather", "Economy = Economy",
              "League = League", "LifePath = LifePath"):
    need(token, main, f"earlier contract lost: {token}")
need("local SAVE_VERSION = 10", main, "save version regressed")
errors.extend(x for x in [at_least(root, "2.4.0")] if x)

if errors:
    for error in errors:
        print("FAIL", error)
    raise SystemExit(1)
print("AI Rivals v2.4: every declared life path has a career and dialogue; "
      "transitions are earned, never a way round the lock PASS")
