from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
main=(ROOT/"main.lua").read_text()
mat=(ROOT/"src/manager/Materialize.lua").read_text()
manifest=(ROOT/"manifest.json").read_text()

assert "function M:runtimeObjectsSafe(mapId)" in main
assert "if ow.transitioning or ow.mapSetup then return false end" in main
assert "if world.playerMoving then return false end" in main
assert "and M:runtimeObjectsSafe(playerMap)" in main
assert "and M:runtimeObjectsSafe(world.playerMap)" in main

header=mat[mat.index("function M:spawnFor(mapId)"):mat.index("-- A remembered handle")]
assert "self:runtimeObjectsSafe(mapId)" in header
assert "self:gauntletDone()" in header

assert '"version": "7.3.7"' in manifest
print("7.3.7 Yellow transition spawn-guard checks passed")
