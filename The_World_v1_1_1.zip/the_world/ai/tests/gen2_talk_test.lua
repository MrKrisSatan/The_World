-- Standalone: luajit mods/ai_rivals/tests/gen2_talk_test.lua
--
-- REPORTED: "the rivals can't be interacted with in gold version".
--
-- Gold's `World:interactBody` walks a fixed ladder: trainer flag, strength
-- boulder, itemball, `npc.def.scriptKey`, bg event, tile events.  A
-- mod-spawned rival matches none of them -- it cannot carry a `scriptKey`,
-- because that names bytecode in the cart's extracted script table.  So the A
-- press fell through to `interacted(..., "none")`, and the Gen 1 fallback on
-- the `world.interacted` event never fired either: Gold raises the "npc" kind
-- ONLY from the scriptKey arm.
--
-- Before any of that, though, `interactBody` asks
-- `Gen1Facade.talkToWrapper()` -- a mod's replacement of
-- `OverworldController.talkTo` -- and a true return suppresses the built-in
-- path.  `talkTo` is a BACKED member of the facade, so this is the supported
-- route and needs no engine patch.  These cases assert the router that owns
-- that field behaves, including the ordering property that made it a router
-- rather than a second direct patch.
package.path = "./?.lua;./?/init.lua;" .. package.path
if not _G.love then _G.love = require("tests.love_stub") end

local T = require("tests.modkit")

-- The rival talk handler is registered against a GEN 2 dataset only, so the
-- fixture has to look like Gold to the mod's own data-driven detector
-- (src/Version.lua: gen2Maps / gen2Trainers are the signal).
local Data = T.fixtures.fresh()
-- A Gold dataset has gen2Maps and NO `maps`.  Leaving the Gen 1 table in place
-- would make the fixture kinder than the engine: `detectGeneration` requires
-- the absence of `maps`, so a dataset carrying both reads as Gen 1 and the
-- whole Gen 2 arm under test would never run.
Data.maps = nil
Data.trainers = nil
Data.gen2Maps = { NEW_BARK_TOWN = { id = "NEW_BARK_TOWN", connections = {} } }
Data.gen2Trainers = {}
Data.gen2Sprites = Data.gen2Sprites or {
  SPRITE_CHRIS = { id = "SPRITE_CHRIS", image = "chris", frames = 4, walker = true },
}

local run = T.sdk.loadMod("mods/ai_rivals", { data = Data, generation = 2 })
T.eq(run.mod and run.mod.state, "loaded",
  "the mod runs on gen 2 (" .. tostring(run.mod and run.mod.skipReason) .. ")")
T.eq(#run.errors, 0, "and loads with no boot errors (" .. tostring(run.errors[1]) .. ")")

local Gen2Talk = run.loader.exports.ai_rivals.modules.Gen2Talk
T.check(type(Gen2Talk) == "table", "the talk router is exported")

-- ---- the router's contract ------------------------------------------------

do
  local calls = {}
  Gen2Talk.register("test:low", function() calls[#calls + 1] = "low"; return false end, 10)
  Gen2Talk.register("test:high", function() calls[#calls + 1] = "high"; return false end, 90)
  Gen2Talk.register("test:mid", function() calls[#calls + 1] = "mid"; return false end, 50)

  local order = {}
  for _, h in ipairs(Gen2Talk.handlers) do
    if h.id:match("^test:") then order[#order + 1] = h.id end
  end
  T.same(order, { "test:low", "test:mid", "test:high" },
    "handlers run in ascending priority")

  -- re-registering replaces rather than stacks: game.ready fires twice on a
  -- New Game, and a duplicated handler would answer one press twice
  Gen2Talk.register("test:mid", function() return false end, 50)
  local seen = 0
  for _, h in ipairs(Gen2Talk.handlers) do
    if h.id == "test:mid" then seen = seen + 1 end
  end
  T.eq(seen, 1, "re-registering an id replaces it instead of stacking")

  Gen2Talk.unregister("test:low")
  Gen2Talk.unregister("test:mid")
  Gen2Talk.unregister("test:high")
end

-- ---- installation onto the live field -------------------------------------

local OW = require("src.world.OverworldController")
local foreignCalls = 0
OW.talkTo = function() foreignCalls = foreignCalls + 1; return false end
Gen2Talk.installed = false          -- simulate a fresh boot
OW.__aiRivalsTalkRouter = nil
T.check(Gen2Talk.install(), "the router installs onto OverworldController")
T.check(Gen2Talk.install(), "installing twice is idempotent")

-- a press nobody claims still reaches whatever owned the field before us
OW.talkTo({}, { def = { name = "SOME_VILLAGER" } })
T.eq(foreignCalls, 1, "an unclaimed press chains to the previous owner")

-- ---- the actual defect ----------------------------------------------------

do
  local consumedBy
  Gen2Talk.register("test:rival", function(world, npc)
    local key = Gen2Talk.npcKey(npc)
    if type(key) == "string" and key:match("^AIR_") then
      consumedBy = key
      return true
    end
    return false
  end, 40)

  -- exactly the object shape main.lua spawns: name AIR_<rival id>, no
  -- scriptKey, no trainer flag, no itemball.  This is the press that used to
  -- do nothing at all on Gold.
  local rivalNpc = { def = { name = "AIR_chris", sprite = "SPRITE_CHRIS",
                             x = 5, y = 5, movement = "STAY" } }
  local before = foreignCalls
  local handled = OW.talkTo({}, rivalNpc)
  T.eq(handled, true, "talking to a spawned rival is consumed on Gold")
  T.eq(consumedBy, "AIR_chris", "and reaches the rival handler by object name")
  T.eq(foreignCalls, before,
    "a consumed press does NOT fall through to the built-in path")

  -- the Wonder Trade attendant shares the field and must still work
  local wtHits = 0
  Gen2Talk.register("test:wonder", function(_, npc)
    local def = npc and npc.def
    if def and def.name == "WONDER_TRADE" then wtHits = wtHits + 1; return true end
    return false
  end, 30)
  T.eq(OW.talkTo({}, { def = { name = "WONDER_TRADE" } }), true,
    "the Wonder Trade attendant is served by the same router")
  T.eq(wtHits, 1, "and its handler ran exactly once")
  T.eq(OW.talkTo({}, rivalNpc), true, "the rival still answers alongside it")

  -- a raising handler must not break the A button for the whole map
  Gen2Talk.register("test:boom", function() error("handler blew up") end, 5)
  local okPress, result = pcall(OW.talkTo, {}, rivalNpc)
  T.check(okPress, "a raising handler does not propagate out of the press")
  T.eq(result, true, "and a later handler still consumes the press")
  Gen2Talk.unregister("test:boom")

  T.eq(Gen2Talk.npcKey(nil), nil, "an absent npc resolves to no key")
  T.eq(Gen2Talk.npcKey({ id = "X", def = { name = "Y" } }), "X",
    "an explicit id wins over the def name")

  Gen2Talk.unregister("test:rival")
  Gen2Talk.unregister("test:wonder")
end

-- ---- the mod registered its own handler for a Gold dataset ----------------

-- Registration happens at game.ready, not at the entry chunk: with `mod.game`
-- not yet up the generation is UNKNOWN, and acting on a guess there is the
-- defect that put Gen 1 map_scripts onto a Gold boot.  So drive the real
-- lifecycle rather than asserting against a half-booted mod.
do
  local Runtime = require("src.mods.Runtime")
  Runtime.emit("game.ready", {
    game = { data = Data, save = { party = {} } },
  })
end

do
  local ids = {}
  for _, h in ipairs(Gen2Talk.handlers) do ids[h.id] = true end
  T.check(ids["ai_rivals:rivals"],
    "the mod registers its rival talk handler on a gen 2 boot")
  T.check(ids["ai_rivals:wonder_trade"],
    "and moves Wonder Trade onto the router rather than patching talkTo again")
end

T.finish("ai_rivals gen2 talk")
