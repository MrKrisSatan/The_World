#!/usr/bin/env python3
"""Roster size and gauntlet size are separate numbers (3.3).

Before this, the creation step, the answer handler and activeRoster all
hardcoded 4, so adding a fifth rival to data/rivals.lua would have left it
unreachable — the mod would have capped the game below its own content.
"""
import re
import sys
from pathlib import Path

root = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(Path(__file__).resolve().parent))
from _version import at_least

main = (root / "main.lua").read_text(encoding="utf-8")
all_source = main + "\n" + "\n".join(p.read_text(encoding="utf-8") for p in (root / "src").rglob("*.lua"))
errors = []


def need(token, blob, label):
    if token not in blob:
        errors.append(label)


def code_of(blob):
    return "\n".join(l for l in blob.splitlines() if not l.lstrip().startswith("--"))


code = code_of(main)

# --- the gauntlet cap is its own number -------------------------------------
need("M.GAUNTLET_MAX", all_source, "no gauntlet cap constant")
need("while #order > M.GAUNTLET_MAX do table.remove(order) end", all_source,
     "the gauntlet order is not capped, so every rival would queue up in the lab")

# --- nothing may hardcode the roster size -----------------------------------
# The creation step, the answer handler and activeRoster must all read #ROSTER.
# Anchored on the block that BUILDS the step, not on a byte offset before the
# id -- a fixed-size window silently misses code when the comment above it
# grows, which is how the first version of this check failed on correct code.
step_start = all_source.index("local choices, values = RosterPolicy.creationChoices")
step_end = all_source.index("end", main.index('saveKey = "ai_rivals_count"'))
step = all_source[step_start:step_end]
# 5.0.9: the size passed here is the ORDINARY roster count, not #ROSTER.
# src/Specials.lua appends a rare character when the world seed rolls one, so
# #ROSTER is 100 most saves and 101 on the rest -- the ALL option used to move
# with a roll the player cannot see.
need("RosterPolicy.creationChoices(", step,
     "character creation does not delegate to the roster policy")
need("RosterPolicy.ordinaryCount(ROSTER)", step,
     "the creation menu sizes itself from #ROSTER, which the rare-special "
     "roll inflates")
policy = (root / "src" / "RosterPolicy.lua").read_text(encoding="utf-8")
need('"ALL"', policy, "there is no ALL choice, so selecting every rival is arithmetic")
if re.search(r'choices\s*=\s*\{\s*"ONE",\s*"TWO",\s*"THREE",\s*"FOUR"\s*\}', code):
    errors.append("the creation step still hardcodes ONE..FOUR")

for label, pattern in (
    ("the answer handler", r"math\.min\(4,\s*math\.floor\(tonumber\(ev\.value\)"),
    ("activeRoster", r"chosen\s*=\s*math\.max\(1,\s*math\.min\(4,"),
):
    if re.search(pattern, code):
        errors.append(f"{label} still clamps the rival count to a literal 4")

# 5.0.9: was a search for the inline `math.min(#ROSTER, math.floor(...))`
# expression. That expression stopped existing when the handler was refactored
# to delegate to RosterPolicy, so this check had been RED on correct code for
# several releases -- restating an implementation instead of reading the
# module's vocabulary (lesson 19). It now asserts the rule: the handler clamps
# through the policy, against the ordinary count.
handler_start = code.index('ev.saveKey == "ai_rivals_count"')
handler = code[handler_start:handler_start + 1200]
need("RosterPolicy.clamp(raw", handler,
     "the answer handler does not clamp through the roster policy")
need("RosterPolicy.ordinaryCount(ROSTER)", handler,
     "the answer handler does not clamp to the ordinary roster")
need("RosterPolicy.active(ROSTER, chosen", code,
     "activeRoster does not delegate roster clamping")

# --- a one-rival roster must not ask a question with one answer -------------
need("if #choices > 1 then", step,
     "a single-rival roster would still be asked how many rivals it wants")

# --- setRivalCount was already roster-driven and must stay that way ---------
setter = all_source[all_source.index("function M:setRivalCount"):]
setter = setter[:setter.index("\nend\n")]
need("RosterPolicy.clamp(value, RosterPolicy.ordinaryCount(ROSTER)", setter,
     "setRivalCount no longer delegates roster clamping to the ordinary count")

# --- rare specials join the WORLD, never the opening queue (5.0.9) ---------
# A rolled special used to be queued in Oak's lab, so about one save in ten
# opened with a Lv5 starter against a rival holding MEWTWO. It was also the
# last source of nondeterminism in ai_rivals_test.lua: the extra rival made
# five checks run or not run depending on a hidden roll.
setter_all = all_source[all_source.index("function M:setRivalCount"):]
setter_all = setter_all[:setter_all.index("\nend\n")]
need("RosterPolicy.isOrdinary(rival.def)", setter_all,
     "the intro gauntlet order still queues rare specials")
gauntlet = (root / "src" / "manager" / "Gauntlet.lua").read_text(encoding="utf-8")
need("ordinaryDef(r.def)", gauntlet,
     "the gauntlet rebuild still queues rare specials")

# --- a gift must be reproducible (5.0.9) -----------------------------------
# pickGiftItem indexed a pairs()-ordered list with the rival's RNG, so the
# same save could hand over a different item on different runs -- the one
# thing this mod's deterministic RNG exists to prevent.
rival_src = (root / "src" / "Rival.lua").read_text(encoding="utf-8")
gift = rival_src[rival_src.index("function Rival:pickGiftItem"):]
gift = gift[:gift.index("\nend\n")]
need("table.sort(choices)", gift,
     "pickGiftItem draws from an unordered list, so gifts are not reproducible")

errors.extend(x for x in [at_least(root, "3.3.0")] if x)

if errors:
    for error in errors:
        print("FAIL", error)
    raise SystemExit(1)
print("AI Rivals v3.3 roster: every rival selectable at creation, gauntlet "
      "capped independently PASS")
