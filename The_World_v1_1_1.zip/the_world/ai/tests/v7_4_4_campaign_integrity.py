from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
r=(ROOT/"src/Rival.lua").read_text()
s=(ROOT/"src/Simulation.lua").read_text()
a=(ROOT/"src/AI.lua").read_text()
m=(ROOT/"manifest.json").read_text()
assert "Rival.BADGE_LEAD = 3" in r
assert "Rival.BADGE_TRAIL = 3" in r
assert "campaignTrainerWins" in r
assert "local function undefeatedLocalTrainer(rival)" in s
assert "local function fightRequiredTrainer(rival,foe)" in s
assert 'rival:defeatedTrainer(foe.id)' in s
assert "local requiredFoe=undefeatedLocalTrainer(rival)" in s
assert 'return "campaign trainer blocked progress"' in s
assert "rival.catchUpMode=badgeGap<=-(rival.BADGE_TRAIL or 3)" in s
assert "if rival and rival.catchUpMode then return false end" in a
assert '"version": "7.4.4"' in m
print("7.4.4 campaign integrity checks passed")
