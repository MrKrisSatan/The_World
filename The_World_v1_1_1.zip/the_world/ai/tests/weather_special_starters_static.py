from pathlib import Path

specials = (Path(__file__).resolve().parents[1] / "src" / "Specials.lua").read_text(encoding="utf-8")

expected = {
    "Guts": "WX_150_MEWTWO_VOID",
    "Casca": "WX_297_DRATINI_SNOWCOIL",
    "Griffith": "WX_300_MEW_PRIMALWEATHER",
}
for name, species in expected.items():
    assert species in specials, f"{name} Weather FX starter is not using {species}"

for bad in ("MEWTWO_VOID", "DRATINI_SNOWCOIL", "MEW_PRIMALWEATHER"):
    # Ignore the valid WX_* strings which contain the old suffix.
    assert f'"{bad}"' not in specials, f"legacy unregistered Weather FX species id remains: {bad}"

print("weather special starter IDs: OK")
