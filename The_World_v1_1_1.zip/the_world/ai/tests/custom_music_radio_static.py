import sys
import re
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent))
from _version import at_least
root = Path(__file__).resolve().parents[1]

def code_only(text):
    """Strip Lua comments before scanning.

    Lesson 3, for the eighth time: a file that DOCUMENTS a trap matches the
    pattern for the trap. Both assertions below were written to forbid a
    string that the fix's own comment quotes while explaining why it was
    wrong, so they failed on correct code.
    """
    text = re.sub(r"--\[(=*)\[.*?\]\1\]", " ", text, flags=re.S)
    return "\n".join(
        line for line in text.splitlines() if not line.lstrip().startswith("--")
    )

p = (root/'src'/'Pokegear.lua').read_text()
pcode = code_only(p)
m = (root/'main.lua').read_text()
man = (root/'manifest.json').read_text()
assert 'label = "WEATHER TRACKER"' in p
assert '"WEATHER TRACKER", items' in p
assert 'label = "CUSTOM MUSIC"' in p
assert 'AIR_RivalGearMusicFolders' in p and 'AIR_RivalGearMusicTracks' in p
for ext in ('ogg = true','mp3 = true','wav = true','flac = true'):
    assert ext in p
# 5.1.0: source opening moved into Pokegear.ensureCustomMusic, so the "start
# a track" path and the "resume after a reload" path cannot disagree about
# looping or about what to do when the file is gone. Assert the RULE -- one
# and only one place opens audio -- rather than the old literal (lesson 19).
assert pcode.count('love.audio.newSource') == 1, 'exactly one place may open audio'
assert 'function Pokegear.ensureCustomMusic' in p
assert 'function Pokegear.customMusicActive' in p

# 5.1.0: CUSTOM MUSIC REPLACES THE GAME'S MUSIC. It used to forward every cue
# to the engine, so a chosen track played ON TOP of the map theme. Returning
# nil stops a new cue but not one already playing, so the engine's current
# source has to be stopped explicitly too, and the map theme handed back when
# custom music is switched off.
assert 'local KEEP_REASONS = { once = true }' in p, 'jingles must survive'
assert 'silenceEngineMusic' in p
assert 'restoreEngineMusic' in p
assert 'separate user stream' not in pcode, 'play-alongside path is gone'
assert 'customMusicFolder' in m and 'customMusicTrack' in m
# 4.5.0: this pinned the exact version, so every release failed here until
# somebody edited the test to make it pass -- which is what _version.py exists
# to prevent. Assert the FLOOR the feature shipped at instead.
assert at_least(root, "4.4.3") is None, at_least(root, "4.4.3")
print('custom music + Weather Tracker static PASS')
