from pathlib import Path
root = Path(__file__).resolve().parents[1]

main = (root / "main.lua").read_text(encoding="utf-8")
rocket = (root / "src" / "Rocket.lua").read_text(encoding="utf-8")
poke = (root / "src" / "Pokegear.lua").read_text(encoding="utf-8")
quests = (root / "src" / "Quests.lua").read_text(encoding="utf-8")

assert 'Gen2Talk.register("ai_rivals:rocket"' in main
assert "function Rocket:playerIsRocket()" in rocket
assert "function Rocket:onPlayerDefeated(member)" in rocket
assert "self.rng:chance(0.045" not in rocket
assert "dx == 0 and dy <= 5" in rocket
assert 'value = "_quests"' in poke
assert 'AIR_RivalGearQuests' in poke
assert 'AIR_RivalGearQuestDetail' in poke
assert 'kind = "CLEAR_ROCKETS"' in quests
assert 'kind = "CATCH_RARE"' in quests
assert 'rewardItem = "RARE_CANDY"' in quests
assert "onRocketDefeated" in quests
assert "ownedCount" in quests
print("Team Rocket hostility + dynamic quests static checks: OK")
