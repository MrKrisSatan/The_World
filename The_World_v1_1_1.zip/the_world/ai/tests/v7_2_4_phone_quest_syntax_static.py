from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
main=(ROOT/"main.lua").read_text()
manifest=(ROOT/"manifest.json").read_text()
for name in ("giveItemOffer","tradeSpeciesOffer","accompanyOffer","defeatRivalOffer"):
    assert f"self.quests.{name} and self.quests:{name}()" in main
    assert f"self.quests:{name} and" not in main
assert '"version": "7.2.4"' in manifest
print("7.2.4 phone quest syntax checks passed")
