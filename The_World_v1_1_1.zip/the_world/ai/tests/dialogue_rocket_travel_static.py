from pathlib import Path
root = Path(__file__).resolve().parents[1]
main = (root/"main.lua").read_text(encoding="utf-8")
rocket = (root/"src"/"Rocket.lua").read_text(encoding="utf-8")
dialogue = (root/"data"/"dialogue.lua").read_text(encoding="utf-8")

# Spoken rival dialogue must not be assigned to ticker in interaction paths.
block = main[main.index("function M:interactWithRival"):main.index("function M:facedRival")]
assert "self.ticker =" not in block
handler = main[main.index("local function rivalTalkHandler"):main.index("local function rocketTalkHandler")]
assert "M.ticker =" not in handler
assert '"show_text"' in handler

# Rocket has expanded dialogue and physical/graph travel rules.
assert "ROCKET_LINES" in rocket
assert "function Rocket:walkVisibleMember" in rocket
assert "Pathfinder.find" in rocket
assert 'graph:has("ROCKET_HIDEOUT")' in rocket
assert "member.map = nextMap" in rocket
assert "member.map = member.destination" not in rocket
assert "self:startMission(member,op,target)" in rocket
assert "self:assignRoute(member, self.home)" in rocket
assert "returningHome" in rocket

# Rival dialogue expansion loaded.
for phrase in ("Been a while.", "No excuses.", "Back to the\\nnotebook."):
    assert phrase in dialogue, phrase

print("Dialogue routing + Rocket route traversal static checks: OK")
