#!/usr/bin/env python3
"""Static contracts for v1.33 rival relationships.

The behavioural proof lives in the three standalone Lua suites (they run under
any lua5.1). This file guards the things a static read can guarantee: that one
model exists rather than several, that every write goes through it, that the
option gate reaches every subsystem, and that persistence is versioned.
"""
import json
import re
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from _version import at_least

root = Path(__file__).resolve().parents[1]
rel = (root / "src" / "Relationships.lua").read_text(encoding="utf-8")
rival = (root / "src" / "Rival.lua").read_text(encoding="utf-8")
sim = (root / "src" / "Simulation.lua").read_text(encoding="utf-8")
ai = (root / "src" / "AI.lua").read_text(encoding="utf-8")
dialogue = (root / "src" / "Dialogue.lua").read_text(encoding="utf-8")
lines = (root / "data" / "dialogue.lua").read_text(encoding="utf-8")
main = (root / "main.lua").read_text(encoding="utf-8")
all_source = main + "\n" + "\n".join(p.read_text(encoding="utf-8") for p in (root / "src").rglob("*.lua"))
manifest = json.loads((root / "manifest.json").read_text(encoding="utf-8"))
errors = []


def need(token, blob, label):
    if token not in blob:
        errors.append(label)


# --- one model, and it is the only one -------------------------------------
STATES = ["FRIENDLY", "NEUTRAL", "COMPETITIVE", "RIVALRY",
          "RESPECT", "HOSTILE", "MENTOR", "ALLIED"]
for state in STATES:
    need(f'"{state}"', rel, f"relationship state {state} is not defined")

need("function R.state(bond)", rel, "states are not derived from a bond")
need("R.EFFECTS", rel, "causes are not a named table")
need("R.BOND_LIMIT", rel, "the bond store has no cap")
need("R.REASON_LIMIT", rel, "remembered causes have no cap")
need("function R.fightBias", rel, "no shared fight-odds predicate")
need("function R.willCooperate", rel, "no shared cooperation predicate")
need("function R.serialize", rel, "bonds cannot be serialized")

# Determinism: nothing in the model may roll dice or read the wall clock.
for banned in ("math.random", "rng", "os.time", "os.clock", "love."):
    if banned in rel:
        errors.append(f"the relationship model is not deterministic ({banned})")

# Derivation must be reachable for every state the model advertises.
derivation = rel[rel.index("function R.state(bond)"):]
derivation = derivation[:derivation.index("\nend")]
for state in STATES:
    if f'return "{state}"' not in derivation:
        errors.append(f"{state} is unreachable from the derivation")

# --- persistence ------------------------------------------------------------
need("bonds = Relationships.new()", rival, "rivals have no bond store")
need("bonds = Relationships.serialize(self.bonds)", rival, "bonds are not saved")
need("self.bonds = Relationships.new(saved.bonds)", rival, "bonds are not restored")
need("local SAVE_VERSION = 10", main, "save version was not bumped to 10")

# --- every write names a cause ---------------------------------------------
# No caller may set an axis or a state directly; they call apply/battle only.
for blob, name in ((sim, "Simulation"), (main, "main"), (ai, "AI")):
    for banned in (".regard", ".rivalry =", ".respect ="):
        if banned in blob:
            errors.append(f"{name} writes a relationship axis directly")

for token in ("recordRelationshipBattle", "TITLE_TAKEN", "TITLE_LOST", "TRADED"):
    need(token, sim, f"Simulation does not record {token}")
need('recordRelationship(b.id, "TRADED"', sim, "rival trades are not a cause")
need('M:recordBondBattle(rival, "player"', all_source, "player battles are not a cause")
need('"HELPED"', all_source, "helping a rival is not a cause")

# --- the option gate reaches every subsystem -------------------------------
need('key = "relationships"', all_source, "no RIVAL BONDS option")
need("function M:relationshipsEnabled", main, "no single option gate")
need("relationships = self:relationshipsEnabled()", main, "the gate is not in the world view")
need("world.relationships == false", sim, "Simulation ignores the option gate")
need("ctx.relationships ~= false", sim, "the duel path ignores the option gate")
need("function Dialogue:bondsEnabled", dialogue, "Dialogue ignores the option gate")

# --- dialogue extends rather than replaces ---------------------------------
need("D.relationship = {", lines, "no relationship dialogue bucket")
need("function Dialogue:relationshipLine", dialogue, "no relationship line lookup")
need("resolveBucket", dialogue, "relationship lines bypass bucket resolution")
need("REL =", dialogue, "the {REL} token is missing")
# the 1.32 selection path must still be present and reachable
for token in ("function Dialogue:greeting", "self.lines.badgeNews",
              "local score = self:scoreLine(rival)", "self.lines.scoreRemind"):
    need(token, dialogue, f"1.32 dialogue selection was replaced ({token})")
for state in STATES:
    if state != "NEUTRAL" and f"  {state} = {{" not in lines:
        errors.append(f"no dialogue for derived state {state}")
if re.search(r"D\.relationship\s*=\s*\{[^}]*NEUTRAL\s*=", lines):
    errors.append("NEUTRAL should have no relationship bucket")

# --- behaviour, not just labels --------------------------------------------
need("fightBiasToward", ai, "relationships do not influence AI targeting")
need("willCooperateWith", sim, "relationships do not influence cooperation")
need("#reachable == 1 then return reachable[1]", ai,
     "duel weighting can shift the rival's own RNG stream")

# --- news is transitions only ----------------------------------------------
need('kind == "relationship"', all_source, "relationship transitions are not news")
need("Relationships.headline", main, "relationship news bypasses the one headline path")

# --- debug -----------------------------------------------------------------
need('mod.commands:register("rival_relationship"', all_source, "no relationship debug verb")
need("Relationships.describe", all_source, "the debug verb cannot explain a bond")
need("Relationships = Relationships,", main, "the model is not exported for tests")

# --- preserved compatibility ------------------------------------------------
for token in ("KantoCompat", "WonderTrade.install(mod, M)",
              "rivalGiftAllowed", "MASTER_BALL", "pendingRivalBattleLaunch"):
    need(token, main, f"1.32 compatibility contract lost: {token}")
errors.extend(x for x in [at_least(root, "1.33.0")] if x)

if errors:
    for error in errors:
        print("FAIL", error)
    raise SystemExit(1)
print("AI Rivals v1.33 relationships: one derived model, gated, bounded, "
      "versioned, and wired to behaviour PASS")
