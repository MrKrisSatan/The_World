from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
pers=(ROOT/"data/personalities.lua").read_text()
rivals=(ROOT/"data/rivals.lua").read_text()
rocket=(ROOT/"src/Rocket.lua").read_text()
rv=(ROOT/"src/Rival.lua").read_text()
main=(ROOT/"main.lua").read_text()
manifest=(ROOT/"manifest.json").read_text()
assert 'CRUSADER = {' in pers
assert 'incorruptibleRocket = true' in pers
assert 'religious = true' in pers
assert '"CRUSADER"' in rivals
assert 'incorruptibleRocket == true' in rocket
assert 'weatherFx' in rv and 'match("^WX_")' in rv
assert 'weatherStarterBias' in rv
assert 'compat:present("weather")' in main
for game in ('"red"','"blue"','"yellow"','"gold"'): assert game in manifest
assert '"version": "7.2.0"' in manifest
print("7.2 Crusader/weather starter static checks passed")
