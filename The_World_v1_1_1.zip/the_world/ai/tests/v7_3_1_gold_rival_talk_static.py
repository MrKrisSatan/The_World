from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
g=(ROOT/"src/Gen2Talk.lua").read_text()
m=(ROOT/"main.lua").read_text()
manifest=(ROOT/"manifest.json").read_text()
assert "npc.def and (npc.def.name or npc.def.id)" in g
assert g.index("npc.def and (npc.def.name or npc.def.id)") < g.index("or npc.id")
assert "M:rivalAtNpc(defName)" in m
assert "M:rivalAtNpc(name)" in m
assert "M:rivalAtNpc(runtimeId)" in m
assert "or M:facedRival()" in m
assert "local currentMap = where.mapId or where.map" in m
assert '"version": "7.3.1"' in manifest
print("7.3.1 Gold rival talk checks passed")
