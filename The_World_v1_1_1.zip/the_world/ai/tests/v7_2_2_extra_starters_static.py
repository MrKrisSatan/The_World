from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
rv=(ROOT/"src/Rival.lua").read_text()
manifest=(ROOT/"manifest.json").read_text()
for mon in ("EEVEE","CLEFAIRY","PIKACHU"):
    assert f'"{mon}"' in rv
assert "for _, baseSpecies in ipairs(out)" in rv
assert '"version": "7.2.2"' in manifest
print("7.2.2 extra starter checks passed")
