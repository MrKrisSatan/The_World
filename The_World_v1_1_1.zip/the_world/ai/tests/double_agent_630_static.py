from pathlib import Path
root=Path(__file__).resolve().parents[1]
f=(root/'src/Factions.lua').read_text(); d=(root/'src/DoubleAgent.lua').read_text(); r=(root/'src/RocketDisguise.lua').read_text(); q=(root/'src/Quests.lua').read_text(); m=(root/'manifest.json').read_text()
assert '"version": "6.3.0"' in m
for x in ['SUSPECTED','INVESTIGATED','EXPOSED','HUNTED','adjustSuspicion','adjustTrust']: assert x in f
for x in ['ROCKET_THEFT','ROCKET_JOB_COMPLETED','RANGER_JOB_COMPLETED','rememberEvent']: assert x in d
assert 'state ~= "EXPOSED" and state ~= "HUNTED"' in r
assert 'offerFromIssuer' in q and 'sourceInteraction=true' in q and 'offeredByNpc=true' in q
print('double_agent_630_static: ok')
