-- Standalone: lua5.1 tests/relationship_soak_test.lua   (from mods/ai_rivals)
--
-- Performance and DIVERGENCE. Roadmap §39 asks that four rivals never collapse
-- into identical agents; the relationship graph is one of the places that can
-- silently fail. Two horizons are checked, because they fail differently:
--
--   4000 ticks  ~100 minutes of play. The mid-game spread must be varied.
--   20000 ticks ~8 hours. Long play must not degenerate into one state.
--
-- This suite found two real bugs. Both battle outcomes originally pushed
-- regard down, so every long rivalry decayed into HOSTILE regardless of how it
-- went (fixed by the derived WORTHY cause); and flat per-event deltas made an
-- axis the lifetime integral of everything that ever happened, pinning every
-- pair at a clamp (fixed by making the axes asymptotic).

local cache = {}
local function req(n)
  if cache[n] then return cache[n] end
  local f = assert(loadfile(n .. ".lua")); cache[n] = f(req, {}); return cache[n]
end
local Util, Rival, R = req("src/Util"), req("src/Relationships"), nil
Rival, R = req("src/Rival"), req("src/Relationships")
local PERS, ROSTER = req("data/personalities"), req("data/rivals")

local pass, fail = 0, 0
local function ok(c, m) if c then pass = pass + 1 else fail = fail + 1; print("FAIL " .. m) end end

-- Contact rates match the live loop: personality.rivalFightChance, the 18-tick
-- post-fight cooldown from Simulation, and the trade traffic tryTrade produces.
local function soak(ticks)
  local ctx = { data = { pokemon = {}, constants = {} }, personalities = PERS,
                graph = { has = function() return false end },
                gyms = { order = {}, byBadge = {} } }
  local rivals = {}
  for _, def in ipairs(ROSTER) do rivals[#rivals + 1] = Rival.new(def, ctx) end
  local cd, fights = {}, 0
  local started = os.clock()
  for tick = 1, ticks do
    for _, a in ipairs(rivals) do
      a.ticks = tick
      cd[a.id] = math.max(0, (cd[a.id] or 0) - 1)
      if cd[a.id] == 0 then
        local b = rivals[a.rng:int(1, #rivals)]
        if b.id ~= a.id and (cd[b.id] or 0) == 0 then
          local chance = (a.personality.rivalFightChance or 0.08) * a:fightBiasToward(b.id)
          if a.rng:float() < chance then
            local aWon = a.rng:float() < 0.5
            b.ticks = tick
            a:recordRelationshipBattle(b.id, aWon, { lead = 0 })
            b:recordRelationshipBattle(a.id, not aWon, { lead = 0 })
            cd[a.id], cd[b.id], fights = 18, 18, fights + 1
          elseif a.rng:float() < 0.004 then
            b.ticks = tick
            a:recordRelationship(b.id, "TRADED")
            b:recordRelationship(a.id, "TRADED")
          end
        end
      end
    end
  end
  local ms = (os.clock() - started) * 1000
  local tally, rows = {}, {}
  for _, r in ipairs(rivals) do
    local row = {}
    for _, o in ipairs(rivals) do
      if o.id ~= r.id then
        local state = r:relationshipTo(o.id)
        tally[state] = (tally[state] or 0) + 1
        row[#row + 1] = ("%s=%s"):format(o.id:sub(1, 4), state)
      end
    end
    rows[#rows + 1] = ("  %-8s %s"):format(r.id, table.concat(row, "  "))
  end
  return { rivals = rivals, tally = tally, rows = rows, ms = ms, fights = fights }
end

for _, ticks in ipairs({ 4000, 20000 }) do
  local out = soak(ticks)
  local distinct, worst = 0, 0
  for _, n in pairs(out.tally) do
    distinct = distinct + 1
    worst = math.max(worst, n)
  end
  local summary = {}
  for state, n in pairs(out.tally) do summary[#summary + 1] = state .. "=" .. n end
  table.sort(summary)
  print(("%d ticks: %d fights, %.1f ms (%.4f ms/tick) -- %s")
    :format(ticks, out.fights, out.ms, out.ms / ticks, table.concat(summary, " ")))
  for _, row in ipairs(out.rows) do print(row) end

  ok(out.ms / ticks < 0.5,
     ticks .. ": relationship cost stays under half a millisecond per tick")
  ok(distinct >= 3,
     ticks .. ": the social graph holds at least three distinct states")
  ok(worst <= 8,
     ticks .. ": no single state swallows the whole graph")
  -- directionality must survive: some pair must disagree about each other
  local asymmetric = false
  for _, a in ipairs(out.rivals) do
    for _, b in ipairs(out.rivals) do
      if a.id ~= b.id and a:relationshipTo(b.id) ~= b:relationshipTo(a.id) then
        asymmetric = true
      end
    end
  end
  ok(asymmetric, ticks .. ": relationships stay directional, not mirrored")
  -- and nothing may grow without bound
  for _, r in ipairs(out.rivals) do
    ok(Util.count(r:serialize().bonds) <= R.BOND_LIMIT,
       ticks .. ": " .. r.id .. "'s saved bond store stays capped")
  end
end

print(("\n%d passed, %d failed"):format(pass, fail))
os.exit(fail == 0 and 0 or 1)
