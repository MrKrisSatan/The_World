from pathlib import Path
import json
ROOT=Path(__file__).resolve().parents[1]
r=(ROOT/'src/Rangers.lua').read_text()
m=json.loads((ROOT/'manifest.json').read_text())
assert m['version']=='6.1.0'
for token in ['generateOrganisation','strategicPulse','discoverRocketBase','knownRocketBases','raidBase','servicePoints','jurisdictions','intelligence','resources']:
    assert token in r, token
assert 'version = 2' in r
assert 'rival.rocketAffiliation then return nil' in r
print('ranger 6.1 static OK')
