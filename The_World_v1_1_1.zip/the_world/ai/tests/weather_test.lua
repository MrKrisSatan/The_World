-- Standalone: lua5.1 tests/weather_test.lua   (from mods/ai_rivals)
--
-- The 1.37.0 weather model. Two things matter here above all others:
--
--   1. The chip type must come from the OVERWORLD id, never the battle string.
--      exports.battleWeather() collapses STORM, GALE and RAIN_LIGHT into one
--      "RAINY", and they chip ELECTRIC, FLYING and WATER respectively.
--   2. The catalogue must be READ from Weather FX when it is there and fall
--      back cleanly when it is not -- without ever believing a broken host.

local cache = {}
local function req(n)
  if cache[n] then return cache[n] end
  local f = assert(loadfile(n .. ".lua")); cache[n] = f(req, {}); return cache[n]
end
local Util, Weather = req("src/Util"), req("src/Weather")

local pass, fail = 0, 0
local function eq(a, b, m) if a == b then pass = pass + 1 else fail = fail + 1
  print(("FAIL %s (got %s want %s)"):format(m, tostring(a), tostring(b))) end end
local function ok(c, m) if c then pass = pass + 1 else fail = fail + 1; print("FAIL " .. m) end end

-- A stand-in for the compat handle. `types` mimics Weather FX's exports.types.
local function host(list, version)
  return {
    _exports = { version = version or "4.18.6",
                 types = list and function() return list end or nil },
    exports = function(self) return self._exports end,
  }
end

-- ------------------------------------------------------------------
-- 1. THE BUG THIS RELEASE FIXES
-- ------------------------------------------------------------------
-- Each of these overworld weathers reports the same battle string but chips a
-- different type. Resolving from the battle string cannot tell them apart.
local RAINY = { "RAIN_LIGHT", "RAIN_HEAVY", "STORM", "GALE" }
local chips = {}
for _, id in ipairs(RAINY) do
  eq(Weather.battleString(nil, id), "RAINY", id .. " reports the RAINY battle string")
  chips[Weather.chipType(nil, id)] = true
end
ok(Util.count(chips) >= 3,
   "weathers sharing one battle string chip DIFFERENT types")
eq(Weather.chipType(nil, "STORM"), "ELECTRIC", "a thunderstorm chips all but Electric")
eq(Weather.chipType(nil, "RAIN_LIGHT"), "WATER", "light rain chips all but Water")
eq(Weather.chipType(nil, "GALE"), "FLYING", "a gale chips all but Flying")
eq(Weather.chipType(nil, "THUNDERSNOW"), "ELECTRIC",
   "thundersnow chips Electric-immune, not Ice-immune")
eq(Weather.battleString(nil, "THUNDERSNOW"), "SNOWY",
   "...even though it reports SNOWY")
eq(Weather.chipType(nil, "ASHFALL"), "FIRE", "ashfall chips all but Fire")
eq(Weather.battleString(nil, "ASHFALL"), "SANDSTORM", "...even though it reports SANDSTORM")

-- ------------------------------------------------------------------
-- 2. Reading the host
-- ------------------------------------------------------------------
local live = {
  { id = "SUNNY", chipType = "FIRE", battle = "SUNNY", sunny = true },
  { id = "STORM", chipType = "ELECTRIC", battle = "RAINY", wet = true },
  { id = "NEW_SKY", chipType = "STEEL", battle = "NEW_BATTLE" },
  { id = "MOONFALL", chipType = "DARK", battle = "MOONFALL" },
  { id = "ALSO_NEW", chipType = "FAIRY", battle = "ALSO_NEW" },
}
local h = host(live)
local catalogue, source = Weather.catalogue(h)
eq(source, "host", "a well-formed host catalogue is used")
eq(Weather.chipType(h, "NEW_SKY"), "STEEL",
   "a weather this mod has never heard of is understood from the host")
eq(Weather.chipType(h, "FOG"), nil, "fog has no chip type")
ok(catalogue.HAIL ~= nil,
   "ids the host did not send are kept from the fallback, not lost")

-- the cache must key on version, or a hot reload serves stale rows
local h2 = host(live, "9.9.9")
Weather.catalogue(h2)
h2._exports.types = function()
  return { { id = "SUNNY", chipType = "GRASS", battle = "SUNNY" },
           { id = "A", chipType = "X", battle = "A" },
           { id = "B", chipType = "Y", battle = "B" },
           { id = "C", chipType = "Z", battle = "C" } }
end
h2._exports.version = "9.9.10"
eq(Weather.chipType(h2, "SUNNY"), "GRASS", "a version change re-reads the catalogue")

-- ------------------------------------------------------------------
-- 3. Never believe a broken host
-- ------------------------------------------------------------------
eq(select(2, Weather.catalogue(nil)), "fallback", "no compat handle falls back")
eq(select(2, Weather.catalogue(host(nil))), "fallback", "a host with no types() falls back")
eq(select(2, Weather.catalogue(host({}))), "fallback", "an EMPTY catalogue is not believed")
eq(select(2, Weather.catalogue(host({ { id = "ONLY" } }))), "fallback",
   "a catalogue too small to be real is not believed")
local junk = host({ { id = 7 }, "nope", { chipType = "FIRE" },
  { id = "OK1", chipType = "FIRE", battle = "A" },
  { id = "OK2", chipType = "WATER", battle = "B" },
  { id = "OK3", chipType = "ICE", battle = "C" },
  { id = "OK4", chipType = "ROCK", battle = "D" } })
eq(select(2, Weather.catalogue(junk)), "host", "valid rows are used")
eq(Weather.chipType(junk, "OK1"), "FIRE", "and are read correctly")
local thrower = { exports = function() error("boom") end }
eq(select(2, Weather.catalogue(thrower)), "fallback", "a throwing host falls back")
local badTypes = host({})
badTypes._exports.types = function() error("boom") end
eq(select(2, Weather.catalogue(badTypes)), "fallback", "a throwing types() falls back")
eq(Weather.chipType(nil, nil), nil, "a nil weather has no chip")
eq(Weather.chipType(nil, 42), nil, "a non-string weather has no chip")
eq(Weather.entry(nil, "NOT_A_SKY"), nil, "an unknown id is not invented")

-- ------------------------------------------------------------------
-- 4. Favoured types (§19) mirror Weather FX's own encounter rule
-- ------------------------------------------------------------------
eq(Weather.favouredType(nil, "SUNNY"), "FIRE", "sun favours Fire")
eq(Weather.favouredType(nil, "BLIZZARD"), "ICE", "a blizzard favours Ice")
eq(Weather.favouredType(nil, "FOG"), "GHOST", "fog favours Ghost even with no chip")
eq(Weather.favouredType(nil, "MIST"), "GHOST", "and so does mist")
eq(Weather.favouredType(nil, "CLEAR"), nil, "clear skies favour nothing")
ok(Weather.favoursType(nil, "STORM", "ELECTRIC"), "a storm is good Electric hunting")
ok(not Weather.favoursType(nil, "STORM", "WATER"), "but not good Water hunting")
ok(Weather.bansType(nil, "SUNNY", "WATER"), "sun drives Water away")
ok(Weather.bansType(nil, "BLIZZARD", "GRASS"), "a blizzard drives Grass away")
ok(not Weather.bansType(nil, "SUNNY", "FIRE"), "sun does not drive Fire away")
eq(Util.count(Weather.bannedTypes(nil, "CLEAR")), 0, "clear skies ban nothing")

-- ------------------------------------------------------------------
-- 5. Affinity, and the PSYCHIC_TYPE spelling
-- ------------------------------------------------------------------
eq(Weather.affinity(nil, "STORM", { "ELECTRIC", "ELECTRIC" }), 1,
   "an all-Electric team is immune to a storm's chip")
eq(Weather.affinity(nil, "STORM", { "WATER", "GRASS" }), -1,
   "a team with none of the sky's type is fully exposed")
eq(Weather.affinity(nil, "STORM", { "ELECTRIC", "WATER" }), 0, "a split team is neutral")
eq(Weather.affinity(nil, "CLEAR", { "FIRE" }), 0, "clear skies have no affinity")
eq(Weather.affinity(nil, "STORM", {}), 0, "an empty team has no affinity")
eq(Weather.canonicalType("PSYCHIC_TYPE"), "PSYCHIC", "the Gen 1 spelling is canonicalised")
eq(Weather.affinity(nil, "PSYSTORM", { "PSYCHIC_TYPE" }), 1,
   "and a Psychic team is recognised under either spelling")

-- ------------------------------------------------------------------
-- 6. Determinism and presentation
-- ------------------------------------------------------------------
eq(Weather.chipType(nil, "STORM"), Weather.chipType(nil, "STORM"), "reads are pure")
eq(Weather.label("HAUNTED_MIST"), "haunted mist", "ids read as prose")
eq(Weather.label(nil), "clear skies", "no weather reads as clear skies")

-- Every fallback entry must be well formed, or a host-less game is broken.
for id, def in pairs(Weather.FALLBACK) do
  ok(type(id) == "string", "fallback id is a string")
  ok(def.chip == nil or type(def.chip) == "string", id .. " has a sane chip type")
  ok(def.battle == nil or type(def.battle) == "string", id .. " has a sane battle string")
end

print(("\n%d passed, %d failed"):format(pass, fail))
os.exit(fail == 0 and 0 or 1)
