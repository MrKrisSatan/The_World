from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
gt=(ROOT/"src/Gen2Talk.lua").read_text()
sp=(ROOT/"src/Sprites.lua").read_text()
mat=(ROOT/"src/manager/Materialize.lua").read_text()
manifest=(ROOT/"manifest.json").read_text()
assert "local previousInteract = OW.interact" in gt
assert "OW.interact = function(world)" in gt
assert "local function facingNpc(world)" in gt
assert "handler.fn(world, npc)" in gt
assert "return data.gen2Sprites or data.sprites" in sp
assert "self.generation == 2" in mat
assert "live.gen2Sprites" in mat
assert 'movement = self.generation == 2 and 6 or "STAY"' in mat
assert '"version": "7.3.2"' in manifest
print("7.3.2 Gold talk/sprite checks passed")
