-- Standalone: lua5.1 tests/rival_economy_test.lua  (from mods/ai_rivals)
--
-- The economy through real Rival objects, and the invariant §38 states
-- outright: a rival may never spend money it does not have, and no path may
-- invent any. That is asserted here after every single transaction across a
-- long simulated career, not just at the end.

local cache = {}
local function req(n)
  if cache[n] then return cache[n] end
  local f = assert(loadfile(n .. ".lua")); cache[n] = f(req, {}); return cache[n]
end
local Util, Rival, Economy = req("src/Util"), req("src/Rival"), req("src/Economy")
local PERS, ROSTER = req("data/personalities"), req("data/rivals")

local pass, fail = 0, 0
local function eq(a, b, m) if a == b then pass = pass + 1 else fail = fail + 1
  print(("FAIL %s (got %s want %s)"):format(m, tostring(a), tostring(b))) end end
local function ok(c, m) if c then pass = pass + 1 else fail = fail + 1; print("FAIL " .. m) end end

local DATA = {
  pokemon = { MON = { baseStats = { hp = 60, attack = 70, defense = 60,
    speed = 60, special = 60 }, types = { "NORMAL" },
    level1Moves = { "TACKLE" }, learnset = {} } },
  moves = { TACKLE = { power = 40, type = "NORMAL" } },
  constants = { fallbackMove = "TACKLE" }, type_chart = { matchups = {} },
}
local ctx = { data = DATA, personalities = PERS,
              graph = { has = function() return true end },
              gyms = { order = {}, byBadge = {}, centers = { "CERULEAN_CITY" } } }

local function make(i)
  local r = Rival.new(ROSTER[i or 1], ctx)
  r.ticks, r.map = 0, "CERULEAN_CITY"
  r.gauntletComplete = function() return true end
  return r
end

-- 1. The one money door.
local r = make(1)
local start = r.money
eq(r:earn(500), 500, "earning reports what was earned")
eq(r.money, start + 500, "and the purse grows by it")
eq(r:earn(-100), 0, "a negative earning is refused")
eq(r:earn(0), 0, "a zero earning is refused")
eq(r:spend(200, "BALLS"), 200, "spending reports what was spent")
eq(r.money, start + 300, "and the purse shrinks by it")
eq(r:spend(r.money + 1, "BALLS"), 0, "spending more than the purse is REFUSED")
eq(r.money, start + 300, "and the purse is untouched by a refused spend")
eq(r:spend(-50, "BALLS"), 0, "a negative spend is refused")
ok(r.money >= 0, "the purse is never negative")
-- forfeits are capped at what is actually held
r.money = 100
eq(r:forfeit(500), 100, "a forfeit can only take what the rival has")
eq(r.money, 0, "leaving nothing behind rather than a debt")
eq(r:forfeit(50), 0, "and an empty purse forfeits nothing")

-- 2. The ledger tracks it and stays bounded.
local ledger = r:ensureLedger()
eq(ledger.spent.BALLS, 200, "the spend was recorded against its category")
eq(ledger.earned, 500, "income was recorded")
eq(ledger.lost, 100, "the forfeit was recorded as a loss, not a purchase")
ok(Util.count(ledger.spent) == #Economy.CATEGORIES, "the ledger row set is fixed")

-- 3. Shopping stays inside the purse -- checked after every visit.
local shopper = make(2)
shopper.money = 5000
for visit = 1, 200 do
  local before = shopper.money
  shopper:restockBalls()
  ok(shopper.money >= 0, "visit " .. visit .. ": the purse never goes negative")
  ok(shopper.money <= before, "visit " .. visit .. ": shopping never adds money")
  if visit % 20 == 0 then shopper:earn(2000) end
end
ok(true, "200 shopping trips completed")
-- a broke rival buys nothing and does not error
local broke = make(3)
broke.money = 0
eq(broke:restockBalls(), 0, "a rival with no money buys nothing")
eq(broke.money, 0, "and still has no money")
-- a rival with exactly one ball's worth can buy one
local thin = make(3)
thin.money = Rival.SHOP.POKE_BALL.price
thin.inventory = { POKE_BALL = 0 }
thin:restockBalls()
ok(thin:itemCount("POKE_BALL") >= 1,
   "a rival that can afford exactly one emergency ball gets one")
ok(thin.money >= 0, "and is not left in debt")

-- 4. THE POINT: four rivals with identical money leave the mart with
--    DIFFERENT bags. Before 1.38 they all walked one list to one set of
--    targets and came out holding the same thing.
local bags = {}
for i = 1, #ROSTER do
  local rr = make(i)
  rr.money = 12000
  rr.inventory = {}
  rr:restockBalls()
  local signature = {}
  for _, item in ipairs(Rival.SHOP_ORDER) do
    signature[#signature + 1] = item .. "=" .. rr:itemCount(item)
  end
  bags[#bags + 1] = { id = rr.id, sig = table.concat(signature, ","),
                      spent = Economy.totalSpent(rr:ensureLedger()) }
  print(("  %-8s spent %-6d %s"):format(rr.id, bags[#bags].spent, bags[#bags].sig))
end
local distinct = {}
for _, bag in ipairs(bags) do distinct[bag.sig] = true end
ok(Util.count(distinct) >= 3,
   "four rivals with the same money leave the mart with at least three different bags")
for _, bag in ipairs(bags) do
  ok(bag.spent <= 12000, bag.id .. " never spent more than it had")
end

-- 5. Persistence.
local blob = shopper:serialize()
local reloaded = Rival.new(ROSTER[2], ctx)
ok(reloaded:restore(blob), "a rival with a ledger restores")
eq(reloaded.money, shopper.money, "the purse survives save/load")
eq(reloaded:ensureLedger().spent.BALLS, shopper.ledger.spent.BALLS,
   "the ledger survives save/load")
-- a pre-1.38 save has no ledger and invents no history
blob.ledger = nil
local migrated = Rival.new(ROSTER[2], ctx)
ok(migrated:restore(blob), "a pre-1.38 save record still restores")
eq(Economy.totalSpent(migrated:ensureLedger()), 0,
   "an old save starts with an empty ledger rather than an invented one")
eq(migrated.money, blob.money, "but keeps the money it actually had")

-- 6. A LONG CAREER. Every transaction, every tick, checked.
local career = make(1)
career.money = 3000
local minted = false
for tick = 1, 20000 do
  career.ticks = tick
  local before = career.money
  if tick % 13 == 0 then career:earn(math.floor(60 + (tick % 40))) end
  if tick % 37 == 0 then career:forfeit(math.floor(tick % 500)) end
  if tick % 29 == 0 then career:restockBalls() end
  if career.money < 0 then minted = true end
  if career.money > before + 200 then minted = true end
end
ok(not minted, "20000 ticks of trading never minted or lost money illegally")
ok(career.money >= 0, "the purse ends non-negative")
local ledger2 = career:ensureLedger()
ok(Util.count(ledger2.spent) == #Economy.CATEGORIES,
   "the saved ledger is still exactly one row per category after a long game")
local saved = career:serialize()
ok(Util.count(saved.ledger.spent) == #Economy.CATEGORIES,
   "and so is the SERIALIZED one")
-- the books balance: everything that left the purse is accounted for
local accounted = Economy.totalSpent(ledger2) + ledger2.lost
local net = ledger2.earned + 3000 - career.money
ok(math.abs(accounted - net) < 1,
   ("the books balance: %d accounted for, %d actually left the purse")
     :format(accounted, net))

print(("\n%d passed, %d failed"):format(pass, fail))
os.exit(fail == 0 and 0 or 1)
