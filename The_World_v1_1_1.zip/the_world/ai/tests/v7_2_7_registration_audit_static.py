from pathlib import Path
import re
ROOT=Path(__file__).resolve().parents[1]
rocket=(ROOT/"src/Rocket.lua").read_text()
rangers=(ROOT/"src/Rangers.lua").read_text()
main=(ROOT/"main.lua").read_text()
manifest=(ROOT/"manifest.json").read_text()
assert "registeredTrainerClasses" in rocket
assert "registeredTrainerClasses" in rangers
assert "if ok then" in rocket and "self.registeredTrainerClasses[class] = true" in rocket
assert "if ok then" in rangers and "self.registeredTrainerClasses[class] = true" in rangers
for bad in ("AIR_Pokegear","src/Pokegear","__airPokegear"):
    assert bad not in main
pat=re.compile(r'[\w\.\]\)]+:[A-Za-z_]\w*\s+and\s+')
for f in ROOT.rglob("*.lua"):
    for line in f.read_text(errors="ignore").splitlines():
        assert not pat.search(line), (f,line)
assert '"version": "7.2.7"' in manifest
print("7.2.7 registration/audit checks passed")
