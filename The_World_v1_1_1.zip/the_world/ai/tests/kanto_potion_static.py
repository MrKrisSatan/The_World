"""Static contract for the AI Rivals-side Kanto Potion compatibility shim."""
from pathlib import Path

root = Path(__file__).resolve().parents[1]
source = (root / "src" / "KantoCompat.lua").read_text(encoding="utf-8")
main = (root / "main.lua").read_text(encoding="utf-8")
required = [
    'type(target.isPlayer) == "boolean"',
    "battle.player.mon == target",
    "target.isPlayer = true",
    "target.isPlayer = old",
    "pcall(original, self, user, target, action",
    "KantoCompat.install(M.compat)",
    'require, "src.render.Assets"',
    "KantoCompat.installPartyIconGuard()",
    "PartyMenu._aiRivalsKantoIconGuard",
]
missing = [item for item in required if item not in source + main]
if missing:
    raise SystemExit("Kanto Potion shim contract failed: " + "; ".join(missing))
print("AI Rivals Kanto Reforged Potion compatibility contract PASS")
