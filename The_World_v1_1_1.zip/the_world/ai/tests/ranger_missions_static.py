from pathlib import Path
root=Path(__file__).parents[1]
q=(root/"src/Quests.lua").read_text()
r=(root/"src/Rangers.lua").read_text()
a=(root/"src/AI.lua").read_text()
p=(root/"src/RivalGear.lua").read_text()
assert 'RANGER_FOREST_SWEEP' in q
assert '25' in q
assert 'rangerMissionOffer' in q
assert 'q.dialogue' in p
assert 'rangerMission' in q
assert 'RANGER_MISSION' in a
assert 'rival.rocketAffiliation' in a
assert 'aiMissionFor' in r
assert 'takeAIMission' in r
assert 'missions = Util.copy(self.missions)' in r
# The old silent refresh factory must not exist.
assert 'while offered < 6' not in q
assert 'rocket.quests' not in q
print('ranger mission static checks passed')
