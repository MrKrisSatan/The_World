-- Standalone: lua5.1 tests/career_dialogue_test.lua  (from mods/ai_rivals)
--
-- §7: a rival who left the Gym Challenge talks about the life it took. §22: a
-- rival still ON the Gym Challenge must never speak a line hinting at a
-- destiny it has not taken, and an unbuilt career must have no lines at all.

local cache = {}
local function req(n)
  if cache[n] then return cache[n] end
  local f = assert(loadfile(n .. ".lua")); cache[n] = f(req, {}); return cache[n]
end
local Rival, Dialogue = req("src/Rival"), req("src/Dialogue")
local Career, LifePath = req("src/Career"), req("src/LifePath")
local LINES, GYMS = req("data/dialogue"), req("data/gyms")
local PERS, ROSTER = req("data/personalities"), req("data/rivals")
local pass, fail = 0, 0
local function ok(c,m) if c then pass=pass+1 else fail=fail+1; print("FAIL "..m) end end
local function eq(a,b,m) if a==b then pass=pass+1 else fail=fail+1
  print(("FAIL %s (got %s want %s)"):format(m,tostring(a),tostring(b))) end end

local ctx = { data = { pokemon = {}, constants = {} }, personalities = PERS,
              graph = { has = function() return false end }, gyms = { order = {}, byBadge = {} } }
local dlg = Dialogue.new(LINES, GYMS, { relationships = function() return true end })

-- every BUILT career has lines; no unbuilt one does (§22: no hints)
for _, path in ipairs(Career.IMPLEMENTED) do
  ok(LINES.career[path] ~= nil, "dialogue covers built career " .. path)
end
for _, path in ipairs(LifePath.PATHS) do
  local built = false
  for _, id in ipairs(Career.IMPLEMENTED) do if id == path then built = true end end
  if not built then
    eq(LINES.career[path], nil, "no dialogue for unbuilt career " .. path)
  end
end
eq(LINES.career.GYM_CHALLENGE, nil, "an ordinary rival has no career line")

for _, def in ipairs(ROSTER) do
  local r = Rival.new(def, ctx); r.ticks = 1
  eq(dlg:careerLine(r), nil, def.id .. ": a Gym Challenge rival offers no career line")
  ok(type(dlg:greeting(r)) == "string", def.id .. ": greeting still works")
  for _, path in ipairs(Career.IMPLEMENTED) do
    local c = Rival.new(def, ctx); c.ticks = 1
    LifePath.commit(c:ensureLifePath(), path, 1, "test")
    local line = dlg:careerLine(c)
    ok(type(line) == "string" and #line > 0,
       def.id .. ": " .. path .. " resolves a line")
    ok(not line:find("{[A-Z]+}"), def.id .. ": " .. path .. " leaves no unexpanded token")
    ok(not line:find("_"), def.id .. ": " .. path .. " exposes no identifier")
    ok(type(dlg:greeting(c)) == "string", def.id .. ": " .. path .. " greeting works")
  end
end
print(("\n%d passed, %d failed"):format(pass, fail))
os.exit(fail == 0 and 0 or 1)
