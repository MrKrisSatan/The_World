-- Standalone: luajit tests/bond_spread_soak_test.lua   (from mods/ai_rivals)
--
-- 4.6.0. Five new states and a pair state are only worth having if the world
-- can REACH them, and LOVERS is only "very rare" if measured to be.
--
-- The relationship soak that already exists drives the live simulation and
-- reports that almost every bond stays NEUTRAL, which is honest but useless
-- for this question: it cannot tell "the state is unreachable" from "these
-- rivals never met". So this soak drives the MODEL directly with named causes,
-- which is the only way to answer the two questions that matter:
--
--   1. can a long, warm, generous relationship actually arrive at DEVOTED --
--      and therefore can two of them arrive at LOVERS;
--   2. does devotion stay OUT of reach of ordinary friendliness, so it is rare
--      because it is hard rather than because a die said no.
--
-- Lesson 9: measure numerically, and print the numbers, so a future retune is
-- checked against a spread rather than against a vibe.

local cache = {}
local function req(n)
  if cache[n] then return cache[n] end
  local f = assert(loadfile(n .. ".lua")); cache[n] = f(req, {}); return cache[n]
end

local pass, fail = 0, 0
local function ok(c, m) if c then pass = pass + 1 else fail = fail + 1; print("FAIL " .. m) end end

local R = req("src/Relationships")

-- One relationship, driven for `ticks` with a repeating pattern of causes.
local function run(pattern, ticks, step)
  local bonds = {}
  local tick = 0
  local i = 0
  while tick < ticks do
    i = i + 1
    local code = pattern[(i - 1) % #pattern + 1]
    if code then R.apply(bonds, "other", code, { tick = tick }) end
    tick = tick + step
  end
  return bonds.other, R.state(bonds.other)
end

-- The affection seed starts as high as 75, so a devoted bond must be reachable
-- from a LOW seed too or the state is really "was lucky at world generation".
local function seeded(value, pattern, ticks, step)
  local bonds = {}
  bonds.other = { regard = 0, rivalry = 0, respect = 0, affection = value,
    affectionSeeded = true, wins = 0, losses = 0, streak = 0, favours = 0,
    lead = 0, peakRegard = 0, peakAffection = value, state = "NEUTRAL",
    since = 0, tick = 0, reasons = {} }
  local tick, i = 0, 0
  while tick < ticks do
    i = i + 1
    R.apply(bonds, "other", pattern[(i - 1) % #pattern + 1], { tick = tick })
    tick = tick + step
  end
  return bonds.other, R.state(bonds.other)
end

------------------------------------------------------------------
-- 1. THE WARM PATH REACHES DEVOTED -- EVENTUALLY.
------------------------------------------------------------------

local GENEROUS = { "HELPED", "GIFT_RECEIVED", "TRADED", "COOPERATED", "REQUEST_DONE" }

local _, shortWarm = run(GENEROUS, 900, 30)
ok(shortWarm ~= "DEVOTED",
  "half an hour of generosity is not devotion (got " .. shortWarm .. ")")

local devotedBond, longWarm = run(GENEROUS, 8000, 40)
ok(longWarm == "DEVOTED",
  "a long, generous, mutual history does reach DEVOTED (got " .. longWarm
  .. " a" .. tostring(devotedBond.affection) .. " r" .. tostring(devotedBond.regard)
  .. " f" .. tostring(devotedBond.favours) .. ")")

local _, fromCold = seeded(15, GENEROUS, 8000, 40)
ok(fromCold == "DEVOTED",
  "and reaches it from the LOWEST affection seed too (got " .. fromCold .. ")")

------------------------------------------------------------------
-- 2. ORDINARY FRIENDLINESS DOES NOT DRIFT INTO IT.
------------------------------------------------------------------
-- The failure mode that would make LOVERS worthless is every long-running
-- friendly pair sliding into it just by lasting. Gifts alone must not.

local _, giftsOnly = run({ "GIFT_RECEIVED" }, 20000, 40)
ok(giftsOnly ~= "DEVOTED",
  "twenty thousand ticks of gifts alone is not devotion (got " .. giftsOnly .. ")")

local _, battlesOnly = run({ "BATTLE_WIN", "BATTLE_LOSS" }, 20000, 40)
ok(battlesOnly ~= "DEVOTED",
  "and neither is a lifetime of battling (got " .. battlesOnly .. ")")

------------------------------------------------------------------
-- 3. THE COLD PATH REACHES NEMESIS, AND NEEDS A HISTORY.
------------------------------------------------------------------

local bonds = {}
for i = 1, 40 do
  R.battle(bonds, "foe", false, { tick = i * 20 })
  R.apply(bonds, "foe", "SNUBBED", { tick = i * 20 })
end
local coldState = R.state(bonds.foe)
ok(coldState == "NEMESIS",
  "sustained defeat plus grievance reaches NEMESIS (got " .. coldState .. ")")

local quick = {}
R.apply(quick, "foe", "TURNED_ROCKET", { tick = 10 })
R.apply(quick, "foe", "SNUBBED", { tick = 20 })
local quickState = R.state(quick.foe)
ok(quickState ~= "NEMESIS",
  "two bad events are not a nemesis (got " .. quickState .. ")")

------------------------------------------------------------------
-- 4. THE SPREAD.
------------------------------------------------------------------
-- Drive many different histories and count where they land. A model that
-- collapses to two or three answers has lost the texture the extra states were
-- added for -- the same failure the 20k relationship soak exists to catch.

local PATTERNS = {
  { "BATTLE_WIN" }, { "BATTLE_LOSS" }, { "BATTLE_WIN", "BATTLE_LOSS" },
  { "GIFT_RECEIVED" }, { "TRADED" }, { "COOPERATED" }, { "HELPED" },
  { "SNUBBED" }, { "REQUEST_IGNORED" }, { "OVERTAKEN" },
  { "BATTLE_LOSS", "SNUBBED" }, { "BATTLE_WIN", "TRADED" },
  { "HELPED", "GIFT_RECEIVED", "TRADED", "COOPERATED", "REQUEST_DONE" },
  { "BATTLE_LOSS", "BATTLE_LOSS", "BATTLE_WIN" },
  { "TITLE_LOST" }, { "TITLE_TAKEN" }, { "TURNED_ROCKET" }, { "LEFT_ROCKET" },
}
local counts, distinct = {}, 0
local total = 0
for _, pattern in ipairs(PATTERNS) do
  for _, ticks in ipairs({ 600, 3000, 9000 }) do
    local _, state = run(pattern, ticks, 30)
    if not counts[state] then counts[state] = 0; distinct = distinct + 1 end
    counts[state] = counts[state] + 1
    total = total + 1
  end
end
local report = {}
for state, n in pairs(counts) do
  report[#report + 1] = ("%s=%d(%d%%)"):format(state, n, math.floor(n / total * 100))
end
table.sort(report)
print("  bond spread over " .. total .. " histories: " .. table.concat(report, "  "))

ok(distinct >= 6,
  "the model still produces a spread of outcomes, not two (" .. distinct .. " states)")

-- WHAT THIS SAMPLE IS AND IS NOT.
--
-- These histories are deliberately EXTREME -- one cause repeated for hours --
-- because that is what finds a state the model cannot reach. It is not a
-- picture of a real save, and half the patterns are grievances, so "HOSTILE is
-- the biggest bucket" says more about the sample than the model. Asserting a
-- flat share here would be measuring the wrong thing (lesson 12), so the
-- share is asserted per HALF instead: neither the warm histories nor the cold
-- ones may collapse to a single answer.
local warmPatterns = { "GIFT_RECEIVED", "TRADED", "COOPERATED", "HELPED", "LEFT_ROCKET" }
local warmCounts, warmDistinct, warmTotal = {}, 0, 0
for _, code in ipairs(warmPatterns) do
  for _, ticks in ipairs({ 600, 3000, 9000 }) do
    local _, state = run({ code }, ticks, 30)
    if not warmCounts[state] then warmCounts[state] = 0; warmDistinct = warmDistinct + 1 end
    warmCounts[state] = warmCounts[state] + 1
    warmTotal = warmTotal + 1
  end
end
ok(warmDistinct >= 2,
  "warm histories do not all land on one state (" .. warmDistinct .. ")")

-- RARITY, STATED AS A RULE RATHER THAN A RATIO.
--
-- "DEVOTED appears in under N% of a synthetic sample" is a number that moves
-- whenever the sample does. The rule that actually makes devotion rare is
-- structural: it takes favours -- things one rival DID for another -- and no
-- history without them may reach it, however long it runs or how warm it gets.
local favourless = { "BATTLE_WIN", "BATTLE_LOSS", "SNUBBED", "OVERTAKEN",
                     "TITLE_LOST", "TITLE_TAKEN", "WORTHY", "AVENGED" }
local leaked = {}
for _, code in ipairs(favourless) do
  local _, state = run({ code }, 20000, 30)
  if state == "DEVOTED" then leaked[#leaked + 1] = code end
end
ok(#leaked == 0,
  "no history without favours reaches devotion (" .. table.concat(leaked, ",") .. ")")

-- And the reverse: DEVOTED is reachable only when EVERY part of the
-- conjunction is present, which is what "very rare" means here.
local _, noRespect = run({ "GIFT_RECEIVED", "REQUEST_IGNORED" }, 12000, 30)
ok(noRespect ~= "DEVOTED",
  "generosity mixed with slights does not arrive there either (" .. noRespect .. ")")

print(("bond spread soak: %d passed, %d failed"):format(pass, fail))
os.exit(fail == 0 and 0 or 1)
