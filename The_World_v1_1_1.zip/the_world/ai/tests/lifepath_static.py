#!/usr/bin/env python3
"""Static contracts for v2.1 Life Path foundation.

Guards the rules that a behavioural test cannot easily see: that eligibility is
derived rather than stored, that the player is never told, that the decision is
locked, and that no new counter was invented for pressure.
"""
import re
import sys
from pathlib import Path

root = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(Path(__file__).resolve().parent))
from _version import at_least

lifepath = (root / "src" / "LifePath.lua").read_text(encoding="utf-8")
rival = (root / "src" / "Rival.lua").read_text(encoding="utf-8")
main = (root / "main.lua").read_text(encoding="utf-8")
all_source = main + "\n" + "\n".join(p.read_text(encoding="utf-8") for p in (root / "src").rglob("*.lua"))
errors = []


def need(token, blob, label):
    if token not in blob:
        errors.append(label)


def code_of(blob):
    return "\n".join(l for l in blob.splitlines() if not l.lstrip().startswith("--"))


# --- §32: eligibility is DERIVED from the seed, never stored -----------------
need("function LifePath.eligibleRivals", lifepath, "no eligibility derivation")
need("function LifePath.divergentCount", lifepath, "no divergence count")
for banned in ("record.eligible", "saved.eligible", "record.pressure",
               "saved.pressure"):
    if banned in lifepath:
        errors.append(f"eligibility or pressure is STORED ({banned}) -- both "
                      f"must be derived, or a save can be tampered into a destiny")
# and it must not consult a clock or a live RNG
for banned in ("math.random", "os.time", "os.clock", "love.", "rng:"):
    if banned in lifepath:
        errors.append(f"the life-path model is not deterministic ({banned})")
need("function LifePath.roll", lifepath, "no deterministic roll")

# --- §3: never all four ------------------------------------------------------
elig = lifepath[lifepath.index("function LifePath.eligibleRivals"):]
elig = elig[:elig.index("\nend")]
need("math.max(0, #ids - 1)", elig,
     "the divergent count is not capped below the roster size -- §3 forbids "
     "every rival abandoning the Gym Challenge")
need("table.sort(ids)", elig,
     "eligibility depends on roster order rather than being deterministic")

# --- §33: the decision is locked --------------------------------------------
commit = lifepath[lifepath.index("function LifePath.commit(record, path, tick, reason)"):]
commit = commit[:commit.index("\nend")]
need("if record.locked then return false end", commit,
     "a committed life path can be re-decided -- save-scummable")
need('path ~= LifePath.GYM_CHALLENGE or saved.locked == true', lifepath,
     "an active career could load unlocked, so a tampered save could re-decide it")

# --- §19/§28/§29: transitions are EARNED, not a way round the lock ----------
need("LifePath.TRANSITIONS", lifepath, "no declared transition edges")
need("function LifePath.transition", lifepath, "no transition operation")
need("function LifePath.doubt", lifepath, "no derived doubt")
need("LifePath.TRANSITION_TENURE", lifepath, "a rival could defect the day it joins")
# commit must STILL refuse once locked -- a transition is a separate door
commit_body = lifepath[lifepath.index("function LifePath.commit(record, path, tick, reason)"):]
commit_body = commit_body[:commit_body.index("\nend")]
need("if record.locked then return false end", commit_body,
     "commit no longer refuses a locked record, so a life path became "
     "re-decidable and §33 is broken")
# a transition must leave the record LOCKED, or a returned rival could diverge again
trans = lifepath[lifepath.index("function LifePath.transition(record, path, tick, reason)"):]
trans = trans[:trans.index("\nend")]
need("record.locked = true", trans,
     "a transition unlocks the record, so a returned rival could take a second "
     "divergence -- §33 must hold across the whole arc")
need("if not allowed then return nil end", trans,
     "a transition to an undeclared destination is permitted")
# §17: nothing may transition INTO Team Rocket -- it must be committed to.
#
# 4.7.0 builds TRANSITIONS from the rows (`transition = "return"` or
# "defection") instead of listing edges literally, so the check reads the two
# things that can now put a destination in front of a rival: the shared
# defection set, and any row that names its own. A Rocket life must never be
# somewhere a rival DRIFTS to -- §17's whole point is that it is chosen.
rows_src = (root / "data" / "lifepaths.lua").read_text(encoding="utf-8")
need("LifePath.DEFECTION_TARGETS", lifepath, "no declared defection targets")
defection = lifepath[lifepath.index("LifePath.DEFECTION_TARGETS = {"):]
defection = defection[:defection.index("}")]
for dest in re.findall(r'"([A-Z_]+)"', defection):
    if "ROCKET" in dest and dest != "ROCKET_DEFECTOR":
        errors.append(f"a defector may land in {dest} -- §17 requires a Rocket "
                      f"life to be committed to, not drifted into")
# And no row may declare an edge of its own that leads there.
for block in re.findall(r"to = \{([^}]*)\}", rows_src):
    for dest in re.findall(r'"([A-Z_]+)"', block):
        if "ROCKET" in dest and dest != "ROCKET_DEFECTOR":
            errors.append(f"a row transitions INTO {dest} -- §17 forbids it")
# The build itself must stay data-driven, or the edges quietly become a second
# hand-maintained list beside the rows.
need('row.transition == "defection"', lifepath,
     "TRANSITIONS is no longer built from the rows")
# doubt must be zero for a path with no arc (2.1's no-information rule)
doubt = lifepath[lifepath.index("function LifePath.doubt(path, facts)"):]
doubt = doubt[:doubt.index("\nend")]
need("if not LifePath.TRANSITIONS[path] then return 0 end", doubt,
     "a rival with no career reads a non-zero doubt from default facts")

# --- §20: a path change moves relationships through the 1.33 causes ---------
relationships = (root / "src" / "Relationships.lua").read_text(encoding="utf-8")
for cause in ("TURNED_ROCKET", "LEFT_ROCKET", "CHANGED_PATH", "CAME_BACK"):
    need(cause, relationships, f"§20: no relationship cause for {cause}")
need("function M:applyPathRelationships", all_source,
     "§20: a life-path change does not move anyone's opinion")
need("function M:considerTransition", all_source, "no manager door for transitions")
apply = all_source[all_source.index("function M:applyPathRelationships"):]
apply = apply[:apply.index("\nend\n\nfunction M:sightingsEnabled")]
need('self:recordBond(rival, "player", cause', apply,
     "§20: the player's relationship is not affected by a path change")

# --- §18: a Rocket rival gains no capability -------------------------------
# §18: the Rocket life is bound by the same rules as every other -- it may not
# hand its rival money, badges, levels, species or items. Read from the row now
# that the definition lives there, and checked for BOTH Rocket lives: 4.7.0
# added ROCKET_EXECUTIVE, and a rule enforced on one of two Rocket careers is
# a rule with a hole in it.
career_src = (root / "src" / "Career.lua").read_text(encoding="utf-8")
rocket = ""
for path in ("TEAM_ROCKET", "ROCKET_EXECUTIVE"):
    start = rows_src.index('add{ id = "' + path + '"')
    nxt = rows_src.find("\nadd{", start)
    rocket += rows_src[start:nxt if nxt != -1 else len(rows_src)]
for banned in ("money", "badges", "level", "species", "item"):
    if banned in rocket:
        errors.append(f"§18: the Team Rocket career grants a resource "
                      f"({banned}) -- it must remain bound by the same rules")

# --- the manager door has every guard ----------------------------------------
door = all_source[all_source.index("function M:considerLifePath"):]
door = door[:door.index("\nend\n\nfunction M:sightingsEnabled")]
for guard in ("record.locked", "self:lifePathEligible(rival)",
              'LifePath.stage(pressure, false) ~= "TRANSITIONING"',
              "LifePath.commit("):
    if guard not in door:
        errors.append(f"considerLifePath skips a guard: {guard}")
need('LifePath.roll(self:lifePathSeed(), "choice:" .. rival.id)', door,
     "the path is chosen by a live roll rather than from the seed")

# --- the seed is written once -----------------------------------------------
seed = all_source[all_source.index("function M:lifePathSeed"):]
seed = seed[:seed.index("\nend")]
need("if self.pathSeed then return self.pathSeed end", seed,
     "the seed is recomputed rather than reused -- §32 forbids it")
for banned in ("os.time", "os.clock", "math.random"):
    if banned in seed:
        errors.append(f"the seed is derived from a clock or RNG ({banned}), so "
                      f"two saves could not be reproduced")
need("out.pathSeed = self.pathSeed", all_source, "the seed is not saved")
need("self.pathSeed = type(saved)", all_source, "the seed is not restored")

# --- §2/§35: pressure reads existing systems, invents no counter -------------
facts = rival[rival.index("function Rival:lifePathFacts"):]
facts = facts[:facts.index("\nend\n\nfunction Rival:lifePathPressure")]
for source in ("self:badgeCount()", "self:collectionSize()", "self:dexCount()",
               "self:navKnownCount()", "self:teamStyle()",
               'self:relationshipTo("player")', "League.wall(record)"):
    if source not in facts:
        errors.append(f"the facts snapshot ignores an existing system: {source}")
for banned in ("self.pathPressure", "self.lifePathCounter", "self.pressureTotal"):
    if banned in rival:
        errors.append(f"a duplicate pressure counter was invented ({banned})")

# --- §22: the player is never told -------------------------------------------
# The detail screen may only show a life path once it is ACTIVE, never the
# eligibility, the pressure or the candidate list.
detail_leaks = ("lifePathPressure()", "lifePathEligible", "lifePathCandidates",
                "lifePathStage()")
# Slice from the life-path row to the end of the detail builder. Anchored on
# the label alone, because the surrounding indentation is not something a
# contract should depend on.
screens = all_source[all_source.index('label = "NOW"'):]
screens = screens[:screens.index("return detail")]
for leak in detail_leaks:
    if leak in screens:
        errors.append(f"§22: the detail screen exposes hidden machinery ({leak})")
need("rival.onGymChallenge and not rival:onGymChallenge()", main,
     "the detail screen would show a life path row for an ordinary rival")
# headlines must not contain raw identifiers
if re.search(r'return name \.\. "[^"]*[A-Z]{3,}_[A-Z]', lifepath):
    errors.append("§22: a headline exposes an internal path identifier")

# --- §34: not simulated every tick -------------------------------------------
need("(M.sim.tick or 0) % 240 == 0", all_source,
     "the life-path decision runs too often for the tick budget")

# --- surfaces and persistence ------------------------------------------------
need('mod.commands:register("rival_lifepath"', all_source, "no life-path debug verb")
need('mod.commands:register("rival_setpath"', all_source, "no debug path override")
need('key = "life_paths"', main, "no RIVAL LIFE PATHS option")
need('kind == "life_path"', main, "a divergence is not news")
need("lifePath = LifePath.newRecord()", rival, "rivals have no life-path record")
need("lifePath = LifePath.serializeRecord(self.lifePath),", rival,
     "the life-path record is not saved")
need("self.lifePath = LifePath.newRecord(saved.lifePath)", rival,
     "the life-path record is not restored")
need("LifePath = LifePath,", main, "the model is not exported for tests")

# --- preserved ---------------------------------------------------------------
for token in ("KantoCompat", "WonderTrade.install(mod, M)", "rivalGiftAllowed",
              "Relationships.headline", "TeamPlan = TeamPlan", "Story = Story",
              "Presence = Presence", "Weather = Weather", "Economy = Economy",
              "League = League"):
    need(token, main, f"earlier contract lost: {token}")
need("local SAVE_VERSION = 10", main, "save version regressed")
errors.extend(x for x in [at_least(root, "2.4.0")] if x)

if errors:
    for error in errors:
        print("FAIL", error)
    raise SystemExit(1)
print("AI Rivals v2.1 Life Paths: eligibility derived from a stable seed, "
      "pressure derived from existing systems, decisions locked, player untold PASS")
