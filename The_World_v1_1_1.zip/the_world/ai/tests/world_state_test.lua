local cache = {}
local function req(n)
  if cache[n] then return cache[n] end
  local f = assert(loadfile(n .. ".lua")); cache[n] = f(req, {}); return cache[n]
end
local WorldState = req("src/WorldState")
local pass, fail = 0, 0
local function ok(c,m) if c then pass=pass+1 else fail=fail+1; print("FAIL "..m) end end
local manager = {
  rocket = { members = {{id="r1",active=true,map="VIRIDIAN_FOREST"}}, incidents={{tick=1,kind="ecology",map="VIRIDIAN_FOREST",memberId="r1",operation="SPECIES_SWEEP",species="WEEDLE"}} },
  rangers = { members = {{id="rg1",active=true,map="VIRIDIAN_FOREST"}}, news={{tick=1,text="Rangers are protecting the forest.",meta={location="VIRIDIAN_FOREST",missionId="m1"}}} },
  ecologyFor = function() return { maps = { VIRIDIAN_FOREST = { WEEDLE = {v=5,t=1} } } } end,
}
local ws = WorldState.new(manager)
ok(ws:observe({tick=10,playerMap="PALLET_TOWN"}), "world state observes a tick")
ok(ws:routeStatus("VIRIDIAN_FOREST") ~= "CALM", "rocket/ranger activity changes route reputation")
ok(#ws.events >= 2, "rocket and ranger incidents enter the chronicle")
local saved = ws:serialize()
local ws2 = WorldState.new(manager, saved)
ok(ws2:routeStatus("VIRIDIAN_FOREST") == ws:routeStatus("VIRIDIAN_FOREST"), "route state survives serialization")
ok(#ws2.events == #ws.events, "chronicle survives serialization")
print(("%d passed, %d failed"):format(pass,fail))
os.exit(fail == 0 and 0 or 1)
