-- Standalone: lua5.1 tests/phone_test.lua   (from mods/ai_rivals)
--
-- The rival phone, ABSORBED FROM 1.30 in 2.5.0.
--
-- It shipped in 1.30, was dropped before 1.31.5, and nothing in the eight
-- releases since replaced it. Two things had to change on the way back in:
-- its `LifePaths` coupling (that module is superseded -- see the audit in
-- docs) and two `goto continue` skips, which are a Lua 5.2 extension LuaJIT
-- accepts but plain 5.1 does not -- so the module could never be parsed by
-- this harness and had never been covered by a test at all.

local cache = {}
local function req(n)
  if cache[n] then return cache[n] end
  local f = assert(loadfile(n .. ".lua")); cache[n] = f(req, {}); return cache[n]
end
local Util, Phone = req("src/Util"), req("src/Phone")
local Rival, LifePath = req("src/Rival"), req("src/LifePath")
local PERS, ROSTER = req("data/personalities"), req("data/rivals")

local pass, fail = 0, 0
local function eq(a, b, m) if a == b then pass = pass + 1 else fail = fail + 1
  print(("FAIL %s (got %s want %s)"):format(m, tostring(a), tostring(b))) end end
local function ok(c, m) if c then pass = pass + 1 else fail = fail + 1; print("FAIL " .. m) end end

local DATA = {
  pokemon = { MON = { baseStats = { hp = 50, attack = 50, defense = 50,
    speed = 50, special = 50 }, types = { "NORMAL" },
    level1Moves = { "TACKLE" }, learnset = {} } },
  moves = { TACKLE = { power = 40, type = "NORMAL" } },
  constants = { fallbackMove = "TACKLE" }, type_chart = { matchups = {} },
  maps = { ROUTE_1 = {} },
}
local ctx = { data = DATA, personalities = PERS,
              graph = { has = function() return true end,
                        neighbours = function() return {} end },
              gyms = { order = {}, byBadge = {} },
              compat = { krAllows = function() return true end } }

local function world(generation)
  local rivals = {}
  for i, def in ipairs(ROSTER) do
    local r = Rival.new(def, ctx)
    r.ticks, r.map = 0, "ROUTE_1"
    rivals[i] = r
  end
  return { rivals = rivals, generation = generation or 1 }, rivals
end

-- 1. It loads at all -- which under 5.1 it previously did not.
ok(type(Phone) == "table", "the phone module loads under plain Lua 5.1")
ok(type(Phone.new) == "function", "and exposes a constructor")

-- 2. Every rival gets a number, and numbers are UNIQUE.
local manager, rivals = world(1)
local phone = Phone.new(manager)
phone:bootstrapAll()
local seen = {}
for _, r in ipairs(rivals) do
  ok(r.phoneNumber ~= nil, r.id .. " has a phone number")
  ok(seen[r.phoneNumber] == nil,
     r.id .. "'s number is unique (" .. tostring(r.phoneNumber) .. ")")
  seen[r.phoneNumber] = true
end
eq(Util.count(seen), #rivals, "every rival has a distinct number")

-- 3. A NUMBER MUST SURVIVE A LOAD UNCHANGED.
-- Regenerating would hand the player a new number for a contact they already
-- have, which is the one thing a phone book must never do.
local before = {}
for _, r in ipairs(rivals) do before[r.id] = r.phoneNumber end
rivals[1].phoneContact = true
local blob = rivals[1]:serialize()
local reloaded = Rival.new(ROSTER[1], ctx)
ok(reloaded:restore(blob), "a rival with phone state restores")
eq(reloaded.phoneNumber, before[rivals[1].id], "the number survives save/load")
eq(reloaded.phoneContact, true, "and so does contact state")
-- bootstrapping again must NOT reassign
local manager2 = { rivals = { reloaded }, generation = 1 }
local phone2 = Phone.new(manager2)
phone2:bootstrapAll()
eq(reloaded.phoneNumber, before[rivals[1].id],
   "re-bootstrapping an existing rival does not regenerate its number")

-- 4. A pre-2.5 save has no phone fields and is given them cleanly.
local bare = Rival.new(ROSTER[2], ctx)
ok(bare:restore({ id = ROSTER[2].id, map = "ROUTE_1", party = {} }),
   "a pre-2.5 save record restores")
eq(bare.phoneNumber, nil, "with no number invented at load")
eq(bare.phoneContact, false, "and no contact claimed")
Phone.new({ rivals = { bare }, generation = 1 }):bootstrapAll()
ok(bare.phoneNumber ~= nil, "but bootstrapping issues one")
eq(bare.phoneContact, false, "without granting contact status")

-- 5. Gen 1 has no Pokegear: registerContacts must be a no-op, not an error.
local m1 = world(1)
local p1 = Phone.new(m1)
p1:bootstrapAll()
ok(pcall(function() p1:registerContacts() end),
   "registering contacts on Gen 1 is safe")
-- and Gen 2 without the registry present is equally safe
local m2 = world(2)
local p2 = Phone.new(m2)
p2:bootstrapAll()
ok(pcall(function() p2:registerContacts() end),
   "registering contacts on Gen 2 with no registry is safe")

-- 6. The career bias replaces the superseded 1.30 LifePaths coupling.
local plain = Rival.new(ROSTER[1], ctx)
plain.ticks = 0
local social = Rival.new(ROSTER[2], ctx)
social.ticks = 0
LifePath.commit(social:ensureLifePath(), "CENTER_ASSISTANT", 1, "test")
local hidden = Rival.new(ROSTER[3], ctx)
hidden.ticks = 0
LifePath.commit(hidden:ensureLifePath(), "TEAM_ROCKET", 1, "test")
local p3 = Phone.new({ rivals = { plain, social, hidden }, generation = 1 })
p3:bootstrapAll()
ok(pcall(function() p3:maybeOffer(plain) end), "an offer can be evaluated")
ok(pcall(function() p3:maybeOffer(social) end), "for a careered rival too")
ok(pcall(function() p3:maybeOffer(hidden) end), "and for a Rocket rival")

-- 7. Declining is remembered, so the offer does not nag.
local nagged = Rival.new(ROSTER[4], ctx)
nagged.ticks = 0
local p4 = Phone.new({ rivals = { nagged }, generation = 1 })
p4:bootstrapAll()
p4:declineOffer(nagged)
eq(nagged.phoneOfferDeclined, true, "a decline is recorded")
eq(p4:maybeOffer(nagged), nil, "and the offer is not made again")
-- accepting grants contact
local yes = Rival.new(ROSTER[1], ctx)
yes.ticks = 0
local p5 = Phone.new({ rivals = { yes }, generation = 1 })
p5:bootstrapAll()
p5:acceptOffer(yes)
eq(yes.phoneContact, true, "accepting grants contact status")

-- 8. It survives a long run without growing anything unbounded.
local mLong, rLong = world(1)
local pLong = Phone.new(mLong)
pLong:bootstrapAll()
for tick = 1, 6000 do
  for _, r in ipairs(rLong) do r.ticks = tick end
  pcall(function() pLong:update(1, rLong, { playerMap = "ROUTE_1" }) end)
end
for _, r in ipairs(rLong) do
  ok(r.phoneNumber ~= nil, r.id .. " still has its number after a long run")
  local saved = r:serialize()
  ok(saved.phoneNumber == r.phoneNumber, r.id .. "'s number serializes")
end
ok(pcall(function() pLong:consumePending() end), "pending calls drain safely")

print(("\n%d passed, %d failed"):format(pass, fail))
os.exit(fail == 0 and 0 or 1)
