-- Standalone: luajit tests/title_match_test.lua   (from mods/ai_rivals)
--
-- 4.6.0: "Then rivals can challenge the champion."
--
-- THE BUG THIS SUITE EXISTS FOR
--
-- §30's title challenge shipped in 1.39 and could never once have fired.
-- `League.mayChallengeTitle` is gated on `record.qualified`; `qualified` is set
-- only by CLEARING the Elite Four; and `Simulation.attemptLeague` refused to
-- run at all while anybody -- the player or another rival -- held the title.
-- So the event that creates a champion is precisely the event that stops
-- anybody from ever qualifying to face one. A dead feature with no failing
-- test, because nothing tested the two rules TOGETHER.
--
-- The first section therefore drives the two rules together, and it is written
-- to fail on 4.5.x: with the crown taken, a rival with eight badges and a
-- strong team can never reach `qualified`.

-- Runs from the ENGINE ROOT (it needs tests/modkit for a real dataset), so mod
-- files are loaded through an explicit mod root rather than a relative path.
package.path = "./?.lua;./?/init.lua;" .. package.path
local MOD = "mods/ai_rivals/"
if io.open("src/League.lua") then MOD = "" end   -- also runnable from the mod dir

local cache = {}
local function req(n)
  if cache[n] then return cache[n] end
  local f = assert(loadfile(MOD .. n .. ".lua")); cache[n] = f(req, {}); return cache[n]
end

local pass, fail = 0, 0
local function ok(c, m) if c then pass = pass + 1 else fail = fail + 1; print("FAIL " .. m) end end
local function eq(a, b, m) if a == b then pass = pass + 1 else fail = fail + 1
  print(("FAIL %s (got %s want %s)"):format(m, tostring(a), tostring(b))) end end

local League = req("src/League")
local Simulation = req("src/Simulation")

------------------------------------------------------------------
-- 1. THE RECORD: a title match is bookkeeping before it is a battle.
------------------------------------------------------------------

local champ = League.newRecord({ qualified = false, reigns = 1 })
local challenger = League.newRecord({ qualified = true })

ok(League.mayTitleMatch(challenger), "a rival that cleared the Elite Four may challenge")
ok(not League.mayTitleMatch(champ), "one that has not, may not")

League.recordTitleMatch(champ, true, { defending = true })
eq(champ.defences, 1, "a champion that wins records a defence")
eq(champ.titleMatches, 1, "and the bout is counted")
ok(champ.titleCooldown > 0, "a champion is not defending again immediately")

League.recordTitleMatch(challenger, false, { defending = false })
eq(challenger.qualified, false,
  "a beaten challenger must clear the Elite Four again -- one clear buys ONE shot")
eq(challenger.defences, 0, "a challenger never accrues defences")
ok(not League.mayTitleMatch(challenger), "and cannot immediately re-enter")

-- The cooldown has to actually run down, or a champion defends once and never
-- again -- the same shape as the 1500-attempt League bug, in reverse.
for _ = 1, League.TITLE_COOLDOWN do League.tickTitle(champ) end
eq(champ.titleCooldown, 0, "the cooldown ages to zero")

------------------------------------------------------------------
-- 2. QUALIFYING WHILE SOMEBODY WEARS THE CROWN.
------------------------------------------------------------------

local T = require("tests.modkit")
local Data = T.fixtures.fresh()

-- THE FIXTURE SHIPS ONE TRAINER CLASS AND NO ELITE FOUR.
--
-- `attemptLeague` refuses outright when it cannot resolve five real League
-- parties -- deliberately, since 1.7: a conversion with no recognisable League
-- must never have one invented for it, or the title gets awarded for zero
-- battles. That refusal is correct and it is also the reason this suite cannot
-- reach the code it exists to test, exactly as double_faint_test could not
-- reach the promote/refill path until it injected a six-mon trainer.
--
-- So the League is BUILT here, from the fixture's own species, and the parties
-- are deliberately weak: the subject under test is who may run, who qualifies
-- and where the title ends up, not whether the simulator can beat Lance.
local FIXTURE_SPECIES = next(Data.pokemon)
local function leaguePartyAt(level)
  return { { species = FIXTURE_SPECIES, level = level },
           { species = FIXTURE_SPECIES, level = level } }
end
for i, class in ipairs({ "OPP_LORELEI", "OPP_BRUNO", "OPP_AGATHA", "OPP_LANCE",
                         "OPP_CHAMPION" }) do
  Data.trainers.classes = Data.trainers.classes or Data.trainers
  Data.trainers.classes[class] = {
    id = class, name = class:gsub("OPP_", ""), index = 90 + i, baseMoney = 100,
    parties = { leaguePartyAt(3 + i) },
  }
end

local Rival = req("src/Rival")
local MapGraph = req("src/MapGraph")
local roster = req("data/rivals")
local personalities = req("data/personalities")
local gyms = req("data/gyms")

local manager = { rivals = {}, playerChampion = false }
local graph = MapGraph.build(Data.maps or {})
local ctx = {
  data = Data, graph = graph, gyms = gyms, manager = manager,
  personalities = personalities, roster = roster.rows or roster,
}

local function newRival(def, badges, level)
  local r = Rival.new(def, ctx)
  r.map = "INDIGO_PLATEAU"
  r.ticks = 1000
  for _, badge in ipairs(gyms.order) do
    if badges > 0 then r.badges[badge] = true; badges = badges - 1 end
  end
  for i = 1, 6 do
    r:addPokemon((Data.pokemon and next(Data.pokemon)) or "PIKACHU", level)
    local slot = r.party[i]
    if slot then slot.hp = r:maxHpOf(slot) end
  end
  return r
end

local rows = roster.rows or roster
local holder = newRival(rows[1], 8, 80)
local hopeful = newRival(rows[2], 8, 82)
manager.rivals = { holder, hopeful }
holder.champion = true
League.beginReign(holder:ensureLeague(), 100)

-- With the crown taken, the run must still be allowed -- and must produce a
-- CHALLENGER rather than a second champion.
local outcome, why = Simulation.attemptLeague(hopeful, nil)
ok(outcome ~= nil,
  "a rival may run the Elite Four while somebody else holds the title"
  .. (outcome and "" or " (refused: " .. tostring(why) .. ")"))
-- The REFUSAL is the thing 4.5.x got wrong, so name it: a run may be turned
-- away for missing data, never because somebody is already champion.
ok(why ~= "title already held" and why ~= "player is champion",
  "and is never turned away merely because the crown is taken")
eq(outcome and outcome.won, true, "with a beatable League, the run is cleared")
eq(hopeful.champion, false,
  "clearing the Elite Four does NOT hand over a title somebody is wearing")
eq(hopeful:ensureLeague().qualified, true,
  "it makes them a qualified challenger, which is what a title match needs")
eq(holder.champion, true, "the sitting champion keeps the crown until beaten")
eq(outcome and outcome.qualified, true, "and the outcome says which kind of win it was")

-- With the crown VACANT the same run still takes the title outright, or this
-- change would have quietly removed the only way to become champion.
local vacantManager = { rivals = {}, playerChampion = false }
local vacantCtx = {
  data = Data, graph = graph, gyms = gyms, manager = vacantManager,
  personalities = personalities, roster = rows,
}
local lone = Rival.new(rows[3], vacantCtx)
lone.map = "INDIGO_PLATEAU"
lone.ticks = 1000
for _, badge in ipairs(gyms.order) do lone.badges[badge] = true end
for i = 1, 6 do
  lone:addPokemon(FIXTURE_SPECIES, 80)
  local slot = lone.party[i]
  if slot then slot.hp = lone:maxHpOf(slot) end
end
vacantManager.rivals = { lone }
local crowned = Simulation.attemptLeague(lone, nil)
eq(crowned and crowned.won, true, "an uncontested League run is still winnable")
eq(lone.champion, true, "and it still crowns a champion")

------------------------------------------------------------------
-- 3. THE TITLE ACTUALLY CHANGES HANDS.
------------------------------------------------------------------

-- Force the qualification so the match is under test rather than the League.
hopeful.champion = false
holder.champion = true
local hopefulRecord = hopeful:ensureLeague()
hopefulRecord.qualified = true
hopefulRecord.titleCooldown = 0
local holderRecord = holder:ensureLeague()
holderRecord.titleCooldown = 0
if not holderRecord.reignStart then League.beginReign(holderRecord, 100) end

-- A challenger with a much stronger team should take it; make the outcome
-- decidable rather than hoping the simulator flips the right way.
for _, slot in ipairs(hopeful.party) do slot.level = 95; slot.hp = hopeful:maxHpOf(slot) end
for i, slot in ipairs(holder.party) do
  if i > 1 then holder.party[i] = nil else slot.level = 5; slot.hp = holder:maxHpOf(slot) end
end

eq(Simulation.titleChallenger(manager.rivals, holder).id, hopeful.id,
  "the qualified rival is the one picked to challenge")

local world = { tick = 2000, rivals = manager.rivals, relationships = true }
local result = Simulation.tryTitleMatch(manager.rivals, world)
ok(result ~= nil, "a title match happens when a qualified challenger exists")
if result then
  eq(result.challenger, hopeful.id, "the challenger is named")
  eq(result.champion, holder.id, "so is the holder")
  if result.challengerWon then
    eq(hopeful.champion, true, "beating the champion takes the title")
    eq(holder.champion, false, "and the old champion loses it")
    eq(hopeful:ensureLeague().qualified, false,
      "the new champion's qualification is consumed -- they cannot challenge themselves")
    ok(hopeful:ensureLeague().reignStart ~= nil, "a new reign starts")
    ok(holder:ensureLeague().longestReign >= 0, "and the old one is closed and measured")
  else
    eq(holder:ensureLeague().defences >= 1, true, "a successful defence is recorded")
  end
end

-- One per tick, and only with a challenger. Called again immediately, nothing
-- happens: both sides are on cooldown, which is what stops a title from
-- changing hands four times a minute.
local again = Simulation.tryTitleMatch(manager.rivals, world)
eq(again, nil, "a second title match cannot happen straight away")

------------------------------------------------------------------
-- 4. THE PLAYER'S TITLE IS NOT SETTLED BEHIND THEIR BACK.
------------------------------------------------------------------
-- If the PLAYER is champion, the challenge has to be fought in person. A
-- simulated bout would take the player's championship away in a menu.

local playerWorld = { tick = 3000, rivals = manager.rivals, playerChampion = true }
for _, r in ipairs(manager.rivals) do
  local rec = r:ensureLeague()
  rec.qualified = true
  rec.titleCooldown = 0
end
eq(Simulation.tryTitleMatch(manager.rivals, playerWorld), nil,
  "the simulation stands down while the PLAYER holds the title")

print(("title matches: %d passed, %d failed"):format(pass, fail))
os.exit(fail == 0 and 0 or 1)
