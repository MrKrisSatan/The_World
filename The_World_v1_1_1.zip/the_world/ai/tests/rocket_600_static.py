from pathlib import Path
import json
ROOT=Path(__file__).resolve().parents[1]
r=(ROOT/'src'/'Rocket.lua').read_text()
d=(ROOT/'data'/'rocket.lua').read_text()
m=json.loads((ROOT/'manifest.json').read_text())
assert m['version']=='6.0.0'
for token in ['leadership = nil','resources = 100','territory = {}','bases = {}','function Rocket:strategicPulse','function Rocket:strategyWeight','function Rocket:recordTerritory','function Rocket:establishBase']:
    assert token in r, token
for doctrine in ['EXPANSIONIST','POACHER','RECRUITER','SCIENTIFIC','COVERT']:
    assert doctrine in d and doctrine in r, doctrine
assert 'version=3' in r
assert 'self:strategyWeight(op, member)' in r
assert 'self:establishBase(member.missionTarget, member)' in r
assert 'self.tick % 60 == 0 then self:strategicPulse()' in r
print('rocket_600_static: PASS')
