-- Standalone: lua5.1 tests/relationship_dialogue_test.lua (from mods/ai_rivals)
--
-- Every derived state must resolve a line for every personality, leave no
-- unexpanded token, and fall silent when the RIVAL BONDS option is off --
-- without changing how greetings behaved in 1.32.
local cache = {}
local function req(name)
  if cache[name] then return cache[name] end
  local f = assert(loadfile(name .. ".lua")); cache[name] = f(req, {}); return cache[name]
end
local Rival = req("src/Rival")
local Dialogue = req("src/Dialogue")
local LINES, GYMS = req("data/dialogue"), req("data/gyms")
local PERS, ROSTER = req("data/personalities"), req("data/rivals")
local pass, fail = 0, 0
local function ok(c,m) if c then pass=pass+1 else fail=fail+1; print("FAIL "..m) end end
local function eq(a,b,m) if a==b then pass=pass+1 else fail=fail+1
  print(("FAIL %s (got %s want %s)"):format(m,tostring(a),tostring(b))) end end

local ctx = { data = { pokemon = {}, constants = {} }, personalities = PERS,
              graph = { has = function() return false end },
              gyms = { order = {}, byBadge = {} } }
local enabled = true
local dlg = Dialogue.new(LINES, GYMS, { relationships = function() return enabled end })

for _, def in ipairs(ROSTER) do
  local r = Rival.new(def, ctx); r.ticks = 1
  -- neutral says nothing about the relationship
  eq(dlg:relationshipLine(r, "player"), nil, def.id .. ": NEUTRAL offers no line")
  eq(dlg:tokens(r).REL, "another trainer", def.id .. ": {REL} reads neutral by default")
  -- every derived state must produce a line for every personality
  for _, code in ipairs({ "BATTLE_LOSS","HELPED","REQUEST_DONE","COOPERATED","TRADED" }) do
    r:recordRelationship("player", code, { tick = 2 })
  end
  for state in pairs(LINES.relationship) do
    r.bonds.player.state = state
    -- force the derived state by asking the bucket directly
    local line = dlg:line(r, LINES.relationship[state], 31)
    ok(type(line) == "string" and #line > 0,
       def.id .. ": " .. state .. " resolves a line for this personality")
    ok(not line:find("{[A-Z]+}") or line:find("{PLAYER}") or line:find("{RIVAL}"),
       def.id .. ": " .. state .. " leaves no unexpanded token")
  end
  -- greeting still works and never returns nil
  ok(type(dlg:greeting(r)) == "string", def.id .. ": greeting still produces text")
end

-- every state the model can derive has a bucket or falls through safely
local R = req("src/Relationships")
for _, state in ipairs(R.STATES) do
  if state ~= "NEUTRAL" then
    ok(LINES.relationship[state] ~= nil, "dialogue covers derived state " .. state)
  end
end

-- turning bonds off silences relationship flavour without breaking dialogue
local r = Rival.new(ROSTER[1], ctx); r.ticks = 5
for i=1,6 do r:recordRelationshipBattle("player", false, { tick = i }) end
ok(dlg:relationshipLine(r, "player") ~= nil, "an active bond produces flavour")
enabled = false
eq(dlg:relationshipLine(r, "player"), nil, "the option gate silences relationship flavour")
eq(dlg:tokens(r).REL, "another trainer", "the option gate neutralises {REL}")
ok(type(dlg:greeting(r)) == "string", "greeting is unaffected when bonds are off")
enabled = true

print(("\n%d passed, %d failed"):format(pass, fail))
os.exit(fail == 0 and 0 or 1)
