#!/usr/bin/env python3
"""Static contracts for v1.35 story arcs.

Behaviour is proven by the four standalone Lua suites. This file guards what a
static read can: that the narrator READS the other three systems rather than
keeping its own copies, that milestones are a fixed closed set, that a chapter
turning is separated from a chapter being news, and that migration is silent.
"""
import json
import re
import sys
from pathlib import Path

root = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(Path(__file__).resolve().parent))
from _version import at_least

story = (root / "src" / "Story.lua").read_text(encoding="utf-8")
rival = (root / "src" / "Rival.lua").read_text(encoding="utf-8")
sim = (root / "src" / "Simulation.lua").read_text(encoding="utf-8")
main = (root / "main.lua").read_text(encoding="utf-8")
all_source = main + "\n" + "\n".join(p.read_text(encoding="utf-8") for p in (root / "src").rglob("*.lua"))
dialogue = (root / "src" / "Dialogue.lua").read_text(encoding="utf-8")
lines = (root / "data" / "dialogue.lua").read_text(encoding="utf-8")
errors = []


def need(token, blob, label):
    if token not in blob:
        errors.append(label)


MOODS = ["CONTENT", "CONFIDENT", "DETERMINED", "FOCUSED",
         "FRUSTRATED", "HUMBLED", "TRIUMPHANT", "RESTLESS"]
CHAPTERS = ["ORIGIN", "RISING", "SETBACK", "REBUILDING",
            "RESURGENT", "CONTENDER", "CHAMPION"]

# --- the model ---------------------------------------------------------------
for mood in MOODS:
    need(f'"{mood}"', story, f"mood {mood} is not declared")
for chapter in CHAPTERS:
    need(f'"{chapter}"', story, f"chapter {chapter} is not declared")

need("function Story.mood", story, "mood is not derived")
need("function Story.chapter", story, "chapter is not derived")
need("Story.MILESTONES", story, "milestones are not a declared list")
need("function Story.backfill", story, "no silent migration path")
need("Story.SETBACK_COOLDOWN", story, "setbacks have no cooldown")
need("Story.NEWSWORTHY_HOLD", story, "chapter news is not rate-limited")
need("function Story.serialize", story, "the story cannot be serialized")

# Every declared mood and chapter must be reachable from the derivation, or it
# is decoration rather than a state.
for name, fn in (("mood", "function Story.mood(story, facts)"),
                 ("chapter", "function Story.chapter(story, facts)")):
    body = story[story.index(fn):]
    body = body[:body.index("\nend")]
    pool = MOODS if name == "mood" else CHAPTERS
    for value in pool:
        if f'return "{value}"' not in body:
            errors.append(f"{value} is unreachable from the {name} derivation")

# Deterministic: no dice, no clock, no engine.
for banned in ("math.random", "os.time", "os.clock", "love.", "rng:"):
    if banned in story:
        errors.append(f"the story model is not deterministic ({banned})")

# --- the narrator reads other systems, it does not duplicate them ------------
# Every one of these is owned elsewhere; a second copy is a second thing to
# get out of step.
need("self.memory and self.memory.events", rival,
     "the streak is not read from 1.32 Memory")
need("self:ensureTeamPlan()", rival, "the story does not read 1.34 TeamPlan")
need("for id, bond in pairs((self.bonds or {}))", rival,
     "the story does not read 1.33 Relationships")
need("function Rival:storyFacts", rival, "no facts snapshot")
need("function Rival:recentStreak", rival, "no streak read")
# and it must not invent counters of its own
for banned in ("self.storyWins", "self.storyLosses", "self.storyBattles"):
    if banned in rival:
        errors.append(f"the story keeps a duplicate counter: {banned}")

# --- a chapter turning is not the same as it being news ----------------------
need("chapterChanged and notable", sim, "Simulation news every chapter turn")
need("chapterChanged and notable", main, "main news every chapter turn")
need("if event.notable ~= true then return end", main,
     "quiet milestones are not filtered out of the news")

# --- migration is silent -----------------------------------------------------
need("if not story.seeded then", rival, "a pre-1.35 save is not backfilled")
need("Story.backfill(story, facts, tick)", rival, "backfill is not used on migration")
need("self.story = Story.new(saved.story)", rival, "the story is not restored")
need("story = Story.serialize(self.story),", rival, "the story is not saved")

# --- the unused 1.32 API is now used, not duplicated -------------------------
need('self:rememberEvent({ tick = tick, type = "MILESTONE"', rival,
     "milestones do not reach the 1.32 event history (§32)")

# --- surfaces ----------------------------------------------------------------
need('mod.commands:register("rival_story"', all_source, "no story debug verb")
need('label = "MOOD"', all_source, "the detail screen does not show the mood")
need('label = "CHAPTER"', all_source, "the detail screen does not show the chapter")
need('SCREEN .. "Story"', all_source, "no milestone screen")
need("function Dialogue:moodLine", dialogue, "no mood dialogue lookup")
need("MOOD =", dialogue, "the {MOOD} token is missing")
need("D.mood = {", lines, "no mood dialogue bucket")
for mood in MOODS:
    if mood == "CONTENT":
        continue
    if not re.search(rf"^  {mood} = \{{", lines, re.M):
        errors.append(f"no dialogue for derived mood {mood}")
if re.search(r"D\.mood\s*=\s*\{[^}]*CONTENT\s*=", lines):
    errors.append("CONTENT should have no mood bucket")
need("Story = Story,", main, "the model is not exported for tests")

# --- 1.32 dialogue selection still intact ------------------------------------
for token in ("local score = self:scoreLine(rival)",
              "local relationship = self:relationshipLine(rival, \"player\")"):
    need(token, dialogue, f"earlier dialogue selection was replaced ({token})")

# --- preserved ---------------------------------------------------------------
for token in ("KantoCompat", "WonderTrade.install(mod, M)", "rivalGiftAllowed",
              "Relationships.headline", "function M:relationshipsEnabled",
              "TeamPlan = TeamPlan"):
    need(token, main, f"earlier contract lost: {token}")
need("local SAVE_VERSION = 10", main, "save version regressed")
errors.extend(x for x in [at_least(root, "1.35.0")] if x)

if errors:
    for error in errors:
        print("FAIL", error)
    raise SystemExit(1)
print("AI Rivals v1.35 story arcs: derived from existing systems, closed "
      "milestone set, rate-limited news, silent migration PASS")
