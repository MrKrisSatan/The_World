from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
main=(ROOT/'main.lua').read_text()
a=main[main.index('local function registerGen1Trainers'):main.index('local function registerGen2Trainers')]
b=main[main.index('local function registerGen2Trainers'):main.index('local function registerTrainers')]
assert 'rival.personality' not in a
assert 'rival.personality' not in b
assert 'M:starterOpts()' in a and 'M:starterOpts()' in b
assert 'M:starterOpts(nil, nil, nil, r.personality)' in main
assert '"version": "7.2.6"' in (ROOT/'manifest.json').read_text()
print('7.2.6 register-ready nil checks passed')
