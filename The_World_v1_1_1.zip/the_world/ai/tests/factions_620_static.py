from pathlib import Path
R=Path(__file__).resolve().parents[1]
m=(R/'main.lua').read_text(); d=(R/'src'/'RocketDisguise.lua').read_text(); f=(R/'src'/'Factions.lua').read_text()
assert '6.2.0' in (R/'manifest.json').read_text()
for x in ['AIR_ROCKET_UNIFORM','AIR_ROCKET_BALL','mod.hooks:wrap("item.use"','battle.kind=="trainer"','battle:throwBall(id)','rocketMission=true','fujiEligible']:
    assert x in d, x
assert 'rocketFriendly(member)' in m
for x in ['researchers','breeders','collectors','communities']: assert x in f
print('6.2.0 faction/disguise static checks passed')
