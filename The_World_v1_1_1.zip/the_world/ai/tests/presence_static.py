#!/usr/bin/env python3
"""Static contracts for v1.36 Living Kanto.

Behaviour is proven by the two standalone Lua suites. This file guards what a
static read can: that the observer is read-only with respect to rivals, that
navigation memory changes speed and never access, that §17 was not
reimplemented, and that the sighting budget is enforced in one place.
"""
import re
import sys
from pathlib import Path

root = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(Path(__file__).resolve().parent))
from _version import at_least

presence = (root / "src" / "Presence.lua").read_text(encoding="utf-8")
rival = (root / "src" / "Rival.lua").read_text(encoding="utf-8")
sim = (root / "src" / "Simulation.lua").read_text(encoding="utf-8")
main = (root / "main.lua").read_text(encoding="utf-8")
all_source = main + "\n" + "\n".join(p.read_text(encoding="utf-8") for p in (root / "src").rglob("*.lua"))
errors = []


def need(token, blob, label):
    if token not in blob:
        errors.append(label)


# --- the observer is an observer ---------------------------------------------
# It may only ever write its own record. Any assignment through the view would
# make a sighting change the world it is reporting on.
# Assignment only -- `view.state == "TRAINING"` is a read and is fine, so the
# pattern must exclude `==`.
for banned in ("view", "rival", "self"):
    if re.search(rf"\b{banned}\.\w+\s*=(?!=)", presence):
        errors.append(f"the observer writes through {banned}.* rather than "
                      f"only its own record")
for banned in ("math.random", "os.time", "os.clock", "love."):
    if banned in presence:
        errors.append(f"the observer is not deterministic ({banned})")

need("Presence.SIGHTING_COOLDOWN", presence, "no per-rival sighting cooldown")
need("Presence.GLOBAL_COOLDOWN", presence, "no world-wide sighting cooldown")
need("Presence.LOG_LIMIT", presence, "the sighting log is unbounded")
need("function Presence.observe", presence, "no observation entry point")
need("function Presence.classify", presence, "sightings are not classified")
need("function Presence.place", presence, "no location purpose (§12)")
need("function Presence.serialize", presence, "the log cannot be serialized")

# The budget must be enforced inside observe(), not by callers.
observe = presence[presence.index("function Presence.observe"):]
observe = observe[:observe.index("\nend")]
for guard in ("GLOBAL_COOLDOWN", "SIGHTING_COOLDOWN", "view.engaged",
              "view.sameMap"):
    if guard not in observe:
        errors.append(f"observe() does not enforce {guard} itself")

# --- §12 location matching must survive a conversion -------------------------
# An exact-equality table would be wrong on randomizers and total conversions.
need('id:find(entry.match, 1, true)', presence,
     "locations are matched exactly rather than by substring")
if re.search(r'PLACES\s*=\s*\{[^}]*\[\s*"', presence):
    errors.append("locations look like an exact-keyed table")

# --- navigation memory: speed only, never access ----------------------------
need("Rival.NAV_LIMIT", rival, "navigation memory is unbounded in size")
need("Rival.NAV_MAX", rival, "per-map familiarity is unbounded")
need("function Rival:familiarity", rival, "no familiarity read")
need("function Rival:trimNavMemory", rival, "navigation memory is never trimmed")
need("self:trimNavMemory(mapId)", rival,
     "the current map is not protected from eviction")
# The gates live in canEnterMap / routeTo and must not mention familiarity.
for fn in ("function Rival:canEnterMap", "function Rival:routeTo"):
    if fn in rival:
        body = rival[rival.index(fn):]
        body = body[:body.index("\nend")]
        for banned in ("familiarity", "visitedMaps", "knowsRoute"):
            if banned in body:
                errors.append(f"{fn} consults navigation memory -- §15/§38 "
                              f"forbid familiarity opening a route")
# familiarity may only reach travel speed
need("local function hopCost(mapId, rival)", sim,
     "hop cost does not consider familiarity")
need("cost = math.max(2, math.floor(cost * (1 - 0.25 * known) + 0.5))", sim,
     "the familiarity saving was rescaled or uncapped")

# --- camps -------------------------------------------------------------------
need("function Presence.campWorthy", presence, "no camp predicate")
need("canTrain = mapHasWildEncounters(rival)", sim,
     "a camp can be made where training is illegal")
need("rival.campTicks", sim, "camps have no duration")
need("campTicks = self.campTicks,", rival, "camp state is not saved")

# --- §17 was already done and must not be reimplemented ----------------------
need('kind == "bought_balls"', all_source, "the existing shop reporting was removed")
need('kind == "tm_bought"', all_source, "the existing TM reporting was removed")
if "errandLine" in presence or "errandLine" in main:
    errors.append("§17 was reimplemented as a duplicate errand channel")

# --- wiring ------------------------------------------------------------------
need("function M:observePresence", all_source, "the observer is never called")
need('key = "sightings"', all_source, "no RIVAL SIGHTINGS option")
need("function M:sightingsEnabled", all_source, "no single option gate for sightings")
need('kind == "sighting"', all_source, "sightings do not reach the news channel")
need("local ta = self.presence.byRival[a.id] or -1", all_source,
     "sightings are handed out in roster order, starving the last rival")
need("out.presence = Presence.serialize(self.presence)", all_source,
     "the sighting log is not saved")
need("self.presence = Presence.new(", all_source, "the sighting log is not restored")
need('mod.commands:register("rival_where"', all_source, "no location debug verb")
need("Presence = Presence,", all_source, "the model is not exported for tests")
need("edge.to or edge", main,
     "adjacency keys on edge records rather than map ids")

# --- preserved ---------------------------------------------------------------
for token in ("KantoCompat", "WonderTrade.install(mod, M)", "rivalGiftAllowed",
              "Relationships.headline", "TeamPlan = TeamPlan", "Story = Story"):
    need(token, main, f"earlier contract lost: {token}")
need("local SAVE_VERSION = 10", main, "save version regressed")
errors.extend(x for x in [at_least(root, "1.36.0")] if x)

if errors:
    for error in errors:
        print("FAIL", error)
    raise SystemExit(1)
print("AI Rivals v1.36 Living Kanto: read-only observer, budgeted sightings, "
      "familiarity affects speed not access, §17 not duplicated PASS")
