from pathlib import Path
root = Path(__file__).parents[1]
main = (root / "main.lua").read_text()
all_source = main + "\n" + "\n".join(p.read_text() for p in (root / "src").rglob("*.lua"))
poke = (root / "src" / "Pokegear.lua").read_text()

start = all_source.index("function M:rivalDetailItems")
end = all_source.index("function M:rivalInfoItems", start)
primary = main[start:end]
for label in ("CHALLENGE", "ACCOMPANY", "TRADE", "GIVE HELP", "RIVAL INFO", "GOODBYE"):
    assert label in primary
assert primary.count("value =") == 6, "face-to-face menu should stay compact"
assert 'SCREEN .. "Info"' in all_source
assert 'if #label > 10 then label = label:sub(1, 10) end' in all_source
assert '13 - #label - (right ~= "" and 2 or 0)' in all_source
assert 'battleMode == "DOUBLE" and "2V2" or "1V1"' in all_source
assert 'right = M.companionId == rival.id and "ON" or "JOIN"' in all_source
assert 'if #label > 11 then label = label:sub(1, 11) end' in all_source

assert 'AIR_RivalGearTournamentMode' in poke
assert 'label = "STANDARD"' in poke
assert 'label = "DOUBLE"' in poke
assert 'local doubleOK = playerHealthy >= 2 and doubleMax >= count' in poke
assert 'manager:arrangeTournament(arg and arg.hostId, count, mode, arg and arg.venueMap)' in poke
assert 'value = "_format"' not in poke[poke.index('AIR_RivalGearTournament", {'):poke.index('AIR_RivalGearTournamentMode", {')]
print("compact rival talk + explicit tournament mode static PASS")
