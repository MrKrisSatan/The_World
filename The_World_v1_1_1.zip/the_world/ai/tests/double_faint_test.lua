-- Standalone: luajit mods/ai_rivals/tests/double_faint_test.lua
--
-- The double-battle faint softlock, and the invariant that rules it out.
--
-- REPORTED: "double battles get stuck in a loop when one Pokemon faints".
--
-- ROOT CAUSE: `__dbExecuteAction` BORROWS the canonical slots -- while a
-- partner acts or is acted on, battle.enemy/battle.enemy2 are swapped, because
-- many Gen 1 move effects still read battle.enemy internally.  A partner that
-- fainted INSIDE that borrow had its replacement written straight to
-- `battle.enemy2`, which mid-borrow held the real LEAD.  The lead battler was
-- overwritten and lost; the dead partner stayed in `battle.enemy`; the old
-- restore was guarded on battler identity, so it saw a changed pair and
-- skipped -- leaving a corpse in the lead slot permanently.
--
-- From then on `enemyMonFainted` was never reachable (the mod's onFaint saw
-- `__dbSideSlot == "enemy2"` on the lead and took the partner arm every time),
-- so the battle could never be won: menu -> move -> messages -> menu, forever.
-- executeAction no-ops on a target at 0 HP, which is why nothing visibly
-- happened while the loop ran.
--
-- The invariant asserted here is deliberately stronger than "it terminates":
--   a battle that has not resolved never has a fainted body in a lead slot.
-- That is the thing that was actually broken, and it fails loudly the frame it
-- breaks rather than 9000 frames later when the loop detector notices.
--
-- Fixture-based; needs no ROM.  The two `decorate*` seams this drives are
-- public exports precisely so this flow is reachable without a live overworld,
-- which is why it went untested (and unfixed) for so long.
package.path = "./?.lua;./?/init.lua;" .. package.path
if not _G.love then _G.love = require("tests.love_stub") end

local T = require("tests.modkit")
local Data = T.fixtures.fresh()

-- Benches deep enough that promote/refill/handover all actually run.  The
-- shipped fixture trainer has two mons, so in doubles both are out at once and
-- the whole replacement path is skipped -- which is exactly why the autoplay
-- only ever reproduced the bug against a bigger party.

local function requireBattleState()
  local candidates = {
    "src.battle.BattleState",
    "battle.BattleState",
    "BattleState",
  }
  local errors = {}
  for _, name in ipairs(candidates) do
    local ok, value = pcall(require, name)
    if ok and value then return value end
    errors[#errors + 1] = tostring(value)
  end
  error("AI Rivals: could not load BattleState (" .. table.concat(errors, " | ") .. ")")
end

local function party(n, level)
  local p = {}
  for i = 1, n do
    p[i] = { species = ({ "FIXMON_A", "FIXMON_B", "FIXMON_C" })[(i % 3) + 1],
             level = level }
  end
  return p
end
Data.trainers.OPP_FIX_BIG = { id = "OPP_FIX_BIG", index = 90, baseMoney = 10,
                              name = "BIG", parties = { party(6, 20) } }
Data.trainers.OPP_FIX_BIG2 = { id = "OPP_FIX_BIG2", index = 91, baseMoney = 10,
                               name = "BIG2", parties = { party(5, 20) } }

local run = T.sdk.loadMod("mods/ai_rivals", { data = Data })
T.eq(#run.errors, 0, "the mod loads clean (" .. tostring(run.errors[1]) .. ")")
local ex = run.loader.exports.ai_rivals

require("src.battle.TypeChart").load(Data)
local Pokemon = require("src.pokemon.Pokemon")
local BattleState = requireBattleState()

T.check(type(ex.decorateTrainerDouble) == "function",
  "the trainer-double staging seam is exported")
T.check(type(ex.decorateTrainerPairBattle) == "function",
  "the trainer-pair staging seam is exported")

local press = {}
local stack = { items = {} }
function stack:push(s) table.insert(self.items, s) end
function stack:top() return self.items[#self.items] end
function stack:pop() return table.remove(self.items) end

local allyLevel = 20
ex.companionActive = function() return true end
ex.registerAllySource({ id = "double_faint_test", priority = 1,
  provide = function() return Pokemon.new(Data, "FIXMON_C", allyLevel), true end })

local function makeGame(partyN, level)
  local p = {}
  for i = 1, partyN do p[i] = Pokemon.new(Data, "FIXMON_C", level) end
  return {
    data = Data,
    save = { party = p, player = { name = "RED" }, inventory = {},
             options = { battleStyle = "set" },
             pokedex = { seen = {}, owned = {} }, flags = {}, money = 0 },
    input = { wasPressed = function(_, k) return press[k] end,
              isDown = function(_, k) return press[k] end },
    mods = { exports = {} }, screens = {}, stack = stack,
  }
end

-- Play a whole double battle to its natural end, holding A to advance text and
-- answering any forced-replacement party menu with the first healthy mon.
-- Returns: outcome, frames, invariantBreach or nil.
local function autoplay(opts)
  math.randomseed(opts.seed)
  allyLevel = opts.allyLevel
  stack.items = {}
  local game = makeGame(opts.partyN, opts.playerLevel)
  local battle = BattleState.newTrainer(game, "OPP_FIX_BIG", 1)
  battle.game = game
  stack:push(battle)
  if opts.format == "pair" then
    battle = ex.decorateTrainerPairBattle(game, battle, "OPP_FIX_BIG2", 1)
  else
    battle = ex.decorateTrainerDouble(game, battle)
  end
  if not battle.__double then return "not-double" end
  -- the intro is a sprite/text sequence the headless stub cannot drive
  battle.phase = "menu"
  for _, m in ipairs(battle.enemyParty or {}) do m.level = opts.enemyLevel end

  local history = {}
  for frame = 1, opts.frames do
    for k in pairs(press) do press[k] = false end
    local top = stack:top()
    if top ~= battle then
      if top and top.screenId == "PartyMenu" and top.onSwitch then
        local pick
        for _, m in ipairs(top.party or game.save.party) do
          if (m.hp or 0) > 0 then pick = m break end
        end
        stack:pop()
        if not pick then return "party-menu-with-no-healthy-mon", frame end
        top.onSwitch(pick, top)
      else
        stack:pop()
      end
    else
      if frame % 2 == 0 then press.a = true end
      local ok, err = pcall(battle.update, battle, 1 / 60)
      if not ok then return "error: " .. tostring(err), frame end
    end

    -- THE INVARIANT, checked at a PLAYER-DECISION BOUNDARY.
    --
    -- A fainted body legitimately occupies the lead slot for many frames
    -- while its faint is being played out: the slide, the cry, the "X
    -- fainted!" box and the promote all ride the queue.  What is never legal
    -- is arriving back at the command menu -- queue drained, no text up, no
    -- screen pushed -- with a corpse still in the enemy lead.  That is the
    -- desync, and from there `enemyMonFainted` is unreachable and the battle
    -- cannot be won.  Checking at the boundary rather than every frame is
    -- what makes this assertion true of a healthy battle.
    local atBoundary = battle.phase == "menu" and #(battle.queue or {}) == 0
      and not battle.current and #stack.items == 1
    if not battle.result and atBoundary then
      if battle.enemy and battle.enemy.mon and battle.enemy.mon.hp <= 0 then
        return "resolved-none", frame, "a fainted foe holds the enemy lead slot"
      end
    end
    -- A borrow is taken and released inside one synchronous executeAction
    -- call, so it must never be observable from a frame boundary at all.
    if battle.__dbBorrow then
      return "resolved-none", frame, "a slot borrow outlived its action"
    end

    if battle.result then return "resolved:" .. battle.result, frame end

    history[#history + 1] = tostring(battle.phase) .. ":" .. #(battle.queue or {})
      .. ":" .. tostring(battle.player and battle.player.mon.hp)
      .. ":" .. tostring(battle.enemy and battle.enemy.mon.hp)
      .. ":" .. tostring(battle.enemy2 and battle.enemy2.mon.hp)
      .. ":" .. tostring(battle.player2 and battle.player2.mon.hp)
    -- a live battle visits many distinct states; a softlocked one cycles
    -- through a handful and never leaves them
    if frame > 900 then
      local set, n = {}, 0
      for j = frame - 599, frame do
        if not set[history[j]] then set[history[j]] = true; n = n + 1 end
      end
      if n <= 6 then return "resolved-none", frame, "battle looped without progressing" end
    end
  end
  return "unfinished", opts.frames
end

-- Both formats, both outcomes, and the shapes that matter: a lone player mon
-- (no bench to fall back on), a deep bench on both sides, and a losing side.
local CASES = {
  { format = "solo", partyN = 3, playerLevel = 20, allyLevel = 20, enemyLevel = 20 },
  { format = "solo", partyN = 1, playerLevel = 20, allyLevel = 20, enemyLevel = 20 },
  { format = "solo", partyN = 2, playerLevel = 40, allyLevel = 40, enemyLevel = 10 },
  { format = "solo", partyN = 6, playerLevel = 25, allyLevel = 25, enemyLevel = 20 },
  { format = "pair", partyN = 3, playerLevel = 20, allyLevel = 20, enemyLevel = 20 },
  { format = "pair", partyN = 1, playerLevel = 20, allyLevel = 20, enemyLevel = 20 },
  { format = "pair", partyN = 2, playerLevel = 40, allyLevel = 40, enemyLevel = 10 },
  { format = "pair", partyN = 6, playerLevel = 25, allyLevel = 25, enemyLevel = 20 },
  { format = "pair", partyN = 3, playerLevel = 30, allyLevel = 30, enemyLevel = 15 },
}

local played, breaches = 0, 0
for _, case in ipairs(CASES) do
  for seed = 1, 6 do
    local opts = {
      format = case.format, partyN = case.partyN,
      playerLevel = case.playerLevel, allyLevel = case.allyLevel,
      enemyLevel = case.enemyLevel, seed = seed, frames = 90000,
    }
    local outcome, frame, breach = autoplay(opts)
    played = played + 1
    if breach then breaches = breaches + 1 end
    local label = string.format("%s party=%d p=%d e=%d seed=%d",
      case.format, case.partyN, case.playerLevel, case.enemyLevel, seed)
    T.check(not breach,
      label .. ": slots stay consistent (" .. tostring(breach)
      .. " at frame " .. tostring(frame) .. ")")
    T.check(outcome == "resolved:win" or outcome == "resolved:lose"
            or outcome == "resolved:run",
      label .. ": the battle reaches an outcome (got " .. tostring(outcome) .. ")")
  end
end
T.eq(breaches, 0, "no slot desync across " .. played .. " played-out double battles")
T.check(played == #CASES * 6, "every configured double battle case ran")

-- The borrow is reversible on its own terms, not by battler identity: the
-- lead comes back even when the partner slot changed hands during the action.
do
  stack.items = {}
  local game = makeGame(2, 20)
  local battle = BattleState.newTrainer(game, "OPP_FIX_BIG", 1)
  battle.game = game
  stack:push(battle)
  battle = ex.decorateTrainerDouble(game, battle)
  T.check(battle.__double, "a trainer double stages for the borrow case")
  local lead, partner = battle.enemy, battle.enemy2
  T.check(lead ~= partner, "the two foes are distinct battlers")
  -- kill the partner with the action itself, which is what used to eat the lead
  battle.__dbExecuteAction(battle, battle.player, partner, { id = "FIX_TACKLE" })
  partner.mon.hp = 0
  battle:onFaint(partner)
  T.eq(battle.enemy, lead, "the lead survives a partner faint taken mid-action")
  T.check(battle.enemy.mon.hp > 0, "and the lead slot is not holding a corpse")
  T.check(battle.__dbBorrow == nil, "the borrow is released after the action")
  T.eq(battle.enemy.__dbSideSlot, "enemy1", "the lead's slot stamp is re-derived")
end

T.finish("ai_rivals double faint")
