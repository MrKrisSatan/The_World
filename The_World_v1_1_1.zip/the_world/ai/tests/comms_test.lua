-- Standalone: lua5.1 tests/comms_test.lua   (from mods/ai_rivals)
--
-- The 3.0.0 communications model (see docs/pokegear-feasibility.md).
--
-- The properties that matter: a number never changes once issued, a refusal is
-- remembered, calls are budgeted the way sightings are, and nothing here can
-- grow without bound.

local cache = {}
local function req(n)
  if cache[n] then return cache[n] end
  local f = assert(loadfile(n .. ".lua")); cache[n] = f(req, {}); return cache[n]
end
local Util, Comms = req("src/Util"), req("src/Comms")

local pass, fail = 0, 0
local function eq(a, b, m) if a == b then pass = pass + 1 else fail = fail + 1
  print(("FAIL %s (got %s want %s)"):format(m, tostring(a), tostring(b))) end end
local function ok(c, m) if c then pass = pass + 1 else fail = fail + 1; print("FAIL " .. m) end end

-- 1. NUMBERS (§34): deterministic in (seed, id), stable forever, varied.
for _, seed in ipairs({ 1, 999, 4294967295 }) do
  eq(Comms.numberFor(seed, "chris"), Comms.numberFor(seed, "chris"),
     "a number is stable for seed " .. seed)
end
ok(Comms.numberFor(1, "chris") ~= Comms.numberFor(2, "chris"),
   "different saves issue different numbers")
ok(Comms.numberFor(1, "chris") ~= Comms.numberFor(1, "matt"),
   "different contacts get different numbers")
ok(Comms.numberFor(1, "chris"):match("^%d%d%-%d%d%d%d$"),
   "the number is formatted as the Pokegear draws it")
eq(Comms.numberFor(1, nil), nil, "a missing id has no number")
eq(Comms.numberFor(1, ""), nil, "an empty id has no number")
-- collisions across a realistic Kanto network should be rare
local seen, collisions = {}, 0
for i = 1, 400 do
  local n = Comms.numberFor(77, "trainer_" .. i)
  if seen[n] then collisions = collisions + 1 end
  seen[n] = true
end
ok(collisions <= 12, "400 contacts collide rarely (" .. collisions .. ")")

-- 2. TYPES (§18) are a field, not a hierarchy -- §29 needs trainers to become
--    summonable later without a rewrite.
for _, t in ipairs(Comms.TYPES) do
  ok(Comms.isType(t), t .. " is a legal contact type")
  ok(type(Comms.typeLabel(t)) == "string", t .. " has a label")
end
ok(not Comms.isType("ROBOT"), "an unknown type is refused")

-- 3. JOINING (§11, §36): offered and accepted are different states.
local state = Comms.new()
eq(Comms.count(state), 0, "a new phone book is empty")
local rec = Comms.offer(state, "ernie", { name = "Ernie", kind = "TRAINER",
  personality = "FISHERMAN" }, 42)
ok(rec ~= nil, "a trainer can offer their number")
eq(rec.offered, true, "the offer is recorded")
eq(rec.accepted, false, "but the contact is not saved until the player accepts")
eq(#Comms.listed(state), 0, "and does not appear in the list yet")
ok(rec.number ~= nil, "the number is issued at offer time")
ok(Comms.accept(state, "ernie"), "the player accepts")
eq(#Comms.listed(state), 1, "and the contact is listed")

-- a refusal is remembered, so nobody nags
local shy = Comms.new()
Comms.offer(shy, "joey", { name = "Joey" }, 42)
ok(Comms.decline(shy, "joey"), "the player can decline")
eq(#Comms.listed(shy), 0, "a declined contact is not listed")
eq(Comms.accept(shy, "joey"), false, "and cannot be accepted afterwards")
local again = Comms.offer(shy, "joey", { name = "Joey" }, 42)
eq(again.accepted, false, "a declined trainer offering again is still declined")
eq(Comms.accept(state, "nobody"), false, "accepting an unknown contact fails")
eq(Comms.offer(state, "", {}, 42), nil, "an empty id is refused")
eq(Comms.offer(state, nil, {}, 42), nil, "a missing id is refused")

-- the number never changes once issued (§45)
local before = Comms.get(state, "ernie").number
Comms.offer(state, "ernie", { name = "Ernie" }, 999)
eq(Comms.get(state, "ernie").number, before,
   "a second offer NEVER reissues the number -- the saved contact must keep pointing at the same person")

-- 4. THE BUDGET (§28, §38, §39).
local busy = Comms.new()
Comms.offer(busy, "green", { name = "Green", kind = "RIVAL" }, 5)
Comms.accept(busy, "green")
ok(Comms.mayCall(busy, "green", 100000, {}), "an accepted contact may call")
eq(Comms.mayCall(busy, "green", 100000, { busy = true }), false,
   "§39: nothing calls during a battle, menu, cutscene or save")
Comms.record(busy, "green", "CHAT", 100000)
eq(Comms.mayCall(busy, "green", 100000 + 10, {}), false,
   "and not again immediately")
eq(Comms.mayCall(busy, "green", 100000 + Comms.CALL_COOLDOWN - 1, {}), false,
   "the per-contact cooldown is respected")
ok(Comms.mayCall(busy, "green", 100000 + Comms.CALL_COOLDOWN, {}),
   "and released when it expires")
-- a second contact still waits out the world-wide cooldown
Comms.offer(busy, "matt", { name = "Matt", kind = "RIVAL" }, 5)
Comms.accept(busy, "matt")
eq(Comms.mayCall(busy, "matt", 100000 + 10, {}), false,
   "a different contact waits out the world cooldown too")
eq(Comms.mayCall(busy, "unknown", 999999, {}), false, "an unknown contact never calls")
local unlisted = Comms.new()
Comms.offer(unlisted, "x", { name = "X" }, 1)
eq(Comms.mayCall(unlisted, "x", 999999, {}), false,
   "a contact the player never accepted never calls")

-- 5. REASONS are a closed set (§30).
for _, r in ipairs(Comms.REASONS) do
  ok(Comms.isReason(r), r .. " is a legal reason")
  ok(type(Comms.reasonLabel(r)) == "string", r .. " has a label")
end
eq(Comms.record(busy, "green", "BECAUSE_I_SAID_SO", 200000), nil,
   "an unnamed reason is refused rather than logged")
eq(Comms.record(busy, "nobody", "CHAT", 200000), nil, "so is an unknown contact")

-- 6. HISTORY AND MISSED CALLS (§31, §32), both bounded.
local log = Comms.new()
Comms.offer(log, "a", { name = "A" }, 1); Comms.accept(log, "a")
Comms.offer(log, "b", { name = "B" }, 1); Comms.accept(log, "b")
for i = 1, 200 do
  Comms.record(log, (i % 2 == 0) and "a" or "b", "REMATCH", i * 10,
    { missed = i % 5 == 0 })
end
ok(#Comms.get(log, "a").history <= Comms.HISTORY_LIMIT, "per-contact history is capped")
ok(#Comms.missedCalls(log) <= Comms.MISSED_LIMIT, "the missed-call list is capped")
local rows = Comms.callHistory(log, 5)
eq(#rows, 5, "call history returns what was asked for")
ok(rows[1].tick >= rows[2].tick, "and is newest first")
Comms.clearMissed(log)
eq(#Comms.missedCalls(log), 0, "checking the phone clears missed calls")

-- 7. BOUNDS AND CORRUPTION.
local big = Comms.new()
for i = 1, Comms.CONTACT_LIMIT + 40 do
  local r = Comms.offer(big, "c" .. i, { name = "C" .. i }, 1)
  if r then Comms.accept(big, "c" .. i) end
end
ok(Comms.count(big) <= Comms.CONTACT_LIMIT, "the contact list is capped (§35)")
local round = Comms.new(Comms.serialize(big))
ok(Comms.count(round) <= Comms.CONTACT_LIMIT, "and stays capped through a round trip")

local dirty = Comms.new({ contacts = {
  [7] = { name = "bad key" },
  good = { name = "Good", kind = "ROBOT", rematch = -3, lastCall = "soon",
           history = { { reason = "NOPE" }, "junk", { reason = "CHAT", tick = -9 } } },
}, missed = { "junk", { id = 5 }, { id = "good", reason = "NOPE" } } })
eq(Comms.get(dirty, "good").kind, "TRAINER", "a corrupt type falls back")
eq(Comms.get(dirty, "good").rematch, 0, "a negative counter is repaired")
eq(Comms.get(dirty, "good").lastCall, 0, "a corrupt timestamp is repaired")
eq(#Comms.get(dirty, "good").history, 1, "malformed history rows are dropped")
ok(Comms.get(dirty, "good").history[1].tick >= 0, "a negative tick is repaired")
eq(Comms.count(dirty), 1, "a non-string contact key is dropped")
eq(#Comms.missedCalls(dirty), 1, "malformed missed rows are dropped")
eq(Comms.missedCalls(dirty)[1].reason, "CHAT", "with an unknown reason repaired")

-- 8. DETERMINISM: listing order must not depend on pairs().
local ordered = Comms.new()
for _, row in ipairs({ { "z", "TRAINER" }, { "a", "RIVAL" }, { "m", "PROFESSOR" } }) do
  Comms.offer(ordered, row[1], { name = row[1]:upper(), kind = row[2] }, 1)
  Comms.accept(ordered, row[1])
end
local function sig()
  local out = {}
  for _, c in ipairs(Comms.listed(ordered)) do out[#out + 1] = c.id end
  return table.concat(out, ",")
end
eq(sig(), sig(), "the contact list order is stable")
eq(sig(), "a,z,m", "§37: rivals first, then trainers, then professors")

-- 9. §27 priorities exist and are ordered, so a summon cannot outrank a story
--    event later.
ok(Comms.PRIORITY.STORY < Comms.PRIORITY.SUMMON,
   "a critical story event outranks a player summon")
ok(Comms.PRIORITY.SUMMON < Comms.PRIORITY.TRAIN,
   "but a summon outranks routine training")
ok(Comms.PRIORITY.ROCKET < Comms.PRIORITY.SUMMON,
   "and a Rocket operation outranks it (§50)")

-- 10. No live randomness or clock anywhere in the model.
local src = io.open("src/Comms.lua"):read("*a")
local code = {}
for line in src:gmatch("[^\n]*") do
  if not line:match("^%s*%-%-") then code[#code + 1] = line end
end
code = table.concat(code, "\n")
for _, banned in ipairs({ "math.random", "os.time", "os.clock", "love." }) do
  ok(not code:find(banned, 1, true),
     "the model is deterministic and headless (" .. banned .. ")")
end

print(("\n%d passed, %d failed"):format(pass, fail))
os.exit(fail == 0 and 0 or 1)
