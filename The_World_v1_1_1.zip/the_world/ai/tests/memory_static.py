"""Static contracts for v1.32 bounded rival memory."""
from pathlib import Path
import re
import json, sys
root = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(Path(__file__).resolve().parent))
from _version import at_least
mem = (root / "src" / "Memory.lua").read_text(encoding="utf-8")
rival = (root / "src" / "Rival.lua").read_text(encoding="utf-8")
main = (root / "main.lua").read_text(encoding="utf-8")
manifest = json.loads((root / "manifest.json").read_text(encoding="utf-8"))
required = ["Memory.EVENT_LIMIT = 40", "Memory.playerBattle", "favouriteLead",
            "commonMove", "while #m.events > Memory.EVENT_LIMIT",
            "memory = Memory.serialize(self.memory)", "Memory.new(saved.memory)",
            "rival:rememberPlayerBattle(observation)"]
missing = [x for x in required if x not in mem + rival + main]
# the save schema only ever moves forward; memory shipped at 5
schema = int(re.search(r"local SAVE_VERSION = (\d+)", main).group(1))
if schema < 5: missing.append(f"save schema regressed to {schema}")
missing.extend(x for x in [at_least(root, "1.32.0")] if x)
if missing: raise SystemExit("v1.32 memory contract failed: " + "; ".join(missing))
print("AI Rivals v1.32 bounded memory contract PASS")