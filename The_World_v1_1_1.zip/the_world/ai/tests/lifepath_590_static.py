from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
life=(ROOT/'src/LifePath.lua').read_text()
league=(ROOT/'src/League.lua').read_text()
main=(ROOT/'main.lua').read_text()
sim=(ROOT/'src/Simulation.lua').read_text()
manifest=(ROOT/'manifest.json').read_text()
assert '"version": "5.9.0"' in manifest
assert 'function LifePath.assumeChampion' in life
assert 'preChampionPath' in life
assert 'function LifePath.leaveChampion' in life
assert 'function League.earnedChampion' in league
assert 'rival:earnedChampionTitle()' in main
assert '"CHAMPION", "defending the Pokemon League title"' in main
assert 'assumeChampionLifePath' in sim
assert 'leaveChampionLifePath' in sim
print('5.9.0 Life Paths/Champion static checks passed')
