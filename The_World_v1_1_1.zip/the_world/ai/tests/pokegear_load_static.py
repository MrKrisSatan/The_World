from pathlib import Path
import json

ROOT = Path(__file__).resolve().parents[1]
source = (ROOT / "src/RivalGear.lua").read_text(encoding="utf-8")
manifest = json.loads((ROOT / "manifest.json").read_text(encoding="utf-8"))

assert "\nocal req, mod = ..." not in source, "broken duplicated Pokegear module header returned"
assert source.count("local req, mod = ...") == 1, "Pokegear must be one Lua module, not two concatenated copies"
assert 'mod.content.screens:register("AIR_RivalGear"' in source
assert 'label = "POKEGEAR"' in source
assert 'mod.hooks:wrap("ui.start_menu.items"' in source
assert set(manifest.get("games", [])) == {"red", "blue", "yellow", "gold"}
assert manifest.get("gen2compat") is True
print("Pokegear load/targeting checks passed")
