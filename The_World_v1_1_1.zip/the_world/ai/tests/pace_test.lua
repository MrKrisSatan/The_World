-- Standalone: lua5.1 tests/pace_test.lua   (from mods/ai_rivals)
--
-- "Rivals should try to stay close to the player in level and on routes; they
--  should never for example be three gyms ahead."
--
-- Two levers, and the second falls out of the first:
--
--   BADGES  a rival may lead by at most Rival.BADGE_LEAD.
--   ROUTES  Rival:canEnterMap gates the campaign on the rival's OWN badge
--           count, so capping badges caps how far across Kanto they roam.
--           That is asserted here rather than assumed.
--
-- The bug this release fixed: Can.GYM read `world.playerBadges`, but the
-- per-tick ctx the simulation builds never carried that field, so the cap
-- silently compared against 0 on the path that runs most of the time.

local cache = {}
local function req(n)
  if cache[n] then return cache[n] end
  local f = assert(loadfile(n .. ".lua")); cache[n] = f(req, {}); return cache[n]
end
local Util, Rival, AI = req("src/Util"), req("src/Rival"), req("src/AI")
local GYMS, PERS, ROSTER = req("data/gyms"), req("data/personalities"), req("data/rivals")

local pass, fail = 0, 0
local function eq(a, b, m) if a == b then pass = pass + 1 else fail = fail + 1
  print(("FAIL %s (got %s want %s)"):format(m, tostring(a), tostring(b))) end end
local function ok(c, m) if c then pass = pass + 1 else fail = fail + 1; print("FAIL " .. m) end end

local DATA = { pokemon = { MON = { baseStats = { hp = 60, attack = 60,
  defense = 60, speed = 60, special = 60 }, types = { "NORMAL" },
  level1Moves = { "TACKLE" }, learnset = {} } },
  moves = { TACKLE = { power = 40, type = "NORMAL" } },
  constants = { fallbackMove = "TACKLE" }, type_chart = { matchups = {} } }

local function make()
  local r = Rival.new(ROSTER[1], { data = DATA, personalities = PERS,
    -- Rival:routeTo calls graph:route, so the stub needs it or Can.GYM raises.
    graph = { has = function() return true end,
              neighbours = function() return {} end,
              route = function(_, from, to) return { from, to } end,
              routeAllowed = function(_, from, to) return { from, to } end },
    gyms = GYMS,
    -- AI.weatherEdge asks the compat handle for the sky; a stub that only
    -- answers krAllows raises inside Can.GYM.
    compat = { krAllows = function() return true end,
               weather = function() return false end,
               weatherId = function() return nil end,
               battleWeather = function() return nil end,
               exports = function() return nil end } })
  r.ticks, r.map = 0, "PALLET_TOWN"
  return r
end

-- 1. THE BADGE LEAD.
local r = make()
eq(r:playerBadges(), 0, "a rival that has not been told reads the player at 0")
eq(r:badgeLead(), 0, "and leads by nothing")
ok(r:mayEarnBadge(), "so it may win its first badge")

r.playerPaceBadges = 0
r.badges[GYMS.order[1]] = true
eq(r:badgeLead(), 1, "one badge with the player on none is a lead of one")
eq(r:mayEarnBadge(), false,
   "and it may NOT win a second -- this is the whole requirement")

r.playerPaceBadges = 1
ok(r:mayEarnBadge(), "the player earning a badge releases it")
r.badges[GYMS.order[2]] = true
eq(r:mayEarnBadge(), false, "and it stops again one ahead")

-- it can never reach three ahead by any amount of waiting
for tick = 1, 500 do
  if r:mayEarnBadge() then r.badges[GYMS.order[r:badgeCount() + 1] or "X"] = true end
end
ok(r:badgeLead() <= Rival.BADGE_LEAD,
   "500 opportunities never put it past the lead (" .. r:badgeLead() .. ")")
ok(r:badgeLead() < 3, "it is NEVER three gyms ahead")

-- a rival BEHIND the player is not held back
local behind = make()
behind.playerPaceBadges = 5
ok(behind:mayEarnBadge(), "a rival behind the player may catch up freely")
behind.badges[GYMS.order[1]] = true
ok(behind:mayEarnBadge(), "and keep catching up")

-- an unknown player reads as 0, never as permission
local blind = make()
blind.playerPaceBadges = nil
blind.badges[GYMS.order[1]] = true
eq(blind:mayEarnBadge(), false,
   "an unknown player count is treated as 0, not as unlimited")

-- 2. THE OBJECTIVE GATE AND THE AWARD GATE AGREE.
local gated = make()
gated.badges[GYMS.order[1]] = true
gated:addPokemon("MON", 10)
eq(AI.Can.GYM(gated, { playerBadges = 0 }), false,
   "Can.GYM refuses while the rival is already a badge ahead")
eq(gated.playerPaceBadges, 0, "and records the reading it was given")
-- ...and the reading reaches mayEarnBadge, which attemptGym also calls
eq(gated:mayEarnBadge(), false, "so the award-time rule agrees with it")
AI.Can.GYM(gated, { playerBadges = 4 })
eq(gated.playerPaceBadges, 4, "a later reading updates it")
ok(gated:mayEarnBadge(), "and both gates open together")

-- THE BUG: a world object with no playerBadges must not read as permission
local stale = make()
stale.playerPaceBadges = 0
stale.badges[GYMS.order[1]] = true
stale:addPokemon("MON", 10)
eq(AI.Can.GYM(stale, {}), false,
   "a world object MISSING playerBadges does not silently unlock the gym")
eq(AI.Can.GYM(stale, nil), false, "nor does a missing world object")
eq(stale.playerPaceBadges, 0, "and neither overwrites the last real reading")

-- 3. LEVELS track the player, including before they have a party.
local lv = make()
lv.playerPaceLevel = nil
ok(lv:levelCeiling() <= Rival.OPENING_LEVEL_CAP,
   "with no player party the ceiling is the opening cap, not 100")
ok(Rival.OPENING_LEVEL_CAP < 20, "which is genuinely low")
lv.playerPaceLevel = 30
local ceiling = lv:levelCeiling()
ok(ceiling <= 33, "the ceiling tracks the player's lead + 3 (" .. ceiling .. ")")
ok(ceiling > 8, "and rises with them")
lv.playerPaceLevel = 12
ok(lv:levelCeiling() < ceiling, "and comes back down if the player is behind")
-- the gym ceiling still binds where it is lower
lv.playerPaceLevel = 90
ok(lv:levelCeiling() <= 90,
   "a distant gym still caps below the player's level when it is the lower bound")

-- 4. ROUTES follow badges, so no second mechanism is needed.
local roam = make()
roam.playerPaceBadges = 0
eq(roam:canEnterMap("CERULEAN_CITY"), false,
   "a badgeless rival cannot roam to Cerulean")
roam.badges[GYMS.order[1]] = true
ok(roam:canEnterMap("CERULEAN_CITY"),
   "one badge opens Cerulean, exactly as it does for the player")
eq(roam:canEnterMap("FUCHSIA_CITY"), false,
   "but a one-badge rival still cannot be four cities ahead")
eq(roam:canEnterMap("CINNABAR_ISLAND"), false, "nor at the far end of Kanto")

-- 5. PERSISTENCE: pacing survives a load, or a reload grants a free level.
local saved = make()
saved.playerPaceLevel, saved.playerPaceBadges = 22, 3
local blob = saved:serialize()
local back = Rival.new(ROSTER[1], saved.ctx)
ok(back:restore(blob), "a rival with pacing restores")
eq(back.playerPaceLevel, 22, "the level reading survives save/load")
eq(back.playerPaceBadges, 3, "and so does the badge reading")
ok(back:levelCeiling() <= 25,
   "so the ceiling is not briefly wide open after loading")
-- a pre-3.2 save simply has no reading, and reads as 0 rather than unlimited
blob.playerPaceLevel, blob.playerPaceBadges = nil, nil
local old = Rival.new(ROSTER[1], saved.ctx)
ok(old:restore(blob), "a pre-3.2 save record still restores")
eq(old:playerBadges(), 0, "with the player read as 0")
ok(old:levelCeiling() <= Rival.OPENING_LEVEL_CAP,
   "and the opening cap applied rather than none")

-- ------------------------------------------------------------------
-- 6. A LONG RUN. Pacing is exactly the kind of claim that holds in a unit
--    test and drifts over hours, so the gap is measured every tick of a
--    simulated playthrough rather than only at the end.
-- ------------------------------------------------------------------
do
  local rivals = {}
  for i = 1, #ROSTER do
    local rr = Rival.new(ROSTER[i], {
      data = DATA, personalities = PERS,
      graph = { has = function() return true end,
                neighbours = function() return {} end,
                route = function(_, a, b) return { a, b } end,
                routeAllowed = function(_, a, b) return { a, b } end },
      gyms = GYMS,
      compat = { krAllows = function() return true end,
                 weather = function() return false end,
                 weatherId = function() return nil end,
                 battleWeather = function() return nil end,
                 exports = function() return nil end } })
    rr.ticks, rr.map = 0, "PALLET_TOWN"
    rr:addPokemon("MON", 5)
    rivals[i] = rr
  end

  -- A deliberately SLOW player: one badge every 2500 ticks, levelling gently.
  -- The rivals are given a chance to take a badge far more often than that,
  -- which is precisely the pressure that used to let them run away.
  local playerBadges, playerLevel = 0, 6
  local worstBadgeLead, worstLevelLead = 0, 0
  for tick = 1, 24000 do
    if tick % 2500 == 0 then playerBadges = math.min(8, playerBadges + 1) end
    if tick % 600 == 0 then playerLevel = math.min(60, playerLevel + 1) end
    for i, rr in ipairs(rivals) do
      rr.ticks = tick
      rr.playerPaceBadges = playerBadges
      rr.playerPaceLevel = playerLevel
      -- offered a badge every 200 ticks -- far faster than the player earns
      if tick % 200 == 0 and rr:mayEarnBadge() then
        local next_ = GYMS.order[rr:badgeCount() + 1]
        if next_ then rr.badges[next_] = true end
      end
      -- and free experience every tick, so only the ceiling holds it back
      if tick % 50 == 0 then rr:gainExp(400) end
      worstBadgeLead = math.max(worstBadgeLead, rr:badgeLead())
      worstLevelLead = math.max(worstLevelLead,
        math.floor(rr:averageLevel()) - playerLevel)
    end
  end
  print(("  24000 ticks: worst badge lead %d, worst level lead %d")
    :format(worstBadgeLead, worstLevelLead))
  ok(worstBadgeLead <= Rival.BADGE_LEAD,
     "no rival EVER exceeded the badge lead across a full playthrough")
  ok(worstBadgeLead < 3, "and none was ever three gyms ahead")
  ok(worstLevelLead <= 6,
     "nor did any run away on level (" .. worstLevelLead .. ")")
  -- ...and they did not stall either: pacing must not freeze the world
  local moved = 0
  for _, rr in ipairs(rivals) do
    if rr:badgeCount() >= 6 then moved = moved + 1 end
  end
  ok(moved == #rivals,
     "every rival still kept up with the player rather than stalling")
end

print(("\n%d passed, %d failed"):format(pass, fail))
os.exit(fail == 0 and 0 or 1)
