-- Standalone: lua5.1 tests/gen2_region_test.lua   (from mods/ai_rivals)
--
-- "In gen 2 gold the rivals are starting in Kanto. That's post game in gen 2."
--
-- Two causes, both real:
--
--  1. The post-gauntlet starting maps were Kanto-only literals, and Gold's map
--     table CONTAINS every Kanto map -- they are simply unreachable until the
--     Elite Four is beaten. So the four were released straight into postgame.
--  2. The campaign progression floors only engage when byBadge.BOULDERBADGE
--     exists, which is the KANTO badge table. On Gold byBadge is the Johto
--     table, so that whole block was skipped and a rival had NO floor at all --
--     free to walk the raw connection graph wherever it liked.

local cache = {}
local function req(n)
  if cache[n] then return cache[n] end
  local f = assert(loadfile(n .. ".lua")); cache[n] = f(req, {}); return cache[n]
end
local Rival, ROSTER = req("src/Rival"), req("data/rivals")
local GYMS, PERS = req("data/gyms"), req("data/personalities")

local pass, fail = 0, 0
local function eq(a, b, m) if a == b then pass = pass + 1 else fail = fail + 1
  print(("FAIL %s (got %s want %s)"):format(m, tostring(a), tostring(b))) end end
local function ok(c, m) if c then pass = pass + 1 else fail = fail + 1; print("FAIL " .. m) end end

-- 1. THE REGION SPLIT. Gold's Johto routes are 26+, Kanto's are 25 and below.
for _, id in ipairs({ "ROUTE_1", "ROUTE_10", "ROUTE_25", "PALLET_TOWN",
                      "VIRIDIAN_CITY", "CERULEAN_CITY", "SAFFRON_CITY",
                      "CINNABAR_ISLAND", "MT_MOON_1F", "ROCK_TUNNEL_1F",
                      "SILPH_CO_2F", "SAFARI_ZONE_GATE" }) do
  ok(Rival.isKantoOnGold(id), id .. " is Kanto on Gold")
end
for _, id in ipairs({ "ROUTE_26", "ROUTE_29", "ROUTE_30", "ROUTE_48",
                      "NEW_BARK_TOWN", "CHERRYGROVE_CITY", "VIOLET_CITY",
                      "GOLDENROD_CITY", "BLACKTHORN_CITY", "AZALEA_TOWN",
                      "ECRUTEAK_CITY", "MAHOGANY_TOWN" }) do
  ok(not Rival.isKantoOnGold(id), id .. " is Johto, reachable in the main story")
end
-- INDIGO_PLATEAU is the JOHTO league too, reached from Route 26. Blocking it
-- would wall a rival out of its own main story.
ok(not Rival.isKantoOnGold("INDIGO_PLATEAU"),
   "Indigo Plateau is NOT gated -- it is Johto's league as well as Kanto's")
eq(Rival.isKantoOnGold(nil), false, "a missing map id is not Kanto")
eq(Rival.isKantoOnGold(12345), false, "a non-string is not Kanto")

-- 2. THE GATE, through a real rival on a Gold-shaped context.
local DATA = { pokemon = { MON = { baseStats = { hp = 50, attack = 50,
  defense = 50, speed = 50, special = 50 }, types = { "NORMAL" },
  level1Moves = { "TACKLE" }, learnset = {} } },
  moves = { TACKLE = { power = 40, type = "NORMAL" } },
  constants = { fallbackMove = "TACKLE" }, type_chart = { matchups = {} } }

local function goldRival()
  local r = Rival.new(ROSTER[1], {
    data = DATA, personalities = PERS,
    graph = { has = function() return true end, neighbours = function() return {} end },
    gyms = GYMS.gen2,
    compat = { krAllows = function() return true end },
  })
  r.ticks, r.map = 0, "NEW_BARK_TOWN"
  return r
end
local function kantoRival()
  local r = Rival.new(ROSTER[1], {
    data = DATA, personalities = PERS,
    graph = { has = function() return true end, neighbours = function() return {} end },
    gyms = GYMS, compat = { krAllows = function() return true end },
  })
  r.ticks, r.map = 0, "PALLET_TOWN"
  return r
end

local gold = goldRival()
ok(GYMS.gen2 and GYMS.gen2.byBadge and GYMS.gen2.byBadge.ZEPHYR,
   "the fixture really is the Johto badge table")
eq(gold:canEnterMap("ROUTE_29"), true, "a Gold rival may walk Johto's Route 29")
eq(gold:canEnterMap("CHERRYGROVE_CITY"), true, "and reach Cherrygrove")
eq(gold:canEnterMap("ROUTE_1"), false,
   "but may NOT walk into Kanto before the League -- that is postgame")
eq(gold:canEnterMap("CERULEAN_CITY"), false, "nor into a Kanto city")

-- ...and Kanto opens once the League is beaten, exactly as it does for the player
gold.champion = true
eq(gold:canEnterMap("ROUTE_1"), true, "beating the League opens Kanto")
eq(gold:canEnterMap("CERULEAN_CITY"), true, "including its cities")

-- 3. A GEN 1 BOOT IS COMPLETELY UNAFFECTED. The new gate must not fire where
--    Kanto IS the main story.
local kanto = kantoRival()
ok(GYMS.byBadge and GYMS.byBadge.BOULDERBADGE,
   "the fixture really is the Kanto badge table")
eq(kanto:canEnterMap("ROUTE_1"), true, "a Gen 1 rival may walk Route 1 from the start")
eq(kanto:canEnterMap("VIRIDIAN_CITY"), true, "and reach Viridian")
-- the existing Kanto campaign floors still apply and still gate on badges
eq(kanto:canEnterMap("CERULEAN_CITY"), false,
   "while Cerulean still needs a badge, as it always did")

-- 4. THE ROSTER'S OWN DATA no longer sends anyone to Kanto on Gold.
for _, def in ipairs(ROSTER) do
  local maps = def.homeMaps
  ok(type(maps) == "table" and type(maps[1]) ~= "string",
     def.id .. ": home maps are version-keyed, not a flat Kanto list")
  ok(type(maps.gen2) == "table" and #maps.gen2 > 0,
     def.id .. ": has a Gold home set")
  for _, id in ipairs(maps.gen2 or {}) do
    ok(not Rival.isKantoOnGold(id),
       def.id .. ": Gold home map " .. id .. " is in Johto")
  end
  for _, id in ipairs(maps.default or {}) do
    ok(Rival.isKantoOnGold(id) or id == "INDIGO_PLATEAU",
       def.id .. ": Gen 1 home map " .. id .. " is still Kanto")
  end
end

-- 5. And the four Gold homes are not all the same tile.
local seen = {}
for _, def in ipairs(ROSTER) do
  local first = def.homeMaps.gen2 and def.homeMaps.gen2[1]
  if first then seen[first] = (seen[first] or 0) + 1 end
end
local distinct = 0
for _ in pairs(seen) do distinct = distinct + 1 end
ok(distinct >= 3, "the four rivals do not all start on one Johto tile")

print(("\n%d passed, %d failed"):format(pass, fail))
os.exit(fail == 0 and 0 or 1)
