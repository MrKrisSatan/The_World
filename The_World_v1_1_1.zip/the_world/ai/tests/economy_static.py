#!/usr/bin/env python3
"""Static contracts for v1.38 Rival Economy.

Behaviour is proven by the two Lua suites. This file guards the structural
rules: that money moves through exactly one door, that no site mutates a purse
by hand, that the ledger is bounded by a fixed category set, and that the
spending profile is derived from data that already existed rather than a new
file nobody maintains.
"""
import re
import sys
from pathlib import Path

root = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(Path(__file__).resolve().parent))
from _version import at_least

economy = (root / "src" / "Economy.lua").read_text(encoding="utf-8")
rival = (root / "src" / "Rival.lua").read_text(encoding="utf-8")
sim = (root / "src" / "Simulation.lua").read_text(encoding="utf-8")
main = (root / "main.lua").read_text(encoding="utf-8")
all_source = main + "\n" + "\n".join(p.read_text(encoding="utf-8") for p in (root / "src").rglob("*.lua"))
personalities = (root / "data" / "personalities.lua").read_text(encoding="utf-8")
errors = []


def need(token, blob, label):
    if token not in blob:
        errors.append(label)


def code_of(blob):
    return "\n".join(l for l in blob.splitlines() if not l.lstrip().startswith("--"))


# --- one money door ----------------------------------------------------------
need("function Rival:earn", rival, "no income door")
need("function Rival:spend", rival, "no spending door")
need("function Rival:forfeit", rival, "no forfeit door")
# spend must refuse rather than overdraw -- this is §38's hard rule
# Anchor on the FULL signature: `Rival:spendBall` predates `Rival:spend` in
# this file and prefix-matches it, which silently slices the wrong body.
spend = rival[rival.index("function Rival:spend(amount, category)"):]
spend = spend[:spend.index("\nend")]
need("if amount > purse then return 0 end", spend,
     "spend() can overdraw the purse")
need("Economy.recordSpend", spend, "spend() does not reach the ledger")

# No site outside those doors may add to a purse. `self.money = purse - amount`
# inside the doors is expected; a bare `+` anywhere is not.
# The doors themselves are the only place a purse may be assigned from an
# arithmetic expression. Everything else must call them.
DOORS = ("function Rival:earn", "function Rival:spend(amount, category)",
         "function Rival:forfeit")
door_spans = []
for door in DOORS:
    start = rival.index(door)
    door_spans.append((start, rival.index("\nend", start)))


def inside_a_door(pos):
    return any(lo <= pos <= hi for lo, hi in door_spans)


for match in re.finditer(r"^[ \t]*(\w+)\.money\s*=\s*(.+)$", rival, re.M):
    if inside_a_door(match.start()):
        continue
    if "+" in match.group(2) and "STARTING_MONEY" not in match.group(2):
        errors.append("Rival adds to a purse outside the door: "
                      + match.group(2)[:50])
# 4.7.0: the PLAYER's wallet is not a rival purse.
#
# The doors above exist so that a hundred rivals cannot each invent money;
# `M:givePlayerMoney` is the player's single prize-money door and it has its own
# ceiling (M.MAX_PRIZE_MONEY) plus the engine's. Excluding it by NAME rather
# than loosening the pattern keeps the rule exactly as strict everywhere else --
# an exception with a name is a decision, an exception in a regex is a hole.
PLAYER_DOOR = "function M:givePlayerMoney"


def door_span(scanned):
    """The player-money door's span WITHIN the string actually being scanned.

    code_of() strips comment lines, so an offset taken from the raw file does
    not address the same byte in the stripped copy -- the exact prefix-anchor
    class of mistake that keeps costing this project (lesson 2). Compute it
    against the string the regex runs over.
    """
    if PLAYER_DOOR not in scanned:
        return None
    start = scanned.index(PLAYER_DOOR)
    return (start, scanned.index("\nend", start))

for name, blob in (("Simulation", sim), ("main", main)):
    scanned = code_of(blob)
    player_door_span = door_span(scanned) if name == "main" else None
    for match in re.finditer(r"^[ \t]*(\w+)\.money\s*=\s*(.+)$", scanned, re.M):
        expr = match.group(2)
        if "+" not in expr:
            continue
        # a guarded fallback for an object that predates the door is allowed;
        # a bare add is not
        if player_door_span and player_door_span[0] <= match.start() <= player_door_span[1]:
            continue
        line_start = scanned.rfind("\n", 0, match.start())
        preceding = scanned[max(0, line_start - 120):match.start()]
        if ".earn then" not in preceding:
            errors.append(f"{name} adds to a purse outside the door: {expr[:50]}")

# every fallback add must be guarded by a presence check on the door
for guard, fallback in (("if rival.earn then", "rival.money = (tonumber(rival.money) or 0) + money"),
                        ("if winner.earn then", "winner.money = (tonumber(winner.money) or 0) + taken")):
    if fallback in sim and guard not in sim:
        errors.append(f"an unguarded direct purse add remains: {fallback[:40]}")

# --- the ledger is bounded ---------------------------------------------------
need("Economy.CATEGORIES", economy, "categories are not a closed set")
need("function Economy.newLedger", economy, "no ledger constructor")
need("function Economy.recordSpend", economy, "no spend recorder")
# there must be NO transaction list -- that is the unbounded save table
for banned in ("table.insert(ledger", "ledger.log", "ledger.history",
               "ledger[#ledger"):
    if banned in economy:
        errors.append(f"the ledger keeps an unbounded transaction list ({banned})")
need("math.min(9999999", economy, "ledger totals are uncapped")
# the ledger must rebuild exactly the category set, dropping anything else
newledger = economy[economy.index("function Economy.newLedger"):]
newledger = newledger[:newledger.index("\nend")]
need("for _, category in ipairs(Economy.CATEGORIES)", newledger,
     "the ledger is rebuilt from stored keys rather than the fixed category list")

# --- budgets cannot mint money ----------------------------------------------
need("function Economy.budget", economy, "no budget allocator")
budget = economy[economy.index("function Economy.budget"):]
budget = budget[:budget.index("\nend")]
need("math.floor(spendable * share)", budget,
     "budget shares are not floored, so rounding can hand out more than the purse")
need("if handed > spendable then", budget,
     "a malformed profile could mint money")

# --- the profile is derived, not a new data file -----------------------------
need("function Economy.profile", economy, "no spending profile")
for field in ("catchChance", "trainRate", "challengeChance",
              "rivalFightChance", "wanderChance"):
    if field not in economy:
        errors.append(f"the profile ignores the existing personality field {field}")
    if field not in personalities:
        errors.append(f"personality field {field} vanished -- the profile would flatten")
# no new data file smuggled in
if (root / "data" / "economy.lua").exists():
    errors.append("a new economy data file was added; the profile must derive "
                  "from personalities that already describe the behaviour")
# shares must be normalised, or a new category silently inflates spending
need("out[category] = total > 0 and math.max(0, w[category]) / total or 0", economy,
     "profile shares are not normalised")

for banned in ("math.random", "os.time", "os.clock", "love."):
    if banned in economy:
        errors.append(f"the economy model is not deterministic ({banned})")

# --- shopping is budgeted, not a fixed walk ----------------------------------
need("local budget = Economy.budget(spendable, profile)", rival,
     "shopping does not allocate a budget")
need("local afford = math.floor((budget[category] or 0) / spec.price)", rival,
     "a category can spend outside its budget")
need('if self:itemCount("POKE_BALL") == 0 then', rival,
     "no emergency ball purchase -- a rival could be stranded unable to catch")
need("Economy.targetFor(item, spec, profile, self.personality)", rival,
     "stock targets ignore the spending profile")

# --- surfaces ----------------------------------------------------------------
need('mod.commands:register("rival_economy"', all_source, "no economy debug verb")
need('label = "SPENDS ON"', main, "the detail screen does not show funding")
need("Economy = Economy,", main, "the model is not exported for tests")

# --- preserved ---------------------------------------------------------------
for token in ("KantoCompat", "WonderTrade.install(mod, M)", "rivalGiftAllowed",
              "Relationships.headline", "TeamPlan = TeamPlan", "Story = Story",
              "Presence = Presence", "Weather = Weather"):
    need(token, main, f"earlier contract lost: {token}")
need("local SAVE_VERSION = 10", main, "save version regressed")
errors.extend(x for x in [at_least(root, "1.38.0")] if x)

if errors:
    for error in errors:
        print("FAIL", error)
    raise SystemExit(1)
print("AI Rivals v1.38 Economy: one money door, bounded ledger, budgets that "
      "cannot mint, profiles derived from existing personality data PASS")
