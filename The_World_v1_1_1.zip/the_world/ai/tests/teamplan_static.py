#!/usr/bin/env python3
"""Static contracts for v1.34 team identity.

Behaviour is proven by the three standalone Lua suites. This file guards what a
static read can: that the identity is seeded from the field that already
existed, that it never overrides a real matchup, that every battle path credits
service, that RNG streams were not disturbed, and that nothing is unbounded.
"""
import json
import re
import sys
from pathlib import Path

root = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(Path(__file__).resolve().parent))
from _version import at_least

plan = (root / "src" / "TeamPlan.lua").read_text(encoding="utf-8")
rival = (root / "src" / "Rival.lua").read_text(encoding="utf-8")
sim = (root / "src" / "Simulation.lua").read_text(encoding="utf-8")
main = (root / "main.lua").read_text(encoding="utf-8")
all_source = main + "\n" + "\n".join(p.read_text(encoding="utf-8") for p in (root / "src").rglob("*.lua"))
dialogue = (root / "src" / "Dialogue.lua").read_text(encoding="utf-8")
personalities = (root / "data" / "personalities.lua").read_text(encoding="utf-8")
errors = []


def need(token, blob, label):
    if token not in blob:
        errors.append(label)


ARCHETYPES = ["BALANCED", "HYPER_OFFENSIVE", "DEFENSIVE", "STATUS",
              "MONO_TYPE", "FAST", "EVOLUTION", "FAVOURITE", "ANTI_PLAYER"]

# --- the model ---------------------------------------------------------------
for name in ARCHETYPES:
    need(f'  {name} ', plan, f"archetype {name} has no weights")
    if f'{name} =' not in plan:
        errors.append(f"archetype {name} is not labelled")

need("TeamPlan.FROM_PLAN", plan, "the identity is not seeded from personality.teamPlan")
need("function TeamPlan.fit", plan, "no identity fit function")
need("function TeamPlan.observe", plan, "identity cannot move on evidence")
need("TeamPlan.DRIFT_REASONS", plan, "drift reasons are not a named closed set")
need("TeamPlan.TYPE_LIMIT", plan, "tracked types are unbounded")
need("TeamPlan.CREDIT_MAX", plan, "type credit is unbounded")
need("function TeamPlan.serviceScore", plan, "no service score for the favourite")
need("function TeamPlan.serialize", plan, "the identity cannot be serialized")

# Deterministic: no dice, no clock, no engine reach-through.
for banned in ("math.random", "os.time", "os.clock", "love.", "rng:"):
    if banned in plan:
        errors.append(f"the team model is not deterministic ({banned})")

# personality.teamPlan must still exist for all four shipped personalities --
# this is the seed, and losing it silently makes every rival BALANCED.
seeds = re.findall(r'teamPlan\s*=\s*"([a-z]+)"', personalities)
if len(seeds) < 4:
    errors.append(f"expected 4 personality teamPlan seeds, found {len(seeds)}")
for seed in seeds:
    if not re.search(rf'^\s*{seed}\s*=\s*"', plan, re.M):
        errors.append(f"personality seed '{seed}' maps to no archetype")
if len(set(seeds)) < 3:
    errors.append("the shipped personalities do not seed divergent identities")

# --- identity must not override a real matchup -------------------------------
# The identity term is deliberately a small addend inside teamFor's existing
# score, not a replacement for it. If it ever becomes the dominant term, rivals
# bring stylish teams to gyms they then lose, and §39 divergence turns into
# four rivals that are each individually bad.
need("local identity = self:teamFit(slot.species, slot) * 12", rival,
     "the identity term in teamFor was rewritten or rescaled")
need("lvl * 2 + moveScore / 10 + novelty + defence + identity", rival,
     "the matchup terms no longer sit alongside the identity term")
need("slot.ace and 10000", rival, "the ace contract in teamFor was lost")

# --- service is credited on every battle path --------------------------------
need("local function creditTeam(rival, won, opponentId, tick)", sim,
     "no single team-credit door")
if sim.count("creditTeam(") < 8:
    errors.append("not every battle resolution site credits the team")
for site in ("rival:awardBadge(badge)", "rival.leagueAttempts",
             "local aWon = result and result.winner"):
    if site not in sim:
        errors.append(f"expected battle site missing: {site}")
need("if rival.creditLeadBattle then rival:creditLeadBattle(not playerWon) end", main,
     "player battles do not credit the team's service record")
need("function Rival:creditLeadBattle", rival, "no lead credit method")
need("function Rival:markStarter", rival, "the starter is not tagged for §7")
if all_source.count("rival:markStarter(rival:addPokemon(species, 5))") != 2:
    errors.append("both starter-seeding paths must tag the starter")

# --- the favourite emerges from service, not only rarity ---------------------
need("TeamPlan.serviceScore(slot, now)", rival, "the ace ignores service record")
need('or slot.origin == "starter"', rival, "the first Pokemon is not favourite-eligible")

# --- RNG discipline ----------------------------------------------------------
# Catch weighting must consume the same single rng:int call as before, or every
# pre-1.34 save replays differently from the moment it loads.
need("#candidates > 1 and rival.teamFit", sim,
     "catch weighting can shift the rival's own RNG stream")
need("weighted[rival.rng:int(1, #weighted)]", sim, "weighted catch draw is missing")
if re.search(r"rng:(int|float|chance)", plan):
    errors.append("the team model draws from a rival RNG stream")

# --- surfaces ----------------------------------------------------------------
need('mod.commands:register("rival_team"', all_source, "no team debug verb")
need('mod.commands:register("rival_setstyle"', all_source, "no style debug verb")
need('kind == "team_style"', all_source, "an identity change is not news")
need('label = "TEAM STYLE"', all_source, "the detail screen does not show the identity")
need('label = "FAVOURITE"', all_source, "the detail screen does not show the favourite")
need("STYLE =", dialogue, "the {STYLE} dialogue token is missing")
need("ACE =", dialogue, "the {ACE} dialogue token is missing")
need("TeamPlan = TeamPlan,", main, "the model is not exported for tests")

# --- preserved --------------------------------------------------------------
for token in ("KantoCompat", "WonderTrade.install(mod, M)", "rivalGiftAllowed",
              "Relationships.headline", "function M:relationshipsEnabled"):
    need(token, main, f"earlier contract lost: {token}")
need("local SAVE_VERSION = 10", main, "save version regressed")
errors.extend(x for x in [at_least(root, "1.34.0")] if x)

if errors:
    for error in errors:
        print("FAIL", error)
    raise SystemExit(1)
print("AI Rivals v1.34 team identity: seeded from existing data, subordinate to "
      "matchup, credited everywhere, bounded and deterministic PASS")
