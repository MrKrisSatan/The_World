-- Standalone: lua5.1 tests/scout_test.lua   (from mods/ai_rivals)
--
-- src/Scout.lua: what one trainer may honestly say about another.
--
-- The property that matters is that a report is EVIDENCE, not a database
-- lookup. A caller who has never battled the subject must not be able to
-- recite their party, and a subject nobody has heard of must produce nothing
-- at all rather than a confident "no badges, no team" (lesson 5: no
-- information has to mean zero information, not a plausible default).

local cache = {}
local function req(n)
  if cache[n] then return cache[n] end
  local f = assert(loadfile(n .. ".lua")); cache[n] = f(req, {}); return cache[n]
end
local Scout = req("src/Scout")

local pass, fail = 0, 0
local function eq(a, b, m) if a == b then pass = pass + 1 else fail = fail + 1
  print(("FAIL %s (got %s want %s)"):format(m, tostring(a), tostring(b))) end end
local function ok(c, m) if c then pass = pass + 1 else fail = fail + 1; print("FAIL " .. m) end end

local function rival(id, name, opts)
  opts = opts or {}
  local r = { id = id, name = name, party = opts.party or {}, map = opts.map,
              bonds = opts.bonds or {} }
  if opts.badges then r.badgeCount = function() return opts.badges end end
  function r:bondWith(other) return self.bonds[other] or { wins = 0, losses = 0 } end
  return r
end

local function rowText(report)
  local parts = {}
  for _, row in ipairs(report.rows) do
    parts[#parts + 1] = tostring(row.label) .. "=" .. tostring(row.right)
  end
  return table.concat(parts, ",")
end

local FULL_TEAM = {
  { species = "SQUIRTLE", level = 15 },
  { species = "ODDISH", level = 11 },
  { species = "MAGIKARP", level = 8 },
}

-- 1. LEVELS come from the head-to-head record, and nothing else.
local subject = rival("matt", "MATT", { party = FULL_TEAM, badges = 3, map = "CERULEAN_CITY" })
local stranger = rival("chris", "CHRIS")
eq(Scout.level(stranger, subject, 10), "RUMOUR", "no battles is rumour at best")

local met = rival("chris", "CHRIS", { bonds = { matt = { wins = 1, losses = 0 } } })
eq(Scout.level(met, subject, 10), "SEEN", "one battle is first-hand but partial")

local familiar = rival("chris", "CHRIS", { bonds = { matt = { wins = 2, losses = 1 } } })
eq(Scout.level(familiar, subject, 10), "KNOWN", "three battles is the whole rotation")
eq(Scout.battlesBetween(familiar, subject, 10), 3, "wins and losses are both evidence")

-- 2. A REPORT NEVER EXCEEDS ITS LEVEL.
local rumour = Scout.report(stranger, subject, 10)
ok(not rowText(rumour):find("SQUIRTLE"), "rumour cannot name the team (" .. rowText(rumour) .. ")")
ok(rowText(rumour):find("BADGES=3"), "rumour still carries what is public")
ok(rowText(rumour):find("AROUND"), "rumour still carries where they were")

local seen = Scout.report(met, subject, 10)
ok(rowText(seen):find("SQUIRTLE"), "one battle shows the lead")
ok(not rowText(seen):find("MAGIKARP"), "one battle does not show the whole box")
ok(rowText(seen):find("PARTY=3"), "one battle does show how many they carried")

local known = Scout.report(familiar, subject, 10)
for _, species in ipairs({ "SQUIRTLE", "ODDISH", "MAGIKARP" }) do
  ok(rowText(known):find(species), "a well-known team reports " .. species)
end
ok(rowText(known):find("L15"), "levels are reported with the species")

-- 3. NO INFORMATION MEANS NO INFORMATION.
local ghost = rival("ghost", "GHOST")
local nothing = Scout.report(stranger, ghost, 10)
eq(nothing.level, "NONE", "an unmet, unplaced, unbadged subject is unknown")
ok(not rowText(nothing):find("BADGES"), "an unknown subject does not report zero badges")
ok(nothing.line:upper():find("NEVER"), "and says so plainly (" .. nothing.line .. ")")

-- 4. ORDINARY TRAINERS HOLD NO BOND: rumour is their ceiling by construction.
local fromTrainer = Scout.report(nil, subject, 10)
eq(fromTrainer.level, "RUMOUR", "a trainer with no bond record answers at rumour level")
eq(Scout.rumour(subject, 10).level, "RUMOUR", "the rumour helper agrees")
ok(not rowText(fromTrainer):find("SQUIRTLE"), "a trainer cannot recite a rival's party")

-- 5. EVERY SPOKEN LINE FITS THE BOX IT IS DRAWN IN.
-- The engine's text box is 18 columns and shows the last two lines only, so
-- anything past 36 characters would silently lose its beginning.
for _, report in ipairs({ rumour, seen, known, nothing, fromTrainer }) do
  ok(#report.line <= 36, "the spoken line fits the text box (" .. report.line .. ")")
  ok(#report.rows > 0, "a report always has something on screen")
  for _, row in ipairs(report.rows) do
    ok(#tostring(row.label) <= 10, "row labels fit the shared row: " .. tostring(row.label))
  end
end
eq(#Scout.fit(string.rep("x", 80), 36), 36, "long lines are cut to the box")

-- 6. THE MODEL IS PURE: reading a report twice cannot change the world.
local before = rowText(known)
Scout.report(familiar, subject, 99)
eq(rowText(Scout.report(familiar, subject, 10)), before, "a report has no side effects")
eq(#subject.party, 3, "and never edits the subject it describes")

-- 7. Junk in, no crash out.
for _, bad in ipairs({ { nil, nil }, { {}, {} }, { "x", 7 } }) do
  local okCall, report = pcall(Scout.report, bad[1], bad[2], 1)
  ok(okCall and type(report) == "table", "a malformed subject still produces a report")
end

print(("scout: %d passed, %d failed"):format(pass, fail))
os.exit(fail == 0 and 0 or 1)
