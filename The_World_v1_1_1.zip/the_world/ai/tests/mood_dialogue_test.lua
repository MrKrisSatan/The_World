-- Standalone: lua5.1 tests/mood_dialogue_test.lua  (from mods/ai_rivals)
--
-- Every derived mood must resolve a line for every personality, leave no
-- unexpanded token, and keep {MOOD} in step with the mood the story derived --
-- without changing how greetings behaved in 1.32/1.33/1.34.

local cache = {}
local function req(n)
  if cache[n] then return cache[n] end
  local f = assert(loadfile(n .. ".lua")); cache[n] = f(req, {}); return cache[n]
end
local Rival, Dialogue, Story = req("src/Rival"), req("src/Dialogue"), req("src/Story")
local LINES, GYMS = req("data/dialogue"), req("data/gyms")
local PERS, ROSTER = req("data/personalities"), req("data/rivals")
local pass, fail = 0, 0
local function ok(c,m) if c then pass=pass+1 else fail=fail+1; print("FAIL "..m) end end
local function eq(a,b,m) if a==b then pass=pass+1 else fail=fail+1
  print(("FAIL %s (got %s want %s)"):format(m,tostring(a),tostring(b))) end end

local ctx = { data = { pokemon = {}, constants = {} }, personalities = PERS,
              graph = { has = function() return false end }, gyms = { order = {}, byBadge = {} } }
local dlg = Dialogue.new(LINES, GYMS, { relationships = function() return true end })

-- every derived mood except CONTENT must have a bucket
for _, mood in ipairs(Story.MOODS) do
  if mood ~= "CONTENT" then
    ok(LINES.mood[mood] ~= nil, "dialogue covers derived mood " .. mood)
  end
end
ok(LINES.mood.CONTENT == nil, "CONTENT deliberately has no bucket")

for _, def in ipairs(ROSTER) do
  local r = Rival.new(def, ctx); r.ticks = 1
  eq(dlg:moodLine(r), nil, def.id .. ": a content rival offers no mood line")
  eq(dlg:tokens(r).MOOD, "content", def.id .. ": {MOOD} reads content by default")
  for mood in pairs(LINES.mood) do
    r:ensureStory().mood = mood
    local line = dlg:moodLine(r)
    ok(type(line) == "string" and #line > 0,
       def.id .. ": " .. mood .. " resolves a line for this personality")
    ok(not line:find("{[A-Z]+}"), def.id .. ": " .. mood .. " leaves no unexpanded token")
    ok(dlg:tokens(r).MOOD == Story.moodLabel(mood):lower(),
       def.id .. ": {MOOD} tracks the derived mood (" .. mood .. ")")
  end
  ok(type(dlg:greeting(r)) == "string", def.id .. ": greeting still produces text")
end
print(("\n%d passed, %d failed"):format(pass, fail))
os.exit(fail == 0 and 0 or 1)
