from pathlib import Path
s=Path('src/RivalWars.lua').read_text(); m=Path('main.lua').read_text(); p=Path('src/manager/Persistence.lua').read_text(); manifest=Path('manifest.json').read_text()
for x in ['RECOVER_STOLEN_POKEMON','HELP_RECOVER_POKEMON','RIVAL_RAID','RECOVER_FROM_ROCKET','onTalkOffer','requestLine','STOLEN_POKEMON_RECOVERED','FAILED_STOLEN_RECOVERY']: assert x in s,x
assert 'M.rivalWars:update' in m
assert 'rivalWars' in p
assert '"version": "6.7.0"' in manifest
# player quest must only be offered from talk path, not update
update=s[s.index('function W:update'):s.index('function W:requestLine')]
assert 'offerFromIssuer' not in update
ontalk=s[s.index('function W:onTalkOffer'):]
assert 'offerFromIssuer' in ontalk
print('rival wars 6.7 static: ok')
