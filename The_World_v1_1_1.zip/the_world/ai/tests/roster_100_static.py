from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
roster = (ROOT / "data" / "rivals.lua").read_text(encoding="utf-8")
rival = (ROOT / "src" / "Rival.lua").read_text(encoding="utf-8")
main = (ROOT / "main.lua").read_text(encoding="utf-8")
roster_policy = (ROOT / "src" / "RosterPolicy.lua").read_text(encoding="utf-8")
life = (ROOT / "src" / "LifePath.lua").read_text(encoding="utf-8")
personalities = (ROOT / "data" / "personalities.lua").read_text(encoding="utf-8")
career = (ROOT / "src" / "Career.lua").read_text(encoding="utf-8")
# 4.7.0: a path's career lives in its row now, not in a Career.lua literal.
rows = (ROOT / "data" / "lifepaths.lua").read_text(encoding="utf-8")
dialogue = (ROOT / "data" / "dialogue.lua").read_text(encoding="utf-8")

checks = {
    "100-slot generation": "for slot = 6, 100 do",
    "save-seeded personalities": 'hashSeed(ctx.starterSeed or 1, "personality:" .. def.id)',
    "100-rival ALL preset": 'i == size and "ALL"',
    # 5.0.9: `#roster` became `size`, the count of ORDINARY rows -- a rolled
    # rare special used to inflate it. The default itself is still four.
    "legacy four-rival default": "else count = math.min(4, size) end",
    "scaled career share": 'LifePath.roll(seed, "divergent-share")',
}
blobs = {**{k: roster for k in ("100-slot generation",)},
         "save-seeded personalities": rival,
         "100-rival ALL preset": roster_policy,
         "legacy four-rival default": roster_policy,
         "scaled career share": life}
for label, token in checks.items():
    assert token in blobs[label], f"missing {label}"
for personality in ("EXPLORER", "MENTOR", "ACE", "SURVIVALIST", "SHOWBOAT",
                    "SCHOLAR", "TRADER", "SPECIALIST"):
    assert f"  {personality} = {{" in personalities, personality
for path in ("BATTLE_COACH", "RANGER", "COURIER", "PHOTOGRAPHER",
             "TYPE_SPECIALIST"):
    assert f'add{{ id = "{path}"' in rows, f"row {path}"
    assert "career = {" in rows[rows.index(f'add{{ id = "{path}"'):], f"career {path}"
    assert f"  {path} = {{" in dialogue, f"dialogue {path}"
print("100-rival roster static checks passed")
