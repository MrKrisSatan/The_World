from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
main=(ROOT/"main.lua").read_text()
mat=(ROOT/"src/manager/Materialize.lua").read_text()
persist=(ROOT/"src/manager/Persistence.lua").read_text()
manifest=(ROOT/"manifest.json").read_text()

assert "function M:playerNearConnectionSeam(world)" in main
assert "local margin = 3" in main
assert 'd == "north"' in main
assert 'd == "south"' in main
assert 'd == "west"' in main
assert 'd == "east"' in main
assert "function M:updateConnectionYield(world)" in main
assert "M:updateConnectionYield(world)" in main
assert "M:despawnAll()" in main
assert "self.rocket:despawnAll()" in main
assert "self.rangers:despawnAll()" in main
assert "if self.connectionYieldActive then return false end" in main
assert "if self.connectionYieldActive then return 0 end" in mat
assert "self.connectionYieldActive = false" in persist
assert '"version": "7.4.0"' in manifest
print("7.4.0 universal connection-buffer checks passed")
