from pathlib import Path

main = (Path(__file__).parents[1] / "main.lua").read_text()
all_source = main + "\n" + "\n".join(p.read_text() for p in (Path(__file__).parents[1] / "src").rglob("*.lua"))
assert "local function fitStatusRow(item)" in all_source
assert "rightRoom = math.max(0, 16 - #label - 1)" in all_source
assert "for i = 1, #items do items[i] = fitStatusRow(items[i]) end" in all_source
assert all_source.count('value = type(value) == "table" and value.value or value') >= 4
print("status menu layout/API2 dispatch PASS")
