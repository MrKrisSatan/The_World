from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
main = (ROOT / "main.lua").read_text(encoding="utf-8")
sim = (ROOT / "src" / "Simulation.lua").read_text(encoding="utf-8")

assert "if M.sim then" in main
assert "if M.sim and not (world and world.playerMoving) then" not in main
assert "function M:releaseRivalBattleSequence" in main
ended = main[main.index('mod.events:on("battle.ended"'):]
assert "M:releaseRivalBattleSequence(rival.id)" in ended
assert "if r.isFainted and r:isFainted() and r.heal then" in sim
assert 'r:setState("HEALING", "using the Poké Center")' in sim
print("live world simulation and rival battle release checks passed")
