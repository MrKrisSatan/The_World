-- Standalone: lua5.1 mods/ai_rivals/tests/ai_rivals_test.lua
--
-- Fixture-based on purpose.  tests/fixture_data is the only dataset that
-- exists without a ROM import, so every case here either runs against it or
-- builds the smallest synthetic table that exercises the thing under test.
-- Nothing here needs the player's ROM-derived cache, which is what makes it
-- CI-safe. That sentence used to SPELL the cache path, and `modkit validate`
-- scans file bodies for those literals without stripping comments -- so this
-- test file, whose whole point is that it never touches the cache, was the
-- single MK301 error refusing `modkit pack` for the entire 4.x line (the
-- recurring lesson that a file documenting a trap matches the pattern for the
-- trap). The path is described rather than written.
package.path = "./?.lua;./?/init.lua;" .. package.path

local T = require("tests.modkit")
local Runtime = require("src.mods.Runtime")

local Data = T.fixtures.fresh()
local run = T.sdk.loadMod("mods/ai_rivals", { data = Data })
T.eq(#run.errors, 0, "the mod loads clean (" .. tostring(run.errors[1]) .. ")")

local exports = run.loader.exports.ai_rivals
T.check(type(exports) == "table", "the mod publishes exports")

local Mods = exports.modules
local Util, MapGraph = Mods.Util, Mods.MapGraph
local Rival, AI, Simulation = Mods.Rival, Mods.AI, Mods.Simulation
local BattleSim = Mods.BattleSim
local WonderTrade = Mods.WonderTrade
local KantoCompat = Mods.KantoCompat
local roster = exports.data.roster
local GYMS = exports.data.gyms
-- v1.32 bounded persistent memory: observations are evidence from completed
-- battles, favourites emerge from counts, and history cannot grow forever.
do
  local Memory = Mods.Memory
  local memory = Memory.new()
  for i = 1, 55 do
    memory = Memory.playerBattle(memory, {
      rivalWon = i % 3 == 0, tick = i, location = "ROUTE_1",
      lead = i % 2 == 0 and "PIKACHU" or "EEVEE",
      species = { "PIKACHU", "BULBASAUR" }, moves = { "THUNDERBOLT" },
    })
  end
  T.eq(memory.battles.player.total, 55, "memory counts completed player battles")
  T.eq(memory.player.favouriteLead, "PIKACHU", "memory derives the observed favourite lead")
  T.eq(memory.player.commonMove, "THUNDERBOLT", "memory derives observed common moves")
  T.check(#memory.events <= Memory.EVENT_LIMIT, "memory event history is bounded")
  local restored = Memory.new(Memory.serialize(memory))
  T.eq(restored.battles.player.total, 55, "memory survives serialization")
  T.eq(restored.last.location, "ROUTE_1", "last battle location survives serialization")
end
-- v1.33 relationships: one bounded, event-driven model. States are DERIVED
-- from causes, never assigned; both sides of a bond are independent; an old
-- save migrates to neutral; and the store cannot grow forever.
do
  local Relationships = Mods.Relationships
  T.check(type(Relationships) == "table", "the relationship model is exported")

  -- the canonical arc, driven only by battle outcomes
  local bonds = Relationships.new()
  for i = 1, 4 do Relationships.battle(bonds, "crystal", false, { tick = i }) end
  T.eq(Relationships.stateOf(bonds, "crystal", 4), "RIVALRY",
    "repeated defeat derives a rivalry")
  for i = 5, 7 do Relationships.battle(bonds, "crystal", true, { tick = i }) end
  T.eq(Relationships.stateOf(bonds, "crystal", 7), "RESPECT",
    "getting even turns a rivalry into respect")
  T.eq(Relationships.bond(bonds, "crystal", 7).losses, 4,
    "the head-to-head record is kept")

  -- causes are a closed set: a typo cannot silently move a relationship
  T.eq(Relationships.apply(bonds, "crystal", "NOT_A_CAUSE", { tick = 8 }), nil,
    "an unnamed cause is refused")

  -- bounds
  local many = Relationships.new()
  for i = 1, 60 do Relationships.apply(many, "s" .. i, "TRADED", { tick = i }) end
  T.eq(Util.count(many), Relationships.BOND_LIMIT, "the bond store is capped")
  T.check(#Relationships.bond(bonds, "crystal", 7).reasons <= Relationships.REASON_LIMIT,
    "remembered causes are bounded")

  -- a corrupt or hand-edited save can never yield an illegal state
  local dirty = Relationships.new({ crystal = { regard = "lots", rivalry = 9e9,
    state = "BEST_FRIENDS", wins = -3 } })
  T.check(Relationships.isState(Relationships.stateOf(dirty, "crystal", 0)),
    "a corrupt bond still derives a legal state")

  -- respect persists where heat fades
  local aged = Relationships.bond(bonds, "crystal", 7 + Relationships.DECAY_TICKS * 100)
  T.eq(aged.respect, Relationships.bond(bonds, "crystal", 7).respect,
    "respect never decays")
  T.check(aged.rivalry <= Relationships.bond(bonds, "crystal", 7).rivalry,
    "rivalry cools without contact")

  -- the shared predicates the duel, trade and cooperation paths consume
  T.check(Relationships.fightBias("RIVALRY") > Relationships.fightBias("ALLIED"),
    "hostility raises fight odds relative to alliance")
  T.check(Relationships.willCooperate("ALLIED")
    and not Relationships.willCooperate("HOSTILE"),
    "cooperation follows the relationship")
end

-- The same model through live Rival objects: directional, private to each
-- rival, and surviving the real serialize/restore path.
do
  local Relationships = Mods.Relationships
  local ctx = { data = Data, personalities = exports.data.personalities,
                graph = MapGraph.build(Data.maps or {}), gyms = GYMS }
  local a = Rival.new(roster[1], ctx)
  local b = Rival.new(roster[2], ctx)
  local c = Rival.new(roster[3], ctx)
  a.ticks, b.ticks, c.ticks = 0, 0, 0
  T.eq(a:relationshipTo(b.id), "NEUTRAL", "a fresh rival is neutral")
  for i = 1, 5 do
    a.ticks, b.ticks = i, i
    a:recordRelationshipBattle(b.id, true, { lead = 0 })
    b:recordRelationshipBattle(a.id, false, { lead = 0 })
  end
  T.check(a:relationshipTo(b.id) ~= b:relationshipTo(a.id),
    "the two sides of a bond are tracked independently")
  T.eq(c:relationshipTo(a.id), "NEUTRAL",
    "an uninvolved rival's view is untouched")
  T.check(b:fightBiasToward(a.id) > 1.0,
    "the losing side is more likely to pick the next fight")

  local blob = b:serialize()
  local reloaded = Rival.new(roster[2], ctx)
  T.check(reloaded:restore(blob), "a rival with bonds restores")
  reloaded.ticks = b.ticks
  T.eq(reloaded:relationshipTo(a.id), b:relationshipTo(a.id),
    "relationships survive save/load")
  T.eq(reloaded:bondWith(a.id).losses, 5,
    "the head-to-head record survives save/load")

  -- a pre-1.33 save simply has no bonds key
  blob.bonds = nil
  local migrated = Rival.new(roster[2], ctx)
  T.check(migrated:restore(blob), "a pre-1.33 save record still restores")
  T.eq(migrated:relationshipTo(a.id), "NEUTRAL",
    "an old save migrates to neutral rather than inventing history")
  T.eq(migrated.playerWins, blob.playerWins,
    "the 1.32 fields are untouched by the 1.33 migration")

  -- however long the world runs, the SAVED store stays bounded
  for i = 1, 200 do
    c.ticks = i
    c:recordRelationship("ghost_" .. i, "SNUBBED")
  end
  T.check(Util.count(c:serialize().bonds) <= Relationships.BOND_LIMIT,
    "the saved bond store stays capped with many subjects")
end

-- v1.34 team identity: seeded from personality.teamPlan (previously dead
-- data), subordinate to the matchup, earned rather than assigned, bounded.
do
  local TeamPlan = Mods.TeamPlan
  T.check(type(TeamPlan) == "table", "the team identity model is exported")

  local seeded = {}
  for _, def in ipairs(roster) do
    local personality = exports.data.personalities[def.personality]
    local plan = TeamPlan.new(nil, personality and personality.teamPlan)
    T.check(TeamPlan.isArchetype(plan.style),
      def.id .. " seeds a legal team identity")
    seeded[plan.style] = true
  end
  T.check(Util.count(seeded) >= 3,
    "the shipped roster does not start as four identical team builders")

  -- type preference is earned, never assigned
  local plan = TeamPlan.new(nil, "balanced")
  T.eq(TeamPlan.preferredType(plan), nil, "a new rival has no type preference")
  for _ = 1, 6 do TeamPlan.creditTypes(plan, { "WATER" }, true) end
  T.eq(TeamPlan.preferredType(plan), "WATER",
    "the preferred type emerges from what a rival actually fields")

  -- identity moves only on sustained evidence pointing one way
  local drifter = TeamPlan.new(nil, "balanced")
  for _ = 1, 3 do TeamPlan.observe(drifter, "BEATEN_BADLY") end
  T.eq(drifter.style, "BALANCED", "a few defeats do not rewrite an identity")
  for _ = 1, 20 do TeamPlan.observe(drifter, "BEATEN_BADLY") end
  T.eq(drifter.style, "DEFENSIVE", "sustained evidence does move it")
  local torn = TeamPlan.new(nil, "balanced")
  for _ = 1, 30 do
    TeamPlan.observe(torn, "BEATEN_BADLY")
    TeamPlan.observe(torn, "WON_QUICKLY")
    TeamPlan.observe(torn, "OUTSPED")
  end
  T.eq(torn.style, "BALANCED", "contradictory evidence leaves it where it was")
  local _, _, _, changed = TeamPlan.observe(torn, "NOT_A_REASON")
  T.eq(changed, false, "an unnamed reason cannot move an identity")

  -- bounds
  local greedy = TeamPlan.new()
  for i = 1, 40 do TeamPlan.creditTypes(greedy, { "T" .. i }, true) end
  T.check(Util.count(greedy.types) <= TeamPlan.TYPE_LIMIT,
    "tracked type credit is capped")
end

-- The same identity through live Rival objects: it changes which team gets
-- fielded, the favourite emerges from service, and an old save re-seeds.
do
  local TeamPlan = Mods.TeamPlan
  local ctx = { data = Data, personalities = exports.data.personalities,
                graph = MapGraph.build(Data.maps or {}), gyms = GYMS }
  local r = Rival.new(roster[1], ctx)
  r.ticks = 0
  T.check(TeamPlan.isArchetype(r:teamStyle()), "a rival reports a legal identity")
  T.check(type(r:battleStyle()) == "string", "a rival reports a battle style")

  -- the favourite emerges from service, not from rarity alone
  local starter = r.party[1] or r:addPokemon(
    Rival.firstAvailableStarter(roster[1], nil, Data.pokemon, nil,
      { seed = 1, roster = roster }), 5)
  if starter then
    r:markStarter(starter)
    r:refreshAce()
    T.eq(r:favouriteSpecies(), starter.species,
      "the first Pokemon is the favourite before anything else has served")
    for i = 1, 40 do
      r.ticks = i * 20
      r:creditLeadBattle(i % 2 == 0)
    end
    T.check((starter.battles or 0) == 40, "the lead's battles are recorded")
    T.check((starter.wins or 0) == 20, "the lead's victories are recorded")
    T.check(r:preferredType() ~= nil,
      "type credit accrues from the types actually fielded")
  end

  -- persistence and the pre-1.34 migration
  local blob = r:serialize()
  local reloaded = Rival.new(roster[1], ctx)
  T.check(reloaded:restore(blob), "a rival with an identity restores")
  reloaded.ticks = r.ticks
  T.eq(reloaded:teamStyle(), r:teamStyle(), "the identity survives save/load")
  T.eq(reloaded:preferredType(), r:preferredType(),
    "type credit survives save/load")
  blob.teamPlan = nil
  for _, slot in ipairs(blob.party) do slot.battles, slot.wins = nil, nil end
  local migrated = Rival.new(roster[1], ctx)
  T.check(migrated:restore(blob), "a pre-1.34 save record still restores")
  T.check(TeamPlan.isArchetype(migrated:teamStyle()),
    "an old save re-seeds its identity from its personality")
  T.eq(migrated:preferredType(), nil,
    "an old save is given no invented type history")
  T.eq(migrated.playerWins, blob.playerWins,
    "earlier fields are untouched by the 1.34 migration")
end

-- v1.35 story arcs: milestones are a fixed closed set, mood and chapter are
-- derived from the other systems, migration is silent, news is rate-limited.
do
  local Story = Mods.Story
  T.check(type(Story) == "table", "the story model is exported")

  local function facts(over)
    local f = { tick = 0, badges = 0, party = 1, collection = 1, seen = 1,
      playerWins = 0, playerLosses = 0, rivalWins = 0, leagueAttempts = 0,
      champion = false, confidence = 1, streak = 0, shiny = false, rare = false,
      aceBattles = 0, evolved = false, teamChanges = 0,
      teamChangedSinceSetback = false, trainedSinceSetback = false, hasGoal = false }
    for k, v in pairs(over or {}) do f[k] = v end
    return f
  end

  -- the milestone list is fixed, so the save has a hard ceiling
  local story = Story.new()
  local everything = facts({ badges = 8, party = 6, collection = 60, seen = 120,
    playerWins = 3, playerLosses = 2, rivalWins = 4, leagueAttempts = 2,
    champion = true, shiny = true, rare = true, aceBattles = 40,
    evolved = true, teamChanges = 2 })
  Story.check(story, everything, 10)
  T.eq(Story.unlockedCount(story), Story.milestoneCount(),
    "a rival that has done everything unlocks every milestone and no more")
  T.eq(#Story.check(story, everything, 20), 0, "a milestone unlocks exactly once")

  -- §4's arc, driven only by evidence
  local hero = Story.new()
  hero.seeded = true
  Story.advance(hero, facts({ badges = 3, confidence = 1.4, streak = 2 }), 10)
  T.eq(hero.mood, "CONFIDENT", "arc: starts confident")
  Story.openSetback(hero, "player", 20)
  Story.advance(hero, facts({ badges = 3, confidence = 0.9, streak = -1, tick = 21 }), 21)
  T.eq(hero.chapter, "SETBACK", "arc: a defeat opens a setback")
  Story.advance(hero, facts({ badges = 3, confidence = 0.9, streak = -1,
    tick = 40, trainedSinceSetback = true }), 40)
  T.eq(hero.mood, "DETERMINED", "arc: training turns frustration into purpose")
  Story.advance(hero, facts({ badges = 3, tick = 60,
    trainedSinceSetback = true, teamChangedSinceSetback = true }), 60)
  T.eq(hero.chapter, "REBUILDING", "arc: changing the team is rebuilding")
  Story.answerSetback(hero, "player", 80)
  Story.advance(hero, facts({ badges = 4, confidence = 1.3, streak = 1, tick = 81 }), 81)
  T.eq(hero.chapter, "RESURGENT", "arc: beating them back is the payoff")

  -- a setback cannot reopen immediately, and a mild loss is not a setback
  T.eq(Story.openSetback(hero, "green", 82, { streak = 0, confidence = 1.0 }), false,
    "a defeat inside the cooldown does not open a new setback")
  local calm = Story.new()
  T.eq(Story.openSetback(calm, "green", 5000, { streak = 0, confidence = 1.0 }), false,
    "an ordinary loss on an even record is not a setback")
  T.eq(Story.openSetback(calm, "player", 5000, { streak = 0, confidence = 1.0 }), true,
    "a defeat by the player always counts")

  -- corrupt saves cannot produce an illegal story
  local dirty = Story.new({ mood = "ECSTATIC", chapter = "ENDGAME",
    unlocked = { NOT_A_MILESTONE = 1 } })
  T.check(Story.isMood(dirty.mood), "a corrupt mood is repaired")
  T.check(Story.isChapter(dirty.chapter), "a corrupt chapter is repaired")
  T.eq(Story.unlockedCount(dirty), 0, "an unknown milestone id is dropped")
end

-- The narrator through live Rival objects, including the silent migration.
do
  local Story = Mods.Story
  local ctx = { data = Data, personalities = exports.data.personalities,
                graph = MapGraph.build(Data.maps or {}), gyms = GYMS }
  local r = Rival.new(roster[1], ctx)
  r.ticks = 0
  r.story.seeded = true
  T.eq(r:mood(), "CONTENT", "a new rival starts content")
  T.eq(r:chapter(), "ORIGIN", "a new rival starts at the origin")

  -- the streak is READ from 1.32 memory rather than counted again
  for i = 1, 3 do
    r:rememberPlayerBattle({ tick = i, rivalWon = false, location = "X" })
  end
  T.check(r:recentStreak() <= -3, "consecutive defeats read as a losing streak")
  r:rememberPlayerBattle({ tick = 4, rivalWon = true, location = "X" })
  T.eq(r:recentStreak(), 1, "a win breaks the streak rather than adding to it")

  -- the arc end to end
  r.ticks, r.confidence = 100, 1.4
  T.check(r:noteDefeat("player", 100), "the defeat opens a setback")
  r:advanceStory(100)
  T.eq(r:chapter(), "SETBACK", "the chapter turns to setback")
  r.ticks = 140
  r:noteTrained(140)
  r:advanceStory(140)
  T.eq(r:mood(), "DETERMINED", "training turns the mood to determined")
  r.ticks = 200
  T.check(r:noteVictory("player", 200), "beating them answers the setback")
  r:advanceStory(200)
  T.eq(r:chapter(), "RESURGENT", "and the chapter pays it off")

  -- persistence
  local blob = r:serialize()
  local reloaded = Rival.new(roster[1], ctx)
  T.check(reloaded:restore(blob), "a rival with a story restores")
  reloaded.ticks = r.ticks
  T.eq(reloaded:chapter(), r:chapter(), "the chapter survives save/load")
  T.eq(Story.unlockedCount(reloaded:ensureStory()),
    Story.unlockedCount(r:ensureStory()), "milestones survive save/load")

  -- a pre-1.35 save backfills SILENTLY
  blob.story = nil
  local migrated = Rival.new(roster[1], ctx)
  T.check(migrated:restore(blob), "a pre-1.35 save record still restores")
  migrated.ticks = 5000
  T.eq(#select(1, migrated:advanceStory(5000)), 0,
    "an upgraded save announces nothing on its first tick")
  T.eq(migrated.playerWins, blob.playerWins,
    "earlier fields are untouched by the 1.35 migration")
end

-- v1.36 Living Kanto: a read-only observer with a hard sighting budget,
-- location purpose matched by substring, and navigation memory that changes
-- travel SPEED without ever opening a route.
do
  local Presence = Mods.Presence
  T.check(type(Presence) == "table", "the presence model is exported")

  local function view(over)
    local v = { id = "chris", name = "Chris", map = "ROUTE_3", mapLabel = "Route 3",
      state = "TRAVELLING", objective = "EXPLORE", sameMap = true,
      travelling = true, engaged = false }
    for k, val in pairs(over or {}) do v[k] = val end
    return v
  end

  -- §12: location purpose survives a randomizer or conversion
  T.eq(Presence.place("POKEMON_TOWER_3F"), "GHOST", "a tower floor is a ghost location")
  T.eq(Presence.place("CELADON_DEPT_STORE_2F"), "SHOP", "a store floor is a shop")
  T.eq(Presence.place("ROUTE_3"), nil, "an ordinary route has no special purpose")

  -- the sighting must match what the rival is actually doing
  T.eq(Presence.classify(view({ camping = true })), "CAMP", "a camping rival is camping")
  T.eq(Presence.classify(view({ objective = "GYM" })), "GYM", "a gym-bound rival is gym-bound")

  -- the budget
  local state = Presence.new()
  T.check(Presence.observe(state, view(), 1000) ~= nil, "a visible rival can be sighted")
  T.eq(Presence.observe(state, view(), 1001), nil, "not sighted twice in a breath")
  T.eq(Presence.observe(state, view({ id = "matt" }), 1010), nil,
    "a second rival waits out the world cooldown")
  T.eq(Presence.observe(state, view({ sameMap = false, adjacent = false }), 9000), nil,
    "a rival nowhere near the player is never sighted")
  T.eq(Presence.observe(state, view({ engaged = true }), 9000), nil,
    "a rival already engaged is not 'spotted'")

  -- bounds
  local busy = Presence.new()
  for i = 1, 200 do
    Presence.observe(busy, view({ id = "r" .. (i % 4) }),
      i * Presence.SIGHTING_COOLDOWN)
  end
  T.check(#busy.log <= Presence.LOG_LIMIT, "the sighting log is capped")

  -- camps are only legal where training is
  T.check(Presence.campWorthy({ map = "ROUTE_3", canTrain = true }),
    "a route is camp-worthy")
  T.check(not Presence.campWorthy({ map = "VIRIDIAN_POKECENTER", canTrain = true }),
    "a Pokemon Center is not a campsite")
  T.check(not Presence.campWorthy({ map = "ROUTE_3", canTrain = false }),
    "ground with no wild encounters is not camp-worthy")
end

-- Navigation memory through a live Rival: bounded, learnable, and never a key.
do
  local ctx = { data = Data, personalities = exports.data.personalities,
                graph = MapGraph.build(Data.maps or {}), gyms = GYMS }
  local r = Rival.new(roster[1], ctx)
  T.eq(r:familiarity("NOWHERE"), 0, "unseen ground is unfamiliar")
  for _ = 1, 40 do r:visitMap("HOME") end
  T.eq(r:familiarity("HOME"), 1, "a well-walked map reaches full familiarity")
  T.check(r:knowsRoute("HOME"), "and counts as known")

  -- a full atlas must still be able to learn somewhere new
  for i = 1, 400 do r:visitMap("MAP_" .. i) end
  T.check(Util.count(r.visitedMaps) <= Rival.NAV_LIMIT,
    "navigation memory stays capped")
  r:visitMap("BRAND_NEW")
  T.check((r.visitedMaps["BRAND_NEW"] or 0) >= 1,
    "a full atlas can still learn new ground -- the current map is never evicted")

  local blob = r:serialize()
  local reloaded = Rival.new(roster[1], ctx)
  T.check(reloaded:restore(blob), "a rival with navigation memory restores")
  T.check(Util.count(reloaded.visitedMaps) <= Rival.NAV_LIMIT,
    "the restored atlas is still capped")
end

-- v1.37 weather intelligence. The headline property: a chip type comes from
-- the OVERWORLD id, never the battle-field string, because that string
-- collapses weathers that chip different types.
do
  local Weather = Mods.Weather
  T.check(type(Weather) == "table", "the weather model is exported")

  T.eq(Weather.battleString(nil, "STORM"), "RAINY", "a storm reports RAINY")
  T.eq(Weather.battleString(nil, "RAIN_LIGHT"), "RAINY", "so does light rain")
  T.eq(Weather.chipType(nil, "STORM"), "ELECTRIC", "but a storm chips all but Electric")
  T.eq(Weather.chipType(nil, "RAIN_LIGHT"), "WATER", "and light rain all but Water")
  T.eq(Weather.chipType(nil, "THUNDERSNOW"), "ELECTRIC",
    "thundersnow chips Electric-immune despite reporting SNOWY")
  T.eq(Weather.chipType(nil, "ASHFALL"), "FIRE",
    "ashfall chips Fire-immune despite reporting SANDSTORM")

  -- the catalogue is read from the host, and a broken host is not believed
  local function host(list, version)
    return { _exports = { version = version or "4.18.6",
               types = list and function() return list end or nil },
             exports = function(self) return self._exports end }
  end
  local live = {
    { id = "SUNNY", chipType = "FIRE", battle = "SUNNY", sunny = true },
    { id = "NEW_SKY", chipType = "STEEL", battle = "NEW_BATTLE" },
    { id = "A", chipType = "X", battle = "A" },
    { id = "B", chipType = "Y", battle = "B" },
  }
  T.eq(select(2, Weather.catalogue(host(live))), "host",
    "a well-formed host catalogue is used")
  T.eq(Weather.chipType(host(live), "NEW_SKY"), "STEEL",
    "a weather this mod has never heard of is understood from the host")
  T.eq(select(2, Weather.catalogue(nil)), "fallback", "no host falls back")
  T.eq(select(2, Weather.catalogue(host({}))), "fallback",
    "an empty host catalogue is not believed")
  T.eq(select(2, Weather.catalogue({ exports = function() error("boom") end })),
    "fallback", "a throwing host falls back")

  -- favoured types mirror Weather FX's own encounter rule
  T.eq(Weather.favouredType(nil, "SUNNY"), "FIRE", "sun favours Fire")
  T.eq(Weather.favouredType(nil, "FOG"), "GHOST", "fog favours Ghost with no chip")
  T.eq(Weather.favouredType(nil, "CLEAR"), nil, "clear skies favour nothing")
  T.eq(Weather.affinity(nil, "STORM", { "ELECTRIC" }), 1,
    "an Electric team is at home in a storm")
  T.eq(Weather.affinity(nil, "STORM", { "WATER" }), -1,
    "a Water team is worn down by one")
  T.eq(Weather.canonicalType("PSYCHIC_TYPE"), "PSYCHIC",
    "the Gen 1 Psychic spelling is canonicalised")

  -- §6's WEATHER archetype, omitted in 1.34
  T.check(Mods.TeamPlan.isArchetype("WEATHER"), "WEATHER is a legal archetype")
end

-- v1.38 economy: one money door, a bounded ledger, budgets that cannot mint,
-- and spending profiles derived from personality fields that already existed.
do
  local Economy = Mods.Economy
  T.check(type(Economy) == "table", "the economy model is exported")

  -- profiles are normalised, so a new category cannot inflate anyone's spend
  for id, personality in pairs(exports.data.personalities) do
    local profile = Economy.profile(personality)
    local total = 0
    for _, category in ipairs(Economy.CATEGORIES) do
      total = total + (profile[category] or 0)
    end
    T.check(math.abs(total - 1) < 1e-9, id .. ": spending shares sum to one")
  end

  -- and they DISAGREE, which is the point of the release
  local collector = Economy.profile({ catchChance = 0.9, challengeChance = 0.1 })
  local brawler = Economy.profile({ catchChance = 0.05, challengeChance = 0.9,
    rivalFightChance = 0.3 })
  T.check(collector.BALLS > brawler.BALLS, "a collector funds balls harder")
  T.check(brawler.HEALING > collector.HEALING, "a brawler funds healing harder")

  -- a budget may never hand out more than the purse (§38: no invented money)
  for _, purse in ipairs({ 0, 199, 3000, 999999 }) do
    local budget = Economy.budget(purse, collector)
    local handed = 0
    for _, category in ipairs(Economy.CATEGORIES) do
      handed = handed + budget[category]
    end
    T.check(handed <= purse, "a budget of " .. purse .. " never exceeds the purse")
  end
  local evil = {}
  for _, c in ipairs(Economy.CATEGORIES) do evil[c] = 50 end
  local handed = 0
  for _, c in ipairs(Economy.CATEGORIES) do
    handed = handed + Economy.budget(1000, evil)[c]
  end
  T.check(handed <= 1000, "a malformed profile cannot mint money")

  -- the ledger is a fixed row set, whatever a save contains
  local dirty = Economy.newLedger({ spent = { BALLS = -5, NONSENSE = 900 },
    earned = "lots" })
  T.eq(dirty.spent.BALLS, 0, "a negative stored spend is repaired")
  T.eq(dirty.spent.NONSENSE, nil, "an unknown stored category is dropped")
  T.eq(Util.count(dirty.spent), #Economy.CATEGORIES,
    "the ledger has exactly one row per category")
end

-- The money door and the budgeted mart through a live Rival.
do
  local Economy = Mods.Economy
  local ctx = { data = Data, personalities = exports.data.personalities,
                graph = MapGraph.build(Data.maps or {}), gyms = GYMS }
  local r = Rival.new(roster[1], ctx)
  local start = r.money
  T.eq(r:earn(500), 500, "earning reports what was earned")
  T.eq(r.money, start + 500, "and the purse grows")
  T.eq(r:spend(r.money + 1, "BALLS"), 0, "spending more than the purse is refused")
  T.eq(r.money, start + 500, "and a refused spend leaves the purse untouched")
  T.eq(r:spend(-10, "BALLS"), 0, "a negative spend is refused")
  r.money = 100
  T.eq(r:forfeit(500), 100, "a forfeit can only take what is held")
  T.eq(r.money, 0, "leaving no debt")
  T.check(r:ensureLedger().lost == 100,
    "the forfeit is recorded as a loss, not a purchase")

  -- shopping never overdraws, however many visits
  local shopper = Rival.new(roster[2], ctx)
  shopper.money = 5000
  shopper.map = (GYMS.centers and GYMS.centers[1]) or shopper.map
  for _ = 1, 50 do
    local before = shopper.money
    shopper:restockBalls()
    T.check(shopper.money >= 0, "the purse never goes negative")
    T.check(shopper.money <= before, "shopping never adds money")
  end

  -- persistence, and the pre-1.38 migration
  local blob = shopper:serialize()
  local reloaded = Rival.new(roster[2], ctx)
  T.check(reloaded:restore(blob), "a rival with a ledger restores")
  T.eq(reloaded.money, shopper.money, "the purse survives save/load")
  blob.ledger = nil
  local migrated = Rival.new(roster[2], ctx)
  T.check(migrated:restore(blob), "a pre-1.38 save record still restores")
  T.eq(Economy.totalSpent(migrated:ensureLedger()), 0,
    "an old save starts with an empty ledger rather than an invented one")
  T.eq(migrated.money, blob.money, "but keeps the money it actually had")
end

-- v1.39 League: the retry gate escalates for a rival getting nowhere and not
-- for one that is improving, and a title shot must be earned.
do
  local League = Mods.League
  T.check(type(League) == "table", "the League model is exported")

  -- a rival getting nowhere is backed off
  local stuck = League.newRecord()
  for _ = 1, 8 do
    League.recordAttempt(stuck, 4, false, { strength = 200 })
  end
  T.eq(stuck.walls[4], 8, "every failure at a stage is recorded")
  T.eq(select(1, League.wall(stuck)), 4, "and the wall is named")
  T.check(stuck.cooldown >= League.MIN_GAP, "the retry respects the minimum gap")
  T.check(stuck.cooldown > League.BASE_COOLDOWN,
    "and has escalated well past the old flat 16-tick retry")

  -- a rival that keeps improving is NOT backed off for losing
  local improving = League.newRecord()
  League.recordAttempt(improving, 4, false, { strength = 200 })
  local first = improving.cooldown
  for step = 1, 6 do
    League.recordAttempt(improving, 4, false, { strength = 200 + step * 50 })
  end
  T.eq(improving.cooldown, first,
    "a rival that comes back stronger is not punished for losing again")
  T.check(improving.cooldown < stuck.cooldown,
    "and waits far less than one that is getting nowhere")

  -- the strength bar
  stuck.cooldown = 0
  T.check(not League.mayAttempt(stuck, 200),
    "a rival no stronger than when it failed may not walk back in")
  T.check(League.mayAttempt(stuck, 200 + League.MAX_BAR + 1),
    "one that has genuinely trained may")

  -- §30: a title shot is earned, and spent
  local winner = League.newRecord()
  T.eq(League.mayChallengeTitle(winner), false,
    "a rival that has never cleared the League may not challenge for the title")
  League.recordAttempt(winner, 5, true, { strength = 300 })
  T.eq(winner.qualified, true, "clearing the Elite Four qualifies a rival")
  T.eq(Util.count(winner.walls), 0, "and resets whatever was stopping it")
  League.beginReign(winner, 1000)
  T.eq(winner.qualified, false,
    "taking the title spends the qualification -- it must be earned again")
  T.eq(League.endReign(winner, 1600), 600, "a reign reports its length")

  -- bounds and corruption
  local dirty = League.newRecord({ attempts = -5, bestStage = 99,
    walls = { [0] = 4, [99] = 4, [2] = -7 }, qualified = "yes" })
  T.eq(dirty.attempts, 0, "a negative attempt count is repaired")
  T.eq(dirty.bestStage, League.MAX_STAGE, "an impossible best stage is clamped")
  T.eq(dirty.walls[99], nil, "a wall outside the legal stage range is dropped")
  T.eq(dirty.qualified, false, "a non-boolean qualification is not believed")

  -- §27 standings sort deterministically
  local function row(id, badges, clears, champion)
    return { id = id, name = id, badges = badges, clears = clears, best = 0,
             caught = 0, champion = champion == true, qualified = false,
             attempts = 0 }
  end
  local rows = { row("d", 8, 0), row("a", 8, 1), row("c", 2, 0), row("b", 8, 0, true) }
  League.sortStandings(rows)
  T.eq(rows[1].id, "b", "the champion leads the standings")
  T.eq(rows[2].id, "a", "then whoever has cleared the League")
  T.eq(rows[4].id, "c", "and the least advanced is last")
end

-- The League record through a live Rival, including the pre-1.39 migration.
do
  local League = Mods.League
  local ctx = { data = Data, personalities = exports.data.personalities,
                graph = MapGraph.build(Data.maps or {}), gyms = GYMS }
  local r = Rival.new(roster[1], ctx)
  T.check(type(r:ensureLeague()) == "table", "a rival has a League record")
  T.eq(r:mayChallengeTitle(), false, "and no title entitlement to start with")
  T.check(r:mayAttemptLeague(), "but may attempt the League")

  local blob = r:serialize()
  local reloaded = Rival.new(roster[1], ctx)
  T.check(reloaded:restore(blob), "a rival with a League record restores")
  T.eq(reloaded:ensureLeague().attempts, r:ensureLeague().attempts,
    "the record survives save/load")

  -- a pre-1.39 save has leagueAttempts but no record
  blob.league = nil
  blob.leagueAttempts = 7
  local migrated = Rival.new(roster[1], ctx)
  T.check(migrated:restore(blob), "a pre-1.39 save record still restores")
  T.eq(migrated:ensureLeague().attempts, 7,
    "the real attempt count is carried across")
  T.eq(migrated:ensureLeague().qualified, false,
    "but no title entitlement is invented -- it must be earned under the new rule")
  T.eq(Util.count(migrated:ensureLeague().walls), 0,
    "and no failure history is invented")
end

-- v2.1/v2.2 life paths and careers: eligibility derived from a stable seed,
-- decisions locked, and a career that reorders existing objectives rather than
-- becoming a second AI.
do
  local LifePath, Career = Mods.LifePath, Mods.Career
  T.check(type(LifePath) == "table", "the life-path model is exported")
  T.check(type(Career) == "table", "the career model is exported")

  local ids = {}
  for _, def in ipairs(roster) do ids[#ids + 1] = def.id end

  -- eligibility is pure in the seed and never every rival
  for _, seed in ipairs({ 1, 4242, 987654321 }) do
    local a = table.concat(LifePath.eligibleRivals(seed, ids), ",")
    T.eq(table.concat(LifePath.eligibleRivals(seed, ids), ","), a,
      "eligibility is deterministic for seed " .. seed)
    T.check(#LifePath.eligibleRivals(seed, ids) < #ids,
      "never every rival: seed " .. seed)
  end

  -- a committed decision cannot be re-decided
  local record = LifePath.newRecord()
  T.check(LifePath.commit(record, "BREEDER", 10, "test"), "a divergence commits")
  T.eq(LifePath.commit(record, "TEAM_ROCKET", 20), false,
    "and refuses a second commitment -- no save-scumming into a better life")
  T.eq(LifePath.newRecord({ path = "TEAM_ROCKET", locked = false }).locked, true,
    "an active career loads locked whatever the stored flag said")

  -- a career reorders existing objectives; every one must be implemented
  for _, path in ipairs(Career.IMPLEMENTED) do
    for _, objective in ipairs(Career.def(path).priorities) do
      T.check(AI.Can[objective] ~= nil,
        path .. " names an objective the AI can evaluate: " .. objective)
    end
    T.check(not Career.pursuesBadges(path), path .. " stops prioritising badges")
  end
  T.check(Career.pursuesBadges(LifePath.GYM_CHALLENGE),
    "an ordinary rival still chases badges")
  T.eq(Career.priorities("TEAM_ROCKET"), nil,
    "an unbuilt career leaves the personality's objective order alone")

  -- progress is bounded and the column set fixed
  local progress = Career.newProgress("BREEDER")
  T.eq(Career.credit("BREEDER", progress, "areas", 1), false,
    "a metric from another career is refused rather than added")
  for _ = 1, 500 do Career.credit("BREEDER", progress, "caught", 9999) end
  T.check(progress.caught <= Career.METRIC_MAX, "career metrics are capped")
  T.eq(Util.count(progress), #Career.def("BREEDER").metrics,
    "and the column set never grows")
end

-- Life paths and careers through a live Rival, including the migrations.
do
  local LifePath, Career = Mods.LifePath, Mods.Career
  local ctx = { data = Data, personalities = exports.data.personalities,
                graph = MapGraph.build(Data.maps or {}), gyms = GYMS }
  local r = Rival.new(roster[1], ctx)
  T.check(r:onGymChallenge(), "a new rival is on the Gym Challenge")
  T.check(r:pursuesBadges(), "and chases badges")
  T.check(r:lifePathPressure() >= 0 and r:lifePathPressure() <= 1,
    "its life-path pressure is in range")

  T.check(LifePath.commit(r:ensureLifePath(), "EXPLORER", 100, "test"),
    "it can take up exploring")
  T.check(not r:pursuesBadges(), "and stops chasing badges")
  T.eq(table.concat(r:objectivePriorities(), " "),
    table.concat(Career.def("EXPLORER").priorities, " "),
    "working to the career's objective order")

  local blob = r:serialize()
  local back = Rival.new(roster[1], ctx)
  T.check(back:restore(blob), "a rival with a career restores")
  T.eq(back:lifePathId(), "EXPLORER", "the path survives save/load")

  -- a pre-2.1 save has neither key
  blob.lifePath, blob.career = nil, nil
  local migrated = Rival.new(roster[1], ctx)
  T.check(migrated:restore(blob), "a pre-2.1 save record still restores")
  T.check(migrated:onGymChallenge(),
    "and is on the Gym Challenge, which is what it was actually doing")
  T.eq(Util.count(migrated:ensureCareer()), 0, "with no career columns invented")
end

-- Kanto Reforged 1.2.0 still requests src.core.Assets when it draws a custom
-- party icon. Modern engine builds moved that module to src.render.Assets.
do
  local loaded, preload = {}, {}
  local modern = { resolve = function(path) return path end }
  KantoCompat.installAssetAlias(loaded, preload, function(name)
    T.eq(name, "src.render.Assets", "legacy asset alias loads the modern module")
    return modern
  end)
  T.check(type(preload["src.core.Assets"]) == "function",
    "Kanto asset compatibility alias is registered")
  T.eq(preload["src.core.Assets"](), modern,
    "legacy Kanto asset import resolves to the engine asset module")
end

-- Kanto Reforged 1.2.0 redirects every non-nil executeAction target by its
-- isPlayer flag. Party Pokémon used by Potions have no such flag, so AI
-- Rivals marks them only for the duration of that inner wrapper.
do
  local partyMon = { species = "PIKACHU", hp = 12 }
  local battle = {
    player = { isPlayer = true, mon = partyMon },
    enemy = { isPlayer = false, mon = { species = "GEODUDE" } },
    playerParty = { partyMon },
  }
  local brokenInner = function(self, _user, target)
    return target.isPlayer and self.player or self.enemy
  end
  local safe = KantoCompat.wrapExecuteAction(brokenInner)
  T.eq(safe(battle, battle.player, partyMon, { special = "item" }), battle.player,
    "Potion target reaches Kanto Reforged as the player battler")
  T.eq(partyMon.isPlayer, nil, "temporary Potion marker does not persist in the save")

  local failing = KantoCompat.wrapExecuteAction(function()
    error("fixture failure")
  end)
  pcall(failing, battle, battle.player, partyMon, { special = "item" })
  T.eq(partyMon.isPlayer, nil, "Potion marker is restored after an engine error")
end

------------------------------------------------------------------
-- A synthetic Kanto with Oak's lab, one gym, and a couple of real
-- trainers so the economy has something to fight.
------------------------------------------------------------------

local function testMaps()
  return {
    OAKS_LAB = { id = "OAKS_LAB", width = 6, height = 5,
                 connections = {}, warps = {} },
    PALLET_TOWN = { id = "PALLET_TOWN", width = 10, height = 9,
      connections = { north = { map = "ROUTE_1", offset = 0 } }, warps = {} },
    ROUTE_1 = { id = "ROUTE_1", width = 10, height = 18,
      connections = { north = { map = "VIRIDIAN_CITY", offset = 0 },
                      south = { map = "PALLET_TOWN", offset = 0 } }, warps = {} },
    VIRIDIAN_CITY = { id = "VIRIDIAN_CITY", width = 20, height = 18,
      connections = { south = { map = "ROUTE_1", offset = 0 },
                      north = { map = "ROUTE_2", offset = 0 } },
      warps = { { destMap = "VIRIDIAN_POKECENTER", destWarp = 1, x = 4, y = 6 } } },
    ROUTE_2 = { id = "ROUTE_2", width = 10, height = 18,
      connections = { south = { map = "VIRIDIAN_CITY", offset = 0 },
                      north = { map = "PEWTER_CITY", offset = 0 } }, warps = {} },
    PEWTER_CITY = { id = "PEWTER_CITY", width = 20, height = 18,
      connections = { south = { map = "ROUTE_2", offset = 0 } },
      warps = { { destMap = "PEWTER_GYM", destWarp = 1, x = 8, y = 4 } } },
    PEWTER_GYM = { id = "PEWTER_GYM", width = 5, height = 7, warps = {} },
    VIRIDIAN_POKECENTER = { id = "VIRIDIAN_POKECENTER", width = 5, height = 4,
                            warps = {} },
  }
end

local function testData()
  return {
    maps = testMaps(),
    pokemon = {
      CHARMANDER = { name = "CHARMANDER", types = { "FIRE" }, dex = 4,
        baseStats = { hp = 39, attack = 52, defense = 43, speed = 65, special = 50 },
        growthRate = "MEDIUM_SLOW",
        evolutions = { { method = "level", level = 16, species = "CHARMELEON" } },
        learnset = { { level = 1, move = "SCRATCH" }, { level = 9, move = "EMBER" } } },
      CHARMELEON = { name = "CHARMELEON", types = { "FIRE" }, dex = 5,
        baseStats = { hp = 58, attack = 64, defense = 58, speed = 80, special = 65 },
        growthRate = "MEDIUM_SLOW", learnset = { { level = 1, move = "SCRATCH" } } },
      SQUIRTLE = { name = "SQUIRTLE", types = { "WATER" }, dex = 7,
        baseStats = { hp = 44, attack = 48, defense = 65, speed = 43, special = 50 },
        growthRate = "MEDIUM_SLOW", learnset = { { level = 1, move = "TACKLE" } } },
      GEODUDE = { name = "GEODUDE", types = { "ROCK", "GROUND" }, dex = 74,
        baseStats = { hp = 40, attack = 80, defense = 100, speed = 20, special = 30 },
        growthRate = "MEDIUM_SLOW", learnset = { { level = 1, move = "TACKLE" } } },
      RATTATA = { name = "RATTATA", types = { "NORMAL" }, dex = 19,
        baseStats = { hp = 30, attack = 56, defense = 35, speed = 72, special = 25 },
        growthRate = "MEDIUM_FAST", learnset = { { level = 1, move = "TACKLE" } } },
      PIDGEY = { name = "PIDGEY", types = { "NORMAL", "FLYING" }, dex = 16,
        baseStats = { hp = 40, attack = 45, defense = 40, speed = 56, special = 35 },
        growthRate = "MEDIUM_SLOW", learnset = { { level = 1, move = "TACKLE" } } },
    },
    moves = {
      SCRATCH = { name = "SCRATCH", power = 40, type = "NORMAL", pp = 35, accuracy = 100 },
      EMBER   = { name = "EMBER",   power = 40, type = "FIRE",   pp = 25, accuracy = 100 },
      TACKLE  = { name = "TACKLE",  power = 35, type = "NORMAL", pp = 35, accuracy = 95 },
    },
    -- the engine's own shape: rows under `matchups`, multipliers x10
    type_chart = { matchups = {
      { attacker = "FIRE", defender = "ROCK", multiplier = 5 },
      { attacker = "WATER", defender = "ROCK", multiplier = 20 },
    }, types = {} },
    -- one gym leader and two ordinary trainers; OPP_AIR_* is added by the
    -- mod's own registration at game.ready
    trainers = {
      OPP_BROCK = { name = "BROCK", baseMoney = 60,
                    parties = { { { species = "GEODUDE", level = 14 } } } },
      OPP_YOUNGSTER = { name = "YOUNGSTER", baseMoney = 80,
                        parties = { { { species = "RATTATA", level = 8 } } } },
      OPP_LASS = { name = "LASS", baseMoney = 70,
                   parties = { { { species = "PIDGEY", level = 9 } } } },
    },
    encounters = { ROUTE_1 = { slots = {
      { species = "CHARMANDER", level = 4 }, { species = "RATTATA", level = 3 } } } },
    constants = { badges = GYMS.order, partyMax = 6 },
  }
end

local data = testData()
local graph = MapGraph.build(data.maps)
local gyms = Util.copy(GYMS)
gyms.centers = graph:filterExisting(GYMS.centers)
gyms.training = graph:matching(GYMS.trainingPrefixes)

-- Boot the manager the way game.ready does.  The fixture data is only used
-- for the mod's own load; the manager runs against the synthetic Kanto.
local Mgr = exports.manager
Runtime.emit("game.ready", { game = { data = data, save = { party = {} } } })
T.check(Mgr.ready == true, "game.ready built the manager")

-- Absorbed Wonder Trade includes live registered species but never sends a
-- string-ID Weather FX variant through the ROM-index animation path.
data.pokemon.WX_TEST_CHARMANDER = {
  id="WX_TEST_CHARMANDER", name="CINDER CHARMANDER", dex=4,
  baseStats=Util.copy(data.pokemon.CHARMANDER.baseStats), types={"FIRE","GHOST"},
}
local wonderPool = WonderTrade.buildPool(data, Mgr)
local wonderSet = {}; for _, id in ipairs(wonderPool) do wonderSet[id] = true end
T.check(wonderSet.WX_TEST_CHARMANDER == true,
  "Wonder Trade pool includes a registered Weather FX-style species")
T.check(not WonderTrade.animationSafe(data,
    {species="CHARMANDER"}, {species="WX_TEST_CHARMANDER"}),
  "Weather variants bypass the ROM-index trade animation")
data.pokemon.CHARMANDER.index, data.pokemon.SQUIRTLE.index = 4, 7
T.check(WonderTrade.animationSafe(data,
    {species="CHARMANDER"}, {species="SQUIRTLE"}),
  "ROM-indexed species retain the normal trade animation")
data.pokemon.WX_TEST_CHARMANDER = nil

-- A standalone rival (not one of the manager's, so tests do not leak into
-- each other).  `manager` exposes the real roster to the trainer pool so
-- the rivals' own classes are excluded exactly like in the game.
local function ctxFor()
  return { data = data, personalities = exports.data.personalities,
           graph = graph, gyms = gyms, versionKey = "default",
           compat = nil, manager = Mgr }
end

local function newRival(over)
  over = over or {}
  local def = over.def or roster[1]
  local r = Rival.new(def, ctxFor())
  r.map = over.map or "PALLET_TOWN"
  if not over.noStarter then
    -- 4.5.0: STARTERS COME FROM THE POOL, NOT FROM THE ROW.
    --
    -- 2.6.0 moved the deal into ROSTER.pools, so a roster row no longer
    -- carries a `starters` table and firstAvailableStarter needs the roster
    -- and a seed to deal from. This call still used the pre-2.6 shape, so it
    -- returned nil, every fixture rival was built with an EMPTY PARTY, and the
    -- suite crashed on the first line that read party[1] -- taking every check
    -- after it with it. The product path (M:dealStarters) always passed opts.
    local species = Rival.firstAvailableStarter(def, "default", data.pokemon,
      nil, { seed = 1, roster = roster })
    if species then r:addPokemon(species, 5) end
  end
  return r
end

-- Persistent bonds and rival Wonder Trades (1.31.0).
local bonded = newRival()
local rareShiny = { species="SQUIRTLE", level=12, moves={"TACKLE"}, shiny=true }
rareShiny.hp = bonded:maxHpOf(rareShiny)
bonded:storePokemon(rareShiny)
T.check(bonded:considerAttachment(rareShiny, "caught"),
  "a shiny catch always forms an attachment")
T.check(rareShiny.ace == true and bonded.aceSpecies == "SQUIRTLE",
  "the strongest bonded Pokemon becomes the persistent ace")

local wonderRival = newRival()
local starterSpecies = wonderRival.party[1].species
wonderRival:storePokemon({ species=starterSpecies, level=5,
  moves=wonderRival:movesFor(starterSpecies, 5), hp=10 })
local wonder = wonderRival:wonderTradeDuplicate()
T.check(wonder and wonder.gave == starterSpecies and wonder.got ~= starterSpecies,
  "a rival can Wonder Trade exactly one boxed duplicate")
T.check(wonder and wonder.slot.shiny and wonder.slot.attached,
  "a rival bonds with its shiny Wonder Trade result")
local selected = wonderRival:teamFor({})
T.check(selected[1] == wonder.slot and wonder.slot.ace,
  "the bonded Wonder Trade Pokemon is selected as the team ace")
wonderRival.wonderTradeCooldown = 77
local wonderSave = wonderRival:serialize()
local wonderReload = newRival()
T.check(wonderReload:restore(wonderSave), "ace-bearing rival save restores")
T.eq(wonderReload.wonderTradeCooldown, 77, "Wonder Trade cooldown persists")
T.check(wonderReload.aceSpecies == wonder.got,
  "ace identity and attachment persist across save/load")

------------------------------------------------------------------
-- 1. Load and roster
------------------------------------------------------------------

-- 4.5.0: THESE THREE CHECKS WERE FROZEN AT THE 2.5 DESIGN.
--
-- 2.6 moved starters into ROSTER.pools and 4.3 grew the roster to 100 slots
-- with a personality POOL per generated row, but this block still asserted
-- four rivals, a per-row `starters` chain and a single `personality` field.
-- It had been unreachable since the fixture builder above began returning nil
-- starters, so it went on describing a mod that no longer exists. Each check
-- now reads the shipped design instead of restating an old one (lesson 19).
T.check(#roster >= 4, "the shipped roster still covers the original four")
-- 5.0.9: counts the ORDINARY rows. src/Specials.lua appends a rare Berserk
-- character when the world seed rolls one, so #roster is 100 most runs and
-- 101 on the rest -- which is why this line and the five below it were FLAKY
-- rather than failing, and why the flakiness read as a dialogue regression
-- when it was six years of a hidden roll. Lesson 19: read the vocabulary from
-- the implementing module instead of restating it.
local RosterPolicyMod = Runtime.req and Runtime.req("src/RosterPolicy")
  or dofile("mods/ai_rivals/src/RosterPolicy.lua")
local function ordinaryOnly(list)
  local out = {}
  for _, def in ipairs(list or {}) do
    if not (def and (def.rareSpecial or (def.def and def.def.rareSpecial))) then
      out[#out + 1] = def
    end
  end
  return out
end
T.eq(#ordinaryOnly(roster), 100, "the roster provides the full 100 selectable slots")
local ids, classes = {}, {}
for _, def in ipairs(roster) do
  T.check(not ids[def.id], "rival id " .. def.id .. " is unique")
  T.check(not classes[def.trainerClass],
    "trainer class " .. tostring(def.trainerClass) .. " is unique")
  T.check(def.trainerClass:sub(1, 8) == "OPP_AIR_",
    def.name .. " registers its OWN trainer class, not a vanilla one")
  -- A row names either one personality or a pool one is dealt from; both must
  -- resolve to personalities that exist.
  local named = { def.personality }
  if type(def.personalities) == "table" then named = def.personalities end
  local allKnown = #named > 0
  for _, id in ipairs(named) do
    if exports.data.personalities[id] == nil then allKnown = false end
  end
  T.check(allKnown, def.name .. " names only personalities that exist")
  -- Starters are DEALT from the pool by (seed, slot); a row carries no chain
  -- of its own, so the deal is what has to be non-empty.
  T.check(#Rival.starterChain(def, "default", { seed = 1, roster = roster }) > 0,
    def.name .. " is dealt a default starter")
  ids[def.id], classes[def.trainerClass] = true, true
end

------------------------------------------------------------------
-- 2. Core rival: progression ceilings and party target
------------------------------------------------------------------

local r = newRival()
T.eq(#r.party, 1, "a new rival starts with exactly one Pokemon")
T.eq(r.party[1].level, 5, "and it starts at level 5")
T.eq(r:badgeCount(), 0, "a new rival has no badges")
T.eq(r:partyTarget(), 1, "party target starts at the starter only")
Mgr:finishGauntlet()
T.eq(r:partyTarget(), 6, "the finished Lab gauntlet opens all six team slots")

-- the level ceiling follows the next gym leader's ace + 2
local r2 = newRival()
T.eq(r2:levelCeiling(), 16, "pre-Brock ceiling is Brock's Lv14 ace + 2")
r2:awardBadge("BOULDERBADGE")
T.eq(r2:levelCeiling(), 23, "after Brock the ceiling follows Misty (21 + 2)")
r2.playerPaceLevel = 7
T.eq(r2:levelCeiling(), 10,
  "the player-relative ceiling prevents an early rival running away")
r2.playerPaceLevel = nil

-- an over-level team from an old save is pulled back to the ceiling
local r3 = newRival()
r3.party[1].level = 40
r3.party[1].exp = Rival.expForLevel(r3:speciesDef("CHARMANDER"), 40)
r3:enforceLevelCeiling()
T.eq(r3.party[1].level, 16, "an over-level team is pulled back to the ceiling")
T.eq(r3.party[1].exp, Rival.expForLevel(r3:speciesDef("CHARMANDER"), 16),
  "and its exp is corrected with it")

------------------------------------------------------------------
-- 3. BattleSim runs with any RNG (the skirmish/League seam)
------------------------------------------------------------------

local a = { { species = "CHARMELEON", level = 20, moves = { "SCRATCH" } } }
local b = { { species = "GEODUDE", level = 20, moves = { "TACKLE" } } }
local outBare = BattleSim.run(data, a, b, {})
T.check(type(outBare) == "table" and outBare.winner ~= nil,
  "a fight with a bare {} RNG resolves (rival-vs-rival fights actually run)")
local outNil = BattleSim.run(data, a, b, nil)
T.check(type(outNil) == "table" and outNil.winner ~= nil,
  "and a fight with no RNG resolves")

------------------------------------------------------------------
-- 4. The money economy: buying Poké Balls
------------------------------------------------------------------

T.eq(Rival.STARTING_MONEY, 3000, "rivals start with the player's pocket money")
T.eq(Rival.POKEBALL_PRICE, 200, "a Poké Ball costs 200, like the mart")

local shop = newRival({ map = "VIRIDIAN_CITY" })
shop.money = 5000
shop.balls = 0
local bought = shop:restockBalls()
T.check(bought > 0, "a rival at a town buys Poké Balls")
T.eq(shop.balls, bought, "and holds exactly what it bought")
T.check(shop:itemCount("POTION") > 0 and shop:itemCount("ANTIDOTE") > 0
  and shop:itemCount("REPEL") > 0,
  "a rival buys usable battle and field supplies as well as balls")
T.check(shop.balls >= 3 and shop.balls <= 15,
  "stock stays within the personality's target band")
T.check(shop.money < 5000,
  "balls and supplies are all paid for out of the winnings")

local noShop = newRival({ map = "ROUTE_1" })
noShop.money = 10000
T.eq(noShop:restockBalls(), 0, "a route has no mart to buy at")

local broke = newRival({ map = "VIRIDIAN_CITY" })
broke.money = 0
T.eq(broke:restockBalls(), 0, "a rival with no money buys nothing")

local lab = newRival({ map = "OAKS_LAB" })
lab.money = 10000
T.eq(lab:restockBalls(), 0, "the lab has no mart")

------------------------------------------------------------------
-- 5. Catching costs a ball
------------------------------------------------------------------

local catcher = newRival({ map = "ROUTE_1" })
catcher:awardBadge("BOULDERBADGE")     -- party target 2, ceiling 23
catcher.balls = 5
catcher.personality = Util.copy(catcher.personality)
catcher.personality.catchChance = 1.0
local before = #catcher.party
local caught = Simulation.tryCatch(catcher)
T.check(caught ~= nil, "a rival holding balls catches from the route table")
T.eq(#catcher.party, before + 1, "the catch adds a Pokemon")
T.eq(catcher.balls, 4, "and spends exactly one ball")

catcher:takeItem("POKE_BALL", catcher:itemCount("POKE_BALL"))
T.check(not catcher:canCatch(), "no balls means no catching")
catcher:addItem("GREAT_BALL", 1)
T.check(catcher:canCatch(), "a premium ball alone still permits catching")
local labCatcher = newRival({ map = "OAKS_LAB" })
labCatcher.balls = 5
T.check(not labCatcher:canCatch(), "the lab forbids catching")

-- Six is an active-team limit, not a collection limit: further captures go
-- to the rival's own PC box and never create a seventh battle slot.
local boxer = newRival({ map = "ROUTE_1" })
for _ = 2, 6 do boxer:addPokemon("RATTATA", 5) end
local boxed = boxer:capturePokemon("PIDGEY", 5)
T.check(boxed ~= nil, "a full-team rival can still catch a Pokemon")
T.eq(#boxer.party, 6, "the active team never exceeds six")
T.eq(#boxer.pcBoxes[1], 1, "the seventh capture is stored in the rival PC")

------------------------------------------------------------------
-- 6. Rivals fight each other: the same-map skirmish pays
------------------------------------------------------------------

local skirmishA = newRival({ map = "VIRIDIAN_CITY" })
local skirmishB = newRival({ map = "VIRIDIAN_CITY", def = roster[2] })
skirmishA.money = 0
skirmishB.money = 1000
skirmishA.rivalFightCooldown, skirmishB.rivalFightCooldown = 0, 0
skirmishA.personality = Util.copy(skirmishA.personality)
skirmishA.personality.rivalFightChance = 1.0
local skirmish = Simulation.tryRivalSkirmish({ skirmishA, skirmishB }, {})
T.check(skirmish ~= nil, "two rivals on one map skirmish")
T.check(skirmish.money ~= nil and skirmish.money > 0, "money changes hands")
T.eq(skirmishA.money + skirmishB.money, 1000,
  "and it is zero-sum: the winner takes it from the loser")

------------------------------------------------------------------
-- 7. Rivals fight each other: the cross-Kanto duel objective
------------------------------------------------------------------

local duelRival = newRival({ map = "VIRIDIAN_CITY" })
local duelTarget = newRival({ map = "PEWTER_CITY", def = roster[2] })
duelRival.personality = Util.copy(duelRival.personality)
duelRival.personality.duelChance = 1.0
duelRival.personality.wanderChance = 0
local objective = AI.evaluate(duelRival, { rivals = { duelRival, duelTarget } })
T.eq(objective, "RIVAL_DUEL", "a rival with a reachable rival picks the duel")
T.eq(duelRival.state, "SEEKING_RIVAL", "and enters the seek state")
T.check(duelRival.rivalTarget ~= nil and duelRival.rivalTarget.id == duelTarget.id,
  "and targets that rival")
T.eq(duelRival.destination, "PEWTER_CITY", "and routes to its map")

-- arriving at the target's map starts the fight
local arr = newRival({ map = "PEWTER_CITY" })
arr.objective = "RIVAL_DUEL"
arr.rivalTarget = duelTarget
AI.onArrive(arr, { rivals = { arr, duelTarget } })
T.eq(arr.state, "CHALLENGING_RIVAL", "arriving at the target's map challenges it")

-- the duel resolves headlessly and the winner is paid
local duelA = newRival({ map = "PEWTER_CITY" })
local duelB = newRival({ map = "PEWTER_CITY", def = roster[2] })
duelA.party[1] = { species = "CHARMELEON", level = 30, moves = { "SCRATCH" } }
duelA.money = 0
duelB.money = 1000
duelA.rivalTarget = duelB
local duel = Simulation.attemptDuel(duelA)
T.check(duel ~= nil, "a duel resolves")
if duel.won then
  T.eq(duelA.money, duel.money, "the winner takes the prize")
  T.eq(duelB.money, 1000 - duel.money, "and the loser pays exactly that")
end
T.check(duelA.rivalTarget == nil, "the duel target is cleared")
T.check(duelA.state == "IDLE", "the duel leaves the challenger free")
T.check((duelA.rivalFightCooldown or 0) > 0, "and puts it on a fight cooldown")

------------------------------------------------------------------
-- 8. Rivals fight the world's trainers for money
------------------------------------------------------------------

local pool = Simulation.trainerPool(newRival())
local classes = {}
for _, entry in ipairs(pool or {}) do classes[entry.class] = true end
T.check(classes.OPP_BROCK == nil, "gym leaders are not 'enemy' trainers")
T.check(classes.OPP_AIR_CHRIS == nil, "the rivals' own classes are not enemy trainers")
T.check(classes.OPP_YOUNGSTER == true, "an ordinary trainer is in the pool")

local tb = newRival({ map = "ROUTE_1" })
tb.party[1] = { species = "CHARMELEON", level = 30, moves = { "SCRATCH" } }
tb.money = 0
local tbOut = Simulation.tryTrainerBattle(tb)
T.check(tbOut ~= nil and tbOut.won == true, "a strong rival beats a local trainer")
T.check(tb.money > 0, "and is paid for the win")
T.check(tbOut.trainer ~= "OPP_BROCK" and tbOut.trainer ~= "OPP_AIR_CHRIS",
  "the foe is a real trainer, never a gym leader or a rival")

------------------------------------------------------------------
-- 9. The world keeps progressing after the scripted intro
------------------------------------------------------------------

T.check(Mgr:gauntletDone(), "the lab gauntlet is durably done")
local updates0 = Mgr.sim.counters.rivalUpdates
for _ = 1, 60 do Mgr.sim:runTick(Mgr.rivals, Mgr:worldView()) end
T.check(Mgr.sim.counters.rivalUpdates > updates0,
  "the world tick keeps advancing rivals after the intro")
local inLab = 0
for _, r in ipairs(Mgr.rivals) do
  if r.map == "OAKS_LAB" then inLab = inLab + 1 end
end
T.eq(inLab, 0, "no rival is stuck in the lab")

-- Dynamic rivals never park on route seams or door warps.
local exitOverview = { width = 10, rows = {
  "..........", "..........", "..........", ".........." },
  markers = { { kind = "warp", x = 4, y = 2 } } }
T.check(Mgr:isTransitCell("ROUTE_1", exitOverview, 0, 2),
  "a connection seam is traversal-only")
T.check(Mgr:isTransitCell("ROUTE_1", exitOverview, 4, 2),
  "a warp tile is traversal-only")
T.check(not Mgr:isTransitCell("ROUTE_1", exitOverview, 5, 2),
  "an ordinary interior tile remains available")

local purposeful = newRival({ map = "ROUTE_1" })
purposeful.personality = Util.copy(purposeful.personality)
purposeful.personality.priorities = { "TRAIN" }
purposeful.personality.wanderChance = 0
AI.evaluate(purposeful, { playerBadges = 0 })
T.check(type(purposeful.travelReason) == "string" and #purposeful.travelReason > 0,
  "every selected destination records a user-visible reason")

------------------------------------------------------------------
-- 10. The economy persists
------------------------------------------------------------------

Mgr:save()
local state = run.loader.modSave["ai_rivals"] and run.loader.modSave["ai_rivals"].state
T.check(state and state.rivals and state.rivals.chris
  and state.rivals.chris.money ~= nil,
  "money is written into the save bucket")
T.check(state.rivals.chris.balls ~= nil, "and the ball stock with it")
Mgr:load()
T.check((Mgr.byId.chris.money or 0) >= 0 and (Mgr.byId.chris.balls or 0) >= 0,
  "money and balls restore cleanly")

------------------------------------------------------------------
-- 11. Move management, the PC, ball tiers, persistence and news
------------------------------------------------------------------

-- A TM move and a species that can learn it, plus a status move to forget.
data.moves.THUNDERBOLT = { name = "THUNDERBOLT", power = 95, type = "ELECTRIC",
                           pp = 15, accuracy = 100 }
data.moves.GROWL = { name = "GROWL", power = 0, type = "NORMAL", pp = 40, accuracy = 100 }
data.pokemon.CHARMANDER.tms = { THUNDERBOLT = true }

-- learnMove adds a move and forgets the weakest when the slot is full.
local mv = newRival()
mv.party[1].moves = { "SCRATCH", "EMBER", "TACKLE", "GROWL" }
T.check(mv:learnMove(mv.party[1], "THUNDERBOLT"), "a rival learns a TM move")
T.check(Util.contains(mv.party[1].moves, "THUNDERBOLT"), "the move is in the set")
T.check(not Util.contains(mv.party[1].moves, "GROWL"), "and the weakest was forgotten")
T.check(mv:canTmLearn("CHARMANDER", "THUNDERBOLT"), "the species is TM-compatible")
local emptyMoves = { species = "CHARMANDER", level = 5 }
T.check(mv:learnMove(emptyMoves, "THUNDERBOLT")
  and emptyMoves.moves and emptyMoves.moves[1] == "THUNDERBOLT",
  "learning attaches a move list when the slot had none")
data.pokemon.CHARMANDER.tms = { "THUNDERBOLT" }
T.check(mv:canTmLearn("CHARMANDER", "THUNDERBOLT"),
  "array-shaped TM compatibility is accepted")
data.pokemon.CHARMANDER.tms = { THUNDERBOLT = true }

-- TMs are bought with money, found in the world, and taught to the team.
local tmr = newRival()
tmr.money = 5000
local bought = tmr:buyTms()
T.eq(bought, "THUNDERBOLT", "the rival buys the available TM")
T.check(tmr.tms and tmr.tms.THUNDERBOLT, "and owns it")
local found = tmr:findTm()
T.check(found ~= nil, "or finds one while training")
tmr.party[1].moves = { "SCRATCH" }
tmr.map = "VIRIDIAN_POKECENTER"
local applied = tmr:applyTms()
T.check(#applied > 0, "owned TMs get taught")
T.check(Util.contains(tmr.party[1].moves, "THUNDERBOLT"), "the team learns it")

-- The PC: withdraw and deposit at will, and swap the best team in for a gym.
local boxer = newRival({ map = "VIRIDIAN_POKECENTER" })
boxer.party[1] = { species = "CHARMELEON", level = 10, moves = { "SCRATCH" } }
boxer:storePokemon({ species = "CHARMELEON", level = 35, moves = { "SCRATCH" } })
T.eq(#boxer.pcBoxes[1], 1, "a stronger spare sits in the PC")
boxer:swapTeamForGym({ { species = "GEODUDE", level = 14 } })
T.eq(boxer.party[1].level, 35, "the gym team pulls the stronger Pokemon in")
T.check(#boxer.party <= 6, "and never exceeds six")
local dep = newRival()
dep:depositPokemon(1)
T.eq(#dep.party, 0, "a deposit empties the slot")
T.eq(#dep.pcBoxes[1], 1, "into the PC")
local wd = newRival()
wd.party = { { species = "CHARMELEON", level = 20, moves = { "SCRATCH" } } }
wd:storePokemon({ species = "SQUIRTLE", level = 15, moves = { "TACKLE" } })
local withdrawn = wd:withdrawPokemon("SQUIRTLE")
T.check(withdrawn ~= nil and #wd.party == 2, "a withdraw brings a PC Pokemon in")

-- Ball tiers: richer rivals save for Great balls, which make catches better.
local rich = newRival({ map = "VIRIDIAN_CITY" })
rich.money = 10000
rich:restockBalls()
T.check(rich:itemCount("GREAT_BALL") > 0, "healthy winnings buy a Great Ball")
T.eq(rich:bestBall(), "GREAT_BALL", "and it becomes the catch ball")
T.eq(rich:catchBonus(), 1.3, "the Great Ball improves the catch odds")
local greatBefore = rich:itemCount("GREAT_BALL")
local ballSpent = rich:spendBall()
T.eq(ballSpent, "GREAT_BALL", "a catch spends the strongest ball")
T.eq(rich:itemCount("GREAT_BALL"), greatBefore - 1, "and one is gone from the bag")

-- Repels are only burned on routes the rival does NOT train on.
local repper = newRival({ map = "ROUTE_1" })
repper:addItem("REPEL", 3)
for _ = 1, 10 do repper:useFieldSupplies() end
T.eq(repper:itemCount("REPEL"), 3,
  "no Repel is wasted on the rival's own training route")

-- Defeated trainers stay defeated for that rival's simulation.
local ptb = newRival({ map = "ROUTE_1" })
ptb.party[1] = { species = "CHARMELEON", level = 30, moves = { "SCRATCH" } }
local ptbOut = Simulation.tryTrainerBattle(ptb)
if ptbOut and ptbOut.won then
  T.check(ptb:hasDefeatedTrainer(ptbOut.trainer), "the beaten trainer is recorded")
end

-- World news: every event becomes a line the player can read.
Mgr.log(r, { kind = "caught", species = "RATTATA" })
Mgr.log(r, { won = true, gym = { leader = "MISTY" } })
T.check(#Mgr.news > 0, "the world news feed holds lines")
local joined = table.concat((function()
  local out = {}
  for _, n in ipairs(Mgr.news) do out[#out + 1] = n.text end
  return out
end)(), "\n")
T.check(joined:find("caught a RATTATA") ~= nil, "news reports a catch")
T.check(joined:find("beat MISTY") ~= nil, "news reports a gym win")
T.check(Mgr.ticker and type(Mgr.ticker.text) == "string"
  and Mgr.ticker.text:find("WORLD NEWS") ~= nil,
  "new events are promoted to the overworld news ticker")

-- Champion continuity: a duel can dethrone the champion.
local champA = newRival({ map = "PEWTER_CITY" })
local champB = newRival({ map = "PEWTER_CITY", def = roster[2] })
champA.party[1] = { species = "CHARMELEON", level = 40, moves = { "SCRATCH" } }
champB.champion = true
champA.rivalTarget = champB
local champDuel = Simulation.attemptDuel(champA)
if champDuel and champDuel.won then
  T.check(champDuel.dethroned == true, "the title changes hands on a loss")
  T.check(champA.champion == true, "the challenger becomes Champion")
  T.check(champB.champion == false, "the old Champion is dethroned")
end
champB.champion = true
champA.champion = false
local oldRivals, oldById = Mgr.rivals, Mgr.byId
Mgr.rivals, Mgr.byId = { champA, champB }, { [champA.id] = champA, [champB.id] = champB }
Mgr.eliteChampionId = nil
T.eq(Mgr:selectEliteChampion(), champB,
  "the persisted Champion is selected for the next title defence")
Mgr.rivals, Mgr.byId, Mgr.eliteChampionId = oldRivals, oldById, nil

-- Route and encounter history are private per-rival state and survive saves.
champA:visitMap("ROUTE_1")
champA:recordEncounter("ROUTE_1", "RATTATA", true)
local progress = champA:serialize()
local restoredProgress = newRival()
restoredProgress:restore(progress)
T.eq(restoredProgress.visitedMaps.ROUTE_1, 1, "visited routes persist")
T.eq(restoredProgress.encounterHistory.ROUTE_1.RATTATA.caught, 1,
  "encounter history persists")

------------------------------------------------------------------
-- 12. The gauntlet lock: one starter, nothing more, until the lab is done
------------------------------------------------------------------

-- A rival before the gauntlet is complete can hold exactly one Pokemon.
local preGauntlet = Rival.new(roster[1], {
  data = data, personalities = exports.data.personalities,
  graph = graph, gyms = gyms, versionKey = "default",
  manager = { gauntletFinished = false } })
preGauntlet.map = "OAKS_LAB"
-- Same pre-2.6 call shape as the fixture builder above: the deal needs the
-- roster and a seed, or it returns nil and this whole section tests nothing.
local starter = Rival.firstAvailableStarter(roster[1], "default", data.pokemon,
  nil, { seed = 1, roster = roster })
T.check(preGauntlet:addPokemon(starter, 5) ~= nil,
  "the first starter is granted in the lab")
T.eq(#preGauntlet.party, 1, "and the party is exactly one")
T.check(preGauntlet:addPokemon(starter, 5) == nil,
  "a second Pokemon is refused before the gauntlet")
T.eq(#preGauntlet.party, 1, "so a full party of starters is impossible")

-- Repeated seeding (boot + New Game both re-seed) must not stack starters.
local seeder = newRival()
local seededCount = #seeder.party
Mgr:seed(seeder)
Mgr:seed(seeder)
T.eq(#seeder.party, seededCount,
  "seeding a rival that already has a party adds nothing")

-- Once the gauntlet is complete, growth is allowed again.
Mgr:finishGauntlet()
local postGauntlet = newRival()
T.check(postGauntlet:addPokemon("RATTATA", 5) ~= nil,
  "after the gauntlet a rival may grow its team")

------------------------------------------------------------------
-- 13. Goals beyond badges and player interaction (1.15.0)
------------------------------------------------------------------

-- The Pokédex: species the rival has held count toward milestones.
local dexer = newRival()
for _, sp in ipairs({ "CHARMANDER", "SQUIRTLE", "GEODUDE", "RATTATA", "PIDGEY",
                      "CHARMELEON" }) do dexer:registerDex(sp) end
T.eq(dexer:dexCount(), 6, "the dex counts distinct species held")
T.check(dexer:dexMilestone() == nil, "no milestone at six entries")
for _, sp in ipairs({ "BULBASAUR", "CATERPIE", "WEEDLE", "PIKACHU" }) do
  dexer:registerDex(sp)
end
T.eq(dexer:dexCount(), 10, "and reaches ten entries")
T.eq(dexer:dexMilestone(), 10, "crossing ten announces the milestone")
T.check(dexer:dexMilestone() == nil, "and it is announced exactly once")

-- Hunting: the target comes from the real encounter tables.
local hunter = newRival({ map = "ROUTE_1" })
local target = hunter:pickHuntTarget()
T.check(target ~= nil and data.pokemon[target] ~= nil,
  "a hunt target is drawn from the loaded encounter tables")

-- Rivals trade duplicate PC Pokemon between themselves.
local tradeA = newRival({ map = "ROUTE_1" })
local tradeB = newRival({ map = "ROUTE_1", def = roster[2] })
tradeA:storePokemon({ species = "PIDGEY", level = 5, moves = { "TACKLE" } })
tradeA:storePokemon({ species = "PIDGEY", level = 5, moves = { "TACKLE" } })
tradeB:storePokemon({ species = "RATTATA", level = 5, moves = { "TACKLE" } })
tradeB:storePokemon({ species = "RATTATA", level = 5, moves = { "TACKLE" } })
local trade = Simulation.tryTrade({ tradeA, tradeB }, {})
T.check(trade ~= nil, "two rivals with duplicates trade")
if trade then
  T.check(trade.gave ~= trade.got, "they swap different species")
  local function hasSpecies(r, species)
    for _, box in ipairs(r.pcBoxes or {}) do
      for _, s in ipairs(box) do if s.species == species then return true end end
    end
    return false
  end
  T.check(hasSpecies(tradeA, trade.got), "the giver receives the other's species")
  T.check(hasSpecies(tradeB, trade.gave), "and the receiver gets the first's")
end

-- A League-strong rival rematches a beaten leader for money.
local rematcher = newRival()
rematcher.party[1] = { species = "CHARMELEON", level = 40, moves = { "SCRATCH" } }
rematcher.defeatedLeaders = { OPP_BROCK = 1 }
local rm = Simulation.attemptRematch(rematcher)
T.check(rm ~= nil, "a rematch against a beaten leader resolves")
if rm then
  T.check(rm.won == true, "a strong rival wins the rematch")
  T.check((rematcher.money or 0) > 0, "and is paid for it")
  T.check((rematcher.rematchCooldown or 0) > 0, "and rests before the next one")
end

-- A beaten rival can part with a small item from its bag.
local gifter = newRival()
gifter:addItem("POTION", 1)
-- 5.0.9: this used to demand POTION specifically, which assumed the bag was
-- otherwise empty. It has not been since backgrounds began seeding a starting
-- inventory, so the assertion depended on hash order and failed on most runs.
-- The invariants that actually matter are that the gift comes FROM the bag
-- and LEAVES it -- both now checked against the bag as it really is.
local giftPool = {}
for item, count in pairs(gifter.inventory or {}) do
  if tonumber(count) and count > 0 and item ~= "POKE_BALL" then
    giftPool[item] = count
  end
end
local gift = gifter:pickGiftItem()
T.check(gift ~= nil and giftPool[gift] ~= nil, "a gift is drawn from the bag")
if gift then
  T.eq(gifter:itemCount(gift), giftPool[gift] - 1, "and leaves the bag")
end
-- and the draw is REPRODUCIBLE: same rival, same seed, same gift.
local giftA = newRival()
local giftB = newRival()
giftA:addItem("POTION", 1)
giftB:addItem("POTION", 1)
T.eq(giftA:pickGiftItem(), giftB:pickGiftItem(),
  "two identically seeded rivals gift the same item")
Mgr.game.save.inventory = { POTION = 0 }
T.check(Mgr:givePlayerItem("POTION"), "the item reaches the player's bag")
T.eq(Mgr.game.save.inventory.POTION, 1, "and is added to it")

-- Player-facing gifts are badge gated. Zero badges must never leak stronger
-- rival inventory, and Master Balls use only the dedicated eight-badge roll.
T.check(Mgr:rivalGiftAllowed("POTION", 0), "pre-Pewter gifts allow Potions")
T.check(Mgr:rivalGiftAllowed("POKE_BALL", 0), "pre-Pewter gifts allow Poké Balls")
T.check(not Mgr:rivalGiftAllowed("ANTIDOTE", 0), "pre-Pewter gifts reject status items")
T.check(not Mgr:rivalGiftAllowed("GREAT_BALL", 0), "pre-Pewter gifts reject Great Balls")
T.check(Mgr:rivalGiftAllowed("GREAT_BALL", 2), "Great Balls unlock with badge progress")
T.check(Mgr:rivalGiftAllowed("RARE_CANDY", 5), "rare gifts unlock late")
T.check(not Mgr:rivalGiftAllowed("MASTER_BALL", 8),
  "ordinary selection never awards a Master Ball")

local leagueGifter = newRival()
leagueGifter.inventory = { POTION = 1 }
leagueGifter.rng = {
  chance = function(_, chance) return chance == 0.15 end,
  int = function(_, lo) return lo end,
}
local oldBadgeCount, oldGivePlayerItem = Mgr.playerBadgeCount, Mgr.givePlayerItem
local granted
Mgr.playerBadgeCount = function() return 8 end
Mgr.givePlayerItem = function(_, item) granted = item return true end
T.eq(Mgr:awardRivalLoot(leagueGifter), "MASTER_BALL",
  "eight badges enable the 15 percent Master Ball reward")
T.eq(granted, "MASTER_BALL", "the Master Ball reaches the player")
T.eq(leagueGifter:itemCount("POTION"), 1,
  "the special reward does not consume ordinary rival inventory")
Mgr.playerBadgeCount, Mgr.givePlayerItem = oldBadgeCount, oldGivePlayerItem

-- The news feed reports the new activities.
Mgr.log(r, { kind = "trade", gave = "PIDGEY", got = "RATTATA", with = "matt" })
Mgr.log(r, { kind = "rematch", won = true, trainer = "OPP_BROCK" })
Mgr.log(r, { kind = "dex", milestone = 10 })
Mgr.log(r, { kind = "hunt", species = "RATTATA" })
local feed = table.concat((function()
  local out = {}
  for _, n in ipairs(Mgr.news) do out[#out + 1] = n.text end
  return out
end)(), "\n")
T.check(feed:find("traded a PIDGEY") ~= nil, "news reports a trade")
T.check(feed:find("rematch") ~= nil, "news reports a rematch")
T.check(feed:find("Pok") ~= nil and feed:find("dex entries") ~= nil,
  "news reports a dex milestone")
T.check(feed:find("hunting a RATTATA") ~= nil, "news reports a hunt")

------------------------------------------------------------------
-- 14. Regression coverage for 1.18.1 repair pass
------------------------------------------------------------------

-- Center arrival must enter the full Simulation workflow, not heal early and
-- bypass PC/economy/move management.
local centerRival = newRival({ map = "VIRIDIAN_POKECENTER" })
centerRival.objective = "HEAL"
centerRival.party[1].hp = 1
AI.onArrive(centerRival, {})
T.eq(centerRival.state, "HEALING", "Center arrival queues the complete visit")
Simulation.tickRival(centerRival, { playerMap = "VIRIDIAN_POKECENTER",
  near = true, allowGymBattle = true })
T.eq(centerRival.party[1].hp, centerRival:maxHpOf(centerRival.party[1]),
  "an on-screen Center visit still heals")

-- Level-up and evolution preserve a move learned outside the natural
-- learnset. The fixture has no TM registry for SURF, so use a known move as a
-- synthetic taught move that Charmeleon's learnset does not contain.
local mover = newRival()
mover.party[1].moves = { "SCRATCH", "TACKLE" }
mover.party[1].level = 15
mover.party[1].exp = Rival.expForLevel(data.pokemon.CHARMANDER, 16)
mover:gainExp(1)
T.check(Util.contains(mover.party[1].moves, "TACKLE"),
  "evolution preserves manually taught moves")

-- Selling removes only boxed surplus and retains one specimen for the dex
-- collection.
local seller = newRival()
seller:storePokemon({ species = "PIDGEY", level = 5, moves = { "TACKLE" } })
seller:storePokemon({ species = "PIDGEY", level = 6, moves = { "TACKLE" } })
local saleMoney, saleCount = seller:sellDuplicates()
T.eq(saleCount, 1, "exactly one duplicate is sold")
T.check(saleMoney > 0, "duplicate sales earn money")
local retained = 0
for _, box in ipairs(seller.pcBoxes) do
  for _, slot in ipairs(box) do if slot.species == "PIDGEY" then retained = retained + 1 end end
end
T.eq(retained, 1, "one collected specimen remains in the PC")

-- A synthetic reverse warp must never inherit coordinates belonging to the
-- opposite map.
local reverse = graph:edgeBetween("PEWTER_GYM", "PEWTER_CITY")
T.check(reverse ~= nil, "a reverse door route exists")
T.check(reverse.x == nil and reverse.y == nil,
  "reverse door routing does not reuse foreign coordinates")

-- Both participants carry real residual damage out of a simulated battle.
local damageA = { { species = "CHARMANDER", level = 12, moves = { "SCRATCH" } } }
local damageB = { { species = "SQUIRTLE", level = 12, moves = { "TACKLE" } } }
local damageResult = BattleSim.run(data, damageA, damageB, Util.rng(91))
T.check(type(damageResult.aHp) == "table" and type(damageResult.bHp) == "table",
  "BattleSim returns persistent HP for both teams")

-- Background League simulation must not invent opponents from a dataset that
-- does not contain a complete Elite Four and Champion.
local leagueCandidate = newRival()
leagueCandidate.champion = false
local leagueResult = Simulation.attemptLeague(leagueCandidate)
T.check(leagueResult == nil and leagueCandidate.champion == false,
  "an incomplete League dataset cannot award the title")

-- A hunt remembers a reachable habitat, and remote rivals cannot trade.
local routedHunter = newRival({ map = "PEWTER_CITY" })
local routedTarget = routedHunter:pickHuntTarget()
T.check(routedTarget == nil or routedHunter.huntMap == "ROUTE_1",
  "a hunt stores a real encounter-map destination")
local remoteA = newRival({ map = "ROUTE_1" })
local remoteB = newRival({ map = "PEWTER_CITY", def = roster[2] })
for _, rmt in ipairs({ remoteA, remoteB }) do
  rmt:storePokemon({ species = "PIDGEY", level = 5, moves = { "TACKLE" } })
  rmt:storePokemon({ species = "PIDGEY", level = 5, moves = { "TACKLE" } })
end
T.check(Simulation.tryTrade({ remoteA, remoteB }, {}) == nil,
  "rivals on different maps cannot trade remotely")

------------------------------------------------------------------
-- 15. Decision-quality and title-integrity regressions (1.18.3)
------------------------------------------------------------------

-- Missing compatibility data is not permission to teach an illegal TM.
local savedTms = data.pokemon.SQUIRTLE.tms
data.pokemon.SQUIRTLE.tms = nil
T.check(not mv:canTmLearn("SQUIRTLE", "THUNDERBOLT"),
  "unknown TM compatibility is rejected safely")
data.pokemon.SQUIRTLE.tms = savedTms

-- Rare Candy stock is now functional and respects the current Gym ceiling.
local candyUser = newRival()
local candyBefore = candyUser.party[1].level
candyUser:addItem("RARE_CANDY", 1)
local candied = candyUser:useRareCandy()
T.check(candied ~= nil and candyUser.party[1].level == candyBefore + 1,
  "an owned Rare Candy gains exactly one legal level")
T.eq(candyUser:itemCount("RARE_CANDY"), 0, "the used candy leaves the bag")

-- General shopping keeps savings instead of draining the wallet to zero.
local saver = newRival({ map = "VIRIDIAN_CITY" })
saver.money = 2000
saver.inventory = {}
saver.balls = 0
saver:restockBalls()
T.check(saver:itemCount("POKE_BALL") > 0, "a saver still buys emergency balls")
T.check(saver.money >= 1200, "and preserves a premium-ball reserve")

-- A vacant title remains with vanilla Blue; an arbitrary rival is never
-- installed merely because the party hook was queried.
local titleFlags, oldTitle = {}, Mgr.eliteChampionId
for _, rr in ipairs(Mgr.rivals) do
  titleFlags[rr] = rr.champion
  rr.champion = false
end
Mgr.eliteChampionId = nil
T.check(Mgr:selectEliteChampion() == nil and Mgr.eliteChampionId == "blue",
  "a vacant title uses the vanilla Champion")
for rr, flag in pairs(titleFlags) do rr.champion = flag end
Mgr.eliteChampionId = oldTitle

------------------------------------------------------------------
-- 16. Explicit player interaction and private story gates (1.18.4)
------------------------------------------------------------------

local helped = newRival()
helped.inventory.POKE_BALL, helped.balls = 0, 0
Mgr.game.save.inventory = { POKE_BALL = 1 }
local didHelp = Mgr:helpRequest(helped)
T.check(didHelp == true, "the player can explicitly answer a rival help request")
T.eq(Mgr.game.save.inventory.POKE_BALL, 0, "help debits the player's real bag")
T.eq(helped:itemCount("POKE_BALL"), 1, "and credits the rival's persistent bag")

-- An unsupported engine constructor aborts a Pokémon trade atomically.
local tradeSafe = newRival()
tradeSafe:storePokemon({ species = "PIDGEY", level = 5, moves = { "TACKLE" } })
tradeSafe:storePokemon({ species = "PIDGEY", level = 6, moves = { "TACKLE" } })
Mgr.game.save.party = {
  { species = "CHARMANDER", level = 5, moves = { "SCRATCH" } },
  { species = "RATTATA", level = 5, moves = { "TACKLE" } },
}
local partyBefore, pcBefore = #Mgr.game.save.party, #tradeSafe.pcBoxes[1]
local tradeCommitted = Mgr:tradeOffer(tradeSafe)
T.eq(#Mgr.game.save.party, partyBefore, "a trade never removes a player party slot")
T.eq(#tradeSafe.pcBoxes[1], pcBefore,
  "a trade atomically replaces the rival's offered slot")
if not tradeCommitted then
  T.eq(Mgr.game.save.party[#Mgr.game.save.party].species, "RATTATA",
    "an unavailable trade leaves the player's Pokémon untouched")
end

local gated = newRival()
T.check(not gated:canEnterMap("VICTORY_ROAD_1F"),
  "Victory Road is private to rivals without every badge")
for _, badge in ipairs(gated.ctx.gyms.order) do gated:awardBadge(badge) end
T.check(gated:canEnterMap("VICTORY_ROAD_1F"),
  "the same rival unlocks Victory Road through its own progress")

------------------------------------------------------------------
-- 17. Persistent companion mode (1.19.0)
------------------------------------------------------------------

local companion = Mgr.rivals[1]
local joined = Mgr:setCompanion(companion)
T.check(joined == true and Mgr.companionId == companion.id,
  "a rival can be selected as the persistent companion")
T.eq(companion.travelReason, "Accompanying the player",
  "the companion has a visible reason for following")
Mgr:save()
local companionState = run.loader.modSave.ai_rivals.state
T.eq(companionState.companionId, companion.id, "companion identity is saved")
local left = Mgr:setCompanion(nil)
T.check(left == true and Mgr.companionId == nil,
  "the player can dismiss the companion explicitly")
T.check(type(exports.registerAllySource) == "function"
  and type(exports.isDoubleBattle) == "function",
  "the absorbed double-battle integration API is available")

-- A-button interaction exposes actions only, not the old diagnostic card.
local actionItems = Mgr:rivalDetailItems(companion)
local actionLabels = {}
for _, item in ipairs(actionItems) do actionLabels[item.label] = item.right end
T.check(actionLabels.CHALLENGE ~= nil, "interaction menu exposes challenge status")
T.check(actionLabels.ACCOMPANY ~= nil, "interaction menu exposes accompany")
T.check(actionLabels["MOVE TO SAFE TILE"] ~= nil, "interaction menu exposes safe move")
T.check(actionLabels["GIVE HELP"] ~= nil, "interaction menu exposes help")
T.check(actionLabels.TRADE ~= nil, "interaction menu exposes trade")
T.eq(#actionItems, 5, "interaction menu omits the full trainer card")

local visibleTrainer = newRival({ map = "ROUTE_1" })
visibleTrainer:setState("TRAINING", "test visible training")
local visibleExp = visibleTrainer.party[1].exp
for _ = 1, 8 do
  Simulation.tickRival(visibleTrainer, {
    playerMap = "ROUTE_1", playerParty = Mgr.game.save.party,
    near = true, allowGymBattle = true,
  })
end
T.eq(visibleTrainer.party[1].exp, visibleExp,
  "a visible rival cannot gain abstract training experience")

------------------------------------------------------------------
-- 18. Interaction and transient-UI regressions (1.25.6)
------------------------------------------------------------------

-- A bag API can refuse a grant (for example because it is full). Do not
-- bypass that result by mutating the backing table or debit the rival later.
Mgr.game.save.inventory = {
  add = function() return false end,
  POTION = 0,
}
T.check(not Mgr:givePlayerItem("POTION"),
  "a false inventory grant result is respected")
T.eq(Mgr.game.save.inventory.POTION, 0,
  "a refused grant does not mutate the backing bag")

-- The direct runner fallback must propagate a refused challenge instead of
-- leaving a rival in CHALLENGING_PLAYER with no battle on screen.
local refused = newRival({ map = "ROUTE_1" })
Mgr.game.save.party = { { species = "CHARMANDER", level = 5, hp = 10 } }
local oldGetOverworld = Mgr.getOverworld
Mgr.getOverworld = function()
  return { runner = { run = function() return false end } }
end
local accepted = Mgr:startRivalChallenge(refused)
T.check(not accepted, "a refused direct battle runner is reported as failure")
T.check(Mgr.pending == nil and refused.state == "IDLE",
  "a refused challenge clears pending battle state")
Mgr.getOverworld = oldGetOverworld

-- Android/desktop manual challenges must not trust a queued start_battle row:
-- affected builds accept it but never drain it. Dialogue completion schedules
-- the direct BattleState push used by the working gauntlet path.
local mobileRows, mobileOpts
Mgr.generation = 1
Mgr.getOverworld = function()
  return { runner = { run = function(_, rows, opts)
    mobileRows, mobileOpts = rows, opts
    return true
  end } }
end
accepted = Mgr:startRivalChallenge(refused)
T.check(accepted and #mobileRows == 1 and mobileRows[1][1] == "show_text",
  "manual Gen1 challenge queues dialogue without unreliable start_battle")
T.check(mobileOpts and type(mobileOpts.onDone) == "function",
  "manual challenge installs a dialogue completion launch callback")
mobileOpts.onDone()
T.check(Mgr.pendingRivalBattleLaunch
    and Mgr.pendingRivalBattleLaunch.rivalId == refused.id,
  "dialogue completion schedules the deferred direct battle push")
Mgr.pendingRivalBattleLaunch, Mgr.pending = nil, nil
Mgr.getOverworld = oldGetOverworld

-- High-frequency news must remain a small transient queue. Persistent history
-- has its own independent forty-entry cap.
Mgr.ticker = { text = "WORLD NEWS  •  active", age = 0, duration = 8, offset = 0 }
Mgr.tickerQueue = {}
for i = 1, 20 do
  Mgr:addNews(refused, { kind = "news", text = "headline " .. tostring(i) })
end
T.check(#Mgr.tickerQueue <= 8, "the visible ticker queue is bounded")

------------------------------------------------------------------
-- 19. Persistent opponent scouting and counter teams (1.26.0)
------------------------------------------------------------------

data.moves.WATER_GUN = {
  name = "WATER GUN", power = 40, type = "WATER", pp = 25, accuracy = 100,
}
local counterBuilder = newRival({ map = "VIRIDIAN_POKECENTER" })
counterBuilder.party = {
  { species = "CHARMANDER", level = 12, moves = { "SCRATCH", "EMBER" } },
}
counterBuilder.pcBoxes = { {
  { species = "SQUIRTLE", level = 12, moves = { "TACKLE", "WATER_GUN" } },
} }
local rockTeam = {
  { species = "GEODUDE", level = 12, moves = { "TACKLE" } },
}
T.check(counterBuilder:rememberOpponent("chris", rockTeam, false, 77),
  "a rival records an observed opponent team")
T.check(counterBuilder:prepareCounterTeam("chris"),
  "a rival can prepare from persistent scouting")
T.eq(counterBuilder.party[1].species, "SQUIRTLE",
  "counter selection prefers super-effective coverage at equal level")
local counterSave = counterBuilder:serialize()
local counterReload = newRival()
T.check(counterReload:restore(counterSave), "counter knowledge save restores")
T.eq(counterReload:knownOpponentParty("chris")[1].species, "GEODUDE",
  "observed opponent teams persist across save/load")

local fieldCounter = newRival({ map = "ROUTE_1" })
fieldCounter.party = {
  { species = "CHARMANDER", level = 12, moves = { "SCRATCH", "EMBER" } },
}
fieldCounter.pcBoxes = { {
  { species = "SQUIRTLE", level = 12, moves = { "TACKLE", "WATER_GUN" } },
} }
T.check(not fieldCounter:prepareCounterTeam("chris", rockTeam),
  "a rival cannot withdraw a counter outside a Poke Center")
T.eq(fieldCounter.party[1].species, "CHARMANDER",
  "a field challenge uses the team currently on hand")
fieldCounter:rememberOpponent("chris", rockTeam, false, 81)
T.eq(fieldCounter.counterTarget, "chris",
  "a loss schedules the desired counter for a later Center visit")

local fairScout = newRival()
fairScout:rememberOpponent("player", {
  { species = "SQUIRTLE", level = 12, moves = { "WATER_GUN" } },
}, false, 88, false)
T.eq(#fairScout:knownOpponentParty("player")[1].moves, 0,
  "player scouting does not reveal unused moves from the save party")
T.check(fairScout:rememberRevealedMove("player", "SQUIRTLE", "WATER_GUN"),
  "a move selected in battle can be added to scouting knowledge")
T.eq(fairScout:knownOpponentParty("player")[1].moves[1], "WATER_GUN",
  "revealed moves are retained for later counter planning")

------------------------------------------------------------------
-- 20. Companion-only double battles (1.26.1)
------------------------------------------------------------------

local oldOverworldForMode, oldCompanion = Mgr.getOverworld, Mgr.companionId
Mgr.getOverworld = function()
  return { runner = { run = function() return true end } }
end
Mgr.game.save.party = { { species = "CHARMANDER", level = 8, hp = 20 } }
refused.party[1].hp = refused:maxHpOf(refused.party[1])
Mgr.companionId = nil
T.eq(Mgr:rivalBattleMode(refused), "SINGLE",
  "a rival challenge is single without an active companion")
companion.party[1].hp = companion:maxHpOf(companion.party[1])
Mgr.companionId = companion.id
T.eq(Mgr:rivalBattleMode(refused), "DOUBLE",
  "a healthy accompanying rival enables an eligible double battle")
Mgr.companionId, Mgr.getOverworld = oldCompanion, oldOverworldForMode

------------------------------------------------------------------
-- 21. Companion handoff and battle-state synchronization (1.26.2)
------------------------------------------------------------------

local incumbent = companion
Mgr.companionId = incumbent.id
incumbent.travelReason = "Accompanying the player"
local blockedReplacement = newRival({ def = roster[2] })
blockedReplacement.missingHMForMap = function() return "SURF" end
local oldWorldView = Mgr.worldView
Mgr.worldView = function() return { playerMap = "ROUTE_1" } end
local switched = Mgr:setCompanion(blockedReplacement)
T.check(not switched, "an HM-blocked replacement cannot become companion")
T.eq(Mgr.companionId, incumbent.id,
  "a failed replacement leaves the current companion selected")
T.eq(incumbent.travelReason, "Accompanying the player",
  "a failed replacement does not dismiss the current companion")
Mgr.worldView = oldWorldView

local syncSlot = {
  species = "CHARMANDER", level = 8, exp = 100, hp = 12,
  moves = { "SCRATCH" }, status = "POISON",
}
local syncMon = {
  species = "SQUIRTLE", level = 9, exp = 220, hp = 17,
  moves = { { id = "TACKLE", pp = 21 } }, status = nil,
  pp = { 21 },
}
Mgr.companionBattleSlot, Mgr.companionBattleMon = syncSlot, syncMon
T.check(Mgr:restoreCompanionBattle({ __dbExternalAlly = true }),
  "a completed companion battle restores its persistent slot")
T.eq(syncSlot.species, "SQUIRTLE", "battle evolution/species changes persist")
T.eq(syncSlot.moves[1], "TACKLE", "battle move changes persist")
T.eq(syncSlot.level, 9, "battle levels persist")
T.eq(syncSlot.status, nil, "battle status cures persist")
T.eq(syncSlot.pp[1], 21, "available move PP persists")
Mgr.companionId = oldCompanion

------------------------------------------------------------------
-- 22. Responsive actions and persistent blackouts (1.27.1)
------------------------------------------------------------------

Mgr.pendingRivalAction = nil
T.check(Mgr:queueRivalAction(refused, { value = "_help" }),
  "touch-style menu rows queue their action value")
T.eq(Mgr.pendingRivalAction.value, "_help",
  "a table-valued menu choice is normalized")
T.check(not Mgr:queueRivalAction(refused, { value = "_unknown" }),
  "unknown menu actions are rejected")
Mgr.pendingRivalAction = nil

local blackout = newRival({ map = "ROUTE_1" })
blackout.lastPokemonCenter = "VIRIDIAN_POKECENTER"
for _, mon in ipairs(blackout.party) do mon.hp = 0 end
local warped, center = blackout:warpToLastPokemonCenter()
T.check(warped, "a fully fainted rival blacks out")
T.eq(center, "VIRIDIAN_POKECENTER", "blackout uses the last visited Center")
T.eq(blackout.map, "VIRIDIAN_POKECENTER", "blackout changes the rival map")
T.eq(blackout.state, "HEALING", "a blacked-out rival is ready to heal")

local blackoutSave = blackout:serialize()
local blackoutReload = newRival()
T.check(blackoutReload:restore(blackoutSave), "blackout save restores")
T.eq(blackoutReload.lastPokemonCenter, "VIRIDIAN_POKECENTER",
  "last visited Center persists across save/load")

local centerVisit = newRival({ map = "VIRIDIAN_POKECENTER" })
T.check(centerVisit:recordPokemonCenterVisit(), "a Center visit is recorded")
T.eq(centerVisit.lastPokemonCenter, "VIRIDIAN_POKECENTER",
  "the current Center becomes the blackout destination")

------------------------------------------------------------------
-- 23. Character-created roster size and richer dialogue (1.28.0)
------------------------------------------------------------------

Runtime.emit("intro.oak_speech.answered", {
  saveKey = "ai_rivals_count", value = "2",
})
T.eq(#ordinaryOnly(Mgr.rivals), 2, "the character-creation answer changes the live roster")
T.eq(Mgr.rivals[1].id, "chris", "one-to-four selection preserves roster order")
T.eq(Mgr.rivals[2].id, "dyanari", "two rivals selects the first two rivals")
T.check(Mgr.byId.matt == nil and Mgr.byId.larissa == nil,
  "unselected rivals are absent from simulation and spawning lookups")

Mgr.gauntlet = { active = true, index = 1,
  order = { "chris", "dyanari" }, lab = "OAKS_LAB" }
Runtime.emit("intro.oak_speech.answered", {
  saveKey = "ai_rivals_count", value = "3",
})
T.eq(#ordinaryOnly(Mgr.rivals), 3, "three-rival selection is accepted")
T.eq(#Mgr.gauntlet.order, 3, "the active gauntlet follows the selected count")
T.eq(Mgr.gauntlet.order[3], "matt", "gauntlet order contains selected rivals only")

Runtime.emit("intro.oak_speech.answered", {
  saveKey = "ai_rivals_count", value = "1",
})
T.eq(#ordinaryOnly(Mgr.rivals), 1, "one-rival selection is accepted")
Runtime.emit("intro.oak_speech.answered", {
  saveKey = "ai_rivals_count", value = "4",
})
T.eq(#ordinaryOnly(Mgr.rivals), 4, "four-rival selection restores the full roster")
Mgr.gauntlet = nil

local personalityLines = exports.data.dialogue.greeting.IDLE
for _, personality in ipairs({ "CHALLENGER", "SPEEDRUNNER", "COLLECTOR", "STRATEGIST" }) do
  T.check(type(personalityLines[personality]) == "table"
      and #personalityLines[personality] >= 3,
    personality .. " has an expanded personality-specific idle dialogue pool")
end

------------------------------------------------------------------
-- 24. FOLLOWERS_EX-style entity movement (1.29.0)
------------------------------------------------------------------

local followRival = Mgr.rivals[1]
local followEntity = {
  id = 777, name = "AIR_" .. followRival.id,
  cellX = 3, cellY = 3, facing = "down", moving = false,
}
local oldGame, oldSpawned, oldFollowing = Mgr.game, Mgr.spawned, Mgr.companionId
Mgr.game = { overworld = {
  isOverworld = true, map = { id = "ROUTE_1" }, npcs = { followEntity },
  player = { stepFrames = 12 },
} }
Mgr.spawned = { [followRival.id] = 777 }
Mgr.companionId = followRival.id
followRival.map, followRival.x, followRival.y = "ROUTE_1", 3, 3
followRival.walking = false
T.eq(Mgr:liveRivalEntity(followRival), followEntity,
  "the live rival NPC is resolved for follower animation")
T.check(Mgr:moveRivalNpc(followRival, 4, 3, "right"),
  "a companion begins an entity-local follower step")
T.check(followEntity.moving == true and followEntity.targetX == 4
    and followEntity.targetY == 3 and followEntity.progress == 0,
  "following uses NPC target/progress fields instead of a script queue")
T.eq(followEntity.stepFrames, 12,
  "the rival matches the player's current walking cadence")
followRival.walking, followRival.walkTarget = false, nil
Mgr.game, Mgr.spawned, Mgr.companionId = oldGame, oldSpawned, oldFollowing

run.release()
T.finish("ai_rivals")
