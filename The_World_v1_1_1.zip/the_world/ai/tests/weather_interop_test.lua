-- Standalone: lua5.1 tests/weather_interop_test.lua  (from mods/ai_rivals)
--
-- THE TEST THAT WOULD HAVE CAUGHT THE DRIFT.
--
-- This mod carried hand-written copies of Weather FX's tables for eighteen
-- releases and nothing compared them to the real thing, so when Weather FX
-- added STORM (chips ELECTRIC, reports "RAINY") our copy quietly kept saying
-- RAINY meant WATER.
--
-- Run against a real Weather FX tree to compare our fallback catalogue with
-- its lib/Types.lua, entry by entry:
--
--     lua5.1 tests/weather_interop_test.lua /path/to/mods/weather_fx
--
-- With no path it verifies the INVARIANTS the model must hold whatever the
-- host says -- which is what makes it safe to run in CI where Weather FX is
-- not installed.

local cache = {}
local function req(n)
  if cache[n] then return cache[n] end
  local f = assert(loadfile(n .. ".lua")); cache[n] = f(req, {}); return cache[n]
end
local Util, Weather = req("src/Util"), req("src/Weather")

local pass, fail, warn = 0, 0, 0
local function eq(a, b, m) if a == b then pass = pass + 1 else fail = fail + 1
  print(("FAIL %s (got %s want %s)"):format(m, tostring(a), tostring(b))) end end
local function ok(c, m) if c then pass = pass + 1 else fail = fail + 1; print("FAIL " .. m) end end

-- ------------------------------------------------------------------
-- Invariants -- always checked
-- ------------------------------------------------------------------

-- A battle string that several overworld ids share must NOT be used to infer
-- a chip type. This is the property that broke; assert it structurally.
local byBattle = {}
for id, def in pairs(Weather.FALLBACK) do
  if def.battle then
    byBattle[def.battle] = byBattle[def.battle] or {}
    byBattle[def.battle][#byBattle[def.battle] + 1] = id
  end
end
local ambiguous = 0
for battle, ids in pairs(byBattle) do
  local chips = {}
  for _, id in ipairs(ids) do
    chips[tostring(Weather.FALLBACK[id].chip)] = true
  end
  if Util.count(chips) > 1 then
    ambiguous = ambiguous + 1
    -- every id under an ambiguous battle string must still resolve correctly
    for _, id in ipairs(ids) do
      eq(Weather.chipType(nil, id), Weather.FALLBACK[id].chip,
         id .. " resolves its own chip despite sharing the " .. battle .. " string")
    end
  end
end
ok(ambiguous > 0,
   "the catalogue really does contain ambiguous battle strings (so the test means something)")

-- Nothing in the model may consult the battle string for a chip.
-- Comment lines are stripped first: this file EXPLAINS the battle-string trap
-- at length, and matching prose would fail on the documentation rather than on
-- the code.
local src = io.open("src/Weather.lua"):read("*a")
local code = {}
for line in src:gmatch("[^\n]*") do
  if not line:match("^%s*%-%-") then code[#code + 1] = line end
end
code = table.concat(code, "\n")
ok(not code:find("battleWeather"),
   "the weather model never CALLS exports.battleWeather() to resolve a chip")

-- ------------------------------------------------------------------
-- Comparison against a real Weather FX tree -- when one is given
-- ------------------------------------------------------------------
local root = arg and arg[1]
if not root then
  print("(no Weather FX path given -- invariants only)")
  print(("\n%d passed, %d failed"):format(pass, fail))
  os.exit(fail == 0 and 0 or 1)
end

local path = root .. "/lib/Types.lua"
local handle = io.open(path)
if not handle then
  print("FAIL cannot open " .. path)
  os.exit(1)
end
local text = handle:read("*a")
handle:close()

-- Parse the catalogue out of the source. Deliberately a text scan rather than
-- loading the module: lib/Types.lua expects Weather FX's own loader, and this
-- suite must not need a running host.
local ids = {}
for pos, id in text:gmatch("()id = \"([A-Z_0-9]+)\"") do
  ids[#ids + 1] = { pos = pos, id = id }
end
ok(#ids > 10, "the Weather FX catalogue was parsed")

local seen = {}
local drift = 0
for i, entry in ipairs(ids) do
  local stop = ids[i + 1] and ids[i + 1].pos or #text
  local body = text:sub(entry.pos, stop)
  if not seen[entry.id] then
    seen[entry.id] = true
    local chip = body:match("chipType = \"([A-Z_]+)\"")
    local battle = body:match("battle = \"([A-Z_]+)\"")
    local mine = Weather.FALLBACK[entry.id]
    if not mine then
      -- Not a failure: Weather FX may add weathers at any time, and the model
      -- reads them live from the host. It only means our OFFLINE fallback is
      -- behind, which matters solely when Weather FX is absent.
      warn = warn + 1
      print(("  note: %s is new to us (host-read only; fallback lacks it)"):format(entry.id))
    else
      if chip ~= mine.chip then
        drift = drift + 1
        print(("FAIL %s chip drifted: ours=%s theirs=%s")
          :format(entry.id, tostring(mine.chip), tostring(chip)))
      end
      if battle ~= mine.battle then
        drift = drift + 1
        print(("FAIL %s battle string drifted: ours=%s theirs=%s")
          :format(entry.id, tostring(mine.battle), tostring(battle)))
      end
    end
  end
end
eq(drift, 0, "our fallback catalogue matches the installed Weather FX")

-- The stable export surface Weather FX documents must still be there.
local main = io.open(root .. "/main.lua")
if main then
  local body = main:read("*a")
  main:close()
  for _, fn in ipairs({ "weather", "battleWeather", "types", "version" }) do
    ok(body:find("mod.exports." .. fn, 1, true) ~= nil,
       "Weather FX still exports " .. fn)
  end
end

print(("\n%d passed, %d failed, %d notes"):format(pass, fail, warn))
os.exit(fail == 0 and 0 or 1)
