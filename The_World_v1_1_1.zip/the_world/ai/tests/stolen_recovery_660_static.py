from pathlib import Path
import json
r=Path(__file__).resolve().parents[1]
m=(r/'main.lua').read_text(); s=(r/'src/StolenRecovery.lua').read_text(); p=(r/'src/manager/Persistence.lua').read_text()
assert json.loads((r/'manifest.json').read_text())['version']=='6.6.0'
for x in ['ROCKET_STOLEN_PURCHASE','STOLEN_POKEMON_FOUND','RETURN_STOLEN_POKEMON','STOLEN_POKEMON_RECOVERED','returnToOwner','originalOwnerId']: assert x in s
assert 'offerFromIssuer' in s and 'worldState:addEvent' in s
assert 'stolenRecovery' in m and 'stolenRecovery' in p
print('stolen recovery 6.6 static: ok')
