from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
rv=(ROOT/"src/Rival.lua").read_text()
m=(ROOT/"manifest.json").read_text()
assert 'if vk == "gold" or vk == "gen2"' in rv
for mon in ("CHIKORITA","CYNDAQUIL","TOTODILE"):
    assert f'"{mon}"' in rv
assert "for _, baseSpecies in ipairs(out)" in rv
assert '"version": "7.2.3"' in m
print("7.2.3 Gold starter checks passed")
