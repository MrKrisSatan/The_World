#!/usr/bin/env python3
"""Gold trainer battles must stay INSIDE the mod (3.1).

We used to ship patches/0001-gen2-mod-trainer-battle.patch. An engine patch is
not acceptable: a mod has to work on a stock install, and a player who cannot
patch their engine had a feature that silently did nothing.

This file fails if the patch returns, if any doc claims one is needed, or if
the mod-only route is removed.
"""
import re
import sys
from pathlib import Path

root = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(Path(__file__).resolve().parent))
from _version import at_least

main = (root / "main.lua").read_text(encoding="utf-8")
errors = []


def need(token, blob, label):
    if token not in blob:
        errors.append(label)


# --- no patch may ship, and nothing may require one -------------------------
if (root / "patches").exists():
    stray = [p.name for p in (root / "patches").iterdir()
             if p.suffix in (".patch", ".diff")]
    if stray:
        errors.append(f"an engine patch is shipping again: {stray}")

# Documentation must not tell a player to patch the engine. Comments in code
# that EXPLAIN the removal are fine, so only .md is scanned for the claim.
for doc in (root / "docs").glob("*.md"):
    text = doc.read_text(encoding="utf-8")
    for line in text.splitlines():
        low = line.lower()
        if "patch" not in low:
            continue
        # a line that says a patch is REQUIRED/NEEDED/SHIPPED is the failure
        if re.search(r"(need|needs|require|requires|must apply|we ship)\b[^.]*patch",
                     low) and "no engine patch" not in low and "~~" not in line:
            errors.append(f"{doc.name} still claims an engine patch is needed: "
                          f"{line.strip()[:80]}")

# --- the mod-only route must exist and be reached first on Gold -------------
need("function M:pushGen2RivalBattle", main, "no Gold battle route")
need('if self.versionKey == "gen2" then', main,
     "Gold does not take its own battle route first -- the Gen 1 path uses "
     "BattleState.newTrainer, which Gen2Compat marks ABSENT on Gold")
route = main[main.index("function M:pushGen2RivalBattle"):]
route = route[:route.index("\nfunction M:pushManualRivalBattle")]
need("world:overworld()", route,
     "the route does not use the public world facade")
need("ow.startBattle", route,
     "the route does not use World:startBattle, the only Gold entry point that "
     "constructs and pushes a trainer battle in one call")
need("party = {}", route,
     "the trainer shell carries a party, so the trainer.party hook would not be "
     "the single source of the team and a Gold roster could drift from the "
     "rival's real one")
for banned in ("queueScript", "newTrainer", "src.battle.gen2"):
    if banned in "\n".join(l for l in route.splitlines()
                           if not l.lstrip().startswith("--")):
        errors.append(f"the Gold route reaches for {banned}: queueScript "
                      f"refuses the trainer arm, newTrainer is absent on Gold, "
                      f"and a direct gen2 require is not a supported mod seam")

# --- the party must still come from our existing hook -----------------------
need('"trainer.party"', main,
     "the trainer.party hook is gone -- it is what supplies the rival's real "
     "team on BOTH generations")

# --- the callback must not double-count -------------------------------------
# Comments stripped first: the route DOCUMENTS why this call was removed, and
# matching prose would fail on the documentation. (Sixth occurrence of this
# trap in this project -- strip comment lines before scanning source, always.)
route_code = "\n".join(l for l in route.splitlines()
                       if not l.lstrip().startswith("--"))
if re.search(r"onRivalBattleFinished", route_code):
    errors.append("the Gold callback calls a function that does not exist; "
                  "battle.ended already settles a rival battle on both "
                  "generations and doing it twice double-counts everything")

# --- preserved ---------------------------------------------------------------
for token in ("KantoCompat", "WonderTrade.install(mod, M)", "Comms = Comms",
              "LifePath = LifePath", "Career = Career"):
    need(token, main, f"earlier contract lost: {token}")
errors.extend(x for x in [at_least(root, "3.1.0")] if x)

if errors:
    for error in errors:
        print("FAIL", error)
    raise SystemExit(1)
print("AI Rivals v3.1 Gold battles: no engine patch, World:startBattle plus "
      "the mod's own trainer.party hook PASS")
