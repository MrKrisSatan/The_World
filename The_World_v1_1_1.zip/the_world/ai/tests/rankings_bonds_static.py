import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent))
from _version import at_least

root = Path(__file__).resolve().parents[1]
rel = (root / "src" / "Relationships.lua").read_text()
rank = (root / "src" / "Rankings.lua").read_text()
ach = (root / "src" / "Achievements.lua").read_text()
league = (root / "src" / "League.lua").read_text()
sim = (root / "src" / "Simulation.lua").read_text()
ai = (root / "src" / "AI.lua").read_text()
poke = (root / "src" / "Pokegear.lua").read_text()
main = (root / "main.lua").read_text()
rival = (root / "src" / "Rival.lua").read_text()

assert at_least(root, "4.6.0") is None, at_least(root, "4.6.0")


def body(text):
    """Source with comment lines removed.

    Lesson 3, six occurrences and counting: a file that DOCUMENTS a trap
    matches every pattern for the trap. Every 'must not appear' check below
    scans this, never the raw text.
    """
    return "\n".join(l for l in text.splitlines() if not l.strip().startswith("--"))


relBody = body(rel)
simBody = body(sim)
achBody = body(ach)

# --- The new states exist and are ordered before what they refine -----------
for state in ("DEVOTED", "NEMESIS", "PROTEGE", "ADMIRER", "ESTRANGED"):
    assert f'"{state}"' in rel, f"{state} is not declared in R.STATES"
    assert f'R.LABELS' in rel and state in rel.split("R.LABELS")[1][:400], \
        f"{state} has no label"

# Order is the design: a general state tested first makes the specific one
# unreachable. Pin the pairs by source position rather than by prose.
def before(a, b, text, why):
    ia, ib = text.index(a), text.index(b)
    assert ia < ib, why

stateFn = relBody[relBody.index("function R.state(bond)"):relBody.index("function R.pairState")]
before('return "NEMESIS"', 'return "HOSTILE"', stateFn,
       "NEMESIS must be tested before HOSTILE or it can never be reached")
before('return "DEVOTED"', 'return "ALLIED"', stateFn,
       "DEVOTED must be tested before ALLIED")
before('return "ADMIRER"', 'return "RESPECT"', stateFn,
       "ADMIRER must be tested before RESPECT")

pairFn = relBody[relBody.index("function R.pairState"):relBody.index("function R.isPairState")]
before('return "UNREQUITED"', 'return "CLOSE_FRIENDS"', pairFn,
       "UNREQUITED must be tested before CLOSE_FRIENDS: DEVOTED is itself warm")
assert 'a == "DEVOTED" and b == "DEVOTED"' in pairFn, \
    "LOVERS must require BOTH sides devoted -- it is not a state one rival can decide"

# --- Devotion is rare by conjunction, not by a die roll ---------------------
for const in ("DEVOTION_AFFECTION", "DEVOTION_REGARD", "DEVOTION_FAVOURS",
              "DEVOTION_RESPECT", "DEVOTION_TICKS"):
    assert f"R.{const}" in rel, f"{const} is missing"
assert "rng" not in relBody and "random" not in relBody, \
    "nothing in the relationship model may roll for a state"

# The devotion clock must not read `since`, which is reset every time the
# derived state moves -- a threshold cancelled by being met can never be held.
assert "met = num(tick, 0)" in rel, "bonds must record when the pair MET"
assert "num(bond.met" in rel, "the devotion clock must read `met`"

# --- Rankings put the player in the table ----------------------------------
assert "function Rankings.playerRow" in rank
assert "League.sortStandings(rows)" in rank, \
    "ranking order must reuse the League's comparison, not restate it"
assert "row.rank = i" in rank
assert 'id = "__player"' in rank
assert "if isTable(player) then" in rank, \
    "a save with no player facts must not get an invented row"

# --- Achievements are derived, never logged --------------------------------
assert "function Achievements.record" in ach
for banned in ("achievements[#achievements", "table.insert(rival.achievements",
               "rival.achievementLog", "self.achievements ="):
    assert banned not in achBody, f"achievements must not be logged ({banned})"
assert "gyms.byBadge" in ach and "rival.badges" in ach, \
    "gym highlights must join the badge case to the gym table"
assert "opts.league = record" in ach, \
    "the resolved League record must go back into opts before highlights read it"

# --- Title matches ---------------------------------------------------------
assert "function League.mayTitleMatch" in league
assert "function League.recordTitleMatch" in league
assert "record.defences" in league
assert "if not won then record.qualified = false end" in league, \
    "a beaten challenger must re-clear the Elite Four: one clear buys ONE shot"
assert "function Simulation.tryTitleMatch" in sim
assert "if world and world.playerChampion then return nil end" in sim, \
    "the simulation must never settle the PLAYER's title behind their back"
assert "playerChampion = self.playerChampion == true" in main, \
    "worldView must carry playerChampion or the guard above reads nil"

# The 4.5.x dead feature: these refusals ended the function, so nobody could
# ever qualify while a champion existed, and §30's challenge was unreachable.
assert 'return nil, "title already held"' not in simBody, \
    "a held title must no longer refuse the Elite Four run outright"
assert 'return nil, "player is champion"' not in simBody
assert "local contested = titleHolder ~= nil" in sim
assert "if contested then" in sim

# --- Lovers travel together ------------------------------------------------
assert 'rival.objective = "STAY_CLOSE"' in ai
assert "partnerAmong" in ai and "function Rival:partnerAmong" in rival
assert "function Rival:pairStateWith" in rival
# It must not be bolted onto the personality priority lists (nine places to
# forget), and must sit below the gym/heal guards.
aiBody = body(ai)
assert '"STAY_CLOSE"' not in (root / "data" / "personalities.lua").read_text(), \
    "STAY_CLOSE belongs in evaluate, not in every personality's priority list"
# Anchored on the wander ROLL, not the first mention of `wanderChance` -- the
# default-personality fallback names it 130 lines earlier, and a prefix anchor
# that matches the wrong occurrence fails for a reason that has nothing to do
# with the contract (lesson 2).
# 5.2.0: repointed. The wander roll now reads a style-biased threshold
# (Travel.wanderChance), so the literal `rival.rng:chance(rival.personality.
# wanderChance or 0)` no longer exists and this failed on correct code -- the
# same restating-an-implementation trap lesson 19 names, one line below a
# comment about lesson 2. The CONTRACT is unchanged: staying close outranks
# the detour. Anchored on the detour's own setState, which is unique to that
# block and does not move when the threshold changes.
before('rival.objective = "STAY_CLOSE"',
       'rival:setState("TRAVELLING", "detour")', aiBody,
       "staying close must outrank the wander detour")
assert 'rival.state ~= "CHALLENGING_GYM"' in ai, \
    "being in love must not interrupt a gym battle"

# --- Grievance toward a rival feeds Team Rocket ----------------------------
lp = (root / "src" / "LifePath.lua").read_text()
assert "facts.hostileToRival" in lp, \
    "Rocket's grievance prerequisite must see rival-to-rival hatred too"
assert "function Rival:hasNemesis" in rival

# --- The screens -----------------------------------------------------------
assert 'AIR_RivalGearRankings' in poke and 'AIR_RivalGearRecord' in poke
assert '"TRAINER RANKINGS"' in poke
assert '"CHAMPION"' in poke
assert "function M:trainerRankings" in main and "function M:trainerRecord" in main
# Full-width sentences get their own fitter: fitRow's ten characters is the
# LABEL half of a label+status pair and beheads a highlight.
assert "WIDE_COLS = 17" in poke
assert "local function wideLines" in poke

print("rankings, records, bonds and title matches static PASS")
