from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
main=(ROOT/"main.lua").read_text()
manifest=(ROOT/"manifest.json").read_text()

assert 'GEN1_CONNECTION_SENTINEL = "__airGen1ConnectionYieldV739"' in main
assert 'GEN2_CONNECTION_SENTINEL = "__airGen2ConnectionYieldV739"' in main
assert "local function yieldPhysicalActorsBeforeConnection()" in main
assert "M:despawnAll()" in main
assert "M.rocket:despawnAll()" in main
assert "M.rangers:despawnAll()" in main

# Gen 1 path
assert "local previous = OW.crossConnection" in main
assert "OW.crossConnection = function(self, ...)" in main

# Gen 2 / Gold authoritative path
assert 'require, "src.world.gen2.World"' in main
assert "local previous = World2.tryConnection" in main
assert "World2.tryConnection = function(world, dir, ...)" in main
assert "map:connection(compass[dir] or dir)" in main
assert "if conn then yieldPhysicalActorsBeforeConnection() end" in main

assert 'Util.guard("connection-yield"' in main
assert '"version": "7.3.9"' in manifest
print("7.3.9 four-game connection-yield checks passed")
