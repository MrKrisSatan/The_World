-- Standalone: lua5.1 tests/league_test.lua   (from mods/ai_rivals)
--
-- The 1.39.0 League model. Two properties matter above all:
--
--   1. A rival that cannot win must not keep throwing itself at the Elite Four.
--      This is the bug the Gym path had in the original build and had fixed;
--      the League path was written from the same template and never was.
--   2. A title shot must be EARNED. §38 says the AI plays by the same rules as
--      the player, and the player cannot challenge the Champion without first
--      beating the Elite Four.

local cache = {}
local function req(n)
  if cache[n] then return cache[n] end
  local f = assert(loadfile(n .. ".lua")); cache[n] = f(req, {}); return cache[n]
end
local Util, League = req("src/Util"), req("src/League")

local pass, fail = 0, 0
local function eq(a, b, m) if a == b then pass = pass + 1 else fail = fail + 1
  print(("FAIL %s (got %s want %s)"):format(m, tostring(a), tostring(b))) end end
local function ok(c, m) if c then pass = pass + 1 else fail = fail + 1; print("FAIL " .. m) end end

-- 1. A fresh record lets a rival straight in.
local r = League.newRecord()
eq(r.attempts, 0, "a new record has no attempts")
eq(r.qualified, false, "and no title entitlement")
ok(League.mayAttempt(r, 100), "a rival that has never tried may attempt")
eq(League.bar(r), 0, "with no extra strength to find")

-- 2. THE ESCALATION. Repeated failure at one stage must back the rival off.
local stuck = League.newRecord()
local cooldowns = {}
for i = 1, 8 do
  League.recordAttempt(stuck, 4, false, { strength = 200 })
  cooldowns[#cooldowns + 1] = stuck.cooldown
end
-- The first couple of failures both sit on League.MIN_GAP: nobody runs the
-- Elite Four every eight seconds even when it is going well, so the floor
-- binds before the escalation does. What must be true is that persistent
-- fruitless failure backs the rival off further.
ok(cooldowns[1] >= League.MIN_GAP, "even the first retry respects the minimum gap")
ok(cooldowns[8] > cooldowns[2], "persistent fruitless failure waits much longer")
ok(cooldowns[8] > cooldowns[4], "and the eighth longer than the fourth")
ok(cooldowns[8] <= League.MAX_COOLDOWN, "but the wait is capped")
eq(stuck.walls[4], 8, "the wall records every failure at that stage")
eq(select(1, League.wall(stuck)), 4, "and names the stage that keeps stopping them")
eq(select(2, League.wall(stuck)), 8, "with the count")
ok(League.bar(stuck) > 0, "the bar rises with failures")
ok(League.bar(stuck) <= League.MAX_BAR, "and is capped")

-- The bar is a STRENGTH comparison, so training gets you back in and sulking
-- does not. This is §28's loop as a mechanism rather than a description.
stuck.cooldown = 0
ok(not League.mayAttempt(stuck, 200),
   "a rival no stronger than when it failed may NOT walk back in")
ok(League.mayAttempt(stuck, 200 + League.MAX_BAR + 1),
   "one that has genuinely trained may")
stuck.cooldown = 5
ok(not League.mayAttempt(stuck, 99999),
   "and nobody attempts while still on cooldown, however strong")

-- ...but a rival that comes back STRONGER and still loses is making progress,
-- and must not be backed off for it. Escalating on every failure punishes the
-- exact behaviour §28 asks for.
local improving = League.newRecord()
League.recordAttempt(improving, 4, false, { strength = 200 })
local first = improving.cooldown
for step = 1, 6 do
  League.recordAttempt(improving, 4, false, { strength = 200 + step * 50 })
end
eq(improving.cooldown, first,
   "a rival that keeps getting stronger is not backed off for losing")
ok(improving.cooldown < cooldowns[8],
   "and waits far less than one that is getting nowhere")

-- 3. Clearing resets the walls -- the problem is demonstrably solved.
local winner = League.newRecord()
League.recordAttempt(winner, 3, false, { strength = 100 })
League.recordAttempt(winner, 3, false, { strength = 100 })
ok(League.bar(winner) > 0, "failures raise the bar")
League.recordAttempt(winner, 5, true, { strength = 300 })
eq(Util.count(winner.walls), 0, "a clear resets the walls")
eq(League.bar(winner), 0, "and the bar with them")
eq(winner.clears, 1, "the clear is counted")
eq(winner.bestStage, 5, "and the best stage recorded")
eq(winner.qualified, true, "clearing the Elite Four QUALIFIES a rival")

-- 4. §30: a title shot is earned, and spent.
eq(League.mayChallengeTitle(League.newRecord()), false,
   "a rival that has never cleared the League may not challenge for the title")
ok(League.mayChallengeTitle(winner), "one that has cleared it may")
League.beginReign(winner, 1000)
eq(winner.qualified, false,
   "taking the title SPENDS the qualification -- it must be earned again")
eq(League.mayChallengeTitle(winner), false, "so no immediate re-challenge")
eq(winner.reigns, 1, "the reign is counted")
eq(League.reignLength(winner, 1500), 500, "and its length is readable")
eq(League.endReign(winner, 1600), 600, "ending it reports how long it lasted")
eq(winner.longestReign, 600, "and the longest is remembered")
eq(League.reignLength(winner, 2000), 0, "a rival with no reign has no reign length")
eq(League.endReign(winner, 2000), 0, "and ending a reign twice reports nothing")

-- 5. Bounds. A long game, or a hostile save, cannot grow the record.
local grinder = League.newRecord()
for i = 1, 5000 do
  League.recordAttempt(grinder, (i % 12) + 1, i % 97 == 0, { strength = i })
end
ok(Util.count(grinder.walls) <= League.MAX_STAGE,
   "the wall table is capped at the maximum stage count")
for stage, losses in pairs(grinder.walls) do
  ok(stage >= 1 and stage <= League.MAX_STAGE, "every wall key is a legal stage")
  ok(losses <= 999, "every wall count is capped")
end
ok(grinder.attempts <= 99999, "attempts are capped")
ok(grinder.bestStage <= League.MAX_STAGE, "the best stage cannot exceed the League")

local dirty = League.newRecord({ attempts = -5, clears = "many",
  bestStage = 99, lastStage = -3, qualified = "yes",
  walls = { [0] = 4, [99] = 4, ["x"] = 2, [2] = -7 }, reigns = -1 })
eq(dirty.attempts, 0, "a negative attempt count is repaired")
eq(dirty.clears, 0, "a corrupt clear count is repaired")
eq(dirty.bestStage, League.MAX_STAGE, "an impossible best stage is clamped")
eq(dirty.lastStage, 0, "a negative stage is clamped")
eq(dirty.qualified, false, "a non-boolean qualification is not believed")
eq(dirty.walls[0], nil, "stage 0 is not a stage")
eq(dirty.walls[99], nil, "and neither is stage 99")
eq(dirty.walls[2], 0, "a negative wall count is repaired")

local round = League.newRecord(League.serializeRecord(grinder))
eq(round.attempts, grinder.attempts, "the record survives a round trip")
eq(round.clears, grinder.clears, "as do clears")
eq(Util.count(round.walls), Util.count(grinder.walls), "and the walls")

-- 6. §27 standings sort deterministically, never by pairs() order.
local function row(id, badges, clears, best, caught, champion)
  return { id = id, name = id, badges = badges, clears = clears,
           best = best, caught = caught, champion = champion == true,
           qualified = false, attempts = 0 }
end
local rows = {
  row("d", 8, 0, 3, 40), row("a", 8, 1, 5, 10),
  row("c", 2, 0, 0, 90), row("b", 8, 0, 3, 40, true),
}
League.sortStandings(rows)
eq(rows[1].id, "b", "the champion leads the standings")
eq(rows[2].id, "a", "then the rival that has cleared the League")
eq(rows[4].id, "c", "and the least advanced is last")
local again = { row("d", 8, 0, 3, 40), row("a", 8, 1, 5, 10),
                row("c", 2, 0, 0, 90), row("b", 8, 0, 3, 40, true) }
League.sortStandings(again)
for i = 1, #rows do
  eq(again[i].id, rows[i].id, "the sort is deterministic at position " .. i)
end
eq(League.status(rows[1]), "CHAMPION", "the champion is labelled")
eq(League.status(row("x", 8, 0, 0, 0)), "LEAGUE", "an eight-badge rival is at the League")
eq(League.status(row("x", 1, 0, 0, 0)), "1 BADGE", "one badge is singular")
eq(League.status(row("x", 3, 0, 0, 0)), "3 BADGES", "and three are plural")

-- 7. Determinism and presentation.
eq(League.bar(stuck, 4), League.bar(stuck, 4), "the bar is pure")
ok(type(League.describe(grinder)) == "string", "a record describes itself")
eq(League.describe(nil), "no League record", "and a missing one says so")
eq(League.stageLabel(2, { "LORELEI", "BRUNO" }), "BRUNO", "stages can be named")
eq(League.stageLabel(9, { "LORELEI" }), "stage 9", "and fall back to a number")

print(("\n%d passed, %d failed"):format(pass, fail))
os.exit(fail == 0 and 0 or 1)
