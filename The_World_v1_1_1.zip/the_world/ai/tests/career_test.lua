-- Standalone: lua5.1 tests/career_test.lua   (from mods/ai_rivals)
--
-- The 2.2.0 careers: Breeder, Researcher, Explorer, Retired.
--
-- The property that matters most is the §35 one: a career is a different
-- PRIORITY ORDER over objectives that already exist, not a second AI. If that
-- ever stops being true, every bug the original loop fixed comes back once per
-- career.

local cache = {}
local function req(n)
  if cache[n] then return cache[n] end
  local f = assert(loadfile(n .. ".lua")); cache[n] = f(req, {}); return cache[n]
end
local Util, Career, LifePath = req("src/Util"), req("src/Career"), req("src/LifePath")
local Rival, AI = req("src/Rival"), req("src/AI")
local PERS, ROSTER = req("data/personalities"), req("data/rivals")

local pass, fail = 0, 0
local function eq(a, b, m) if a == b then pass = pass + 1 else fail = fail + 1
  print(("FAIL %s (got %s want %s)"):format(m, tostring(a), tostring(b))) end end
local function ok(c, m) if c then pass = pass + 1 else fail = fail + 1; print("FAIL " .. m) end end

-- 1. Every implemented career is a real life path, and vice versa is NOT
--    required -- the unbuilt ones must stay inert rather than half-working.
for _, path in ipairs(Career.IMPLEMENTED) do
  ok(LifePath.isPath(path), path .. " is a declared life path")
  ok(Career.isCareer(path), path .. " has a career definition")
  local def = Career.def(path)
  ok(#def.priorities > 0, path .. " has an objective order")
  ok(#def.metrics > 0, path .. " has progress metrics")
  eq(#def.milestones, 4, path .. " has four ranks (§27)")
  eq(#def.steps, 3, path .. " has three promotion thresholds")
  ok(not Career.pursuesBadges(path), path .. " stops prioritising badges")
end
for _, path in ipairs(LifePath.PATHS) do
  local built = false
  for _, id in ipairs(Career.IMPLEMENTED) do if id == path then built = true end end
  if not built then
    eq(Career.priorities(path), nil,
       path .. " is not built yet and leaves the personality's list alone")
    ok(Career.pursuesBadges(path),
       path .. " is not built yet and does not silently stop the Gym Challenge")
  end
end
eq(Career.priorities(LifePath.GYM_CHALLENGE), nil,
   "an ordinary rival keeps its personality's priorities")
ok(Career.pursuesBadges(LifePath.GYM_CHALLENGE), "and still chases badges")

-- 2. THE 1.14 LESSON, RE-APPLIED. An always-true objective placed early makes
--    every later one dead code. EXPLORE and TRAIN are the always-available
--    fallbacks, so they must be LAST in every career list.
for _, path in ipairs(Career.IMPLEMENTED) do
  local list = Career.def(path).priorities
  for i, objective in ipairs(list) do
    if objective == "EXPLORE" or objective == "TRAIN" then
      for j = i + 1, #list do
        ok(list[j] == "EXPLORE" or list[j] == "TRAIN",
           path .. ": nothing follows a fallback objective (" .. list[j] .. ")")
      end
    end
  end
  -- and every objective named must be one the AI actually implements
  for _, objective in ipairs(list) do
    ok(AI.Can[objective] ~= nil,
       path .. ": " .. objective .. " is an objective the AI can evaluate")
  end
end

-- 3. Progress is bounded and the metric set is fixed (§26).
local progress = Career.newProgress("BREEDER")
eq(Util.count(progress), #Career.def("BREEDER").metrics,
   "a new record has exactly the declared columns")
ok(Career.credit("BREEDER", progress, "caught", 3), "a declared metric credits")
eq(progress.caught, 3, "and records")
eq(Career.credit("BREEDER", progress, "areas", 1), false,
   "a metric from ANOTHER career is refused rather than added")
eq(progress.areas, nil, "and does not appear in the record")
eq(Career.credit("BREEDER", progress, "caught", -5), false, "a negative credit is refused")
eq(Career.credit("BREEDER", progress, "caught", 0), false, "a zero credit is refused")
eq(Career.credit(LifePath.GYM_CHALLENGE, progress, "caught", 1), false,
   "a rival with no career banks nothing")
for _ = 1, 200000 do Career.credit("BREEDER", progress, "caught", 999) end
ok(progress.caught <= Career.METRIC_MAX, "metrics are capped")
eq(Util.count(progress), #Career.def("BREEDER").metrics,
   "and the column set never grows")

-- corruption and round trip
local dirty = Career.newProgress("EXPLORER",
  { areas = -4, rareFinds = "many", encounters = 7, smuggled = 999 })
eq(dirty.areas, 0, "a negative stored metric is repaired")
eq(dirty.rareFinds, 0, "a corrupt stored metric is repaired")
eq(dirty.encounters, 7, "a good one survives")
eq(dirty.smuggled, nil, "a column this career does not declare is dropped")
local round = Career.newProgress("EXPLORER", Career.serializeProgress("EXPLORER", dirty))
eq(round.encounters, 7, "progress survives a round trip")
eq(Util.count(Career.newProgress("NOT_A_PATH")), 0, "an unknown path has no columns")

-- 4. Ranks (§27).
local climb = Career.newProgress("EXPLORER")
eq(Career.level("EXPLORER", climb), 1, "a new career starts at rank one")
eq(Career.rank("EXPLORER", climb), "Wanderer", "with the first title")
Career.credit("EXPLORER", climb, "areas", 12)
eq(Career.level("EXPLORER", climb), 2, "progress promotes")
Career.credit("EXPLORER", climb, "areas", 99999)
eq(Career.level("EXPLORER", climb), 4, "and cannot exceed the last rank")
eq(Career.rank("EXPLORER", climb), "Master Explorer", "which is the top title")
eq(Career.level(LifePath.GYM_CHALLENGE, climb), 0, "a non-career has no rank")
eq(Career.promotionHeadline("X", "EXPLORER", 1), nil,
   "§23: starting a career is not a promotion headline")
ok(Career.promotionHeadline("X", "EXPLORER", 3), "a real promotion is news")
eq(Career.promotionHeadline("X", LifePath.GYM_CHALLENGE, 3), nil,
   "an ordinary rival is never promoted")

-- 5. THROUGH A REAL RIVAL: the career changes what it does.
local DATA = {
  pokemon = { MON = { baseStats = { hp = 50, attack = 50, defense = 50,
    speed = 50, special = 50 }, types = { "NORMAL" },
    level1Moves = { "TACKLE" }, learnset = {} } },
  moves = { TACKLE = { power = 40, type = "NORMAL" } },
  constants = { fallbackMove = "TACKLE" }, type_chart = { matchups = {} },
}
local ctx = { data = DATA, personalities = PERS,
              graph = { has = function() return true end,
                        neighbours = function() return { { to = "ROUTE_2" } } end },
              gyms = { order = { "B1" }, byBadge = {} } }
local function make(i)
  local r = Rival.new(ROSTER[i or 1], ctx)
  r.ticks, r.map = 0, "ROUTE_1"
  return r
end

local plain = make(1)
ok(plain:pursuesBadges(), "an ordinary rival chases badges")
eq(table.concat(plain:objectivePriorities(), " "),
   table.concat(plain.personality.priorities, " "),
   "and works to its personality's objective order")

local breeder = make(1)
ok(LifePath.commit(breeder:ensureLifePath(), "BREEDER", 10, "test"),
   "a rival can take up breeding")
ok(not breeder:pursuesBadges(), "a breeder stops prioritising badges")
eq(table.concat(breeder:objectivePriorities(), " "),
   table.concat(Career.def("BREEDER").priorities, " "),
   "and works to the career's order instead")
ok(table.concat(breeder:objectivePriorities(), " ") ~=
   table.concat(plain:objectivePriorities(), " "),
   "which is genuinely different from the personality's")
-- §7: it does not stop battling entirely
local fights = false
for _, objective in ipairs(breeder:objectivePriorities()) do
  if objective == "TRAIN" then fights = true end
end
ok(fights, "§7: abandoning the Gym Challenge is not abandoning battles")

-- credits flow, and promote
eq(breeder:careerLevel(), 1, "a new breeder is a novice")
for _ = 1, 30 do breeder:creditCareer("caught", 1) end
ok(breeder:careerLevel() > 1, "catching promotes a breeder")
ok(breeder:careerRank() ~= nil, "and it has a rank to show")
local promoted = plain:creditCareer("caught", 1)
eq(promoted, false, "a rival with no career cannot be promoted")

-- 5b. The careers must be DISTINGUISHABLE, not four labels on one behaviour.
-- With an objective vocabulary this small, ordering alone barely separates a
-- breeder from an explorer -- so the levers that actually differ are checked.
do
  local shapes, biases, targets = {}, {}, {}
  for _, path in ipairs(Career.IMPLEMENTED) do
    shapes[table.concat(Career.def(path).priorities, " ")] = true
    biases[Career.catchBias(path)] = true
    targets[Career.partyTarget(path, 6)] = true
  end
  ok(Util.count(shapes) >= 3, "the four careers do not share one objective order")
  ok(Util.count(biases) >= 3, "nor one attitude to catching")
  ok(Util.count(targets) >= 3, "nor one team size")
  ok(Career.catchBias("BREEDER") > Career.catchBias("RETIRED") * 4,
     "a breeder catches far more readily than a retired trainer")
  eq(Career.catchBias(LifePath.GYM_CHALLENGE), 1,
     "an ordinary rival's catch rate is untouched")
  -- every life path is now a built career; nothing is left inert
  for _, path in ipairs(LifePath.PATHS) do
    ok(Career.isCareer(path), path .. " is built")
  end
end

-- 6. Persistence, including a career change rebuilding the columns.
local blob = breeder:serialize()
local back = Rival.new(ROSTER[1], ctx)
ok(back:restore(blob), "a rival with a career restores")
eq(back:lifePathId(), "BREEDER", "the path survives save/load")
eq(back:careerLevel(), breeder:careerLevel(), "as does the rank")
eq(back:ensureCareer().caught, breeder:ensureCareer().caught, "and the metrics")
-- a pre-2.2 save has no career key
blob.career = nil
local migrated = Rival.new(ROSTER[1], ctx)
ok(migrated:restore(blob), "a pre-2.2 save record still restores")
eq(migrated:careerLevel(), 1, "and starts its career at the bottom")
eq(migrated:ensureCareer().caught, 0, "with no invented progress")
-- an ordinary pre-2.1 rival is entirely unaffected
local ancient = Rival.new(ROSTER[2], ctx)
ok(ancient:restore({ id = ROSTER[2].id, map = "ROUTE_1", party = {} }),
   "a bare record restores")
ok(ancient:pursuesBadges(), "and is still on the Gym Challenge")
eq(Util.count(ancient:ensureCareer()), 0, "with no career columns at all")

-- ------------------------------------------------------------------
-- 7. LOCATED CAREERS (2.3.0)
-- ------------------------------------------------------------------
-- §24: "Do not simply teleport them to their new location permanently."
do
  for _, path in ipairs(Career.LOCATED) do
    ok(Career.isCareer(path), path .. " is a built career")
    ok(Career.isLocated(path), path .. " is located")
    local patterns = Career.homePatterns(path)
    ok(type(patterns) == "table" and #patterns > 0, path .. " names a home pattern")
    for _, pattern in ipairs(patterns) do
      eq(pattern, pattern:upper(), path .. ": patterns are upper case for matching")
    end
    local away = Career.fieldwork(path)
    ok(away > 0 and away < 1,
       path .. " spends SOME time away -- one that never leaves is scenery (§10)")
    -- a located career must actually list the objective that takes it there
    local lists = false
    for _, objective in ipairs(Career.def(path).priorities) do
      if objective == "CAREER_HOME" then lists = true end
    end
    ok(lists, path .. " lists CAREER_HOME, or it would never report for work")
  end
  for _, path in ipairs({ "BREEDER", "RESEARCHER", "EXPLORER", "RETIRED" }) do
    ok(not Career.isLocated(path), path .. " is not about a place")
    eq(Career.fieldwork(path), 0, "and has no fieldwork share")
  end
  eq(Career.homePatterns(LifePath.GYM_CHALLENGE), nil,
     "an ordinary rival has no workplace")

  -- findHome: substring matching that survives a conversion
  local KANTO = { "PALLET_TOWN", "OAKS_LAB", "VIRIDIAN_POKECENTER",
                  "PEWTER_GYM", "LAVENDER_POKEMONTOWER_1F", "CELADON_MART_2F",
                  "ROUTE_1" }
  eq(Career.findHome("OAK_ASSISTANT", KANTO), "OAKS_LAB", "the lab is found")
  eq(Career.findHome("TOWER_CARETAKER", KANTO), "LAVENDER_POKEMONTOWER_1F",
     "the tower is found")
  eq(Career.findHome("CENTER_ASSISTANT", KANTO), "VIRIDIAN_POKECENTER",
     "a Centre is found")
  eq(Career.findHome("GYM_ASSISTANT", KANTO), "PEWTER_GYM", "a Gym is found")
  eq(Career.findHome("MART_WORKER", KANTO), "CELADON_MART_2F", "a Mart is found")
  eq(Career.findHome("BREEDER", KANTO), nil, "an unlocated career has no home")
  -- a game with none of these buildings is a legitimate answer, not a crash
  eq(Career.findHome("OAK_ASSISTANT", { "ROUTE_1", "ROUTE_2" }), nil,
     "a game with no lab yields no home rather than erroring")
  eq(Career.findHome("OAK_ASSISTANT", {}), nil, "an empty map list is safe")
  eq(Career.findHome("OAK_ASSISTANT", nil), nil, "a missing map list is safe")
  -- the `allow` predicate is respected, so a gated building is not chosen
  eq(Career.findHome("GYM_ASSISTANT", KANTO, function() return false end), nil,
     "a building the rival may not enter is never chosen")
  -- deterministic: same inputs, same building, whatever order they arrive in
  local shuffled = { "ROUTE_1", "CELADON_MART_2F", "OAKS_LAB", "PEWTER_GYM" }
  eq(Career.findHome("OAK_ASSISTANT", shuffled), "OAKS_LAB",
     "the choice does not depend on map order")
  -- pattern precedence: the first pattern that matches anything wins
  eq(Career.findHome("CENTER_ASSISTANT", { "SOME_CENTRE", "A_POKECENTER" }),
     "A_POKECENTER", "an earlier, more specific pattern outranks a later one")
end

-- 8. A LOCATED RIVAL ROUTES TO WORK RATHER THAN APPEARING THERE.
do
  local MAPS = { ROUTE_1 = {}, PALLET_TOWN = {}, OAKS_LAB = {},
                 VIRIDIAN_POKECENTER = {} }
  local located = Rival.new(ROSTER[1], { data = { pokemon = DATA.pokemon,
    moves = DATA.moves, constants = DATA.constants,
    type_chart = DATA.type_chart, maps = MAPS },
    personalities = PERS,
    graph = { has = function(_, id) return MAPS[id] ~= nil end,
              neighbours = function() return { { to = "PALLET_TOWN" } } end,
              nearest = function(_, from, candidates) return candidates[1] end },
    gyms = { order = {}, byBadge = {} } })
  located.ticks, located.map = 0, "ROUTE_1"
  eq(located:careerHome(), nil, "a Gym Challenge rival has no workplace")
  ok(LifePath.commit(located:ensureLifePath(), "OAK_ASSISTANT", 5, "test"),
     "it can join Professor Oak")
  eq(located:careerHome(), "OAKS_LAB", "and now has a workplace")
  eq(located:atCareerHome(), false, "it is not there yet")
  ok(located.map ~= "OAKS_LAB",
     "§24: taking the job did NOT teleport it into the building")
  -- the objective that takes it there is selectable from here, and not once
  -- it has arrived
  located.rng = Util.rng(11)
  located.canEnterMap = function() return true end
  local canGo = AI.Can.CAREER_HOME(located, {})
  ok(canGo ~= nil, "the CAREER_HOME objective evaluates")
  eq(AI.Destination.CAREER_HOME(located), "OAKS_LAB", "and routes to the lab")
  located.map = "OAKS_LAB"
  eq(located:atCareerHome(), true, "once it walks there it is at its post")
  eq(AI.Can.CAREER_HOME(located, {}), false,
     "and does not re-select the objective while standing in the doorway")
  -- a game without the building leaves the rival working to the rest of its list
  local homeless = Rival.new(ROSTER[2], { data = { pokemon = DATA.pokemon,
    moves = DATA.moves, constants = DATA.constants,
    type_chart = DATA.type_chart, maps = { ROUTE_1 = {} } },
    personalities = PERS,
    graph = { has = function(_, id) return id == "ROUTE_1" end,
              neighbours = function() return {} end },
    gyms = { order = {}, byBadge = {} } })
  homeless.ticks, homeless.map = 0, "ROUTE_1"
  homeless.rng = Util.rng(3)
  LifePath.commit(homeless:ensureLifePath(), "TOWER_CARETAKER", 5, "test")
  eq(homeless:careerHome(), nil, "a game with no Tower yields no workplace")
  eq(AI.Can.CAREER_HOME(homeless, {}), false,
     "so the objective is never selected and the rest of the list runs")
end

print(("\n%d passed, %d failed"):format(pass, fail))
os.exit(fail == 0 and 0 or 1)
