-- Standalone: luajit tests/lifepath_reach_test.lua   (from mods/ai_rivals)
--
-- CAN EVERY LIFE PATH ACTUALLY HAPPEN TO SOMEBODY?
--
-- 4.7.0 grew the paths from sixteen to a hundred and five, and the failure
-- mode of doing that is not a crash. It is a data file full of rows that read
-- like content and can never be dealt to anybody, because some other row uses
-- the same facts with bigger numbers. A strictly dominated path is dead
-- content: it ships, it reads well, and no player ever sees it.
--
-- MEASURING THIS FOUND FOUR REAL THINGS:
--
--   1. Three LEGACY lives (MART_WORKER, RANGER, TYPE_SPECIALIST) stopped being
--      reachable when the newcomers arrived. Not because their weights moved
--      -- because the queue in front of them got six times longer while the
--      candidate window stayed at three. The window now scales with the
--      roster (LifePath.candidateWindow).
--   2. TYPE_SPECIALIST had been strictly dominated by GYM_ASSISTANT since 2.4
--      -- badges+fight, but always less of both. It could never once have been
--      offered, and nothing noticed for five releases.
--   3. Nine of the paths I wrote were the same idea ("a quiet job in a town")
--      competing on the same two facts. They now each say what they are about.
--   4. The first version of this measurement asked whether a path could be
--      ranked FIRST. The game picks from a window, not the top -- so that
--      number was measuring something nobody experiences (lesson 12). It asks
--      the real question now: can this path ever be OFFERED.

local cache = {}
local function req(n)
  if cache[n] then return cache[n] end
  local f = assert(loadfile(n .. ".lua")); cache[n] = f(req, {}); return cache[n]
end

local pass, fail = 0, 0
local function ok(c, m) if c then pass = pass + 1 else fail = fail + 1; print("FAIL " .. m) end end

local LifePath = req("src/LifePath")

-- Fixed seed: this is a soak, and a soak that reports a different number every
-- run cannot be compared against the last release.
math.randomseed(20260819)

local STYLES = { "EVOLUTION", "MONO_TYPE", "WEATHER", "DEFENSIVE", false }

local function randomRival()
  return {
    catchChance = math.random(), challengeChance = math.random(),
    wanderChance = math.random(), collection = math.random() * 60,
    seen = math.random() * 120, badges = math.random(0, 8),
    mapsKnown = math.random() * 64, leagueFailures = math.random(0, 6),
    money = math.random(0, 20000), ghostAffinity = math.random(),
    hostileToRival = math.random() < 0.25,
    -- The relationship facts are rarer than the rest by design: most rivals
    -- have not been betrayed by anybody.
    betrayal = math.random() < 0.20 and math.random() or 0,
    jealousy = math.random() < 0.20 and math.random() or 0,
    fear = math.random() < 0.20 and math.random() or 0,
    kinship = math.random() < 0.30 and math.random() or 0,
    mentorship = math.random() < 0.30 and math.random() or 0,
    devotion = math.random() < 0.10 and math.random() or 0,
    teamStyle = STYLES[math.random(1, #STYLES)] or nil,
  }
end

local N = 40000
local offered, distinct = {}, 0
local window = LifePath.candidateWindow()
for _ = 1, N do
  for _, entry in ipairs(LifePath.rankPaths(randomRival(), window)) do
    if not offered[entry.path] then
      offered[entry.path] = 0
      distinct = distinct + 1
    end
    offered[entry.path] = offered[entry.path] + 1
  end
end

local missing = {}
for _, path in ipairs(LifePath.PATHS) do
  if not offered[path] then missing[#missing + 1] = path end
end

print(("  %d of %d paths offered at least once over %d rivals (window %d)")
  :format(distinct, #LifePath.PATHS, N, window))

ok(#missing == 0,
  "every declared life path can be offered to somebody -- dead content: "
  .. table.concat(missing, ", "))

ok(#LifePath.PATHS >= 100,
  "the roster is the hundred the brief asked for (" .. #LifePath.PATHS .. ")")

-- The window has to grow with the roster or this whole failure comes back the
-- next time somebody adds twenty paths.
ok(window > 3, "the candidate window scales past the old constant three")
ok(window <= math.ceil(#LifePath.PATHS * 0.15),
  "but stays a shortlist rather than 'pick anything' (" .. window .. ")")

-- No single path may swallow the world. A path offered to nearly everybody is
-- not a life, it is the default -- which is what the Gym Challenge is for.
local worst, worstPath = 0, nil
for path, n in pairs(offered) do
  if n > worst then worst, worstPath = n, path end
end
ok(worst <= N * 0.75,
  ("no path is offered to nearly everyone (%s at %d%%)")
    :format(tostring(worstPath), math.floor(worst / N * 100)))

-- The relationship-gated lives must be UNREACHABLE without their fact, or the
-- gate is decoration. Checked directly rather than trusted from the sweep.
local plain = { catchChance = 0.5, challengeChance = 0.5, wanderChance = 0.5,
                collection = 30, seen = 60, badges = 4, mapsKnown = 32,
                leagueFailures = 3, money = 5000, ghostAffinity = 0.5 }
local gated = LifePath.gatedPaths(plain)
for _, pair in ipairs({ { "AVENGER", "betrayal" }, { "SWORN_RIVAL", "jealousy" },
                        { "RECLUSE", "fear" }, { "PROTECTOR", "kinship" },
                        { "FAMILY_TRAINER", "kinship" },
                        { "DEVOTED_PARTNER", "devotion" } }) do
  ok(gated[pair[1]] == pair[2],
    pair[1] .. " is barred from a rival with no " .. pair[2]
      .. " (got " .. tostring(gated[pair[1]]) .. ")")
end

-- ...and reachable WITH it, or the gate is a wall.
local wronged = {}
for k, v in pairs(plain) do wronged[k] = v end
wronged.betrayal = 1
local found = false
for _, entry in ipairs(LifePath.rankPaths(wronged, #LifePath.PATHS)) do
  if entry.path == "AVENGER" and entry.score > LifePath.FLOOR / 100 then found = true end
end
ok(found, "a betrayed rival can reach the life that betrayal leads to")

print(("lifepath reachability: %d passed, %d failed"):format(pass, fail))
os.exit(fail == 0 and 0 or 1)
