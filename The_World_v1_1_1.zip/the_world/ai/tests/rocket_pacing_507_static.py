from pathlib import Path
root = Path(__file__).resolve().parents[1]
rocket = (root/"src"/"Rocket.lua").read_text(encoding="utf-8")

assert "function Rocket:playerStoryReady(world)" in rocket
assert 'map == "PALLET_TOWN"' in rocket
assert "return (tonumber(self.tick) or 0) >= 180" in rocket
assert "function Rocket:travelReady(member)" in rocket
assert "if not self:travelReady(member) then return false end" in rocket
assert "self.nextOp=self.tick+self.rng:int(45,90)" in rocket
assert "if not self:playerStoryReady(world) then return 0 end" in rocket
assert "member.map = member.destination" not in rocket

print("Rocket opening protection + slow travel static checks: OK")
