#!/usr/bin/env python3
"""Static contracts for the 2.5 absorption of v1.30.0.

Two files existed in 1.30 and in no release since: src/Phone.lua and
src/LifePaths.lua. One was absorbed; one was rejected as superseded. This file
records WHY, in a form that fails if either decision is quietly undone.
"""
import re
import sys
from pathlib import Path

root = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(Path(__file__).resolve().parent))
from _version import at_least

phone = (root / "src" / "Phone.lua").read_text(encoding="utf-8")
main = (root / "main.lua").read_text(encoding="utf-8")
source_files = list((root / "src").rglob("*.lua"))
all_source = main + "\n" + "\n".join(p.read_text(encoding="utf-8") for p in source_files)
rival = (root / "src" / "Rival.lua").read_text(encoding="utf-8")
rivals_data = (root / "data" / "rivals.lua").read_text(encoding="utf-8")
errors = []


def need(token, blob, label):
    if token not in blob:
        errors.append(label)


# --- Phone was ABSORBED and must stay wired ---------------------------------
need("function Phone.new", phone, "the absorbed phone lost its constructor")
need("self.phone = Phone.new(self)", main, "the phone is never constructed")
need("M.phone:update(dt, M.rivals, world)", main, "the phone is never ticked")
need("self.phone:registerContacts()", all_source,
     "contacts are not re-registered after a load, so a Gold save's Pokegear "
     "would be empty until a rival was met again")
need("phoneNumber = self.phoneNumber,", rival, "the phone number is not saved")
need("self.phoneNumber = saved.phoneNumber", rival,
     "the phone number is REGENERATED on load, which would hand the player a "
     "new number for a contact they already have")

# Lua 5.2 goto is a LuaJIT extension. Plain 5.1 rejects it, which is what kept
# this module out of the headless harness for its whole life.
# Comment lines stripped first -- Phone.lua explains why the goto skips were
# rewritten, and matching that prose would fail on the documentation. FIFTH
# occurrence of this trap (1.37, 2.0, 2.3, 2.4, here): strip comments BEFORE
# scanning source, always.
phone_code = "\n".join(l for l in phone.splitlines()
                       if not l.lstrip().startswith("--"))
if re.search(r"\bgoto\s+\w+", phone_code) or "::" in phone_code:
    errors.append("the phone uses Lua 5.2 goto/labels again -- plain 5.1 "
                  "cannot parse it and no test can cover it")

# the shim must return the TABLE shape 1.30's call sites index
bias = phone[phone.index("function LifePaths.phoneBias"):]
bias = bias[:bias.index("\nend")]
for field in ("offerBias", "weatherReportBias", "dark"):
    if field not in bias:
        errors.append(f"the phone bias shim dropped {field}; call sites index it")

# --- LifePaths (1.30) was REJECTED as superseded -----------------------------
if (root / "src" / "LifePaths.lua").exists():
    errors.append("src/LifePaths.lua (1.30, plural) was re-added. It is "
                  "superseded by src/LifePath.lua + src/Career.lua: it "
                  "re-scored a rival's role EVERY evaluate with a stickiness "
                  "term, which the v2.x brief forbids outright (§2 'do not "
                  "implement RNG roll -> rival becomes breeder', §32 stable "
                  "seed, §33 decision_locked). Two systems both claiming to "
                  "own a rival's role is worse than either alone.")
for blob, name in ((main, "main.lua"), (phone, "Phone.lua"),
                   ((root / "src" / "AI.lua").read_text(encoding="utf-8"), "AI.lua")):
    if 'req("src/LifePaths")' in blob:
        errors.append(f"{name} requires the superseded 1.30 LifePaths module")

# --- the four-version spawn claim -------------------------------------------
# 2.6: starters are DEALT from a shared pool, not fixed per rival. The pools
# are the contract; the per-rival chains are gone.
rival_src = (root / "src" / "Rival.lua").read_text(encoding="utf-8")
need("ROSTER.pools", rivals_data, "the shared starter pools are missing")
need("function Rival.starterPool", rival_src, "no pool resolution")
GEN1 = ["BULBASAUR", "CHARMANDER", "SQUIRTLE", "PIKACHU", "EEVEE", "CLEFAIRY"]
JOHTO = ["CHIKORITA", "CYNDAQUIL", "TOTODILE"]
pools = {}
# Scope the search to the ROSTER.pools block. The bare key names now also
# appear in each rival's version-keyed `homeMaps`, so an unanchored search
# finds a home-map arm and reports the pools as missing species they never
# held.
pools_block = rivals_data[rivals_data.index("ROSTER.pools = {"):]
pools_block = pools_block[:pools_block.index("\n}")]
for key in ("default", "yellow", "gen2"):
    m = re.search(rf"{key}\s*=\s*\{{(.*?)\}}", pools_block, re.S)
    if not m:
        errors.append(f"no starter pool for '{key}'")
        continue
    pools[key] = re.findall(r'"([A-Z_]+)"', m.group(1))
for key in ("default", "yellow"):
    for sp in GEN1:
        if sp not in pools.get(key, []):
            errors.append(f"the {key} starter pool is missing {sp}")
    for sp in JOHTO:
        if sp in pools.get(key, []):
            errors.append(f"the {key} starter pool contains {sp}, which is Gen 2")
for sp in GEN1 + JOHTO:
    if sp not in pools.get("gen2", []):
        errors.append(f"Gold's starter pool is missing {sp}")
# the deal must be seeded and deterministic, never a live roll
chain = rival_src[rival_src.index("function Rival.starterChain(def, versionKey, opts)"):]
chain = chain[:chain.index("\nend")]
if "math.random" in chain or "os.time" in chain or "os.clock" in chain:
    errors.append("the starter deal uses live randomness -- it would reroll on "
                  "every load, and a rival's ace, identity and story are all "
                  "downstream of the Pokemon it started with")
need("table.sort(ranked", chain,
     "the deal is not a real permutation -- a plain rotation yields only as "
     "many hands as there are species")
need("return a.species < b.species", chain,
     "the permutation has no deterministic tie-break")
# the world seed must be persisted, and must have real entropy
seed_fn = all_source[all_source.index("function M:worldSeed"):]
seed_fn = seed_fn[:seed_fn.index("\nend")]
need("if self.seedValue then return self.seedValue end", seed_fn,
     "the world seed is recomputed rather than reused")
if not any(tok in seed_fn for tok in ("os.time", "math.random")):
    errors.append("the world seed has no entropy source, so every save would "
                  "deal the identical hand and pick the identical destiny")
need("out.seedValue = self.seedValue", all_source, "the world seed is not saved")
need("if not self.seedValue and self.pathSeed then", all_source,
     "a pre-2.6 save is not given its existing seed, so upgrading would "
     "reassign destinies a player has already been living with")

# --- 3.4: Gold's sprite table is gen2Sprites ---------------------------------
need("function M:spriteTable", all_source, "no shared sprite-table accessor")
need("data.sprites or data.gen2Sprites", all_source,
     "the sprite resolvers read only data.sprites; Gold keeps its overworld "
     "sprites in data.gen2Sprites, so on Gold they find nothing, the spawn "
     "fails closed and the rival never appears")
for fn in ("function M:safeSprite", "function M:spriteForRival"):
    body = all_source[all_source.index(fn):]
    body = body[:body.index("\nend")]
    if "self.data and self.data.sprites)" in body:
        errors.append(f"{fn} still resolves its own Gen 1-only sprite table "
                      f"instead of calling M:spriteTable")
# the menu must not claim a presence the player cannot find
need("M:playerMapId()", all_source, "no player-map accessor for the menu check")
need("not (M.spawned and M.spawned[rival.id])", all_source,
     "the rivals menu reports rival.map alone, so a rival that failed to spawn "
     "is still announced as standing next to the player")

# the sprite fallback must be deterministic and must never name an absent id
safe = all_source[all_source.index("function M:safeSprite"):]
safe = safe[:safe.index("\nend")]
need("table.sort(ids)", safe,
     "the last-resort sprite is chosen by pairs() order, so the same save "
     "could give a rival different sprites on two loads")
if 'return preferred or "SPRITE_BLUE"' in safe:
    errors.append("safeSprite can still name SPRITE_BLUE, which Gold does not "
                  "have -- a spawn with an unknown sprite fails rather than "
                  "degrading")
need("no usable sprite", all_source,
     "the spawn site does not handle a nil sprite, so it would pass nil through")

# --- 2.7: the gauntlet room is resolved, never assumed ----------------------
need('"ELMS_LAB"', main, "Gold's lab is not a gauntlet candidate")
need('"NEW_BARK_TOWN"', main, "Gold's starting town is not a gauntlet candidate")
resolver = all_source[all_source.index("local function resolveGauntletLab"):]
resolver = resolver[:resolver.index("\nend")]
if 'return "OAKS_LAB"' in resolver:
    errors.append("the gauntlet resolver still falls back to OAKS_LAB -- on "
                  "Gold that names a room the game does not have, which is "
                  "what put four rivals 'waiting in Oak's Lab' on Gold")
need("return nil", resolver, "the resolver has no honest 'no lab here' answer")
begin = all_source[all_source.index("function M:beginGauntlet"):]
begin = begin[:begin.index("\nend\n")]
need("if not lab then return false end", begin,
     "a gauntlet can still be armed with no lab to hold it in")
# the intro prompt must name the resolved room, not a hardcoded one
if 'text = "Battle the AI rivals\\nin Oak\'s Lab?"' in main:
    errors.append("the character-creation prompt still hardcodes Oak's Lab")
need('M:labLabel(labId)', main, "the intro prompt does not name the resolved room")
need("local labId = M:gauntletLab()", main,
     "the intro prompt is inserted without checking a lab exists")
# only the two KANTO-GEOMETRY branches may still name OAKS_LAB
main_code = "\n".join(l for l in main.splitlines()
                      if not l.lstrip().startswith("--"))
literals = main_code.count('"OAKS_LAB"')
if literals > 4:
    errors.append(f"{literals} hardcoded OAKS_LAB literals remain in code "
                  f"(expected at most 4: the candidate list, the 5x6 interior "
                  f"geometry branches and its synthetic grid)")

# --- preserved ---------------------------------------------------------------
for token in ("KantoCompat", "WonderTrade.install(mod, M)", "rivalGiftAllowed",
              "Relationships.headline", "TeamPlan = TeamPlan", "Story = Story",
              "Presence = Presence", "Weather = Weather", "Economy = Economy",
              "League = League", "LifePath = LifePath", "Career = Career"):
    need(token, main, f"earlier contract lost: {token}")
need("local SAVE_VERSION = 10", main, "save version regressed")
errors.extend(x for x in [at_least(root, "3.4.0")] if x)

if errors:
    for error in errors:
        print("FAIL", error)
    raise SystemExit(1)
print("AI Rivals v2.7: starters dealt from a seeded pool and the intro "
      "gauntlet resolved per game across Red/Blue/Yellow/Gold PASS")
