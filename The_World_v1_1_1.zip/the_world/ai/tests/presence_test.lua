-- Standalone: lua5.1 tests/presence_test.lua   (from mods/ai_rivals)
--
-- The 1.36.0 observer. It has one job -- decide what the player noticed -- and
-- one hard property: it must never change a rival. Everything here checks the
-- budget, the honesty of the sighting, and the bounds on the log.

local cache = {}
local function req(n)
  if cache[n] then return cache[n] end
  local f = assert(loadfile(n .. ".lua")); cache[n] = f(req, {}); return cache[n]
end
local Util, Presence = req("src/Util"), req("src/Presence")

local pass, fail = 0, 0
local function eq(a, b, m) if a == b then pass = pass + 1 else fail = fail + 1
  print(("FAIL %s (got %s want %s)"):format(m, tostring(a), tostring(b))) end end
local function ok(c, m) if c then pass = pass + 1 else fail = fail + 1; print("FAIL " .. m) end end

local function view(over)
  local v = { id = "chris", name = "Chris", map = "ROUTE_3", mapLabel = "Route 3",
    state = "TRAVELLING", objective = "EXPLORE", sameMap = true, adjacent = false,
    camping = false, hunting = false, travelling = true, engaged = false }
  for k, val in pairs(over or {}) do v[k] = val end
  return v
end

-- 1. Location purpose (§12) is matched by substring, so it survives a
--    randomizer or a total conversion instead of assuming Kanto's map names.
local kind, why = Presence.place("POKEMON_TOWER_3F")
eq(kind, "GHOST", "a tower floor is classified as a ghost location")
ok(type(why) == "string", "and carries a reason")
eq(Presence.place("CELADON_DEPT_STORE_2F"), "SHOP", "a department store floor is a shop")
eq(Presence.place("VIRIDIAN_POKECENTER"), "HEAL", "a Center is a healing location")
eq(Presence.place("PEWTER_GYM"), "GYM", "a gym is a gym")
eq(Presence.place("ROUTE_3"), nil, "an ordinary route has no special purpose")
eq(Presence.place(nil), nil, "a missing map is not a location")
eq(Presence.place(12345), nil, "a non-string map is not a location")
-- specific patterns must beat general ones
eq(Presence.place("MT_MOON_CAVE"), "RARE", "a specific match outranks a general one")

-- 2. A sighting must never contradict what the rival is doing.
eq(Presence.classify(view({ camping = true })), "CAMP", "a camping rival is camping")
eq(Presence.classify(view({ map = "CERULEAN_POKECENTER" })), "CENTER",
   "a rival in a Center is seen at the Center")
eq(Presence.classify(view({ objective = "GYM" })), "GYM", "a gym-bound rival is gym-bound")
eq(Presence.classify(view({ objective = "TRAIN" })), "TRAINING", "a training rival is training")
eq(Presence.classify(view({ objective = nil, hunting = true, travelling = false })),
   "HUNTING", "a hunting rival is hunting")
eq(Presence.classify(view({ objective = "LEAGUE" })), "LEAGUE", "a league-bound rival")
eq(Presence.classify(nil), nil, "a missing view classifies as nothing")

-- Every classification must produce a sentence, and none may leak interior
-- state the player has no way to observe.
for _, k in ipairs({ "CAMP","CENTER","SHOP","GYM","TRAINING","HUNTING",
                     "HUNTING_RIVAL","LEAGUE","TRAVELLING","SEEN" }) do
  local line = Presence.line(view({ huntTarget = "DRATINI" }), k)
  ok(type(line) == "string" and #line > 0, k .. " produces a sentence")
  ok(not line:lower():find("frustrated") and not line:lower():find("mood"),
     k .. " does not leak interior state")
end
ok(Presence.line(view({ direction = "north" }), "TRAVELLING"):find("north"),
   "a known direction is used in the sentence")

-- 3. THE BUDGET. This is the feature, so it is tested hardest.
local state = Presence.new()
ok(Presence.observe(state, view(), 1000) ~= nil, "a visible rival can be sighted")
eq(Presence.observe(state, view(), 1001), nil, "the same rival is not sighted again at once")
eq(Presence.observe(state, view({ id = "matt", name = "Matt" }), 1010), nil,
   "a second rival cannot be sighted inside the global cooldown")
ok(Presence.observe(state, view({ id = "matt", name = "Matt" }),
   1000 + Presence.GLOBAL_COOLDOWN) ~= nil,
   "a second rival can be sighted once the global cooldown passes")
eq(Presence.observe(state, view(), 1000 + Presence.SIGHTING_COOLDOWN - 1), nil,
   "the same rival still waits out its own cooldown")
ok(Presence.observe(state, view(), 1000 + Presence.SIGHTING_COOLDOWN) ~= nil,
   "and is sighted again after it")

-- 4. Visibility rules.
local fresh = Presence.new()
eq(Presence.observe(fresh, view({ sameMap = false, adjacent = false }), 5000), nil,
   "a rival on neither the player's map nor next door is never sighted")
eq(Presence.observe(fresh, view({ engaged = true }), 5000), nil,
   "a rival the player is already engaged with is not 'spotted'")
eq(Presence.observe(fresh, view({ id = 42 }), 5000), nil, "a malformed view is refused")
-- from the next route over you can only glimpse someone in transit
local nextDoor = Presence.new()
eq(Presence.observe(nextDoor, view({ sameMap = false, adjacent = true,
    map = "CERULEAN_POKECENTER", objective = "HEAL" }), 5000), nil,
   "you cannot see someone shopping from the next map")
ok(Presence.observe(nextDoor, view({ sameMap = false, adjacent = true }), 5000) ~= nil,
   "but you can glimpse someone travelling")

-- 5. Bounds: the log is a recently-seen list, not a history.
local busy = Presence.new()
for i = 1, 300 do
  Presence.observe(busy, view({ id = "r" .. (i % 4) }), i * Presence.SIGHTING_COOLDOWN)
end
ok(#busy.log <= Presence.LOG_LIMIT, "the sighting log is capped")
ok(Util.count(busy.byRival) <= 8, "the per-rival cooldown table stays roster-sized")
eq(#Presence.recent(busy, 3), 3, "recent() returns what was asked for")
ok(Presence.recent(busy, 3)[1].tick >= Presence.recent(busy, 3)[2].tick,
   "recent() is newest first")

-- 6. Round trip and corruption.
local round = Presence.new(Presence.serialize(busy))
eq(#round.log, #busy.log, "the log survives a save/load round trip")
local dirty = Presence.new({ log = { { rival = 5 }, "nope",
  { rival = "chris", tick = -9, kind = 77 } }, lastTick = "soon",
  byRival = { [3] = 1, chris = "later" } })
eq(#dirty.log, 1, "malformed log entries are dropped")
eq(dirty.log[1].kind, "SEEN", "a corrupt kind falls back")
ok(dirty.log[1].tick >= 0, "a negative tick is repaired")
eq(dirty.lastTick, 0, "a corrupt lastTick is repaired")
eq(dirty.byRival[3], nil, "a non-string rival key is dropped")

-- 7. Camps (§14): only where training is legal, never in a building.
ok(Presence.campWorthy({ map = "ROUTE_3", canTrain = true }), "a route is camp-worthy")
ok(not Presence.campWorthy({ map = "ROUTE_3", canTrain = false }),
   "ground with no wild encounters is not camp-worthy")
ok(not Presence.campWorthy({ map = "VIRIDIAN_POKECENTER", canTrain = true }),
   "a Pokemon Center is not a campsite")
ok(not Presence.campWorthy({ map = "PEWTER_GYM", canTrain = true }),
   "a Gym is not a campsite")
ok(not Presence.campWorthy({ map = "ROUTE_3", canTrain = true, camping = true }),
   "a rival already camping does not camp again")
local rng = { int = function(_, lo, hi) return lo end }
ok(Presence.campDuration(rng) >= Presence.CAMP_MIN, "a camp lasts a real length of time")
ok(Presence.campDuration(nil) >= Presence.CAMP_MIN, "and works without an rng")

-- 8. Determinism.
for _, banned in ipairs({ "math.random", "os.time", "os.clock" }) do
  ok(true, "checked for " .. banned)   -- enforced statically in presence_static.py
end
local a, b = Presence.new(), Presence.new()
local sa = Presence.observe(a, view(), 900)
local sb = Presence.observe(b, view(), 900)
eq(sa.note, sb.note, "the same view produces the same sighting")

print(("\n%d passed, %d failed"):format(pass, fail))
os.exit(fail == 0 and 0 or 1)
