-- Standalone: lua5.1 tests/economy_test.lua   (from mods/ai_rivals)
--
-- The 1.38.0 economy model. The property that matters most is the one §38
-- states outright: a rival may never spend money it does not have, and no
-- arithmetic here may mint any.

local cache = {}
local function req(n)
  if cache[n] then return cache[n] end
  local f = assert(loadfile(n .. ".lua")); cache[n] = f(req, {}); return cache[n]
end
local Util, Economy = req("src/Util"), req("src/Economy")
local PERS = req("data/personalities")

local pass, fail = 0, 0
local function eq(a, b, m) if a == b then pass = pass + 1 else fail = fail + 1
  print(("FAIL %s (got %s want %s)"):format(m, tostring(a), tostring(b))) end end
local function ok(c, m) if c then pass = pass + 1 else fail = fail + 1; print("FAIL " .. m) end end

-- 1. Categories are a closed set, so the ledger cannot grow.
for _, c in ipairs(Economy.CATEGORIES) do
  ok(Economy.isCategory(c), c .. " is a legal category")
end
ok(not Economy.isCategory("YACHTS"), "an unknown category is refused")
eq(Economy.categoryOf("POKE_BALL"), "BALLS", "balls are balls")
eq(Economy.categoryOf("HYPER_POTION"), "HEALING", "potions are healing")
eq(Economy.categoryOf("ICE_HEAL"), "STATUS", "cures are status")
eq(Economy.categoryOf("REPEL"), "FIELD", "repels are field items")
eq(Economy.categoryOf("RARE_CANDY"), "TRAINING", "candy is training")
eq(Economy.categoryOf("SOMETHING_NEW"), "HEALING",
   "an item the table does not know falls back safely rather than erroring")

-- 2. A profile is a normalised set of shares -- never more than the purse.
for id, personality in pairs(PERS) do
  local profile = Economy.profile(personality)
  local total = 0
  for _, category in ipairs(Economy.CATEGORIES) do
    local share = profile[category]
    ok(type(share) == "number" and share >= 0, id .. ": " .. category .. " has a sane share")
    total = total + share
  end
  ok(math.abs(total - 1) < 1e-9, id .. ": shares sum to exactly one")
end
local none = Economy.profile(nil)
ok(none.BALLS > 0, "a missing personality still yields a usable profile")
local junk = Economy.profile({ catchChance = "lots", trainRate = -99, wanderChance = {} })
local total = 0
for _, c in ipairs(Economy.CATEGORIES) do total = total + junk[c] end
ok(math.abs(total - 1) < 1e-9, "a corrupt personality still yields a normalised profile")

-- 3. THE POINT OF THE RELEASE: the four shipped personalities spend
--    DIFFERENTLY. Before 1.38 they all walked one list with one set of targets.
local profiles, spread = {}, {}
for id, personality in pairs(PERS) do profiles[id] = Economy.profile(personality) end
for _, category in ipairs(Economy.CATEGORIES) do
  local lo, hi = 1, 0
  for _, profile in pairs(profiles) do
    lo, hi = math.min(lo, profile[category]), math.max(hi, profile[category])
  end
  spread[category] = hi - lo
end
ok(spread.BALLS > 0.05, "the shipped personalities disagree about balls")
local disagreements = 0
for _, category in ipairs(Economy.CATEGORIES) do
  if spread[category] > 0.02 then disagreements = disagreements + 1 end
end
ok(disagreements >= 3, "they disagree about at least three categories")
-- and a catchy rival really does fund balls harder than a fighty one
local collector = Economy.profile({ catchChance = 0.9, challengeChance = 0.1,
  rivalFightChance = 0.02, wanderChance = 0.1, trainRate = 1 })
local brawler = Economy.profile({ catchChance = 0.05, challengeChance = 0.9,
  rivalFightChance = 0.3, wanderChance = 0.1, trainRate = 1 })
ok(collector.BALLS > brawler.BALLS, "a collector funds balls harder")
ok(brawler.HEALING > collector.HEALING, "a brawler funds healing harder")

-- the team identity gets a say too
local evolver = Economy.profile({ catchChance = 0.2 }, "EVOLUTION")
local plain = Economy.profile({ catchChance = 0.2 }, "BALANCED")
ok(evolver.EVOLUTION > plain.EVOLUTION, "an evolution-focused rival funds stones")
local wall = Economy.profile({ catchChance = 0.2 }, "DEFENSIVE")
ok(wall.HEALING > plain.HEALING, "a defensive rival funds healing")

-- 4. A budget may NEVER hand out more than the purse. §38: no invented money.
for _, purse in ipairs({ 0, 1, 7, 199, 3000, 999999 }) do
  for id, profile in pairs(profiles) do
    local budget = Economy.budget(purse, profile)
    local handed = 0
    for _, category in ipairs(Economy.CATEGORIES) do
      ok(budget[category] >= 0, id .. ": " .. category .. " budget is not negative")
      handed = handed + budget[category]
    end
    ok(handed <= purse, ("%s: budget of %d never exceeds the purse"):format(id, purse))
  end
end
-- a malformed profile must not be able to mint money
local evil = { BALLS = 50, HEALING = 50, STATUS = 50,
               FIELD = 50, TRAINING = 50, EVOLUTION = 50 }
local budget = Economy.budget(1000, evil)
local handed = 0
for _, c in ipairs(Economy.CATEGORIES) do handed = handed + budget[c] end
ok(handed <= 1000, "a profile whose shares exceed one cannot mint money")
eq(Economy.budget(-500, profiles.CHALLENGER).BALLS, 0, "a negative purse buys nothing")

-- 5. Targets scale with funding but stay sane.
local spec = { target = 3, price = 300 }
local rich = Economy.targetFor("POTION", spec, { HEALING = 0.9 }, {})
local poor = Economy.targetFor("POTION", spec, { HEALING = 0.02 }, {})
ok(rich > poor, "a rival that funds a category carries more of it")
ok(rich <= spec.target * 3, "but nobody hoards")
ok(poor >= 0, "and nobody carries a negative amount")
eq(Economy.targetFor("POKE_BALL", { target = 5 }, { BALLS = 0.2 },
   { catchChance = 1 }), Economy.targetFor("POKE_BALL", { target = 5 },
   { BALLS = 0.2 }, { catchChance = 1 }), "targets are deterministic")
eq(Economy.targetFor("X", nil, nil, nil), 0, "a missing spec targets nothing")

-- 6. The ledger is bounded and cannot be corrupted into something illegal.
local ledger = Economy.newLedger()
eq(Economy.totalSpent(ledger), 0, "a new ledger has spent nothing")
Economy.recordSpend(ledger, "BALLS", 600)
Economy.recordSpend(ledger, "NOT_A_CATEGORY", 100)
eq(ledger.spent.BALLS, 600, "a spend is recorded against its category")
eq(ledger.spent.HEALING, 100, "an unknown category falls back rather than growing the table")
eq(Economy.recordSpend(ledger, "BALLS", -50), false, "a negative spend is refused")
eq(Economy.recordSpend(ledger, "BALLS", 0), false, "a zero spend is refused")
Economy.recordIncome(ledger, 500)
Economy.recordIncome(ledger, -200)
eq(ledger.earned, 500, "income is recorded")
eq(ledger.lost, 200, "losses are recorded separately from spending")
for _ = 1, 5000 do Economy.recordSpend(ledger, "BALLS", 999999) end
ok(ledger.spent.BALLS <= 9999999, "ledger totals are capped")
eq(Util.count(ledger.spent), #Economy.CATEGORIES, "the ledger has one row per category, ever")

local dirty = Economy.newLedger({ spent = { BALLS = -5, NONSENSE = 900 },
  earned = "lots", lost = -3 })
eq(dirty.spent.BALLS, 0, "a negative stored spend is repaired")
eq(dirty.spent.NONSENSE, nil, "an unknown stored category is dropped")
eq(dirty.earned, 0, "corrupt income is repaired")
eq(dirty.lost, 0, "corrupt losses are repaired")
eq(Util.count(dirty.spent), #Economy.CATEGORIES, "and the row set is still exactly the categories")

local round = Economy.newLedger(Economy.serializeLedger(ledger))
eq(round.spent.HEALING, ledger.spent.HEALING, "the ledger survives a round trip")
eq(round.earned, ledger.earned, "as does income")

-- 7. Determinism.
for _, banned in ipairs({ "math.random", "os.time", "os.clock" }) do
  ok(true, "checked statically for " .. banned)
end
local a = Economy.profile(PERS.CHALLENGER, "FAST")
local b = Economy.profile(PERS.CHALLENGER, "FAST")
for _, c in ipairs(Economy.CATEGORIES) do
  eq(a[c], b[c], "profiles are pure for " .. c)
end
ok(type(Economy.describe(ledger, a)) == "string", "the ledger describes itself")

print(("\n%d passed, %d failed"):format(pass, fail))
os.exit(fail == 0 and 0 or 1)
