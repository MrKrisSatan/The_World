#!/usr/bin/env python3
from pathlib import Path
import json
ROOT=Path(__file__).resolve().parents[1]
eco=(ROOT/'src/Ecology.lua').read_text()
world=(ROOT/'src/WorldState.lua').read_text()
rocket=(ROOT/'src/Rocket.lua').read_text()
main=(ROOT/'main.lua').read_text()
manifest=json.loads((ROOT/'manifest.json').read_text())
checks={
 '5.7 manifest': manifest.get('version')=='5.7.0',
 'migrant species join abundance': 'for species, byMap in pairs(self.migrations)' in eco and 'speciesSet[species] = true' in eco,
 'habitat suitability': 'function Ecology:habitatSuitability' in eco,
 'seeded migration destination': 'function Ecology:chooseMigrationDestination' in eco and 'chooseMigrationDestination' in rocket,
 'ranger recovery door': 'function Ecology:recover' in eco and 'ecology:recover(ranger.map' in world,
 'world route ecology': 'function WorldState:routeEcology' in world and 'world = self.worldState:routeEcology(mapId)' in main,
 'native/migrant report': 'native = cap[species] ~= nil' in eco and 'migrantPressure' in eco,
}
failed=[k for k,v in checks.items() if not v]
for k,v in checks.items(): print(('PASS ' if v else 'FAIL ')+k)
raise SystemExit(1 if failed else 0)
