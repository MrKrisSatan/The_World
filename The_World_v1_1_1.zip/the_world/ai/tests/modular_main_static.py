from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
main = (ROOT / "main.lua").read_text(encoding="utf-8")

contracts = {
    "BattleFlow": (
        "src/BattleFlow.lua",
        "return BattleFlow.release(self, rivalId)",
    ),
    "RuntimePolicy": (
        "src/RuntimePolicy.lua",
        "RuntimePolicy.trackPlayerMotion(M, world, dt)",
    ),
    "RosterPolicy": (
        "src/RosterPolicy.lua",
        # 5.0.9: the size is the ORDINARY roster count, not #ROSTER, which the
        # rare-special roll inflates. The contract this suite is checking is
        # DELEGATION, so it anchors on the call rather than its argument.
        "RosterPolicy.creationChoices(",
    ),
}
for name, (path, delegation) in contracts.items():
    source = (ROOT / path).read_text(encoding="utf-8")
    assert f'local {name} = req("src/{name}")' in main
    assert delegation in main
    assert f"return {name}" in source
assert "BattleFlow = BattleFlow, RuntimePolicy = RuntimePolicy" in main
print("modular main composition checks passed")


# 4.7.1 manager extractions. These modules own substantial M-method clusters
# while sharing the live manager through the same install contract.
manager_installed = {
    "Gauntlet": ("src/manager/Gauntlet.lua", "GauntletManager"),
    "Materialize": ("src/manager/Materialize.lua", "MaterializeManager"),
    "Persistence": ("src/manager/Persistence.lua", "PersistenceManager"),
    "Comms": ("src/manager/Comms.lua", "CommsManager"),
}
for name, (path, local_name) in manager_installed.items():
    source = (ROOT / path).read_text(encoding="utf-8")
    assert f'local {local_name} = req("src/manager/{name}")' in main
    assert f"{local_name}.install(mod, M)" in main
    module_name = {"Gauntlet":"Gauntlet", "Materialize":"Materialize", "Persistence":"Persistence", "Comms":"CommsManager"}[name]
    assert f"function {module_name}.install(" in source
    module_name = {"Gauntlet":"Gauntlet", "Materialize":"Materialize", "Persistence":"Persistence", "Comms":"CommsManager"}[name]
    assert f"return {module_name}" in source

# The manager context is the sole bridge for former main-scope constants/helpers.
for key in ("LAB_SLOTS", "RIVAL_SPRITE_PREFER", "SAVE_VERSION",
            "gauntletLabId", "homeMapsFor"):
    assert f"  {key} =" in main, f"manager context missing {key}"

assert len(main.splitlines()) < 4500, "main.lua regressed toward the monolith"
print("4.7.1 manager extraction checks passed")
