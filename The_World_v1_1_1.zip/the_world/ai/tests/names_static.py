from pathlib import Path
import re

ROOT = Path(__file__).resolve().parents[1]
names = (ROOT / "data" / "names.lua").read_text(encoding="utf-8")
roster = (ROOT / "data" / "rivals.lua").read_text(encoding="utf-8")

def pool(label):
    m = re.search(r"Names\.%s = \{(.*?)\}" % label, names, re.S)
    assert m, label
    return re.findall(r'"([^"]+)"', m.group(1))

boys = pool("BOYS")
girls = pool("GIRLS")

assert len(boys) == 400, len(boys)
assert len(girls) == 400, len(girls)
assert len({x.lower() for x in boys}) == 400
assert len({x.lower() for x in girls}) == 400
assert "DYANARI" in girls
assert "LARISSA" in girls

# A rival gets one given name only. No generated surname can be concatenated
# with another given name, so "Ash Ash"/"Kelly Ash" style results are impossible.
assert all(" " not in x for x in boys + girls)

# A male and female rival should never collide on the same visible name.
assert not ({x.lower() for x in boys} & {x.lower() for x in girls})

# Shawn is the sole authored personality.
assert roster.count('personality = "HEARTBREAK_KID"') == 1
assert roster.count('personality = "') == 1
assert roster.count('personalities = PERSONALITY_POOL') == 5
assert 'for slot = 6, 100 do' in roster

print("4.7.1 rival name-pool static checks passed")
