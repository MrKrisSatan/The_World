"""4.5.0 -- the Pokegear call conversation, as a contract.

The bug this release fixes was not a broken button: the call worked and its
only feedback went to `manager.ticker`, which main.lua draws exclusively while
the overworld is the top of the state stack.  These checks name the properties
that keep it fixed rather than listing strings:

  * CALL opens a conversation screen instead of closing the contact screen
  * the conversation carries the three things a call is for
  * every reply is written to the screen's own text box, not only the ticker
  * a tournament staged from inside a menu waits for the overworld
"""
from pathlib import Path

root = Path(__file__).parents[1]
poke = (root / "src" / "Pokegear.lua").read_text()
main = (root / "main.lua").read_text()
scout = (root / "src" / "Scout.lua").read_text()
comms = (root / "src" / "Comms.lua").read_text()


def strip_comments(text):
    """A file that documents a trap matches the pattern for the trap."""
    return "\n".join(l for l in text.splitlines() if not l.lstrip().startswith("--"))


poke_code = strip_comments(poke)
main_code = strip_comments(main + "\n" + "\n".join(p.read_text() for p in (root / "src").rglob("*.lua")))

# 1. CALL opens the conversation; it must not go back to closing itself.
assert 'mod.ui.push(game, "AIR_RivalGearCall", { contact = c })' in poke_code, \
    "CALL no longer opens the conversation screen"
for screen in ("AIR_RivalGearCall", "AIR_RivalGearAsk", "AIR_RivalGearScout",
               "AIR_RivalGearTournament"):
    assert f'mod.content.screens:register("{screen}"' in poke_code, f"missing {screen}"

# 2. Every option the brief asks for is reachable from the call.
for value in ('"_summon"', '"_tournament"', '"_scout"', '"_rematch"', '"_hangup"'):
    assert value in poke_code, f"the conversation cannot dispatch {value}"

# 3. Replies are written where the player is looking. The conversation screens
#    use the engine's message box and set their own footer on every answer.
assert poke_code.count("messageBox = true") >= 4, \
    "a conversation screen without a text box has nowhere to answer"
assert poke_code.count("selfMenu.footer = speech(") >= 4, \
    "an answer that is not written to the footer is invisible inside a menu"
assert "local SPEECH_LIMIT = 36" in poke_code, \
    "spoken lines must be fitted to the two 18-column lines the box shows"

# 4. Rows still fit the shared label/right row (the 4.3.1 overlap contract).
assert "rightRoom = math.max(0, 16 - #label - 1)" in poke_code
assert "local function fitRows(items)" in poke_code

# 4b. Handing the map back is one row, and stops at screens we do not own.
assert "local function closeAll(game)" in poke_code
assert "menu.__airPokegear = true" in poke_code
assert "closeAll(game)" in poke_code

# 5. Both formats, and a size the save can actually field.
assert 'mod.content.screens:register("AIR_RivalGearTournamentMode"' in poke_code
assert 'label = "STANDARD"' in poke_code and 'label = "DOUBLE"' in poke_code
assert 'manager:tournamentLimits("SINGLE")' in poke_code
assert 'manager:tournamentLimits("DOUBLE")' in poke_code
assert "local PRESETS = { 3, 4, 8, 16, 32, 64, 100 }" in poke_code, \
    "stepping to 100 one press at a time is not a control scheme"
assert "manager:arrangeTournament(arg and arg.hostId, count, mode, arg and arg.venueMap)" in poke_code
assert "local hostId = (host and host.id) or (c and c.rivalId) or nil" in poke_code, \
    "the host must resolve for saves written before contacts carried rivalId"

# 6. The knowledge model is derived, and ordinary trainers stay at rumour.
assert "function M:scoutReport(caller, subject)" in main_code
assert "function M:rivalForContact(record)" in main_code
assert 'return "RUMOUR"' in strip_comments(scout)
assert "Scout.KNOWN_BATTLES = 3" in scout
assert 'local Scout = req("src/Scout")' in main_code

# 7. Calls the player placed are recorded, through the closed reason set.
assert '"TOURNAMENT", "SCOUT", "CHALLENGE",' in comms, "new reasons must join the closed set"
assert 'TOURNAMENT = "Tournament", SCOUT = "Asked About", CHALLENGE = "Challenge",' in comms
assert "function M:noteCall(contactId, reason)" in main_code

# 8. A rival contact carries its rival from the moment it is offered.
assert "rivalId = info.rivalId," in comms

# 9. A tournament arranged inside the Pokegear waits for the overworld.
assert "M.tournaments:updatePending()" in main_code
gate = [l for l in main_code.splitlines() if "M.tournaments:updatePending" in l]
window = main_code[main_code.index("M.tournaments:updatePending") - 400:
                   main_code.index("M.tournaments:updatePending")]
assert "M:overworldIdle()" in window, \
    "a staged match may not launch while menus own the screen"

print("pokegear call conversation static PASS")

assert 'value = "_challenge"' in poke_code
assert 'manager:queueRivalAction(rival, "_challenge")' in poke_code
assert 'label = "TOURNAMENT HERE"' in poke_code
