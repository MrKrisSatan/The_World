-- Standalone: lua5.1 tests/pokegear_call_test.lua   (from mods/ai_rivals)
--
-- 4.5.0 -- THE POKEGEAR CALL CONVERSATION.
--
-- The reported symptom was "pressing CALL/REMATCH does nothing".  It is not a
-- dispatch failure: the row fires, the manager stages the action and the only
-- feedback is written to `manager.ticker`, which src/../main.lua draws ONLY
-- when the overworld is the top of the state stack (render.hud checks
-- `top.isOverworld`).  Inside the Pokegear the player is four screens deep, so
-- every word of that feedback is invisible, the contact screen simply pops one
-- level, and the deferred effect happens minutes later somewhere else.
--
-- These checks therefore assert what the PLAYER can see and choose, not what
-- the manager recorded:  a call opens a conversation, the conversation offers
-- the three things a call is for (summon, tournament, scouting), each option
-- answers ON SCREEN, and the format choice is reachable.
--
-- The stub ListMenu below mirrors src/ui/ListMenu.lua's real semantics:
-- A -> onChoose(item, self), B -> pop + onCancel, close() pops only when this
-- menu is the top of the stack.

local cache = {}
local function req(n)
  if cache[n] then return cache[n] end
  local f = assert(loadfile(n .. ".lua")); cache[n] = f(req, {}); return cache[n]
end

local pass, fail = 0, 0
local function ok(c, m) if c then pass = pass + 1 else fail = fail + 1; print("FAIL " .. m) end end
local function eq(a, b, m) if a == b then pass = pass + 1 else fail = fail + 1
  print(("FAIL %s (got %s want %s)"):format(m, tostring(a), tostring(b))) end end

------------------------------------------------------------------
-- A miniature of the engine's ListMenu / state stack / input.
------------------------------------------------------------------

local function newStack()
  local stack = { items = {} }
  function stack:push(s) self.items[#self.items + 1] = s; return s end
  function stack:pop() return table.remove(self.items) end
  function stack:top() return self.items[#self.items] end
  return stack
end

local function newInput()
  local input = { pressed = {} }
  function input:wasPressed(key) return self.pressed[key] == true end
  function input:isDown() return false end
  function input:set(key) self.pressed = {}; if key then self.pressed[key] = true end end
  return input
end

local ListMenu = {}
ListMenu.__index = ListMenu

function ListMenu.new(game, title, items, opts)
  opts = opts or {}
  return setmetatable({
    game = game, title = title, items = items or {}, index = 1,
    onChoose = opts.onChoose, onCancel = opts.onCancel,
    footer = opts.footer, messageBox = opts.messageBox,
    rows = opts.rows or ((opts.messageBox or opts.dialogue) and 4 or 7),
  }, ListMenu)
end

function ListMenu:update()
  local input = self.game.input
  if #self.items == 0 then return end
  if input:wasPressed("up") then self.index = math.max(1, self.index - 1)
  elseif input:wasPressed("down") then self.index = math.min(#self.items, self.index + 1)
  elseif input:wasPressed("b") then
    self.game.stack:pop(); if self.onCancel then self.onCancel() end
  elseif input:wasPressed("a") then
    if self.onChoose then self.onChoose(self.items[self.index], self) end
  end
end

function ListMenu:close()
  if self.game.stack:top() == self then self.game.stack:pop() end
end

------------------------------------------------------------------
-- Stub mod surface.
------------------------------------------------------------------

local screens = {}
local hooks = {}
local modStub = {
  content = { screens = { register = function(_, id, def) screens[id] = def end } },
  hooks = { wrap = function(_, name, fn) hooks[name] = fn end },
  ui = {
    ListMenu = ListMenu,
    insertBefore = function(items, _, item) items[#items + 1] = item; return items end,
    push = function(game, id, arg)
      local def = screens[id]
      if not def then error("no such screen: " .. tostring(id)) end
      return game.stack:push(def.new(game, arg))
    end,
  },
  assets = { path = function(_, p) return p end },
  list = function() return {} end,
  info = function() return nil end,
}

local function newGame()
  return { stack = newStack(), input = newInput(), save = { party = {
    { species = "PIKACHU", hp = 20 }, { species = "EEVEE", hp = 18 } } } }
end

-- Press a key against the top screen.
local function press(game, key)
  game.input:set(key)
  local top = game.stack:top()
  if top then top:update(0) end
  game.input:set(nil)
end

-- Move the cursor onto the row carrying `value`, then press A.
local function choose(game, value)
  local top = game.stack:top()
  ok(top ~= nil, "a screen is open when choosing " .. tostring(value))
  if not top then return end
  local target
  for i, item in ipairs(top.items) do if item.value == value then target = i end end
  ok(target ~= nil, "row " .. tostring(value) .. " exists on '" .. tostring(top.title) .. "'")
  if not target then return end
  while top.index < target do press(game, "down") end
  while top.index > target do press(game, "up") end
  press(game, "a")
end

local function hasRow(menu, value)
  for _, item in ipairs(menu and menu.items or {}) do
    if item.value == value then return true end
  end
  return false
end

local function screenText(menu)
  local parts = { tostring(menu and menu.title or ""), tostring(menu and menu.footer or "") }
  for _, item in ipairs(menu and menu.items or {}) do
    parts[#parts + 1] = tostring(item.label or "") .. " " .. tostring(item.right or "")
  end
  return table.concat(parts, " | ")
end

------------------------------------------------------------------
-- Fixtures: two rivals with real parties and a manager stub that
-- answers exactly the calls Pokegear makes on it.
------------------------------------------------------------------

local Comms = req("src/Comms")
local Scout = pcall(req, "src/Scout") and req("src/Scout") or nil

local function fakeRival(id, name, party, badges, map)
  local r = {
    id = id, name = name, party = party, map = map,
    bonds = {},
    badgeCount = function(self) return badges end,
    maxHpOf = function(_, slot) return slot.maxHp or 20 end,
  }
  function r:bondWith(other) return self.bonds[other] or { wins = 0, losses = 0 } end
  return r
end

local function newManager()
  local chris = fakeRival("chris", "CHRIS",
    { { species = "CHARMANDER", level = 14, hp = 20 },
      { species = "PIDGEY", level = 12, hp = 18 } }, 2, "PEWTER_CITY")
  local matt = fakeRival("matt", "MATT",
    { { species = "SQUIRTLE", level = 15, hp = 22 },
      { species = "ODDISH", level = 11, hp = 16 } }, 3, "CERULEAN_CITY")
  chris.bonds.matt = { wins = 2, losses = 1 }

  local comms = Comms.new()
  local function join(id, info)
    Comms.offer(comms, id, info, 7)
    Comms.accept(comms, id)
  end
  join("PHONE_AIR_CHRIS", { name = "CHRIS", kind = "RIVAL", rivalId = "chris" })
  -- The offer must carry the rival through: a RIVAL contact that reaches the
  -- Pokegear anonymous is indistinguishable from an ordinary trainer.
  ok(Comms.get(comms, "PHONE_AIR_CHRIS").rivalId == "chris",
    "a rival contact knows which rival it is")
  join("TRAINER_BUG_CATCHER_1", { name = "BUG CATCHER", kind = "TRAINER" })

  local M = {
    comms = comms,
    -- 4.5.3 gates the DOUBLE tournament on the player having two healthy
    -- Pokemon, and reads them from the MANAGER's game rather than the screen's.
    -- The stub carries one for the same reason the fixture trainer in
    -- double_faint_test carries six: a harness too small to reach the gate
    -- reports a pass that means nothing.
    game = { save = { party = {
      { species = "PIKACHU", hp = 20 }, { species = "EEVEE", hp = 18 } } } },
    rivals = { chris, matt },
    byId = { chris = chris, matt = matt },
    generation = 1,
    calls = {}, tournaments = {},
    compat = nil,
    radioEnabled = false, radioStation = "OFF",
    sim = { tick = 100 },
  }
  function M:worldView() return { playerMap = "VIRIDIAN_CITY" } end
  function M:save() end
  function M:callContact(id)
    self.calls[#self.calls + 1] = id
    local record = Comms.get(self.comms, id)
    if not record then return false, "That number is not in your Pokegear." end
    if record.kind == "RIVAL" then return true, "CHRIS is coming to you." end
    return true, "BUG CATCHER is ready for a rematch."
  end
  function M:tournamentLimits() return 12 end
  function M:arrangeTournament(hostId, count, mode)
    self.tournaments[#self.tournaments + 1] = { host = hostId, count = count, mode = mode }
    return true, mode .. " tournament arranged with " .. tostring(count) .. " rivals."
  end
  function M:rivalForContact(record)
    return record and record.rivalId and self.byId[record.rivalId] or nil
  end
  function M:scoutReport(caller, subject)
    if Scout then return Scout.report(caller, subject, self.sim.tick) end
    return { headline = "?", rows = {} }
  end
  function M:noteCall(id, reason)
    self.noted = self.noted or {}
    self.noted[#self.noted + 1] = { id = id, reason = reason }
    return Comms.isReason(reason)
  end
  function M:acceptPendingPhoneOffer() return true end
  function M:declinePendingPhoneOffer() return true end
  return M
end

------------------------------------------------------------------
-- 1. A CALL OPENS A CONVERSATION THE PLAYER CAN READ.
------------------------------------------------------------------

local Pokegear = req("src/RivalGear")
local manager = newManager()
RivalGear.init(modStub, manager, Comms)

local game = newGame()
local rivalContact = Comms.get(manager.comms, "PHONE_AIR_CHRIS")
modStub.ui.push(game, "AIR_RivalGearContact", { contact = rivalContact })
eq(#game.stack.items, 1, "the contact screen opens")

choose(game, "_call")
local conversation = game.stack:top()
ok(conversation ~= nil and conversation ~= game.stack.items[1],
  "CALL opens a new screen instead of closing the contact screen")
ok(conversation and (conversation.footer or ""):upper():find("CHRIS"),
  "the rival answers on screen (footer: " .. tostring(conversation and conversation.footer) .. ")")

------------------------------------------------------------------
-- 2. THE CONVERSATION OFFERS THE THREE THINGS A CALL IS FOR.
------------------------------------------------------------------

ok(hasRow(conversation, "_summon"), "the conversation can ask the rival to come to you")
-- 4.5.2/4.5.3 renamed this row and moved the format onto its own screen. The
-- CONTRACT being defended is "a call can arrange a tournament", not the string
-- the row happens to carry, so the check is widened rather than re-pinned.
ok(hasRow(conversation, "_tournament_here") or hasRow(conversation, "_tournament"),
  "the conversation can arrange a tournament")
ok(hasRow(conversation, "_scout"), "the conversation can ask about another rival's team")
ok(hasRow(conversation, "_hangup"), "the conversation can be ended deliberately")

------------------------------------------------------------------
-- 3. SUMMONING ANSWERS IN THE CONVERSATION, NOT ON A HIDDEN TICKER.
------------------------------------------------------------------

choose(game, "_summon")
eq(game.stack:top(), conversation, "asking the rival to come to you keeps the call open")
ok(#manager.calls == 1 and manager.calls[1] == "PHONE_AIR_CHRIS",
  "the summon reaches the manager exactly once")
ok((conversation.footer or ""):upper():find("COMING")
   or (conversation.footer or ""):upper():find("WAY"),
  "the rival's answer is shown in the call (footer: " .. tostring(conversation.footer) .. ")")

------------------------------------------------------------------
-- 4. ASKING ABOUT ANOTHER RIVAL'S TEAM.
------------------------------------------------------------------

choose(game, "_scout")
local pick = game.stack:top()
ok(pick ~= conversation, "a rival to ask about is chosen from a list")
ok(hasRow(pick, "matt"), "the other rival can be asked about")
ok(not hasRow(pick, "chris"), "a rival is not asked about themselves")
choose(game, "matt")
local report = game.stack:top()
ok(report ~= pick, "the answer is a screen of its own")
local text = screenText(report):upper()
ok(text:find("SQUIRTLE"), "a rival they have battled reports that team (" .. text .. ")")
press(game, "b")
press(game, "b")
eq(game.stack:top(), conversation, "backing out of the answer returns to the call")

------------------------------------------------------------------
-- 5. TOURNAMENTS: 2..N RIVALS AND BOTH FORMATS, FROM THE CALL.
------------------------------------------------------------------

local function rowOf(menu, value)
  for _, item in ipairs(menu.items or {}) do if item.value == value then return item end end
end

choose(game, hasRow(conversation, "_tournament_here") and "_tournament_here" or "_tournament")
local tour = game.stack:top()
ok(tour ~= conversation, "the tournament setup is its own screen")
ok(hasRow(tour, "_count") and hasRow(tour, "_start"),
  "tournament setup offers a size and a start")

local countRow = rowOf(tour, "_count")
game.input:set("right"); tour:update(0); game.input:set(nil)
ok(tonumber((tostring(countRow.right):match("^(%d+)"))) >= 3,
  "the rival count can be raised (" .. tostring(countRow.right) .. ")")
ok(tostring(countRow.right):find("12"), "the count row shows the save's own ceiling")

-- 4.5.3 made the format an EXPLICIT screen instead of a hidden toggle on the
-- count row. Either shape satisfies the contract that matters -- the player can
-- pick singles or doubles, and the pick is the one actually arranged -- so the
-- test follows whichever the build offers instead of dictating one. What it
-- will not do is stop checking that the choice reaches the manager.
choose(game, "_start")
local modeScreen = game.stack:top()
if modeScreen ~= tour and hasRow(modeScreen, "_double") then
  ok(hasRow(modeScreen, "_single"), "the battle-mode screen offers standard battles")
  ok(true, "and the double-battle tournament")
  choose(game, "_double")
else
  local formatRow = rowOf(tour, "_format")
  ok(formatRow ~= nil, "a format row exists when there is no battle-mode screen")
  if formatRow then
    local before = formatRow.right
    choose(game, "_format")
    ok(formatRow.right ~= before, "pressing A on FORMAT switches singles/doubles")
    choose(game, "_start")
  end
end
eq(#manager.tournaments, 1, "starting arranges exactly one tournament")
eq(manager.tournaments[1].mode, "DOUBLE", "the chosen format is the one arranged")
ok(manager.tournaments[1].count >= 3, "the chosen size is the one arranged")

------------------------------------------------------------------
-- 6. TRAINER CONTACTS: the same conversation, with a rematch.
------------------------------------------------------------------

local game2 = newGame()
local trainerContact = Comms.get(manager.comms, "TRAINER_BUG_CATCHER_1")
modStub.ui.push(game2, "AIR_RivalGearContact", { contact = trainerContact })
choose(game2, "_call")
local trainerCall = game2.stack:top()
ok(trainerCall and hasRow(trainerCall, "_rematch"),
  "a trainer call offers a rematch")
ok(not hasRow(trainerCall, "_summon"),
  "a trainer is not asked to walk across Kanto")
choose(game2, "_rematch")
ok((trainerCall.footer or ""):upper():find("REMATCH")
   or (trainerCall.footer or ""):upper():find("WAITING"),
  "the trainer answers the rematch request on screen")

-- A staged battle waits for an idle overworld, so the conversation offers to
-- hand the map back rather than leaving the player three menus deep wondering
-- whether anything happened.
ok(hasRow(trainerCall, "_close"), "the call offers to close the Pokegear for the fight")
choose(game2, "_close")
eq(#game2.stack.items, 0, "closing pops every Pokegear screen, not just the top one")

------------------------------------------------------------------
-- 7. WHAT A CALLER MAY NOT SAY.
--
-- Written after the implementation, deliberately probing the parts the
-- earlier checks left alone: leakage, refusals, the size ceiling and whose
-- screens CLOSE MENU is allowed to pop.
------------------------------------------------------------------

do
  -- A trainer holds no head-to-head record, so a trainer must answer at
  -- rumour level about a rival OTHER rivals have fought repeatedly.
  local game3 = newGame()
  modStub.ui.push(game3, "AIR_RivalGearCall", { contact = trainerContact })
  choose(game3, "_scout")
  choose(game3, "matt")
  local text = screenText(game3.stack:top()):upper()
  ok(not text:find("SQUIRTLE"),
    "an ordinary trainer does not recite a rival's party (" .. text .. ")")
  ok(text:find("BADGES") or text:find("AROUND"),
    "but does pass on what is public")
end

do
  -- SEEN is a partial answer by design: two battles must not release the
  -- whole team, or the knowledge level is decoration.
  local seenCaller = fakeRival("seen", "SEEN", {}, 0, "ROUTE_1")
  seenCaller.bonds.matt = { wins = 1, losses = 1 }
  local subject = manager.byId.matt
  subject.party[3] = { species = "GROWLITHE", level = 9, hp = 14 }
  local report = manager:scoutReport(seenCaller, subject)
  local seen = {}
  for _, row in ipairs(report.rows or {}) do seen[tostring(row.label):upper()] = true end
  ok(not seen["GROWLITHE"],
    "two battles do not reveal a Pokemon that never came out")
  seenCaller.bonds.matt = { wins = 2, losses = 2 }
  local full = manager:scoutReport(seenCaller, subject)
  local known = {}
  for _, row in ipairs(full.rows or {}) do known[tostring(row.label):upper()] = true end
  ok(known["GROWLITHE"], "a caller who has fought them often knows the whole team")
  subject.party[3] = nil
end

do
  -- A refused summon must SAY it was refused. The old build put the refusal
  -- on the ticker, which is exactly where the player could not read it.
  local refuser = newManager()
  function refuser:callContact() return false, "CHRIS is already accompanying you." end
  RivalGear.init(modStub, refuser, Comms)
  local game4 = newGame()
  modStub.ui.push(game4, "AIR_RivalGearCall",
    { contact = Comms.get(refuser.comms, "PHONE_AIR_CHRIS") })
  choose(game4, "_summon")
  local call = game4.stack:top()
  ok((call.footer or ""):upper():find("ACCOMPANYING"),
    "a refusal is spoken in the call (footer: " .. tostring(call.footer) .. ")")
  ok(call.items[1].right ~= "ON WAY", "and the row does not claim success")
end

do
  -- The size ceiling is the save's, not the preset table's.
  local small = newManager()
  function small:tournamentLimits() return 5 end
  RivalGear.init(modStub, small, Comms)
  local game5 = newGame()
  modStub.ui.push(game5, "AIR_RivalGearTournament",
    { contact = Comms.get(small.comms, "PHONE_AIR_CHRIS") })
  for _ = 1, 8 do choose(game5, "_count") end
  choose(game5, "_start")
  if hasRow(game5.stack:top(), "_single") then choose(game5, "_single") end
  ok(#small.tournaments == 1, "a tournament is arranged")
  ok(small.tournaments[1].count <= 5,
    "the preset jump is capped by the roster (" .. tostring(small.tournaments[1].count) .. ")")
  ok(small.tournaments[1].count >= 3, "and never falls below the minimum field")
end

do
  -- CLOSE MENU hands the map back, but must stop at a screen we do not own:
  -- the start menu underneath belongs to the engine.
  local host = newManager()
  RivalGear.init(modStub, host, Comms)
  local game6 = newGame()
  local foreign = { title = "START MENU" }
  game6.stack:push(foreign)
  modStub.ui.push(game6, "AIR_RivalGear", {})
  modStub.ui.push(game6, "AIR_RivalGearCall",
    { contact = Comms.get(host.comms, "TRAINER_BUG_CATCHER_1") })
  choose(game6, "_rematch")
  ok(hasRow(game6.stack:top(), "_close"),
    "a staged rematch offers to hand the map back")
  choose(game6, "_close")
  eq(game6.stack:top(), foreign, "closing pops every Pokegear screen and stops there")
  eq(#game6.stack.items, 1, "and pops nothing that is not ours")
end

print(("pokegear call conversation: %d passed, %d failed"):format(pass, fail))
os.exit(fail == 0 and 0 or 1)
