-- Standalone: luajit tests/bonds_rankings_test.lua   (from mods/ai_rivals)
--
-- 4.6.0. Three features, one suite, because they share one question: does the
-- world the screens describe actually exist?
--
--   1. The deeper relationship states, and LOVERS as a state neither rival can
--      reach alone.
--   2. TRAINER RANKINGS with the player IN the table.
--   3. The trainer record -- derived from the world, never logged.
--
-- The title-match half lives in tests/title_match_test.lua, which needs the
-- battle simulator.

local cache = {}
local function req(n)
  if cache[n] then return cache[n] end
  local f = assert(loadfile(n .. ".lua")); cache[n] = f(req, {}); return cache[n]
end

local pass, fail = 0, 0
local function ok(c, m) if c then pass = pass + 1 else fail = fail + 1; print("FAIL " .. m) end end
local function eq(a, b, m) if a == b then pass = pass + 1 else fail = fail + 1
  print(("FAIL %s (got %s want %s)"):format(m, tostring(a), tostring(b))) end end

local R = req("src/Relationships")
local Achievements = req("src/Achievements")
local Rankings = req("src/Rankings")
local League = req("src/League")

------------------------------------------------------------------
-- 1. THE NEW STATES REFINE; THEY DO NOT STEAL.
------------------------------------------------------------------
-- Every 4.6.0 state is a strict subset of one that already existed, and each
-- is tested BEFORE the general case. Written the other way round the specific
-- state is unreachable -- the general one matches first, every time -- which
-- is the "guard that can never be true" failure wearing a new hat. These
-- checks pin the ORDER by constructing a bond that satisfies both and
-- asserting the specific answer.

local function bond(over)
  local b = {
    regard = 0, rivalry = 0, respect = 0, affection = 0, favours = 0, lead = 0,
    wins = 0, losses = 0, peakRegard = 0, peakAffection = 0, since = 0, tick = 0,
    reasons = {},
  }
  for k, v in pairs(over or {}) do b[k] = v end
  return b
end

eq(R.state(bond({ regard = -90, rivalry = 70, wins = 1, losses = 6 })), "NEMESIS",
  "hatred with a history reads as NEMESIS, not merely HOSTILE")
eq(R.state(bond({ regard = -60, rivalry = 70, wins = 0, losses = 2 })), "HOSTILE",
  "a falling-out without the history is still HOSTILE")
eq(R.state(bond({ regard = -90, rivalry = 70, wins = 0, losses = 2 })), "HOSTILE",
  "hatred needs contests behind it, not just a low number")

eq(R.state(bond({ affection = 95, regard = 70, favours = 5, respect = 30,
                  tick = 5000, since = 0 })), "DEVOTED",
  "the full conjunction reaches DEVOTED")
eq(R.state(bond({ affection = 95, regard = 70, favours = 5, respect = 30,
                  tick = 400, since = 0 })), "ALLIED",
  "without the shared history it is only ALLIED -- devotion takes time")
eq(R.state(bond({ affection = 100, regard = 70, favours = 1, respect = 30,
                  tick = 9000, since = 0 })), "FRIENDLY",
  "affection alone never reaches DEVOTED (it starts seeded as high as 75)")

eq(R.state(bond({ regard = 30, wins = 0, losses = 4, lead = -3 })), "PROTEGE",
  "the junior half of a mentorship has its own state")
eq(R.state(bond({ regard = 30, wins = 4, losses = 0, lead = 3 })), "MENTOR",
  "and the senior half is unchanged")

eq(R.state(bond({ respect = 60, wins = 0, losses = 5, regard = 5 })), "ADMIRER",
  "respect earned from well behind reads as ADMIRER")
eq(R.state(bond({ respect = 60, wins = 3, losses = 3, regard = 5 })), "RESPECT",
  "respect between equals is still RESPECT")

eq(R.state(bond({ peakRegard = 60, regard = -30 })), "ESTRANGED",
  "a bond that was warm and went cold reads as ESTRANGED")
eq(R.state(bond({ peakRegard = 0, regard = -30 })), "NEUTRAL",
  "a bond that was NEVER warm is not estranged, it is just cold")

-- The migration case: a save written before peaks existed must not suddenly
-- report every cold relationship as a falling-out.
local migrated = R.new({ someone = { regard = -30, rivalry = 5 } })
eq(R.state(migrated.someone), "NEUTRAL",
  "an old save's cold bond does not become ESTRANGED on load")
local warm = R.new({ someone = { regard = 55, rivalry = 0 } })
ok(warm.someone.peakRegard >= 55,
  "a loaded bond's peak starts at what the save can prove, not at zero")

------------------------------------------------------------------
-- 2. LOVERS IS A PAIR STATE.
------------------------------------------------------------------
-- Neither rival can decide it alone. That is the whole reason it is rare:
-- rarity here is a conjunction that is hard to satisfy twice, not a die roll,
-- and nothing in Relationships.lua rolls for a state.

local devoted = bond({ affection = 95, regard = 70, favours = 5, respect = 30,
                       tick = 5000, since = 0 })
local alsoDevoted = bond({ affection = 92, regard = 80, favours = 6, respect = 40,
                           tick = 6000, since = 0 })
local friendly = bond({ regard = 40 })
local cold = bond({ regard = -90, rivalry = 70, wins = 1, losses = 6 })

eq(R.pairState(devoted, alsoDevoted), "LOVERS",
  "two independently devoted rivals are LOVERS")
eq(R.pairState(devoted, friendly), "UNREQUITED",
  "devotion in one direction only is UNREQUITED, not LOVERS")
eq(R.pairState(friendly, friendly), "CLOSE_FRIENDS", "mutual warmth is friendship")
eq(R.pairState(cold, cold), "FEUD", "mutual hatred is a feud")
eq(R.pairState(bond({ rivalry = 60 }), bond({ rivalry = 60 })), "ARCH_RIVALS",
  "two hot rivalries pointing at each other are arch rivals")
eq(R.pairState(friendly, cold), "NONE",
  "a warm side and a cold side agree on nothing, and the pair says so")

ok(R.pairHeadline("CHRIS", "LARISSA", "LOVERS"), "a pair state has a sentence")
ok(R.pairHeadline("CHRIS", "LARISSA", "NONE") == nil,
  "and 'nothing in particular' is not news")

-- Behaviour, not just a label: a devoted rival does not go picking fights with
-- the one they are devoted to.
ok(R.fightBias("DEVOTED") < R.fightBias("ALLIED"),
  "devotion suppresses fight-seeking further than alliance does")
ok(R.fightBias("NEMESIS") > R.fightBias("HOSTILE"),
  "a nemesis is sought out harder than an ordinary enemy")
ok(R.willCooperate("DEVOTED"), "and they will stand together in a double battle")

------------------------------------------------------------------
-- 3. RANKINGS PUT THE PLAYER IN THE TABLE.
------------------------------------------------------------------

local function fakeRival(id, name, badges, over)
  local r = {
    id = id, name = name, party = {}, bonds = {},
    badges = {}, champion = false,
    badgeCount = function() return badges end,
    ensureLeague = function(self) return self.league end,
  }
  r.league = League.newRecord(over and over.league or {})
  for k, v in pairs(over or {}) do if k ~= "league" then r[k] = v end end
  return r
end

local chris = fakeRival("chris", "CHRIS", 8, { champion = true,
  league = { clears = 1, attempts = 2, reigns = 1, defences = 3 } })
local matt = fakeRival("matt", "MATT", 6)
local larissa = fakeRival("larissa", "LARISSA", 5)
local dyanari = fakeRival("dyanari", "DYANARI", 4)

local rows = Rankings.build({ matt, chris, dyanari, larissa },
  { name = "Player", badges = 7, caught = 30 })
eq(#rows, 5, "every trainer in the save is ranked, the player included")
eq(rows[1].name, "CHRIS", "the champion tops the table")
eq(rows[2].name, "Player", "the player is ranked by badges like everyone else")
eq(rows[3].name, "MATT", "then the next rival down")
eq(rows[5].name, "DYANARI", "and the table runs to the bottom")
eq(rows[2].rank, 2, "rows carry their rank")
ok(rows[2].player, "the player's row is marked so the screen can show it")
eq(Rankings.statusLabel(rows[1]), "CHAMPION", "the champion's status is the title")
eq(Rankings.statusLabel(rows[2]), "7 Badges", "everyone else shows their badges")
eq(Rankings.statusLabel(rows[5]), "4 Badges", "plural is not assumed")
eq(Rankings.badgeLabel({ badges = 1 }), "1 Badge", "one badge is singular")
eq(Rankings.champion(rows).id, "chris", "the champion is findable for the banner")

-- No champion is a REAL state -- the Elite Four have not been beaten yet --
-- and must not be papered over with whoever happens to be top.
local vacant = Rankings.build({ matt, larissa }, { name = "Player", badges = 1 })
eq(Rankings.champion(vacant), nil, "a vacant title reports as vacant")

-- A save with no player yet does not get an invented row: a player with zero
-- badges placed below everybody is a claim, and absence is not a claim.
local noPlayer = Rankings.build({ matt, larissa }, nil)
eq(#noPlayer, 2, "no player facts means no player row")

-- Ordering is deterministic. The same world twice gives the same table, or the
-- ranking reshuffles under the player's cursor.
local again = Rankings.build({ larissa, dyanari, chris, matt },
  { name = "Player", badges = 7, caught = 30 })
local sameOrder = true
for i = 1, #rows do
  if rows[i].id ~= again[i].id then sameOrder = false end
end
ok(sameOrder, "the same world produces the same ranking, whatever order it is fed")

------------------------------------------------------------------
-- 4. THE RECORD IS DERIVED FROM THE WORLD.
------------------------------------------------------------------

local GYMS = {
  order = { "BOULDERBADGE", "CASCADEBADGE", "THUNDERBADGE" },
  byBadge = {
    BOULDERBADGE = { leader = "BROCK" },
    CASCADEBADGE = { leader = "MISTY" },
    THUNDERBADGE = { leader = "LT_SURGE" },
  },
}
local NOTABLE = { "ARTICUNO", "MEWTWO" }

chris.badges = { BOULDERBADGE = true, CASCADEBADGE = true }
chris.party = {
  { species = "CHARIZARD", level = 60 },
  { species = "ARTICUNO", level = 55 },
}
chris.pcBoxes = { { { species = "PIDGEY", level = 12, shiny = true } } }
chris.favouriteSpecies = function() return "CHARIZARD" end
chris.bonds = { player = true, matt = true, dyanari = true }
chris.relationshipTo = function(_, id)
  if id == "player" then return "RIVALRY" end
  if id == "matt" then return "NEMESIS" end
  return "FRIENDLY"
end
chris.bondWith = function(_, id)
  return { rivalry = id == "player" and 70 or 50 }
end

local record = Achievements.record(chris, {
  gyms = GYMS, notable = NOTABLE, names = { matt = "MATT", dyanari = "DYANARI" },
})

eq(record.badges, 8, "the record reads the badge count from the rival")
eq(record.eliteFour, "Defeated", "a champion has beaten the Elite Four")
eq(record.champion, true, "and holds the title")
eq(record.defences, 3, "title defences come from the League record")
eq(record.favourite, "CHARIZARD", "the favourite is the bonded ace")
ok(record.career:find("Champion"), "the career ends at Champion (" .. record.career .. ")")

local highlights = table.concat(record.highlights, " | ")
ok(highlights:find("Defeated Brock"), "a held badge names its leader (" .. highlights .. ")")
ok(highlights:find("Defeated Misty"), "in ladder order")
ok(not highlights:find("Surge"), "a badge NOT held is not claimed")
ok(highlights:find("Captured Articuno"), "a notable capture is a highlight")
ok(highlights:find("shiny Pidgey"), "so is a shiny, wherever it is stored")
ok(highlights:find("Became Champion"), "so is the title")
ok(highlights:find("Defended title 3 times"), "and the defences of it")

eq(record.rivalries[1].name, "MATT", "the strongest rivalry is named first")
eq(record.rivalries[1].state, "NEMESIS", "with the state that earned it")
eq(record.rivalries[2].name, "Player", "the player counts as a rivalry")
ok(#record.rivalries <= Achievements.MAX_RIVALRIES, "the list is bounded")

-- A rival with nothing to its name says nothing, rather than defaulting.
local rookie = fakeRival("rookie", "ROOKIE", 0)
local blank = Achievements.record(rookie, { gyms = GYMS, notable = NOTABLE })
eq(blank.eliteFour, "Not yet", "a rookie has not entered the League")
eq(#blank.highlights, 0, "and has no highlights to invent")
eq(blank.favourite, nil, "no favourite means nil, not a stand-in first slot")
eq(blank.career, "Trainer", "and the career is what they are, not what they plan")

-- The interesting middle: a rival that keeps failing has a story, and "Not
-- yet" throws it away.
local trying = fakeRival("trying", "TRYING", 8,
  { league = { attempts = 6, bestStage = 4 } })
eq(Achievements.eliteFour(trying.league, false), "Reached 4",
  "a rival that keeps falling at Lance says how far it got")

------------------------------------------------------------------
-- 5. THE RECORD CANNOT OUTLIVE THE FACT.
------------------------------------------------------------------
-- The point of deriving rather than logging: take the badge away and the
-- sentence about it goes too. A logged achievement list would still be
-- claiming Brock here.

chris.badges.CASCADEBADGE = nil
local after = Achievements.record(chris, { gyms = GYMS, notable = NOTABLE })
local afterText = table.concat(after.highlights, " | ")
ok(not afterText:find("Misty"),
  "a badge removed from the world removes its highlight (" .. afterText .. ")")
ok(afterText:find("Defeated Brock"), "and leaves the ones still true")

print(("bonds, rankings and records: %d passed, %d failed"):format(pass, fail))
os.exit(fail == 0 and 0 or 1)
