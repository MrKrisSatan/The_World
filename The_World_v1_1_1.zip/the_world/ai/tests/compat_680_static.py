#!/usr/bin/env python3
import json, pathlib, re
root=pathlib.Path(__file__).resolve().parents[1]
manifest=json.loads((root/'manifest.json').read_text())
assert manifest['version']=='6.8.0'
assert set(['red','blue','yellow','gold']).issubset(set(manifest.get('games',[])))
assert manifest.get('gen2compat') is True
version=(root/'src/Version.lua').read_text()
rocket=(root/'src/RocketDisguise.lua').read_text()
main=(root/'main.lua').read_text()
quests=(root/'src/Quests.lua').read_text()
g2talk=(root/'src/Gen2Talk.lua').read_text()
assert 'data.gen2Maps or data.gen2Trainers' in version
assert 'SPRITE_SURFING_PIKACHU' in version
assert 'Version.detect(data)=="gen2" then return true' in rocket
assert '(inv.POKE_FLUTE or 0)>0' in rocket
assert 'map:find("LAVENDER",1,true)' in rocket
assert 'isFujiInteraction' in main
assert 'WonderTrade.makeMon(game.data,species,level,generation)' in rocket
assert 'src.core.gen2.Boxes' in rocket and 'Boxes.NUM_BOXES' in rocket
assert 'sourceInteraction=true' in rocket and 'offeredByNpc=true' in rocket
assert 'Gen2Talk.register' in main and 'talkToWrapper' in g2talk
# Gold must not be forced through a Gen1-only constructor for black-market purchases.
place=rocket[rocket.index('local function placePurchasedPokemon'):rocket.index('function D:buyStolenPokemon')]
assert 'src.pokemon.Pokemon' not in place
# Gen1 progression proof remains intact.
assert 'POKE_FLUTE' in rocket
print('AI Rivals v6.8 Red/Blue/Yellow/Gold compatibility static checks PASS')
