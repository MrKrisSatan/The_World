#!/usr/bin/env python3
"""7.1.0 cross-generation feature parity + personality pool audit."""
import json, pathlib, re
root=pathlib.Path(__file__).resolve().parents[1]
manifest=json.loads((root/'manifest.json').read_text())
assert manifest['version']=='7.1.0'
assert {'red','blue','yellow','gold'} <= set(manifest.get('games', []))
assert manifest.get('gen2compat') is True

main=(root/'main.lua').read_text()
required_modules=['FeatureParity','DoubleBattles','WonderTrade','WeatherResearch','Memory','Relationships','Phone','Pokegear','Tournaments','Ecology','WorldState','Rocket','Rangers','Factions','RocketDisguise','DoubleAgent','StolenRecovery','RivalWars','Quests']
for name in required_modules:
    assert re.search(rf'(?:local\s+{re.escape(name)}\s*=.*src/{re.escape(name)}|src/{re.escape(name)})', main), name
parity=(root/'src/FeatureParity.lua').read_text()
for feature in ['rivals','league','phone','pokegear','quests','team_rocket','rocket_uniform','rocket_balls','stolen_pokemon','double_agent','rangers','factions','rival_wars','ecology','weather_fx','weather_research','wonder_trade','tournaments','double_battles']:
    assert re.search(rf'\b{feature}=true', parity), feature
for game in ['red','blue','yellow','gold']:
    assert re.search(rf'\b{game}=true', parity), game

# All major feature managers are built before gameplay irrespective of generation.
for token in ['RangersManager.new','Factions.new','RocketDisguise.new','RivalWars.new','Quests.new']:
    assert token in main, token

poke=(root/'src/RivalGear.lua').read_text()
assert 'Pokégear for both generations' in poke
assert 'Red, Blue, Yellow and Gold' in poke

g2talk=(root/'src/Gen2Talk.lua').read_text()
assert 'Gen1Facade.talkToWrapper' in g2talk and 'Gen2Talk.register' in g2talk

weather=(root/'src/WeatherResearch.lua').read_text()
assert 'local GEN1' in weather and 'local GEN2' in weather
assert 'Gen2Talk.register' in weather and 'map_scripts:register' in weather

wonder=(root/'src/WonderTrade.lua').read_text()
assert 'src.battle.gen2.Mon' in wonder and 'src.pokemon.Pokemon' in wonder
assert 'simulateAgent' in wonder

rocket=(root/'src/RocketDisguise.lua').read_text()
assert 'Version.detect(data)=="gen2"' in rocket
assert 'src.core.gen2.Boxes' in rocket
assert 'WonderTrade.makeMon' in rocket

sim=(root/'src/Simulation.lua').read_text()
assert 'data.gen2Encounters' in sim and 'data.gen2Trainers' in sim

ecology=(root/'src/Ecology.lua').read_text()
quests=(root/'src/Quests.lua').read_text()
rocket_sim=(root/'src/Rocket.lua').read_text()
for text,name in [(ecology,'Ecology'),(quests,'Quests'),(rocket_sim,'Rocket')]:
    assert 'gen2' in text.lower(), name

personalities=(root/'data/personalities.lua').read_text()
rivals=(root/'data/rivals.lua').read_text()
new_ids=[
 'NORTHERN_LOYALIST','COURT_SCHEMER','DRAGON_HEIR','QUIET_SPY','OATHBOUND_KNIGHT',
 'IRON_COMMISSAR','MACHINE_ADEPT','INQUISITIVE_PURIFIER','VOID_VETERAN','GLORY_REAVER',
 'CYBER_OPERATIVE','SECTION_CHIEF','HEAVY_OPERATIVE','GHOST_HACKER',
 'SOLAR_IDEALIST','MIDNIGHT_TACTICIAN','WINGED_GUARDIAN','REALITY_ENGINEER',
 'STREET_MERC','NETRUNNER','CORPORATE_FIXER','NOMAD','ROCKER_REBEL','EDGERUNNER']
for pid in new_ids:
    assert re.search(rf'\b{pid}\s*=\s*{{', personalities), pid
    assert f'"{pid}"' in rivals, pid
# Ensure each new archetype has the data fields consumed by AI/Economy/Travel.
for pid in new_ids:
    block=personalities.split(pid+' = {',1)[1].split('\n  },',1)[0]
    for field in ['priorities','gymConfidence','challengeChance','trainRate','wanderChance','catchChance','partyTarget','healAt','teamPlan']:
        assert field in block, (pid,field)
print('AI Rivals v7.1 feature parity + expanded personality checks PASS')
