from pathlib import Path
root = Path(__file__).resolve().parents[1]
main = (root / "main.lua").read_text(encoding="utf-8")

block = main[main.index('mod.events:on("intro.oak_speech.answered"'):
             main.index("-- THE TICK.")]
assert 'Util.guard("intro.answer"' not in block
assert 'M.pendingIntroRivalCount = count' in block
assert 'M.pendingIntroGauntletMode = mode' in block
assert 'pcall(function() mod.save:set("aiRivalCount", count) end)' in block

update = main[main.index('mod.hooks:wrap("core.update"'):]
assert 'if M.pendingIntroRivalCount and M.rivalContext then' in update
assert 'if M.pendingIntroGauntletMode then' in update
assert 'M:setRivalCount(pendingCount)' in update

print("intro answer deferred-init/retry static checks: OK")
