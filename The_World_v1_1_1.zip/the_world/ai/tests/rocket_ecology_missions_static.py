from pathlib import Path
import re

ROOT = Path(__file__).resolve().parents[1]
rocket = (ROOT / "src" / "Rocket.lua").read_text(encoding="utf-8")
ecology = (ROOT / "src" / "Ecology.lua").read_text(encoding="utf-8")
data = (ROOT / "data" / "rocket.lua").read_text(encoding="utf-8")

required_ops = [
    "SPECIES_SWEEP", "SPECIES_POACH", "DRIVE_MIGRATION",
    "FOOD_SOURCE_EXPERIMENT", "HABITAT_STRIP", "BREEDING_SITE",
]
for op in required_ops:
    assert op in data, f"missing Rocket ecology operation {op}"
    assert op in rocket, f"operation {op} is not resolved"

assert "function Rocket:chooseEcologyTarget" in rocket
assert "function Rocket:resolveEcologyOperation" in rocket
assert "ecologyTargets" in rocket
assert "encounterSlots" in rocket
assert "recordMigration" in rocket
assert "recordAdaptation" in rocket
assert "migrationDestination" in rocket
assert "foodSource" in rocket
assert "adaptations" in ecology
assert "migrations" in ecology
assert "function Ecology:recordMigration" in ecology
assert "function Ecology:recordAdaptation" in ecology
assert "local displaced = self:migrationBias" in ecology
assert "adaptation = self:adaptationPressure" in ecology
assert "version = 3" in ecology

print("Rocket ecological mission system: PASS")
