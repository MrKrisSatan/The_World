"""Every module a file uses by bare name must be one that file required.

THE BUG THIS SUITE EXISTS FOR
-----------------------------
5.0.0 moved large clusters of M methods out of main.lua and into
src/manager/*.lua. The methods came across; the LOCALS they closed over did
not. `Util`, `Rival`, `AI`, `Comms` and the local function `activeRoster` were
main.lua locals, and an extracted chunk gets its own scope -- so in the new
files every one of them was a read of a nil GLOBAL.

Nothing caught it. Syntax was fine, `modkit lint` was fine, the mod loaded,
the intro ran. It surfaced as

    intro.gauntlet.retry: .../manager/Persistence.lua:42:
    attempt to index global 'Util' (a nil value)

on the first save -- three releases after the split, because the crash needs a
save to happen and the save happens after the gauntlet.

The rule is mechanical, so the test is too: if a file writes `Foo.bar` or
`Foo:bar` and `Foo` is the name of a module in this mod, that file must
declare `Foo` -- by requiring it, or as its own local, or as a parameter.
Anything else is a global read, and a global read of a module name is the bug
above.

This is deliberately name-driven rather than a Lua parse: the failure mode was
a KNOWN SET of module names appearing unbound, and a check that needs no Lua
toolchain runs everywhere the rest of the Python suites run.
"""
import re
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]

# Every module name that can legitimately appear as `Name.x` / `Name:x`.
MODULE_NAMES = {p.stem for p in (ROOT / "src").rglob("*.lua")}
MODULE_NAMES |= {
    # data/ modules are required under other local names; these are the ones
    # that are also used bare.
    "Data",
}

# Names that are bound by something other than a require and are fine bare.
ALLOWED_BARE = {
    # standard library and engine-provided globals
    "Game", "Pokemon", "BattleState", "Battle", "Text", "Flags",
}

SCAN = sorted(
    [p for p in (ROOT / "src").rglob("*.lua")]
    + [ROOT / "main.lua"]
    + [p for p in (ROOT / "data").rglob("*.lua")]
)

# `local Foo`, `local Foo =`, `local Foo, Bar =`, `function Foo.x`, and the
# `local req, mod = ...` header all count as declaring the name.
def declared(source):
    names = set()
    for match in re.finditer(r"^\s*local\s+([A-Za-z_][\w, ]*)", source, re.M):
        for part in match.group(1).split(","):
            part = part.strip()
            if part:
                names.add(part)
    for match in re.finditer(r"^\s*(?:local\s+)?function\s+([A-Za-z_]\w*)", source, re.M):
        names.add(match.group(1))
    # `for Foo in`, `for Foo, Bar in`
    for match in re.finditer(r"^\s*for\s+([A-Za-z_][\w, ]*?)\s+(?:in|=)", source, re.M):
        for part in match.group(1).split(","):
            part = part.strip()
            if part:
                names.add(part)
    return names


def strip_comments_and_strings(source):
    """§3: a file that DOCUMENTS a trap matches the pattern for the trap.

    The comment block at the top of src/manager/Persistence.lua names `Util`
    while explaining why it is now required; without this the suite would
    flag the very comment that records the fix.
    """
    source = re.sub(r"--\[(=*)\[.*?\]\1\]", " ", source, flags=re.S)
    source = re.sub(r"--[^\n]*", " ", source)
    source = re.sub(r"\[(=*)\[.*?\]\1\]", '""', source, flags=re.S)
    source = re.sub(r'"(?:\\.|[^"\\])*"', '""', source)
    source = re.sub(r"'(?:\\.|[^'\\])*'", '""', source)
    return source


failures = []
for path in SCAN:
    raw = path.read_text(encoding="utf-8")
    source = strip_comments_and_strings(raw)
    bound = declared(source) | ALLOWED_BARE
    used = set()
    for match in re.finditer(r"\b([A-Z][A-Za-z0-9_]*)\s*[.:]", source):
        used.add(match.group(1))
    for name in sorted(used & MODULE_NAMES):
        if name not in bound:
            failures.append(f"{path.relative_to(ROOT)}: uses `{name}` but never declares it")

assert not failures, "unbound module names (the 5.0.7 crash class):\n  " + "\n  ".join(failures)


# The specific requires the 5.0.7 crash needed, pinned by name so a future
# refactor that drops one fails here rather than in a player's save.
required_by = {
    "src/manager/Persistence.lua": ["Util", "Rival", "Comms"],
    "src/manager/Materialize.lua": ["Util", "Rival", "AI"],
    "src/manager/Gauntlet.lua": ["Util", "Rival", "AI"],
}
for rel, names in required_by.items():
    source = (ROOT / rel).read_text(encoding="utf-8")
    for name in names:
        assert f'local {name} = req("src/{name}")' in source, f"{rel} must require {name}"

# `activeRoster` is a main.lua local that closes over mod.save/mod.options, so
# it cannot be required. It travels through the same _ctx seam as every other
# main.lua value the managers need, and both ends are pinned.
main = (ROOT / "main.lua").read_text(encoding="utf-8")
assert "activeRoster = activeRoster," in main, "main.lua must export activeRoster on _ctx"
gauntlet = (ROOT / "src/manager/Gauntlet.lua").read_text(encoding="utf-8")
assert "local activeRoster = C.activeRoster" in gauntlet

# homeMapsFor sits above the manager table and read the nil global `M` for the
# whole 4.x line, which silently disabled the version-keyed arm of every
# roster row's homeMaps. The forward declaration is what makes it a local.
forward = main.index("\nlocal M\n")
table_decl = main.index("\nM = {\n")
helper = main.index("local function homeMapsFor")
assert forward < helper < table_decl, "M must be forward-declared above homeMapsFor"
assert "\nlocal M = {" not in main, "M is declared once, as a forward declaration"

print("nil-global contract checks passed")
