from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
main=(ROOT/"main.lua").read_text()
manifest=(ROOT/"manifest.json").read_text()

assert 'GEN1_CONNECTION_SENTINEL = "__airGen1ConnectionYieldV738"' in main
assert "local previous = OW.crossConnection" in main
assert "OW.crossConnection = function(self, ...)" in main
assert "M:despawnAll()" in main
assert "M.rocket:despawnAll()" in main
assert "M.rangers:despawnAll()" in main
assert "return previous(self, ...)" in main
assert "if detectGeneration(M.data) == 2 then return false end" in main
assert 'Util.guard("gen1:connection-yield"' in main
assert '"version": "7.3.8"' in manifest
print("7.3.8 Gen1 connection-yield checks passed")
