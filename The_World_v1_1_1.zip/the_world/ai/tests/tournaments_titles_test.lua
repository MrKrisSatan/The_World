-- Standalone: luajit tests/tournaments_titles_test.lua   (from mods/ai_rivals)
--
-- 4.7.0. Two features that share nothing except being asked for together:
--
--   1. A tournament may be initiated once a day BY EACH INITIATOR -- the
--      player and every rival separately -- and the reward scales with how
--      many rivals took part and how many people watched.
--   2. Rivals have TITLES the rest of Kanto knows them by, derived from the
--      team they are actually carrying and the standing they have earned.
--
-- The tournament half exists because a daily limit is exactly the kind of rule
-- that looks right and is wrong: one shared key means the first rival to hold
-- an event spends everybody's day, and a limit read from a clock that does not
-- exist locks the feature out entirely on a boot with no device time.

local cache = {}
local function req(n)
  if cache[n] then return cache[n] end
  local f = assert(loadfile(n .. ".lua")); cache[n] = f(req, {}); return cache[n]
end

local pass, fail = 0, 0
local function ok(c, m) if c then pass = pass + 1 else fail = fail + 1; print("FAIL " .. m) end end
local function eq(a, b, m) if a == b then pass = pass + 1 else fail = fail + 1
  print(("FAIL %s (got %s want %s)"):format(m, tostring(a), tostring(b))) end end

local Tournaments = req("src/Tournaments")
local Titles = req("src/Titles")

------------------------------------------------------------------
-- 1. ONE DAY, ONE TOURNAMENT, PER INITIATOR
------------------------------------------------------------------

local function newManager()
  local M = { rivals = {}, byId = {}, news = {}, sim = { tick = 0 } }
  function M:worldView() return { playerMap = "CERULEAN_CITY" } end
  function M:save() end
  return M
end

local manager = newManager()
local t = Tournaments.new(manager)

local free, today = t:mayInitiateToday("player")
ok(free, "the player starts the day able to run one")
ok(today ~= nil, "and the day has a key")

t:spendInitiation("player", today)
ok(not (t:mayInitiateToday("player")), "having run one, the player is done for today")

-- The bug this separates out: rivals must not share the player's allowance,
-- or each other's. A hundred rivals on one key means the world holds one
-- tournament a day between all of them.
ok(t:mayInitiateToday("chris"), "a rival's allowance is their own, not the player's")
t:spendInitiation("chris", today)
ok(not t:mayInitiateToday("chris"), "and is spent when they use it")
ok(t:mayInitiateToday("matt"), "another rival still has theirs")

-- Tomorrow.
t:spendInitiation("chris", "2020-01-01")
ok(t:mayInitiateToday("chris"), "a new day restores the allowance")

-- Round-trips through the save, bounded and typed.
local saved = t:serialize()
local restored = Tournaments.new(manager)
restored:restore(saved)
ok(not restored:mayInitiateToday("player"),
  "a spent day survives a save and reload")
saved.initiatedDay = { [1] = "junk", chris = 77, matt = "2020-01-01" }
local defensive = Tournaments.new(manager)
defensive:restore(saved)
ok(defensive:mayInitiateToday("chris"),
  "a malformed day entry is dropped rather than trusted")
ok(defensive:mayInitiateToday("matt"),
  "and a stale one simply does not match today")

------------------------------------------------------------------
-- 2. THE PURSE SCALES -- AND IS BOUNDED
------------------------------------------------------------------

local small = { originalCount = 3, witnessCount = 0 }
local big = { originalCount = 40, witnessCount = 12 }
local huge = { originalCount = 100, witnessCount = 100 }

local mSmall = t:purseMultiplier(small)
local mBig = t:purseMultiplier(big)
ok(mBig > mSmall, "more rivals and a bigger crowd pay better")
eq(t:purseMultiplier({ originalCount = 0, witnessCount = 0 }), 1,
  "an empty field pays the base and no more")

-- Each half moves it on its own, or one of the two things Christopher asked
-- for is decoration.
ok(t:purseMultiplier({ originalCount = 10, witnessCount = 0 }) > mSmall,
  "the field size alone raises the purse")
ok(t:purseMultiplier({ originalCount = 3, witnessCount = 10 }) > mSmall,
  "the crowd alone raises the purse")

ok(t:purseMultiplier(huge) <= Tournaments.MAX_MULTIPLIER,
  "and the whole thing is capped (" .. t:purseMultiplier(huge) .. ")")
eq(t:prizeCount(1.0), 1, "a quiet event pays one item")
ok(t:prizeCount(t:purseMultiplier(big)) >= 2, "a big one pays more")
ok(t:prizeCount(99) <= 3, "but never unbounded")

------------------------------------------------------------------
-- 3. WHO IS WATCHING
------------------------------------------------------------------

local function fakeRival(id, map) return { id = id, name = id:upper(), map = map } end
manager.rivals = {
  fakeRival("chris", "CERULEAN_CITY"),
  fakeRival("matt", "CERULEAN_CITY"),
  fakeRival("larissa", "PEWTER_CITY"),
  fakeRival("dyanari", "CERULEAN_CITY"),
}
for _, r in ipairs(manager.rivals) do manager.byId[r.id] = r end

local bracket = { venueMap = "CERULEAN_CITY", playerEntry = true,
                  allEntrants = { "chris", "player" }, entrants = { "chris" } }
eq(t:witnesses(bracket), 3,
  "rivals at the venue who are not competing are the crowd, and the player counts")

bracket.allEntrants = { "chris", "matt", "dyanari", "player" }
eq(t:witnesses(bracket), 1,
  "a rival IN the bracket is not also watching it")

bracket.venueMap = "PEWTER_CITY"
bracket.playerEntry = false
eq(t:witnesses(bracket), 1, "only the venue's own map counts")

eq(t:witnesses({ }), 0, "an event with no venue has no crowd, not an error")

------------------------------------------------------------------
-- 4. TITLES
------------------------------------------------------------------

local FIRE = { types = { "FIRE" } }
local WATER = { types = { "WATER" } }
local NORMAL = { types = { "NORMAL" } }

local function titled(over)
  local r = {
    name = over.name or "RIVAL", gender = over.gender, party = over.party or {},
    champion = over.champion, lifePath = over.lifePath,
    badgeCount = function() return over.badges or 0 end,
    ensureLeague = function() return over.league or {} end,
    speciesDef = function(_, species)
      if species == "CHARMANDER" then return FIRE end
      if species == "SQUIRTLE" then return WATER end
      return NORMAL
    end,
  }
  return r
end

local fire = { { species = "CHARMANDER" }, { species = "CHARMANDER" },
               { species = "CHARMANDER" } }
local water = { { species = "SQUIRTLE" }, { species = "SQUIRTLE" },
                { species = "SQUIRTLE" } }

-- The two Christopher named.
eq(Titles.of(titled{ gender = "female", badges = 8, party = fire }),
  "Princess of Ashes",
  "a powerful female Fire specialist is the Princess of Ashes")
eq(Titles.of(titled{ gender = "male", badges = 8, party = water }),
  "Might of Oceans",
  "a powerful male Water specialist is the Might of Oceans")
eq(Titles.of(titled{ gender = "female", badges = 5, party = fire }),
  "the Cinder Maiden",
  "and the same trainer earlier on is not yet the Princess")
eq(Titles.of(titled{ gender = "male", badges = 5, party = water }),
  "the Ocean's Wrath",
  "the mid tier is Ocean's Wrath")

-- A title is EARNED. Nobody starts with one.
eq(Titles.of(titled{ gender = "female", badges = 0, party = fire }), nil,
  "a rookie has no title at all")
eq(Titles.of(titled{ gender = "male", badges = 1, party = water }), nil,
  "one badge is not a reputation")

-- No dominant type means no elemental name -- "Princess of Nothing In
-- Particular" is worse than a plain standing title.
local mixed = { { species = "CHARMANDER" }, { species = "SQUIRTLE" },
                { species = "PIDGEY" }, { species = "RATTATA" } }
local mixedTitle = Titles.of(titled{ badges = 8, party = mixed })
ok(mixedTitle and not tostring(mixedTitle):find("Ashes"),
  "a balanced team gets a standing title, not an elemental one (" ..
  tostring(mixedTitle) .. ")")
eq(Titles.dominantType(titled{ party = mixed }), nil,
  "and no type is reported as dominant when none is")
eq(Titles.dominantType(titled{ party = { { species = "CHARMANDER" } } }), nil,
  "one Pokemon is not a specialism")

-- The crown outranks everything.
eq(Titles.of(titled{ badges = 8, party = mixed, champion = true }), "the Champion",
  "a champion with no specialism is known for the crown")

-- Rocket is what you are known for, whatever you carry.
eq(Titles.of(titled{ badges = 5, party = fire, lifePath = "TEAM_ROCKET" }),
  Titles.ROCKET, "a Rocket is known for that first")

-- DERIVED, not stored: change the team and the name changes with it. A stored
-- title would still be calling this trainer the Princess of Ashes.
local switcher = titled{ gender = "female", badges = 8, party = fire }
eq(Titles.of(switcher), "Princess of Ashes", "she is the Princess today")
switcher.party = water
eq(Titles.of(switcher), "Queen of Tides",
  "and something else entirely once the team changes")

-- Determinism: the same rival read twice gives the same name, or rivals
-- calling each other by title would look like a bug.
local a = Titles.of(titled{ gender = "male", badges = 6, party = fire })
local b = Titles.of(titled{ gender = "male", badges = 6, party = fire })
eq(a, b, "the same trainer is called the same thing every time")

eq(Titles.full(titled{ name = "CHRIS", gender = "male", badges = 8, party = fire }),
  "CHRIS, Lord of Ashes", "the full form is name and title")
eq(Titles.full(titled{ name = "ROOKIE", badges = 0 }), "ROOKIE",
  "and a trainer with no title is just their name")

------------------------------------------------------------------
-- 5. RIVALS ACTUALLY USE THE TITLES ON EACH OTHER
------------------------------------------------------------------
-- "Other rivals should use their titles when referring to them in
-- conversation." A title that only ever appears on a record screen is a
-- database field, not a reputation -- so this checks the places one trainer
-- speaks about another: scouting reports, phone gossip, tournament billing.

local Scout = req("src/Scout")

local famous = titled{ name = "MATT", gender = "male", badges = 8, party = water }
famous.party = water
famous.id = "matt"
famous.bonds = {}
famous.bondWith = function() return { wins = 2, losses = 2 } end

-- Scout reads the spoken name off the subject; main stamps it. Both halves are
-- checked, because either one alone is a feature that does not reach a player.
local plain = Scout.report({ id = "chris", bondWith = function()
  return { wins = 2, losses = 2 } end }, famous, 100)
ok(tostring(plain.line):find("MATT"),
  "with no title stamped, a caller uses the plain name (" .. tostring(plain.line) .. ")")

local titledSubject = setmetatable({ spokenName = "Might of Oceans" },
  { __index = famous })
local spoken = Scout.report({ id = "chris", bondWith = function()
  return { wins = 2, losses = 2 } end }, titledSubject, 100)
ok(tostring(spoken.line):find("Might") or tostring(spoken.line):find("Oceans"),
  "a titled rival is spoken about by title (" .. tostring(spoken.line) .. ")")

-- The manager must be the one deciding the name, in ONE place, or half the
-- game says "MATT" and the other half says "Might of Oceans".
local main_src = io.open("main.lua"):read("*a")
ok(main_src:find("function M:spokenNameOf", 1, true),
  "there is a single accessor for the spoken name")
ok(main_src:find("self:spokenNameOf(rival)", 1, true),
  "phone gossip uses it")
local tourn_src = io.open("src/Tournaments.lua"):read("*a")
ok(tourn_src:find("manager.spokenNameOf", 1, true),
  "tournament announcements use it")
ok(tourn_src:find('if id == PLAYER then return "PLAYER" end', 1, true),
  "and the player is never given a title on their behalf")

print(("tournaments and titles: %d passed, %d failed"):format(pass, fail))
os.exit(fail == 0 and 0 or 1)
