#!/usr/bin/env python3
"""Static contracts for v1.39 Rival League.

Behaviour is proven by the two Lua suites. This file guards the structural
rules, above all the two that were broken: the retry gate must escalate, and a
title shot must be earned rather than owed.
"""
import re
import sys
from pathlib import Path

root = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(Path(__file__).resolve().parent))
from _version import at_least

league = (root / "src" / "League.lua").read_text(encoding="utf-8")
rival = (root / "src" / "Rival.lua").read_text(encoding="utf-8")
sim = (root / "src" / "Simulation.lua").read_text(encoding="utf-8")
main = (root / "main.lua").read_text(encoding="utf-8")
all_source = main + "\n" + "\n".join(p.read_text(encoding="utf-8") for p in (root / "src").rglob("*.lua"))
errors = []


def need(token, blob, label):
    if token not in blob:
        errors.append(label)


def code_of(blob):
    return "\n".join(l for l in blob.splitlines() if not l.lstrip().startswith("--"))


# --- THE 1500-ATTEMPT BUG ----------------------------------------------------
# The flat 16-tick retry must be gone from the simulation branch entirely.
if re.search(r"rival\.leagueCooldown\s*=\s*16\b", code_of(sim)):
    errors.append("the flat 16-tick League retry cooldown is still assigned in "
                  "Simulation -- this is the 1500-attempt bug")
need("League.MIN_GAP", league, "no minimum gap between League runs")
need("League.MAX_COOLDOWN", league, "the retry cooldown is uncapped")
need("record.unproductive", league,
     "escalation does not distinguish a rival that is improving")
need("rival:mayAttemptLeague()", sim, "the League branch does not consult the gate")
need("League.tick(record)", sim, "the League cooldown is never ticked down")
# escalation must be driven by unproductive failures, not raw attempts
escalate = league[league.index("record.walls[stage] = math.min"):]
escalate = escalate[:escalate.index("return record")]
need("record.unproductive * League.COOLDOWN_STEP", escalate,
     "the cooldown does not escalate on unproductive failures")
need("math.max(League.MIN_GAP", escalate, "the minimum gap is not applied")

# --- §30: a title shot is EARNED --------------------------------------------
need("function League.mayChallengeTitle", league, "no title qualification check")
need("rival.mayChallengeTitle and rival:mayChallengeTitle()", main,
     "the title challenge does not require a qualifying League run")
need("record.qualified = true", league, "clearing the League does not qualify")
qual = league[league.index("function League.beginReign"):]
qual = qual[:qual.index("\nend")]
need("record.qualified = false", qual,
     "taking the title does not spend the qualification, so a deposed champion "
     "would keep a free title shot forever")

# --- bounds ------------------------------------------------------------------
need("League.MAX_STAGE", league, "the wall table is unbounded")
walls = league[league.index("function League.newRecord"):]
walls = walls[:walls.index("\nend")]
need("if n >= 1 and n <= League.MAX_STAGE then", walls,
     "a corrupt save could add wall rows outside the legal stage range")
for capped in ("math.min(999", "math.min(99999", "math.min(9999"):
    if capped not in league:
        errors.append(f"a League counter is uncapped ({capped} missing)")
# deterministic wall selection -- never pairs() order
wall_fn = league[league.index("function League.wall"):]
wall_fn = wall_fn[:wall_fn.index("\nend")]
need("for stage = 1, League.MAX_STAGE do", wall_fn,
     "the wall is chosen by pairs() order, so two identical saves could disagree")
# deterministic standings
sort_fn = league[league.index("function League.sortStandings"):]
sort_fn = sort_fn[:sort_fn.index("\nend")]
need("tostring(a.id) < tostring(b.id)", sort_fn,
     "the standings sort has no final tie-break, so it is not deterministic")

for banned in ("math.random", "os.time", "os.clock", "love."):
    if banned in league:
        errors.append(f"the League model is not deterministic ({banned})")

# --- persistence -------------------------------------------------------------
need("league = League.newRecord()", rival, "rivals have no League record")
need("league = League.serializeRecord(self.league),", rival,
     "the League record is not saved")
need("self.league = League.newRecord(saved.league)", rival,
     "the League record is not restored")
need("tonumber(saved.leagueAttempts)", rival,
     "a pre-1.39 save loses its real attempt count")

# --- surfaces ----------------------------------------------------------------
need('mod.commands:register("rival_league"', all_source, "no League debug verb")
need('SCREEN .. "Standings"', all_source, "no standings screen (§27)")
need('value = "_standings"', all_source, "the standings screen is unreachable")
need("League = League,", main, "the model is not exported for tests")
need('name .. " fell at the League, stage "', main,
     "League news does not say where the rival fell")

# --- preserved ---------------------------------------------------------------
for token in ("KantoCompat", "WonderTrade.install(mod, M)", "rivalGiftAllowed",
              "Relationships.headline", "TeamPlan = TeamPlan", "Story = Story",
              "Presence = Presence", "Weather = Weather", "Economy = Economy"):
    need(token, main, f"earlier contract lost: {token}")
need("local SAVE_VERSION = 10", main, "save version regressed")
errors.extend(x for x in [at_least(root, "1.39.0")] if x)

if errors:
    for error in errors:
        print("FAIL", error)
    raise SystemExit(1)
print("AI Rivals v1.39 League: escalating retry gate, earned title shots, "
      "bounded records, deterministic standings PASS")
