-- Standalone: lua5.1 tests/integration_test.lua   (from mods/ai_rivals)
--
-- v2.0 INTEGRATION AND ACCEPTANCE.
--
-- Eight subsystems were built between 1.32 and 1.39 -- memory, relationships,
-- team identity, story, presence, weather, economy, League -- and every one of
-- them was tested ALONE. This is the first suite that runs all eight on the
-- same four rivals at once, over a long career, and asks the questions that
-- only make sense at the seams:
--
--   * does a rival carrying all eight records survive save/load intact?
--   * does a bare pre-1.32 save migrate through all eight without any of them
--     inventing history?
--   * do eight systems that each individually respect the news budget still
--     respect it COLLECTIVELY? (each was measured on its own channel)
--   * does the serialized size of a rival stay bounded over a long game? this
--     is the "no unbounded save tables" rule, tested end to end for the first
--     time rather than per-system
--   * do the rivals still diverge once every system is pulling at once?

local cache = {}
local function req(n)
  if cache[n] then return cache[n] end
  local f = assert(loadfile(n .. ".lua")); cache[n] = f(req, {}); return cache[n]
end
local Util = req("src/Util")
local Rival = req("src/Rival")
local Relationships = req("src/Relationships")
local TeamPlan = req("src/TeamPlan")
local Story = req("src/Story")
local Presence = req("src/Presence")
local Weather = req("src/Weather")
local Economy = req("src/Economy")
local League = req("src/League")
local Memory = req("src/Memory")
local PERS, ROSTER = req("data/personalities"), req("data/rivals")

local pass, fail = 0, 0
local function eq(a, b, m) if a == b then pass = pass + 1 else fail = fail + 1
  print(("FAIL %s (got %s want %s)"):format(m, tostring(a), tostring(b))) end end
local function ok(c, m) if c then pass = pass + 1 else fail = fail + 1; print("FAIL " .. m) end end

-- ------------------------------------------------------------------
-- Fixture
-- ------------------------------------------------------------------
local TYPES = { "NORMAL", "WATER", "FIRE", "GRASS", "ELECTRIC", "ROCK" }
local DATA = { pokemon = {}, moves = { TACKLE = { power = 40, type = "NORMAL" } },
               constants = { fallbackMove = "TACKLE" }, type_chart = { matchups = {} },
               encounters = { ROUTE_9 = { slots = {} } } }
for i = 1, 18 do
  local id = "MON_" .. i
  DATA.pokemon[id] = {
    baseStats = { hp = 50 + i, attack = 50 + (i * 3) % 60, defense = 45 + i,
                  speed = 40 + (i * 5) % 70, special = 50 + i },
    types = { TYPES[(i % #TYPES) + 1] }, level1Moves = { "TACKLE" }, learnset = {},
  }
  DATA.encounters.ROUTE_9.slots[#DATA.encounters.ROUTE_9.slots + 1] = { species = id }
end
local GYMS = { order = {}, byBadge = {}, centers = { "CERULEAN_CITY" } }
for i = 1, 8 do GYMS.order[i] = "BADGE_" .. i end

local function compatFor(sky)
  return {
    _sky = sky,
    weather = function() return sky ~= nil end,
    weatherId = function(self) return self._sky end,
    battleWeather = function(self) return Weather.battleString(self, self._sky) end,
    exports = function() return nil end,
    krAllows = function() return true end,
  }
end

local function makeWorld(sky)
  local compat = compatFor(sky)
  local ctx = { data = DATA, personalities = PERS, compat = compat,
                graph = { has = function() return true end,
                          neighbours = function()
                            return { { to = "ROUTE_10" }, { to = "CERULEAN_POKECENTER" },
                                     { to = "ROUTE_9" } }
                          end },
                gyms = GYMS }
  local rivals = {}
  for i = 1, #ROSTER do
    local r = Rival.new(ROSTER[i], ctx)
    r.ticks, r.map = 0, "ROUTE_9"
    r.gauntletComplete = function() return true end
    r.story.seeded = true
    rivals[#rivals + 1] = r
  end
  return rivals, compat, ctx
end

-- ------------------------------------------------------------------
-- 1. EVERY SUBSYSTEM IS PRESENT ON EVERY RIVAL
-- ------------------------------------------------------------------
local rivals, compat, ctx = makeWorld("STORM")
eq(#rivals, #ROSTER, "the whole roster constructs with every system loaded")
for _, r in ipairs(rivals) do
  ok(type(r.memory) == "table", r.id .. " has 1.32 memory")
  ok(type(r.bonds) == "table", r.id .. " has 1.33 relationships")
  ok(type(r.teamPlan) == "table", r.id .. " has 1.34 team identity")
  ok(type(r.story) == "table", r.id .. " has 1.35 story")
  ok(type(r.ledger) == "table", r.id .. " has 1.38 ledger")
  ok(type(r.league) == "table", r.id .. " has 1.39 League record")
  ok(type(r:spendingProfile()) == "table", r.id .. " reports a spending profile")
  ok(Story.isMood(r:mood()), r.id .. " reports a legal mood")
  ok(TeamPlan.isArchetype(r:teamStyle()), r.id .. " reports a legal team identity")
end

-- ------------------------------------------------------------------
-- 2. A LONG SHARED CAREER, EXERCISING EVERYTHING AT ONCE
-- ------------------------------------------------------------------
local TICKS = 24000
local presence = Presence.new()
local news = {}
local function logNews(kind) news[kind] = (news[kind] or 0) + 1 end

local sizes = {}
local function measure(r)
  -- A crude but honest proxy for saved size: count every scalar reachable in
  -- the serialized blob. What matters is whether it GROWS without bound.
  local seen, n = {}, 0
  local function walk(v, depth)
    if depth > 12 then return end
    if type(v) ~= "table" then n = n + 1 return end
    if seen[v] then return end
    seen[v] = true
    for key, value in pairs(v) do
      n = n + 1
      walk(value, depth + 1)
    end
  end
  walk(r:serialize(), 0)
  return n
end

-- DIFFERENT STARTING HANDS, DIFFERENT LUCK.
--
-- An earlier version of this fixture gave all four rivals the same party and
-- the same win/loss pattern, and they duly converged on one mood, one ace and
-- one relationship state -- which says nothing about the systems, only that
-- identical inputs give identical outputs. Divergence is only meaningful when
-- the world treats them differently, which is what actually happens in play.
for i, r in ipairs(rivals) do
  r.party = {}
  for j = 1, 4 do r:addPokemon("MON_" .. ((i * 5 + j * 3) % 18 + 1), 10 + i + j) end
  r.money = 3000 + i * 700
end

for tick = 1, TICKS do
  local sky = ({ "STORM", "SUNNY", "FOG", "CLEAR", "BLIZZARD" })[(math.floor(tick / 3000) % 5) + 1]
  compat._sky = sky
  for i, r in ipairs(rivals) do
    r.ticks = tick

    -- battles against the player and each other
    local rate = math.max(5, math.floor(1 / (r.personality.rivalFightChance or 0.1)))
    if tick % rate == 0 then
      local won = ((tick / rate) + i) % (2 + i) ~= 0
      r:rememberPlayerBattle({ tick = tick, rivalWon = won, location = "ROUTE_9" })
      r:creditLeadBattle(won)
      local _, _, _, changed = r:recordRelationshipBattle("player", won,
        { tick = tick, lead = 0 })
      if changed then logNews("relationship") end
      if won then r:noteVictory("player", tick) else r:noteDefeat("player", tick) end
      r.confidence = Util.clamp((r.confidence or 1) + (won and 0.03 or -0.05), 0.5, 2.0)
      if won then r:earn(120) else r:forfeit(80) end
    end
    -- rival vs rival
    if tick % (rate * 3) == 0 then
      local other = rivals[(i % #rivals) + 1]
      if other ~= r then
        local won = (tick + i) % 2 == 0
        local _, _, _, ch = r:recordRelationshipBattle(other.id, won,
          { tick = tick, lead = 0 })
        if ch then logNews("relationship") end
      end
    end
    -- badges, training, shopping, hunting
    if tick % (2000 + i * 400) == 0 then
      local badge = GYMS.order[math.min(8, math.floor(tick / (2000 + i * 400)))]
      if badge then r.badges[badge] = true; logNews("badge") end
    end
    if tick % (700 + i * 250) == 0 then r:noteTrained(tick) end
    if tick % (300 + i * 130) == 0 then r:restockBalls() end
    if tick % (500 + i * 200) == 0 then r.map = "ROUTE_9"; r:pickHuntTarget() end
    if tick % 60 == 0 then r:visitMap("MAP_" .. (tick % 300)) end
    -- League, once the badges are in
    if r:badgeCount() >= 8 then
      local record = r:ensureLeague()
      League.tick(record)
      if r:mayAttemptLeague() then
        local cleared = r:leagueStrength() > 120
        League.recordAttempt(record, cleared and 5 or 4, cleared,
          { strength = r:leagueStrength() })
        logNews("league")
        if cleared and not r.champion then
          r.champion = true
          League.beginReign(record, tick)
          logNews("champion")
        end
      end
    end
    -- story
    local gained, _, chapterChanged, _, notable = r:advanceStory(tick)
    for _, m in ipairs(gained or {}) do if m.news then logNews("milestone") end end
    if chapterChanged and notable then logNews("chapter") end
    -- presence. Rivals are near the player SOMETIMES, not permanently: an
    -- earlier version of this fixture parked all four on the player's tile for
    -- ten hours, which is the worst case presence_soak_test already measures
    -- in isolation and is not a world to design the ticker around.
    local nearPlayer = ((tick + i * 700) % 3000) < 400
    if nearPlayer and Presence.observe(presence, { id = r.id, name = r.name,
        map = r.map, mapLabel = r.map, state = r.state, objective = r.objective,
        sameMap = true, travelling = true }, tick) then
      logNews("sighting")
    end
  end
  if tick % 4000 == 0 then sizes[#sizes + 1] = measure(rivals[1]) end
end

-- ------------------------------------------------------------------
-- 3. THE COLLECTIVE NEWS BUDGET
-- ------------------------------------------------------------------
-- Each system was measured on its own channel. They share one ticker.
local total = 0
local report = {}
for kind, n in pairs(news) do
  total = total + n
  report[#report + 1] = kind .. "=" .. n
end
table.sort(report)
print("news over 24000 ticks x " .. #rivals .. " rivals: " .. table.concat(report, " "))
print(("  total %d  (~%.1f per hour of play)"):format(total, total / (TICKS / 2400)))
ok(total > 10, "the world does report things worth knowing")
ok(total / (TICKS / 2400) < 120,
   "eight systems sharing one ticker stay under two items a minute COLLECTIVELY")
for kind, n in pairs(news) do
  ok(n <= total * 0.75, "no single channel swamps the ticker: " .. kind)
end

-- ------------------------------------------------------------------
-- 4. SAVE SIZE IS BOUNDED (the non-negotiable, measured end to end)
-- ------------------------------------------------------------------
print("serialized scalar count for one rival at 4000-tick intervals:")
print("  " .. table.concat(sizes, " "))
ok(#sizes >= 4, "size was sampled across the career")
local first, last = sizes[1], sizes[#sizes]
ok(last <= first * 2.5,
   ("a rival's save does not grow without bound (%d -> %d)"):format(first, last))
local peak = 0
for _, n in ipairs(sizes) do peak = math.max(peak, n) end
ok(peak < 4000, "and stays small enough for a mobile save")

-- ------------------------------------------------------------------
-- 5. EVERY SYSTEM SURVIVES ONE ROUND TRIP, TOGETHER
-- ------------------------------------------------------------------
for _, r in ipairs(rivals) do
  local blob = r:serialize()
  local back = Rival.new(ROSTER[1], ctx)
  -- restore against the right definition
  for i, def in ipairs(ROSTER) do if def.id == r.id then back = Rival.new(def, ctx) end end
  ok(back:restore(blob), r.id .. " restores with all eight subsystems")
  back.ticks = r.ticks
  eq(back:relationshipTo("player"), r:relationshipTo("player"),
     r.id .. ": relationships survive")
  eq(back:teamStyle(), r:teamStyle(), r.id .. ": team identity survives")
  eq(back:chapter(), r:chapter(), r.id .. ": story chapter survives")
  eq(Story.unlockedCount(back:ensureStory()), Story.unlockedCount(r:ensureStory()),
     r.id .. ": milestones survive")
  eq(back.money, r.money, r.id .. ": money survives")
  eq(Economy.totalSpent(back:ensureLedger()), Economy.totalSpent(r:ensureLedger()),
     r.id .. ": the ledger survives")
  eq(back:ensureLeague().attempts, r:ensureLeague().attempts,
     r.id .. ": the League record survives")
  eq(back:preferredType(), r:preferredType(), r.id .. ": type credit survives")
  eq(#back.memory.events, #r.memory.events, r.id .. ": memory survives")
  ok(Util.count(back.visitedMaps) <= Rival.NAV_LIMIT,
     r.id .. ": navigation memory survives and stays capped")
end

-- ------------------------------------------------------------------
-- 6. A BARE PRE-1.32 SAVE MIGRATES THROUGH ALL EIGHT
-- ------------------------------------------------------------------
-- The oldest shape any of these systems has to cope with: a rival record with
-- none of their keys at all. Every system must default safely AND invent
-- nothing -- eight separate migrations, exercised together for the first time.
local ancient = {
  id = ROSTER[1].id, name = ROSTER[1].name, map = "ROUTE_9", money = 2500,
  badges = { BADGE_1 = true, BADGE_2 = true }, playerWins = 3, playerLosses = 5,
  party = { { species = "MON_1", level = 20, hp = 30, moves = { "TACKLE" } } },
  leagueAttempts = 4,
}
local migrated = Rival.new(ROSTER[1], ctx)
ok(migrated:restore(ancient), "a pre-1.32 rival record restores")
migrated.ticks = 5000
eq(migrated.money, 2500, "the money it really had is kept")
eq(migrated.playerWins, 3, "as is its real battle record")
eq(migrated:badgeCount(), 2, "and its real badges")
eq(migrated:ensureLeague().attempts, 4, "and its real League attempts")
-- ...and nothing is invented
eq(migrated:relationshipTo("player"), "NEUTRAL", "no relationship history is invented")
eq(migrated:preferredType(), nil, "no type history is invented")
eq(Economy.totalSpent(migrated:ensureLedger()), 0, "no spending history is invented")
eq(Util.count(migrated:ensureLeague().walls), 0, "no League failures are invented")
eq(#migrated.memory.events, 0, "no memory is invented")
eq(migrated:ensureStory().seeded, false, "the story has not yet been seeded")
local firstGained = select(1, migrated:advanceStory(5000))
eq(#firstGained, 0, "and its first tick announces nothing")
ok(Story.unlockedCount(migrated:ensureStory()) > 0,
   "while still recording what it had genuinely earned")

-- ------------------------------------------------------------------
-- 7. DIVERGENCE SURVIVES ALL EIGHT SYSTEMS PULLING AT ONCE
-- ------------------------------------------------------------------
local styles, moods, chapters, aces, purses, bonds = {}, {}, {}, {}, {}, {}
for _, r in ipairs(rivals) do
  styles[r:teamStyle()] = true
  moods[r:mood()] = true
  chapters[r:chapter()] = true
  aces[tostring(r:favouriteSpecies())] = true
  purses[#purses + 1] = r.money
  bonds[r:relationshipTo("player")] = true
  print(("  %-8s %-16s %-11s %-12s ace=%-7s P%-6d %s"):format(
    r.id, TeamPlan.label(r:teamStyle()), r:moodLabel(), r:chapterLabel(),
    tostring(r:favouriteSpecies()), r.money, r:relationshipTo("player")))
end
-- Wealth is a real axis and a 1.38 one: the same battles pay differently once
-- four different spending profiles are drawing on the purse.
local purseSpread = 0
do
  local lo, hi = math.huge, 0
  for _, money in ipairs(purses) do lo, hi = math.min(lo, money), math.max(hi, money) end
  purseSpread = hi - lo
end
local axes = 0
local axisNames = { "team identity", "mood", "chapter", "favourite",
                    "player relationship" }
local diverged = {}
for n, set in ipairs({ styles, moods, chapters, aces, bonds }) do
  if Util.count(set) >= 2 then
    axes = axes + 1
    diverged[#diverged + 1] = axisNames[n]
  end
end
if purseSpread > 20000 then
  axes = axes + 1
  diverged[#diverged + 1] = "wealth"
end
print("  diverged on: " .. table.concat(diverged, ", "))
ok(axes >= 3, "the four rivals differ on at least three independent axes")
ok(Util.count(styles) >= 2, "they do not converge on one team identity")

-- ------------------------------------------------------------------
-- 8. LEGALITY INVARIANTS ACROSS THE WHOLE CAREER
-- ------------------------------------------------------------------
local champions = 0
for _, r in ipairs(rivals) do
  ok(r.money >= 0, r.id .. ": never ended in debt")
  ok(Story.isMood(r:mood()) and Story.isChapter(r:chapter()),
     r.id .. ": ended in a legal story state")
  ok(Relationships.isState(r:relationshipTo("player")),
     r.id .. ": ended in a legal relationship state")
  ok(TeamPlan.isArchetype(r:teamStyle()), r.id .. ": ended with a legal identity")
  ok(Util.count(r.bonds) <= Relationships.BOND_LIMIT, r.id .. ": bonds capped")
  ok(Util.count(r.teamPlan.types) <= TeamPlan.TYPE_LIMIT, r.id .. ": type credit capped")
  ok(#r.memory.events <= 40, r.id .. ": memory capped")
  ok(Util.count(r:ensureLeague().walls) <= League.MAX_STAGE, r.id .. ": League walls capped")
  ok(Util.count(r:ensureLedger().spent) == #Economy.CATEGORIES,
     r.id .. ": the ledger row set is exactly the categories")
  ok(#r.party <= 6, r.id .. ": never fielded an illegal party")
  if r.champion then champions = champions + 1 end
end
ok(#presence.log <= Presence.LOG_LIMIT, "the sighting log stayed capped")

print(("\n%d passed, %d failed"):format(pass, fail))
os.exit(fail == 0 and 0 or 1)
