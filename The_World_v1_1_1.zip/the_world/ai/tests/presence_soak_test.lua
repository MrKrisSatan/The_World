-- Standalone: lua5.1 tests/presence_soak_test.lua  (from mods/ai_rivals)
--
-- The sighting budget, measured against a worst case rather than an average.
--
-- The failure mode is not a crash. It is a player who reads "You spotted
-- Chris" for the fifth time in two minutes and stops reading the news ticker
-- at all -- taking the relationship, team and story reporting from 1.33-1.35
-- down with it, because they all share that channel.
--
-- So this simulates the WORST case for the budget: all four rivals parked on
-- the player's map for ten hours, the observer asked on every single tick.

local cache = {}
local function req(n)
  if cache[n] then return cache[n] end
  local f = assert(loadfile(n .. ".lua")); cache[n] = f(req, {}); return cache[n]
end
local Util, Presence, Rival = req("src/Util"), req("src/Presence"), req("src/Rival")
local PERS, ROSTER = req("data/personalities"), req("data/rivals")

local pass, fail = 0, 0
local function ok(c, m) if c then pass = pass + 1 else fail = fail + 1; print("FAIL " .. m) end end

local TICKS = 24000

-- Worst case: everyone visible, always, and the observer asked every tick.
-- The manager asks in LEAST-RECENTLY-SEEN order, not roster order, because at
-- most one rival is noticed per tick and a fixed order starves whoever comes
-- last. The soak reproduces that ordering so it is testing what ships.
local state = Presence.new()
local sightings, perRival = 0, {}
local function askOrder(tick)
  local order = {}
  for _, def in ipairs(ROSTER) do order[#order + 1] = def end
  table.sort(order, function(a, b)
    local ta = state.byRival[a.id] or -1
    local tb = state.byRival[b.id] or -1
    if ta ~= tb then return ta < tb end
    return tostring(a.id) < tostring(b.id)
  end)
  return order
end
for tick = 1, TICKS do
  for i, def in ipairs(askOrder(tick)) do
    local s = Presence.observe(state, {
      id = def.id, name = def.name or def.id, map = "CERULEAN_CITY",
      mapLabel = "Cerulean City", state = "TRAVELLING", objective = "EXPLORE",
      sameMap = true, travelling = true,
    }, tick)
    if s then
      sightings = sightings + 1
      perRival[def.id] = (perRival[def.id] or 0) + 1
    end
  end
end
local perHour = sightings / (TICKS / 2400)
print(("worst case: %d sightings over %d ticks (~%.1f per hour of play)")
  :format(sightings, TICKS, perHour))
ok(sightings > 0, "sightings do happen when rivals are visible")
ok(perHour <= 30, "the worst case stays under thirty sightings an hour")
ok(#state.log <= Presence.LOG_LIMIT, "the log stays capped through the worst case")
ok(Util.count(state.byRival) == #ROSTER,
   "every rival gets noticed at least once -- no starvation by roster order")
-- and no single rival may dominate the channel
local most = 0
for _, n in pairs(perRival) do most = math.max(most, n) end
ok(most <= sightings * 0.6, "no single rival dominates the sighting channel")

-- Realistic case: rivals wander, so they are usually somewhere else.
local real = Presence.new()
local realSightings = 0
for tick = 1, TICKS do
  for i, def in ipairs(ROSTER) do
    local here = ((tick + i * 700) % 3000) < 400   -- ~13% of the time
    if here then
      if Presence.observe(real, { id = def.id, name = def.name or def.id,
        map = "ROUTE_4", mapLabel = "Route 4", state = "TRAVELLING",
        objective = "EXPLORE", sameMap = true, travelling = true }, tick) then
        realSightings = realSightings + 1
      end
    end
  end
end
print(("realistic: %d sightings over %d ticks (~%.1f per hour)")
  :format(realSightings, TICKS, realSightings / (TICKS / 2400)))
ok(realSightings > 4, "a wandering world still produces sightings")
ok(realSightings < sightings, "and fewer than the worst case")

-- NAVIGATION MEMORY (§15): familiarity must be bounded and must never open a
-- route. The gate check lives in Rival:canEnterMap, which this does not touch;
-- what is asserted here is that a long game cannot grow an unbounded atlas.
local ctx = { data = { pokemon = {}, constants = {} }, personalities = PERS,
              graph = { has = function() return false end },
              gyms = { order = {}, byBadge = {} } }
local r = Rival.new(ROSTER[1], ctx)
for i = 1, 500 do r:visitMap("MAP_" .. (i % 200)) end
ok(Util.count(r.visitedMaps) <= Rival.NAV_LIMIT, "navigation memory is capped in size")
for _, seen in pairs(r.visitedMaps) do
  ok(seen <= Rival.NAV_MAX, "no single map's familiarity exceeds the cap")
  break
end
for i = 1, 50 do r:visitMap("HOME") end
ok(r:familiarity("HOME") == 1, "a well-walked map reaches full familiarity")
ok(r:familiarity("NEVER_BEEN") == 0, "unseen ground is unfamiliar")
ok(r:knowsRoute("HOME"), "a well-walked map is known")
ok(not r:knowsRoute("NEVER_BEEN"), "unseen ground is not known")
ok(r:navKnownCount() >= 1, "the rival reports how much of Kanto it has learned")
-- and it survives save/load
local blob = r:serialize()
local reloaded = Rival.new(ROSTER[1], ctx)
ok(reloaded:restore(blob), "a rival with navigation memory restores")
ok(reloaded:familiarity("HOME") == 1, "familiarity survives save/load")
ok(Util.count(reloaded.visitedMaps) <= Rival.NAV_LIMIT,
   "the restored atlas is still capped")

print(("\n%d passed, %d failed"):format(pass, fail))
os.exit(fail == 0 and 0 or 1)
