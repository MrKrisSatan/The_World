from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
rv=(ROOT/"src/Rival.lua").read_text()
manifest=(ROOT/"manifest.json").read_text()
assert "local starterBase = {}" in rv
assert "wxBaseSpecies" in rv
assert "starterBase[tostring(baseSpecies):upper()] = true" in rv
assert "if wxBaseSpecies(species)" in rv
assert '"version": "7.2.1"' in manifest
print("7.2.1 WX starter scope checks passed")
