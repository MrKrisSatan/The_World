from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
rd=(ROOT/"src/RocketDisguise.lua").read_text()
st=(ROOT/"src/StaticRivals.lua").read_text()
manifest=(ROOT/"manifest.json").read_text()

# Gold disguise source.
assert 'maps.TEAM_ROCKET_BASE_B1F' in rd
assert 'item=="X_ACCURACY"' in rd
assert 'obj.x==21 and obj.y==12' in rd
assert 'target.itemball.item=self.UNIFORM' in rd
assert 'if Version.detect(data)=="gen2" then return false end' in rd
assert 'self:syncOwnedFromInventory()' in rd
assert '"MAHOGANY_HIDEOUT"' in rd

# Native grass placement.
assert "local function grassCell(manager,def,x,y)" in st
assert "Permissions.isGrass(tile)==true" in st
assert "ts.grassTile~=nil and tile==ts.grassTile" in st
assert 'if rival.state=="TRAINING" then return true end' in st
assert 'local pos=positions(manager,def,rivals)' in st
assert 'r.staticInGrass=c.grass==true' in st

assert '"version": "7.4.3"' in manifest
print("7.4.3 hideout/grass checks passed")
