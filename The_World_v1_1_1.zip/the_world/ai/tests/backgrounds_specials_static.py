import re, json, zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]

def read(path):
    return (ROOT / path).read_text(encoding="utf-8")

def test_background_count():
    text = read("data/backgrounds.lua")
    ids = re.findall(r'id\s*=\s*"BG_(\d+)"', text)
    assert len(ids) == 250
    assert sorted(set(ids)) == [f"{i:03d}" for i in range(1, 251)]

def test_special_roster():
    text = read("src/Specials.lua")
    for name, title in [("Guts","Black Angel"),("Casca",""),("Griffith","White Hawk")]:
        assert f'name = "{name}"' in text
        if title:
            assert f'forcedTitle = "{title}"' in text
    assert "rareChance" in text
    assert "MEWTWO_VOID" in text
    assert "DRATINI_SNOWCOIL" in text
    assert "MEW_PRIMALWEATHER" in text

def test_special_personalities():
    text = read("data/personalities.lua")
    for key in ("BLACK_ANGEL","HAWKSWORD","WHITE_HAWK"):
        assert f"  {key} = {{" in text

def test_background_integration():
    rival = read("src/Rival.lua")
    rocket = read("src/Rocket.lua")
    life = read("src/LifePath.lua")
    assert 'req("src/Backgrounds")' in rival
    assert "Backgrounds.startingInventory(background)" in rival
    assert "backgroundPathBias" in rival
    assert 'req("src/Backgrounds")' in rocket
    assert "backgroundProfile" in rocket
    assert "backgroundPathBias" in life
    persistence = read("src/manager/Persistence.lua")
    assert "out.specials = {}" in persistence
    assert "out.rivalCount = math.max(1, #self.rivals - #out.specials)" in persistence

def test_version():
    manifest=json.loads(read("manifest.json"))
    assert manifest["version"]=="5.0.1"
