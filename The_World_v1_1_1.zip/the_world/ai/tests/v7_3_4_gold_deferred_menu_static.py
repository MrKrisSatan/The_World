from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
main=(ROOT/"main.lua").read_text()
manifest=(ROOT/"manifest.json").read_text()

assert "if game.world and game.world.map then" in main
assert "return game.world" in main
assert "if ow.textbox or ow.choicebox then return false end" in main
assert "ow.transitioning or ow.mapSetup" in main
assert "M.pendingRivalMenu" in main
assert "M:openRivalMenu(rival)" in main
assert '"version": "7.3.4"' in manifest
print("7.3.4 Gold deferred-menu checks passed")
