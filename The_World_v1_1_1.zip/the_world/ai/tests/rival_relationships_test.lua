-- Standalone: lua5.1 tests/rival_relationships_test.lua  (from mods/ai_rivals)
--
-- Four REAL Rival objects from data/rivals.lua, exercising the relationship
-- methods, directionality, privacy between uninvolved rivals, the save/load
-- round trip and the pre-1.33 migration path.
local cache = {}
local function req(name)
  if cache[name] then return cache[name] end
  local f = assert(loadfile(name .. ".lua"))
  cache[name] = f(req, {})
  return cache[name]
end
local Util = req("src/Util")
local Rival = req("src/Rival")
local R = req("src/Relationships")
local PERS = req("data/personalities")
local ROSTER = req("data/rivals")

local pass, fail = 0, 0
local function eq(a,b,m) if a==b then pass=pass+1 else fail=fail+1
  print(("FAIL %s (got %s want %s)"):format(m,tostring(a),tostring(b))) end end
local function ok(c,m) if c then pass=pass+1 else fail=fail+1; print("FAIL "..m) end end

local ctx = { data = { pokemon = {}, constants = {} }, personalities = PERS,
              graph = { has = function() return false end }, gyms = { order = {}, byBadge = {} },
              relationships = true }
local rivals, byId = {}, {}
for _, def in ipairs(ROSTER) do
  local r = Rival.new(def, ctx); r.ticks = 0
  rivals[#rivals+1] = r; byId[def.id] = r
end
ok(#rivals >= 4, "the roster constructs (" .. #rivals .. " rivals)")

-- Fresh rivals are neutral toward everyone -- EXCEPT declared family.
--
-- 4.7.0 made FAMILY a declared fact read off the roster rather than something
-- earned, so two rivals the roster calls siblings are family from tick zero.
-- That is the point of the state; asserting NEUTRAL there would be asserting
-- that the feature does not work. Both halves are checked, because "nothing
-- else starts as anything" is the part that was actually protecting the model.
local kinPairs = 0
for _, r in ipairs(rivals) do
  eq(r:relationshipTo("player"), "NEUTRAL", r.id .. " starts neutral toward the player")
  for _, o in ipairs(rivals) do
    if o.id ~= r.id then
      if r:isKinWith(o.id) then
        kinPairs = kinPairs + 1
        eq(r:relationshipTo(o.id), "FAMILY", r.id .. " starts as family to " .. o.id)
      else
        eq(r:relationshipTo(o.id), "NEUTRAL", r.id.." neutral toward "..o.id)
      end
    end
  end
end

-- a one-sided run of results between two rivals, recorded from each side
local chris, matt = byId.chris, byId.matt
for i = 1, 5 do
  chris.ticks, matt.ticks = i, i
  chris:recordRelationshipBattle(matt.id, true, { lead = 0 })
  matt:recordRelationshipBattle(chris.id, false, { lead = 0 })
end
ok(chris:relationshipTo(matt.id) ~= "NEUTRAL", "winning repeatedly is not neutral")
eq(matt:relationshipTo(chris.id), "RIVALRY", "the loser develops a rivalry")
ok(matt:bondWith(chris.id).losses == 5, "the loser's record is its own")
ok(chris:bondWith(matt.id).wins == 5, "the winner's record is its own")

-- relationships are DIRECTIONAL: B feeling hostile does not make A hostile
ok(chris:relationshipTo(matt.id) ~= matt:relationshipTo(chris.id),
   "the two sides of a bond are tracked independently")

-- and PRIVATE: nothing chris did touched larissa's view of anyone
eq(byId.larissa:relationshipTo(matt.id), "NEUTRAL", "an uninvolved rival is unaffected")
eq(byId.larissa:relationshipTo(chris.id), "NEUTRAL", "an uninvolved rival stays neutral")

-- behaviour actually changes: the loser is likelier to pick the fight
ok(matt:fightBiasToward(chris.id) > 1.0, "a rivalry raises the loser's fight odds")
ok(not matt:willCooperateWith(chris.id), "a rivalry blocks cooperation")

-- favours move it back, and cooperation becomes possible again
for i = 6, 9 do
  matt.ticks = i
  matt:recordRelationship(chris.id, "HELPED")
  matt:recordRelationship(chris.id, "REQUEST_DONE")
end
ok(matt:willCooperateWith(chris.id), "sustained favours restore cooperation")

-- save/load: the whole social graph survives serialize -> restore
local blobs = {}
for _, r in ipairs(rivals) do blobs[r.id] = r:serialize() end
local restored = {}
for _, def in ipairs(ROSTER) do
  local r = Rival.new(def, ctx)
  ok(r:restore(blobs[def.id]), def.id .. " restores")
  r.ticks = blobs[def.id].ticks or 9
  restored[def.id] = r
end
eq(restored.matt:relationshipTo(chris.id), matt:relationshipTo(chris.id),
   "a rival's relationship survives save/load")
eq(restored.matt:bondWith(chris.id).losses, 5, "head-to-head survives save/load")
eq(restored.chris:bondWith(matt.id).wins, 5, "the other side survives save/load")
eq(restored.larissa:relationshipTo(chris.id), "NEUTRAL", "neutral bonds survive save/load")

-- a pre-1.33 save has no bonds key at all
local legacy = blobs.chris
legacy.bonds = nil
local migrated = Rival.new(ROSTER[1], ctx)
ok(migrated:restore(legacy), "a pre-1.33 save record still restores")
eq(migrated:relationshipTo("matt"), "NEUTRAL", "an old save migrates to neutral")
eq(migrated:relationshipTo("player"), "NEUTRAL", "an old save invents no player history")
eq(migrated.playerWins, legacy.playerWins, "1.32 fields are untouched by the migration")

-- the store cannot grow without bound however long the world runs
local hoarder = byId.dyanari
for i = 1, 200 do
  hoarder.ticks = i
  hoarder:recordRelationship("ghost_" .. i, "SNUBBED")
end
ok(Util.count(hoarder.bonds) <= R.BOND_LIMIT, "a rival's bond store stays capped")
local blob = hoarder:serialize()
ok(Util.count(blob.bonds) <= R.BOND_LIMIT, "the SAVED bond store stays capped")

print(("\n%d passed, %d failed"):format(pass, fail))
os.exit(fail == 0 and 0 or 1)
