-- Standalone: lua5.1 tests/lifepath_test.lua   (from mods/ai_rivals)
--
-- The 2.1.0 life-path foundation. Three properties matter more than the rest:
--
--   1. ELIGIBILITY IS UNREROLLABLE (§32, §33). The same seed must give the
--      same answer forever. A player who reloads must not find that Green was
--      a breeder five seconds ago and is now Team Rocket.
--   2. THE DISTRIBUTION IS RIGHT (§3). Most saves have nobody diverging, some
--      have one, two is rare, and all four is impossible.
--   3. PRESSURE IS EARNED, NOT ROLLED (§2). A rival that is winning is under
--      no pressure to stop, whatever else is true of it.

local cache = {}
local function req(n)
  if cache[n] then return cache[n] end
  local f = assert(loadfile(n .. ".lua")); cache[n] = f(req, {}); return cache[n]
end
local Util, LifePath = req("src/Util"), req("src/LifePath")

local pass, fail = 0, 0
local function eq(a, b, m) if a == b then pass = pass + 1 else fail = fail + 1
  print(("FAIL %s (got %s want %s)"):format(m, tostring(a), tostring(b))) end end
local function ok(c, m) if c then pass = pass + 1 else fail = fail + 1; print("FAIL " .. m) end end

local IDS = { "chris", "dyanari", "matt", "larissa" }

-- 1. DETERMINISM. Everything about eligibility is a pure function of the seed.
for _, seed in ipairs({ 0, 1, 12345, 999999999, 4294967295 }) do
  eq(LifePath.roll(seed, "x"), LifePath.roll(seed, "x"), "rolls are pure: " .. seed)
  eq(LifePath.divergentCount(seed), LifePath.divergentCount(seed),
     "the divergent count is pure: " .. seed)
  local a = table.concat(LifePath.eligibleRivals(seed, IDS), ",")
  local b = table.concat(LifePath.eligibleRivals(seed, IDS), ",")
  eq(a, b, "eligibility is pure: " .. seed)
  -- ...and independent of the order the roster happens to be in
  local shuffled = { "larissa", "chris", "matt", "dyanari" }
  eq(table.concat(LifePath.eligibleRivals(seed, shuffled), ","), a,
     "eligibility does not depend on roster order: " .. seed)
end
ok(LifePath.roll(1, "x") ~= LifePath.roll(2, "x"), "different seeds differ")
ok(LifePath.roll(1, "x") ~= LifePath.roll(1, "y"), "different keys differ")
for _, seed in ipairs({ 0, 7, 4242, 987654321 }) do
  local r = LifePath.roll(seed, "k")
  ok(r >= 0 and r < 1, "a roll is in range: " .. seed)
end

-- 2. THE DISTRIBUTION (§3), measured over many saves.
local counts = { [0] = 0, [1] = 0, [2] = 0 }
local SAVES = 20000
for seed = 1, SAVES do
  local n = LifePath.divergentCount(seed)
  ok(n >= 0 and n <= 2, "the count is always 0, 1 or 2")
  counts[n] = counts[n] + 1
end
local pctNone = counts[0] / SAVES * 100
local pctOne = counts[1] / SAVES * 100
local pctTwo = counts[2] / SAVES * 100
print(("over %d saves: none %.1f%%  one %.1f%%  two %.1f%%")
  :format(SAVES, pctNone, pctOne, pctTwo))
ok(math.abs(pctNone - 85) < 3, "~85% of saves have nobody diverging")
ok(math.abs(pctOne - 12) < 3, "~12% have exactly one")
ok(math.abs(pctTwo - 3) < 2, "~3% have two")
ok(pctTwo < pctOne / 2, "two is substantially rarer than one")

-- NEVER ALL FOUR (§3), whatever the configuration says.
local greedy = { none = 0, one = 0, two = 1 }
for seed = 1, 500 do
  local eligible = LifePath.eligibleRivals(seed, IDS, greedy)
  ok(#eligible < #IDS, "never every rival: seed " .. seed)
end
-- and with a tiny roster the cap still holds
eq(#LifePath.eligibleRivals(1, { "solo" }, greedy), 0,
   "a lone rival can never be the one that leaves")
eq(#LifePath.eligibleRivals(1, {}, greedy), 0, "an empty roster is safe")
-- eligibility is spread across the roster rather than always the same rival
local chosen = {}
for seed = 1, 3000 do
  for _, id in ipairs(LifePath.eligibleRivals(seed, IDS)) do
    chosen[id] = (chosen[id] or 0) + 1
  end
end
eq(Util.count(chosen), #IDS, "every rival is eligible in SOME save")
local lo, hi = math.huge, 0
for _, n in pairs(chosen) do lo, hi = math.min(lo, n), math.max(hi, n) end
ok(hi < lo * 2.5, "and no rival is disproportionately singled out")

-- 3. PRESSURE IS EARNED (§2).
local function facts(over)
  local f = { catchChance = 0.2, challengeChance = 0.4, wanderChance = 0.1,
    badges = 2, collection = 8, seen = 20, money = 3000, confidence = 1,
    champion = false, playerLosses = 0, leagueFailures = 0, gymFailures = 0,
    badgeDrought = 0, ghostAffinity = 0, mapsKnown = 5, teamStyle = "BALANCED",
    hostileToPlayer = false }
  for k, v in pairs(over or {}) do f[k] = v end
  return f
end
local calm = LifePath.pressure(facts())
ok(calm < LifePath.PRESSURE_NOTICED, "a rival getting on with it is under no pressure")
local beaten = LifePath.pressure(facts({ leagueFailures = 6, gymFailures = 9,
  playerLosses = 14, badgeDrought = 9000, confidence = 0.6 }))
ok(beaten > LifePath.PRESSURE_CONSIDER, "a rival that keeps failing is under real pressure")
ok(beaten > calm, "and more than one that is not")
-- winning insulates
local winning = LifePath.pressure(facts({ leagueFailures = 6, gymFailures = 9,
  playerLosses = 14, badgeDrought = 9000, confidence = 0.6, badges = 8 }))
ok(winning < beaten, "eight badges blunt the same pressure")
eq(LifePath.pressure(facts({ champion = true, leagueFailures = 9,
  playerLosses = 40 })), 0, "a champion is under NO pressure to give up")
-- bounds
for _, extreme in ipairs({ facts({ leagueFailures = 9e9, playerLosses = 9e9,
  gymFailures = 9e9, badgeDrought = 9e9, collection = 9e9 }), facts({}),
  facts({ confidence = -5, badges = -3 }) }) do
  local p = LifePath.pressure(extreme)
  ok(p >= 0 and p <= 1, "pressure stays in range under extreme facts")
end
eq(LifePath.pressure(nil), 0, "no facts is no pressure")

-- 4. THE STATE MACHINE (§5).
eq(LifePath.stage(0.1, false), "GYM_CHALLENGE", "low pressure is business as usual")
eq(LifePath.stage(0.45, false), "PRESSURE", "some pressure is noticed")
eq(LifePath.stage(0.7, false), "CONSIDERING", "more is actively questioning it")
eq(LifePath.stage(0.9, false), "TRANSITIONING", "enough is ready to leave")
eq(LifePath.stage(0.1, true), "ACTIVE", "a committed rival is ACTIVE whatever the pressure")
for _, s in ipairs(LifePath.STAGES) do ok(LifePath.isStage(s), s .. " is a legal stage") end

-- 5. COMPATIBILITY (§4): weighted, never exclusive.
local collector = facts({ catchChance = 0.9, collection = 55, seen = 90 })
local ranked = LifePath.rankPaths(collector, 3)
local top = {}
for _, e in ipairs(ranked) do top[e.path] = true end
ok(top.BREEDER or top.RESEARCHER or top.OAK_ASSISTANT,
   "a collector's likeliest lives are collection-shaped")
local scores = LifePath.compatibility(collector)
for _, path in ipairs(LifePath.PATHS) do
  ok((scores[path] or 0) > 0,
     "§4: " .. path .. " keeps a floor, so unexpected outcomes stay possible")
end
local total = 0
for _, v in pairs(scores) do total = total + v end
ok(math.abs(total - 1) < 1e-9, "compatibility is normalised")
-- Team Rocket needs more than a mean streak
local meanOnly = LifePath.compatibility(facts({ challengeChance = 1 }))
local meanAndWronged = LifePath.compatibility(facts({ challengeChance = 1,
  hostileToPlayer = true, money = 100, leagueFailures = 5 }))
ok(meanAndWronged.TEAM_ROCKET > meanOnly.TEAM_ROCKET * 1.5,
   "§17: Rocket wants grievance and hardship, not just a ruthless streak")
-- deterministic ordering
eq(LifePath.rankPaths(collector, 3)[1].path, LifePath.rankPaths(collector, 3)[1].path,
   "the ranking is deterministic")

-- 6. COMMITMENT IS LOCKED (§33).
local record = LifePath.newRecord()
eq(record.path, LifePath.GYM_CHALLENGE, "a new rival is on the Gym Challenge")
eq(record.locked, false, "and is not locked")
ok(LifePath.onGymChallenge(record), "and reports as such")
ok(LifePath.commit(record, "BREEDER", 100, "pressure"), "a divergence commits")
eq(record.path, "BREEDER", "and takes effect")
eq(record.previous, LifePath.GYM_CHALLENGE, "remembering what it was")
eq(record.locked, true, "and locks")
ok(not LifePath.onGymChallenge(record), "it is no longer on the Gym Challenge")
eq(LifePath.commit(record, "TEAM_ROCKET", 200), false,
   "a locked record REFUSES a second commitment -- no save-scumming into a better life")
eq(record.path, "BREEDER", "and is unchanged by the attempt")
eq(LifePath.commit(LifePath.newRecord(), "NOT_A_PATH", 1), false,
   "an unknown path is refused")
eq(LifePath.commit(LifePath.newRecord(), LifePath.GYM_CHALLENGE, 1), false,
   "committing to the Gym Challenge is not a divergence")

-- a stored path other than GYM_CHALLENGE is locked by definition, so a
-- tampered save cannot present an active career as still re-decidable
local tampered = LifePath.newRecord({ path = "TEAM_ROCKET", locked = false })
eq(tampered.locked, true, "an active career loads locked whatever the flag said")

-- 7. Bounds and corruption.
local busy = LifePath.newRecord()
for i = 1, 50 do
  busy.locked = false
  LifePath.commit(busy, LifePath.PATHS[(i % #LifePath.PATHS) + 1], i, "debug")
end
ok(#busy.history <= LifePath.HISTORY_LIMIT, "the history is bounded")
local dirty = LifePath.newRecord({ path = "MAYOR", previous = 7, careerLevel = 99,
  progress = -5, since = -1, history = { { path = "NOPE" }, "junk",
  { path = "BREEDER", tick = -9, reason = string.rep("x", 200) } } })
eq(dirty.path, LifePath.GYM_CHALLENGE, "an unknown stored path is repaired")
eq(dirty.previous, nil, "a corrupt previous path is dropped")
ok(dirty.careerLevel <= 4, "career level is clamped")
eq(dirty.progress, 0, "negative progress is repaired")
eq(#dirty.history, 1, "malformed history entries are dropped")
ok(#dirty.history[1].reason <= 40, "an over-long reason is truncated")
local round = LifePath.newRecord(LifePath.serializeRecord(busy))
eq(round.path, busy.path, "the record survives a round trip")
eq(#round.history, #busy.history, "as does its history")

-- 8. Presentation (§22, §23).
ok(LifePath.headline("Green", "TEAM_ROCKET"):find("Team Rocket"),
   "a divergence produces a headline")
eq(LifePath.headline("Green", LifePath.GYM_CHALLENGE), nil,
   "staying the course is not news")
for _, path in ipairs(LifePath.PATHS) do
  ok(type(LifePath.headline("X", path)) == "string", path .. " has a headline")
  ok(type(LifePath.label(path)) == "string", path .. " has a label")
  ok(not LifePath.headline("X", path):find("_"),
     "§22: " .. path .. "'s headline exposes no internal identifier")
end

-- ------------------------------------------------------------------
-- 9. TRANSITIONS (2.4.0 -- §19, §28, §29)
-- ------------------------------------------------------------------
-- The tension: §33 locks a committed path, §19 lets a Rocket rival defect and
-- §28 lets a career end in a return. The lock exists to stop a player
-- RE-ROLLING a destiny, not to stop a character's story continuing -- so a
-- transition is a separate operation along a DECLARED edge with earned
-- prerequisites, and `commit` still refuses outright.
do
  local rocket = LifePath.newRecord()
  ok(LifePath.commit(rocket, "TEAM_ROCKET", 100, "pressure"), "a rival joins Rocket")
  eq(LifePath.commit(rocket, "BREEDER", 200), false,
     "commit STILL refuses -- there is no path back to 'pick again'")

  -- tenure must be served
  eq(LifePath.mayTransition(rocket, 100 + LifePath.TRANSITION_TENURE - 1), false,
     "nobody defects the afternoon they join")
  ok(LifePath.mayTransition(rocket, 100 + LifePath.TRANSITION_TENURE),
     "but may once they have lived the life a while")

  -- only declared edges
  eq(LifePath.transition(rocket, "MART_WORKER", 9000), nil,
     "a transition to an undeclared destination is refused")
  eq(rocket.path, "TEAM_ROCKET", "and changes nothing")
  local landed = LifePath.transition(rocket, "RESEARCHER", 9000)
  eq(landed, "RESEARCHER", "a declared edge is allowed")
  eq(rocket.path, "RESEARCHER", "and takes effect")
  eq(rocket.previous, "TEAM_ROCKET", "remembering what it left")
  eq(rocket.locked, true,
     "and the new life is no more re-decidable than the old one")
  ok(LifePath.isRedeemed(rocket), "the rival reads as a former Rocket")
  eq(LifePath.isRedeemed(LifePath.newRecord()), false,
     "an ordinary rival does not")

  -- §28: a career can end in a return, and a returning rival is marked
  local career = LifePath.newRecord()
  LifePath.commit(career, "EXPLORER", 10, "pressure")
  eq(LifePath.hasReturned(career), false, "an active career has not returned")
  eq(LifePath.transition(career, "TEAM_ROCKET", 9000), nil,
     "a career cannot transition INTO Team Rocket -- that is a commitment, "
     .. "and it has already spent its one divergence")
  eq(LifePath.transition(career, LifePath.GYM_CHALLENGE, 9000),
     LifePath.GYM_CHALLENGE, "but may return to the Gym Challenge")
  ok(LifePath.hasReturned(career), "and reads as a returning trainer")
  eq(career.locked, true,
     "§33 holds across the whole arc: a returned rival cannot diverge again")
  eq(LifePath.transition(career, "BREEDER", 20000), nil,
     "and has no further edges to walk")
  eq(career.careerLevel, 0, "a returned rival carries no career rank")

  -- every declared edge names only real paths
  for from, edge in pairs(LifePath.TRANSITIONS) do
    ok(LifePath.isPath(from), "transition source " .. from .. " is a real path")
    ok(type(edge.to) == "table" and #edge.to > 0, from .. " has destinations")
    for _, to in ipairs(edge.to) do
      ok(LifePath.isPath(to), from .. " -> " .. to .. " is a real path")
      ok(to ~= "TEAM_ROCKET" or from == "TEAM_ROCKET",
         "§17: nothing transitions INTO Team Rocket; it must be committed to")
      ok(to ~= from, from .. " does not transition to itself")
    end
  end

  -- §19: doubt is derived and redemption is NOT guaranteed
  local function facts(over)
    local f = { playerLosses = 0, confidence = 1, careerLevel = 1,
                careerFailures = 0, warmToPlayer = false }
    for k, v in pairs(over or {}) do f[k] = v end
    return f
  end
  ok(LifePath.doubt("TEAM_ROCKET", facts()) < LifePath.TRANSITION_PRESSURE,
     "a Rocket rival doing fine has no doubt")
  ok(LifePath.doubt("TEAM_ROCKET", facts({ playerLosses = 10,
     warmToPlayer = true, careerFailures = 5, confidence = 0.6 }))
     >= LifePath.TRANSITION_PRESSURE,
     "§19: repeated defeat, a warming relationship and failed work produce doubt")
  ok(LifePath.doubt("EXPLORER", facts({ careerLevel = 1 }))
     < LifePath.TRANSITION_PRESSURE,
     "a career just begun has no reason to end")
  ok(LifePath.doubt("EXPLORER", facts({ careerLevel = 4, confidence = 1.8 }))
     >= LifePath.TRANSITION_PRESSURE,
     "§28: a mastered career and a rediscovered competitive spirit do")
  eq(LifePath.doubt("EXPLORER", nil), 0, "no facts is no doubt")
  eq(LifePath.doubt(LifePath.GYM_CHALLENGE, facts()), 0,
     "a rival on the ladder has nothing to doubt")

  -- history stays bounded across a whole arc
  local long = LifePath.newRecord()
  LifePath.commit(long, "TEAM_ROCKET", 1, "x")
  for i = 1, 40 do
    LifePath.transition(long, "RESEARCHER", i)
    long.path = "TEAM_ROCKET"
  end
  ok(#long.history <= LifePath.HISTORY_LIMIT, "arc history stays bounded")

  -- headlines
  ok(LifePath.transitionHeadline("Green", "TEAM_ROCKET", LifePath.GYM_CHALLENGE),
     "leaving Rocket for the ladder is news")
  ok(LifePath.transitionHeadline("Green", "EXPLORER", LifePath.GYM_CHALLENGE),
     "a return is news")
  for from, edge in pairs(LifePath.TRANSITIONS) do
    for _, to in ipairs(edge.to) do
      local head = LifePath.transitionHeadline("X", from, to)
      if head then
        ok(not head:find("_"), from .. "->" .. to .. " exposes no identifier")
      end
    end
  end
end

print(("\n%d passed, %d failed"):format(pass, fail))
os.exit(fail == 0 and 0 or 1)
