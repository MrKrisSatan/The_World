-- Standalone: lua5.1 tests/version_matrix_test.lua   (from mods/ai_rivals)
--
-- "MAKE SURE THE AI RIVALS SPAWN IN RED, BLUE, YELLOW AND GOLD."
--
-- That claim has been asserted in documentation since 1.1 and never MEASURED.
-- This suite builds a synthetic dataset shaped like each of the four boots and
-- checks, for every rival, the whole chain a spawn actually depends on:
--
--   1. the version is detected from the DATA, not a version string;
--   2. the starter set resolves to a species that boot really has;
--   3. the walker sprite resolves to a sprite that boot really has;
--   4. nothing in the chain returns an id the dataset does not carry, because
--      a spawn with an unknown sprite fails rather than degrading.
--
-- Red and Blue are checked separately even though the mod does not distinguish
-- them: the point is that both really do work, not that they share a code path.

local cache = {}
local function req(n)
  if cache[n] then return cache[n] end
  local f = assert(loadfile(n .. ".lua")); cache[n] = f(req, {}); return cache[n]
end
local Util, Version = req("src/Util"), req("src/Version")
local Rival = req("src/Rival")
local ROSTER, PERS = req("data/rivals"), req("data/personalities")

local pass, fail = 0, 0
local function eq(a, b, m) if a == b then pass = pass + 1 else fail = fail + 1
  print(("FAIL %s (got %s want %s)"):format(m, tostring(a), tostring(b))) end end
local function ok(c, m) if c then pass = pass + 1 else fail = fail + 1; print("FAIL " .. m) end end

-- ------------------------------------------------------------------
-- The four boots
-- ------------------------------------------------------------------
local function sprites(list)
  local out = {}
  for _, id in ipairs(list) do out[id] = { image = id:lower() .. ".png" } end
  return out
end
-- NOTE: build lists by concatenation, never `{a, unpack(x), unpack(y)}` --
-- in a Lua table constructor only the LAST unpack expands, and the earlier
-- ones are truncated to a single value. The first draft of this fixture did
-- exactly that and silently gave Gold no Cyndaquil or Totodile, which looked
-- like a mod bug and was not.
local function join(...)
  local out = {}
  for _, list in ipairs({ ... }) do
    for _, id in ipairs(list) do out[#out + 1] = id end
  end
  return out
end

local function species(list)
  local out = {}
  for _, id in ipairs(list) do
    out[id] = { baseStats = { hp = 45, attack = 49, defense = 49,
      speed = 45, special = 65 }, types = { "NORMAL" },
      level1Moves = { "TACKLE" }, learnset = {} }
  end
  return out
end

-- Gen 1 overworld sprite ids, as build_rom_data.py emits them.
local GEN1_SPRITES = { "SPRITE_RED", "SPRITE_BLUE", "SPRITE_OAK", "SPRITE_GIRL",
  "SPRITE_LASS", "SPRITE_YOUNGSTER", "SPRITE_SUPER_NERD", "SPRITE_BUG_CATCHER",
  "SPRITE_COOLTRAINER_M", "SPRITE_COOLTRAINER_F", "SPRITE_ROCKER" }
-- Gold's ids overlap only partly, and it has no SPRITE_BLUE or SPRITE_RED.
local GEN2_SPRITES = { "SPRITE_CHRIS", "SPRITE_KRIS", "SPRITE_LASS",
  "SPRITE_YOUNGSTER", "SPRITE_COOLTRAINER_M", "SPRITE_COOLTRAINER_F",
  "SPRITE_SUPER_NERD", "SPRITE_BUG_CATCHER" }

local KANTO_TRIO = { "BULBASAUR", "CHARMANDER", "SQUIRTLE" }
local JOHTO_TRIO = { "CHIKORITA", "CYNDAQUIL", "TOTODILE" }

local BOOTS = {
  {
    name = "RED", expect = "gen1", starterKey = "default",
    data = { sprites = sprites(GEN1_SPRITES),
             pokemon = species(join({ "PIKACHU", "EEVEE", "CLEFAIRY" }, KANTO_TRIO)),
             moves = { TACKLE = { power = 40, type = "NORMAL" } },
             constants = { fallbackMove = "TACKLE" }, type_chart = { matchups = {} },
             maps = { PALLET_TOWN = {}, ROUTE_1 = {} } },
  },
  {
    name = "BLUE", expect = "gen1", starterKey = "default",
    data = { sprites = sprites(GEN1_SPRITES),
             pokemon = species(join({ "PIKACHU", "CLEFAIRY" }, KANTO_TRIO)),
             moves = { TACKLE = { power = 40, type = "NORMAL" } },
             constants = { fallbackMove = "TACKLE" }, type_chart = { matchups = {} },
             maps = { PALLET_TOWN = {}, ROUTE_1 = {} } },
  },
  {
    -- Yellow: the surfing Pikachu sheet AND a Pikachu. Red/Blue have a
    -- Pikachu too, which is exactly why one witness is not enough.
    name = "YELLOW", expect = "yellow", starterKey = "yellow",
    data = { sprites = sprites(join({ "SPRITE_SURFING_PIKACHU", "SPRITE_PIKACHU" }, GEN1_SPRITES)),
             pokemon = species(join({ "PIKACHU", "EEVEE", "CLEFAIRY" }, KANTO_TRIO)),
             moves = { TACKLE = { power = 40, type = "NORMAL" } },
             constants = { fallbackMove = "TACKLE" }, type_chart = { matchups = {} },
             maps = { PALLET_TOWN = {}, ROUTE_1 = {} } },
  },
  {
    -- 3.4.0: Gold's overworld sprites live in `gen2Sprites`, NOT `sprites`
    -- (src/world/gen2/World.lua:734). The old fixture put them under
    -- `sprites`, which is why it happily proved a spawn chain that could not
    -- work on a real Gold boot -- a fixture that is kinder than the engine
    -- proves nothing.
    name = "GOLD", expect = "gen2", starterKey = "gen2",
    data = { gen2Sprites = sprites(GEN2_SPRITES),
             pokemon = species(join({ "PIKACHU", "CLEFAIRY" }, JOHTO_TRIO, KANTO_TRIO)),
             moves = { TACKLE = { power = 40, type = "NORMAL" } },
             constants = { fallbackMove = "TACKLE" }, type_chart = { matchups = {} },
             gen2Maps = { NEW_BARK_TOWN = {}, ROUTE_29 = {} },
             gen2Trainers = {},
             maps = { NEW_BARK_TOWN = {}, ROUTE_29 = {} } },
  },
}

-- ------------------------------------------------------------------
-- 1. Detection is from the DATA
-- ------------------------------------------------------------------
for _, boot in ipairs(BOOTS) do
  eq(Version.detect(boot.data), boot.expect, boot.name .. " is detected")
  eq(Version.starterKey(boot.data), boot.starterKey,
     boot.name .. " uses the right starter set")
end
-- a boot carrying a surfing sheet but no Pikachu at all is NOT Yellow
eq(Version.detect({ sprites = sprites({ "SPRITE_SURFING_PIKACHU" }) }), "gen1",
   "one witness alone does not make a boot Yellow")
eq(Version.detect(nil), "gen1", "no data falls through to the default arm")
eq(Version.detect({}), "gen1", "an empty dataset falls through too")
-- gen2 wins over everything, because Gold really can carry a Pikachu
eq(Version.detect({ gen2Maps = {}, sprites = sprites({ "SPRITE_SURFING_PIKACHU",
   "SPRITE_PIKACHU" }) }), "gen2", "Gold is Gold even carrying Yellow's signals")

-- ------------------------------------------------------------------
-- 2. THE SPAWN CHAIN, per boot, per rival
-- ------------------------------------------------------------------
-- The sprite chain lives on the manager, so it is reproduced here exactly as
-- main.lua orders it: the per-rival preference list, then the shared safe
-- list, then any sprite with an image, sorted.
local RIVAL_SPRITE_PREFER = {
  chris   = { "SPRITE_BLUE", "SPRITE_COOLTRAINER_M", "SPRITE_RED" },
  dyanari = { "SPRITE_LASS", "SPRITE_COOLTRAINER_F", "SPRITE_BRUNETTE_GIRL", "SPRITE_GIRL" },
  matt    = { "SPRITE_SUPER_NERD", "SPRITE_BUG_CATCHER", "SPRITE_YOUNGSTER", "SPRITE_ROCKER" },
  larissa = { "SPRITE_COOLTRAINER_F", "SPRITE_BRUNETTE_GIRL", "SPRITE_LASS", "SPRITE_GIRL" },
}
local SAFE_SPRITES = { "SPRITE_BLUE", "SPRITE_RED", "SPRITE_OAK", "SPRITE_GIRL",
  "SPRITE_BUG_CATCHER", "SPRITE_LASS", "SPRITE_YOUNGSTER", "SPRITE_SUPER_NERD",
  "SPRITE_COOLTRAINER_M", "SPRITE_COOLTRAINER_F", "SPRITE_BRUNETTE_GIRL",
  "SPRITE_ROCKER" }

local function resolveSprite(data, rivalId)
  -- main.lua:M:spriteTable -- either generation's table.
  --
  -- Gold keeps its overworld sprites in `gen2Sprites`, not `sprites`, and a
  -- resolver that reads only the Gen 1 name finds NOTHING on Gold: the spawn
  -- then fails closed and the rival never appears while the menu still names
  -- its map. Reading only `data.sprites` here makes this function raise on the
  -- Gold fixture rather than report a clean failure, so the absence is named
  -- explicitly -- a suite that dies with "attempt to index nil" tells you far
  -- less than one that says which table is missing.
  local table_ = data.sprites or data.gen2Sprites
  if type(table_) ~= "table" then
    return nil, "no sprite table (neither data.sprites nor data.gen2Sprites)"
  end
  for _, id in ipairs(RIVAL_SPRITE_PREFER[rivalId] or {}) do
    if table_[id] then return id end
  end
  for _, id in ipairs(SAFE_SPRITES) do
    if table_[id] then return id end
  end
  local ids = {}
  for id, rec in pairs(table_) do
    if type(rec) == "table" and rec.image then ids[#ids + 1] = id end
  end
  table.sort(ids)
  return ids[1]
end

for _, boot in ipairs(BOOTS) do
  local key = Version.starterKey(boot.data)
  for _, def in ipairs(ROSTER) do
    -- (a) a sprite that this boot really carries
    local sprite = resolveSprite(boot.data, def.id)
    ok(sprite ~= nil, boot.name .. "/" .. def.id .. ": resolves a sprite")
    local spriteTable = boot.data.sprites or boot.data.gen2Sprites
    ok(spriteTable[sprite] ~= nil,
       boot.name .. "/" .. def.id .. ": the sprite EXISTS in this boot ("
       .. tostring(sprite) .. ")")

    -- (b) a starter DEALT from the pool that this boot really carries
    local starter = Rival.firstAvailableStarter(def, key, boot.data.pokemon, nil,
      { seed = 12345, roster = ROSTER })
    ok(starter ~= nil,
       boot.name .. "/" .. def.id .. ": is dealt a starter this boot has")
    ok(starter == nil or boot.data.pokemon[starter] ~= nil,
       boot.name .. "/" .. def.id .. ": the dealt starter EXISTS in this boot")

    -- (c) the rival constructs and can hold that starter
    local ctx = { data = boot.data, personalities = PERS,
                  graph = { has = function() return true end,
                            neighbours = function() return {} end },
                  gyms = { order = {}, byBadge = {} },
                  compat = { krAllows = function() return true end } }
    local rival = Rival.new(def, ctx)
    ok(rival ~= nil, boot.name .. "/" .. def.id .. ": constructs")
    rival.ticks = 0
    if starter then
      local slot = rival:addPokemon(starter, 5)
      ok(slot ~= nil, boot.name .. "/" .. def.id .. ": receives its starter")
    end
    -- (d) and it is on the Gym Challenge, in a legal state, on every boot
    ok(rival:onGymChallenge(), boot.name .. "/" .. def.id .. ": starts on the ladder")
    ok(rival:pursuesBadges(), boot.name .. "/" .. def.id .. ": chases badges")
  end
end

-- ------------------------------------------------------------------
-- 3. Yellow and Gold get DIFFERENT starters from Red/Blue
-- ------------------------------------------------------------------
local function startersFor(boot, seed)
  local key = Version.starterKey(boot.data)
  local out = {}
  for _, def in ipairs(ROSTER) do
    out[#out + 1] = tostring(Rival.firstAvailableStarter(def, key,
      boot.data.pokemon, nil, { seed = seed or 12345, roster = ROSTER }))
  end
  return table.concat(out, ",")
end
for _, boot in ipairs(BOOTS) do
  print(("  %-6s deal: %s"):format(boot.name, startersFor(boot)))
end

-- Gold's pool must contain the Johto trio and Gen 1's must not.
local gen1Pool, gen2Pool = ROSTER.pools.default, ROSTER.pools.gen2
local function poolHas(pool, id)
  for _, sp in ipairs(pool) do if sp == id then return true end end
  return false
end
for _, sp in ipairs({ "CHARMANDER", "BULBASAUR", "SQUIRTLE", "EEVEE",
                      "PIKACHU", "CLEFAIRY" }) do
  ok(poolHas(gen1Pool, sp), "the Gen 1 pool contains " .. sp)
  ok(poolHas(gen2Pool, sp), "and so does Gold's")
end
for _, sp in ipairs({ "CHIKORITA", "CYNDAQUIL", "TOTODILE" }) do
  ok(not poolHas(gen1Pool, sp), "the Gen 1 pool does NOT contain " .. sp)
  ok(poolHas(gen2Pool, sp), "but Gold's does")
end
eq(#gen1Pool, 6, "the Gen 1 pool is the six species specified")
eq(#gen2Pool, 9, "and Gold's is those six plus the Johto trio")
eq(table.concat(ROSTER.pools.yellow, ","), table.concat(gen1Pool, ","),
   "Yellow deals from the same pool as Red and Blue")

-- ------------------------------------------------------------------
-- 3a. GOLD'S SPRITE TABLE IS `gen2Sprites` (3.4.0)
--
-- The reported symptom: "I'm in New Bark Town, it says there is a rival there
-- in the menu but there isn't a rival there." The resolver read only
-- `data.sprites`, found nothing on Gold, returned nil, and the spawn refused
-- -- correctly, since 2.5 -- while the rival's `map` still said NEW_BARK_TOWN.
do
  local gold = BOOTS[4]
  eq(gold.name, "GOLD", "the fourth boot is Gold")
  eq(gold.data.sprites, nil,
     "the Gold fixture has NO data.sprites -- a fixture kinder than the engine "
     .. "proves nothing")
  ok(type(gold.data.gen2Sprites) == "table",
     "its sprites are under gen2Sprites, as the engine loads them")
  for _, def in ipairs(ROSTER) do
    local sprite, why = resolveSprite(gold.data, def.id)
    ok(sprite ~= nil,
       "GOLD/" .. def.id .. ": resolves a sprite (" .. tostring(why) .. ")")
    ok(sprite == nil or gold.data.gen2Sprites[sprite] ~= nil,
       "GOLD/" .. def.id .. ": and it exists in Gold's own table")
  end
  -- a boot with neither table is named, not crashed
  local nothing, why = resolveSprite({}, "chris")
  eq(nothing, nil, "a boot with no sprite table resolves nothing")
  ok(type(why) == "string", "and says which tables were missing")
end

-- 3b. THE STARTER DEAL (2.6.0)
-- ------------------------------------------------------------------
-- "Random" here must mean: different between playthroughs, IDENTICAL within
-- one. That distinction matters more for starters than for anything else in
-- the mod -- a rival's ace, its team identity, its type credit and half its
-- story are downstream of the Pokemon it opened with, so a starter that
-- rerolled on load would quietly invalidate five other systems.
do
  local boot = BOOTS[1]   -- RED
  local key = Version.starterKey(boot.data)
  local function deal(seed)
    local out = {}
    for _, def in ipairs(ROSTER) do
      out[#out + 1] = tostring(Rival.firstAvailableStarter(def, key,
        boot.data.pokemon, nil, { seed = seed, roster = ROSTER }))
    end
    return out
  end

  -- (a) STABLE within a save: the same seed always deals the same hand.
  for _, seed in ipairs({ 1, 999, 123456789, 4294967295 }) do
    eq(table.concat(deal(seed), ","), table.concat(deal(seed), ","),
       "seed " .. seed .. " deals the same hand every time")
  end

  -- (b) VARIED between saves: different seeds really do deal differently.
  local hands = {}
  for seed = 1, 400 do hands[table.concat(deal(seed), ",")] = true end
  local distinct = Util.count(hands)
  print(("  400 seeds produced %d distinct hands"):format(distinct))
  -- A plain rotation of the pool yields only #pool hands (six). A real
  -- permutation yields hundreds. This number is the difference between
  -- "random" meaning something and meaning almost nothing.
  ok(distinct >= 60,
     "different saves deal genuinely different hands, not six rotations")

  -- (c) NO DUPLICATES while the pool is bigger than the roster.
  --
  -- 4.3.0 grew the roster to 100 slots, and this check kept reading the WHOLE
  -- roster: 100 rivals cannot draw 100 different species from a six-species
  -- pool, so it failed 300 times for a reason that was never a bug. Dealing
  -- without replacement is a promise about the first #pool rivals; past that
  -- the pool is exhausted and repeats are the only possible behaviour.
  local pool = ROSTER.pools[key] or ROSTER.pools.default or {}
  local unique = math.min(#pool, #ROSTER)
  ok(unique >= 4, "the pool can still cover the original four rivals")
  for seed = 1, 300 do
    local seen, dupes = {}, 0
    local hand = deal(seed)
    for i = unique + 1, #hand do hand[i] = nil end
    for _, sp in ipairs(hand) do
      if seen[sp] then dupes = dupes + 1 end
      seen[sp] = true
    end
    ok(dupes == 0, "seed " .. seed .. ": the first " .. unique
      .. " rivals get different starters")
  end

  -- (d) EVERY species in the pool is reachable -- none is dead data.
  local dealt = {}
  for seed = 1, 600 do
    for _, sp in ipairs(deal(seed)) do dealt[sp] = (dealt[sp] or 0) + 1 end
  end
  for _, sp in ipairs(ROSTER.pools.default) do
    ok((dealt[sp] or 0) > 0, sp .. " is dealt in some save")
  end
  local lo, hi = math.huge, 0
  for _, n in pairs(dealt) do lo, hi = math.min(lo, n), math.max(hi, n) end
  ok(hi < lo * 3, "no species dominates the deal")

  -- (e) GOLD really does deal the Johto trio sometimes.
  local gold = BOOTS[4]
  local goldKey = Version.starterKey(gold.data)
  local johto = { CHIKORITA = 0, CYNDAQUIL = 0, TOTODILE = 0 }
  for seed = 1, 600 do
    for _, def in ipairs(ROSTER) do
      local sp = Rival.firstAvailableStarter(def, goldKey, gold.data.pokemon,
        nil, { seed = seed, roster = ROSTER })
      if johto[sp] ~= nil then johto[sp] = johto[sp] + 1 end
    end
  end
  for sp, n in pairs(johto) do
    ok(n > 0, "Gold deals " .. sp .. " in some save (" .. n .. " of 600)")
  end

  -- (f) A DECLARED chain still wins, so a third-party roster keeps working.
  local fixed = { id = "custom", slot = 1,
                  starters = { default = { "PIKACHU" } } }
  for seed = 1, 20 do
    eq(Rival.firstAvailableStarter(fixed, "default", boot.data.pokemon, nil,
         { seed = seed, roster = ROSTER }), "PIKACHU",
       "a roster row that declares its own starter is never overridden")
  end
  local legacy = { id = "legacy", slot = 2, starters = { "EEVEE", "PIKACHU" } }
  eq(Rival.firstAvailableStarter(legacy, "default", boot.data.pokemon, nil,
       { seed = 7, roster = ROSTER }), "EEVEE",
     "and the legacy flat-list form still resolves")

  -- (g) A boot carrying NONE of the pool falls back rather than dealing nil.
  local sparse = { pokemon = species({ "RATTATA" }) }
  local got = Rival.firstAvailableStarter(ROSTER[1], "default", sparse.pokemon,
    nil, { seed = 5, roster = ROSTER })
  eq(got, "RATTATA", "a boot with none of the pool falls back to the last resort")
  eq(Rival.firstAvailableStarter(ROSTER[1], "default", species({ "NOTHING" }),
       nil, { seed = 5, roster = ROSTER }), nil,
     "and a boot with nothing usable yields nil rather than an invented species")

  -- (h) A scope filter is respected: whatever hides a species from the player
  --     hides it from the deal too.
  local noFire = Rival.firstAvailableStarter(ROSTER[1], "default",
    boot.data.pokemon, function(sp) return sp ~= "CHARMANDER" end,
    { seed = 3, roster = ROSTER })
  ok(noFire ~= "CHARMANDER", "a scope filter removes a species from the deal")

  -- (i) A pool SMALLER than the roster shares rather than failing.
  local tiny = { pokemon = species({ "PIKACHU", "EEVEE" }) }
  local anyNil = false
  for _, def in ipairs(ROSTER) do
    if not Rival.firstAvailableStarter(def, "default", tiny.pokemon, nil,
         { seed = 9, roster = ROSTER }) then anyNil = true end
  end
  ok(not anyNil, "a pool smaller than the roster still gives everyone a starter")
end

-- ------------------------------------------------------------------
-- 3c. THE INTRO GAUNTLET IS NOT IN OAK'S LAB ON GOLD (2.7.0)
-- ------------------------------------------------------------------
-- Reported from a real Gold boot: the mod said the rivals were waiting in
-- Oak's Lab, and the character-creation screen offered a battle there. Gold
-- has no Oak's Lab.
--
-- The cause was a resolver whose candidate list held only Kanto maps and
-- whose fallback RETURNED "OAKS_LAB" regardless -- so the comment claiming
-- "Gen 2 has neither of these, so the gauntlet simply does not start there"
-- described behaviour the code did not have.
--
-- main.lua's resolver is reproduced here exactly: first candidate present in
-- the boot's map table wins, and nil when none is.
do
  local CANDIDATES = { "OAKS_LAB", "ELMS_LAB", "PALLET_TOWN", "NEW_BARK_TOWN" }
  local LABELS = { OAKS_LAB = "Oak's Lab", ELMS_LAB = "Elm's Lab",
                   PALLET_TOWN = "Pallet Town", NEW_BARK_TOWN = "New Bark Town" }
  local function resolveLab(maps)
    for _, id in ipairs(CANDIDATES) do
      if maps and maps[id] then return id end
    end
    return nil
  end

  -- Kanto boots find the Kanto lab.
  for _, name in ipairs({ "RED", "BLUE", "YELLOW" }) do
    local maps = { OAKS_LAB = {}, PALLET_TOWN = {}, ROUTE_1 = {} }
    eq(resolveLab(maps), "OAKS_LAB", name .. " holds the gauntlet in Oak's Lab")
  end

  -- Gold finds ELM'S lab, and NEVER Oak's.
  local gold = { ELMS_LAB = {}, NEW_BARK_TOWN = {}, ROUTE_29 = {} }
  eq(resolveLab(gold), "ELMS_LAB", "Gold holds the gauntlet in Elm's Lab")
  ok(resolveLab(gold) ~= "OAKS_LAB",
     "Gold never names Oak's Lab -- the room does not exist in that game")
  eq(LABELS[resolveLab(gold)], "Elm's Lab",
     "and the intro screen would say Elm's Lab")

  -- A Gold boot with only the outdoor town still works.
  eq(resolveLab({ NEW_BARK_TOWN = {}, ROUTE_29 = {} }), "NEW_BARK_TOWN",
     "a Gold boot with no lab interior falls back to New Bark Town")
  -- ...and a Kanto boot with only the town does too.
  eq(resolveLab({ PALLET_TOWN = {}, ROUTE_1 = {} }), "PALLET_TOWN",
     "a Kanto boot with no lab interior falls back to Pallet Town")

  -- THE CASE THAT WAS BROKEN: a boot with none of them must yield nil, not a
  -- Kanto map. Naming a room the game lacks is what produced the report.
  eq(resolveLab({ SOME_TOWN = {}, ROUTE_A = {} }), nil,
     "a boot with no known starting room yields NO gauntlet, not Oak's Lab")
  eq(resolveLab({}), nil, "an empty map table yields no gauntlet")
  eq(resolveLab(nil), nil, "a missing map table yields no gauntlet")

  -- Whatever is resolved must be a map the boot really has -- the whole point.
  for _, boot in ipairs(BOOTS) do
    local maps = boot.data.maps or boot.data.gen2Maps or {}
    local lab = resolveLab(maps)
    if lab then
      ok(maps[lab] ~= nil,
         boot.name .. ": the gauntlet room EXISTS in this boot (" .. lab .. ")")
    end
  end

  -- Every candidate has a player-facing name, so no screen ever shows a raw
  -- map id where a room name belongs.
  for _, id in ipairs(CANDIDATES) do
    ok(LABELS[id] ~= nil, id .. " has a display name")
    ok(not LABELS[id]:find("_"), id .. "'s display name is not a map id")
  end
end

-- ------------------------------------------------------------------
-- 4. A HOSTILE BOOT still degrades rather than naming an absent sprite
-- ------------------------------------------------------------------
-- The failure that matters is a spawn asking for an id the boot lacks: the
-- spawn fails outright rather than falling back, and the rival never appears.
local odd = { sprites = sprites({ "SPRITE_TOTALLY_CUSTOM" }),
              pokemon = species({ "MYSTERYMON" }),
              moves = { TACKLE = { power = 40, type = "NORMAL" } },
              constants = { fallbackMove = "TACKLE" }, type_chart = { matchups = {} },
              maps = { HOME = {} } }
for _, def in ipairs(ROSTER) do
  local sprite = resolveSprite(odd, def.id)
  eq(sprite, "SPRITE_TOTALLY_CUSTOM",
     "a total conversion still resolves to a sprite it really has: " .. def.id)
end
-- ...and a boot with no usable sprites at all yields nil, not a guess
local bare = { sprites = {}, pokemon = species({ "X" }) }
eq(resolveSprite(bare, "chris"), nil,
   "a boot with no usable sprite yields nil rather than naming an absent one")
-- deterministic: the arbitrary fallback must at least be arbitrary the same way
local many = { sprites = sprites({ "SPRITE_ZEBRA", "SPRITE_ALPHA", "SPRITE_MID" }) }
eq(resolveSprite(many, "chris"), resolveSprite(many, "chris"),
   "the last-resort sprite choice is stable between calls")
eq(resolveSprite(many, "chris"), "SPRITE_ALPHA",
   "and is the sorted first, not whatever pairs() happened to yield")

print(("\n%d passed, %d failed"):format(pass, fail))
os.exit(fail == 0 and 0 or 1)
