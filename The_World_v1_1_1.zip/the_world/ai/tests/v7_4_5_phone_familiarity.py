from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
c=(ROOT/"src/Comms.lua").read_text()
mc=(ROOT/"src/manager/Comms.lua").read_text()
p=(ROOT/"src/Phone.lua").read_text()
m=(ROOT/"manifest.json").read_text()
assert "function Comms.trainerPhoneProfile" in c
assert "if roll>=58" in c
assert "function Comms.noteTrainerBattle" in c
assert "record.battleCount=" in c
assert "phoneOfferAfter" in c
assert "(self.generation or 1)==2" in mc
assert "Comms.noteTrainerBattle" in mc
assert "phoneBattleThreshold=1+" in p
assert "and battles < 6" in p
assert "phoneOfferDeclinedAt" in p
assert '"version": "7.4.5"' in m
print("7.4.5 phone familiarity checks passed")
