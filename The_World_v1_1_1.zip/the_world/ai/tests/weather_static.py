#!/usr/bin/env python3
"""Static contracts for v1.37 Weather Intelligence.

The behavioural proof is in the three Lua suites. This file guards the
structural rules -- above all the one that broke: a chip type may never be
resolved from the battle-field string, because that string collapses several
overworld weathers that chip different types.
"""
import re
import sys
from pathlib import Path

root = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(Path(__file__).resolve().parent))
from _version import at_least

weather = (root / "src" / "Weather.lua").read_text(encoding="utf-8")
battlesim = (root / "src" / "BattleSim.lua").read_text(encoding="utf-8")
sim = (root / "src" / "Simulation.lua").read_text(encoding="utf-8")
rival = (root / "src" / "Rival.lua").read_text(encoding="utf-8")
ai = (root / "src" / "AI.lua").read_text(encoding="utf-8")
teamplan = (root / "src" / "TeamPlan.lua").read_text(encoding="utf-8")
compat = (root / "src" / "Compat.lua").read_text(encoding="utf-8")
main = (root / "main.lua").read_text(encoding="utf-8")
all_source = main + "\n" + "\n".join(p.read_text(encoding="utf-8") for p in (root / "src").rglob("*.lua"))
errors = []


def need(token, blob, label):
    if token not in blob:
        errors.append(label)


def code_of(blob):
    """Source with comment-only lines removed -- these files explain the trap
    at length, and matching prose would fail on the documentation."""
    return "\n".join(l for l in blob.splitlines() if not l.lstrip().startswith("--"))


# --- THE BUG THIS RELEASE FIXES ---------------------------------------------
need("function Weather.chipType", weather, "no chip resolution by overworld id")
if "battleWeather" in code_of(weather):
    errors.append("the weather model resolves something from the battle string")
need("opts.chipType or CHIP[opts.weather]", battlesim,
     "BattleSim ignores a caller-resolved chip type")
# every site that sets opts.weather must also resolve the chip from the id
setters = code_of(sim).count("opts.weather = compat:battleWeather()")
resolved = code_of(sim).count("opts.chipType = Weather.chipType(compat, opts.weatherId)")
if setters == 0:
    errors.append("no battle site consults weather at all")
if resolved != setters:
    errors.append(f"{setters} sites set a battle weather but only {resolved} "
                  f"resolve the chip from the overworld id")

# The ambiguity must be represented in the fallback, or the tests are vacuous.
pairs = re.findall(r'(\w+)\s*=\s*\{[^}]*chip = "(\w+)"[^}]*battle = "(\w+)"', weather)
by_battle = {}
for ident, chip, battle in pairs:
    by_battle.setdefault(battle, set()).add(chip)
if not any(len(v) > 1 for v in by_battle.values()):
    errors.append("the fallback catalogue has no ambiguous battle string -- "
                  "either it is wrong or the drift test is vacuous")

# --- read the host, do not mirror it -----------------------------------------
need("function Weather.catalogue", weather, "no catalogue reader")
need("exports.types", weather, "the live host catalogue is never read")
need("Weather.FALLBACK", weather, "no offline fallback")
need("count >= 4", weather, "an empty or tiny host catalogue would be believed")
need("cached.version == version", weather,
     "the catalogue cache is not keyed on the host version")
need("compat._weatherCatalogue", weather,
     "the cache is not on the compat handle, so a late-loading host is frozen out")
for banned in ("math.random", "os.time", "os.clock", "love."):
    if banned in weather:
        errors.append(f"the weather model is not deterministic ({banned})")
# every host field must be validated before use
need("function validEntry", weather, "host rows are trusted without validation")

# --- the stable interop surface is unchanged ---------------------------------
need("function Compat:weatherId", compat, "the overworld id accessor was removed")
need("function Compat:battleWeather", compat, "the battle weather accessor was removed")

# --- behaviour ---------------------------------------------------------------
need('"WEATHER",', teamplan, "the WEATHER archetype (§6) is missing")
need("WEATHER         = {", teamplan, "the WEATHER archetype has no weights")
need("RODE_THE_SKY", teamplan, "no drift reason toward a weather identity")
need("plan.style == \"WEATHER\" and opts.skyType", teamplan,
     "a WEATHER team does not focus on the sky")
need("function Rival:weatherFocusType", rival, "no favoured-type read")
need("function Rival:weatherAffinity", rival, "no affinity read")
need("function Rival:currentWeatherId", rival, "no sky read")
# hunting and travel must WEIGHT, never lock
need("local pool = list", rival, "hunting does not weight the pool")
need("self.rng:int(1, #pool)", rival, "the weighted hunt draw is missing")
need("if #allowed > 1 and rival.weatherAffinity then", ai,
     "exploration ignores the weather")
need("local edge = allowed[rival.rng:int(1, #allowed)]", ai,
     "the explore draw was changed -- pre-1.37 saves would diverge")
# the exclusive reading
need("rodeTheSky and (dominant == nil or dominant == sky)", rival,
     "type mastery and weather evidence are not exclusive, so they cancel")

# --- surfaces ----------------------------------------------------------------
need('mod.commands:register("rival_weather"', all_source, "no weather debug verb")
need('label = "SKY"', all_source, "the detail screen does not show the sky")
need("Weather = Weather,", main, "the model is not exported for tests")

# --- preserved ---------------------------------------------------------------
for token in ("KantoCompat", "WonderTrade.install(mod, M)", "rivalGiftAllowed",
              "Relationships.headline", "TeamPlan = TeamPlan", "Story = Story",
              "Presence = Presence"):
    need(token, main, f"earlier contract lost: {token}")
need("local SAVE_VERSION = 10", main, "save version regressed")
errors.extend(x for x in [at_least(root, "1.37.0")] if x)

if errors:
    for error in errors:
        print("FAIL", error)
    raise SystemExit(1)
print("AI Rivals v1.37 Weather Intelligence: chip resolved from the overworld "
      "id, catalogue read from the host, hunting and travel weighted not locked PASS")
