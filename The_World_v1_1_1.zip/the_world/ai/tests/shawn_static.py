from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
roster = (ROOT / "data" / "rivals.lua").read_text(encoding="utf-8")
personalities = (ROOT / "data" / "personalities.lua").read_text(encoding="utf-8")
dialogue = (ROOT / "data" / "dialogue.lua").read_text(encoding="utf-8")
main = (ROOT / "main.lua").read_text(encoding="utf-8")
roster_policy = (ROOT / "src" / "RosterPolicy.lua").read_text(encoding="utf-8")

assert 'id = "shawn"' in roster
assert 'name = "SHAWN"' in roster
assert 'personality = "HEARTBREAK_KID"' in roster
assert 'for slot = 6, 100 do' in roster
assert 'personalities = PERSONALITY_POOL' in roster
assert roster.count('personality = "HEARTBREAK_KID"') == 1
assert roster.count('personality = "') == 1
assert 'HEARTBREAK_KID = {' in personalities
assert '[5] = "FIVE"' in roster_policy
for phrase in ("I'm your frenemy", "Heartbreak Kid", "showstopper",
               "Sweet Chin Music", "main event"):
    assert phrase in dialogue, phrase
print("Shawn / Heartbreak Kid static checks passed")
