#!/usr/bin/env python3
"""Rivals must stay alongside the player (3.2).

The bug this guards: Can.GYM capped a rival at one badge ahead by reading
`world.playerBadges`, but the per-tick ctx the simulation builds never carried
that field. The cap silently compared against 0 on the path that runs most of
the time, and nothing failed loudly.
"""
import re
import sys
from pathlib import Path

root = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(Path(__file__).resolve().parent))
from _version import at_least

rival = (root / "src" / "Rival.lua").read_text(encoding="utf-8")
ai = (root / "src" / "AI.lua").read_text(encoding="utf-8")
sim = (root / "src" / "Simulation.lua").read_text(encoding="utf-8")
main = (root / "main.lua").read_text(encoding="utf-8")
errors = []


def need(token, blob, label):
    if token not in blob:
        errors.append(label)


def code_of(blob):
    return "\n".join(l for l in blob.splitlines() if not l.lstrip().startswith("--"))


# --- one decision, not two copies -------------------------------------------
need("Rival.BADGE_LEAD", rival, "no badge-lead constant")
need("function Rival:mayEarnBadge", rival, "no badge-lead decision")
need("function Rival:badgeLead", rival, "no badge-lead reading")
# both the objective gate and the award gate must call it
need("rival.mayEarnBadge and not rival:mayEarnBadge()", ai,
     "Can.GYM no longer consults the shared decision")
need("rival.mayEarnBadge and not rival:mayEarnBadge()", sim,
     "the award path does not enforce the lead -- objective selection is "
     "advisory and cannot be the only gate")
# and neither may re-implement the comparison inline
for name, blob in (("AI", ai), ("Simulation", sim)):
    if re.search(r"badgeCount\(\)\s*[<>]=?\s*[^=]*playerBadges", code_of(blob)):
        errors.append(f"{name} compares badges inline instead of calling "
                      f"mayEarnBadge -- two copies of this rule can disagree, "
                      f"and did")

# --- the reading must actually reach the tick --------------------------------
ctx = sim[sim.index("local ctx = {"):]
ctx = ctx[:ctx.index("}")]
need("playerBadges = world.playerBadges", ctx,
     "the per-tick ctx does not carry playerBadges -- this is the exact field "
     "whose absence made the cap compare against 0")
need("playerBadges = self:playerBadgeCount()", main,
     "the world view no longer supplies the player's badge count")

# --- an unknown player must never read as permission -------------------------
reader = rival[rival.index("function Rival:playerBadges"):]
reader = reader[:reader.index("\nend")]
need("or 0", reader,
     "an unknown player badge count does not default to 0, so 'not told yet' "
     "could read as unlimited")
# the level ceiling had the same hole
ceiling = rival[rival.index("function Rival:levelCeiling"):]
ceiling = ceiling[:ceiling.index("\nend")]
if re.search(r"or\s+100\b", ceiling):
    errors.append("levelCeiling still falls back to 100 when the player has no "
                  "party, which is no cap at all during the whole opening")
need("Rival.OPENING_LEVEL_CAP", ceiling,
     "no opening cap for a player who has no party yet")
need("self.playerPaceLevel", ceiling, "the ceiling ignores the player's level")

# --- pacing must survive a load ---------------------------------------------
need("playerPaceLevel = self.playerPaceLevel,", rival,
     "the level reading is not saved, so a reload grants a free level")
need("playerPaceBadges = self.playerPaceBadges,", rival,
     "the badge reading is not saved")
need("self.playerPaceLevel = tonumber(saved.playerPaceLevel)", rival,
     "the level reading is not restored")

# --- refuse the fight, do not withhold the badge -----------------------------
gate = sim[sim.index("function Simulation.attemptGym"):]
gate = gate[:gate.index("\nend\n")]
first_award = gate.find("awardBadge")
first_check = gate.find("mayEarnBadge")
if first_check < 0 or (0 <= first_award < first_check):
    errors.append("the lead is checked after the battle rather than before it; "
                  "a rival that beats a Gym Leader and receives nothing is a "
                  "worse bug than one that waits")

errors.extend(x for x in [at_least(root, "3.2.0")] if x)

if errors:
    for error in errors:
        print("FAIL", error)
    raise SystemExit(1)
print("AI Rivals v3.2 pacing: one badge-lead decision enforced at both the "
      "objective and the award, reading carried by the tick, saved PASS")
