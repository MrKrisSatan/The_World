#!/usr/bin/env python3
"""Static contracts for the absorbed Wonder Trade safety/compatibility path."""
import json, re, sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from _version import at_least

root = Path(__file__).resolve().parents[1]
src = (root / "src" / "WonderTrade.lua").read_text(encoding="utf-8")
main = (root / "main.lua").read_text(encoding="utf-8")
rival = (root / "src" / "Rival.lua").read_text(encoding="utf-8")
simulation = (root / "src" / "Simulation.lua").read_text(encoding="utf-8")
manifest = json.loads((root / "manifest.json").read_text(encoding="utf-8"))
errors = []

def need(token, label):
    if token not in src: errors.append(label)

need("function W.makeMon", "missing guarded constructor")
need("function W.animationSafe", "missing modded-species animation gate")
need('type(da.index) == "number"', "received animation does not require ROM index")
need("party[slot] = received", "missing atomic party-slot commit")
need('emit("pokemon.received"', "missing pokemon.received event")
need('emit("trade.completed"', "missing trade.completed event")
need("W.buildPool(game.data, manager)", "pool is not rebuilt from live merged data")
need("manager.compat.krAllows", "Kanto Reforged scope is not respected")
if "table.remove(party" in src: errors.append("party removal can lose the sent Pokemon")
if 'WonderTrade.install(mod, M)' not in main: errors.append("Wonder Trade is not installed by AI Rivals")
if 'WonderTrade = WonderTrade' not in main: errors.append("Wonder Trade test/export surface missing")
challenge = main[main.index("function M:startRivalChallenge"):main.index("function M:queueRivalAction")]
if "not runningOnIOS()" in challenge: errors.append("iOS is still excluded from direct Gen1 battle launch")
if "pendingRivalBattleLaunch" not in challenge: errors.append("manual challenge lacks deferred direct launch")
for token in ("function Rival:considerAttachment", "function Rival:refreshAce",
              "function Rival:wonderTradeDuplicate", "slot.ace and 10000"):
    if token not in rival: errors.append(f"missing rival ace contract: {token}")
for token in ('rival.rng:chance(0.25)', 'kind="wonder_trade"', 'kind="ace"'):
    if token not in simulation: errors.append(f"missing simulated Wonder Trade contract: {token}")
errors.extend(x for x in [at_least(root, "1.32.0")] if x)
if "wonder_trade" not in manifest.get("conflicts", []): errors.append("standalone duplicate is not blocked")
for dep in ("weather_fx", "Kanto-Reforged"):
    if dep not in manifest.get("optional_dependencies", []): errors.append(f"missing optional dependency {dep}")
gen1 = re.search(r"local GEN1 = \{(.*?)\nlocal GEN2", src, re.S)
gen2 = re.search(r"local GEN2 = \{(.*?)\nlocal TEXT", src, re.S)
if not gen1 or len(re.findall(r'"[A-Z0-9_]+"', gen1.group(1))) != 11:
    errors.append("expected 11 Kanto Center attendants")
if not gen2 or len(re.findall(r'"[A-Z0-9_]+"', gen2.group(1))) != 22:
    errors.append("expected 22 Johto/Kanto Gen2 Center attendants")

if errors:
    for error in errors: print("FAIL", error)
    raise SystemExit(1)
print("Wonder Trade absorption: atomic receive, 33 Centers, Weather FX/Kanto compatibility PASS")
