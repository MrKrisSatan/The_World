-- Standalone: lua5.1 tests/relationships_test.lua   (run from mods/ai_rivals)
--
-- The 1.33.0 relationship model, with no engine, no LOVE, no save and no
-- fixture data. src/Relationships.lua depends on nothing but src/Util.lua,
-- which is deliberate: the rules that decide what a rival feels can be
-- proven on any machine with a Lua interpreter.
-- Runs Relationships.lua + the Rival relationship methods standalone under
-- lua5.1, with no engine, no LOVE and no save.
local function req(name)
  local map = { ["src/Util"] = "src/Util.lua", ["src/Relationships"] = "src/Relationships.lua" }
  local f = assert(loadfile(map[name] or (name .. ".lua")))
  return f(req, {})
end
local Util = req("src/Util")
local R = req("src/Relationships")

local pass, fail = 0, 0
local function eq(a, b, msg)
  if a == b then pass = pass + 1 else fail = fail + 1
    print(("FAIL %s (got %s want %s)"):format(msg, tostring(a), tostring(b))) end
end
local function ok(c, msg)
  if c then pass = pass + 1 else fail = fail + 1; print("FAIL " .. msg) end
end

-- 1. Old save migrates to neutral, invents nothing.
local bonds = R.new(nil)
eq(next(bonds), nil, "a pre-1.33 save yields an empty bond store")
eq(R.stateOf(bonds, "player", 0), "NEUTRAL", "an unmet subject reads NEUTRAL")
eq(R.bond(bonds, "green", 0).wins, 0, "an unmet subject has no invented record")

-- 2. The canonical arc from the roadmap, driven only by battle outcomes.
local green = R.new()
local seen = {}
for i = 1, 4 do
  local _, _, after = R.battle(green, "crystal", false, { tick = i })
  seen[#seen + 1] = after
end
eq(R.stateOf(green, "crystal", 4), "RIVALRY", "four straight defeats produce RIVALRY")
ok(Util.indexOf(seen, "COMPETITIVE") ~= nil, "the arc passes through COMPETITIVE first")
for i = 5, 7 do R.battle(green, "crystal", true, { tick = i }) end
eq(R.stateOf(green, "crystal", 7), "RESPECT", "getting even turns frustration into RESPECT")
local bond = R.bond(green, "crystal", 7)
eq(bond.wins, 3, "head-to-head wins are counted")
eq(bond.losses, 4, "head-to-head losses are counted")

-- 3. Predictability: same causes, same order -> same state, every time.
local function replay()
  local b = R.new()
  for i = 1, 4 do R.battle(b, "crystal", false, { tick = i }) end
  for i = 5, 7 do R.battle(b, "crystal", true, { tick = i }) end
  return R.stateOf(b, "crystal", 7)
end
eq(replay(), replay(), "identical cause sequences derive identical states")

-- 4. Every state is reachable from causes alone (never assigned).
local reach = {}
do
  local b = R.new(); for i=1,10 do R.battle(b,"x",false,{tick=i}) end
  reach[R.stateOf(b,"x",10)] = true
end
do
  local b = R.new()
  R.apply(b,"x","HELPED",{tick=1}); R.apply(b,"x","REQUEST_DONE",{tick=2})
  reach[R.stateOf(b,"x",2)] = true
  R.apply(b,"x","COOPERATED",{tick=3})
  reach[R.stateOf(b,"x",3)] = true
end
do
  local b = R.new()
  -- a mentor is someone you have helped AND repeatedly outclassed
  R.apply(b,"x","HELPED",{tick=1}); R.apply(b,"x","TRADED",{tick=2})
  for i=3,6 do R.battle(b,"x",true,{tick=i,lead=3}) end
  reach[R.stateOf(b,"x",6)] = true
end
ok(reach.HOSTILE, "HOSTILE is reachable from repeated defeat")
ok(reach.FRIENDLY or reach.ALLIED, "warmth states are reachable from favours")
ok(reach.ALLIED, "ALLIED is reachable from repeated favours")
ok(reach.MENTOR, "MENTOR is reachable from a winning record plus a badge lead")

-- 4b. HOSTILITY NEEDS A GRIEVANCE, NOT A SCOREBOARD.
--
-- Found by the v2.0 integration soak: all four rivals ended HOSTILE toward the
-- player while WINNING two battles in three, because every result nudges regard
-- down and nothing counteracted it for a lopsided record. A rival does not come
-- to hate someone it comfortably beats.
do
  local winner = R.new()
  for i = 1, 300 do R.battle(winner, "player", i % 3 ~= 0, { tick = i * 10 }) end
  local bond = R.bond(winner, "player", 3000)
  ok(bond.wins > bond.losses * 1.5, "the fixture really is a dominant winner")
  ok(R.state(bond) ~= "HOSTILE",
     "a rival winning two in three is NOT hostile toward its victim")

  local loser = R.new()
  for i = 1, 300 do R.battle(loser, "player", i % 3 == 0, { tick = i * 10 }) end
  ok(R.state(R.bond(loser, "player", 3000)) ~= "HOSTILE",
     "nor is a rival losing two in three -- battles alone are not a grievance")

  -- ...but real grievance still produces hostility, for the dominant rival too
  local wronged = R.new()
  for i = 1, 20 do R.battle(wronged, "player", true, { tick = i }) end
  for i = 1, 40 do
    R.apply(wronged, "player", "SNUBBED", { tick = 100 + i })
    R.apply(wronged, "player", "REQUEST_IGNORED", { tick = 100 + i })
  end
  ok(R.bond(wronged, "player", 200).regard <= -55,
     "sustained grievance drives regard to the floor")
end

-- 5. Bounds: neither the store nor a bond's reason list may grow forever.
local big = R.new()
for i = 1, 60 do R.apply(big, "subject_" .. i, "TRADED", { tick = i }) end
eq(Util.count(big), R.BOND_LIMIT, "the bond store is capped")
local hot = R.new()
for i = 1, 80 do R.battle(hot, "crystal", i % 2 == 0, { tick = i }) end
ok(#R.bond(hot, "crystal", 80).reasons <= R.REASON_LIMIT, "reason history is bounded")
ok(math.abs(R.bond(hot,"crystal",80).regard) <= 100, "regard stays inside its axis")
ok(R.bond(hot,"crystal",80).rivalry <= 100, "rivalry stays inside its axis")
ok(R.bond(hot,"crystal",80).respect <= 100, "respect stays inside its axis")

-- 6. Serialization round trip (this is what mod.save does to it).
local round = R.new(R.serialize(green))
eq(R.stateOf(round, "crystal", 7), "RESPECT", "state survives a save/load round trip")
eq(R.bond(round,"crystal",7).losses, 4, "head-to-head survives a save/load round trip")
local twice = R.new(R.serialize(R.new(R.serialize(round))))
eq(R.stateOf(twice, "crystal", 7), "RESPECT", "repeated round trips do not drift")

-- 7. Garbage in a hand-edited save cannot produce an illegal state.
local dirty = R.new({ crystal = { regard = "lots", rivalry = 9e9, respect = -50,
  state = "BEST_FRIENDS", wins = -3, reasons = { { code = "NONSENSE" }, "TRADED" } } })
ok(R.isState(R.stateOf(dirty, "crystal", 0)), "a corrupt bond still derives a legal state")
eq(R.bond(dirty,"crystal",0).rivalry, 100, "an out-of-range axis is clamped, not trusted")
eq(R.bond(dirty,"crystal",0).wins, 0, "a negative record is repaired")

-- 8. Decay: contact fades, respect does not.
local old = R.new()
for i = 1, 4 do R.battle(old, "crystal", false, { tick = i }) end
local later = R.bond(old, "crystal", 4 + R.DECAY_TICKS * 200)
ok(later.rivalry < R.bond(old, "crystal", 4).rivalry, "rivalry cools without contact")
eq(later.respect, R.bond(old, "crystal", 4).respect, "respect never decays")
eq(R.bond(old, "crystal", 4).rivalry, R.bond(old, "crystal", 4).rivalry, "reads are pure")
ok(R.bond(old,"crystal",1e9).rivalry >= 0, "decay cannot drive an axis past rest")

-- 9. The shared predicates the other systems consume.
ok(R.fightBias("RIVALRY") > R.fightBias("NEUTRAL"), "a feud raises fight odds")
ok(R.fightBias("ALLIED") < R.fightBias("NEUTRAL"), "an alliance lowers fight odds")
ok(R.willCooperate("ALLIED") and not R.willCooperate("HOSTILE"),
   "cooperation follows the relationship")
for _, s in ipairs(R.STATES) do
  ok(type(R.fightBias(s)) == "number", "every state has a fight bias: " .. s)
  ok(type(R.label(s)) == "string", "every state has a label: " .. s)
end

-- 10. Causes are a closed set; a typo cannot silently move a relationship.
local strict = R.new()
local b2 = R.apply(strict, "crystal", "BECAUSE_I_SAID_SO", { tick = 1 })
eq(b2, nil, "an unnamed cause is refused")
eq(next(strict), nil, "a refused cause writes nothing")

print(("\n%d passed, %d failed"):format(pass, fail))
os.exit(fail == 0 and 0 or 1)
