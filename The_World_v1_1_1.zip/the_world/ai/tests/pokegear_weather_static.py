from pathlib import Path

root = Path(__file__).resolve().parents[1]
poke = (root / "src" / "Pokegear.lua").read_text(encoding="utf-8")
compat = (root / "src" / "Compat.lua").read_text(encoding="utf-8")

for token in (
    'manager.compat:weatherMap()',
    'WEATHER FX - LIVE',
    '{ "johto", "kanto" }',
    '{ "kanto" }',
    'right = weather:sub(1, 12)',
):
    assert token in poke, f"missing Pokégear Weather FX integration token: {token}"

assert 'function Compat:weatherMap()' in compat
assert 'type(exports.weatherMap) == "function"' in compat
assert 'exports.lib.require("Fronts")' in compat
print("pokegear weather integration static checks passed")
