-- Standalone: lua5.1 tests/rival_weather_test.lua  (from mods/ai_rivals)
--
-- Weather intelligence through real Rival objects: that a rival with NO
-- Weather FX behaves exactly as it did before weather existed, that hunting
-- and travel lean on the sky without ever being locked by it, and that a
-- WEATHER team builds around the sky rather than its own record.

local cache = {}
local function req(n)
  if cache[n] then return cache[n] end
  local f = assert(loadfile(n .. ".lua")); cache[n] = f(req, {}); return cache[n]
end
local Util, Rival, Weather = req("src/Util"), req("src/Rival"), req("src/Weather")
local TeamPlan, AI = req("src/TeamPlan"), req("src/AI")
local PERS, ROSTER = req("data/personalities"), req("data/rivals")

local pass, fail = 0, 0
local function eq(a, b, m) if a == b then pass = pass + 1 else fail = fail + 1
  print(("FAIL %s (got %s want %s)"):format(m, tostring(a), tostring(b))) end end
local function ok(c, m) if c then pass = pass + 1 else fail = fail + 1; print("FAIL " .. m) end end

local function mon(types, evo)
  return { baseStats = { hp = 60, attack = 70, defense = 60, speed = 60, special = 60 },
           types = types, level1Moves = { "TACKLE" }, learnset = {}, evolutions = evo }
end
local DATA = {
  pokemon = {
    ZAPPER = mon({ "ELECTRIC" }), SPLASHER = mon({ "WATER" }),
    BURNER = mon({ "FIRE" }), LEAFY = mon({ "GRASS" }), ROCKY = mon({ "ROCK" }),
  },
  moves = { TACKLE = { power = 40, type = "NORMAL" } },
  constants = { fallbackMove = "TACKLE" }, type_chart = { matchups = {} },
  encounters = { ROUTE_9 = { slots = {
    { species = "ZAPPER" }, { species = "SPLASHER" },
    { species = "BURNER" }, { species = "LEAFY" }, { species = "ROCKY" } } } },
}

-- A compat stand-in. `sky` is the current overworld weather id.
local function compatFor(sky, present)
  return {
    _sky = sky,
    weather = function(self) return present ~= false end,
    weatherId = function(self) return self._sky end,
    battleWeather = function(self) return Weather.battleString(self, self._sky) end,
    exports = function() return nil end,   -- forces the fallback catalogue
    -- the DEX SCOPE probe Rival:addPokemon consults; a real compat always has
    -- it, and answering "allowed" here keeps the fixture species usable
    krAllows = function() return true end,
  }
end

local function ctxFor(compat)
  return { data = DATA, personalities = PERS, compat = compat,
           graph = { has = function() return true end,
                     neighbours = function(_, id)
                       return { { to = "ROUTE_10" }, { to = "CERULEAN_POKECENTER" },
                                { to = "ROUTE_9" } }
                     end },
           gyms = { order = {}, byBadge = {} } }
end

local function make(i, compat)
  local r = Rival.new(ROSTER[i or 1], ctxFor(compat))
  r.ticks, r.map = 0, "ROUTE_9"
  r.canEnterMap = function() return true end
  return r
end

-- 1. NO HOST: every weather read is inert and nothing changes.
local blind = make(1, nil)
eq(blind:currentWeatherId(), nil, "with no Weather FX there is no sky")
eq(blind:weatherFocusType(), nil, "and nothing for the sky to favour")
eq(blind:weatherAffinity(), 0, "and no affinity either")
local absent = make(1, compatFor("STORM", false))
eq(absent:currentWeatherId(), nil, "a compat reporting Weather FX absent yields no sky")
eq(absent:weatherAffinity(), 0, "and no affinity")

-- 2. Affinity is read off the party actually being fielded.
local storm = make(1, compatFor("STORM"))
storm.party = {}
storm:addPokemon("ZAPPER", 10)
eq(storm:weatherFocusType(), "ELECTRIC", "a storm favours Electric")
eq(storm:weatherAffinity(), 1, "an Electric team is at home in a storm")
storm.party = {}
storm:addPokemon("SPLASHER", 10)
eq(storm:weatherAffinity(), -1, "a Water team is worn down by a storm")
-- and the sky changing changes the answer without anything being re-derived
storm.ctx.compat._sky = "RAIN_LIGHT"
eq(storm:weatherAffinity(), 1, "the same team is at home in light rain")
eq(storm:weatherFocusType(), "WATER", "which favours Water")

-- 3. §19 HUNTING leans on the sky but never locks the pool.
local function huntSpread(sky, style, draws)
  local seen, r = {}, nil
  for i = 1, draws do
    r = make(2, compatFor(sky))
    r.ctx.compat._sky = sky
    r:ensureTeamPlan().style = style
    r.rng = Util.rng(i * 7919)
    r.dex = {}
    local target = r:pickHuntTarget()
    if target then seen[target] = (seen[target] or 0) + 1 end
  end
  return seen
end
local sunny = huntSpread("SUNNY", "BALANCED", 400)
ok((sunny.BURNER or 0) > (sunny.SPLASHER or 0),
   "under sun a rival hunts Fire more often than Water")
ok((sunny.SPLASHER or 0) > 0,
   "but the sky NEVER locks a species out of the pool -- weather changes")
local weathery = huntSpread("SUNNY", "WEATHER", 400)
ok((weathery.BURNER or 0) > (sunny.BURNER or 0),
   "a WEATHER rival leans on the sky harder than a balanced one")
local clear = huntSpread("CLEAR", "BALANCED", 400)
local spread = 0
for _ in pairs(clear) do spread = spread + 1 end
ok(spread >= 4, "under clear skies the hunt is unbiased")

-- 4. §18 TRAVEL: an uncomfortable rival heads indoors, a comfortable one does not.
local function exploreSpread(sky, species, draws)
  local indoors = 0
  for i = 1, draws do
    local r = make(3, compatFor(sky))
    r.party = {}
    r:addPokemon(species, 10)
    r.rng = Util.rng(i * 104729)
    local dest = AI.Destination.EXPLORE(r)
    if type(dest) == "string" and dest:find("POKECENTER") then indoors = indoors + 1 end
  end
  return indoors
end
local exposed = exploreSpread("SUNNY", "SPLASHER", 400)   -- water in the sun
local athome = exploreSpread("SUNNY", "BURNER", 400)      -- fire in the sun
ok(exposed > athome,
   "a team the sky is wearing down heads indoors more often than one enjoying it")
ok(athome > 0, "but a comfortable rival can still go indoors")
ok(exposed < 400, "and an exposed one is not forced to")

-- 5. A WEATHER team builds around the SKY, not its own record.
local wx = make(4, compatFor("SUNNY"))
wx:ensureTeamPlan().style = "WEATHER"
-- give it a Water record, so record and sky disagree
for _ = 1, 10 do TeamPlan.creditTypes(wx.teamPlan, { "WATER" }, true) end
eq(wx:preferredType(), "WATER", "its record says Water")
eq(wx:weatherFocusType(), "FIRE", "but the sky says Fire")
ok(wx:teamFit("BURNER") > wx:teamFit("SPLASHER"),
   "a WEATHER rival follows the sky rather than its record")
local mono = make(4, compatFor("SUNNY"))
mono:ensureTeamPlan().style = "MONO_TYPE"
for _ = 1, 10 do TeamPlan.creditTypes(mono.teamPlan, { "WATER" }, true) end
ok(mono:teamFit("SPLASHER") > mono:teamFit("BURNER"),
   "a MONO_TYPE rival still follows its own record")

-- 6. Winning under a favourable sky is evidence toward a weather identity.
local drifter = make(1, compatFor("STORM"))
drifter:ensureTeamPlan().style = "BALANCED"
drifter.party = {}
drifter:addPokemon("ZAPPER", 10)
for _ = 1, 30 do drifter:creditLeadBattle(true) end
eq(drifter:teamStyle(), "WEATHER",
   "repeatedly winning under a sky that suited the team builds a weather identity")
local loser = make(1, compatFor("STORM"))
loser:ensureTeamPlan().style = "BALANCED"
loser.party = {}
loser:addPokemon("ZAPPER", 10)
for _ = 1, 30 do loser:creditLeadBattle(false) end
ok(loser:teamStyle() ~= "WEATHER", "losing under it is not evidence of anything")

-- 7. Persistence: the WEATHER identity is an ordinary archetype.
ok(TeamPlan.isArchetype("WEATHER"), "WEATHER is a legal archetype")
local blob = drifter:serialize()
local reloaded = Rival.new(ROSTER[1], ctxFor(compatFor("STORM")))
ok(reloaded:restore(blob), "a weather rival restores")
eq(reloaded:teamStyle(), "WEATHER", "the weather identity survives save/load")
ok(type(TeamPlan.battleStyle("WEATHER")) == "string", "and has a battle style")

print(("\n%d passed, %d failed"):format(pass, fail))
os.exit(fail == 0 and 0 or 1)
