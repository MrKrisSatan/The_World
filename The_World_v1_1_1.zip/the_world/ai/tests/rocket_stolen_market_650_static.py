from pathlib import Path
import json
root=Path(__file__).resolve().parents[1]
r=(root/'src/Rocket.lua').read_text()
d=(root/'src/RocketDisguise.lua').read_text()
m=(root/'main.lua').read_text()
manifest=json.loads((root/'manifest.json').read_text())
assert manifest['version']=='6.5.0'
for token in ['stolenAssets','stolenPrice','transferStolen','internalStolenMarketPulse','SOLD_TO_PLAYER','saleHistory']:
    assert token in r+d
assert 'for _,asset in ipairs(self:stolenAssets(member,true))' in r
assert 'ai_rivals:buy_stolen_pokemon' in d and 'buyStolenPokemon' in d
assert 'stolenOffer(member)' in m and 'Don\'t ask where it came from' in m
assert 'aiRivalsProvenance' in d
assert 'originalOwnerId' in r and 'originalOwnerName' in r
print('rocket stolen market 6.5 static: ok')
