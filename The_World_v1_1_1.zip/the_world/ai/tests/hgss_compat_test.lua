-- Standalone: lua5.1 tests/hgss_compat_test.lua   (from mods/ai_rivals)
--
-- Compatibility with HGSS Visual Overhaul (LucianoNeo/gen1recomp-mods 0.5.9).
--
-- Reported: "things revert when speaking to ai in your mod then go back to HG".
--
-- HGSS patches a shared sprite record with its own art AND a marker
-- (`hgssNativeImage`, plus a 32px hgssFrameWidth/hgssFrameHeight contract),
-- then wraps SpriteRenderer.new so any def carrying that marker has its image
-- replaced with the HGSS texture at construction (main.lua:1979 in 0.5.9).
--
-- We were writing `record.image` over the top and LEAVING THE MARKER, which
-- makes the record internally inconsistent: our 16px art under their 32px
-- frame contract, still flagged as theirs. Whichever path read it next won, so
-- the look flipped depending on whether a renderer was built through their
-- wrapper -- the reported flicker.

local cache = {}
local function req(n)
  if cache[n] then return cache[n] end
  local f = assert(loadfile(n .. ".lua")); cache[n] = f(req, {}); return cache[n]
end
local Sprites = req("src/Sprites")

local pass, fail = 0, 0
local function eq(a, b, m) if a == b then pass = pass + 1 else fail = fail + 1
  print(("FAIL %s (got %s want %s)"):format(m, tostring(a), tostring(b))) end end
local function ok(c, m) if c then pass = pass + 1 else fail = fail + 1; print("FAIL " .. m) end end

-- The exact shape HGSS 0.5.9 patches on (main.lua:205 and :255).
local function hgssRecord()
  return {
    image = "assets/voxel/frame_layout_6_32.png",   -- their proxy sheet
    hgssNativeImage = "overrides/sprites/lass.png", -- the real art
    frames = 6, walker = true, trueColor = true,
    hgssFrameWidth = 32, hgssFrameHeight = 32,
  }
end

-- 1. A record HGSS authored is recognised as foreign.
ok(Sprites.foreignArt(hgssRecord(), "vanilla/lass.png"),
   "an HGSS-patched record is recognised as another mod's work")
-- ...and by the MARKER alone, even with no vanilla baseline to compare
ok(Sprites.foreignArt(hgssRecord(), nil),
   "the marker alone is decisive, with or without a captured baseline")
ok(Sprites.foreignArt({ hgssNativeImage = "x" }, nil), "hgssNativeImage claims it")
ok(Sprites.foreignArt({ hgssFrameWidth = 32 }, nil), "so does the frame contract")

-- 2. An untouched vanilla record is ours to paint.
eq(Sprites.foreignArt({ image = "vanilla/lass.png" }, "vanilla/lass.png"), false,
   "an untouched vanilla record is not foreign")
eq(Sprites.foreignArt({ image = nil }, "vanilla/lass.png"), false,
   "a record with no art is not foreign")
eq(Sprites.foreignArt(nil, "vanilla/lass.png"), false, "a missing record is safe")
eq(Sprites.foreignArt({ image = "anything" }, nil), false,
   "with no baseline and no marker we do not guess")

-- 3. OUR OWN art is not mistaken for a foreign claim -- otherwise the second
--    pass over a slot we already painted would refuse to touch it and the
--    rival's look would depend on how many times the resolver had run.
eq(Sprites.foreignArt({ image = "ai_rivals/green.png" }, "vanilla/lass.png",
     "ai_rivals/green.png"), false,
   "a slot we painted ourselves is still ours on a second pass")
ok(Sprites.foreignArt({ image = "someone_else/lass.png" }, "vanilla/lass.png",
     "ai_rivals/green.png"),
   "but a THIRD mod's art is foreign even where we had painted before")

-- 4. An unknown overhaul with no marker we know is still caught, by the art
--    simply not being vanilla any more.
ok(Sprites.foreignArt({ image = "wilds_of_kanto/lass.png" }, "vanilla/lass.png"),
   "a mod we have never heard of is caught by the baseline comparison")

-- 5. The marker list must actually name what HGSS writes, or the decisive
--    test silently degrades to the baseline one.
local record = hgssRecord()
local named = false
for _, marker in ipairs(Sprites.FOREIGN_MARKERS) do
  if record[marker] ~= nil then named = true end
end
ok(named, "the marker list names a field HGSS 0.5.9 really writes")
ok(#Sprites.FOREIGN_MARKERS > 0, "the marker list is not empty")

-- 6. THE INVARIANT THAT MATTERS: we never leave a record half-ours.
--    Either we own the whole thing (our art, no foreign marker) or we do not
--    touch it. A record carrying our image AND their marker is the bug.
local function applyLikeRegisterSlots(rec, ourArt, vanilla, mine)
  if not Sprites.foreignArt(rec, vanilla, mine) then
    rec.image = ourArt
    rec.walker = true
  end
  return rec
end
local theirs = applyLikeRegisterSlots(hgssRecord(), "ai_rivals/green.png",
  "vanilla/lass.png")
eq(theirs.image, "assets/voxel/frame_layout_6_32.png",
   "an HGSS record keeps HGSS's art -- we do not repaint it")
eq(theirs.hgssNativeImage, "overrides/sprites/lass.png",
   "and keeps its marker, so their renderer still draws it")
ok(not (theirs.image == "ai_rivals/green.png" and theirs.hgssNativeImage),
   "the record is NEVER left half-ours -- that combination is the flicker")

local plain = applyLikeRegisterSlots({ image = "vanilla/lass.png" },
  "ai_rivals/green.png", "vanilla/lass.png")
eq(plain.image, "ai_rivals/green.png",
   "a record nobody else authored is still painted with our art")
eq(plain.hgssNativeImage, nil, "and carries no foreign marker")

print(("\n%d passed, %d failed"):format(pass, fail))
os.exit(fail == 0 and 0 or 1)
