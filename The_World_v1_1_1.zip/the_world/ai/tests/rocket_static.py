from pathlib import Path
import json
import sys
sys.path.insert(0, str(Path(__file__).resolve().parent))
ROOT=Path(__file__).resolve().parents[1]
rocket=(ROOT/'src'/'Rocket.lua').read_text()
main=(ROOT/'main.lua').read_text()
data=(ROOT/'data'/'rocket.lua').read_text()
manifest=json.loads((ROOT/'manifest.json').read_text())
assert 'RocketManager = req("src/Rocket")' in main
assert 'self.rocket = RocketManager.new' in main
assert 'out.rocket = self.rocket and self.rocket:serialize()' in (ROOT/'src'/'manager'/'Persistence.lua').read_text()
assert 'self.rocket:load(saved.rocket)' in (ROOT/'src'/'manager'/'Persistence.lua').read_text()
assert 'M.rocket:update(dt, world)' in main
assert 'function Rocket:advanceMember' in rocket
assert 'self.manager.graph:route(member.map, destination)' in rocket
assert 'function Rocket:attemptRecruit' in rocket
assert 'function Rocket:attemptSteal' in rocket
assert 'SAFARI_SEIZURE' in rocket and 'self.seized.SAFARI_ZONE' in rocket
assert 'function Rocket:promoteDemote' in rocket
assert 'function Rocket:checkRedemption' in rocket
assert 'function Rocket:maybeAmbushPlayer' in rocket
assert 'function Rocket:registerTrainers' in rocket
for mon in ['ZUBAT','KOFFING','RATTATA','EKANS','NIDORAN_M','NIDORAN_F','MEOWTH','HOUNDOUR','MAGIKARP','TENTACOOL']:
    assert mon in data
# 5.0.8: was `manifest['version'] == '5.0.1'`. A literal pin fails at every
# release, and because it sat at the BOTTOM of the file nothing below it ever
# ran -- it had been red since 5.0.2 while reading like a Rocket regression.
# §34: a suite that fails for an unrelated reason reports almost nothing and
# looks busy doing it. Asserting the FLOOR is what tests/_version.py exists
# for.
from _version import version, tuple_of
assert tuple_of(version(ROOT)) >= tuple_of('5.0.1'), manifest['version']

# 5.0.8: Rocket dialogue moved out of a local table in src/Rocket.lua and
# became a situation x rank x role cross product. Both ends pinned so a
# refactor that drops one fails here.
assert 'RocketDialogue = req("data/rocket_dialogue")' in rocket
assert 'local ROCKET_LINES = RocketDialogue.build()' in rocket
assert 'function Rocket:noteBattleOutcome' in rocket
assert 'M.rocket:noteBattleOutcome(member, won)' in main
rocket_lines = (ROOT/'data'/'rocket_dialogue.lua').read_text()
for role in ['Scout','Enforcer','Thief','Smuggler','Scientist','Recruiter','Quartermaster']:
    assert role in rocket_lines, role
    assert role in data, role
for rank in ['Grunt','Executive','Leader']:
    assert rank in rocket_lines, rank

print('rocket_static: PASS')
