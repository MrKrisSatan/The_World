#!/usr/bin/env python3
"""The ecology has ONE DOOR, stores only events, and reaches both generations.

§26: a rule enforced only at decision time is advisory. The population model is
only trustworthy if every hunting event goes through Ecology:record -- a second
writer would make the save and the model two sources for one fact.
"""
import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(Path(__file__).resolve().parent))
from _version import at_least


def code_only(text):
    """Strip Lua comments before scanning (§3 -- eighth occurrence and counting)."""
    text = re.sub(r"--\[(=*)\[.*?\]\1\]", " ", text, flags=re.S)
    return "\n".join(
        line for line in text.splitlines() if not line.lstrip().startswith("--")
    )


eco = (ROOT / "src" / "Ecology.lua").read_text(encoding="utf-8")
main = (ROOT / "main.lua").read_text(encoding="utf-8")
sim = (ROOT / "src" / "Simulation.lua").read_text(encoding="utf-8")
persist = (ROOT / "src" / "manager" / "Persistence.lua").read_text(encoding="utf-8")
travel = (ROOT / "src" / "Travel.lua").read_text(encoding="utf-8")

errors = []


def need(token, blob, label):
    if token not in blob:
        errors.append(label)


# --- one door -------------------------------------------------------------
need("function Ecology:record", eco, "there is no Ecology:record door")
others = code_only(main) + "\n" + code_only(sim)
for match in re.finditer(r"\.maps\s*\[", others):
    errors.append("something outside Ecology.lua writes the population table")
if 'ecology:record' not in code_only(sim):
    errors.append("rival catches do not press on the population")
if 'eco:record' not in code_only(main):
    errors.append("player encounters do not press on the population")

# --- derived, not stored --------------------------------------------------
# The population itself must never be persisted: it is fully recoverable from
# the static table plus the events, which is the house test for storing.
need("out.ecology = self.ecology", persist, "pressure events are not saved")
for banned in ("out.population", "out.abundance"):
    if banned in persist:
        errors.append(f"{banned} stores a derived quantity")

# --- bounded --------------------------------------------------------------
for token in ("MAX_MAPS", "MAX_SPECIES_PER_MAP", "EPSILON", "function Ecology:prune"):
    need(token, eco, f"the save is not bounded: missing {token}")

# --- never manufactures a species ----------------------------------------
# A variant id must be one data.pokemon already has. This is a non-negotiable:
# no impossible Pokemon.
variant = eco[eco.index("function Ecology.variantSpecies"):]
variant = variant[: variant.index("\nend\n")]
need("data.pokemon", variant, "variantSpecies does not consult the real species table")
if "return prefix" in variant or 'return "WX_"' in variant:
    errors.append("variantSpecies builds an id instead of finding one")

# --- both generations -----------------------------------------------------
# encounter.roll / encounter.species exist on Gen 1 AND Gen 2. A model wired to
# only one of them silently switches itself off on Gold (§8).
for hook in ("encounter.roll", "encounter.species"):
    need(f'mod.hooks:wrap("{hook}"', main, f"{hook} is not wired")
# The capacity walk has to handle both encounter table shapes.
capacity = eco[eco.index("function Ecology:capacity"):]
capacity = capacity[: capacity.index("\nend\n")]
need("data.encounters", capacity, "capacity ignores the Gen 1 table shape")
need("gen2Encounters", capacity, "capacity ignores the Gen 2 table shape")

# --- never draws from the engine's RNG ------------------------------------
# §13: adding a draw to a shared stream retroactively changes every existing
# save's encounter sequence.
if "love.math.random" in code_only(eco):
    errors.append("Ecology draws from the engine RNG")
if "ctx.rng" in code_only(main)[code_only(main).find("encounter.roll"):]:
    errors.append("the encounter hooks draw from the engine RNG")
need("local function ecoRoll", main, "there is no private ecology stream")

# --- travel styles may not beat the pacing rule ---------------------------
# Christopher's standing requirement: rivals never end up three gyms ahead.
# A style biases POSITION only.
tcode = code_only(travel)
for banned in ("BADGE_LEAD", "mayEarnBadge", "badgeCount", "playerPaceLevel"):
    if banned in tcode:
        errors.append(f"Travel.lua touches pacing via {banned}")
need("function Travel.styleOf", travel, "there is no style resolver")
need("Travel.STYLES", travel, "the style list is not exposed for tests to read")
# The resolver must rank against the real cast rather than carry tuned weights
# -- the first version's fixed weights made two styles unreachable.
need("data/personalities", tcode,
     "styleOf does not calibrate against the shipped cast")

errors.extend(x for x in [at_least(ROOT, "5.2.0")] if x)

if errors:
    for error in errors:
        print("FAIL", error)
    raise SystemExit(1)
print("ecology + travel static: one door, bounded, derived, both generations PASS")
