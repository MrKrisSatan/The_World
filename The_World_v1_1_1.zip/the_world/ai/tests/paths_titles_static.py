import re
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from _version import at_least

root = Path(__file__).resolve().parents[1]
rows = (root / "data" / "lifepaths.lua").read_text(encoding="utf-8")
life = (root / "src" / "LifePath.lua").read_text(encoding="utf-8")
career = (root / "src" / "Career.lua").read_text(encoding="utf-8")
titles = (root / "src" / "Titles.lua").read_text(encoding="utf-8")
tourn = (root / "src" / "Tournaments.lua").read_text(encoding="utf-8")
rival = (root / "src" / "Rival.lua").read_text(encoding="utf-8")
rel = (root / "src" / "Relationships.lua").read_text(encoding="utf-8")
roster = (root / "data" / "rivals.lua").read_text(encoding="utf-8")
main = (root / "main.lua").read_text(encoding="utf-8")
all_source = main + "\n" + "\n".join(p.read_text(encoding="utf-8") for p in (root / "src").rglob("*.lua"))

assert at_least(root, "4.7.0") is None, at_least(root, "4.7.0")


def body(text):
    """Source with comment lines stripped -- lesson 3, seven occurrences now."""
    return "\n".join(l for l in text.splitlines() if not l.strip().startswith("--"))


errors = []


def need(token, blob, label):
    if token not in blob:
        errors.append(label)


# --- ONE HUNDRED PATHS, AND EACH ONE REACHABLE ------------------------------
ids = re.findall(r'add\{ id = "([A-Z_]+)"', rows)
if len(ids) < 100:
    errors.append(f"only {len(ids)} life paths declared; the brief asked for 100")
if len(set(ids)) != len(ids):
    dupes = [i for i in set(ids) if ids.count(i) > 1]
    errors.append(f"duplicate path ids: {dupes}")

# The five named in the brief, by id and by the label a player will read.
for pid, label in (("RANGER", "Pokemon Ranger"),
                   ("LEGENDARY_HUNTER", "Legendary Hunter"),
                   ("CELEBI_AGENT", "Agent of Celebi"),
                   ("ARCEUS_AMBASSADOR", "Ambassador of Arceus"),
                   ("LEAGUE_CHAMPION", "League Champion")):
    if pid not in ids:
        errors.append(f"the brief named {label} and there is no {pid} row")
    elif f'label = "{label}"' not in rows:
        errors.append(f"{pid} does not read as {label}")

# The original sixteen keep their ids AND their order. A committed path is
# stored by id, so renaming one silently rehomes every save that took it.
for i, pid in enumerate(("BREEDER", "RESEARCHER", "OAK_ASSISTANT", "TOWER_CARETAKER",
                         "GHOST_RESEARCHER", "EXPLORER", "GYM_ASSISTANT",
                         "CENTER_ASSISTANT", "MART_WORKER", "RETIRED", "TEAM_ROCKET",
                         "BATTLE_COACH", "RANGER", "COURIER", "PHOTOGRAPHER",
                         "TYPE_SPECIALIST")):
    if i >= len(ids) or ids[i] != pid:
        errors.append(f"the original sixteen moved: slot {i} is "
                      f"{ids[i] if i < len(ids) else 'missing'}, expected {pid}")

# --- THE MODULES READ THE ROWS ----------------------------------------------
need('LifePath.ROWS = req("data/lifepaths")', life, "LifePath does not read the rows")
need("local ROWS = req(\"data/lifepaths\")", career, "Career does not read the rows")
for token in ("LifePath.PATHS[#LifePath.PATHS + 1] = row.id",
              "LifePath.LABELS[row.id] = row.label"):
    need(token, life, f"paths/labels are not built from the rows ({token})")
# A second hand-written list beside the data is the drift this refactor exists
# to end -- three careers were dead because of exactly that.
if re.search(r'LifePath\.PATHS = \{\s*\n\s*"', life):
    errors.append("LifePath.PATHS is hand-listed again")

# --- EVERY WEIGHT NAMES A FACT THAT EXISTS ----------------------------------
vocab = set(re.findall(r'"(\w+)",', life[life.index("LifePath.FACTS = {"):
                                         life.index("}", life.index("LifePath.FACTS = {"))]))
if len(vocab) < 15:
    errors.append("could not read the fact vocabulary from LifePath.FACTS")
for block in re.findall(r"weights = \{([^}]*)\}", rows) + \
             re.findall(r"requires = \{([^}]*)\}", rows):
    for fact in re.findall(r"(\w+) =", block):
        if fact not in vocab:
            errors.append(f"a row names the unknown fact '{fact}'")
# ...and the loader says so at boot rather than scoring it zero forever.
need("LifePath.ROW_ERRORS", life, "unknown facts are not reported at load")

# --- RARITY IS A GATE, NOT A DIE --------------------------------------------
need("requires", life, "the requires gate is not implemented")
need("if (f[fact] or 0) < (tonumber(minimum) or 0) then gated = true end", life,
     "a required fact does not actually bar the path")
lifeBody = body(life)
for banned in ("rng", "math.random"):
    if banned in lifeBody:
        errors.append(f"LifePath rolls dice ({banned}) -- compatibility must be "
                      f"a pure reading of the rival")
# The relationship-gated lives are the point of 4.7.0's relationship work.
for pid, fact in (("AVENGER", "betrayal"), ("SWORN_RIVAL", "jealousy"),
                  ("RECLUSE", "fear"), ("PROTECTOR", "kinship"),
                  ("MENTOR_PATH", "mentorship"), ("DEVOTED_PARTNER", "devotion")):
    start = rows.index(f'add{{ id = "{pid}"')
    nxt = rows.find("\nadd{", start)
    block = rows[start:nxt if nxt != -1 else len(rows)]
    if f"requires" not in block or fact not in block:
        errors.append(f"{pid} is not gated on {fact} -- it would be dealt to "
                      f"rivals it makes no sense for")

# --- RELATIONSHIPS FEED PATHS -----------------------------------------------
need("function Rival:relationshipFacts", rival, "no relationship facts are derived")
need("for fact, value in pairs(self:relationshipFacts()) do", rival,
     "the relationship facts never reach the life-path reading")
for state in ("BETRAYED", "JEALOUS", "FEARFUL", "FAMILY"):
    need(f'"{state}"', rel, f"{state} is not a declared relationship state")
# Family is declared, never earned: it must come off the roster.
need("bond.kin = self:isKinWith(id)", rival, "family is not read from the roster")
need("a.kin, b.kin = { b.id }, { a.id }", roster, "the roster declares no family")
relBody = body(rel)
if "kin = true" in relBody and "saved.kin == true" not in relBody:
    errors.append("kin is set from somewhere other than the roster")

# --- TITLES ARE DERIVED -----------------------------------------------------
need("function Titles.of", titles, "no title derivation")
need("Princess of Ashes", titles, "the brief's own example title is missing")
need("Might of Oceans", titles, "the brief's own example title is missing")
need("the Ocean's Wrath", titles, "the brief's own example title is missing")
titlesBody = body(titles)
for banned in ("rng", "math.random"):
    if banned in titlesBody:
        errors.append(f"titles are rolled ({banned}) -- a name that flickers "
                      f"reads as a bug when rivals use it in conversation")
# Nothing may STORE a title: a stored one outlives the team it describes.
for blob, name in ((body(main), "main"), (body(rival), "Rival")):
    if re.search(r"\.title\s*=\s*Titles\.", blob):
        errors.append(f"{name} stores a derived title")
need("if record.title then", all_source, "the Pokegear record surface shows no title")
need("function M:spokenNameOf", all_source, "no single accessor for the spoken name")
# Rivals name each other by title wherever one trainer speaks about another:
# news, phone gossip, scouting, tournament billing. A title that only appears
# on a record screen is a database field, not a reputation.
need("self:spokenNameOf(other)", all_source, "rivals do not use titles in the news")
need("self:spokenNameOf(rival)", all_source, "phone gossip does not use titles")
need("manager.spokenNameOf", tourn, "tournament announcements do not use titles")
need("spokenName", (root / "src" / "Scout.lua").read_text(encoding="utf-8"),
     "scouting reports do not use titles")
# ...and Scout must stay pure: it reads a stamped string, it does not reach
# into Titles itself.
if 'req("src/Titles")' in body((root / "src" / "Scout.lua").read_text(encoding="utf-8")):
    errors.append("Scout depends on Titles -- it is a pure module and the "
                  "caller already knows the name")
# ROOKIE has no elemental name: a title is earned.
need('if tier == "ROOKIE" then return nil end', titles,
     "an unknown trainer is handed a title")

# --- TOURNAMENTS: ONE A DAY, PER INITIATOR ----------------------------------
need("function Tournaments:mayInitiateToday", tourn, "no per-initiator limit")
need("function Tournaments:spendInitiation", tourn, "the allowance is never spent")
need("self.initiatedDay", tourn, "initiators share one key")
tournBody = body(tourn)
if "if not today then return true, nil end" not in tournBody:
    errors.append("a boot with no clock is locked out of tournaments entirely "
                  "rather than having the limit not apply")
# Rewards scale with BOTH halves the brief named, and both are bounded.
for token in ("Tournaments.PER_ENTRANT", "Tournaments.PER_WITNESS",
              "Tournaments.MAX_MULTIPLIER", "function Tournaments:witnesses"):
    need(token, tourn, f"reward scaling is incomplete ({token})")
need("t.witnessCount = self:witnesses(t)", tourn,
     "the crowd is not counted at the moment the event finishes")
need("M.MAX_PRIZE_MONEY", all_source, "prize money has no ceiling")

if errors:
    for e in errors:
        print("FAIL " + e)
    raise SystemExit(1)
print("life paths, titles and tournament limits static PASS")
