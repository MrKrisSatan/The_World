"""Static contract checks for badge-gated rival gifts (no Lua runtime needed)."""
from pathlib import Path
import json
import re
import sys

sys.path.insert(0, str(Path(__file__).resolve().parent))
from _version import at_least

root = Path(__file__).resolve().parents[1]
main = (root / "main.lua").read_text(encoding="utf-8")
manifest = json.loads((root / "manifest.json").read_text(encoding="utf-8"))
errors = []

# badge-gated gifts shipped in 1.32 and must survive every later release
errors.extend(x for x in [at_least(root, "1.32.0")] if x)
if not re.search(r"badges\s*>=\s*8\s+and\s+rival\.rng:chance\(0\.15\)", main):
    errors.append("missing single eight-badge 15% Master Ball roll")
if main.count('givePlayerItem("MASTER_BALL")') != 1:
    errors.append("Master Ball must have exactly one grant path")

table = re.search(r"local RIVAL_GIFT_BADGES\s*=\s*\{(.*?)\n\}", main, re.S)
if not table:
    errors.append("gift allowlist is missing")
else:
    body = table.group(1)
    zero_badge = set(re.findall(r"([A-Z_]+)\s*=\s*0", body))
    if zero_badge != {"POTION", "POKE_BALL"}:
        errors.append(f"zero-badge pool is {sorted(zero_badge)!r}")
    if "MASTER_BALL" in body:
        errors.append("Master Ball leaked into ordinary gift allowlist")

if main.count("rivalGiftAllowed(item, badges)") != 2:
    errors.append("both ordinary reward paths must use the badge gate")

if errors:
    raise SystemExit("\n".join(errors))
print("Badge-gated rival gifts and eight-badge Master Ball contract PASS")
