-- Standalone: lua5.1 tests/story_test.lua   (from mods/ai_rivals)
--
-- The 1.35.0 story model: milestones as a fixed closed set, mood and chapter
-- DERIVED from evidence, setbacks opened by defeat and closed by answering it.

local cache = {}
local function req(n)
  if cache[n] then return cache[n] end
  local f = assert(loadfile(n .. ".lua")); cache[n] = f(req, {}); return cache[n]
end
local Util, Story = req("src/Util"), req("src/Story")

local pass, fail = 0, 0
local function eq(a, b, m) if a == b then pass = pass + 1 else fail = fail + 1
  print(("FAIL %s (got %s want %s)"):format(m, tostring(a), tostring(b))) end end
local function ok(c, m) if c then pass = pass + 1 else fail = fail + 1; print("FAIL " .. m) end end

local function facts(over)
  local f = { tick = 0, badges = 0, party = 1, collection = 1, seen = 1,
    playerWins = 0, playerLosses = 0, rivalWins = 0, leagueAttempts = 0,
    champion = false, confidence = 1, streak = 0, shiny = false, rare = false,
    aceBattles = 0, evolved = false, teamChanges = 0,
    teamChangedSinceSetback = false, trainedSinceSetback = false, hasGoal = false }
  for k, v in pairs(over or {}) do f[k] = v end
  return f
end

-- 1. Every declared mood and chapter must be legal and labelled.
for _, m in ipairs(Story.MOODS) do
  ok(Story.isMood(m), m .. " is a legal mood")
  ok(type(Story.moodLabel(m)) == "string", m .. " has a label")
end
for _, c in ipairs(Story.CHAPTERS) do
  ok(Story.isChapter(c), c .. " is a legal chapter")
  ok(type(Story.chapterLabel(c)) == "string", c .. " has a label")
end

-- 2. Milestones are a FIXED closed set, so the save has a hard ceiling.
local story = Story.new()
eq(Story.unlockedCount(story), 0, "a new rival has unlocked nothing")
local everything = facts({ badges = 8, party = 6, collection = 60, seen = 120,
  playerWins = 3, playerLosses = 2, rivalWins = 4, leagueAttempts = 2,
  champion = true, shiny = true, rare = true, aceBattles = 40,
  evolved = true, teamChanges = 2 })
Story.check(story, everything, 10)
eq(Story.unlockedCount(story), Story.milestoneCount(),
   "a rival that has done everything unlocks every milestone and no more")
local again = Story.check(story, everything, 20)
eq(#again, 0, "a milestone unlocks exactly once")
-- an id this build no longer defines is dropped rather than carried
local orphan = Story.new({ unlocked = { FIRST_BADGE = 1, NOT_A_MILESTONE = 2 } })
eq(Story.has(orphan, "FIRST_BADGE"), true, "a known milestone survives a load")
eq(Story.has(orphan, "NOT_A_MILESTONE"), false, "an unknown milestone is dropped")

-- 3. Unlock order is stable, never pairs() order.
local function order()
  local st, ids = Story.new(), {}
  for _, m in ipairs(Story.check(st, everything, 1)) do ids[#ids + 1] = m.id end
  return table.concat(ids, ",")
end
eq(order(), order(), "milestones are reported in a stable order")

-- 4. Backfill is silent: a long pre-1.35 save records, it does not announce.
local migrated = Story.new()
Story.backfill(migrated, everything, 5)
eq(Story.unlockedCount(migrated), Story.milestoneCount(),
   "an old save records what it has genuinely earned")
eq(#Story.check(migrated, everything, 6), 0,
   "a backfilled save announces nothing afterwards")
eq(migrated.seeded, true, "a backfilled save is marked seeded")

-- 5. Setbacks: opened by defeat, closed only by answering the same opponent.
local arc = Story.new()
eq(Story.openSetback(arc, "player", 100), true, "a defeat opens a setback")
eq(Story.openSetback(arc, "green", 110), false, "a second defeat does not stack")
eq(Story.answerSetback(arc, "green", 120), false,
   "beating someone else does not answer the setback")
eq(Story.answerSetback(arc, "player", 130), true, "beating them does answer it")
eq(Story.answerSetback(arc, "player", 140), false, "it cannot be answered twice")
eq(Story.openSetbackAge(arc, 200), nil, "an answered setback is not open")

-- 6. THE CANONICAL ARC from roadmap §4, driven only by evidence.
--    CONFIDENT -> defeat -> FRUSTRATED -> training -> DETERMINED
--              -> team change -> REBUILDING -> rematch -> RESURGENT
local hero = Story.new()
hero.seeded = true
local f = facts({ badges = 3, confidence = 1.4, streak = 2 })
Story.advance(hero, f, 10)
eq(hero.mood, "CONFIDENT", "arc: starts confident")
eq(hero.chapter, "RISING", "arc: and is on the rise")

Story.openSetback(hero, "player", 20)
f = facts({ badges = 3, confidence = 0.9, streak = -1, tick = 21 })
Story.advance(hero, f, 21)
eq(hero.mood, "FRUSTRATED", "arc: the defeat makes it frustrated")
eq(hero.chapter, "SETBACK", "arc: and opens a setback")

f = facts({ badges = 3, confidence = 0.9, streak = -1, tick = 40,
            trainedSinceSetback = true })
Story.advance(hero, f, 40)
eq(hero.mood, "DETERMINED", "arc: training turns frustration into purpose")

f = facts({ badges = 3, confidence = 1.0, streak = 0, tick = 60,
            trainedSinceSetback = true, teamChangedSinceSetback = true,
            teamChanges = 1 })
Story.advance(hero, f, 60)
eq(hero.chapter, "REBUILDING", "arc: changing the team is rebuilding")

Story.answerSetback(hero, "player", 80)
f = facts({ badges = 4, confidence = 1.3, streak = 1, tick = 81, teamChanges = 1 })
Story.advance(hero, f, 81)
eq(hero.chapter, "RESURGENT", "arc: beating them back is the payoff")
eq(hero.mood, "CONFIDENT", "arc: and confidence returns")

-- the arc is replayable: identical evidence, identical story
local function replayArc()
  local h = Story.new(); h.seeded = true
  Story.advance(h, facts({ badges = 3, confidence = 1.4, streak = 2 }), 10)
  Story.openSetback(h, "player", 20)
  Story.advance(h, facts({ confidence = 0.9, streak = -1, tick = 21 }), 21)
  Story.answerSetback(h, "player", 30)
  Story.advance(h, facts({ confidence = 1.3, streak = 1, tick = 31 }), 31)
  return h.chapter .. "/" .. h.mood
end
eq(replayArc(), replayArc(), "identical evidence produces an identical story")

-- 7. Chapters can move BACKWARDS -- a contender who is beaten is in setback
--    again, which is what makes the §30 postgame work without extra machinery.
local champ = Story.new(); champ.seeded = true
Story.advance(champ, facts({ badges = 8, leagueAttempts = 2, tick = 1 }), 1)
eq(champ.chapter, "CONTENDER", "eight badges is a contender")
Story.openSetback(champ, "player", 2)
Story.advance(champ, facts({ badges = 8, leagueAttempts = 2, tick = 3 }), 3)
eq(champ.chapter, "SETBACK", "a contender that is beaten is in setback again")
Story.advance(champ, facts({ badges = 8, champion = true, tick = 4 }), 4)
eq(champ.chapter, "CHAMPION", "the title outranks everything")
eq(champ.mood, "TRIUMPHANT", "and reads as triumphant")

-- 8. Corrupt saves cannot yield an illegal mood or chapter.
local dirty = Story.new({ mood = "ECSTATIC", chapter = "ENDGAME",
  moodSince = -5, unlocked = { [7] = 1 } })
ok(Story.isMood(dirty.mood), "a corrupt mood is repaired")
ok(Story.isChapter(dirty.chapter), "a corrupt chapter is repaired")
ok(dirty.moodSince >= 0, "a corrupt timestamp is repaired")
eq(Story.unlockedCount(dirty), 0, "a non-string milestone key is dropped")

-- 9. Round trip.
local round = Story.new(Story.serialize(hero))
eq(round.chapter, hero.chapter, "the chapter survives a save/load round trip")
eq(Story.unlockedCount(round), Story.unlockedCount(hero),
   "milestones survive a save/load round trip")

-- 10. Determinism: no dice, no clock.
eq(Story.mood(hero, facts({ confidence = 1.4, streak = 2 })),
   Story.mood(hero, facts({ confidence = 1.4, streak = 2 })),
   "mood derivation is pure")

-- 11. §31: only flagged milestones are news.
local quiet, loud = 0, 0
for _, m in ipairs(Story.MILESTONES) do
  if m.news then loud = loud + 1 else quiet = quiet + 1 end
end
ok(quiet > 0, "some milestones are deliberately quiet")
ok(loud < Story.milestoneCount(), "not every milestone interrupts the player")
eq(Story.milestoneHeadline("X", Story.MILESTONE_BY_ID.FIRST_CATCH), nil,
   "a quiet milestone produces no headline")
ok(Story.milestoneHeadline("X", Story.MILESTONE_BY_ID.ALL_BADGES) ~= nil,
   "a notable milestone produces a headline")

print(("\n%d passed, %d failed"):format(pass, fail))
os.exit(fail == 0 and 0 or 1)
