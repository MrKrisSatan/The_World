-- Standalone: lua5.1 tests/team_divergence_test.lua  (from mods/ai_rivals)
--
-- Roadmap §39: four rivals must not converge into identical optimal agents.
-- The team-identity system is one of the places that can silently fail, and it
-- fails quietly -- everything still works, the rivals just all build the same
-- team. So this measures divergence directly, from an IDENTICAL candidate pool
-- and identical opportunities, with only the identity differing.

local cache = {}
local function req(n)
  if cache[n] then return cache[n] end
  local f = assert(loadfile(n .. ".lua")); cache[n] = f(req, {}); return cache[n]
end
local Util, Rival, TeamPlan = req("src/Util"), req("src/Rival"), req("src/TeamPlan")
local PERS, ROSTER = req("data/personalities"), req("data/rivals")

local pass, fail = 0, 0
local function ok(c, m) if c then pass = pass + 1 else fail = fail + 1; print("FAIL " .. m) end end

-- A pool wide enough that different identities have something to disagree
-- about: attackers, walls, speedsters, unevolved forms, status users.
local POOL, DATA = {}, { pokemon = {}, moves = {
  TACKLE = { power = 40, type = "NORMAL" }, EMBER = { power = 40, type = "FIRE" },
  BUBBLE = { power = 40, type = "WATER" }, VINE = { power = 40, type = "GRASS" },
  GROWL = { power = 0, type = "NORMAL" }, TOXIC = { power = 0, type = "POISON" },
}, constants = { fallbackMove = "TACKLE" }, type_chart = { matchups = {} } }
local TYPES = { "FIRE", "WATER", "GRASS", "NORMAL" }
local MOVES = { "EMBER", "BUBBLE", "VINE", "TACKLE" }
for i = 1, 24 do
  local kind = i % 4
  local t = TYPES[(i % #TYPES) + 1]
  local base
  if kind == 0 then base = { hp = 60, attack = 120, defense = 55, speed = 95, special = 60 }
  elseif kind == 1 then base = { hp = 110, attack = 45, defense = 115, speed = 35, special = 55 }
  elseif kind == 2 then base = { hp = 55, attack = 70, defense = 50, speed = 125, special = 70 }
  else base = { hp = 50, attack = 52, defense = 52, speed = 48, special = 60 } end
  local id = "MON_" .. i
  DATA.pokemon[id] = { baseStats = base, types = { t },
    evolutions = kind == 3 and { { level = 16, species = "MON_1" } } or nil,
    level1Moves = { MOVES[(i % #MOVES) + 1], kind == 1 and "TOXIC" or "GROWL" },
    learnset = {} }
  POOL[#POOL + 1] = id
end

local ctx = { data = DATA, personalities = PERS,
              graph = { has = function() return false end },
              gyms = { order = {}, byBadge = {} } }

-- Each rival gets the SAME pool and the SAME number of battles. Only the
-- identity differs, so any divergence is caused by this system alone.
local rivals, teams = {}, {}
for i = 1, #ROSTER do
  local r = Rival.new(ROSTER[i], ctx)
  r.ticks = 0
  r.party = {}
  for _, sp in ipairs(POOL) do
    local slot = r:addPokemon(sp, 25)
    if slot and #r.party > 6 then
      table.remove(r.party)
      r:storePokemon(slot)
    end
  end
  rivals[#rivals + 1] = r
end

-- Run them through identical battle traffic so type credit and service accrue.
for tick = 1, 3000 do
  for _, r in ipairs(rivals) do
    r.ticks = tick
    if tick % 7 == 0 then r:creditLeadBattle(tick % 3 ~= 0) end
    if tick % 400 == 0 then
      -- rotate the lead so different Pokemon accumulate service
      local slot = table.remove(r.party, 1)
      if slot then r.party[#r.party + 1] = slot end
    end
  end
end

local signatures, styles, aces, types = {}, {}, {}, {}
for _, r in ipairs(rivals) do
  local ordered = r:teamFor({})
  local six = {}
  for i = 1, math.min(6, #ordered) do six[#six + 1] = ordered[i].species end
  local signature = table.concat(six, ",")
  signatures[signature] = (signatures[signature] or 0) + 1
  styles[r:teamStyle()] = true
  aces[tostring(r:favouriteSpecies())] = true
  types[tostring(r:preferredType())] = true
  print(("  %-8s %-16s ace=%-8s type=%-7s | %s"):format(
    r.id, TeamPlan.label(r:teamStyle()), tostring(r:favouriteSpecies()),
    tostring(r:preferredType()), signature))
end

local function count(t) local n = 0; for _ in pairs(t) do n = n + 1 end; return n end
print(("distinct teams=%d styles=%d aces=%d types=%d")
  :format(count(signatures), count(styles), count(aces), count(types)))

ok(count(signatures) >= 3,
   "four rivals build at least three different teams from an identical pool")
for signature, n in pairs(signatures) do
  ok(n < #rivals, "no single team is fielded by every rival: " .. signature:sub(1, 30))
end
ok(count(styles) >= 3, "the roster holds at least three distinct identities")

-- and the identity must be STABLE: re-deriving without new evidence must not
-- shuffle the team, or the player would never learn to recognise it
for _, r in ipairs(rivals) do
  local a, b = r:teamFor({}), r:teamFor({})
  local same = true
  for i = 1, math.min(6, #a) do
    if a[i].species ~= b[i].species then same = false end
  end
  ok(same, r.id .. "'s team selection is stable between reads")
end

-- PHASE 2. Above, every rival received identical traffic, which isolates the
-- identity as the only variable -- and correctly produces the same favourite
-- for all four, because they all did the same things. In play they do not: a
-- Collector catches more, a Challenger fights more. Give them the different
-- histories their personalities actually produce and the favourite, the
-- preferred type and the team must all come apart.
print("phase 2: divergent histories")
local p2, aces2, types2, sig2 = {}, {}, {}, {}
for i = 1, #ROSTER do
  local r = Rival.new(ROSTER[i], ctx)
  r.ticks = 0
  r.party = {}
  -- each rival ends up with a different slice of the same world
  for j = i, #POOL, 2 do
    local slot = r:addPokemon(POOL[j], 20 + (j % 9))
    if slot and #r.party > 6 then table.remove(r.party); r:storePokemon(slot) end
  end
  p2[#p2 + 1] = r
end
for tick = 1, 3000 do
  for i, r in ipairs(p2) do
    r.ticks = tick
    -- fight frequency follows the personality, as it does in the real loop
    local rate = math.max(2, math.floor(1 / (r.personality.rivalFightChance or 0.1)))
    if tick % rate == 0 then r:creditLeadBattle((tick + i) % 3 ~= 0) end
    if tick % (300 + i * 90) == 0 then
      local slot = table.remove(r.party, 1)
      if slot then r.party[#r.party + 1] = slot end
    end
  end
end
for _, r in ipairs(p2) do
  local ordered = r:teamFor({})
  local six = {}
  for i = 1, math.min(6, #ordered) do six[#six + 1] = ordered[i].species end
  sig2[table.concat(six, ",")] = true
  aces2[tostring(r:favouriteSpecies())] = true
  types2[tostring(r:preferredType())] = true
  print(("  %-8s %-16s ace=%-8s type=%-7s | %s"):format(
    r.id, TeamPlan.label(r:teamStyle()), tostring(r:favouriteSpecies()),
    tostring(r:preferredType()), table.concat(six, ",")))
end
print(("distinct teams=%d aces=%d types=%d")
  :format(count(sig2), count(aces2), count(types2)))
ok(count(sig2) >= 3, "divergent histories produce at least three distinct teams")
ok(count(aces2) >= 2, "divergent histories produce different favourites")
ok(count(types2) >= 2, "divergent histories produce different preferred types")

print(("\n%d passed, %d failed"):format(pass, fail))
os.exit(fail == 0 and 0 or 1)
