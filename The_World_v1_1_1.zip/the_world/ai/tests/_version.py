"""Shared version helper for the static contract suites.

A literal version pin in a contract test breaks at every release and teaches
whoever is releasing to edit tests until they pass, which is exactly backwards.
Each suite asserts the FLOOR at which its feature shipped instead, so a test
fails when a feature regresses rather than when the number moves.
"""
import json
from pathlib import Path


def version(root):
    raw = json.loads((Path(root) / "manifest.json").read_text(encoding="utf-8"))
    return raw.get("version", "0.0.0")


def tuple_of(text):
    parts = []
    for chunk in str(text).split("."):
        digits = "".join(c for c in chunk if c.isdigit())
        parts.append(int(digits) if digits else 0)
    while len(parts) < 3:
        parts.append(0)
    return tuple(parts[:3])


def at_least(root, floor):
    """Return an error string when the shipped version predates `floor`."""
    shipped = version(root)
    if tuple_of(shipped) < tuple_of(floor):
        return f"manifest version {shipped} is older than {floor}"
    return None
