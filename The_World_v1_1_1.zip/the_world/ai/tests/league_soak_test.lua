-- Standalone: lua5.1 tests/league_soak_test.lua  (from mods/ai_rivals)
--
-- THE REGRESSION GUARD FOR THE 1500-ATTEMPT BUG.
--
-- Before 1.39 the League retry gate was a flat 16-tick cooldown and nothing
-- else, so a rival whose team the Elite Four could beat attempted it 1500
-- times over ten hours of play, lost all 1500, and logged a news item every
-- time. Nothing errored. It was simply the Gym path's old bug -- "a static
-- confidence gate made a rival attempt Brock 90 times and lose 90 times" --
-- living on in a path written from the same template and never revisited.
--
-- So this measures the thing that broke: how many doomed attempts a stuck
-- rival makes, and how many it makes once it actually trains.

local cache = {}
local function req(n)
  if cache[n] then return cache[n] end
  local f = assert(loadfile(n .. ".lua")); cache[n] = f(req, {}); return cache[n]
end
local Util, League = req("src/Util"), req("src/League")

local pass, fail = 0, 0
local function ok(c, m) if c then pass = pass + 1 else fail = fail + 1; print("FAIL " .. m) end end

local TICKS = 24000            -- ~10 hours of play

-- CASE 1: a rival that never gets any stronger. It should give up trying
-- rather than grinding the Elite Four forever.
local stuck, attempts = League.newRecord(), 0
for tick = 1, TICKS do
  League.tick(stuck)
  if League.mayAttempt(stuck, 200) then
    attempts = attempts + 1
    League.recordAttempt(stuck, 4, false, { strength = 200 })
  end
end
print(("stuck rival: %d attempts over %d ticks (was 1500)"):format(attempts, TICKS))
ok(attempts > 0, "a stuck rival does still try")
ok(attempts < 40, "but nowhere near the 1500 doomed attempts of the old gate")
local wall, count = League.wall(stuck)
ok(wall == 4, "and the record names what is stopping it")
ok(count == attempts, "having counted every failure")

-- CASE 2: a rival that trains between runs. It should keep getting back in --
-- the escalation must gate the HOPELESS, not punish the diligent.
local trainer, tries, strength = League.newRecord(), 0, 200
for tick = 1, TICKS do
  League.tick(trainer)
  strength = strength + 1              -- it is out there training
  if League.mayAttempt(trainer, strength) then
    tries = tries + 1
    League.recordAttempt(trainer, 4, false, { strength = strength })
  end
end
print(("training rival: %d attempts over %d ticks"):format(tries, TICKS))
ok(tries > attempts, "a rival that trains gets more attempts than one that does not")
ok(tries < 200, "but is still paced rather than grinding")

-- CASE 3: a rival that eventually wins. The record must end coherent.
local winner, runs, cleared = League.newRecord(), 0, false
local power = 200
for tick = 1, TICKS do
  League.tick(winner)
  power = power + 2
  if League.mayAttempt(winner, power) then
    runs = runs + 1
    local win = power > 900
    League.recordAttempt(winner, win and 5 or 4, win, { strength = power })
    if win and not cleared then
      cleared = true
      League.beginReign(winner, tick)
    end
  end
end
print(("eventual champion: %d runs, %d clears"):format(runs, winner.clears))
ok(cleared, "a rival that keeps improving eventually clears the League")
ok(winner.clears >= 1, "and the clear is recorded")
ok(winner.reigns >= 1, "and the reign began")
ok(winner.bestStage == 5, "and the best stage is the full League")

-- CASE 4: bounds across the whole run.
for name, record in pairs({ stuck = stuck, trainer = trainer, winner = winner }) do
  ok(Util.count(record.walls) <= League.MAX_STAGE,
     name .. ": the wall table stays capped")
  local saved = League.serializeRecord(record)
  ok(Util.count(saved.walls) <= League.MAX_STAGE,
     name .. ": the SERIALIZED wall table stays capped")
  ok(record.attempts <= 99999, name .. ": attempts stay capped")
  ok((record.cooldown or 0) <= League.MAX_COOLDOWN,
     name .. ": the cooldown stays capped")
end

-- CASE 5: the news budget. Every attempt is one item, so the attempt count IS
-- the news count -- which is why the old gate produced 1500 lines.
ok(attempts < 40, "a stuck rival produces well under forty League news items")

print(("\n%d passed, %d failed"):format(pass, fail))
os.exit(fail == 0 and 0 or 1)
