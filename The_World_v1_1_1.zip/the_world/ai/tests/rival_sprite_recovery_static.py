from pathlib import Path

text = (Path(__file__).resolve().parents[1] / "src" / "manager" / "Materialize.lua").read_text(encoding="utf-8")

assert "function M:reconcileRivalSprites(mapId)" in text
assert "self:reconcileRivalSprites(mapId)" in text
assert "if not entity then" in text
assert "self.spawned[rival.id] = nil" in text
assert "pcall(function() self:spawnFor(mapId) end)" in text

spawn = text.index("function M:spawnFor(mapId)")
gate = text.index("if rival.map == mapId and not self.spawned[rival.id] then", spawn)
reconcile = text.index("self:reconcileRivalSprites(mapId)", spawn)
assert reconcile < gate, "stale handles must be reconciled before the spawn gate"

print("rival sprite stale-handle recovery: OK")
