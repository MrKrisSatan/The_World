-- DIALOGUE VOLUME AND REACHABILITY (5.0.8)
-- ==================================================================
-- §36: dead content is the failure mode of adding content. A bank that ships
-- ten thousand lines and delivers three thousand of them looks exactly like
-- one that works -- nothing errors, nothing is empty, nothing duplicates. The
-- only way to know is to COUNT what materialises.
--
-- That is not hypothetical. The first cut of src/ClauseMix.lua paired
-- situations and attitudes with two independent modular indices, which
-- repeats after lcm(ns, na) rather than covering ns * na. Every cell quietly
-- delivered about a third of its cap. This suite is what found it, and the
-- coverage check at the bottom is what stops it coming back.
--
-- Run from the MOD directory:  lua5.1 tests/dialogue_volume_test.lua

local cache = {}
local function req(name)
  if cache[name] ~= nil then return cache[name] end
  local chunk = assert(loadfile(name .. ".lua"), "cannot load " .. name)
  local value = chunk(req, {})
  cache[name] = value
  return value
end

local failures, checks = 0, 0
local function check(ok, label)
  checks = checks + 1
  if not ok then
    failures = failures + 1
    print("FAIL: " .. label)
  end
  return ok
end

-- ------------------------------------------------------------------
-- 1. ClauseMix covers the whole grid
-- ------------------------------------------------------------------
local ClauseMix = req("src/ClauseMix")

for _, dims in ipairs({ {10,10}, {12,24}, {6,10}, {8,12}, {5,5}, {3,4}, {1,9} }) do
  local ns, na = dims[1], dims[2]
  local A, B = {}, {}
  for i = 1, ns do A[i] = "s" .. i end
  for i = 1, na do B[i] = "a" .. i end
  local all = ClauseMix.cross(A, B, ns * na)
  check(#all == ns * na,
    ("ClauseMix covers %dx%d fully (got %d of %d)"):format(ns, na, #all, ns * na))
  local seen, dupes = {}, 0
  for _, line in ipairs(all) do
    if seen[line] then dupes = dupes + 1 end
    seen[line] = true
  end
  check(dupes == 0, ("ClauseMix %dx%d emits no duplicate pair"):format(ns, na))
  -- and a cap below the grid must still deliver exactly the cap
  local capped = ClauseMix.cross(A, B, math.min(15, ns * na))
  check(#capped == math.min(15, ns * na),
    ("ClauseMix honours a cap on %dx%d (got %d)"):format(ns, na, #capped))
end

-- ------------------------------------------------------------------
-- 2. Rival lines
-- ------------------------------------------------------------------
local D = req("data/dialogue")
local PERSONALITIES = req("data/personalities")

local TOKENS = {
  NAME = 8, TITLE = 14, TITLECAP = 14, PLAYER = 8, RIVAL = 8, BADGES = 1,
  N = 5, NEXT = 8, CITY = 10, LAST = 8, MON = 9, ACE = 9, WINS = 1,
  LOSSES = 1, RECORD = 3, REL = 12, STYLE = 8, MOOD = 9,
}
local function probe(line)
  return (line:gsub("{([A-Z]+)}", function(k)
    return string.rep("x", TOKENS[k] or 6)
  end))
end

local BUCKETS = {
  "greeting", "challenge", "scoreRemind", "eliteChampion", "afterWin",
  "afterLoss", "gymLoss", "gauntletWait", "gauntletChallenge",
  "gauntletNeedStarter", "badgeNews", "relationship", "mood", "formerly",
  "career",
}

local rivalTotal, rivalCells, emptyCells = 0, 0, 0
local wideFirst, wideRest = 0, 0
local worstPath = ""

local function measure(path, list)
  rivalCells = rivalCells + 1
  if #list == 0 then
    emptyCells = emptyCells + 1
    print("EMPTY CELL: " .. path)
    return
  end
  for _, line in ipairs(list) do
    rivalTotal = rivalTotal + 1
    for page in (probe(line) .. "\f"):gmatch("(.-)\f") do
      local row = 0
      for text in page:gmatch("[^\n\v]+") do
        row = row + 1
        if row == 1 then
          if #text > 26 then
            wideFirst = wideFirst + 1
            worstPath = path
          end
        elseif #text > 18 then
          wideRest = wideRest + 1
        end
      end
    end
  end
end

local function walk(path, node)
  if type(node) ~= "table" then return end
  if type(node[1]) == "string" then measure(path, node) return end
  local keys = {}
  for k in pairs(node) do keys[#keys + 1] = k end
  table.sort(keys, function(a, b) return tostring(a) < tostring(b) end)
  for _, k in ipairs(keys) do walk(path .. "." .. tostring(k), node[k]) end
end

for _, bucket in ipairs(BUCKETS) do walk(bucket, D[bucket]) end

check(rivalTotal >= 10000,
  ("rival lines >= 10000 (got %d)"):format(rivalTotal))
check(emptyCells == 0, ("no empty rival cell (got %d)"):format(emptyCells))
-- The envelope is the widest row the HAND-WRITTEN content already ships, not
-- an aspiration: a build that renders 4.7.0 correctly renders these too.
check(wideFirst == 0,
  ("no first row past 26 columns (got %d, e.g. %s)"):format(wideFirst, worstPath))
-- 5.0.9: every pre-5.0.8 line is reflowed before anything is generated, so
-- the whole bank fits now -- not just the new half. 65 hand-written lines
-- overflowed, including the entire 4.7.0 career formula at 51 columns.
check(wideRest == 0,
  ("no continuation row past 18 columns (got %d)"):format(wideRest))
check((D.reflowedLineCount or 0) > 0, "the reflow pass actually reflowed something")

-- ------------------------------------------------------------------
-- 3. Every personality speaks in every situation
-- ------------------------------------------------------------------
-- This is the check that would have caught the original problem: twelve of
-- the sixteen personalities had NO arms at all and fell through to `default`,
-- which is why every rival except Shawn sounded the same.
local VOICES = req("data/voices")
local missingVoice, missingArm = {}, {}
for id in pairs(PERSONALITIES) do
  if not VOICES[id] then missingVoice[#missingVoice + 1] = id end
end
table.sort(missingVoice)
check(#missingVoice == 0,
  "every personality in data/personalities has a voice pack (missing: "
  .. table.concat(missingVoice, ", ") .. ")")

for _, reg in ipairs({ "DRIVE", "EDGE", "UP", "DOWN" }) do
  for id, pack in pairs(VOICES) do
    if not (pack[reg] and pack[reg][1]) then
      missingArm[#missingArm + 1] = id .. "." .. reg
    end
  end
end
table.sort(missingArm)
check(#missingArm == 0,
  "every voice pack fills every register (missing: "
  .. table.concat(missingArm, ", ") .. ")")

local statefulBuckets = {
  { D.greeting, "greeting" },
  { D.relationship, "relationship" },
  { D.mood, "mood" },
}
for _, entry in ipairs(statefulBuckets) do
  local bucket, label = entry[1], entry[2]
  for state, cell in pairs(bucket or {}) do
    if type(cell) == "table" then
      for id in pairs(PERSONALITIES) do
        check(type(cell[id]) == "table" and cell[id][1] ~= nil,
          ("%s.%s has an arm for %s"):format(label, tostring(state), id))
      end
    end
  end
end

-- Every badge milestone must read differently. A shared bank made
-- badgeNews[1..8] byte-identical in the first draft: eight moments, one
-- sentence, the tokens doing all the work.
local badgeSigs = {}
for n = 1, 8 do
  local cell = (D.badgeNews or {})[n]
  local arm = cell and cell.CHALLENGER
  check(arm and arm[1], ("badgeNews[%d] has a CHALLENGER arm"):format(n))
  if arm then
    local sig = table.concat(arm, "~")
    check(not badgeSigs[sig],
      ("badgeNews[%d] differs from badge %s"):format(n, tostring(badgeSigs[sig])))
    badgeSigs[sig] = n
  end
end

-- src/Simulation.lua sets newsPending = "QUALIFIED"; before 5.0.8 no bucket
-- existed for it and a rival qualifying for the LEAGUE said nothing.
check(type((D.badgeNews or {}).QUALIFIED) == "table"
  and (D.badgeNews.QUALIFIED.default or {})[1] ~= nil,
  "badgeNews.QUALIFIED exists")

-- ------------------------------------------------------------------
-- 4. Team Rocket
-- ------------------------------------------------------------------
local RD = req("data/rocket_dialogue")
local ROCKET_DATA = req("data/rocket")
local lines = RD.build()

check(lines.count >= 10000,
  ("rocket lines >= 10000 (got %d)"):format(lines.count))

-- Every rank the promotion ladder can produce, and every role
-- data/rocket.lua assigns, must have its own cell. Before 5.0.8 the roles
-- were assigned and never once audible.
local RANKS = { "Grunt", "Executive", "Leader" }
local rocketEmpty = 0
for context in pairs(RD.situations) do
  for _, rank in ipairs(RANKS) do
    local byRank = lines[context][rank]
    check(type(byRank) == "table", ("rocket %s/%s exists"):format(context, rank))
    for _, role in ipairs(ROCKET_DATA.roles) do
      local cell = byRank and byRank[role]
      if not (type(cell) == "table" and cell[1]) then
        rocketEmpty = rocketEmpty + 1
        print("EMPTY ROCKET CELL: " .. context .. "/" .. rank .. "/" .. role)
      end
    end
    check(type(byRank.default) == "table" and byRank.default[1] ~= nil,
      ("rocket %s/%s has a role fallback"):format(context, rank))
  end
end
check(rocketEmpty == 0, ("no empty rocket cell (got %d)"):format(rocketEmpty))

-- Rank must actually change the voice. If Grunt and Leader produce the same
-- cell then the ladder is decoration.
for context in pairs(RD.situations) do
  local grunt = table.concat(lines[context].Grunt.Scout or {}, "~")
  local leader = table.concat(lines[context].Leader.Scout or {}, "~")
  check(grunt ~= leader, ("rocket %s: Grunt and Leader differ"):format(context))
  local scout = table.concat(lines[context].Grunt.Scout or {}, "~")
  local thief = table.concat(lines[context].Grunt.Thief or {}, "~")
  check(scout ~= thief, ("rocket %s: Scout and Thief differ"):format(context))
end

-- The speaker label is 18 columns on its own ("Executive Marlowe:"), so the
-- sentence has to start underneath it rather than beside it.
local BoxFit = req("src/BoxFit")
local rocketWide = 0
for context in pairs(RD.situations) do
  for _, rank in ipairs(RANKS) do
    for _, role in ipairs(ROCKET_DATA.roles) do
      for _, sentence in ipairs(lines[context][rank][role] or {}) do
        local out = BoxFit.label("Executive Marlowe:", sentence)
        for page in (out .. "\f"):gmatch("(.-)\f") do
          for text in page:gmatch("[^\n\v]+") do
            if #text > 18 then rocketWide = rocketWide + 1 end
          end
        end
      end
    end
  end
end
check(rocketWide == 0, ("no rocket row past 18 columns (got %d)"):format(rocketWide))

-- ------------------------------------------------------------------
print(("dialogue volume: %d rival lines in %d cells, %d rocket lines"):format(
  rivalTotal, rivalCells, lines.count))
print(("continuation rows past 18 columns (pre-5.0.8 hand-written): %d"):format(wideRest))
print(("%d checks, %d failures"):format(checks, failures))
if failures > 0 then os.exit(1) end
