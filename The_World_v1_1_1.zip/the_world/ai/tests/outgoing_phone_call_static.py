from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]
main = (ROOT / "main.lua").read_text(encoding="utf-8")
all_source = main + "\n" + "\n".join(p.read_text(encoding="utf-8") for p in (ROOT / "src").rglob("*.lua"))
start = all_source.index("function M:callContact(contactId)")
end = all_source.index("function M:pushPhoneTrainerBattle", start)
body = all_source[start:end]
assert "if not Comms.mayCall" not in body, "outgoing phone calls must not use incoming-call busy/cooldown gate"
assert 'if record.kind == "RIVAL" then' in body
assert "return self:callRival(rival)" in body
assert 'Comms.record(self.comms, contactId, "REMATCH"' in body
print("outgoing Pokégear call dispatch PASS")
