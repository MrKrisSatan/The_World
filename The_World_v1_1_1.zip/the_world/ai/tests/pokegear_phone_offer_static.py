from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
POKE = (ROOT / "src" / "Pokegear.lua").read_text()
MAIN = (ROOT / "main.lua").read_text()
ALL = MAIN + "\n" + "\n".join(p.read_text() for p in (ROOT / "src").rglob("*.lua"))

assert "manager:acceptPendingPhoneOffer(c)" in POKE
assert "manager:declinePendingPhoneOffer(c)" in POKE
assert "function M:acceptPendingPhoneOffer(recordOrId)" in ALL
assert "function M:declinePendingPhoneOffer(recordOrId)" in ALL
assert 'type(recordOrId) == "table"' in ALL
assert 'type(recordOrId) == "string"' in ALL
# The update loop still clears the pending slot after pushing the screen; this
# regression specifically verifies the screen no longer depends on that slot.
assert 'mod.ui.push(game, "AIR_RivalGearOffer", { contact = M.pendingPhoneOffer })' in ALL
assert 'M.pendingPhoneOffer = nil' in ALL
print("pokegear phone offer static checks passed")
