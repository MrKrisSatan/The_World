from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
main=(ROOT/"main.lua").read_text()
persist=(ROOT/"src/manager/Persistence.lua").read_text()
manifest=(ROOT/"manifest.json").read_text()

entered=main[main.index('mod.events:on("map.entered"'):main.index('-- The Choose Your Hero')]
assert "M.pendingMapMaterialize" in entered
assert "M:spawnFor(mapId)" not in entered
assert "M.rocket:spawnFor(mapId" not in entered
assert "M.rangers:spawnFor(mapId" not in entered
assert "if M.pendingMapMaterialize then" in main
assert "pending.age >= 0.20" in main
assert "M:overworldRunnerIdle()" in main
assert "M:spawnFor(pending.mapId)" in main
assert "self.pendingMapMaterialize = nil" in persist
assert '"version": "7.3.6"' in manifest
print("7.3.6 deferred materialisation checks passed")
