-- Standalone: lua5.1 tests/rival_story_test.lua  (from mods/ai_rivals)
--
-- The 1.35.0 story through real Rival objects. The point of this suite is that
-- the narrator READS the other three systems rather than keeping its own copy:
-- the streak comes from 1.32 Memory, the rebuild from 1.34 TeamPlan, the
-- social read from 1.33 Relationships. If any of those stops feeding it, these
-- assertions fail rather than the story quietly going flat.

local cache = {}
local function req(n)
  if cache[n] then return cache[n] end
  local f = assert(loadfile(n .. ".lua")); cache[n] = f(req, {}); return cache[n]
end
local Util, Rival, Story = req("src/Util"), req("src/Rival"), req("src/Story")
local TeamPlan = req("src/TeamPlan")
local PERS, ROSTER = req("data/personalities"), req("data/rivals")

local pass, fail = 0, 0
local function eq(a, b, m) if a == b then pass = pass + 1 else fail = fail + 1
  print(("FAIL %s (got %s want %s)"):format(m, tostring(a), tostring(b))) end end
local function ok(c, m) if c then pass = pass + 1 else fail = fail + 1; print("FAIL " .. m) end end

local DATA = {
  pokemon = {
    MON = { baseStats = { hp = 60, attack = 80, defense = 60, speed = 70, special = 60 },
            types = { "NORMAL" }, level1Moves = { "TACKLE" }, learnset = {} },
  },
  moves = { TACKLE = { power = 40, type = "NORMAL" } },
  constants = { fallbackMove = "TACKLE" }, type_chart = { matchups = {} },
}
local ctx = { data = DATA, personalities = PERS,
              graph = { has = function() return false end },
              gyms = { order = {}, byBadge = {} } }

local function make(i)
  local r = Rival.new(ROSTER[i or 1], ctx)
  r.ticks = 0
  r.story.seeded = true   -- a new game, not a migration
  return r
end

-- 1. A brand new rival has a story, and it is the blank one.
local r = make()
eq(r:mood(), "CONTENT", "a new rival starts content")
eq(r:chapter(), "ORIGIN", "a new rival starts at the origin")
eq(Story.unlockedCount(r:ensureStory()), 0, "and has achieved nothing yet")
ok(type(r:moodLabel()) == "string", "the mood has a display label")

-- 2. The streak is READ from 1.32 memory, not kept a second time.
eq(r:recentStreak(), 0, "no battles is no streak")
for i = 1, 3 do
  r:rememberPlayerBattle({ tick = i, rivalWon = false, location = "X" })
end
ok(r:recentStreak() <= -3, "consecutive defeats read as a losing streak")
r:rememberPlayerBattle({ tick = 4, rivalWon = true, location = "X" })
eq(r:recentStreak(), 1, "a win breaks the losing streak rather than adding to it")

-- 3. Milestones fire off facts the rival already carries.
local m = make(2)
m.ticks = 10
local gained = select(1, m:advanceStory(10))
eq(#gained, 0, "a rival with nothing has unlocked nothing")
m:addPokemon("MON", 5)
m:addPokemon("MON", 5)
m.ticks = 20
gained = select(1, m:advanceStory(20))
local ids = {}
for _, g in ipairs(gained) do ids[g.id] = true end
ok(ids.FIRST_CATCH, "a second Pokemon is the first catch")
eq(Story.has(m:ensureStory(), "FIRST_CATCH"), true, "and it is remembered")
m.ticks = 30
eq(#select(1, m:advanceStory(30)), 0, "it does not fire again")

-- 4. THE ARC, end to end, through the real objects.
local hero = make(3)
hero.ticks = 100
hero.confidence = 1.4
hero:rememberPlayerBattle({ tick = 99, rivalWon = true, location = "X" })
hero:rememberPlayerBattle({ tick = 100, rivalWon = true, location = "X" })
hero:advanceStory(100)
eq(hero:mood(), "CONFIDENT", "arc: confident after two wins")

-- the player beats it
hero.ticks = 110
hero.confidence = 0.9
hero:rememberPlayerBattle({ tick = 110, rivalWon = false, location = "X" })
ok(hero:noteDefeat("player", 110), "arc: the defeat opens a setback")
hero:advanceStory(110)
eq(hero:chapter(), "SETBACK", "arc: the chapter turns to setback")
ok(hero:mood() == "FRUSTRATED" or hero:mood() == "HUMBLED",
   "arc: and the mood turns with it")

-- it goes and trains
hero.ticks = 140
hero:noteTrained(140)
hero:advanceStory(140)
eq(hero:mood(), "DETERMINED", "arc: training turns the mood to determined")

-- it rebuilds its team -- this comes from 1.34, not from the story
hero.ticks = 160
for _ = 1, 40 do hero:observeTeamEvidence("BEATEN_BADLY") end
ok((hero.teamChangedAt or 0) >= 110, "arc: the rebuild is stamped after the defeat")
hero:advanceStory(160)
eq(hero:chapter(), "REBUILDING", "arc: rebuilding the team turns the chapter")

-- it wins the rematch
hero.ticks = 200
hero.confidence = 1.3
hero:rememberPlayerBattle({ tick = 200, rivalWon = true, location = "X" })
ok(hero:noteVictory("player", 200), "arc: beating them answers the setback")
hero:advanceStory(200)
eq(hero:chapter(), "RESURGENT", "arc: and the chapter pays it off")

-- 5. A rebuild BEFORE the defeat must not count as answering it.
local early = make(4)
early.ticks = 50
for _ = 1, 40 do early:observeTeamEvidence("OUTSPED") end
early.ticks = 100
early:noteDefeat("player", 100)
early:advanceStory(100)
eq(early:chapter(), "SETBACK",
   "a team change from before the defeat does not count as rebuilding")

-- 6. Persistence: the whole story survives save/load.
local blob = hero:serialize()
local reloaded = Rival.new(ROSTER[3], ctx)
ok(reloaded:restore(blob), "a rival with a story restores")
reloaded.ticks = hero.ticks
eq(reloaded:chapter(), hero:chapter(), "the chapter survives save/load")
eq(reloaded:mood(), hero:mood(), "the mood survives save/load")
eq(Story.unlockedCount(reloaded:ensureStory()),
   Story.unlockedCount(hero:ensureStory()), "milestones survive save/load")
eq(reloaded.teamChangedAt, hero.teamChangedAt, "the rebuild stamp survives save/load")

-- 7. A pre-1.35 save backfills SILENTLY, then behaves normally.
local veteran = Rival.new(ROSTER[1], ctx)
veteran.ticks = 5000
for i = 1, 8 do veteran.badges[tostring(i)] = true end
veteran.ctx = { data = DATA, personalities = PERS,
                graph = { has = function() return false end },
                gyms = { order = { "1","2","3","4","5","6","7","8" }, byBadge = {} } }
veteran.playerWins, veteran.playerLosses = 4, 2
local vblob = veteran:serialize()
vblob.story = nil               -- exactly what a pre-1.35 save looks like
local migrated = Rival.new(ROSTER[1], veteran.ctx)
ok(migrated:restore(vblob), "a pre-1.35 save record still restores")
eq(migrated:ensureStory().seeded, false, "it is not yet seeded")
migrated.ticks = 5000
local firstGained = select(1, migrated:advanceStory(5000))
eq(#firstGained, 0,
   "a twenty-hour save announces nothing on the first tick after upgrading")
ok(Story.unlockedCount(migrated:ensureStory()) > 0,
   "but it does record what it has genuinely earned")
eq(migrated.playerWins, vblob.playerWins, "earlier fields survive the migration")
-- and from then on it behaves like any other rival
migrated.champion = true
migrated.ticks = 5100
local later = select(1, migrated:advanceStory(5100))
local sawChampion = false
for _, g in ipairs(later) do if g.id == "CHAMPION" then sawChampion = true end end
ok(sawChampion, "a milestone earned AFTER the upgrade is announced normally")

-- 8. Bounds: the story cannot grow, whatever a long game does.
local grinder = make(2)
for tick = 1, 4000, 7 do
  grinder.ticks = tick
  grinder:rememberPlayerBattle({ tick = tick,
    rivalWon = (tick % 3 == 0), location = "X" })
  grinder:noteDefeat("player", tick)
  grinder:noteVictory("player", tick + 1)
  grinder:advanceStory(tick)
end
local saved = grinder:serialize().story
ok(Util.count(saved.unlocked) <= Story.milestoneCount(),
   "the saved milestone set cannot exceed the fixed list")
ok(Story.isMood(saved.mood) and Story.isChapter(saved.chapter),
   "a long game still ends in a legal story state")

print(("\n%d passed, %d failed"):format(pass, fail))
os.exit(fail == 0 and 0 or 1)
