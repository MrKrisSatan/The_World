-- Standalone: lua5.1 tests/team_plan_test.lua   (from mods/ai_rivals)
--
-- The 1.34.0 team identity model. Like the relationship model it depends on
-- nothing but src/Util.lua and src/BattleSim.lua, so the rules that decide
-- what kind of team a rival builds can be proven anywhere.

local cache = {}
local function req(n)
  if cache[n] then return cache[n] end
  local f = assert(loadfile(n .. ".lua")); cache[n] = f(req, {}); return cache[n]
end
local Util, TeamPlan = req("src/Util"), req("src/TeamPlan")
local PERS = req("data/personalities")

local pass, fail = 0, 0
local function eq(a, b, m) if a == b then pass = pass + 1 else fail = fail + 1
  print(("FAIL %s (got %s want %s)"):format(m, tostring(a), tostring(b))) end end
local function ok(c, m) if c then pass = pass + 1 else fail = fail + 1; print("FAIL " .. m) end end

-- 1. The seed comes from personality.teamPlan, which until now was dead data.
for id, personality in pairs(PERS) do
  local plan = TeamPlan.new(nil, personality.teamPlan)
  ok(TeamPlan.isArchetype(plan.style),
     id .. ": personality.teamPlan seeds a legal archetype")
end
local styles = {}
for _, personality in pairs(PERS) do
  styles[TeamPlan.new(nil, personality.teamPlan).style] = true
end
local distinct = 0
for _ in pairs(styles) do distinct = distinct + 1 end
ok(distinct >= 3, "the four shipped personalities seed divergent identities")
eq(TeamPlan.new(nil, "nonsense").style, "BALANCED",
   "an unknown plan falls back rather than erroring")
eq(TeamPlan.new(nil, nil).style, "BALANCED", "a missing plan falls back")

-- 2. Every archetype must be scoreable and presentable.
for _, style in ipairs(TeamPlan.ARCHETYPES) do
  ok(TeamPlan.WEIGHTS[style] ~= nil, style .. " has weights")
  ok(type(TeamPlan.label(style)) == "string", style .. " has a label")
  ok(type(TeamPlan.battleStyle(style)) == "string", style .. " has a battle style")
end

-- 3. Traits are read off the engine's own numbers, and separate real species.
local data = { moves = {
  TACKLE = { power = 40, type = "NORMAL" },
  GROWL  = { power = 0,  type = "NORMAL" },
  TOXIC  = { power = 0,  type = "POISON" },
} }
local bruiser = { baseStats = { hp = 60, attack = 130, defense = 60, speed = 100, special = 50 } }
local wall    = { baseStats = { hp = 120, attack = 40, defense = 120, speed = 30, special = 50 } }
local baby    = { baseStats = { hp = 45, attack = 49, defense = 49, speed = 45, special = 65 },
                  evolutions = { { level = 16, species = "X" } } }
local tb = TeamPlan.traits(bruiser, { "TACKLE" }, data)
local tw = TeamPlan.traits(wall, { "TACKLE" }, data)
ok(tb.offence > tw.offence, "an attacker scores higher on offence than a wall")
ok(tw.bulk > tb.bulk, "a wall scores higher on bulk than an attacker")
ok(tb.speed > tw.speed, "a fast Pokemon scores higher on speed")
eq(TeamPlan.traits(baby, {}, data).evolution, 1, "an unevolved species has evolution potential")
eq(TeamPlan.traits(bruiser, {}, data).evolution, 0, "a final form has none")
local status = TeamPlan.traits(wall, { "GROWL", "TOXIC", "TACKLE" }, data)
ok(status.status > 0.5, "a mostly-status moveset reads as status")

-- 4. Archetypes actually disagree about the same Pokemon. This is the whole
--    point: if every identity ranks candidates the same way, rivals converge.
local offensive = TeamPlan.new({ style = "HYPER_OFFENSIVE" })
local defensive = TeamPlan.new({ style = "DEFENSIVE" })
local evolving  = TeamPlan.new({ style = "EVOLUTION" })
ok(TeamPlan.fit(offensive, bruiser, { "TACKLE" }, data)
   > TeamPlan.fit(offensive, wall, { "TACKLE" }, data),
   "a hyper-offensive rival prefers the attacker")
ok(TeamPlan.fit(defensive, wall, { "TACKLE" }, data)
   > TeamPlan.fit(defensive, bruiser, { "TACKLE" }, data),
   "a defensive rival prefers the wall")
ok(TeamPlan.fit(evolving, baby, {}, data) > TeamPlan.fit(offensive, baby, {}, data),
   "an evolution-focused rival values an unevolved Pokemon more highly")

-- 5. Type preference is EARNED, never assigned.
local plan = TeamPlan.new(nil, "balanced")
eq(TeamPlan.preferredType(plan), nil, "a new rival has no type preference")
for _ = 1, 6 do TeamPlan.creditTypes(plan, { "WATER", "WATER" }, true) end
TeamPlan.creditTypes(plan, { "FIRE" }, false)
local preferred, share = TeamPlan.preferredType(plan)
eq(preferred, "WATER", "the preferred type emerges from what it fields and wins with")
ok(share > 0.5, "a dominant type shows a dominant share")
ok(Util.contains(TeamPlan.preferredTypes(plan, 2), "FIRE"),
   "secondary types are still tracked")

-- 6. Bounds: type credit cannot grow forever, in count or in magnitude.
local greedy = TeamPlan.new()
for i = 1, 40 do TeamPlan.creditTypes(greedy, { "TYPE_" .. i }, true) end
ok(Util.count(greedy.types) <= TeamPlan.TYPE_LIMIT, "tracked types are capped")
for _ = 1, 500 do TeamPlan.creditTypes(greedy, { "TYPE_1" }, true) end
ok((greedy.types.TYPE_1 or 0) <= TeamPlan.CREDIT_MAX, "type credit is capped")

-- 7. Identity moves only on ACCUMULATED evidence pointing one way.
local drifter = TeamPlan.new(nil, "balanced")
eq(drifter.style, "BALANCED", "starts where it was seeded")
local moved = false
for _ = 1, 3 do
  local _, _, _, changed = TeamPlan.observe(drifter, "BEATEN_BADLY")
  moved = moved or changed
end
eq(moved, false, "a few defeats do not rewrite an identity")
for _ = 1, 20 do TeamPlan.observe(drifter, "BEATEN_BADLY") end
eq(drifter.style, "DEFENSIVE", "sustained evidence does move the identity")
eq(drifter.changed, 1, "the change is counted")

-- evidence pulling three ways at once leaves a rival where it is
local torn = TeamPlan.new(nil, "balanced")
for _ = 1, 30 do
  TeamPlan.observe(torn, "BEATEN_BADLY")
  TeamPlan.observe(torn, "WON_QUICKLY")
  TeamPlan.observe(torn, "OUTSPED")
end
eq(torn.style, "BALANCED", "contradictory evidence does not move an identity")

-- an unnamed reason is refused outright
local strict = TeamPlan.new(nil, "balanced")
local _, _, _, changed = TeamPlan.observe(strict, "BECAUSE")
eq(changed, false, "an unnamed reason cannot move an identity")
eq(strict.drift, 0, "a refused reason accumulates nothing")

-- 8. Service score: the roadmap's favourite factors, with diminishing returns.
local starter = { species = "A", origin = "starter", battles = 4, wins = 2, since = 0 }
local veteran = { species = "B", battles = 60, wins = 40, since = 0 }
local rookie  = { species = "C", battles = 0, wins = 0, since = 900 }
ok(TeamPlan.serviceScore(veteran, 1000) > TeamPlan.serviceScore(starter, 1000),
   "a long-serving winner outranks the starter eventually")
ok(TeamPlan.serviceScore(starter, 1000) > TeamPlan.serviceScore(rookie, 1000),
   "the starter outranks a Pokemon that has done nothing")
local huge = { species = "D", battles = 5000, wins = 5000, since = 0 }
ok(TeamPlan.serviceScore(huge, 1000) < TeamPlan.serviceScore(veteran, 1000) * 2,
   "service has diminishing returns rather than runaway growth")
eq(TeamPlan.serviceScore(nil, 0), 0, "a missing slot scores nothing")

-- 9. Serialization round trip, and corrupt saves cannot yield illegal state.
local round = TeamPlan.new(TeamPlan.serialize(drifter))
eq(round.style, "DEFENSIVE", "the identity survives a save/load round trip")
local dirty = TeamPlan.new({ style = "GOD_MODE", drift = 9e9,
  types = { WATER = "lots", [5] = 3 }, changed = -4 })
ok(TeamPlan.isArchetype(dirty.style), "a corrupt style is repaired")
ok(dirty.drift <= 99, "a corrupt drift is clamped")
ok(Util.count(dirty.types) <= TeamPlan.TYPE_LIMIT, "corrupt type credit is bounded")

-- 10. Determinism: no dice, no clock.
local function replay()
  local p = TeamPlan.new(nil, "aggressive")
  for _ = 1, 25 do TeamPlan.observe(p, "OUTSPED") end
  for _ = 1, 10 do TeamPlan.creditTypes(p, { "GRASS", "WATER" }, true) end
  return p.style .. ":" .. tostring(TeamPlan.preferredType(p))
end
eq(replay(), replay(), "identical evidence produces identical identities")

print(("\n%d passed, %d failed"):format(pass, fail))
os.exit(fail == 0 and 0 or 1)
