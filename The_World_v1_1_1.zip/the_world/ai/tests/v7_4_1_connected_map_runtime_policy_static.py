from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
main=(ROOT/"main.lua").read_text()
mat=(ROOT/"src/manager/Materialize.lua").read_text()
manifest=(ROOT/"manifest.json").read_text()

assert "function M:mapAllowsRuntimeActors(mapId)" in main
assert "if conn then return false end" in main
assert "if M:mapAllowsRuntimeActors(mapId) then" in main
assert "if self.mapAllowsRuntimeActors and not self:mapAllowsRuntimeActors(mapId)" in mat
assert 'Util.guard("connection-yield"' not in main
assert "pcall(installConnectionYield)" not in main
assert '"version": "7.4.1"' in manifest
print("7.4.1 connected-map runtime policy checks passed")
