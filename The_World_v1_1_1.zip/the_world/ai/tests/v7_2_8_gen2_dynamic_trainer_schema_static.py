from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
rocket=(ROOT/"src/Rocket.lua").read_text()
rangers=(ROOT/"src/Rangers.lua").read_text()
main=(ROOT/"main.lua").read_text()
manifest=(ROOT/"manifest.json").read_text()
for txt in (rocket,rangers):
    assert "self.data.gen2Trainers" in txt
    assert "gen2.classes" in txt
    assert "trainers = { {" in txt
    assert "party = Util.copy(party)" in txt
    assert "parties = { Util.copy(party) }" in txt  # Gen1 branch retained
assert "local classIndex = 180 +" in rocket
assert "local classIndex = 220 +" in rangers
assert "Never invent a fallback trainer record here" in main
assert '"version": "7.2.8"' in manifest
print("7.2.8 Gen2 dynamic trainer schema checks passed")
