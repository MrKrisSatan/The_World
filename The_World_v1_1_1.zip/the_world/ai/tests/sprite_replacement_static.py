import re
from pathlib import Path
root = Path(__file__).resolve().parents[1]

def code_only(text):
    """Strip Lua comments before scanning.

    Lesson 3, for the eighth time: a file that DOCUMENTS a trap matches the
    pattern for the trap. Both assertions below were written to forbid a
    string that the fix's own comment quotes while explaining why it was
    wrong, so they failed on correct code.
    """
    text = re.sub(r"--\[(=*)\[.*?\]\1\]", " ", text, flags=re.S)
    return "\n".join(
        line for line in text.splitlines() if not line.lstrip().startswith("--")
    )

s = (root/'src'/'Sprites.lua').read_text()
scode = code_only(s)
main = (root/'main.lua').read_text()
all_source = main + '\n' + '\n'.join(p.read_text() for p in (root/'src').rglob('*.lua'))
wonder = (root/'src'/'WonderTrade.lua').read_text()
assert 'record.image =' not in s, 'AI Rivals must never repaint a sprite record'
assert 'function Sprites:semanticWalker' in s
assert 'function Sprites:activeData' in s
# 5.1.0: a rival is DEALT one sprite from its gender pool as a pure function
# of (world seed, rival id), stamped once and never overwritten -- walkerFor
# is now only the display substitute for a stamp this generation cannot draw.
assert 'function Sprites:assignWalker' in s
assert 'function Sprites:genderPool' in s
assert 'self.sprites:assignWalker(rival.def, self.data, seed, prefer)' in all_source

# The stamp must survive a version that cannot render it. It used to be
# re-resolved whenever exists() said no, which is exactly what a Gold boot
# does -- so a rival came back from a Gen 2 session wearing a different face.
mat = (root/'src'/'manager'/'Materialize.lua').read_text()
assert 'local stamped = rival.appearanceSprite' in mat
stamp_block = mat[mat.index('function M:spriteForRival'):]
stamp_block = stamp_block[:stamp_block.index('\nend\n')]
assert stamp_block.count('rival.appearanceSprite =') == 1, \
    'the stamp is written in exactly one place'

# THE NIL-HOLE. Both resolvers used to loop `ipairs{ def.overworldSprite, ...,
# def.fallbackSprite }`, and ipairs stops at the first nil -- every roster row
# leaves overworldSprite nil, so fallbackSprite was NEVER read and Guts had
# silently been a Cooltrainer since walkerFor was written.
assert 'ipairs({ def.overworldSprite' not in scode, 'nil-holed constructor is back'
assert 'local function appendAuthored' in s

# Generated rows must not name a sprite, or 95 rivals share two walkers again.
rivals = (root/'data'/'rivals.lua').read_text()
generated = rivals[rivals.index('for slot = 6, 100 do'):]
assert 'fallbackSprite =' not in code_only(generated), \
    'generated roster rows must leave the sprite to the gender pool'
assert 'sprite="SPRITE_SUPER_NERD"' not in wonder
assert 'manager.sprites:npcFor("attendant"' in wonder
assert 'hgssNativeImage' in s
print('sprite replacement interoperability: ok')
