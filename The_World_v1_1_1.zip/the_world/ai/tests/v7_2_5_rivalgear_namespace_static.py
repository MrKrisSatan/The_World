from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
main=(ROOT/"main.lua").read_text()
rg=(ROOT/"src/RivalGear.lua").read_text()
manifest=(ROOT/"manifest.json").read_text()
assert not (ROOT/"src/Pokegear.lua").exists()
assert 'req("src/RivalGear")' in main
assert "RivalGear.init" in main
assert "AIR_RivalGear" in rg
assert "AIR_Pokegear" not in rg
assert "__airRivalGear" in rg
assert '"RIVALGEAR"' in rg
assert '"version": "7.2.5"' in manifest
print("7.2.5 RivalGear namespace checks passed")
