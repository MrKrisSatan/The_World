#!/usr/bin/env python3
"""One rival battle at a time (3.5, from the uploaded 3.4.1 patch).

A rival battle is a TRANSACTION, not an instant: dialogue, the deferred launch,
the battle, then the bookkeeping and gauntlet progression after battle.ended.
Every one of those windows could be re-entered -- by a second talk in the same
frame, a nearby rival's duel AI, a repeated Gen 2 engagement event, or a stale
delayed callback -- and the second entrant corrupts the first's state.

The uploaded patch shipped a bare assert-list version of this. It is kept, but
each requirement is now named so a failure says WHICH window reopened rather
than printing a list of strings.
"""
import re
import sys
from pathlib import Path

root = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(Path(__file__).resolve().parent))
from _version import at_least

main = (root / "main.lua").read_text(encoding="utf-8")
errors = []


def need(token, label):
    if token not in main:
        errors.append(label)


# the lock and the sequence id
need("rivalBattleSequenceActive", "no battle transaction lock")
need("rivalBattleSequenceId", "no sequence id, so a stale callback is "
     "indistinguishable from a live one")
need("rivalBattleActiveRivalId", "the lock does not record WHOSE battle it is, "
     "so one rival could release another's transaction")

# every window the changelog names
need("if self.rivalBattleSequenceActive then\n    return false, "
     '"A rival battle is already in progress."',
     "a second direct challenge can enter while one is in progress")
need('return false, "A rival battle is already being prepared."',
     "a second challenge can enter during the launch window")
need("if M.rivalBattleSequenceActive or M.pendingRivalBattleLaunch then",
     "talking can launch a second battle from the same frame")
need("if M.rivalBattleSequenceActive then return end",
     "a duplicate Gen 2 engagement event can start a second battle")
need("or self.rivalBattleActiveRivalId ~= launch.rivalId then",
     "a stale delayed callback can resurrect an old encounter")

# the lock must be RELEASED on every exit, or the mod wedges for the session
flow = (root / "src" / "BattleFlow.lua").read_text(encoding="utf-8")
if "manager.rivalBattleSequenceActive = false" not in flow:
    errors.append("the extracted battle flow never releases its lock")
need("function M:releaseRivalBattleSequence",
     "there is no shared transaction release")

# release must come AFTER the bookkeeping, or the window is still open
tail = main[main.rindex('mod.events:on("battle.ended"'):]
tail = tail[:tail.index('mod.events:on("world.blacked_out"')]
released = tail.rfind("M:releaseRivalBattleSequence(rival.id)")
gauntlet = tail.rfind("M:finishGauntlet()")
if released < 0:
    errors.append("battle.ended never releases the lock")
elif gauntlet > released:
    errors.append("the lock is released BEFORE gauntlet progression completes, "
                  "which is the window the fix exists to close")

errors.extend(x for x in [at_least(root, "3.5.0")] if x)

if errors:
    for error in errors:
        print("FAIL", error)
    raise SystemExit(1)
print("AI Rivals v3.5 battle re-entrancy: one transaction at a time, released "
      "only after bookkeeping PASS")
