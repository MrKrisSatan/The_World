from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
g=(ROOT/"src/manager/Gauntlet.lua").read_text()
p=(ROOT/"src/manager/Persistence.lua").read_text()
m=(ROOT/"main.lua").read_text()
manifest=(ROOT/"manifest.json").read_text()

skip=g[g.index("function M:skipGauntlet"):g.index("function M:gauntletStepTowardPlayer")]
assert "self.worldStartPending = false" in skip
assert "self.worldStartPending = true" not in skip
assert 'mod.save:get("gauntletMode") == "skip"' in p
assert "self.worldStartPending = false" in p
assert "local playerHasBattleMon" in m
assert "if playerHasBattleMon and mod.options:get(\"encounters\")" in m
assert '"version": "7.3.5"' in manifest
print("7.3.5 immediate skip-world checks passed")
