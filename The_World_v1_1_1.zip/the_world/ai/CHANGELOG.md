## 7.6.3

Scrollable rival-count character-creation menu.

## 7.6.2

Save-crash hotfix and serializer hardening.

## 7.6.1

Fixed the stray `n` before TRAINER in the class-selection prompt.

## 7.6.0

See `CHANGELOG_7.6.0.md`.

## 7.5.4

See `CHANGELOG_7.5.4.md`.

## 7.5.3

See `CHANGELOG_7.5.3.md`.

## 7.5.2

See `CHANGELOG_7.5.2.md`.

## 7.5.1

See `CHANGELOG_7.5.1.md`.

## 7.5.0

See `CHANGELOG_7.5.0.md`.

## 7.4.7

See `CHANGELOG_7.4.7.md`.

## 7.4.6

See `CHANGELOG_7.4.6.md`.

## 7.4.5

See `CHANGELOG_7.4.5.md`.

## 7.4.4

See `CHANGELOG_7.4.4.md`.

## 7.4.3

See `CHANGELOG_7.4.3.md`.

## 7.4.2

See `CHANGELOG_7.4.2.md`.

## 7.4.1

See `CHANGELOG_7.4.1.md`.

## 7.4.0

See `CHANGELOG_7.4.0.md`.

## 7.3.9

See `CHANGELOG_7.3.9.md`.

## 7.3.8

See `CHANGELOG_7.3.8.md`.

## 7.3.7

See `CHANGELOG_7.3.7.md`.

## 7.3.6

See `CHANGELOG_7.3.6.md`.

## 7.3.5

See `CHANGELOG_7.3.5.md`.

## 7.3.4

See `CHANGELOG_7.3.4.md`.

## 7.3.3

See `CHANGELOG_7.3.3.md`.

## 7.3.2

See `CHANGELOG_7.3.2.md`.

## 7.3.1

See `CHANGELOG_7.3.1.md`.

## 7.3.0

See `CHANGELOG_7.3.0.md`.

## 7.2.8

See `CHANGELOG_7.2.8.md`.

## 7.2.7

See `CHANGELOG_7.2.7.md`.

## 7.2.6

See `CHANGELOG_7.2.6.md`.

## 7.2.5

See `CHANGELOG_7.2.5.md`.

## 7.2.4

See `CHANGELOG_7.2.4.md`.

## 7.2.3

See `CHANGELOG_7.2.3.md`.

## 7.2.2

See `CHANGELOG_7.2.2.md`.

## 7.2.1

See `CHANGELOG_7.2.1.md`.

## 7.2.0

See `CHANGELOG_7.2.0.md`.

# AI Rivals 7.1.0 - Four-Game Feature Parity & Expanded Personalities

## Red / Blue / Yellow / Gold parity
- Audited the shared feature stack so core systems are loaded for all four supported games rather than selected by generation at startup.
- Added a regression contract covering Pokégear, phone/comms, Rangers, Team Rocket, factions, double-agent play, Rival Wars, ecology, quests, Weather Research, Wonder Trade, tournaments and simulation adapters.
- Re-asserted the dedicated Gold adapters for dynamic NPC talk, Gen 2 trainer battles, Gen 2 encounter tables, Gen 2 Pokémon construction and 14-box storage.
- Weather Scientist NPCs and Weather FX quest generation retain separate Gen 1 and Gold map/talk adapters while sharing one quest model.
- Rocket Uniform, Rocket Ball and stolen-Pokémon systems remain available on both generations with generation-appropriate progression/storage paths.

## Personality expansion
Added 24 original personality archetypes inspired by the requested genres/settings. They are behavioural homages rather than direct character copies and are available to the ordinary seeded rival pool in every supported game.

New archetypes: Northern Loyalist, Court Schemer, Dragon Heir, Quiet Spy, Oathbound Knight, Iron Commissar, Machine Adept, Purifier, Void Veteran, Glory Reaver, Cyber Operative, Section Chief, Heavy Operative, Ghost Hacker, Solar Idealist, Midnight Tactician, Winged Guardian, Reality Engineer, Street Merc, Netrunner, Corporate Fixer, Nomad, Rocker Rebel and Edgerunner.


# AI Rivals 7.0.0 — Weather Operations & Shared Wonder Trade

- Added Weather Scientist NPCs to Pokémon Centers in Red, Blue, Yellow and Gold.
- Scientist quests are created only when the player talks to a scientist and Weather FX is active.
- Added Weather Field Survey missions that require live readings in the requested weather.
- Added Variant Field Study missions targeting registered Weather FX `WX_*` Pokémon.
- Team Rocket contacts can now offer weather-timed theft jobs and weather-variant procurement jobs while the player is accepted as disguised Rocket.
- Weather/Rocket missions never enter the Pokégear automatically; an NPC interaction is mandatory.
- Added a shared AI Wonder Trade API using the same merged species pool as the player Wonder Trader, including Weather FX variants.
- AI rivals retain their existing Wonder Trade behaviour; Pokémon Rangers and Team Rocket members can now use the Wonder Trader too.
- Rocket stolen Pokémon are explicitly excluded from Wonder Trade so provenance and recovery cases remain intact.
- Ranger and Rocket Wonder Trades are throttled with cooldowns to preserve team identity.
- Full Red/Blue/Yellow/Gold manifest support retained.

# AI Rivals 6.9.0 - Rival Wars

- Rivals can form persistent alliances from the existing relationship model.
- Joining Team Rocket can break an alliance and create a remembered betrayal.
- Betrayed, hostile and nemesis rivals can launch revenge hunts and travel after one another.
- Friendly rivals can respond to recent Rocket conflicts and travel to defend an ally.
- Successful defenses strengthen both rivals' relationships; failed defenses become memories.
- Rival Wars state is persisted and remains backwards-compatible with 6.8 saves.
- All new behaviour is generation-neutral and uses the shared simulation layer for Red, Blue, Yellow and Gold.

# 6.8.0

See `CHANGELOG_6.8.0.md`.

# AI Rivals 6.4.0 - Mission Chains & Rocket Black Market

- Added NPC-gated mission chains. Completing a mission may create a hidden follow-up opportunity, but it never appears in the Pokégear until the original issuer speaks to the player again.
- Ranger and Team Rocket issuers can continue multi-stage operations with persistent chain IDs and chapter history.
- Team Rocket members now sell bundles of 5 Rocket Balls while the player is wearing a trusted Rocket Uniform.
- Rocket Ball bundles cost $1000 by default, with discounts for stronger Rocket reputation/trust.
- Exposed or hunted infiltrators cannot buy from the Rocket black market merely by putting the uniform back on.
- Rocket Ball purchases are remembered by the double-agent/faction system.
- Rocket jobs now progress through actual trainer-Pokémon thefts with Rocket Balls, allowing mission chains to connect directly to the infiltration mechanic.
- Rocket shop purchase totals and spending persist in saves.
- Quest reward text now names the actual reward item instead of always saying Rare Candy.

# 6.3.0 - Double Agents & Dynamic Requests

- Factions now track trust, suspicion, evidence and belief separately from reputation.
- Rocket Uniform cover can be blown; EXPOSED/HUNTED Rocket no longer accepts the disguise at face value.
- Rocket theft, Rocket work, Ranger work and anti-Rocket victories alter faction beliefs.
- Faction actions feed the existing rival memory system so rivals remember the player's allegiances and betrayals.
- Added issuer-bound dynamic requests: events may create a need, but only an actual NPC conversation can create a Pokégear quest offer.
- Preserves all 6.2 infiltration mechanics and save compatibility.

# 6.0.0 - Team Rocket 2.0

- Added save-seeded Rocket leadership doctrines.
- Added persistent Rocket resources, territorial influence and hidden bases.
- Rocket strategy now reacts to Ranger pressure, resources and player anti-Rocket heat.
- Successful operations can strengthen territorial control; Ranger dominance erodes it.
- Hideout operations can establish and upgrade persistent bases.
- Rocket save schema upgraded to v3 with backwards-compatible defaults.

# AI Rivals 5.8.0

[Full notes](CHANGELOG_5.8.0.md)

- Persistent save-specific local Pokemon ecotypes driven by long-term weather, diet, pollution and displacement.
- Ecotypes affect abundance and rare Weather FX variant pressure while preserving backwards-compatible saves.

# AI Rivals 4.7.1

- Added 400 boys' names and 400 girls' names for save-seeded rival naming.
- Added Dyanari and Larissa to the girls' pool.
- Rivals receive unique given names per new save, with no generated surname
  combinations.
- Shawn remains Shawn and keeps `HEARTBREAK_KID`; other rivals use the normal
  personality pool.
- Rival names and personality IDs are persisted, while pre-4.7.1 saves retain
  their original authored names.

# AI Rivals Changelog

## 4.7.1

See `CHANGELOG_4.7.1.md` for the modular 4.7.1 merge.

# Changelog

Full notes for each 4.x release live in [`docs/changelogs/`](docs/changelogs).
The complete history back to 1.7.0, with the design reasoning, is in
[`docs/ai-rivals.md`](docs/ai-rivals.md).

---

## 4.6.0 — Rankings, records, and a feature that could never fire

[Full notes](docs/changelogs/4.6.0.md)

- **TRAINER RANKINGS**, a new Pokégear screen putting every trainer in the save
  on one table with the player among them, ordered by the same comparison as
  everybody else. Selecting a trainer opens their full record.
- **Records are derived, never logged.** "Defeated Brock" is the badge case
  joined to the gym table; take the badge away and the sentence goes with it.
  Notable captures come from `data/notable.lua`.
- **Rivals can challenge the champion.** The title shot shipped in 1.39 and
  could never once have fired: the event that creates a champion was the event
  that stopped anybody qualifying to face one. A held crown now changes what a
  League run is *for* — clearing the Elite Four makes a rival a challenger, and
  the title only moves in a title match. A title held by the player is never
  settled by the simulation.
- **Five new relationship states** — NEMESIS, DEVOTED, PROTEGE, ADMIRER,
  ESTRANGED — each a strict subset of the state it refines, each with its own
  dialogue. **LOVERS is a pair state** requiring both sides to reach DEVOTED
  independently, and a mutual pair actually travels together.
- Team Rocket now reads grievance toward another rival, not only toward the
  player.
- Three bugs found in this release's own code, including a devotion clock that
  could never run because meeting the requirement reset it.
- 77 suites; `pokegear_call_test` repaired from failing.

## 4.5.4

[Full notes](docs/changelogs/4.5.4.md)

- Fixed left/right text collision in the face-to-face rival menu; wider gap
  between label and status rather than trusting the nominal 16-character width.
- Shortened challenge status to 1V1 / 2V2, companion status to JOIN / ON, and
  the Poké Ball help status to BALL; removed redundant chevrons.

## 4.5.3

[Full notes](docs/changelogs/4.5.3.md)

- Trimmed the face-to-face rival menu to six compact actions so fixed-width rows
  stop overlapping; mood, story, battle style, career, weather, preferences and
  relationship details moved into a **Rival Info** submenu.
- Tournament setup now picks participant count first, then an explicit **Battle
  Mode** screen with STANDARD and DOUBLE, replacing the hidden format toggle.
  Double clearly shows unavailable when the teams cannot field it.

## 4.5.2

[Full notes](docs/changelogs/4.5.2.md)

- Fixed an updater/version loop: the packaged manifest reported a stale version.
- Rival calls expose a working CHALLENGE action, checked without falsely
  requiring the overworld battle runner while the Pokégear is open and staged
  until the menus close.
- Added `TOURNAMENT HERE`. Player tournaments are 3–100 rivals capped by the
  save's eligible roster, award 2x EXP and a rare prize, and are limited to one
  per local calendar day with the used day persisted so reloads cannot farm it.

## 4.5.1 — progression, blackout and appearance hotfix

[Full notes](docs/changelogs/4.5.1.md)

- Rivals buy an early Poké Ball stock with their own money when released from
  Oak's Lab, and restock while passing through towns — shopping is no longer
  accidentally gated behind the HEALING state.
- Before the first badge, rivals will not attempt the first gym with fewer than
  three Pokémon; undersized teams catch harder.
- **Defeat now actually costs a rival.** The engine battle used a defensive party
  copy, so saved HP stayed full and blackout never triggered. Losers of player
  duels, rival skirmishes and simulated trainer battles now black out to the
  nearest Poké Center.
- Rival appearance persists one logical walker id, so hair no longer flips
  between compatible sprite ids — still without storing any image or palette
  data.

## 4.5.0 — The Pokégear call is a conversation

[Full notes](docs/changelogs/4.5.0.md)

- **Fixed "CALL / REMATCH does nothing".** It was never a dead button: every word
  of the reply went to the ticker, which only draws over the overworld — and the
  player was four menus deep. Calls now open a real conversation in the engine's
  own text box.
- Calling a rival offers COME HERE, TOURNAMENT, ASK ABOUT and HANG UP; ordinary
  trainers offer REMATCH, ASK ABOUT and a CLOSE MENU row that hands the map back
  in one press.
- **`src/Scout.lua`** decides what a caller may honestly say, derived from the
  head-to-head record: the whole party after 3+ battles, the lead and ace after
  1–2, badges and a sighting with none.
- Tournament sizes 2–100 shown as `chosen/ceiling`, A jumps through the powers of
  two, and a staged match waits for the overworld to be idle before constructing
  itself.

## 4.4.3

[Full notes](docs/changelogs/4.4.3.md)

- Renamed Pokégear MAP to **WEATHER TRACKER**.
- Added **RADIO → CUSTOM MUSIC**: OGG/MP3/WAV/FLAC in `custom_music/`, playlist
  subfolders, browse, play, loop, rescan and stop. The selection persists and a
  missing file fails softly. Stays inside the API 2 sandbox — no arbitrary host
  filesystem access.

## 4.4.2

[Full notes](docs/changelogs/4.4.2.md)

- Fixed player-initiated calls being rejected by the incoming-call scheduler.
  Outgoing calls still write history and cooldown timestamps, preserving inbound
  pacing.

## 4.4.1 — sprite replacement interoperability

[Full notes](docs/changelogs/4.4.1.md)

- AI Rivals no longer claims or repaints player, rival, trainer or NPC artwork.
  Walkers resolve from the merged runtime sprite table on every spawn, preferring
  vanilla logical ids so replacement mods supply their own art.
- Semantic discovery for overhaul mods that rename sprite ids, and a
  deterministic live fallback for total conversions with no familiar ids.
- The Wonder Trade attendant uses the same resolver instead of a hard-coded
  sprite.

## 4.4.0

[Full notes](docs/changelogs/4.4.0.md)

- Autonomous rival-only tournaments, with results and eliminations in World News.
- Player tournaments arranged by phone, 2–100 rivals, single or double format.
- Bracket state persists across saves and safely resumes a pending player match
  after reload.

## 4.3.1

[Full notes](docs/changelogs/4.3.1.md)

- Fixed overlapping text on the status menu by fitting both columns to a shared
  safe row width.
- Fixed API-2 ListMenu dispatch on the status, detail, performance and error
  screens while retaining old-build compatibility.

## 4.3.0

[Full notes](docs/changelogs/4.3.0.md)

- Every ordinary non-gym, non-Rocket trainer in the loaded game is eligible for a
  Pokégear number; offers are randomized per save and capacity is 200.
- Accepted trainers call with rematches, gossip, rival sightings and Weather FX
  regional reports.
- **Persistent 0–100 affection** on every rival→player and rival→rival bond,
  seeded per save and moved by battles, gifts, trades, cooperation, favours,
  snubs and life-path events. Number offers now read affection rather than raw
  battle counters.

## 4.2.4

[Full notes](docs/changelogs/4.2.4.md)

- Fixed phone-number offers reporting `COULD NOT SAVE NUMBER` after the player
  accepted: the offer screen now passes its own contact record instead of relying
  on a pending slot that is cleared as the screen opens.

## 4.2.3

[Full notes](docs/changelogs/4.2.3.md)

- Fixed Gen 1 Pokégear selection on current API 2 — Clock, Phone, Map, contact
  and history actions, phone offers and radio dispatch all read `item.value` from
  `ListMenu:onChoose` rather than comparing item tables to strings, with a scalar
  fallback for older callback shapes.

## 4.2.1

[Full notes](docs/changelogs/4.2.1.md)

- Fixed a fatal parse error in `src/Pokegear.lua`.
- One cross-generation Pokégear, exposed from the Start menu on Gen 1 as well as
  Gen 2, with Red/Blue/Yellow/Gold declared explicitly in the manifest.

## 4.2.0 — Pokégear for four games

[Full notes](docs/changelogs/4.2.0.md)

- **Pokégear** in the Start menu for Red, Blue, Yellow and Gold: CLOCK, PHONE,
  MAP and RADIO, with persistent save-safe phone state and call history.
- **Kanto trainer phone network** — contacts discovered from the loaded game's
  own trainer data, deterministic save-stable numbers, offers after a win, and
  rematches through the engine's native trainer battle construction.
- **Rival calls create a real travel request**: the rival routes to your map
  normally instead of teleporting, and the summon outranks ordinary travel
  objectives without overriding battle or cutscene safety.
- **Removed Choose Your Hero** — the gender question, the sprite selection, the
  injected appearance choice and the bundled assets. Rival appearance now follows
  the rival's name, with roster gender used only for ambiguous ones.

# AI Rivals 4.8.0

## Team Rocket simulation

- Added a separate Team Rocket world simulation that mirrors the rival simulation as a dark reflection.
- Every save generates different Rocket leaders, recruits, strengths, roles, backgrounds, goals, operations, locations, successes and failures.
- Rocket recruits begin in Celadon City and receive one random Pokémon from the configured Rocket starter pool.
- Rocket members travel through the live map graph one connected map at a time rather than teleporting.
- Added recruitment attempts against rivals, Pokémon theft attempts, trainer shakedowns, smuggling, hideout expansion, propaganda, Silph raids and Safari Zone seizure operations.
- Major incidents create persistent world news and investigation quests; nearby rivals can divert to investigate.
- Added phone alerts for major Rocket incidents, recruitment events and thefts.
- Rocket members can be promoted, demoted or, very rarely, redeemed.
- Added random Rocket player ambushes and dynamic Rocket trainer battle parties.
- Added persistent Rocket state and deterministic RNG continuation across save/load.
- Existing 4.7.1 rival name pools, Shawn identity rules and modular manager structure are retained.

## 6.5.0
- Stolen Pokémon are now persistent Rocket assets with provenance and sale history.
- Rocket members can use stolen Pokémon in battle and trade/sell them to one another.
- Friendly Rocket members can sell held stolen Pokémon to a disguised player; purchased Pokémon join the party or PC and leave Rocket ownership.
- Rocket trainer parties refresh when stolen-Pokémon ownership changes.
- Legacy theft records are upgraded on load.
