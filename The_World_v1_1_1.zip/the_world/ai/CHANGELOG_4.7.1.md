# AI Rivals 4.7.1

## 400-name rival identity pools

- Added a **400-name boys pool** and **400-name girls pool** in `data/names.lua`.
- **Dyanari** and **Larissa** are included in the girls pool.
- New saves deterministically deal unique given names from the pools using the
  save's world seed.
- The assignment is stable for the life of a save, so loading/reloading never
  renames a rival.
- Male and female pools have no overlapping visible names, preventing duplicate
  rival names when both genders are active.
- Rivals use given names only. No generated first-name/surname combinations are
  used, eliminating results such as **Ash Ash** or **Kelly Ash**.
- **Shawn remains Shawn** and keeps the authored `HEARTBREAK_KID` personality.
- All other rivals now draw from the normal personality pool instead of having
  their old fixed personality identities.
- The existing 100-slot roster is preserved for compatibility with the rival
  count system.
- Assigned names and personality IDs are now persisted in rival save state.

## Compatibility

- Existing rival IDs, trainer classes, sprite slots, starter logic, Life Paths,
  Bonds, Careers, Titles, phone contacts and relationship state remain intact.
- Existing saves retain their saved rival names once loaded. New saves receive
  the new randomised cast.
