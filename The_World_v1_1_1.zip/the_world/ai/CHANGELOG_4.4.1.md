# AI Rivals 4.4.1 — sprite replacement interoperability

- AI Rivals no longer claims or repaints player, rival, trainer, or NPC sprite artwork.
- Rival walkers are resolved from the current merged runtime sprite table every time they spawn.
- Vanilla logical sprite ids remain preferred, which means normal replacement mods automatically supply their own art.
- Added semantic discovery for overhaul mods that rename sprite ids instead of replacing them in place.
- Added deterministic live-walker fallback for total conversions with no familiar ids.
- Wonder Trade attendant now uses the same live resolver instead of hard-coding `SPRITE_SUPER_NERD`.
- Player and ordinary vanilla NPC sprites remain completely untouched by AI Rivals.
- Battle portraits continue to reference host-game trainer classes, leaving replacement portraits authoritative.
- Reintroduced public foreign-art marker detection for compatibility diagnostics; no AI Rivals code mutates such records.
