# AI Rivals 7.3.9

- Extended the pre-connection runtime-NPC safeguard to **Gold**.
- Red, Blue and Yellow continue to yield physical Rival/Rocket/Ranger NPCs
  immediately before `OverworldController.crossConnection`.
- Gold now wraps the authoritative Gen 2 `World:tryConnection(dir)` path.
- Gold only yields actors when a real connection exists in the attempted
  direction, so ordinary blocked movement does not despawn NPCs.
- Persistent rival, Rocket and Ranger simulation state is never removed.
- Actors rematerialise normally after the destination map has settled through
  the existing deferred-materialisation safeguards.
- All four supported games now use the same safety principle at their native
  connection seam.
