# AI Rivals 7.3.2

- Fixed Gold rival A-button interaction by moving the shared Gen2Talk router onto the current `OverworldController.interact` seam.
- The router now resolves the NPC physically on the player's facing cell before Gold's built-in interaction ladder.
- Fixed Gold rival sprites changing into Pokémon sprites after entering/leaving buildings.
- Gold now prefers and validates against `data.gen2Sprites`; Gen 1 logical sprite ids are never persisted into Gold runtime map objects.
- Gold rival runtime objects use native Gen 2 standing movement data.
- Red, Blue and Yellow retain their existing Gen 1 talk/materialization paths.
