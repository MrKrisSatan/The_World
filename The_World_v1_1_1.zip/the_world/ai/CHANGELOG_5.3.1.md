# AI Rivals 5.3.1

- Pokégear **Quests** lists every formal quest plus Rocket watch requests (`listAll`).
- Pokégear **Weather Tracker** polls Weather FX live state on every open: SKY NOW, BATTLE WX, TIME OF DAY (Weather FX 4.3.1 exports), plus regional map when available.
- Compat: `weatherSnapshot()` and improved `weatherMap()` fallback when only `weather()` is published.
