# AI Rivals 7.2.0

- Added CRUSADER personality: highly religious, extremely aggressive in battle, and absolutely immune to Team Rocket recruitment.
- Weather FX now expands ordinary rival starter pools with real registered WX_* species.
- WX starter selection is deterministic per save/rival and can be biased by personality.
- No WX id is fabricated; only variants present in the loaded Pokémon registry are eligible.
- Red, Blue, Yellow and Gold use the same starter-selection feature path.
