local mod = ...

local loadChunk=loadstring or load
local function compile(source,name)
  local chunk,err=loadChunk(source,name)
  if not chunk then error("The World: "..tostring(err),0) end
  return chunk
end

-- Weather subsystem first: it owns its mature root-relative asset/lib layout.
local wx=mod:read("weather_main.lua")
if not wx then error("The World: weather subsystem missing",0) end
compile(wx,"@the_world/weather_main.lua")(mod)

-- The integrated weather API remains on the same exports table.
local weatherHandle={exports=mod.exports}

-- Kanto Reforged content is now native to The World.
local contentSource=mod:read("reforged/world_content.lua")
if not contentSource then error("The World: merged Pokemon content missing",0) end
compile(contentSource,"@the_world/reforged/world_content.lua")(mod)

-- AI subsystem sees /ai as its private root while sharing every runtime API.
local ai={
  path=tostring(mod.path or "").."/ai",
}
function ai:read(rel)
  return mod:read("ai/"..tostring(rel))
end
function ai.find(a,b)
  local id=b or a
  if id=="weather_fx" or id=="weather-fx" or id=="WeatherFx"
     or id=="the_world" or id=="TheWorld" then
    return weatherHandle
  end
  if not mod.find then return nil end
  local ok,v=pcall(mod.find,mod,id)
  if ok and v then return v end
  ok,v=pcall(mod.find,id)
  return ok and v or nil
end
setmetatable(ai,{__index=mod})

local src=mod:read("ai/main.lua")
if not src then error("The World: AI subsystem missing",0) end
local factory=compile(src,"@the_world/ai/main.lua")()
if type(factory)~="function" then error("The World: invalid AI loader",0) end
factory(ai)

mod.exports.theWorld=true
mod.exports.integratedWeather=true
mod.exports.integratedAIRivals=true
