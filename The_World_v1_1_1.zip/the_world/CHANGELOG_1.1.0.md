# The World 1.1.0

## Kanto Reforged content merged
- Merged Kanto Reforged's Gen 2/Gen 3 Pokemon data, sprites, palettes, dex data,
  move database, move effects, ability data and held-item system into The World.
- The World no longer requires Kanto Reforged as a separate install for this content.
- Kanto Reforged is marked incompatible as a standalone mod to avoid duplicate
  species/move/item registrations.

## New combined options
- POKEMON GENERATIONS:
  - GEN 1
  - GEN 1 + GEN 2
  - GEN 1 + GEN 2 + GEN 3
- ABILITIES: ON / OFF
- HELD ITEMS: ON / OFF
- GEN 2/3 MOVES: ON / OFF
- DARK/STEEL/FAIRY: ON / OFF
- These live on the same unified The World options page as AI Trainers,
  Weather and WX Pokemon.

## Character creation
- Added Pokemon-generation scope selection.
- Added Abilities ON/OFF.
- Added Held Items ON/OFF.
- Added Gen 2/3 Moves ON/OFF.
- Existing AI Trainers, Weather, WX Pokemon, Weather Intensity and Weather
  Quality choices remain.

## Save safety
- Gen 2/3 species, moves and held items remain registered even when their
  gameplay option is OFF so existing parties/saves do not become invalid.
- Generation scope controls what can actually appear in wild encounters and
  is exported to the autonomous AI catch systems.
- Ability and held-item battle effects are runtime-gated and can be toggled.
