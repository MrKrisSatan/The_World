# The World 1.0.0

- Fully merged AI Rivals 7.6.3 and Weather FX 4.28.70.
- Renamed unified mod to The World (`the_world`).
- Weather integration is internal rather than an optional AI dependency.
- Added ZERO rivals to character creation; zero also suppresses rare special rivals.
- Added WEATHER / NO WEATHER character-creation choice.
- Added Weather Intensity: SOFT / NORMAL / HEAVY / AUTO.
- Added Weather Quality: AUTO / HIGH / MEDIUM / LOW.
- NO WEATHER forces the live sky clear/off and disables WX weather encounters.
- Preserved AI Rivals' Rocket, Rangers, classes, happiness, ecology, quests,
  Wonder Trade, championship and living-world simulation.
- Preserved Weather FX's fronts, seasons, day/night, battle weather, typed
  residuals, WX variants, 2D/3D atmosphere and compatibility systems.
