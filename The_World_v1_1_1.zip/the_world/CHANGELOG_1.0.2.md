# The World 1.0.2

- Added AI TRAINERS master switch to character creation and the unified menu.
- AI TRAINERS OFF suppresses rivals and stops Rocket/Ranger autonomous updates.
- Rival count automatically becomes ZERO when AI trainers are disabled.
- Added ALLOW WX POKEMON? to character creation.
- WX POKEMON remains independently switchable in the unified settings menu.
- WEATHER and AI TRAINERS are independent: AI-only and Weather-only saves are supported.
- WEATHER can stay ON with WX POKEMON OFF.
- Removed the separate AI options definition.
- Weather and AI settings now live on one combined The World settings page.
- Character-creation choices mirror into the same menu options when supported.
