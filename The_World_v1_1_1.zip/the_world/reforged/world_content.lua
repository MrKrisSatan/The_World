local mod = ...

local function option(key, default)
  local ok,v=pcall(function() return mod.options:get(key) end)
  if ok and v~=nil then return v end
  return default
end

local function on(key)
  local v=option(key,"on")
  return v==true or v=="on"
end

local function scopeMax()
  local v=option("worldContentScope","gen1_gen2_gen3")
  if v=="gen1" then return 151 end
  if v=="gen1_gen2" then return 251 end
  return 386
end

local Host=require("mods.the_world.reforged.core.host")
local PokemonGen2=require("mods.the_world.reforged.pokemon.pokemon_gen2")
local Gen2Compat=require("mods.the_world.reforged.core.gen2_compat")
local MoveEffects=require("mods.the_world.reforged.battle.move_effects")
local HeldItems=require("mods.the_world.reforged.items.held_items")
local Abilities=require("mods.the_world.reforged.battle.abilities")
local BattleCompat=require("mods.the_world.reforged.battle.battle_compat")

local okData,pokemon_data=pcall(require,"mods.the_world.reforged.pokemon_data")
if not okData or type(pokemon_data)~="table" then
  error("The World: merged Kanto Reforged pokemon_data failed to load",0)
end

local function dexOf(species)
  local row=pokemon_data.species and pokemon_data.species[species]
  if row and row.dex then return tonumber(row.dex) end
  local data=mod.activeGame and mod.activeGame.data
  row=data and data.pokemon and data.pokemon[species]
  return row and tonumber(row.dex) or nil
end

local function speciesAllowed(species)
  local dex=dexOf(species)
  return dex==nil or dex<=scopeMax()
end

mod.exports.worldSpeciesAllowed=speciesAllowed
mod.exports.worldContentScope=function() return option("worldContentScope","gen1_gen2_gen3") end
mod.exports.worldAbilitiesEnabled=function() return on("worldAbilities") end
mod.exports.worldHeldItemsEnabled=function() return on("worldHeldItems") end
mod.exports.worldModernMovesEnabled=function() return on("worldModernMoves") end

-- Types required by Gen2/3 species. They are always registered so later species
-- can safely exist in saves, while worldModernTypes controls modern matchup patches.
local okTypes,types_data=pcall(require,"mods.the_world.reforged.types_data")
if okTypes and type(types_data)=="table" then
  for id,record in pairs(types_data.types or {}) do
    if not mod.content.type_chart:get(id) then
      pcall(function() mod.content.type_chart:register(id,record) end)
    end
  end
  if on("worldModernTypes") then
    local TypeChartPatches=require("mods.the_world.reforged.battle.type_chart_patches")
    if Host.isGen2() then
      pcall(function() TypeChartPatches.applyModernTypes(mod,types_data) end)
    else
      for _,row in ipairs(types_data.matchups or {}) do
        local key=row.attacker..">"..row.defender
        pcall(function() mod.content.type_chart:register(key,{multiplier=row.multiplier}) end)
      end
    end
    pcall(function() TypeChartPatches.apply(mod) end)
  end
end

-- Move effects and move records remain registered even when GEN2/3 MOVES is OFF.
-- Runtime special behavior is gated, preserving old save/party references.
pcall(function() MoveEffects.register(mod) end)
pcall(function() MoveEffects.install(mod) end)

local goldReady=true
if Host.isGen2() then
  pcall(function() Gen2Compat.seedInfra(mod,pokemon_data) end)
  local ok,v=pcall(Gen2Compat.goldDataReady,mod)
  if ok then goldReady=v end
end

for id,record in pairs(pokemon_data.moves or {}) do
  pcall(function()
    local copy={}
    for k,v in pairs(record) do copy[k]=v end
    if Host.isGen2() then
      copy.effect=Gen2Compat.effectForMove(id,record.effect)
      if not mod.content.move_effects:get(copy.effect) then
        Gen2Compat.seedMoveEffectStubs(mod,{moves={[id]=copy}})
      end
    end
    mod.content.moves:register(id,copy)
  end)
end

pcall(function()
  local MoveAnims=require("mods.the_world.reforged.battle.move_anims")
  MoveAnims.register(mod,pokemon_data.moves)
  MoveAnims.install(mod)
end)

-- Species + sprites/palettes/dex. Register all through Gen3 for save safety.
if Host.isGen2() then
  PokemonGen2.registerForGold(mod,pokemon_data,{goldDataReady=goldReady})
else
  PokemonGen2.applyGen1DerivedSprites(mod,pokemon_data)
  local highest=151
  for id,record in pairs(pokemon_data.species or {}) do
    pcall(function() mod.content.pokemon:register(id,record) end)
    if record.dex and record.dex>highest then highest=record.dex end
  end
  pcall(function()
    mod.content.constants:patch("dexSize",highest)
    mod.content.constants:patch("dexDigits",math.max(3,#tostring(highest)))
  end)
end

pcall(function()
  local pals=require("mods.the_world.reforged.species_palettes")
  local Palette=require("mods.the_world.reforged.pokemon.palette_gen2")
  if Host.isGen2() then Palette.apply(mod,pals,pokemon_data)
  else Palette.applyGen1(mod,pals) end
end)

pcall(function()
  local Icons=require("mods.the_world.reforged.pokemon.species_icons")
  Icons.register(mod,pokemon_data.species)
end)

pcall(function()
  local DexEntries=require("mods.the_world.reforged.pokemon.dex_entries")
  DexEntries.bindAll(mod,pokemon_data.species)
  DexEntries.installInlineTextFallback(mod)
  if Host.isGen2() then DexEntries.bindGen2Pokedex(mod,pokemon_data.species) end
end)

-- Evolutions from Gen2/3 data.
pcall(function()
  for speciesId,newEvos in pairs(pokemon_data.evolutions or {}) do
    local existing=mod.content.pokemon:get(speciesId)
    if existing then
      local evos={}
      for _,e in ipairs(existing.evolutions or {}) do evos[#evos+1]=e end
      for _,e in ipairs(newEvos or {}) do evos[#evos+1]=e end
      mod.content.pokemon:patch(speciesId,{evolutions=evos})
    end
  end
end)

-- Learnset additions are registered. Availability of later-generation species
-- is controlled by the generation scope; modern move special behavior is gated.
pcall(function()
  local patches=require("mods.the_world.reforged.learnset_patches")
  local function known(id) return mod.content.moves:get(id)~=nil end
  for speciesId,adds in pairs(patches.learnset or {}) do
    local existing=mod.content.pokemon:get(speciesId)
    if existing then
      local field=Host.isGen2() and "levelMoves" or "learnset"
      local base=existing[field] or existing.learnset or existing.levelMoves or {}
      local out,seen={},{}
      for _,e in ipairs(base) do out[#out+1]=e; seen[e.move]=true end
      for _,e in ipairs(adds) do
        if e.move and known(e.move) and not seen[e.move] then
          out[#out+1]={level=e.level,move=e.move}; seen[e.move]=true
        end
      end
      table.sort(out,function(a,b)
        if a.level==b.level then return tostring(a.move)<tostring(b.move) end
        return (a.level or 0)<(b.level or 0)
      end)
      mod.content.pokemon:patch(speciesId,{[field]=out})
    end
  end
end)

-- Ability ids on species remain present, but battle effects can be switched off.
pcall(function()
  local patches=require("mods.the_world.reforged.ability_patches")
  for speciesId,ability in pairs(patches.abilities or {}) do
    if ability and ability~="NONE" and mod.content.pokemon:get(speciesId) then
      mod.content.pokemon:patch(speciesId,{ability=ability})
    end
  end
end)

-- Held item definitions remain registered for save safety.
pcall(function() HeldItems.register(mod) end)

-- Runtime gates around held-item mechanics.
local function gateHeld(name,neutral)
  local old=HeldItems[name]
  if type(old)~="function" then return end
  HeldItems[name]=function(...)
    if not on("worldHeldItems") then
      if type(neutral)=="function" then return neutral(...) end
      return neutral
    end
    return old(...)
  end
end
gateHeld("modifyDamage",function(damage) return damage end)
gateHeld("afterDamage",nil)
gateHeld("focusBandClamp",function(_,_,dmg) return dmg end)
gateHeld("tryStatusBerry",false)
gateHeld("tickStatusBerry",false)
gateHeld("maybeGiveWildHold",nil)
gateHeld("tryBagUse",false)
pcall(function() HeldItems.install(mod) end)
if Host.isGen1() then pcall(function() HeldItems.registerMarts(mod) end) end

-- Ability mechanics, intentionally runtime-gated.
mod.hooks:wrap("battle.damage",function(next,ctx)
  if not on("worldAbilities") then return next(ctx) end
  local damage,info=Abilities.onDamage(next,ctx)
  if damage and damage>0 then
    pcall(Abilities.onPostDamage,ctx.battle,ctx.user,ctx.target,ctx.move,damage)
  end
  return damage,info
end)

mod.hooks:wrap("battle.crit",function(next,ctx)
  if not on("worldAbilities") then return next(ctx) end
  local battle=(ctx and ctx.battle) or mod.activeBattle
  local target=ctx and (ctx.target or ctx.defender)
  if battle and target then
    local ab=Abilities.abilityOf(battle,target)
    if ab=="BATTLE_ARMOR" or ab=="SHELL_ARMOR" then return false end
  end
  return next(ctx)
end)

mod.hooks:wrap("battle.accuracy",function(next,ctx)
  if not on("worldAbilities") then return next(ctx) end
  local userAbility=Abilities.abilityOf(ctx.battle,ctx.user)
  local old
  if userAbility=="COMPOUND_EYES" and ctx.move and type(ctx.move.accuracy)=="number" then
    old=ctx.move.accuracy
    ctx.move.accuracy=math.min(100,math.floor(old*1.3))
  end
  local hit=next(ctx)
  if old then ctx.move.accuracy=old end
  if hit==false then return false end
  if userAbility=="HUSTLE" and ctx.move and (ctx.move.category=="physical") then
    local rng=(ctx.battle and ctx.battle.rng) or love.math.random
    if rng(0,99)>=80 then return false end
  end
  return hit
end)

mod.events:on("game.ready",function(ev)
  mod.activeGame=ev.game
end)

mod.events:on("battle.started",function(ev)
  mod.activeBattle=ev.battle
  if on("worldAbilities") and ev.battle then
    pcall(Abilities.onEntry,ev.battle,ev.battle.player)
    pcall(Abilities.onEntry,ev.battle,ev.battle.enemy)
  end
end)

mod.events:on("battle.battler_switched",function(ev)
  if on("worldAbilities") and ev.battle and ev.battler then
    pcall(Abilities.onEntry,ev.battle,ev.battler)
  end
end)

mod.events:on("battle.turn_started",function(ev)
  if on("worldAbilities") and ev.battle then
    pcall(Abilities.onTurnStart,ev.battle,ev.battle.player)
    pcall(Abilities.onTurnStart,ev.battle,ev.battle.enemy)
  end
end)

mod.events:on("battle.move_used",function(ev)
  if on("worldAbilities") and ev.battle then
    pcall(Abilities.onMoveUsed,ev.battle,ev.user,ev.move)
  end
end)

mod.events:on("battle.turn_ended",function(ev)
  if on("worldAbilities") and ev.battle then
    pcall(Abilities.onTurnEnded,ev.battle,ev.battle.player)
    pcall(Abilities.onTurnEnded,ev.battle,ev.battle.enemy)
  end
end)

mod.events:on("battle.ended",function(ev)
  if on("worldAbilities") and ev and ev.result=="win" and ev.battle then
    local party=ev.battle.game and ev.battle.game.save and ev.battle.game.save.party
    pcall(Abilities.tryPickup,ev.battle.game,party,ev.battle.rng)
  end
  pcall(BattleCompat.scrubBattle,ev and ev.battle)
  mod.activeBattle=nil
end)

-- Scope guard for actual wild encounters. Species are registered but cannot
-- appear beyond the selected generation.
mod.hooks:wrap("encounter.species",function(next,data,ctx)
  local out=next(data,ctx)
  if type(out)~="table" or not out.species or speciesAllowed(out.species) then return out end

  -- Resolve a legal local alternative from the same route table.
  local slots
  local mapId=ctx and ctx.mapId
  local row=data and data.encounters and mapId and data.encounters[mapId]
  if type(row)=="table" then slots=row.slots or row.grass or row end
  if not slots and data and data.gen2Encounters and mapId then
    for _,bucket in ipairs({data.gen2Encounters.grass,data.gen2Encounters.water}) do
      local r=bucket and bucket[mapId]
      if type(r)=="table" then slots=r.slots or r; break end
    end
  end
  for key,e in pairs(type(slots)=="table" and slots or {}) do
    local sp=type(e)=="table" and (e.species or e.mon or e.id)
      or (type(e)=="string" and e or (type(key)=="string" and key or nil))
    if sp and speciesAllowed(sp) then
      local lv=type(e)=="table" and (e.level or e.lvl or e.minLevel or e.min) or out.level
      return {species=sp,level=tonumber(lv) or out.level,worldScopeFallback=true}
    end
  end
  return out
end)

-- Save hygiene inherited from Kanto Reforged's Gen2 compatibility work.
mod.events:on("save.writing",function(ev)
  if ev and ev.save then
    pcall(BattleCompat.scrubPartyMons,ev.save.party)
  end
end)

mod.log:info("The World: merged Kanto Reforged Pokemon/moves/abilities/held items loaded")
return true
