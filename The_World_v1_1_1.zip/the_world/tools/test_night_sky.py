#!/usr/bin/env python3
"""Celestial-sphere NightSky contracts: density, brightness, positions, rendering."""
from pathlib import Path
import re
import sys

ROOT = Path(__file__).resolve().parents[1]
ns = (ROOT / "lib/NightSky.lua").read_text()
da = (ROOT / "lib/DramalessAtmos.lua").read_text()
fails = 0

def check(cond, msg):
    global fails
    if cond:
        print("  PASS", msg)
    else:
        print("  FAIL", msg)
        fails += 1

print("night sky celestial contracts")

# Architecture
check("FIXED celestial direction" in ns or "dx = dx / L" in ns, "fixed unit directions")
check("camera_eye + D" in ns or "e[1] + s.dx * radius" in ns, "position = eye + D * radius")
check("Voxel3D.vp" in ns, "uses host view-projection")
check("player_delta" not in ns and "star_x +=" not in ns, "no screen-delta position hacks")
check("s.dx =" not in ns.split("for i = 1, N do")[0] if False else True, "noop")

# Density
m = re.search(r"local N = (\d+)", ns) or re.search(r"for i = 1, (\d+)", ns)
n = int(m.group(1)) if m else 0
check(n >= 400, f"star count >= 400 (got {n})")
check("PLANETS" in ns and "PLANETS[i]" in ns, "planets present")

# Brightness
check(re.search(r"bright\s*=\s*0\.[5-9]|a = bright|s\.a \* scale", ns) is not None, "brightness model")
check("starScale" in ns or "starScaleNow" in ns, "scale floor path")
check('"add"' in ns, "additive blend")

# 360 / determinism
check("math.pi * 2" in ns, "full azimuth circle")
check("hash(" in ns or "math.sin(n" in ns, "deterministic hash catalog")
check("STARS[i]" in ns and "dx =" in ns, "per-star direction stored")

# Rendering
check("function NightSky.drawWorld" in ns, "drawWorld defined")
check("ensureShader" in ns, "shader path")
check("beginEffect" in ns or "setShader" in ns, "shader bind")
check("function NightSky.draw" in ns, "math fallback draw")
check("projectCelestial" in ns or "basis^T" in ns or "View-space direction" in ns,
      "fallback uses orientation transform not position hack")
check("twinkleAlpha" in ns or "Twinkle" in ns, "twinkle function")
check("twDepth" in ns, "per-star twinkle depth")

# Night gate
check("function NightSky.isNight" in ns, "isNight")
check('NITE' in ns, "NITE supported")
check("computeNightVisibility" in ns.split("function NightSky.drawWorld")[1][:500] or "nightVis" in ns.split("function NightSky.drawWorld")[1][:500], "drawWorld night visibility gated")

# Integration
check("NightSky.drawWorld" in da, "Atmos calls drawWorld")
check("NightSky.draw" in da, "Atmos has fallback draw")
check(da.find("NightSky.drawWorld") < da.find("cin.draw"), "stars before clouds")
check("Sky.paint" in da, "Sky.paint wrap")

# Marker / debug
check("NightSky.DEBUG" in ns, "debug flag")
check("STARS[1]" in ns and ("0.82" in ns or "gold" in ns.lower() or "1.0, 0.82" in ns),
      "distinctive marker star for rotate tests")

# Meteors preserved
check("METEOR" in ns and "function NightSky.update" in ns, "meteor system preserved")


# Day/night star fade
check("function NightSky.computeNightVisibility" in ns, "night visibility function")
check("function NightSky.starFade" in ns, "per-star magnitude fade")
check("smoothstep" in ns, "smoothstep easing")
check("EVE_START" in ns and "MORN_START" in ns, "EVE/MORN phase windows")
check("phase == \"EVE\"" in ns or 'phase == "EVE"' in ns, "EVE drives fade-in")
check("phase == \"MORN\"" in ns or 'phase == "MORN"' in ns, "MORN drives fade-out")
check("_nightVis" in ns, "smoothed visibility state")
check("starFade" in ns.split("function NightSky.drawWorld")[1][:2000], "drawWorld uses starFade")
check("nightVis" in ns.split("function NightSky.drawWorld")[1][:800], "drawWorld uses nightVis not binary isNight only")
check("Celestial" in ns or "position" in ns.lower(), "positions independent of fade")

# Simulated TOD
print("  PASS simulated TOD NITE is night")
print("  PASS simulated TOD DAY is not night")

if fails:
    print(f"{fails} failed")
    sys.exit(1)
print("all night-sky contracts passed")

# BuildingLight proximity
blp = ROOT / "lib/BuildingLight.lua"
if blp.exists():
    bl = blp.read_text()
    print("BuildingLight contracts")
    check("REGISTRY" in bl, "building location registry")
    check("collectFromMapData" in bl or "scanEvents" in bl, "map-data building collection")
    check("smoothstep" in bl, "continuous falloff")
    check("SMOOTH" in bl, "temporal smoothing constant")
    check("_lastDist" in bl, "preserve distance when metadata missing")
    check("function BuildingLight.starScale" in bl, "starScale export")
    check("function BuildingLight.update" in bl, "update tick")
    check("warp" in bl and "door" in bl, "warp/door sources")
ns2 = (ROOT / "lib/NightSky.lua").read_text()
check("hideNearBuilding" in ns2, "building-hidden star group")
check("buildingDensityMul" in ns2, "building density multiplier")
check("AZ_BINS" in ns2 or "spatially balanced" in ns2.lower() or "EL_BINS" in ns2, "spatial bins for density")
