#!/usr/bin/env python3
"""Static/data validation plus optional Lua behavioral contracts."""
from __future__ import annotations
import re, shutil, subprocess, sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
data = (ROOT / "lib" / "WeatherVariantsData.lua").read_text(encoding="utf-8")
rows = re.findall(r"\{ n=(\d+), id=\"([^\"]+)\", base=\"([^\"]+)\".*?weather=\"([^\"]+)\"", data)
kanto_data = (ROOT / "lib" / "KantoWeatherVariantsData.lua").read_text(encoding="utf-8")
kanto_rows = re.findall(r"\{ n=(\d+), id=\"([^\"]+)\", base=\"([^\"]+)\".*?weather=\"([^\"]+)\"", kanto_data)
errors = []
if len(rows) != 300: errors.append(f"expected 300 rows, got {len(rows)}")
if len({r[1] for r in rows}) != 300: errors.append("variant IDs are not unique")
if {int(r[0]) for r in rows} != set(range(1, 301)): errors.append("numbers are not exactly 1..300")
if len(kanto_rows) != 470: errors.append(f"expected 470 Kanto-only rows, got {len(kanto_rows)}")
if len({r[1] for r in kanto_rows}) != 470: errors.append("Kanto-only variant IDs are not unique")
if {int(r[0]) for r in kanto_rows} != set(range(301, 771)): errors.append("Kanto-only numbers are not exactly 301..770")
base_counts = {base: sum(1 for r in kanto_rows if r[2] == base) for base in {r[2] for r in kanto_rows}}
if len(base_counts) != 235 or set(base_counts.values()) != {2}:
    errors.append("Kanto #152-386 must each have exactly two variants")
if set(r[1] for r in rows) & set(r[1] for r in kanto_rows): errors.append("core and Kanto variant IDs overlap")
module = (ROOT / "lib" / "WeatherVariants.lua").read_text(encoding="utf-8")
dex_module = (ROOT / "lib" / "WeatherVariantDex.lua").read_text(encoding="utf-8")
config = (ROOT / "config.lua").read_text(encoding="utf-8")
for label in {r[3] for r in rows + kanto_rows}:
    if f'["{label}"]' not in module:
        errors.append(f"missing runtime weather mapping: {label}")
for token in ("encounterChance", "rareChance", "veryRareChance", "legendaryChance"):
    if token not in config: errors.append(f"missing rarity control: {token}")
for token in ("Dex.attach(row, clone)", "Dex.bindLive(Data, Variants.registered)"):
    if token not in module: errors.append(f"missing Pokédex integration: {token}")
for token in ("mod.content.text", "data.gen2Pokedex.entries[row.id]", "clone.dexEntry"):
    if token not in dex_module: errors.append(f"missing cross-generation dex bridge: {token}")
manifest = (ROOT / "manifest.json").read_text(encoding="utf-8")
if '"Kanto-Reforged"' not in manifest:
    errors.append("Kanto-Reforged is not declared as an optional dependency")
for token in ('mod.find("Kanto-Reforged")', 'if kantoReforgedInstalled() then', 'row.kantoReforged'):
    if token not in module: errors.append(f"missing Kanto-only runtime gate: {token}")
version_match = re.search(r'"version"\s*:\s*"([^"]+)"', manifest)
if not version_match or not re.fullmatch(r"\d+\.\d+\.\d+", version_match.group(1)):
    errors.append("custom build version must be strict launcher-safe x.y.z")
if '"github": "MrKrisSatan/Weather-fx"' not in manifest:
    errors.append("Weather FX GitHub auto-update source is missing or incorrect")

lua = next((shutil.which(x) for x in ("lua", "lua5.4", "lua5.3", "luajit") if shutil.which(x)), None)
if lua:
    result = subprocess.run([lua, str(ROOT / "tests" / "weather_variants_test.lua")])
    if result.returncode: errors.append("Lua behavioral contracts failed")
else:
    print("weather variants: Lua behavioral contracts skipped (no interpreter)")

if errors:
    for error in errors: print("FAIL", error)
    raise SystemExit(1)
print("weather variants: 300 core + 470 gated Kanto rows, dex entries, runtime gate PASS")
