#!/usr/bin/env python3
import math, sys
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]
failed = 0
def ok(c, m):
    global failed
    print(("PASS" if c else "FAIL"), m)
    if not c: failed += 1

src = (ROOT/"lib/CelestialBodies.lua").read_text()
sim = (ROOT/"lib/CelestialSim.lua").read_text() if (ROOT/"lib/CelestialSim.lua").exists() else ""
ok((ROOT/"lib/CelestialSim.lua").exists(), "CelestialSim exists")
ok("function Sim.sample" in sim, "Sim.sample")
ok("dirFromAlpha" in sim or "math.sin(alpha)" in sim, "east-zenith-west arc")
ok("math.pi" in sim, "moon opposite uses pi")

def dir_a(a):
    return math.cos(a), math.sin(a), 0.0
def alpha(h):
    return ((h-6)/24)*2*math.pi % (2*math.pi)

ok(abs(dir_a(alpha(6))[0]-1)<1e-6 and abs(dir_a(alpha(6))[1])<1e-6, "06:00 east")
ok(abs(dir_a(alpha(12))[0])<1e-6 and abs(dir_a(alpha(12))[1]-1)<1e-6, "12:00 overhead")
ok(abs(dir_a(alpha(18))[0]+1)<1e-6 and abs(dir_a(alpha(18))[1])<1e-6, "18:00 west")
ok(dir_a(alpha(0))[1] < -0.9, "00:00 below")

for i in range(48):
    a = alpha(i/2)
    m = (a + math.pi) % (2*math.pi)
    if abs(((m-a)%(2*math.pi))-math.pi) > 1e-9:
        ok(False, "180 sep"); break
else:
    ok(True, "180 sep")

print("RESULT", "OK" if not failed else "FAIL", failed)
sys.exit(1 if failed else 0)
