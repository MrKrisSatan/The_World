#!/usr/bin/env python3
"""Generate Gen 9 weather variant data for Weather FX.

Produces two weather variants per listed Gen 9 species (plus a few
notable forms). Output is lib/Gen9WeatherVariantsData.lua and an
optional markdown summary.

Usage:
  python3 tools/generate_gen9_weather_variants.py
"""
from __future__ import annotations

import re
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
OUT_LUA = ROOT / "lib" / "Gen9WeatherVariantsData.lua"
OUT_MD  = ROOT / "docs" / "GEN9_WEATHER_VARIANTS.md"

# Curated first-batch roster (starters + popular lines + legendaries / paradox).
# Expand this list later once full national_dex roster is available at build time.
SPECIES = [
    # Starters
    ("SPRIGATITO", "Sprigatito", ["GRASS"]),
    ("FLORAGATO", "Floragato", ["GRASS"]),
    ("MEOWSCARADA", "Meowscarada", ["GRASS", "DARK"]),
    ("FUECOCO", "Fuecoco", ["FIRE"]),
    ("CROCALOR", "Crocalor", ["FIRE"]),
    ("SKELEDIRGE", "Skeledirge", ["FIRE", "GHOST"]),
    ("QUAXLY", "Quaxly", ["WATER"]),
    ("QUAXWELL", "Quaxwell", ["WATER"]),
    ("QUAQUAVAL", "Quaquaval", ["WATER", "FIGHTING"]),
    # Early game
    ("LECHONK", "Lechonk", ["NORMAL"]),
    ("OINKOLOGNE", "Oinkologne", ["NORMAL"]),
    ("TAROUNTULA", "Tarountula", ["BUG"]),
    ("SPIDOPS", "Spidops", ["BUG"]),
    ("NYMBLE", "Nymble", ["BUG"]),
    ("LOKIX", "Lokix", ["BUG", "DARK"]),
    ("PAWMI", "Pawmi", ["ELECTRIC"]),
    ("PAWMO", "Pawmo", ["ELECTRIC", "FIGHTING"]),
    ("PAWMOT", "Pawmot", ["ELECTRIC", "FIGHTING"]),
    ("TANDEMAUS", "Tandemaus", ["NORMAL"]),
    ("MAUSHOLD", "Maushold", ["NORMAL"]),
    ("FIDOUGH", "Fidough", ["FAIRY"]),
    ("DACHSBUN", "Dachsbun", ["FAIRY"]),
    ("SMOLIV", "Smoliv", ["GRASS", "NORMAL"]),
    ("DOLLIV", "Dolliv", ["GRASS", "NORMAL"]),
    ("ARBOLIVA", "Arboliva", ["GRASS", "NORMAL"]),
    ("SQUAWKABILLY", "Squawkabilly", ["NORMAL", "FLYING"]),
    ("NACLI", "Nacli", ["ROCK"]),
    ("NACLSTACK", "Naclstack", ["ROCK"]),
    ("GARGANACL", "Garganacl", ["ROCK"]),
    ("CHARCADET", "Charcadet", ["FIRE"]),
    ("ARMAROUGE", "Armarouge", ["FIRE", "PSYCHIC_TYPE"]),
    ("CERULEDGE", "Ceruledge", ["FIRE", "GHOST"]),
    ("TADBULB", "Tadbulb", ["ELECTRIC"]),
    ("BELLIBOLT", "Bellibolt", ["ELECTRIC"]),
    ("WATTREL", "Wattrel", ["ELECTRIC", "FLYING"]),
    ("KILOWATTREL", "Kilowattrel", ["ELECTRIC", "FLYING"]),
    ("MASCHIFF", "Maschiff", ["DARK"]),
    ("MABOSSTIFF", "Mabosstiff", ["DARK"]),
    ("SHROODLE", "Shroodle", ["POISON", "NORMAL"]),
    ("GRAFAIAI", "Grafaiai", ["POISON", "NORMAL"]),
    ("BRAMBLIN", "Bramblin", ["GRASS", "GHOST"]),
    ("BRAMBLEGHAST", "Brambleghast", ["GRASS", "GHOST"]),
    ("TOEDSCOOL", "Toedscool", ["GROUND", "GRASS"]),
    ("TOEDSCRUEL", "Toedscruel", ["GROUND", "GRASS"]),
    ("KLAWF", "Klawf", ["ROCK"]),
    ("CAPSAKID", "Capsakid", ["GRASS"]),
    ("SCOVILLAIN", "Scovillain", ["GRASS", "FIRE"]),
    ("RELLOR", "Rellor", ["BUG"]),
    ("RABSCA", "Rabsca", ["BUG", "PSYCHIC_TYPE"]),
    ("FLITTLE", "Flittle", ["PSYCHIC_TYPE"]),
    ("ESPATHRA", "Espathra", ["PSYCHIC_TYPE"]),
    ("TINKATINK", "Tinkatink", ["FAIRY", "STEEL"]),
    ("TINKATUFF", "Tinkatuff", ["FAIRY", "STEEL"]),
    ("TINKATON", "Tinkaton", ["FAIRY", "STEEL"]),
    ("WIGLETT", "Wiglett", ["WATER"]),
    ("WUGTRIO", "Wugtrio", ["WATER"]),
    ("BOMBIRDIER", "Bombirdier", ["FLYING", "DARK"]),
    ("FINIZEN", "Finizen", ["WATER"]),
    ("PALAFIN", "Palafin", ["WATER"]),
    ("VAROOM", "Varoom", ["STEEL", "POISON"]),
    ("REVAVROOM", "Revavroom", ["STEEL", "POISON"]),
    ("CYCLIZAR", "Cyclizar", ["DRAGON", "NORMAL"]),
    ("ORTHWORM", "Orthworm", ["STEEL"]),
    ("GLIMMET", "Glimmet", ["ROCK", "POISON"]),
    ("GLIMMORA", "Glimmora", ["ROCK", "POISON"]),
    ("GREAVARD", "Greavard", ["GHOST"]),
    ("HOUNDSTONE", "Houndstone", ["GHOST"]),
    ("FLAMIGO", "Flamigo", ["FLYING", "FIGHTING"]),
    ("CETODDLE", "Cetoddle", ["ICE"]),
    ("CETITAN", "Cetitan", ["ICE"]),
    ("VELUZA", "Veluza", ["WATER", "PSYCHIC_TYPE"]),
    ("DONDOZO", "Dondozo", ["WATER"]),
    ("TATSUGIRI", "Tatsugiri", ["DRAGON", "WATER"]),
    ("ANNIHILAPE", "Annihilape", ["FIGHTING", "GHOST"]),
    ("CLODSIRE", "Clodsire", ["POISON", "GROUND"]),
    ("FARIGIRAF", "Farigiraf", ["NORMAL", "PSYCHIC_TYPE"]),
    ("DUDUNSPARCE", "Dudunsparce", ["NORMAL"]),
    ("KINGAMBIT", "Kingambit", ["DARK", "STEEL"]),
    ("GREAT_TUSK", "Great Tusk", ["GROUND", "FIGHTING"]),
    ("SCREAM_TAIL", "Scream Tail", ["FAIRY", "PSYCHIC_TYPE"]),
    ("BRUTE_BONNET", "Brute Bonnet", ["GRASS", "DARK"]),
    ("FLUTTER_MANE", "Flutter Mane", ["GHOST", "FAIRY"]),
    ("SLITHER_WING", "Slither Wing", ["BUG", "FIGHTING"]),
    ("SANDY_SHOCKS", "Sandy Shocks", ["ELECTRIC", "GROUND"]),
    ("IRON_TREADS", "Iron Treads", ["GROUND", "STEEL"]),
    ("IRON_BUNDLE", "Iron Bundle", ["ICE", "WATER"]),
    ("IRON_HANDS", "Iron Hands", ["FIGHTING", "ELECTRIC"]),
    ("IRON_JUGULIS", "Iron Jugulis", ["DARK", "FLYING"]),
    ("IRON_MOTH", "Iron Moth", ["FIRE", "POISON"]),
    ("IRON_THORNS", "Iron Thorns", ["ROCK", "ELECTRIC"]),
    ("FRIGIBAX", "Frigibax", ["DRAGON", "ICE"]),
    ("ARCTIBAX", "Arctibax", ["DRAGON", "ICE"]),
    ("BAXCALIBUR", "Baxcalibur", ["DRAGON", "ICE"]),
    ("GIMMIGHOUL", "Gimmighoul", ["GHOST"]),
    ("GHOLDENGO", "Gholdengo", ["STEEL", "GHOST"]),
    ("WO_CHIEN", "Wo-Chien", ["DARK", "GRASS"]),
    ("CHIEN_PAO", "Chien-Pao", ["DARK", "ICE"]),
    ("TING_LU", "Ting-Lu", ["DARK", "GROUND"]),
    ("CHI_YU", "Chi-Yu", ["DARK", "FIRE"]),
    ("ROARING_MOON", "Roaring Moon", ["DRAGON", "DARK"]),
    ("IRON_VALIANT", "Iron Valiant", ["FAIRY", "FIGHTING"]),
    ("KORAIDON", "Koraidon", ["FIGHTING", "DRAGON"]),
    ("MIRAIDON", "Miraidon", ["ELECTRIC", "DRAGON"]),
    ("WALKING_WAKE", "Walking Wake", ["WATER", "DRAGON"]),
    ("IRON_LEAVES", "Iron Leaves", ["GRASS", "PSYCHIC_TYPE"]),
    ("DIPPLIN", "Dipplin", ["GRASS", "DRAGON"]),
    ("POLTCHAGEIST", "Poltchageist", ["GRASS", "GHOST"]),
    ("SINISTCHA", "Sinistcha", ["GRASS", "GHOST"]),
    ("OKIDOGI", "Okidogi", ["POISON", "FIGHTING"]),
    ("MUNKIDORI", "Munkidori", ["POISON", "PSYCHIC_TYPE"]),
    ("FEZANDIPITI", "Fezandipiti", ["POISON", "FAIRY"]),
    ("OGERPON", "Ogerpon", ["GRASS"]),
    ("ARCHALUDON", "Archaludon", ["STEEL", "DRAGON"]),
    ("HYDRAPPLE", "Hydrapple", ["GRASS", "DRAGON"]),
    ("GOUGING_FIRE", "Gouging Fire", ["FIRE", "DRAGON"]),
    ("RAGING_BOLT", "Raging Bolt", ["ELECTRIC", "DRAGON"]),
    ("IRON_BOULDER", "Iron Boulder", ["ROCK", "PSYCHIC_TYPE"]),
    ("IRON_CROWN", "Iron Crown", ["STEEL", "PSYCHIC_TYPE"]),
    ("TERAPAGOS", "Terapagos", ["NORMAL"]),
    ("PECHARUNT", "Pecharunt", ["POISON", "GHOST"]),
]

# Two weather concepts per species (primary + secondary)
# Format: (variant_name, types_override_or_None, weather_label, preferred_ability)
VARIANT_TEMPLATES = [
    # Index 0 = first variant, Index 1 = second variant
    # These are applied in order; types can be overridden for flavour.
]

def species_id(name: str) -> str:
    value = name.upper().replace(" ", "_").replace("-", "_")
    value = value.replace("♀", "_F").replace("♂", "_M")
    return re.sub(r"[^A-Z0-9_]+", "_", value).strip("_")

def pick_variants(base: str, base_name: str, base_types: list[str]) -> list[tuple]:
    """Return two (variant, types, weather, ability) tuples for this species."""
    tset = set(base_types)
    results = []

    # Variant A – weather that plays to the primary typing
    if "WATER" in tset or "ICE" in tset:
        results.append(("TIDAL", base_types + (["ICE"] if "ICE" not in tset else []), "Hail", "ICE_BODY"))
    elif "FIRE" in tset:
        results.append(("CINDER", base_types + (["GHOST"] if "GHOST" not in tset else []), "Ashfall", "FLASH_FIRE"))
    elif "GRASS" in tset:
        results.append(("BLOOM", base_types + (["FAIRY"] if "FAIRY" not in tset else []), "Rain", "CHLOROPHYLL"))
    elif "ELECTRIC" in tset:
        results.append(("FROSTSPARK", base_types + (["ICE"] if "ICE" not in tset else []), "Snow", "STATIC"))
    elif "ROCK" in tset or "GROUND" in tset or "STEEL" in tset:
        results.append(("DUNE", base_types + (["GROUND"] if "GROUND" not in tset else []), "Sandstorm", "SAND_STREAM"))
    elif "GHOST" in tset or "DARK" in tset:
        results.append(("NIGHTFOG", base_types + (["GHOST"] if "GHOST" not in tset else []), "Moonlit Fog", "PRESSURE"))
    elif "FAIRY" in tset:
        results.append(("MOONLIT", base_types + (["DARK"] if "DARK" not in tset else []), "Moonlit Fog", "MAGIC_BOUNCE"))
    elif "DRAGON" in tset:
        results.append(("TEMPEST", base_types + (["FLYING"] if "FLYING" not in tset else []), "Storm", "SWIFT_SWIM"))
    elif "BUG" in tset:
        results.append(("DEW", base_types + (["WATER"] if "WATER" not in tset else []), "Rain", "SWIFT_SWIM"))
    elif "FLYING" in tset:
        results.append(("GALE", base_types + (["ELECTRIC"] if "ELECTRIC" not in tset else []), "Wind", "WIND_RIDER"))
    elif "PSYCHIC_TYPE" in tset:
        results.append(("DREAMFOG", base_types + (["GHOST"] if "GHOST" not in tset else []), "Moonlit Fog", "PRESSURE"))
    elif "FIGHTING" in tset:
        results.append(("BRAWL", base_types + (["DARK"] if "DARK" not in tset else []), "Storm", "GUTS"))
    elif "POISON" in tset:
        results.append(("VENOM", base_types + (["DARK"] if "DARK" not in tset else []), "Fog", "POISON_POINT"))
    else:
        results.append(("GALE", base_types + ["FLYING"], "Wind", "WIND_RIDER"))

    # Variant B – opposite / seasonal contrast
    if "FIRE" in tset or "DRAGON" in tset:
        results.append(("STORMDRAGON" if "DRAGON" in tset else "RAINSTORM",
                        (base_types + ["WATER"]) if "WATER" not in tset else base_types,
                        "Storm", "DRIZZLE"))
    elif "WATER" in tset or "ICE" in tset:
        results.append(("SUNFLARE",
                        (base_types + ["FIRE"]) if "FIRE" not in tset else base_types,
                        "Heatwave", "DROUGHT"))
    elif "GRASS" in tset:
        results.append(("WINTERBLOOM",
                        (base_types + ["ICE"]) if "ICE" not in tset else base_types,
                        "Snow", "SNOW_CLOAK"))
    elif "ELECTRIC" in tset:
        results.append(("TEMPEST",
                        (base_types + ["FLYING"]) if "FLYING" not in tset else base_types,
                        "Thunderstorm", "LIGHTNING_ROD"))
    elif "GHOST" in tset or "DARK" in tset:
        results.append(("CINDERGEIST",
                        (base_types + ["FIRE"]) if "FIRE" not in tset else base_types,
                        "Ashfall", "FLASH_FIRE"))
    else:
        results.append(("TEMPEST",
                        (base_types + ["ELECTRIC"]) if "ELECTRIC" not in tset else base_types,
                        "Thunderstorm", "STATIC"))

    # Deduplicate types while preserving order
    cleaned = []
    for variant, types, weather, ability in results[:2]:
        seen = set()
        uniq = []
        for t in types:
            if t not in seen:
                seen.add(t)
                uniq.append(t)
        cleaned.append((variant, uniq[:2], weather, ability))  # max 2 types
    return cleaned

def lua_str(s: str) -> str:
    return '"' + s.replace('\\', '\\\\').replace('"', '\\"') + '"'

def main():
    rows = []
    n = 1000  # start numbering well above Kanto / KR cohorts
    for base_id, base_name, base_types in SPECIES:
        for variant, types, weather, ability in pick_variants(base_id, base_name, base_types):
            n += 1
            uid = f"WX_{n}_{species_id(base_id)}_{species_id(variant)}"
            rows.append({
                "n": n,
                "id": uid,
                "base": base_id,
                "baseName": base_name,
                "variant": variant.upper(),
                "types": types,
                "weather": weather,
                "cohort": 4,
                "rarity": "rare",
                "ability": ability,
                "gen9": True,
            })

    # Write Lua
    lines = [
        "-- Generated by tools/generate_gen9_weather_variants.py; do not edit by hand.",
        "-- Loaded only when Gen9Dex (g9-battle-engine) is present.",
        "-- Two weather variants per Gen 9 species (first batch).",
        "local variants = {",
    ]
    for r in rows:
        type_lua = ", ".join(lua_str(t) for t in r["types"])
        lines.append(
            f'  {{ n={r["n"]}, id={lua_str(r["id"])}, base={lua_str(r["base"])}, '
            f'baseName={lua_str(r["baseName"])}, variant={lua_str(r["variant"])}, '
            f'types={{ {type_lua} }}, weather={lua_str(r["weather"])}, '
            f'cohort={r["cohort"]}, rarity={lua_str(r["rarity"])}, '
            f'ability={lua_str(r["ability"])}, gen9=true }},'
        )
    lines.extend(["}", "return variants", ""])
    OUT_LUA.write_text("\n".join(lines), encoding="utf-8")

    # Write short markdown
    md = [
        "# Gen 9 Weather Variants (first batch)",
        "",
        f"Generated {len(rows)} variants for {len(SPECIES)} species.",
        "Loaded only when Gen9Dex / g9-battle-engine is installed.",
        "",
        "| # | Base | Variant | Types | Weather | Ability |",
        "|---:|---|---|---|---|---|",
    ]
    for r in rows:
        types = "/".join(t.replace("_TYPE", "") for t in r["types"])
        md.append(f'| {r["n"]} | {r["baseName"]} | {r["variant"]} | {types} | {r["weather"]} | {r["ability"]} |')
    md.append("")
    OUT_MD.write_text("\n".join(md), encoding="utf-8")

    print(f"Generated {len(rows)} Gen 9 weather variants → {OUT_LUA}")
    print(f"Docs → {OUT_MD}")

if __name__ == "__main__":
    main()
