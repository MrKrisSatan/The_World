#!/usr/bin/env python3
"""Run full Weather FX tool + test suite. Use after every revision."""
from __future__ import annotations
import subprocess, sys
from pathlib import Path

HERE = Path(__file__).resolve().parent

def run(script, extra=None):
    print(f"\n===== {script} =====")
    cmd = [sys.executable, str(HERE / script)]
    if extra:
        cmd.extend(extra)
    r = subprocess.run(cmd)
    return r.returncode

def main():
    codes = []
    # Gate first — must pass for any ship
    codes.append(("revision_gate.py", run("revision_gate.py")))
    codes.append(("edit_guard.py", run("edit_guard.py")))
    codes.append(("test_night_sky.py", run("test_night_sky.py")))
    codes.append(("test_celestial.py", run("test_celestial.py")))
    codes.append(("test_celestial_lod.py", run("test_celestial_lod.py")))
    codes.append(("test_fog_intensity.py", run("test_fog_intensity.py")))
    codes.append(("test_constellations.py", run("test_constellations.py")))
    codes.append(("test_harden.py", run("test_harden.py")))
    codes.append(("test_world_precip.py", run("test_world_precip.py")))
    codes.append(("test_love_sandbox.py", run("test_love_sandbox.py")))
    codes.append(("test_mod.py", run("test_mod.py")))
    codes.append(("compat_aggressive.py", run("compat_aggressive.py")))
    if (HERE / "audit_compat.py").exists():
        codes.append(("audit_compat.py", run("audit_compat.py")))
    codes.append(("test_weather_companion.py", run("test_weather_companion.py")))
    # informational
    for s in ("ai_debug.py", "mod_map.py"):
        codes.append((s, run(s)))
    print("\n===== DONE =====")
    failed = [(n, c) for n, c in codes if c]
    if failed:
        print("FAILED:")
        for n, c in failed:
            print(f"  {n} exit {c}")
        return 1
    print("all ok — safe baseline for next revision")
    return 0

if __name__ == "__main__":
    sys.exit(main())
