#!/usr/bin/env python3
"""Every shipped Lua file, checked against the engine's `love` sandbox.

WHY THIS IS A SEPARATE TOOL.

tests/weather_fx_test.lua already checks for sandboxed `love` calls, and its own
comment says the quiet failure mode out loud:

    "A hardcoded list that new files are not added to is a guard that quietly
     stops guarding -- which is how this list came to be missing them."

It then went on to miss 21 of the 58 shipped Lua files, including
lib/voxel_atmos/WorldPrecip.lua -- the file whose 3D snow path was broken for
several releases. The Lua suite cannot fix this itself: it runs inside an
engine harness with no portable way to walk a directory, so it can only ever
check a list somebody remembered to update.

Python can walk the tree. So the Lua list stays (it runs in-engine, which is
worth having), and completeness is enforced here instead, where it can be
enforced by construction rather than by memory.

Two things are checked:
  1. no shipped file touches a sandboxed love API;
  2. the Lua suite's hardcoded FILES list still covers every shipped file --
     so if this ever gets deleted, the in-engine guard does not silently rot
     again.

The sandbox detail that makes this matter: the engine hands mods a `love`
facade that throws on `filesystem`, `thread`, `system` and `event`, and it
throws on the INDEX. `if love and love.system then` does not protect anything,
because asking is the throw. One such call on a per-frame path blanks the
screen.
"""
import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]

BLOCKED = ["filesystem", "thread", "system", "event"]

SKIP_DIRS = {"tests", "tools"}

# Accesses that are provably safe because the throw happens inside a pcall.
# Each entry must say why, and must be re-justified if the code moves.
#
# lib/Quality.lua: isMobileDevice() reads love.system.getOS inside
#   pcall(function() ... end), so the sandbox's index-time throw is caught and
#   the function returns false. This is safe as written.
#
#   NOTE FOR WHOEVER READS THIS NEXT: the long comment block further down
#   Quality.lua states that "the probe is gone rather than reworked". That is
#   no longer true -- the probe is still there and is still called from
#   platformDefault(). It was made pcall-safe instead of deleted. The code is
#   fine; the comment is stale and will mislead you.
ALLOW = {
    ("lib/Quality.lua", "system"),
}


def shipped_lua():
    out = []
    for p in sorted(ROOT.rglob("*.lua")):
        rel = p.relative_to(ROOT)
        if rel.parts and rel.parts[0] in SKIP_DIRS:
            continue
        out.append(rel.as_posix())
    return out


failures = []
files = shipped_lua()

# --- 1. no sandboxed love API on any shipped path ---------------------------
for rel in files:
    src = (ROOT / rel).read_text(encoding="utf8", errors="replace")
    for ln, line in enumerate(src.split("\n"), 1):
        if re.match(r"\s*--", line):
            continue          # the names are discussed in comments at length
        for name in BLOCKED:
            if re.search(r"\blove\." + name + r"\b", line):
                if (rel, name) in ALLOW:
                    continue
                failures.append(f"{rel}:{ln} touches sandboxed love.{name}")

# --- 2. the in-engine guard's list is still complete -------------------------
suite = ROOT / "tests/weather_fx_test.lua"
if suite.exists():
    text = suite.read_text(encoding="utf8", errors="replace")
    m = re.search(r"local FILES = \{(.*?)\n  \}", text, re.S)
    if not m:
        failures.append("tests/weather_fx_test.lua: FILES list not found")
    else:
        listed = set(re.findall(r'"([^"]+\.lua)"', m.group(1)))
        missing = sorted(set(files) - listed)
        stale = sorted(listed - set(files))
        for rel in missing:
            failures.append(
                f"tests/weather_fx_test.lua FILES list does not cover {rel} "
                f"-- the in-engine sandbox guard is not watching it"
            )
        for rel in stale:
            failures.append(
                f"tests/weather_fx_test.lua FILES list names {rel}, "
                f"which is not shipped"
            )

if failures:
    for f in failures:
        print("FAIL " + f)
    sys.exit(1)

print(f"PASS love sandbox ({len(files)} shipped Lua files, list complete)")
