#!/usr/bin/env python3
"""Structural checks for the world-space precipitation path.

READ THIS BEFORE ADDING A CHECK HERE.

Every assertion in the previous version of this file was a substring grep:
`"function WP.update" in wp`, `"STREAM_RADIUS" in wp`, and so on. All of them
passed, on every release, while WorldPrecip.lua was a hard compile error that
loaded on no host at all -- the file contained Lua 5.3 bitwise operators (`~`,
`>>`, `&`) that LuaJIT cannot parse, so `V.require("WorldPrecip")` threw and 3D
snow never ran. Greps cannot see that. They only prove text is present.

So the division of labour here is:

  * this file  -- wiring only: does module A still reference module B, are the
                  registration points intact. Cheap, no interpreter needed.
  * dialect    -- the LuaJIT compatibility scan below. This is the check that
                  would have caught the shipped bug, and it is the reason this
                  file is not purely greps any more.
  * behaviour  -- tests/world_precip_sim_test.lua, which loads and RUNS the
                  module. Particle counts, landing rates, near-field density,
                  face contact and allocation churn all live there, because
                  none of them can be established from source text.

If you are about to add an assertion about what the code DOES, it belongs in
the sim test, not here.
"""
import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
wp_path = ROOT / "lib/voxel_atmos/WorldPrecip.lua"
wp = wp_path.read_text()
ca = (ROOT / "lib/voxel_atmos/CinematicAtmos.lua").read_text()
da = (ROOT / "lib/DramalessAtmos.lua").read_text()

failures = []


def check(ok, msg):
    if not ok:
        failures.append(msg)


# --- wiring -----------------------------------------------------------------
check("function WP.update" in wp, "WP.update missing")
check("function WP.draw" in wp, "WP.draw missing")
check("STREAM_RADIUS" in wp, "STREAM_RADIUS missing")
check(
    any(s in wp.lower() for s in ("camera rotation", "camera orientation", "not camera")),
    "the camera-independence rule is no longer stated in WorldPrecip",
)
check("WorldPrecip.update" in ca, "CinematicAtmos no longer drives WorldPrecip")
check(
    'WorldPrecip = "lib/voxel_atmos/WorldPrecip.lua"' in da,
    "WorldPrecip is no longer registered in the DramalessAtmos namespace",
)

# handlesSnow must consult the 3D path rather than answering from a constant.
# Both a hardcoded true (blanks snow when 3D fails) and a hardcoded false
# (double-draws the 2D sheet over working 3D snow) have shipped.
m = re.search(r"function Atmos\.handlesSnow\(\).*?\nend", da, re.S)
check(m is not None, "Atmos.handlesSnow not found")
if m:
    body = m.group(0)
    check("drawingSnow" in body,
          "handlesSnow no longer asks WorldPrecip whether it is actually drawing")
check("function WP.drawingSnow" in wp, "WP.drawingSnow missing")


# --- dialect: LuaJIT is Lua 5.1 and has no bitwise operators ----------------
# This is the check that matters. Strings and comments are removed first so a
# `~` inside a shader source block or a prose comment does not trip it.
def strip_lua(src: str) -> str:
    out, i, n = [], 0, len(src)
    while i < n:
        if src.startswith("--", i):
            m2 = re.match(r"--\[(=*)\[", src[i:])
            if m2:
                close = "]" + m2.group(1) + "]"
                j = src.find(close, i)
                i = n if j < 0 else j + len(close)
            else:
                j = src.find("\n", i)
                i = n if j < 0 else j
            continue
        m2 = re.match(r"\[(=*)\[", src[i:])
        if m2:
            close = "]" + m2.group(1) + "]"
            j = src.find(close, i)
            i = n if j < 0 else j + len(close)
            out.append(" ")
            continue
        c = src[i]
        if c in "\"'":
            j = i + 1
            while j < n:
                if src[j] == "\\":
                    j += 2
                    continue
                if src[j] == c:
                    j += 1
                    break
                j += 1
            i = j
            out.append('""')
            continue
        out.append(c)
        i += 1
    return "".join(out)


BANNED = [
    (r"(?<![<>=~])~(?!=)", "bitwise ~"),
    (r">>", "bitwise >>"),
    (r"<<", "bitwise <<"),
    (r"(?<!&)&(?!&)", "bitwise &"),
    (r"(?<!/)//(?!/)", "integer division //"),
]

for path in sorted((ROOT / "lib").rglob("*.lua")) + sorted(ROOT.glob("*.lua")):
    body = strip_lua(path.read_text())
    for ln, line in enumerate(body.split("\n"), 1):
        for pat, why in BANNED:
            if re.search(pat, line):
                failures.append(
                    f"{path.relative_to(ROOT)}:{ln}: {why} is Lua 5.3 only and "
                    f"will not compile under LuaJIT"
                )

if failures:
    for f in failures:
        print("FAIL " + f)
    sys.exit(1)

print("PASS world precip (wiring + LuaJIT dialect)")
