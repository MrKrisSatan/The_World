#!/usr/bin/env python3
"""Static contracts for Weather FX weather-encounter companion integration."""
from __future__ import annotations
import json, re
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
errors = []
manifest = json.loads((ROOT / 'manifest.json').read_text())
if manifest.get('version') != '4.26.0': errors.append('version is not 4.26.0')
if 'Kanto-Reforged' not in manifest.get('optional_dependencies', []): errors.append('Kanto-Reforged dependency missing')
if 'BATTLE_ART_VOXEL_FORK' not in manifest.get('optional_dependencies', []): errors.append('Dramatic Shape 1.9.3 host dependency missing')

api = (ROOT / 'lib' / 'WeatherEncounterAPI.lua').read_text()
bridge = (ROOT / 'lib' / 'WeatherCompanionBridge.lua').read_text()
enc = (ROOT / 'lib' / 'Encounters.lua').read_text()
main = (ROOT / 'main.lua').read_text()
variants = (ROOT / 'lib' / 'WeatherVariants.lua').read_text()
bridge3d = (ROOT / 'lib' / 'DramalessAtmos.lua').read_text()
interop = (ROOT / 'lib' / 'Interop.lua').read_text()

def need(text, token, label):
    if token not in text: errors.append(f'{label}: missing {token}')

for token in ('function API.route', 'function API.species', 'catchRate = def.catchRate',
              'weatherVariant = true', 'variantChance', 'encounterPct',
              'Variants.data', 'Enc.currentOverlay(mapId)'):
    need(api, token, 'API')
for token in ('registerWeatherProvider', 'setWeatherProvider',
              'registerWeatherEncounterProvider', 'Kanto-Companion-Mobile'):
    need(bridge, token, 'companion bridge')
for token in ('variants = { grass = variantForecast(grassW), water = variantForecast(waterW) }',
              'weatherId = weatherId'):
    need(enc, token, 'encounter overlay')
for token in ('WeatherEncounterAPI = V.require("WeatherEncounterAPI")',
              'WeatherCompanionBridge = V.require("WeatherCompanionBridge")',
              'WeatherVariants.install',
              'mod.exports.weatherEncounters',
              'mod.exports.weatherPokemon',
              'mod.exports.weatherEncounterAPI'):
    need(main, token, 'main wiring')
need(variants, 'function Variants.install()', 'variant registration')
need(bridge3d, 'BATTLE_ART_VOXEL_FORK', 'Dramatic Shape 1.9.3 host')
need(interop, 'BATTLE_ART_VOXEL_FORK', 'Interop host list')
need(variants, 'if Variants.registered[row.id] then', 'idempotent registration')

# All core rows must have the metadata needed by the companion API.
data = (ROOT / 'lib' / 'WeatherVariantsData.lua').read_text()
rows = re.findall(r'\{ n=(\d+), id="([^"]+)", base="([^"]+)".*?weather="([^"]+)"', data)
if len(rows) != 300: errors.append(f'expected 300 core variant rows, got {len(rows)}')
if len(set(r[1] for r in rows)) != len(rows): errors.append('core variant ids are not unique')

if errors:
    for e in errors: print('FAIL', e)
    raise SystemExit(1)
print('weather companion API: route/species metadata, variant forecast, companion provider bridge PASS')
