#!/usr/bin/env python3
"""
Weather FX full audit tool.

Checks:
  - schema completeness vs Settings.get usage
  - dual/competing systems (sky, sun, fog)
  - compatibility risk patterns (Sky.paint wraps, host requires, crystal/gen3)
  - unfinished markers and fragile pcall density
  - celestial pipeline consistency
  - indoor weather gate presence
  - fog intensity wiring
  - file/syntax balance

Exit 0 always for report mode; --strict fails on HIGH findings.
"""
from __future__ import annotations
import argparse, json, re, sys
from pathlib import Path
from collections import defaultdict

ROOT = Path(__file__).resolve().parents[1]

def read(rel: str) -> str:
    p = ROOT / rel
    return p.read_text(errors="ignore") if p.exists() else ""

def all_lua():
    for p in ROOT.rglob("*.lua"):
        if "artifacts" in p.parts and p.parts[0] != str(ROOT):
            continue
        yield p.relative_to(ROOT).as_posix(), p.read_text(errors="ignore")

findings = []  # dict severity, area, msg, file

def add(sev, area, msg, file="-"):
    findings.append({"severity": sev, "area": area, "msg": msg, "file": file})

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--strict", action="store_true")
    ap.add_argument("--json", action="store_true")
    args = ap.parse_args()

    settings = read("lib/Settings.lua")
    main_lua = read("main.lua")
    ws = read("lib/WeatherState.lua")
    night = read("lib/NightSky.lua")
    cel = read("lib/CelestialBodies.lua")
    sim = read("lib/CelestialSim.lua")
    dram = read("lib/DramalessAtmos.lua")
    battle = read("lib/Battle.lua")
    draw = read("lib/Draw.lua")
    scene = read("lib/Scene.lua")
    fog = read("lib/Fog.lua")
    man = {}
    try:
        man = json.loads(read("manifest.json") or "{}")
    except Exception:
        add("HIGH", "meta", "manifest.json invalid", "manifest.json")

    # --- Schema keys ---
    keys = re.findall(r'key\s*=\s*"([^"]+)"', settings)
    add("INFO", "settings", f"{len(keys)} menu options: {', '.join(keys)}", "lib/Settings.lua")
    for need in ("fogIntensity", "intensity", "present", "battleAnim", "battleDamage"):
        if need not in keys:
            add("HIGH", "settings", f"missing schema key {need}", "lib/Settings.lua")

    # Settings.get usage for unknown keys (heuristic)
    used = set(re.findall(r'Settings\.get\(\s*"([^"]+)"\s*\)', "\n".join(t for _, t in all_lua())))
    schema = set(keys)
    orphan_gets = sorted(used - schema - {"debugRain"})  # debugRain is in schema
    for k in orphan_gets:
        if k in schema:
            continue
        add("MED", "settings", f"Settings.get({k!r}) used but not in SCHEMA", "-")

    # --- Indoor gate ---
    if "indoors" in ws and "State._indoorAccum" in ws:
        add("INFO", "indoor", "indoor/cave weather pause present", "lib/WeatherState.lua")
    else:
        add("HIGH", "indoor", "indoor weather gate missing", "lib/WeatherState.lua")

    # --- Fog intensity ---
    if "fogIntensity" in settings and "Settings.fogIntensity" in ws:
        add("INFO", "fog", "FOG INTENSITY wired Settings → WeatherState", "lib/WeatherState.lua")
    else:
        add("HIGH", "fog", "FOG INTENSITY not fully wired", "-")
    if "10.0" in settings or "10.0" in settings:
        add("INFO", "fog", "extreme 300% curve present", "lib/Settings.lua")
    if "math.min(0.55" in draw and "veil" in draw:
        add("MED", "fog", "old veil 0.55 hard cap may still exist somewhere", "lib/Draw.lua")
    if "0.92" in draw:
        add("INFO", "fog", "veil can reach high alpha for extreme fog", "lib/Draw.lua")

    # --- Celestial dual paths ---
    sun_paths = []
    if "drawSunMoonWorld" in night:
        sun_paths.append("NightSky.drawSunMoonWorld")
    if "function Celestial.drawWorld" in cel:
        sun_paths.append("CelestialBodies.drawWorld")
    if "wxPaintCelestialDisc" in main_lua:
        sun_paths.append("main wxPaintCelestialDisc / Sky.paint")
    if "CB.drawWorld" in dram:
        sun_paths.append("DramalessAtmos → CelestialBodies.drawWorld")
    if "drawSunMoonWorld" in dram:
        sun_paths.append("DramalessAtmos → NightSky.drawSunMoonWorld")
    add("INFO", "celestial", f"sun/moon draw paths: {', '.join(sun_paths) or 'NONE'}", "-")
    if len(sun_paths) >= 3:
        add("MED", "celestial",
            "Multiple sun/moon draw paths may fight (2D disc + 3D mesh + host body). "
            "In-game: confirm only one visible and orbit feels world-Y/overhead at noon.",
            "-")
    if "CelestialSim" not in sim and "function Sim.sample" not in sim:
        add("HIGH", "celestial", "CelestialSim missing", "lib/CelestialSim.lua")
    else:
        add("INFO", "celestial", "CelestialSim simulation layer present", "lib/CelestialSim.lua")

    # Camera ownership anti-patterns
    for rel, t in all_lua():
        if "camera.forward" in t or "cameraForward" in t:
            add("MED", "celestial", "camera.forward reference — check not used for celestial direction", rel)

    # --- Sky.paint wrap order risk ---
    wraps = 0
    if "function Sky.paint" in main_lua:
        wraps += 1
    if "function Sky.paint" in dram:
        wraps += 1
    if wraps >= 2:
        add("MED", "compat",
            f"{wraps} Sky.paint wrappers (main + DramalessAtmos). Order depends on install timing.",
            "-")

    # --- Battle / crystal / gen3 ---
    if "crystal" in battle.lower() or "CRYSTAL" in battle:
        add("INFO", "compat", "Crystal-aware battle paths present", "lib/Battle.lua")
    if "gen3" in battle.lower() or "Gen3" in battle or "battleOverlay" in read("lib/BattleDraw.lua"):
        add("INFO", "compat", "Gen3/battle UI coexistence hooks likely present", "lib/BattleDraw.lua")
    if "effectsEnabled" in read("lib/BattleDraw.lua") or "battleAnim" in settings:
        add("INFO", "compat", "BATTLE WEATHER FX/DMG toggles in schema", "lib/Settings.lua")

    # --- pcall density (swallow errors) ---
    for rel, t in all_lua():
        if not rel.startswith("lib/") and rel != "main.lua":
            continue
        n = t.count("pcall(")
        if n > 40:
            add("MED", "robustness", f"high pcall density ({n}) may hide runtime errors", rel)
        elif n > 80:
            add("HIGH", "robustness", f"very high pcall density ({n})", rel)

    # --- Syntax balance ---
    for rel, t in all_lua():
        if rel.startswith("tests/"):
            continue
        if abs(t.count("(") - t.count(")")) > 0:
            add("HIGH", "syntax", f"paren imbalance ({t.count('(')} vs {t.count(')')})", rel)
        # end/function rough
        # skip

    # --- Known unfinished from product surface ---
    unfinished = [
        ("constellations", "Pikachu/Charmander/etc constellations not found in NightSky"),
        ("constellation reveal", "one-time constellation twinkle system not in tree"),
        ("snow on trees/bushes", "vegetation snow accumulation not implemented"),
        ("rainbow after rain", "check Rainbow.lua present but may be incomplete"),
        ("2D/3D weather menu", "present mode exists; verify in-game on all voxel hosts"),
        ("sun FPV overhead", "player reports ongoing; dual draw paths still a risk"),
        ("god rays at NITE", "CinematicAtmos has night stops; verify on Dramaless"),
        ("permanent mod safety", "runtime hooks only by design — re-verify uninstall"),
    ]
    for area, msg in unfinished:
        # check rainbow
        if area.startswith("rainbow"):
            if "function" in read("lib/Rainbow.lua"):
                add("LOW", "unfinished", "Rainbow.lua exists — verify after-rain trigger in-game", "lib/Rainbow.lua")
            else:
                add("MED", "unfinished", msg, "-")
        elif area.startswith("constellation"):
            if "Pikachu" in night or "constellation" in night.lower():
                add("INFO", "unfinished", "constellation data present", "lib/NightSky.lua")
            else:
                add("MED", "unfinished", msg, "lib/NightSky.lua")
        elif "snow on" in area:
            if "tree" in read("lib/Particles.lua").lower() and "snow" in read("lib/Particles.lua").lower():
                add("LOW", "unfinished", "possible particle snow; vegetation accumulation unclear", "lib/Particles.lua")
            else:
                add("MED", "unfinished", msg, "-")
        else:
            add("MED", "unfinished", msg, "-")

    # --- Version ---
    add("INFO", "meta", f"version {man.get('version', '?')} id={man.get('id', '?')}", "manifest.json")

    # --- Report ---
    order = {"HIGH": 0, "MED": 1, "LOW": 2, "INFO": 3}
    findings.sort(key=lambda f: (order.get(f["severity"], 9), f["area"], f["msg"]))

    if args.json:
        print(json.dumps(findings, indent=2))
    else:
        print("=== WEATHER FX FULL AUDIT ===\n")
        by = defaultdict(list)
        for f in findings:
            by[f["severity"]].append(f)
        for sev in ("HIGH", "MED", "LOW", "INFO"):
            items = by.get(sev) or []
            if not items:
                continue
            print(f"## {sev} ({len(items)})")
            for f in items:
                print(f"  [{f['area']}] {f['msg']}")
                if f["file"] != "-":
                    print(f"           → {f['file']}")
            print()
        print(f"Total findings: {len(findings)}")
        print(f"HIGH={len(by['HIGH'])} MED={len(by['MED'])} LOW={len(by['LOW'])} INFO={len(by['INFO'])}")

    highs = sum(1 for f in findings if f["severity"] == "HIGH")
    if args.strict and highs:
        return 1
    return 0

if __name__ == "__main__":
    sys.exit(main())
