#!/usr/bin/env python3
from pathlib import Path
import sys
ROOT = Path(__file__).resolve().parents[1]
failed = 0
def ok(c,m):
    global failed
    print(("PASS" if c else "FAIL"), m)
    if not c: failed += 1
c = (ROOT/"lib/Constellations.lua").read_text()
ns = (ROOT/"lib/NightSky.lua").read_text()
ok("Pikachu" in c and "Charmander" in c and "Squirtle" in c and "Bulbasaur" in c, "four Pokémon")
ok("densify" in c, "outline densify")
ok("ANCHORS" in c, "spread anchors")
ok("appendWorld" in c, "appendWorld")
ok("Constellations" in ns and "appendWorld" in ns, "NightSky wires constellations")
ok("math.rad(25)" in c or "rad(25)" in c, "Pikachu anchor")
ok("math.rad(115)" in c or "rad(115)" in c, "Charmander ~90° away")
print("RESULT", "OK" if not failed else "FAIL", failed)
sys.exit(1 if failed else 0)
