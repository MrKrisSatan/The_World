# Weather FX tools

Run after **every revision** before shipping a zip.

## Required gate

```bash
cd weather_fx
python3 tools/revision_gate.py   # must exit 0
python3 tools/run_all.py         # full suite
```

| Tool | Role |
|------|------|
| **revision_gate.py** | Bugs, labels, battle toggles, night sky, indoor, clear fog, gen3/Crystal/Dramaless markers |
| **test_mod.py** | Structure + 3D bridge contracts |
| **test_night_sky.py** | Star field / celestial contracts |
| **edit_guard.py** | Post-edit contract checks |
| **run_all.py** | Runs gate + tests + maps |
| ai_debug.py / mod_map.py | Diagnostics |

## AI / human workflow

1. Edit only Weather FX (unless user says otherwise).
2. `python3 tools/revision_gate.py` — fix until exit 0.
3. `python3 tools/run_all.py` — full pass.
4. Zip + CHANGELOG version bump.

Baseline starts at **4.18.6**.


## Audit tools

```bash
python3 tools/audit_full.py          # full product/code audit
python3 tools/audit_full.py --json   # machine-readable
python3 tools/audit_compat.py        # host/companion mod matrix
python3 tools/run_all.py             # includes audits
```
