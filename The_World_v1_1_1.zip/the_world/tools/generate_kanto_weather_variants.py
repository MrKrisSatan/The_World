#!/usr/bin/env python3
"""Generate two weather variants for Kanto Reforged species #152-386."""
from __future__ import annotations
import re, sys
from pathlib import Path

PROFILES = {
    "NORMAL": (("GALE", "Wind", "FLYING"), ("UMBRAL", "Eclipse", "DARK")),
    "FIRE": (("CINDER", "Ashfall", "GHOST"), ("SOLAR", "Heatwave", "DRAGON")),
    "WATER": (("TEMPEST", "Storm", "ELECTRIC"), ("RIME", "Hail", "ICE")),
    "ELECTRIC": (("STATIC", "Thunderstorm", "STEEL"), ("AURORA", "Aurora", "FAIRY")),
    "GRASS": (("BLOOM", "Spring Rain", "FAIRY"), ("AUTUMN", "Autumn Rain", "GHOST")),
    "ICE": (("WHITEOUT", "Blizzard", "GHOST"), ("AURORA", "Aurora", "PSYCHIC_TYPE")),
    "FIGHTING": (("TEMPEST", "Wind", "FLYING"), ("IRON", "Dust Storm", "STEEL")),
    "POISON": (("CAUSTIC", "Acid Rain", "WATER"), ("SMOG", "Smog", "DARK")),
    "GROUND": (("DUNE", "Sandstorm", "ROCK"), ("MIRE", "Heavy Rain", "WATER")),
    "FLYING": (("TEMPEST", "Typhoon", "WATER"), ("AURORA", "Aurora", "FAIRY")),
    "PSYCHIC_TYPE": (("DREAMFOG", "Moonlit Fog", "GHOST"), ("ECLIPSE", "Eclipse", "DARK")),
    "BUG": (("DEW", "Rain", "WATER"), ("ASHEN", "Ashfall", "FIRE")),
    "ROCK": (("DUNE", "Sandstorm", "GROUND"), ("FOSSILFROST", "Hail", "ICE")),
    "GHOST": (("MOONVEIL", "Moonlit Fog", "FAIRY"), ("STATIC", "Static Storm", "ELECTRIC")),
    "DRAGON": (("TEMPEST", "Typhoon", "WATER"), ("ECLIPSE", "Eclipse", "DARK")),
    "DARK": (("NIGHTFOG", "Moonlit Fog", "GHOST"), ("DUST", "Dust Storm", "GROUND")),
    "STEEL": (("RIME", "Hail", "ICE"), ("STATIC", "Thunderstorm", "ELECTRIC")),
    "FAIRY": (("AURORA", "Aurora", "ICE"), ("MOONDEW", "Moonlit Rain", "WATER")),
}
LEGENDARY_DEX = {243,244,245,249,250,251,377,378,379,380,381,382,383,384,385,386}

def species_blocks(source: str):
    start = source.index("P.species = {")
    end = source.index("\nP.evolutions =", start)
    section = source[start:end]
    return re.findall(r"^  ([A-Z0-9_]+) = \{\n(.*?)(?=^  [A-Z0-9_]+ = \{|^\})", section, re.M | re.S)

def parse(path: Path):
    rows = []
    for sid, body in species_blocks(path.read_text(encoding="utf-8")):
        dex = int(re.search(r"\bdex = (\d+)", body).group(1))
        if not 152 <= dex <= 386: continue
        name = re.search(r'\bname = "([^"]+)"', body).group(1).title()
        type_body = re.search(r"\btypes = \{(.*?)\n    \}", body, re.S).group(1)
        types = re.findall(r'"([A-Z_]+)"', type_body)
        catch = re.search(r"\bcatchRate = (\d+)", body)
        rows.append((dex, sid, name, types, int(catch.group(1)) if catch else 45))
    rows.sort()
    if len(rows) != 235 or [r[0] for r in rows] != list(range(152, 387)):
        raise SystemExit(f"expected complete #152-386 catalog, got {len(rows)} species")
    return rows

def quote(value: str): return '"' + value.replace('"', '\\"') + '"'

def main():
    if len(sys.argv) != 3: raise SystemExit("usage: generate_kanto_weather_variants.py KANTO_POKEMON_DATA.lua OUT.lua")
    species = parse(Path(sys.argv[1]))
    out = ["-- Generated from Kanto Reforged 1.2.0 species #152-386.", "-- Loaded only after Weather FX detects the optional Kanto-Reforged mod.", "local variants = {"]
    number = 301
    for cohort, profile_index in ((3, 0), (4, 1)):
        for dex, sid, name, base_types, catch in species:
            variant, weather, added = PROFILES.get(base_types[0], PROFILES["NORMAL"])[profile_index]
            types = list(base_types[:1])
            if added not in types: types.append(added)
            rarity = "legendary" if dex in LEGENDARY_DEX or catch <= 3 else ("veryRare" if catch <= 25 else "rare")
            uid = f"WX_{number:03d}_{sid}_{variant}"
            type_lua = ", ".join(quote(t) for t in types)
            out.append(f"  {{ n={number}, id={quote(uid)}, base={quote(sid)}, baseName={quote(name)}, variant={quote(variant)}, types={{ {type_lua} }}, weather={quote(weather)}, cohort={cohort}, rarity={quote(rarity)}, kantoReforged=true }},")
            number += 1
    out += ["}", "return variants", ""]
    if number != 771: raise SystemExit(f"expected 470 variants, generated {number - 301}")
    Path(sys.argv[2]).write_text("\n".join(out), encoding="utf-8")
    print("generated 470 Kanto Reforged-only weather variants")

if __name__ == "__main__": main()
