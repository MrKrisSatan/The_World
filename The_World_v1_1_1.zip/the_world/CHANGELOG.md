# Weather FX 4.28.70

## Snow lumped around the player instead of covering the world

**Cause: `SNOW_RADIAL_BIAS = 4.0`, which I set in 4.28.69.** That was my error,
not a pre-existing one, and the reasoning behind it was wrong in an instructive
way.

Chasing first-person density, 4.28.69 sampled flake radius as `R * u^4.0`, which
put ~38% of live flakes within 25 units of the focus. On paper that is "dense
snow where you are". On screen it is a snow globe travelling with the player
over an otherwise clear world — a lump, exactly as reported.

Measured density per 1000 u², inner/mid/outer thirds of the rendered disk:

| bias | inner | mid | outer | spread |
|------|-------|-----|-------|--------|
| 4.0 (4.28.69) | 92.11 | 31.76 | 17.86 | **5.16x** |
| 1.0 | — | — | — | 5.16x |
| **0.5 (now)** | 29.59 | 31.50 | 28.82 | **1.09x** |

0.5 is uniform density per unit *area*, which is what real snowfall is. Note
1.0 is not neutral either: `rad = R * u` spreads uniformly in *radius*, which
concentrates as 1/r.

The deeper mistake was manufacturing near-field density in the spawn
distribution at all. Perspective already delivers it — near flakes subtend far
more screen area than distant ones. Distribute uniformly and let the projection
do its job. If the near field looks thin, the honest dial is more flakes per
tile, not a bias that empties the map.

## Flake count now derives from rendered area

A fixed 4200-flake budget spread over a wider render distance just stretches the
same handful thinner. The count is now `SNOW_PER_TILE x rendered tiles x
intensity x quality`, so a larger rendered world gets proportionally more snow —
"if the game is rendering more than normal, it should be snowing everywhere
there are rendered tiles". This matches how the rest of CinematicAtmos already
works, holding density per world cell constant.

- `SNOW_PER_TILE = 8.0`, `SNOW_MAX` raised to 9000 as a clamp rather than a
  target. At the default 300-unit radius that is ~8800 live flakes.
- The disk radius follows the host's camera far plane (`Voxel3D.far`, the same
  source NightSky and CelestialBodies read), at 0.85x, clamped to 160–900. The
  snow volume tracks what the host actually renders.
- **One deck height for the whole field.** The old per-flake ceiling scaled with
  spawn radius, which silently skewed the standing population: a flake with a
  short column recycles in seconds while one with a tall column lives ten times
  as long, so even a uniform spawn ended up far-heavy. A single deck makes
  standing density match spawn density — without this, uniform spawning does not
  stay uniform.

## Snow now falls a full tile further

`GROUND_DROP` was 1.5 units — under a tenth of a tile — so flakes settled about
a tile above where the world's floor reads. It is now `1.5 + 1 tile` (17.5
units, one tile being 16). Expressed as `GROUND_EXTRA_TILES` so it stays
meaningful if the focus origin moves: raise to 2 if snow still stops short, drop
to 0 for the old plane. Verified: flakes descend 17.9 units (1.12 tiles).

## Face contact was tuned against the wrong scale

`FACE_R = 1.5` was a guess. A tile is 16 units, so a head is roughly 6 units
across — 1.5 made contact vanishingly rare once the field became uniform, since
even coverage puts far fewer flakes within arm's reach than the old near-biased
spawn did. Now 3.0, measuring ~3–4 hits per 45 seconds: present, not constant.

## Tests

Three assertions added, each mutation-verified:

- **Even coverage.** Density is measured per unit area across inner, mid and
  outer thirds of the disk and the spread is bounded. Reverting the bias to 1.0
  fails it at 5.16x.
- **Fall depth.** Both the ground plane and the depth flakes *actually reach*
  are checked in tiles — the second because a constant can be changed without
  the sim following it. Reverting `GROUND_EXTRA_TILES` fails both.
- **Per-tile coverage**, so the area-derived count cannot silently revert to a
  fixed budget.

## Still unverified by test

Flake size and the look of the tumble remain things no test here can see. The
debug line reports `land=`, `face=` and the per-tile density; if coverage looks
wrong on screen, `WP.tune{ perTile = N }` is the dial, not the bias.

---

# Weather FX 4.28.69

## The 3D snow was never running — one dead function stopped the whole module

**Root cause.** `lib/voxel_atmos/WorldPrecip.lua` contained a `hash()` helper
written with Lua 5.3 bitwise operators:

```lua
n = ((n ~ (n >> 15)) * 2246822519) & 0xffffffff
```

LuaJIT is Lua 5.1 and has no bitwise operators at all — it has the `bit`
library instead. So the file was a **compile error**, not a runtime one:
`V.require("WorldPrecip")` threw, `WorldPrecip` stayed `nil` forever, and
CinematicAtmos silently fell through to its `else` branch. Since 4.28.68
disabled `drawSnow3D`, that branch contains no snow at all. What was on screen
was the 2D overlay from `Particles.lua`, which `Atmos.handlesSnow()` was
keeping alive with a hardcoded `return false`.

`hash()` was dead code. Nothing ever called it. One unused function took the
entire world-space precipitation system offline, and nothing reported it,
because a mod that fails to load degrades silently by design.

**Four more faults were hiding behind it.** Each would have aborted
precipitation every frame even on a host where the file compiles:

- `far()`, `addGroundSnow()` and `spawnGrainAt()` were called but never
  defined — plain nil globals. The sand/ash/debris family could never run.
- `getGrainShader` was called ~16 lines above its `local function`
  declaration, so it too resolved as a nil global.
- `ensureGSnow()` existed and was never called, so `gsnow.n` stayed 0 and
  ground accumulation could not draw.

`WP.update` and `WP.draw` share one `pcall` in CinematicAtmos, so all of this
failed with no log line.

---

## Snow rebuilt for first person

Rain is untouched — every constant, the spawn function, the integration and the
streak geometry are the original math. The cloud bank is untouched; snow now
only *reads* a deck height so flakes fall out of it. Measurements below are
from 50–60 simulated seconds at `SNOW` at a fixed particle cap.

- **Density where you actually are.** The old volume was a 720-unit radius
  against rain's known-good 220. Area goes as r², so most of the budget sat
  past the range where a flake covers a pixel, while the space you walk through
  was empty. Now a 300-unit volume with radial sampling biased toward the
  focus. Share of live flakes within 25 units: **4.7% → 38.1%**.
  - Note the spawn rate is not the density: near flakes fall ~50 units and
    recycle in seconds while far ones live ten times as long, so the standing
    population skews outward even when spawning is biased inward. The exponent
    is tuned against measured standing density, not against spawn rate.
- **Flakes land instead of evaporating.** Lifetime is derived from
  time-to-ground rather than a flat 3.5–10.5s range. Share of flakes finishing
  on the ground rather than vanishing mid-air: **26.6% → 100%**. Three flakes
  in four used to disappear in the air, which is the single most "screensaver"
  thing a snow system can do.
- **Look up.** The near-column ceiling is raised so roughly 100 units of snow
  sit above your head; straight up is served by the near column only.
- **Flakes land on your face.** A flake passing within 1.5 units of the eye is
  consumed and leaves a melting speck. This is a consequence of the simulation
  — the speck exists only because a real simulated flake really intersected the
  eye sphere — drawn as world geometry in the same depth-tested pass, pinned
  off the eye along the direction the flake arrived from. First person only.
- **Flakes tumble.** `snow.rot` / `snow.spin` were simulated every frame and
  then never read by the renderer, so every flake drew as the same
  axis-aligned blob. The billboard basis is rotated now.
- **Per-flake brightness** breaks up the repeated-sprite read; the snow shader
  no longer hardcodes white.
- **Terminal velocity is clamped**, so a flake settles instead of accelerating
  into a raindrop over its lifetime.
- **Every snowy weather works.** The classifier missed all `FROST*` variants
  plus `ICEBOUND` and `WHITEOUT` — those produced zero 3D snow. Exact ids
  first, then prefixes, so a new `FROSTWHATEVER` is snowy by default.

## Performance

- **Draw path allocation: ~22 KB/frame → 0.09 KB/frame.** The old code built a
  fresh table per vertex plus a fresh closure per particle — about 25,200
  allocations a frame at the snow cap. The GC, not the GPU, was the ceiling.
  Vertices now go into a persistent preallocated buffer, mutated in place and
  uploaded as a prefix, with the mesh reallocated only when the high water mark
  rises.
- Snow turbulence used three `math.sin`/`cos` calls per flake per frame (~12,600
  a frame at cap); replaced with a 1024-entry lookup.
- Per-frame `pcall(function() ... end)` closures for the Quality and Settings
  reads are cached on a one-second interval.
- Distant flakes are culled from the vertex build. The simulation still
  integrates them, per the module's architecture rule.

## `V.require` inside `lib/voxel_atmos/` was broken

`buildNamespace` in DramalessAtmos resolved voxel_atmos modules, five stubs and
host modules — then errored. It never chained back to the mod's own loader, so
`V.require("Quality")` and `V.require("Settings")` failed everywhere in that
directory. Every call site wraps them in `pcall`, so they failed silently
forever. The visible consequence: **the QUALITY setting did nothing for 3D
precipitation** — `worldPrecip` was pinned at 1.0 on every tier including
potato. The namespace now falls through to the mod's loader last, so a host
module still wins.

## 2D snow suppression now asks instead of assuming

`Atmos.handlesSnow()` returned a hardcoded `false`, so the 2D sheet always drew.
With 3D snow working, drawing both is exactly what makes world snow look like an
overlay. It now asks `WorldPrecip.drawingSnow()`, which reports whether flake
geometry was actually emitted on the last frame — not whether it was supposed to
be. Fail-closed: any doubt keeps the 2D layer, so a missing host or a failed
load still shows snow.

## Tests

- **`tests/world_precip_sim_test.lua` (new).** Loads and *runs* the module: 46
  assertions covering particle activity, landing rate, near-field density, face
  contact, first-person gating, rain, all three grain families, quality scaling,
  mesh reuse and allocation churn.
- **`tools/test_world_precip.py` rewritten.** Every assertion in the old version
  was a substring grep — all of them passed on every release while the module
  was a hard compile error. It now scans the whole mod for Lua 5.3-only
  operators, which is the check that would have caught the shipped bug.
- **`tools/test_love_sandbox.py` (new).** The Lua suite's `love`-sandbox guard
  works from a hardcoded file list, and its own comment warns that such a list
  "quietly stops guarding". It covered 37 of 58 shipped files; the largest
  omission was `WorldPrecip.lua` itself. The list is now complete, and
  completeness is enforced by walking the tree rather than by memory.
- Every fix above was verified by mutation: reverting it individually makes the
  suite fail. Two assertions that survived their mutation were found this way
  and replaced — one measured ground coverage (also seeded by ambient scatter,
  so it could not witness whether flakes land) and one used a threshold so
  loose a 244× allocation regression sailed past it.

## Known, unverified by test

Tumble rotation, terminal-velocity clamp and flake sizing are *look*, and no
test in this repo can see the screen. They need eyes on them. The debug line now
reports `land=N/M` and `face=N/M`: if `land` is not near 100%, or `face` stays 0
in first person, the sim is not doing what this changelog claims.

## Stale comment worth knowing about (not changed)

`lib/Quality.lua` states that the `love.system` platform probe "is gone rather
than reworked". It is not gone — `isMobileDevice()` still calls it and is still
reached from `platformDefault()`. The code is safe (the access is inside a
`pcall`, so the sandbox's index-time throw is caught), but the comment will
mislead the next reader. Left alone as out of scope; noted in
`tools/test_love_sandbox.py`'s allowlist.

---

# Weather FX 4.28.68

## Kill camera-locked snow

**Cause:** `drawSnow3D` in CinematicAtmos rebuilt flakes around the camera/focus every frame (cell lattice + shader animation). That is why particles stayed locked to the view.

**Fix:**
- `drawSnow3D` disabled
- Only WorldPrecip draws falling snow (world-space, like rain)
- 2D snow forced off in first-person
- Retry loading WorldPrecip at draw time if needed

---

# Weather FX 4.28.67

## Snow falls like rain — from the sky over the whole map

**Root cause:** 3D snow intensity was never driven from the Weather FX weather id, so WorldPrecip often had `snowIntensity = 0` and spawned nothing. Rain worked because its intensity was wired.

**Fixes:**
- CinematicAtmos now sets `snowIntensity` / `snowWind` from snowy WX ids (same pattern as sand/ash)
- WorldPrecip falls back to snowy WX targets if intensity is still 0
- Snow spawn mirrors rain: **360° over the map**, Y starts at the **cloud bank**, falls to the ground on every tile in the stream volume
- No camera-locked sheet; flakes are world XZ/Y; you walk through them
- 2D snow still suppressed when 3D precip is active

---

# Weather FX 4.28.66

## FPV world-space snow redesign

Snow is no longer a camera-locked overlay.

- **No player wrap** — flakes keep real world positions; walking moves *you* through them
- **Map-wide volume** — ~720 unit radius, full 360° around the focus, high cloud deck to ground
- **Up to ~4200** independent flakes with wind, tumble, and soft gravity
- Ground contact builds snow patches; flakes recycle only when finished/far (new spawn in the volume)
- When 3D precip is active, **2D snow is suppressed** so FPV only shows world snow
- Depth scaling keeps near and far flakes readable

---

# Weather FX 4.28.65 — BASELINE

**This is the current baseline.** All future work starts from this build.

Includes:
- Continuous rain SFX (plays only with rain on screen; stops on weather change)
- World-anchored lightning (outer-ring strikes, away from player)
- Thunder one-shots fixed (not killed by rain-bed gate)
- Lightning animation restored (fast first strike, FULL mode always draws bolt)
- Unresolved variant move scrub
- Full pipeline audit harden

---

# Weather FX 4.28.65

## Lightning animation restored

- First strike fires within ~1s after storm strike-rate becomes active
- FULL mode always draws the bolt (no longer blocked by quality potato/low)
- Stronger screen flash so strikes are obvious
- More reliable polyline drawing on mobile GLES
- GALE now includes a modest strike rate

Still: outer-ring impacts only (away from player) + splash-style world anchor

---

# Weather FX 4.28.64

## Fix: thunder / lightning sounds

**Cause**
- Thunder one-shots were stopped every frame whenever rain SFX was not active
- New strikes were easy to miss with the age-only detector

**Fix**
- Rain bed stop no longer kills thunder one-shots
- Each new lightning strike sets `Lightning.justStruck`; Audio plays clap/roll (or Zapdos) once
- Thunder respects lightning OFF setting; falls back across clap → roll if load fails
- Strike weather detection uses weather id + strike channel (not rain-bed gate)

---

# Weather FX 4.28.63

## Lightning: true map anchor + far from player

**Camera lock fix**
- Bolts use the same anchoring model as ground splashes
- Stored at birth with camera position; redrawn as `birthPos + (birthCam - currentCam) * scale`
- Stays on the struck map position while you walk (does not slide with the camera)

**Distance**
- Strikes only spawn on the **outer ring** of the view (edges/corners)
- Never in the centre around the player
- Minimum ~**8 tiles** / ~45% of view size from centre

---

# Weather FX 4.28.62

## Lightning distance from player

- Strikes no longer land next to the player
- Minimum distance ~**5+ tiles** from camera/player centre (scales with view size)
- Prefers mid-range to edge of the rendered map; falls back to screen-edge tiles

---

# Weather FX 4.28.61

## World-space lightning

Lightning bolts no longer sit on the camera/screen.

- Each strike picks a **random tile** on the rendered map
- Bolt falls from the **sky** down to that tile (jagged + optional fork)
- Stored in **world pixels**; redrawn with the live camera so it stays on the tile as you walk
- Brief **impact glow** on the struck tile
- Full-screen flash envelope unchanged (SOFT / OFF still work)

---

# Weather FX 4.28.60 — BASELINE

**This is the current baseline.** All future work starts from this build.

Includes:
- 4.28.47 snow-double foundation
- Continuous rain SFX (60s multi-layer beds; plays only when rain is on screen; stops on weather change)
- Strict rain-family audio (no DUSTSTORM false match)
- Unresolved move scrub on weather variants (level1Moves / learnset / movesFull)
- Full pipeline audit pass

---

# Weather FX 4.28.60

## Full audit harden

- Extended unresolved-move scrub to **learnset** and **movesFull** (not only level1Moves)
- movesFull entries that the host cannot resolve are dropped
- Continues 4.28.59 fix for Mod Manager: `WX_*_*.level1Moves[n]: unresolved reference`

### Audit summary (4.28.60)
- Core V.require: all resolve
- Host-only modules (DayNight/Sky/ShadowMap/Voxel3D): optional via pcall/W.require
- 300 weather variants: unique ids, no duplicate n
- 29 weather types: no duplicate ids
- All audio assets present
- Rain SFX: continuous beds + rain-on-screen + strict stop

---

# Weather FX 4.28.59

## Fix: unresolved reference on weather-variant moves

**Error (Mod Manager):**
`pokemon.WX_250_VOLTORB_RAINORB.level1Moves[3]: unresolved reference to ...`

**Cause:** Variant learnset / level1Moves copied base move ids without checking
the host move registry. Invalid or ROM-specific ids crashed registration.

**Fix:**
- Every `level1Moves` / `learnset` entry is filtered through `moveExists`
- Unresolved moves are dropped instead of registered
- Sanitize runs even when variant types are unchanged
- Final scrub after adaptLearnset on every variant

---

# Weather FX 4.28.58

## Baseline: 4.28.47 + continuous rain SFX

Reverted to **4.28.47-snow-double** as the working base.

### Continuous rain sound
- 60s multi-layer rain/storm beds (no short-loop pause feel)
- 4s equal-power crossfade at the rare wrap point

### When it plays / stops
- Plays only when weather is **rain-family** AND **rain channel > 0.02** (rain on screen / falling)
- **Stops immediately** when weather changes away from rain (snow, clear, sand, etc.)
- Strict rain-family (does not treat DUSTSTORM as rain)

---

# Weather FX 4.28.47

## Snow particle count

- **2× snow particles** for snow / blizzard (and snow-channel weather)
- 2D quality snow budgets doubled (high 1600→3200, etc.)
- 3D `SNOW_MAX` 1100 → **2200**

---

# Weather FX 4.28.46

## Gale — no splash

- GALE weather no longer plays **splash** animations
- Ground small-puddle flecks disabled for gale
- Debris/leaves and rain streaks for gale are unchanged

---

# BASELINE — Weather FX 4.28.45

**Official baseline.** All future work starts here.

Includes (since 4.28.29):
- Gradual weather start + outdoor map continuity
- Snow/ash/sand/dust/rain/gale depth layers + path ends
- Top-down fog reduced 50%
- Seamless continuous rain SFX loop
- Anime Realism battle compat + LuaJIT fixes

---

# Weather FX 4.28.45

## Continuous rain SFX loop

- Rain beds use **static** sources with **unique instances** (no shared Source between slots)
- `setLooping(true)` enforced every frame
- If a bed stops, it **restarts immediately** from 0 (no gap / pause between loops)
- Fixes pause before rain starts again

---

# Weather FX 4.28.44

## Top-down / overhead fog

- **2D fog reduced ~50%** when not in first-person (top-down / overhead)
- Ground fog and veil for overhead also halved
- First-person fog unchanged

---

# Weather FX 4.28.43

## Rain + gale depth layers

- **Rain:** 20 depth layers (2D + 3D; was 6)
- **Gale / debris leaves:** 20 depth layers (2D + 3D)
- Near → far size/opacity scaled gently so far layers stay visible

---

# Weather FX 4.28.42

## Sand / dust depth layers

- Sand and dust use **20** depth layers (2D + 3D)
- Near → far: size, speed, height, and opacity scale gently
- 3D spawns in spread rings around the player for FPV volume

---

# Weather FX 4.28.41

## Gradual weather start + map continuity

- Weather no longer **snaps** to full intensity on load / first outdoor moment
- Channels ease in over several seconds (`gentleIntro`)
- Leaving buildings/caves fades weather back in (no jump)
- Outdoor **map changes** keep the same weather running — no particle/pool reset
- Pinned weather changes ease in instead of hard settle

---

# Weather FX 4.28.40

## Hail fall path by depth layer

- Layer 1 (nearest): falls past the **bottom of the screen** and exits
- Layers 2–9: end progressively higher
- Layer 10 (farthest): stops at **50%** screen height
- Optional small splash when a hailstone reaches its endY

---

# Weather FX 4.28.39

## Hail size

- Hail particle size **+10%**

---

# Weather FX 4.28.38

## Hail depth layers

- Hail uses **10** depth layers (near → far)
- Size, speed, and opacity scale gently by layer

---

# Weather FX 4.28.37

## Hail size

- Hail particle size reduced **50%**

---

# Weather FX 4.28.36

## Ash fall path by depth layer (same as snow)

- Layer 1 (nearest): falls past the **bottom of the screen** and exits
- Layers 2–19: end progressively higher
- Layer 20 (farthest): stops at **50%** screen height
- Applies to ash and black ash
- Starts near the top so near layers travel full height

---

# Weather FX 4.28.35

## Snow fall path by depth layer

- Layer 1 (nearest): falls past the **bottom of the screen** and exits
- Layers 2–19: end progressively higher
- Layer 20 (farthest): stops at **50%** screen height
- pathH is now the end screen-Y (not travel distance from spawn)
- Flakes start near the top so near layers travel the full height

---

# Weather FX 4.28.34

## Snow + ash size

- Snow and ash (including black ash) particle size **+40%** (2D and 3D)
- Depth scaling unchanged (far layers still readable)

---

# Weather FX 4.28.33

## Gentler snow/ash depth sizing

- Far layers were vanishing past ~layer 5 (size/alpha falloff too steep)
- Size now scales roughly **near 100% → far ~50–55%** (linear, no near² crush)
- Alpha also softened so distant flakes/ash stay visible
- All 20 depth layers should read in FPV

---

# Weather FX 4.28.32

## Snow — 20 depth layers + realistic fall

- **20** depth layers (2D + 3D), spread near → far
- Soft, uneven fall speeds and multi-frequency sway
- Near: larger, faster, more opaque, more drift
- Far: tiny, slow, faint, high in the sky volume
- Path length still full-screen near / ~50% far
- Built for first-person depth (walk through the snowfall)

---

# Weather FX 4.28.31

## Ash / black ash — 20 depth layers (FPV)

- **20** discrete depth layers for ash and black ash (2D + 3D)
- Layers spread in radius, height, size, speed, and opacity
- Near: larger, faster, more opaque, around the player
- Far: tiny, slow, faint, high in the volume
- Built for first-person depth read (walk through the ash)

---

# Weather FX 4.28.30

## Rain + ash depth layers

- **Rain:** 6 spread depth layers (2D + 3D) — near long/fast/opaque, far short/slow/faint
- **Ash / black ash:** 6 spread depth layers (2D + 3D), positions and sizes spaced near→far

---

# BASELINE — Weather FX 4.28.29

**Official baseline.** All future work starts here.

Includes:
- Clouds: 4.28.10 particle-path banks
- Banners: yield to other UI mods
- Snow: 6 depth layers, half size, path length + panorama
- Ash / black ash: half count and size
- Anime Realism battle compat (chain-safe, under UI)
- Lua 5.1/LuaJIT syntax fixes (Battle/Compat)

---

# Weather FX 4.28.29

## Ash / black ash

- **50% fewer** ash and black ash particles (2D + 3D)
- **50% smaller** ash / black ash particle size
- Black ash uses the same ash motion/size path in 3D (not debris)

---

# Weather FX 4.28.28

## Snow size + 6 depth layers

- Snow particle size reduced **~50%** at all distances (near and far)
- **6 depth layers** (was 3) for smoother near→far snowfall
- Draw-time snow scale also halved so near flakes are not oversized

---

# Weather FX 4.28.27

## Syntax fixes (Battle.lua / main.lua / Compat.lua)

- **Battle.lua:** nested `battle.overlay` wrapper used `...` inside an inner function — illegal in Lua 5.1/LuaJIT (Love2D). Varargs are captured into a table first.
- **Compat.lua:** added `local V = ...` / `local mod = V.mod` like every other lib module (bare `mod` was invalid).
- **main.lua:** safer Compat export / refresh guards.

---

# Weather FX 4.28.26

## Anime Realism compatibility

- Detect `anime_realism` and apply a battle profile (no edits to that mod)
- Weather particles draw **under** AR UI
- Thinner battle weather particles
- Short single weather announce via `sayNext` only
- Skip BattleState.draw field-art rectangle hijack when AR is present
- Chain-safe BattleState.draw wrap with uninstall

See `tools/COMPAT_ANIME_REALISM_4.28.26.md`.

---

# Weather FX 4.28.25

## Snow fall path + panorama (from 4.28.24)

- **Near flakes** fall the **full screen** path
- **Far flakes** only fall about **50%** of the screen
- Mid depths scale between 50–100%
- **Panoramic wrap**: snow slides around the player / view instead of vanishing at the edges (2D wrap + 3D ring wrap)

---

# Weather FX 4.28.24

## Snow depth (from baseline 4.28.23)

- Wider snow volume (400 unit radius) with **near / mid / far** spawn layers
- Tall vertical column (near eye → high cloud deck)
- Far flakes: smaller, fainter, slower, longer life
- Near flakes: larger, brighter, faster fall
- Stronger draw-time depth scaling for snow
- More active snow particles
- Matching depth layers on 2D particle snow path

---

# BASELINE — Weather FX 4.28.23

**This is the current official baseline.** All future work starts from this build.

## Locked in
- Clouds: exact 4.28.10 `CinematicAtmos` (particle-path cloud banks)
- Banners: Weather FX route/season banners disabled when other UI mods are active
- Seasons: `Seasons.update` from 4.28.13 (seasons still advance)
- `placeBanner` default: off

Do not regress clouds away from the 4.28.10 particle path without a new baseline.

---

# Weather FX 4.28.23

## Base: 4.28.13 seasons-fix

### Clouds → 4.28.10 behavior
- Restored **exact** `CinematicAtmos.lua` from 4.28.10 (where clouds worked)
- Clouds draw only via **buildCloudDescriptors → drawParticles** (no separate broken cloud shader path)

### Banners
- Weather FX route/season banners **off** when other UI mods are active (gen3_battle_ui, kanto_companion, colosseum, Crystal 251, …)
- `placeBanner` defaults to **false**
- Banner not drawn from worldPresent (avoids double composite)

Keeps 4.28.13 `Seasons.update` so seasons still advance.

---

# Weather FX 4.28.13

## Seasons fixed

### Cause
`Seasons.update` was **never called** — only `Seasons.onMap`. Season id stayed at default, change banners never fired, notify timer never ticked. `Seasons.drawNotify` was never drawn.

### Fix
- Call `Seasons.update(dt, mapId)` every weather pipeline tick
- Draw `Seasons.drawNotify()` in `present` / `worldPresent` (above weather)

Also keeps 4.28.11 sprite fix + 4.28.12 area-popup present skip.

---

# Weather FX 4.28.12

## Area / route / town name popups

Other mods' location banners were getting covered or blocked when Weather FX's **present** stage drew full-screen grade/fog/weather on top of the finished frame.

### Fix
- Broader detection of text boxes / area banners in the state stack
- **Skip present compositing** while a text box or UI overlay is open (banners stay visible)
- Keeps 4.28.11 player-sprite reflection fix

Based on **4.28.10** + sprite fix + this.

---

# Weather FX 4.28.11

## Custom player sprites — compatibility fix (from 4.28.10)

Removed `SpriteRenderer` require and disabled sprite puddle reflections that called `p.sprite:resolveImage()` on posed characters.

---

# Weather FX 4.28.10 — BASELINE

**Current starting point for all future Weather FX work.**

Includes: battle text fit (no scroll), sayNext confirm, announce at start, SFX locked to weather id, battle weather persist, prior 4.27–4.28 fixes.

---

# Weather FX 4.28.10

## Battle weather text fits the box (no scroll)

- All weather battle lines are fitted to the standard **2-line × ~18-char** battle text box
- Full message visible at once — no scroll inside the box
- Still uses only `battle:sayNext` so **other UI mods** style the box; WX does not draw its own text box

---

# Weather FX 4.28.9

## Battle weather text uses normal confirm

- Weather messages queue only via `battle:sayNext` — same as chip / other battle text
- **A** (controller) / **Space** (keyboard) advances them like every other battle box
- No `sayNextAuto` / auto-advance path

---

# Weather FX 4.28.8 — BASELINE

**Current starting point for all future Weather FX work.**

Includes: battle weather announce at start, SFX locked to weather id, battle weather persist, prior 4.27–4.28 fixes. Battle chip/buffs/nerfs intact.

---

# Weather FX 4.28.8

## Battle weather text at battle start

- Weather announcement queues **as soon as battle weather is seeded** (same tick as enter)
- Tries front-of-queue APIs (`sayFirst` / `sayNow` / `sayNextAuto` / queue prepend) so the weather box is **first**, not after turn 1
- Announce works when battle FX **or** battle rules are on
- Still only once per weather state (no every-turn spam)

---

# Weather FX 4.28.7 — BASELINE

**Current starting point for all future Weather FX work.**

Includes: path-based SFX, overworld-only audio, SFX locked to weather id, battle weather persist, prior 4.27–4.28 fixes.

---

# Weather FX 4.28.7

## Weather SFX locked to current weather id

- **Beds only for rain/storm family** of the active `State.id` (menu ALWAYS/weather)
- Changing weather **hard-stops** previous rain/storm/wind/thunder oneshots every frame until clean
- Residual rain **channels/particles no longer keep** rain SFX playing
- Thunder only on strike-capable storm weathers (not clear/sunny/fog)
- `nudgeFromVisual` only stops wrong beds — does not restart rain

---

# Weather FX 4.28.6

## Weather SFX stop when weather changes

- Changing weather (menu or transition) **immediately stops** the previous bed
- Clear / non-rain weather stops rain loops right away (no leftover rain SFX)
- Keep-alive only restarts the bed that is still wanted
- Wind stops when gust channel is gone

---

# Weather FX 4.28.5

## Overworld weather persists into battle

- **Seeding** no longer blocked by ruleset-only gate for visuals
- **Crystal**: overworld weather is still seeded for visuals (damage hooks stay separate)
- **Indoors** only skips seed when a real map is indoor (not title/false positives)
- **BattleDraw**: if `battle.field.weather` is empty, falls back to current overworld weather so rain/storm still shows in the fight

---

# Weather FX 4.28.4 — BASELINE

**Current starting point for all future Weather FX work.**

Includes: path-based weather SFX, overworld-only audio (no title screen), menu weather bed switching, top-down ground fog, prior 4.27–4.28 fixes.

---

# Weather FX 4.28.4

## Weather SFX follow menu weather + no title screen audio

- **Title / launcher**: all weather beds and wind stop immediately (no map / not overworld)
- **Overworld only**: SFX start once a live map is present (`Scene.now.mapId` + world/battle)
- **Menu weather change**: bed switches in ~0.4s to the new weather’s sound (or silence for clear/fog)
- Rain nudge only applies to rain/storm family; leaving rain stops rain beds right away

---

# Weather FX 4.28.3

## Weather SFX actually play (tested)

**Root cause:** Gen1Recomp blocks `love.filesystem`. Loading via `ByteData` + `newSource` fails silently. The engine plays SFX with **filesystem paths** (`love.audio.newSource(path, …)`), same as Music.

**Fix:**
1. Resolve paths with `mod.assets:path("assets/sounds/…")` (PhysFS path the host can open)
2. `love.audio.newSource(path, stream|static)` — same as engine Sound/Music
3. ByteData decoder kept only as fallback
4. When rain/lightning is **drawn**, `Audio.nudgeFromVisual` forces the matching bed/thunder
5. Optional `mod.content.sfx:register` for engine volume tables

**Tests run:** all 9 sound files present, ffprobe-decode OK, path resolution OK, play-path simulation OK, Draw nudge wired.

---

# Weather FX 4.28.2

## Rain + lightning SFX still silent — loader rewrite

- **Root cause**: `love.audio.newSource(ByteData)` often fails on Gen1Recomp’s sandboxed Love build; sounds never opened
- New loader tries, in order: **Decoder → Source(Data) → SoundData**
- Stream beds fall back to static; paths include more prefixes
- Rain-family beds keep a **minimum volume** while that weather is active
- Looping rain restarts if the host stops the source
- Thunder uses **cloned** one-shots, higher default gain, safer config read

---

# Weather FX 4.28.1

## Weather SFX fixed

- **Root cause**: audio was hard-muted whenever `Scene.now.visible == "hidden"` — common on voxel/UI setups even while outdoors
- Outdoor weather beds play at reduced gain if visibility is mis-detected
- Sound sources fall back **stream → static** when the host rejects stream ByteData
- More path tries when loading `assets/sounds/*`
- Bed volume uses rain **or** overall weather level (not rain-only)
- Extra beds for primal/psy/dragon/thundersnow
- WEATHER SFX defaults stay audible if the option row is missing

Also from 4.28.0: top-down ground fog (fog-family weather).

---

# Weather FX 4.28.0

## Top-down ground fog (voxel / quality ≤ medium)

- **Ground fog** pools on the lower screen in top-down / diorama (not first person)
- Scales with **FOG INTENSITY**, weather **INTENSITY**, and **QUALITY** (stronger on low/potato)
- Top-down also uses denser full-frame banks (min 2–3 layers)
- LOW/POTATO quality budgets: `fogLayers` raised from 1 → 2
- Soft veil slightly stronger top-down

---

# Weather FX 4.27.9 — BASELINE

**This is the current starting point for all future Weather FX work.**

Included since 4.27.x: Crystal/Gen3 compatibility, unresolved-ref hardening, battle weather once-per-state, FP coexistence registry, aggressive compat suite.

---

# Weather FX 4.27.9

## Kanto First Person (ds_fp_ceiling) coexistence

- Compat registry entry for `ds_fp_ceiling` / Kanto in First Person
- Optional dependency listed
- FP 1.60.1+ auto stand-down of overlapping sky/precip when Weather FX is installed; Weather FX keeps 3D/2D weather ownership on all voxel hosts

---

# Weather FX 4.27.8

## Unresolved reference sweep

- **Learnset move pool** reduced to **Gen 1-safe moves** only (no POWDER_SNOW, MOONBLAST, etc. unless the live registry has them)
- **Abilities**: only assigned if the host ability registry knows them; otherwise `nil` (no unresolved ability ids on pure Gen 1)
- Gen9 abilities still fall back, then are registry-checked
- Host-only modules (`DayNight`, `Voxel3D`, …) loaded via **pcall** so missing modules do not throw
- `WorldPrecip` require path corrected

---

# Weather FX 4.27.7

## Crystal crash + Gen3/Colosseum UI + POWDER_SNOW

- **Crystal 251**: battle.damage / accuracy / turn_order hooks no-op under Crystal (prevents rule collision crashes); visuals still optional; battle→OW handoff skipped under Crystal
- **Gen3 / Colosseum UI**: battle.overlay priority 50, always `pcall(next_)` first, nil-safe battle; paints weather under high-priority UI (9000)
- **POWDER_SNOW**: removed as a writable learnset move unless the live move registry has it; Gen1-safe ice pool prefers ICE_BEAM / BLIZZARD / ICE_PUNCH
- Compat registry: `colosseum_ui_overhaul`

---

# Weather FX 4.27.6

## Battle weather architecture fixes

- Weather **effect text once per weather state** (not every turn); re-says only when weather changes
- Mid-battle weather moves update announcement tracking
- **Battle → overworld**: last battle weather carries out unless player forced weather in options
- **Sun/Moon**: stand down per-body if host already provides sun or moon
- **Fog OFF**: 2D + 3D fog multipliers forced to 0 when FOG INTENSITY is OFF
- **State.setWeather** helper for controlled `State.id` changes
- Crystal 251: rules still stand down (no double damage); visuals remain toggleable
- Gen3: battle overlay still calls `next_` first at priority 100 (behind UI)

---

# Weather FX 4.27.5

## Merge: full 4.27.4 + aggressive compat tooling

- Workspace updated to **all 4.27.4 features** (Wilds of Kanto sprite remap, Gen9 ability gating, variant learnsets/cries, WeatherCompanionBridge, WeatherEncounterAPI, Gen9 variant data).
- Restored **tools/compat_aggressive.py** and **tools/known_mods_registry.json**.
- Compat suite remains part of revision testing.

---

# Weather FX 4.27.4

## Wilds of Kanto (overworld-spawn-mod) + Gen9 ability gating

- **Wilds of Kanto / overworld-spawn-mod compatibility**
  - Weather variants always set `baseSpecies`, `spriteSpecies`, `overworldSpecies`, and `followerSpecies` to the original species.
  - On `game.ready`, wraps Wilds sprite resolution so any `WX_*` species is remapped to its base before HGSS / follower / water sprite lookup:
    - `spriteProviders:resolve` / `resolveWater`
    - `follower.spriteService:resolveFollowerSprite`
    - `exports.resolveFollowerSprite`
    - control engine resolve when present
  - Party followers and overworld forms of weather variants therefore show the **original species sprite**, not the missing-sprite fallback.
- **Gen9 ability gating**
  - Gen 9-only abilities (`BEADS_OF_RUIN`, `WIND_RIDER`, etc.) are only assigned when Gen9Dex / `g9-battle-engine` is installed.
  - Without Gen9, alternatives are used (e.g. Beads of Ruin → Pressure, Wind Rider → Speed Boost).
  - Explicit data-row abilities are also sanitized through the same gate.

---

# Weather FX 4.27.3

## Variant learnsets match new typings

- Weather variants no longer keep a pure copy of the base species learnset when their types change.
- **Learnset adaptation** on registration:
  - Offensive moves of a **dropped** type are swapped for thematic moves of an **added** type (tiered early/mid/late).
  - Each newly gained type is guaranteed at least one STAB option on the level-up curve (and in `level1Moves` when possible).
  - `learnset`, `level1Moves`, and optional `movesFull` (national_dex) are all rewritten.
  - Only move ids that exist in the engine's move registry (or a known static core set) are written — missing modern moves are skipped safely.
- Examples:
  - Bloom Bulbasaur (Grass/Fairy): Poison moves → Fairy STAB (Fairy Wind / Disarming Voice / Play Rough / Moonblast…)
  - Cinder Charmander (Fire/Ghost): gains Ghost coverage (Shadow Claw / Hex / Shadow Ball…)
  - Tidal Squirtle (Water/Ice): gains Ice coverage (Ice Shard / Ice Beam / Blizzard…)
- Status, Normal, and shared-type moves are kept. Base cry/sprites unchanged.

---

# Weather FX 4.27.2

## Weather variant cries from original species

- Every weather variant now **explicitly reuses the base species cry**.
- After cloning, cry-related fields are pinned from the base:
  - `cry`, `cryId`, `cryPath`, `cryIndex`, `sound`, `soundId`
  - `crySpecies` / `cryId` forced to the base species id so audio lookups that key off registered id still resolve the original cry
- Sprite paths (`spriteFront`, `spriteBack`, `sprite`, `pic`, `icon`) are likewise kept from the base unless a variant-specific asset exists.
- Prevents silence / missing-cry stubs when the engine looks up audio by the new `WX_…` species id.

---

# Weather FX 4.27.1

## national_dex (gen1recomp-national-dex) compatibility + Pokédex safety

- **Full support for [sanjinpepic/gen1recomp-national-dex](https://github.com/sanjinpepic/gen1recomp-national-dex).**
- When `national_dex` is installed, every weather variant is registered as an **alternate form** of its base species:
  - `baseSpecies` = base id (e.g. `"MEW"`)
  - `form` = `"WX_PRIMALWEATHER"` (etc.)
  - Synthetic `dex` number in the 30000+ range (above national 1025 and national_dex's own form range)
  - `baseDex` keeps the real national number for display
- Result: weather variants **never appear as extra rows** in the 1–1025 Pokédex list. They show up only when browsing forms of the base species (LEFT/RIGHT on the dex page), exactly like megas / regional forms.
- Without national_dex the previous behaviour is preserved (shared base dex number, no new 1–151 slots invented).
- Gen 9 weather variants also load when national_dex is present (even without Gen9Dex), so the modern roster gets weather forms.
- WeatherVariantDex now prefers `baseDex` when writing gen2 entries so "No. XXX" never shows a synthetic 30000+ number.
- `national_dex` added to optional_dependencies.

---

# Weather FX 4.27.0

## Weather variant abilities + Gen9Dex compatibility

- **Expanded, type-aware ability assignment for every weather variant.**
  - Explicit `ability` field on a data row always wins (example: Primalweather Mew → `BEADS_OF_RUIN`).
  - Otherwise a rich thematic table selects the best ability from weather + typing:
    - Signature variants (Primalweather / Void / Inferno / Maelstrom …)
    - Rain → Drizzle / Swift Swim / Hydration / Motor Drive
    - Sun / Heatwave → Drought / Chlorophyll / Solar Power / Flash Fire
    - Sand / Dust → Sand Stream / Sand Force / Sand Veil
    - Snow / Hail / Blizzard → Snow Warning / Ice Body / Snow Cloak
    - Thunderstorm → Static / Lightning Rod / Motor Drive
    - Fog / Mist / Haunted → Pressure / Magic Bounce / Forecast
    - Ashfall → Flash Fire / White Smoke
    - Wind / Gale → Wind Rider / Gale Wings / Compound Eyes
    - Smog / Acid → Poison Point / Stench
    - Type fallbacks when weather is ambiguous
  - Unknown ability ids are inert but safe; base species ability remains the ultimate fallback.
- **Primalweather Mew** (`WX_300_MEW_PRIMALWEATHER`) is explicitly given **Beads of Ruin**.
- **Gen9Dex / g9-battle-engine compatibility (first real batch)**
  - Detection via `mod.find("g9-battle-engine")` (and common aliases).
  - When present, loads `lib/Gen9WeatherVariantsData.lua`.
  - **240 weather variants** (2 per species) for a curated Gen 9 roster of 120 species (starters, popular lines, Paradox, Treasures of Ruin, legendaries, Teal Mask / Indigo Disk additions).
  - Independent of the Kanto-Reforged path so players can choose either content pack.
  - Generator: `tools/generate_gen9_weather_variants.py` (easy to expand the SPECIES list later).
  - Docs: `docs/GEN9_WEATHER_VARIANTS.md`.
- Ability assignment happens only at species registration; already-caught variants keep their stored data.

## Notes
- Gen 9 exclusive abilities (Beads of Ruin, Wind Rider, etc.) require Gen9Dex (or another ability provider) to be fully functional in battle. Without it the ability id is still written but the engine treats unknown abilities as inert.
- The existing 300 core + 470 Kanto-Reforged variants all receive the new thematic ability logic automatically.

---

# Weather FX 4.26.0

## Weather Pokémon + Kanto Companion Mobile integration

- **Added native Weather Encounter API** to Weather FX for read-only companion overlays.
- **Kanto Companion Mobile compatibility** now has a provider bridge that registers Weather FX encounter data when the companion exposes a provider registration point.
- Expanded the existing `encounterOverlay` export so route panels can receive **weather variants**, not just type-biased encounters.
- Weather variant entries now report:
  - species and display name
  - base species
  - variant/form name
  - current required weather
  - grass vs Surf availability
  - encounter probability
  - level range
  - catch rate
  - type(s)
  - base stats / base EXP / growth rate
  - learnset and evolution data
  - Pokédex metadata and sprites
- Weather variant encounter probabilities are calculated from the **actual route encounter slot distribution × the configured variant chance**, so the companion forecast reflects the same source data as the real encounter system.
- Weather variants are only listed when their required weather is active.
- Weather variants are only listed for a route when their **base species is actually present in that route's grass or Surf encounter table**.
- Both the 300 core Weather FX variants and the 470 Kanto-Reforged variants are exposed through the same API when their source species are registered.
- Weather variant species are now explicitly registered during Weather FX startup, fixing a gap where the database existed but wild substitution could remain dormant.
- Variant registration is now idempotent, preventing duplicate-registration errors during reloads / late game-ready passes.
- Existing caught weather variants remain valid when `WX POKEMON` is switched off; the setting only prevents new wild substitutions.
- Added public exports:
  - `weatherEncounters(mapId)`
  - `weatherPokemon(species)`
  - `weatherEncounterAPI`
  - `weatherCompanion()`

## Compatibility

- Designed around the current **BATTLE ART VOXEL FORK / Dramatic Shape Voxel Mod 1.9.3** release API and Weather FX's fail-closed 3D atmosphere bridge.
- No files from Kanto Companion Mobile or Dramatic Shape are modified on disk.
- The integration is read-only from the companion's perspective, keeping Weather FX as the single source of truth.

## Validation

- 124 existing Weather FX tests passed.
- Added Weather Companion API regression suite.
- **0 failures** in the full static/revision test gates.

---

# 4.25.15

- Added first-class compatibility with the current **Dramatic Shape Voxel Mod 1.9.x** (`DRAMATIC_SHAPE`).
- Reused the existing multi-host 3D atmosphere bridge through Dramatic Shape's published `exports.lib` interface, with no edits to the host mod.
- Weather FX now drives Dramatic Shape's 3D rain, fog, clouds, lighting, puddles and atmospheric effects while retaining 2D fallback and the WX PRESENT 2D/3D override.
- Kept Dramatic Shape, Dramaless Shape, Potato Voxel and Stadium 2 behind the same fail-closed bridge.
- Fixed the release archive path layout so mod files use normal `/` paths instead of Windows `\` separators.

## 4.25.14

**Gen1Recomp stack-overflow import fix**

- Broke the `Battle → BattleDraw → WeatherState → Legendary → Battle` module-load cycle.
- `Legendary` now resolves `Battle` lazily only when Gen 2 capability detection is actually needed.
- `WeatherState` now resolves `Legendary` lazily when weather state begins ticking.
- `TimeOfDay` now resolves `BuildingLight` lazily instead of loading it during module initialization.
- These changes keep the runtime behavior intact while preventing recursive module initialization in Gen1Recomp's mod loader.

## BASELINE 4.25.13

Marked as the working base going forward.

## 4.25.13

**GALE small puddle cycle rewrite**

- Uses real clock expire times (not fragile dt stacking)
- Each of 100 puddles lives 2s then hard-moves to a new map position
- Staggered born/expire so they never all blink together
- Guaranteed position change on respawn

## 4.25.12

**GALE small puddles: 100 at once, 2s life**

- **100** small puddles on screen at the same time
- Each lasts **2 seconds** then respawns elsewhere
- Ages stay staggered so they don’t all blink together

## 4.25.11

**GALE small puddles actually cycle**

- Fixed respawn: each small puddle relocates after 1s to a different spot
- Tick runs from draw as well as update so cycle cannot stall
- Disabled static 3D GALE puddles (they never moved); cycling is 2D

## 4.25.10

**Puddle size pass**

- Normal puddles **+50%** larger
- Small (GALE) puddles enlarged so they actually read on screen (~28% of baseline, with min pixel floor)
- Reseed so old tiny positions/sizes are discarded

## 4.25.9

**Small puddles cycle every 1 second**

- Each small puddle lasts **1 second**, then disappears
- A new one spawns at a different map position
- Staggered ages so the field keeps moving during GALE

## 4.25.8

Cancelled — reverted to 4.25.7 small-puddle settings (10% size).

## 4.25.7

**Small puddles for GALE**

- Cloned puddle animation as **small puddle** (10% size)
- Many small puddles scatter across the map during **GALE** weather
- Normal puddles unchanged (rain-family whitelist)

## 4.25.6

**Spread-out puddles**

- 2D puddles use min spacing so none sit beside each other
- 3D map puddles are sparser and at least ~2 cells apart
- Fixed Draw.lua wetness section corruption

## 4.25.5

**Puddle weather whitelist**

Puddles only for: **RAIN, HEAVY, PRIMAL, STORM, PSY, SLEET, DRAGON**  
(no sand, snow, ash, dust, clear, gale, etc.)

## 4.25.4

**Puddles only during rain**

- 2D and 3D puddles require active rain intensity
- No puddles on sand, snow, ash, dust, clear, or other non-rain weather
- Wetness clears as soon as rain stops

## 4.25.3

**Harsh sun residual: Ground immune**

- Restored sun residual chip (SUN / H.SUN / HEAT)
- **Ground types take no residual chip from HARSH_SUN** (Drought) — Groudon safe

## 4.25.2

**Drought / sun no longer residual-chips**

- SUNNY, HARSH_SUN (Drought), and HEATWAVE no longer deal end-of-turn type chip
- Groudon and other non-Fire Pokémon are no longer damaged by sun weather
- Dry Skin / Solar Power sun damage unchanged

## 4.25.1

**SS Anne / ship weather pause**

- Weather stops on SS Anne (all floors/rooms) like buildings and caves
- Resumes when leaving the ship
- Baseline docs updated

## 4.25.0

**Independent world-space weather particles**

- Every raindrop, snowflake, and grain has its own world XYZ, velocity, lifetime, size, and seed
- Simulation integrates in world space; camera only billboards at draw time
- Streaming volume follows player/focus position — does not rotate with the camera
- Rain: independent trajectories + ground impact flecks
- Snow: independent turbulence, spin, and ground accumulation on landing
- Ash: gray vs black ash chosen per particle
- `WorldPrecip.sample()` exposes particle identities for debug/tests
- 2D particles remain as fallback when no voxel host is active

## BASELINE 4.24.5

Marked as the working base going forward.

## 4.24.5

**Ash + black ash particles**

- Regular ash particles are ash-gray only
- New **black ash** particle kind (same motion as ash)
- ASHFALL weather uses ~50% ash + ~50% black ash

## 4.24.4

**Rainbow disabled**

## 4.24.3

**Particles spawn again**

- 2D snow / sand / ash / debris / hail are **never** suppressed by 3D ownership
- Only 2D rain is skipped when 3D rain is active
- 3D WorldPrecip remains additive on top when the voxel host is running

## 4.24.2

**Sand / dust / fog intensity dials drive 3D particles + fog**

- SAND INTENSITY scales sandstorm WorldPrecip grain count and haze
- DUST INTENSITY scales duststorm the same way
- FOG INTENSITY scales weather.fog dens for all foggy weathers (including sand/dust haze)

## 4.24.1

**Fix: weather particles not rendering**

- 2D was fully suppressed when 3D claimed weather; now only owned channels are zeroed
- Sand/ash/debris/leaves 3D grains forced to spawn + color shader fixed
- Snow still uses 3D path when active; 2D remains as fallback for non-owned channels

## 4.24.0

**3D grains + melting ground snow + quality tiers**

- Sand, dust, ash, leaves/debris use **WorldPrecip** 3D path
- Snow builds a **ground layer** that **melts** when weather is no longer snowy
- QUALITY adds **POTATO**; HIGH/MEDIUM/LOW budgets lowered; `worldPrecip` scale for 3D caps
- 2D precip suppressed when 3D owns those weathers

## 4.23.14

**Depth on all weather particles (not lightning/thunder)**

- Rain, snow, hail, sand, ash, leaves/debris: near large/opaque, far small/faint
- Lightning flashes and thunder SFX unchanged

## 4.23.13

**Snow depth like rain**

- Near flakes: larger, faster, more opaque
- Far flakes: smaller, slower, fainter
- 2D snow and 3D world snow both use depth layering

## 4.23.12

**Ash particles 35% smaller**

## 4.23.11

**Ash: two colors + 3D**

- ~Half ash particles black, half ash-gray
- Random scatter and fall paths
- ASHFALL uses 3D atmosphere/fog (same path as fog weather on voxel hosts)

## 4.23.10

**Sand/dust intensity → visibility**

- SAND INTENSITY and DUST INTENSITY scale haze so **500% ≈ 25% visibility**
- Linear from clear (OFF) to 25% remaining at 500%
- Still haze/blur, not screen darkening

## 4.23.9

**Sand/dust visibility = haze, not darken**

- Sand/dust no longer apply a dark multiply grade to the screen
- Visibility loss comes from fog/veil blur and particle density only
- Intensity dials still scale haze and particles, not screen blacking

## 4.23.8

**Sand/dust fog color & drift**

- Sand fog tint matches sand particles (warm tan)
- Dust fog tint matches dust particles (dusty brown)
- Opacity unchanged (same dens/alpha path)
- Fog drifts **to the right**, same direction as sand/dust animations

## 4.23.7

**Sand/dust use 3D fog (no 2D overlay in FPV)**

- SANDSTORM / DUSTSTORM use the same 3D fog volumes as fog weather
- Mapped to cinematic overcast fog bed
- In first person (and whenever 3D fog is active): **no 2D fog/veil overlay**

## 4.23.6

**First-person always uses 3D weather**

- Detects Dramaless/Potato first-person (1ST) via host `FirstPerson` module
- While in FPV, weather presentation is forced to **3D**
- Overrides WX PRESENT = 2D for that mode only

## 4.23.5

**SAND INTENSITY & DUST INTENSITY**

- New mod-menu dials matching FOG INTENSITY (OFF … 500%)
- Scale sand/dust particles and their visibility haze
- FOG / SAND / DUST intensities all affect distance visibility reduction
- Existing channel caps unchanged (no higher than before)

## 4.23.4

**Sand & dust denser, hazier**

- Sand/dust particles ×2
- +50% fog on SANDSTORM and DUSTSTORM
- Stronger veil/dim so distant visibility drops ~50%

## 4.23.3

**Wet flecks dry in 1 second**

## 4.23.2

**Small random wet flecks across the map**

- Wet spots are **small**
- Appear and dry **randomly** over the whole rain area (not only under one drop)
- Still fade over ~2 seconds

## 4.23.1

**Rain leaves wet marks on the ground**

- Each raindrop impact leaves a wet spot in world space
- Spots dry up over **2 seconds** after the drop hits
- Helps rain feel like real weather on the ground

## 4.23.0

**World-space 3D weather (major)**

- New `WorldPrecip` system: rain & snow as true world-space particles
- Positions, velocities, lifetimes in world XYZ
- Streaming volume follows **player position only** — not camera rotation
- Full 360° volume; turning the camera reveals other parts of the same storm
- Particles keep trajectories when off-screen
- 2D overlay precip still used when 3D bridge is inactive

## Baseline 4.22.17

**Official starting point** (replaces 4.22.7 baseline).

All later revisions build from this tree.

## 4.22.17

**Snow weather is 3D**

- Fixed broken blizzard/gale weather table (syntax)
- `snow` / `blizzard` valid cinematic weather keys
- 3D world-space snow flakes for SNOW / BLIZZARD / HAIL / THUNDERSNOW
- 2D snow suppressed when 3D snow is active

## 4.22.16

**GALE is 3D**

- Dedicated cinematic **gale** atmosphere (scudding clouds, dense air motes, wind)
- Maps WX GALE → 3D gale profile on voxel hosts
- 2D leaves/debris still layer on top

## 4.22.15

**PSYSTORM rain is 3D**

- Maps to cinematic thunderstorm rain (world-space streaks)
- 2D rain particles suppressed while 3D rain draws
- Psychic violet wash and lightning unchanged

## 4.22.14

**PSYSTORM (PSY weather)**

- Rain ×3 (0.5 → 1.5)
- Lightning ×3 (strike 14 → 42)

## 4.22.13

**DRAGONSTORM mixed precip**

- Adds snow and sand animations alongside rain
- 2D particles not suppressed so snow/sand are visible
- Keeps wind, debris, and lightning

## 4.22.12

**Ash looks like ash**

- Ash flakes 4× larger
- Ash-gray color
- Soft layered flake shape (not sand streaks)

## 4.22.11

**THUNDERSNOW = snow + thunder (not rain)**

- Uses snow animations / flakes only (no rain streaks)
- Keeps lightning (`strike`) and stormy atmosphere
- Snow amount tripled again for TSNOW

## 4.22.10

**Snow ×3, hail balls ×2**

- All snow weather channels, particle budgets, and 3D snow intensity tripled
- Hail grain size doubled (larger, rounder balls)

## 4.22.9

**Rainbow is a world asset (not camera-locked).**

- Feet stored as fixed map-pixel coordinates when the bow appears
- Screen projection: `(world - camera) * scale` every frame
- Camera read from Scene + overworld camera fallbacks
- Walking moves the view under the rainbow; the bow stays in the world

## 4.22.8

**Leaves / snow / sand / rainbow**

- Gale leaves: wider size range + near/far depth (speed, size, alpha)
- Snow: 2D flakes draw again (no longer blocked by 3D precip gate)
- Sand: denser mix + higher grain budget + larger grains
- Rainbow: feet fixed in **world/map space** again (not locked to camera)

## Baseline 4.22.7

**Official starting point** (player-confirmed working).

All later revisions build from this tree.

## 4.22.7

**Load fix:** Lua parse error from `(function()...end)()` after `pcall` (statement was chained as a call). Replaced with a `do ... end` block so the mod loads again.

## 4.22.6

**Hardening pass.**

- `lib/Harden.lua` shared safe helpers
- Settings: fallback minimal menu if full schema fails
- State.update / Draw.channels guarded (no nil crashes)
- Pipeline weather tick isolated so one error cannot kill the frame
- Options re-register + empty-menu prevention

## 4.22.5

**Fix missing in-game mod menu options.**

- Hardened `Settings.define` so every schema row is registered cleanly
- ALWAYS choices rebuilt at define time
- Re-registers on game.ready / game.start / save.loaded so the host cannot drop the page

## 4.22.4

**Smoother, overlapping weather transitions.**

- AUTO / CYCLE soft-crossfade into the next weather (no hard sky cut)
- Outgoing weather holds while the next builds — no empty gap
- Longer channel ramps and soft-blend duration
- 3D atmosphere: longer transitions; rain/snow/clouds overlap mid-blend

## 4.22.3

**No weather when loading in a cave or building.**

- Channels stay at zero indoors (including on save load)
- ALWAYS / AUTO / pin only activate on the first **outdoor** moment
- Leaving the building starts the correct sky

## 4.22.2

**Start weather matches settings.**

- **ALWAYS** / force: game starts on that weather (snapped, no blend)
- **AUTO**: random weather chosen at session start
- **Menu pin**: starts on the pinned type
- Always/force pins are hard (not soft-faded in)

## 4.22.1

**No 2D fog overlay on boot / non-fog weather.**

- Screen fog/veil only for FOG, MIST, HAUNTED_MIST, SMOG
- Residual fog channels cleared on settle, restore, and first tick
- Faster clear-out so leftover haze does not linger

## 4.22.0

**More realistic 3D snow.**

- World-space 3D flakes on Dramaless/Potato/Gen2 voxel (soft billboards, flutter, slow fall)
- Snow/blizzard atmosphere presets (not rain streaks)
- 2D fallback/battle snow: slower fall, layered sway, soft cross-shaped flakes
- 3D path used for snowy weather so overlays do not double up

## 4.21.6

**FOG INTENSITY** up to **500%** in **50%** steps (plus OFF / 10% / 25%).

Channel cap raised to 20 so 500% can take full effect.

## 4.21.5

**FOG INTENSITY in the in-game mod options menu.**

- Ensures `mod.options:define` registers the full schema including **FOG INTENSITY**
- Choices: **OFF**, **10%**, 25% … 300%
- Re-registers on boot / game.ready so the row is not dropped

## 4.21.4

**FOG INTENSITY:** added **OFF** and **10%**.

| Setting | Effect |
|---------|--------|
| OFF | No fog/veil (channels zeroed, 2D draw skipped) |
| 10% | Very faint mist (0.06×) |
| 25%…300% | unchanged extreme curve |

## 4.21.3

**Fog hides distance more.**

- 3D: higher extinction density, fog starts closer (long range washes out)
- 2D: stronger far-field layer alpha and weights
- Higher draw opacity / more layers as fog channel rises

## 4.21.2

**Rainbow spans two maps.**

- One foot on the current map, the other ~1 map-width into neighbor space
- Still drawn if the neighbor map is not loaded
- Survives map transitions (clears only indoors / rain / timer)
- Longer hold so you can walk toward the far end

## 4.21.1

**Rainbow spans the sky** — longer, taller, wider.

- Feet placed near opposite map edges (full-width arc)
- Arch height fills most of the screen/sky
- Thicker color bands and smoother curve (more segments)

## 4.21.0

**Pokémon outline constellations** (vivid star silhouettes):

- **Pikachu**, **Charmander**, **Squirtle**, **Bulbasaur**
- Dense outline stars (plus accents / tails)
- Placed ~90° apart so you cannot see all four at once
- Brighter and larger than field stars (easy to spot at night)
- Same celestial sphere + daily vault rotation as other stars

## 4.20.8

**Audit tools:** `tools/audit_full.py`, `tools/audit_compat.py` (wired into `run_all.py`).

No gameplay change — inventory of unfinished work, dual celestial paths, and compatibility markers.

## 4.20.7

**FOG INTENSITY** more extreme + **25%** option.

| Setting | Effective strength |
|---------|-------------------|
| 25% | light mist (0.12×) |
| 50% | 0.35× |
| 100% | 1.0× |
| 150% | 2.25× |
| 200% | 4× |
| 250% | 6.5× |
| **300%** | **10× near-whiteout** — dense enough to get lost in |

Draw path uses higher fog alpha / more layers and a stronger veil at high values.

## 4.20.6

Verified **FOG INTENSITY** scales fog/veil channel targets (50%–300%).
Lookup hardened for string/number keys; fog path applies multiplier before draw.

## 4.20.5

**FOG INTENSITY** steps: **50% → 100% → 150% → 200% → 250% → 300%**.

Fog/veil channel cap raised to 3.0 so the top steps are not clipped.

## 4.20.4

**FOG INTENSITY** — separate mod-menu dial for fog/haze only.

| Choice | Multiplier |
|--------|------------|
| LOW | 0.75 (25% below normal) |
| NORMAL | 1.0 |
| HIGH | 1.35 |
| MAX | 1.75 |

Does not change rain, snow, sand, or other weather intensity.

## 4.20.3

**Celestial polish from research references (game-level only).**

- Soft **horizon fade** for sun/moon/stars
- **Layered radii**: stars > sun > moon (depth order)
- Stars share **daily vault rotation** about world UP with the solar clock
- Docs updated — still no camera-owned sky

## 4.20.2

**Celestial sphere architecture (simulation vs render).**

- New `CelestialSim`: game time → world directions only (no camera).
- Day arc: east → **overhead** → west; moon opposite + light orbital drift.
- Renderer (`NightSky.drawSunMoonWorld`) only places `eye + dir×R` billboards.
- Larger sun disc / radius so noon overhead is obvious when looking up in FPV.
- Docs: `lib/CELESTIAL_ARCHITECTURE.md`

## 4.20.1

**Sun/moon as real 3D sky entities (same renderer as stars).**

- `NightSky.drawSunMoonWorld` draws sun/moon every frame (day and night), not gated by night visibility.
- Path: rise east → **noon straight overhead (+Y)** → set west; moon opposite.
- Large world-space billboards on the celestial sphere; look up in FPV/3rd at noon to see the sun.
- Horizon view at noon: sun is above the frame (out of view) — as in real life.
- Uses the same Voxel3D.vp mesh path that already renders stars.

## 4.20.0

**Sun is true 3D overhead (FPV / 3rd person).**

- Removed screen-locked 2D sun disc from the voxel canvas (it never required looking up).
- Sun/moon only via `CelestialBodies.drawWorld`: `eye + worldDir × radius`.
- Noon = straight up (+Y): look toward the horizon → sun out of view; look up → sun overhead.
- Larger disc, closer celestial radius, depth-always so the sky disc is visible when in view.
- Path still east → overhead → west with game time; origin follows player; orientation is world-only.

## 4.19.9

**Sun elevation / overhead path.**

Clamps were pinning the disc to the mid sky so it never climbed over the player.
- Removed anti-overhead y clamps
- Map elevation fully: horizon → top of sky plate at noon
- 3D disc slightly larger when high (FPV overhead read)

## 4.19.8

**Sun/moon day arc: east → overhead → west** (East–Up plane).

Previous path put noon toward the south, which read as the wrong axis in play.
New path: sunrise east on horizon, noon nearly overhead, sunset west. Moon opposite.
Origin still follows player position; orientation is world-only; time drives the angle.

## 4.19.7

**Celestial sphere LOD** (tied to QUALITY tier / AUTO governor):

| Tier | Stars drawn | Planets | Twinkle | Sun layers | Meteors |
|------|-------------|---------|---------|------------|---------|
| high | every star | 5 | on | 4 | on |
| medium | every 2nd | 3 | on | 3 | on |
| low | every 4th | 1 | off | 2 | off |

Star **positions** stay fixed on the sphere; LOD only skips draw cost. AUTO still demotes tier under load.

## 4.19.6

**Celestial model clarified and enforced:**

- **Origin** = player position (eye) — sphere center follows the player
- **Orientation** = world +Y only — never player/camera rotation
- **Angle** = game time only
- Position = Origin + WorldDirection(time) × Radius
- Sun visible above horizon morning/day; moon evening/night (top half of sky)
- Host still paints our `wxBody` coords; only Weather FX edited

## 4.19.5

**Sun/moon render via host painter + our positions.**

- Host `Sky.paint` receives our `wxBody` (Y-axis orbit coords), not host DayNight body.
- Sun: morning/day, top half of sky; Moon: evening/night, top half of sky.
- Our grainy disc + circle still drawn as backup.
- Only Weather FX files changed.

## 4.19.4

**Force sun/moon visible** — hard disc paint in Sky.paint + voxel canvas overlay.
Removes aggressive edge cull; circle fallback if pixel disc fails; higher day/night alpha floors.

## 4.19.3

**Fix: sun/moon not rendering after host body was blocked.**

- projectOne falls back to world theta/el → sky-plate placement when camera projection fails.
- Near-horizon alpha boosted so the disc stays visible.
- Emergency disc path in main Sky.paint if projectBody returns nil.
- Host body remains blocked (wrong axis); our disc is the only renderer.

## 4.19.2

**Root cause: host Sky.paint still received host `body` (wrong-axis sun).**

- DramalessAtmos Sky.paint wrap now forces `body = nil` into the host painter.
- Celestial direction built from explicit world vectors: East=(1,0,0), Up=(0,1,0), South=(0,0,1); rotation around Up only.
- `Celestial.debugSnapshot` for numerical pipeline proof.
- Host body must never drive the disc; only CelestialBodies does.

## 4.19.1

**Fix: sun was still driven by host DayNight on the wrong axis.**

Root cause: CinematicAtmos used `DayNight.bodyAt` → `bodyDir` for lighting/discs,
and DramalessAtmos used `DayNight.shearAt` for light shafts — host orbit, not our Y-axis.

- bodyDir / shear now from CelestialBodies (world +Y orbit).
- Screen projection uses world basis (+Z look, +Y up); no theta→screen-X slide.
- Host DayNight only as fallback if CelestialBodies missing.
- Axis tests prove fixed-elevation path keeps Y constant (orbit around Y).

## 4.19.0

**World-space Sun & Moon (full celestial rewrite).**

- Single clock: `TOD.hour` → continuous 24h orbit around world **+Y**.
- Sun and Moon **both** always exist; Moon is exactly **180°** opposite Sun.
- Positions from celestial direction only — not camera/player.
- Rise east (6) → noon south high (12) → set west (18) → below horizon at night.
- `tools/test_celestial.py` math suite (continuity, separation, anchors).
- No other mods modified.

## 4.18.9

**Force sun/moon onto Y-axis orbit (Weather FX only).**
Sky.paint no longer uses host body.x/y for the disc. Position comes from CelestialBodies (orbit around world +Y), with a screen fallback that maps theta→horizontal and elevation→height.

## 4.18.8

**Sun/moon orbit around world +Y (vertical).**
Day path: east → south → west as a half-turn around the Y axis, with elevation above the horizon. Fixes wrong-orientation solar motion.

## 4.18.7

**Tools & tests rebuilt as revision gate (from 4.18.6 baseline).**

- `tools/revision_gate.py` — bugs, labels, battle toggles, night sky, indoor, clear fog, gen3/Crystal/Dramaless, fluidity.
- `tools/run_all.py` — runs gate + edit_guard + night_sky + test_mod first; must all pass.
- `test_mod.py` aligned with current DEBUG HUD (Settings helpers).
- Workflow: every new revision → `python3 tools/revision_gate.py` then `python3 tools/run_all.py` before zip.

## 4.18.6

**Mod menu labels (all caps):** RARE WEATHER, WEATHER ROTATION SPEED, BATTLE WEATHER FX, BATTLE WEATHER DMG.

## 4.18.5

**Mod menu label renames:** Rare Weather, Weather Rotation Speed, Battle Weather FX, Battle Weather Dmg.

## 4.18.4

**Planets 2× larger in the night sky** (3D billboard size and 2D fallback).

## 4.18.3

**CRYSTAL_251 battle-rules compatibility.**

- Detect Crystal 251: **BATTLE WX DMG** path forced off (Crystal owns rain/sun/sand rules).
- Do not seed `battle.field.weather` from overworld under Crystal (avoids clashing with Crystal move weather).
- BattleDraw maps Crystal `battle.weather` (rain/sun/sandstorm) to particles when **BATTLE WX FX** is ON.
- Skip WeatherVariants dex bind when Crystal is installed (Crystal owns type chart / 251).

## 4.18.2

**Deep co-op fixes for gen3_battle_ui.**

- BattleField art AUTO stands down when gen3_battle_ui (or colosseum UI) is installed.
- battle.overlay: priority 100, always calls next first, restores canvas/blend/color after draw.
- Whole-frame battle weather skipped when gen3 is present (canvas overlay only) to avoid double rain on Gen 3 HUD.

## 4.18.1

**BATTLE WX FX / BATTLE WX DMG ON-OFF actually enforced.**

- Settings helpers read menu values explicitly (`on`/`off`).
- `Battle.animEnabled` / `effectsEnabled` drive visuals vs damage separately.
- BattleDraw tick/draw no-ops and clears channels when FX is OFF.
- `battle.overlay` wrap registered so canvas battles respect FX OFF.
- Scene battle scale returns 0 when FX is OFF.

## 4.18.0

**Split battle WX options; fix residual clear fog/clouds.**

- Mod menu: **BATTLE WX FX** (on/off visuals) and **BATTLE WX DMG** (on/off damage/modifiers) replace single WX RULES row.
- CLEAR / clear voxel profile: fog & cloud volume forced to 0 (was leaving haze on load).
- Dynamic atmos default starts on clear; faster fog/veil ease-out when target is 0.
- State.settle on CLEAR zeros all channels so load does not linger previous fog.

## 4.17.9

**Hardened compatibility with other UI mods.**

- Gen 2 `ui.options.rows`: call chain first, never mutate returned tables, append only `pipeline:weather`, single wrap, fail-open.
- Settings.define isolated in pcall (own schema only).
- Weather still skips drawing when any full-screen menu covers the world.

## 4.17.8

**Weather pauses in buildings/caves; resumes on exit.**

- Overworld: no weather particles or channels while indoors/caves.
- Battle: no weather seeded if the fight starts indoors/in a cave.
- On leaving: same weather if stay &lt; 5 minutes; may pick a new weather if stay ≥ 5 minutes.
- Weather only turns back on when leaving a building or cave (not when entering battle indoors).

## 4.17.7

**TIME removed from in-game OPTIONS ladder; kept in mod Settings.**

- Unregistered the daynight render pipeline (OFF/AUTO/MORN/DAY/EVE/NITE row).
- Clock / NightSky / building light still tick from the WEATHER pipeline.
- Mod menu **TIME OF DAY** (ON/OFF) remains under Settings.

## 4.17.6

**Auto TIME OFF when Dramaless is detected.**

- On DRAMALESS_SHAPE host detect, Weather FX sets its own TIME OF DAY to OFF.
- Host keeps its clock; we do not edit Dramaless.
- TIME pipeline level forced to OFF; no WX day/night grade while host owns time.

## 4.17.5

**Stars detect Dramaless night and draw outdoors.**

- `NightSky.isNight` reads host DayNight.isNight / mix / moon body (Dramaless).
- `computeNightVisibility` returns full stars when host night (unless TIME pinned DAY).
- DramalessAtmos refreshes DayNight every frame and forces `_nightVis = 1` before drawWorld.

## 4.17.4

**Hard night visual override (host was ignoring softer fixes).**

- After host sky paint at NITE: force dark sky plate over the sky region (fixes residual blue).
- God-rays: refresh `_WX_NIGHT` every atmos frame from TIME pin; skip `drawRays` entirely when set.
- Moon: pure white + grey crater spots; dark stamp under disc kills host orange ring.

## 4.17.3

**Night sky/moon/god-ray polish.**

- God-rays hard-off via shared `_WX_NIGHT` flag (TIME pin / hour / isNight).
- Night sky bands near-black (no residual blue).
- Moon redrawn as cool grey grainy pixel disc — no orange rim/glow.

## 4.17.2

**Ported 4.10 weather-variant stack; sky left alone.**

- WeatherVariants / Kanto data / TypingCharts / dex + docs/tools/tests.
- Settings, Config, Battle, Encounters, config.lua from 4.10 (variant hooks).
- Unchanged: NightSky, CelestialBodies, moon/sun disc, NITE dark sky, god-ray night kill.

## 4.17.1

**Night: no god-rays; darker sky.**

- God-rays / light shafts hard-off when DayNight night **or** Weather FX TIME pin/phase is NITE (hour 20–5).
- `drawRays` early-outs when lightIntensity is 0 (no residual shaft mesh).
- Night sky bands darkened (deep navy) so the sky feels like night, not blue day.
- Sun disc/glow suppressed at NITE; CelestialBodies returns moon only under NITE pin.

## 4.17.0

**Base restored to 4.6.7; sun/moon look and time-of-day motion kept.**

- Full mod tree reset to stable weather_fx **4.6.7** (stars, weather, atmos).
- Kept grainy **moon/sun disc** painting (`wxPaintCelestialDisc`) and NITE sky bands.
- Kept **CelestialBodies** clock-driven sun/moon orbit for 3D.
- Disc draws after stars; moon forced when TIME is NITE.

## 4.6.7

**Fix: mod installs but fails to load.**

- Entry chunk no longer aborts if `Settings.define`, battle/encounters install,
  or `mod.commands` is missing/throws.
- Safer ALWAYS weather row build when a catalogue label is absent.
- Load is fail-soft so Weather FX still enables and registers pipelines.

## 4.6.6

**2× star field + distributed building density reduction.**

- Star count **640 → 1280** (full 360° celestial sphere, deterministic).
- Slightly lower base alpha so the denser field is not washed out.
- ~50% of stars marked `hideNearBuilding` with **spatial bins** (no empty hemisphere).
- Near buildings those stars fade with `BuildingLight.factor` (0 near → 1 far).
- Same stars return when leaving; no per-frame reroll; positions unchanged.

## 4.6.5

**Seamless building-proximity star brightness (map data, not geometry).**

- Building locations from warps/doors/events + TileShape metadata (full map).
- Per-map **registry** cached by map id — independent of voxel mesh load.
- Continuous smoothstep falloff (5→20 steps); dt-smoothed factor.
- Missing metadata keeps last distance (no snap when geometry appears).
- Multi-building uses nearest footprint; does not stack past 1.0.
- Still multiplies after day/night visibility (DAY stays starless).

## 4.6.4

**Fix: stars missing when TIME is set to NITE.**

- Always re-sample `computeNightVisibility()` each frame (smoothed value no longer
  stuck after switching from DAY).
- Pin **NITE** forces visibility = 1 immediately.
- Sky.paint wrap uses continuous visibility (not only binary isNight).
- NightSky loader always receives `V`.

## 4.6.3

**Star twinkling.**

- Every star has its own rate, secondary rate, phase, and depth.
- Dual-sine modulation so the field does not pulse as one sheet.
- **Alpha only** — celestial directions and positions unchanged.
- Works with day/night fade and BuildingLight scale.

## 4.6.2

**Star fade tied to DAY / EVE / NITE / MORN.**

- **DAY** → 0% stars  
- **EVE** (17–20) → smooth fade-in 0% → 100%  
- **NITE** → 100% for the whole phase  
- **MORN** (4–10) → smooth fade-out 100% → 0%  
- Uses `TOD.phaseAt` / `TOD.tod` windows (no independent twilight clock).  
- Large time jumps snap visibility; small steps ease. Celestial positions unchanged.

## 4.6.1

**Realistic day/night star fade.**

- Global night visibility 0→1 from TimeOfDay hour + daylight (dusk/dawn shoulders).
- Smoothstep + temporal smoothing (no pop when the clock steps).
- Bright stars emerge first in twilight; faint stars later (magnitude thresholds).
- Alpha only — celestial directions never change; stars are not spawned/destroyed.
- Draw when visibility > ~2% (twilight), not only binary NITE.
- OPTIONS pins: DAY=0, NITE=1, EVE/MORN intermediate.

## 4.6.0

**Celestial sphere star field (architecture rewrite).**

- Stars have **fixed unit directions** D (deterministic catalog, full 360°).
- Render: `position = camera_eye + D * radius` + host **Voxel3D.vp** only.
- Camera **rotation** selects which part of the sphere is visible; translation
  does not parallax the sky (sphere re-centered on the eye).
- Removed screen-delta / manual “move stars opposite” positioning.
- Math fallback projects the **same** D through camera basis (view-space), not
  a locked overlay.
- Drawn **before** clouds so weather occludes stars.
- Dense catalog (~640), planets, twinkle = brightness only, marker star + DEBUG.
- Meteors preserved. Expanded celestial contracts in `test_night_sky.py`.

## 4.5.36

**Stars always visible at night + stronger tests.**

- Restored dense screen star/planet draw (with camera parallax when available).
- 3D world dome still preferred; **screenFallback** if mesh/shader/vp fails so
  night is never empty.
- Expanded `tools/test_night_sky.py`: density (≥400), brightness floor, 360°
  positions, dual render paths, integration, no meteors-only no-op.

## 4.5.35

**True skybox stars (not stuck to the camera).**

- Stars live on a full 360° world-direction dome projected by the view matrix.
- Turning moves stars off-screen and brings in stars that were behind you.
- Removed the screen-UV star pass that was locking the field to the view.
- Dense field (~720 stars) still drawn.

## 4.5.34

**Dense star field again + full 360° sky.**

- Restores a full sky of stars in front of the camera (4.5.33 was over-culled
  to ~1 star).
- Stars still sit all the way around the player; the back half stays hidden
  until you turn into it.
- Locked world positions; turn one way → stars slide the opposite way.
- Soft rim fade only.

## 4.5.33

**360° star field around the player.**

- Stars/planets placed all the way around a circle (and up to the zenith).
- Only the arc in front of the camera is drawn; turn to see the rest.
- Directions match FirstPerson yaw so the field stays fixed in the world.
- Soft rim fade only — no hard mid-sky cutoff when turning.

## 4.5.32

**Invert horizontal star parallax** (left/right only; up/down unchanged).

## 4.5.31

**Stationary stars with correct look parallax.**

- Uses FirstPerson yaw/pitch (1st & 3rd person) so stars stay fixed in the sky.
- Turn left → stars slide right; turn right → left; look up/down → opposite.
- Soft edge fade (no hard pop-off when turning).
- Wider sky coverage so the field stays full while looking around.

## 4.5.30

**Star field tracks look direction (skybox parallax).**

- Stars/planets keep fixed positions in the sky.
- Looking left moves them right on screen (and the same for up/down/all directions).
- Uses the voxel camera basis each frame so the field does not stick to the view.

## 4.5.29

**Flat, static star field on the sky plane.**

- Stars/planets use fixed sky UVs (same places every frame), spread across the
  full sky rectangle like the game sky — not a camera-centered 3D sphere.
- Primary draw is orthographic on the sky plane; optional flat-plane fallback
  if needed. Twinkle only; positions do not drift.

## 4.5.28

**Stars always at night (sky backdrop + 3D dome).**

- Camera gate removed: if it is night, stars/planets render.
- Restored post-sky-paint star field (between sky gradient and clouds).
- 3D dome sits farther out; draw more resilient if beginEffect fails.
- Minimum star brightness floor so they are not invisible near town.
- Pinned OPTIONS NITE counts as night for star/meteor logic.

## 4.5.27

**More natural weather → weather transitions.**

- Expanded `follows` links across the catalogue so common progressions
  (clear↔rain↔storm, mist↔fog, snow↔sleet↔blizzard, wind family, etc.) are
  preferred when AUTO picks the next spell.
- Slightly longer default channel blend (`transitionSeconds` 4.8) and soft
  location handoff duration.
- Stronger `follows` weight so linked sequences win more often without
  locking out other weather.

## 4.5.26

**Fix: pink line on snow weather.**

- Disabled 3D ground snow-pack mesh draw (shared puddle shader path could show a
  pink line artifact on some hosts).
- Restored original puddle shader (no `snowMode` branch).
- Snow still uses 2D flakes + 3D overcast clouds; cover state remains for a later
  safe pack pass.

## 4.5.25

**Night building-distance ramp shortened.**

- Full wild star brightness / darkest night ambient at **20 steps** from nearest
  building (was 50). Near threshold stays **5 steps**.

## 4.5.24

**Night town → wild light + stars (building distance).**

- Fixed broken `main.lua` update (BuildingLight + NightSky now load/run).
- True night only: ambient eases from full near buildings (≤5 steps) to **10%
  darker** at ≥50 steps; independent of render distance (full map building list).
- Stars/meteors: **10%** brightness near buildings → **100%** far; brighter base.
- Smooth walk-away factor so light does not pop per tile.

## 4.5.23

**Stars only at true night; sky is world-fixed; weather no longer snaps on every map.**

- **Stars:** require real night (host moon body, or WX `NITE` / deep darkness). No
  evening / half-cycle false positives while the sun is still up.
- **Stars:** screen-space star overlay removed (it looked like “stars on glasses”).
  Only the world-dome path remains so stars sit in the sky as you look around.
- **Weather:** regional front / AUTO target changes **blend** over ~14s+ (and across
  a couple of map changes) instead of swapping instantly. Channels crossfade so
  snow can mix with fog/ash mid-handoff. Menu pins, force, and legend events still
  snap immediately.

## 4.5.22

**Ground snow clears when weather changes.**

- 3D ground snow cover builds while snowy weather is active (snow, blizzard,
  hail, thundersnow).
- When weather leaves snow (or rain starts), packs **clear quickly** — they do
  not linger across many transitions the way rain puddles do.
- Works on Dramaless, Potato, and Gen2-3D-Sprites via the shared atmos bridge.

## 4.5.21

**Performance: cut 3D night-sky lag (all voxel hosts).**

- Cache `DayNight` / `ShadowMap` / `NightSky` / host camera modules — no
  `require` every frame in the voxel pass.
- Star mesh uses a **vertex pool** (no thousands of new tables per frame).
- World star budget capped (~220) with lighter twinkle; denser field kept for
  the cheap 2D sky fallback.
- Same path for Dramaless, Potato, and Gen2-3D-Sprites.

## 4.5.20

**Policy: all three voxel hosts are first-class.**

- Documented in `AGENTS.md`: every 3D change must work on **Dramaless Shape**,
  **Potato Voxel**, and **Gen2-3D-Sprites** (`STADIUM2_OVERWORLD_MODELS`).
- Shared bridge only; host differences stay as small branches.
- README / tools hints updated to match.

## 4.5.19

**Gen2-3D-Sprites 3D path hardened (still no disk edits to host mods).**

- `Sky.paint` wrap forwards extra Gen2 args (`top`, `axis`, `ray`) so their sky
  disc/rays keep working.
- Camera angle for star visibility resolves `Voxel` **or** Gen2 `VoxelState`.
- Shared `attachNightSkyHost` for world + screen star paths.
- Dramaless/Potato behavior unchanged.

## 4.5.18

**3D atmosphere host: Gen2-3D-Sprites (Gold/Silver).**

- `STADIUM2_OVERWORLD_MODELS` added to the voxel host list (same `exports.lib`
  + Voxel3D/DayNight/FirstPerson convention as Dramaless).
- Optional dependency listed in the manifest.
- Interop treats it as a voxel / wide-battle companion for day-night and overlay layout.
- Dramaless Shape and Potato Voxel paths unchanged — host selection is by mod id only.

## 4.5.17

**Rainbow after rain (map-locked ends).**

- After a rain spell fully ends (light, heavy, storm, or **primal**), a rainbow
  fades in gently over ~10s, holds, then fades out.
- Light rain upgrading to primal/heavy does **not** show a rainbow mid-spell;
  the bow waits until the whole wet period is over.
- Both feet are fixed in **map pixel space** (deterministic per map), so the
  arc does not drift with the camera — walk the map to find either end.
- Clears if rain returns, or you leave the map / go indoors.

## 4.5.16

**Shooting stars (night only) — no stacking.**

- One shooting star every **1 in-game minute** at night (random direction).
- Every **90 in-game minutes** at night: a **shower** (same heading, staggered)
  **instead of** the single for that beat.
- Daytime timer rollover defers until **1 in-game minute after nightfall**.
- **Never stacks:** only one single *or* one shower may be active; timers wait
  until the current event fully finishes.

## 4.5.15

**Stars/planets only when looking at the sky (not top-down).**

- New `NightSky.skyVisible`: requires host first-person blend (`cardBlend > 0.35`)
  or a tilted `Voxel.angle` (not straight-down orbit).
- Top-down / high map view skips both the world dome and the screen star field
  so they never cover the playfield.
- Default without camera signals is **off** (safe for top-down).

## 4.5.14

**Night stars — verified gates + working fallback.**

- Stronger `NightSky.isNight`: Weather FX NITE **or** host DayNight moon /
  second-half cycle (real in-world night even if WX TIME is OFF).
- `Sky.paint` path loads NightSky **with** `V` and re-enabled 2D star field
  (was a no-op after the world-dome change).
- World dome still draws first in the voxel pass; additive planets/stars.
- `tools/test_night_sky.py` contract suite (all passing).

## 4.5.13

**Night stars and planets actually show.**

- `NightSky` now receives the mod loader (`local V = ...`) so `isNight` can read
  Weather FX TimeOfDay — previously `V` was nil and stars never enabled.
- Night detection also uses host `DayNight` (moon / post-day cycle).
- Star dome is drawn **before** clouds/rain/fog so it sits against the sky.
- Shader VP send uses row-major matrices (Dramaless convention).

## 4.5.12

**No sun at night.**

- AUTO / CYCLE never pick SUNNY, HEATWAVE, or other `sunny` weather at night
  (real night or TIME → NITE).
- A sunny spell already running ends when night falls.
- 3D solar god-rays intensity goes to 0 at night (moon is not a sun shaft).

## 4.5.11

**Weather encounter rate boost + Gen 2 legendaries.**

- Active non-CLEAR weather: ~**50% more** wild encounters (`encounters.rateBoost = 1.5`).
- Legendary claims only **+5%** relative (`legendary.rateBoost = 1.05`).
- Gen 2 legends rouse with typed weather: Raikou/Storm, Entei/Ash, Suicune/Heavy Rain,
  Lugia/Psystorm, Ho-Oh/Harsh Sun, Celebi/Verdant Rain (Gen 1 games keep birds only).

## 4.5.10

**Rain also bans Steel wilds.** Wet weather excludes FIRE and STEEL.

## 4.5.9

**Gen 2 types on weather encounter bans and soft bias.**

- Soft bias strengths for **DARK** and **STEEL**.
- Ban defaults include Gen 2-aware lists (e.g. ICE in sun, FLYING in snow,
  DARK in psychic weather). **STEEL is not banned in sand** (sand immunity).
- `encounters.bans.psychic` for Psystorm-style fronts.

## 4.5.8

**Hard weather type bans on wild encounters.**

- Rain/wet weather: **Fire types never appear** (reroll or drop the encounter).
- Defaults also ban: Water in sun, Bug/Grass in snow/hail & ash, Water/Bug in
  sand, Fire in fog.
- Configure in `config.lua` → `encounters.bans` / `encounters.bansById`.
- Soft type bias (`strength`) is unchanged and still only leans species.

## 4.5.7

**Darker night outside towns.**

- When it is night (or TIME → NITE), routes and wilderness get a deeper
  colour grade so the sky and world read as proper night.
- **Towns/cities keep milder night lighting** so streets stay readable.
- Indoors unchanged (existing indoor grade scale still applies).

## 4.5.6

**Night sky is a full world-space dome, not a screen overlay.**

- ~480 stars + 5 planets placed on a hemisphere around the camera at
  roughly the current view/render distance.
- Drawn with the voxel depth buffer so terrain can occlude them and the
  field fills the visible sky, not a HUD layer on the player.
- Brighter, denser field; still follows TIME → NITE / real night.

## 4.5.5

**Stars/planets when TIME is set to NITE (or real night).**

- Night sky no longer requires the host to publish `body.moon` that frame.
- Uses Weather FX TIME pin (`NITE`) and `TOD.isNight()` / low daylight.
- Sky.paint wrap also installed from main on `game.ready` so stars work
  even if the 3D atmosphere path is off.

## 4.5.4

**Fog density +50% again.**

- 3D bed denser and closer; higher weather fog multipliers.
- 2D fog pass alpha and layer weights +50% on top of 4.5.3.

## 4.5.3

**Denser fog (harder first-person visibility).**

- 3D extinction bed density ~2×; fog starts closer to the camera; stronger
  height falloff so ground-level / FP view greys out sooner.
- Weather fog multipliers raised on clear through thunderstorm presets.
- 2D fog draw strength ~2× (layer weights + pass alpha).

## 4.5.0

**Night sky, greyer rain, dual 2D+3D for more weathers.**

- **Stars and distant planets** at night (moon body): drawn during host
  `Sky.paint` so they sit in the sky behind the world and under 3D clouds.
- **Rain/overcast sky less blue:** weather sky blend pushed into sky bands
  (greyer closed-deck colours in CinematicAtmos + NightSky band mixer).
- **Fuller dual presentation:** every Weather FX type maps to a 3D cloud/fog
  preset; **2D particles stay** for snow, hail, sand, ash, and wind. Only the
  rain/storm family suppresses 2D rain (3D already draws streaks). Fog-family
  and closed rain still use 3D mist as primary fog.

## 4.4.9

**Smoother 3D clouds and sun-aligned rays (Dramaless/Potato path).**

- **Cloud jump fix:**  is a continuous animation clock again.
  It no longer snaps to  (calendar/TOD), which made the cloud
  lattice advect in discrete leaps and feel laggy.
- Frame-time for atmos update is clamped so a hitch cannot fling clouds forward.
- **Sun rays:** before drawing, shear () is refreshed from
   so god-ray direction matches the sun/moon disc in the sky.

## 4.4.8

- Root orientation file is now **** (replaces ).
  Same assistant guidance; quieter name; sorts above  in the mod root.
- Pointers in README, main.lua, and config.lua updated.

## 4.4.7

**`AGENTS.md`: an orientation file for whichever assistant opens this
next.**

The `tools/` suite is good and was going unused -- an assistant that does not
know it exists reads source instead of running `run_all.py`, and one that does
not know about `runtime_hints.py` guesses at a bug the debug HUD already
names.

More importantly it carries the five ways this codebase has ACTUALLY broken,
every one of which shipped and none of which raised an error:

- engine modules captured at file scope give the Gen 1 implementation forever,
  even on Gold -- three releases lost to this one
- the two generations describe maps and the world differently
- `love` is sandboxed and throws on the INDEX, so the usual guard does not
  guard -- one such call blanks the whole screen
- six registries have no Gen 2 home; writes are dropped and reported
- fixtures encode assumptions, which is why a thousand passing assertions
  never caught the Gold bug

And the rule that follows from all of it: after a fix, break it again on
purpose and confirm the suite fails. Four decorative tests in this repo were
found exactly that way.

Pointed at from `main.lua`, `README.md` and `config.lua`, because different
assistants open different files first and a note nobody sees is not a note.

It also states the limit plainly: none of this tooling can see the screen, and
every visual bug in this mod's history was found by a human playing it.

## 4.4.6

**Licence compliance for the vendored Kanto Dynamic Weather code, and a
sandbox guard that had quietly stopped guarding.**

`lib/voxel_atmos/` and `compat/kanto/` are byte-for-byte copies of four
modules and a compatibility bridge from Kanto Dynamic Weather by Campo
(`1-Camp0-1`). That code is MIT licensed, which permits exactly this reuse --
on one condition: the copyright notice and licence text must travel with the
copy. They were not shipped with it.

Added: `lib/voxel_atmos/LICENSE-kanto-dynamic-weather` (Campo's licence,
unmodified), a `NOTICE.md` beside it naming what was taken and from where, and
a credit in the README. Nothing about the code changed -- this is the
attribution MIT asks for, and it is a five-minute fix now against an
untangling job across a dozen releases later.

**The sandbox guard did not cover the new files.** It works from a hardcoded
list, and `DramalessAtmos`, `VoxelAtmosBridge`, the four vendored modules, the
Kanto bridge, `Seasons` and `VolumetricFog` were never added to it. The
vendored code matters MORE than the rest here, not less: it was written
against an engine that had not yet sandboxed `love`, so it is precisely the
kind of code that used a blocked API legally at the time. All of it is clean
today -- but nothing was checking, and a hardcoded list that new files are not
added to is a guard that has stopped guarding without failing. Mutation-checked
against the vendored files specifically.

Verified while here: both mods load together with zero errors, the bridge
fails closed with a named reason at each step rather than drawing broken
weather, and the whole toolchain is green.

# Changelog

> **Version note.** This release is **3.0.0**. The entries below were
> written against a development numbering that ran to 2.22.0 and does not
> correspond to any published release; they are kept in the order the work
> happened. 3.0.0 is above every number this mod has ever carried, so the
> launcher's updater will offer it to anyone on any earlier build.

## 4.4.5

- Renamed `ai_tools/` back to **`tools/`**. Paths in README and scripts updated.

## 4.4.4


**Better in-game DEBUG HUD.**

- **DEBUG HUD** tiers on the mod page: OFF / SIMPLE / FULL / 3D (ON = FULL).
- SIMPLE: weather, place, present mode, 3D status, and a **why:** line.
- 3D: voxel bridge focus (active, handles precip/fog, status, outdoor).
- FULL: previous dense readout, plus **why:** (ladder-off, indoors, clear-sky,
  present-2d, 3d-precip, 2d-draw, …).
- DEBUG RAIN and `config.debug` still force FULL for testers.

## 4.4.3


**Audit revision — docs, outdoor gate, test tooling.**

- Full static audit: `tools/test_mod.py` + `ai_debug` + `edit_guard` green.
- README documents **WX PRESENT**, Dramaless/Potato 3D path, DEBUG `wx:`/`v3:`,
  and `tools/` (including `test_mod.py`).
- 3D outdoor flag follows Weather FX `Scene.now.outdoor` (indoors skip volumes).
- `potato_voxel` listed in optional dependencies.
- From this revision on, each release ships as a zip with changelog.

## 4.4.2


**Full atmosphere attempt on Dramaless / Potato (Weather FX only).**

- Loads embedded Kanto `CinematicAtmos` (clouds, light shafts, rain, fog, motes,
  puddles) via host `exports.lib`; does not edit other mods.
- Stubs for missing host modules: ForestAtmos, Mat4, TileShape, SpriteBillboards,
  TerrainAtlas.
- In-memory `Voxel3D.beginEffect` / `endEffect` polyfills (Dramaless lacks these).
- Draws inside the voxel depth pass by wrapping `Voxel3D.endScene`.
- **WX PRESENT** mod option: AUTO / 2D / 3D.
  - **2D** = original Weather FX rain and fog overlays anytime.
  - **3D** / **AUTO** = atmosphere path when Dramaless or Potato Voxel is present.
- DEBUG HUD: `wx:` presentation mode, `v3:` bridge status (and draw errors).
- 2D overlays suppressed only when 3D claims the matching layer; battles unchanged.
- **`tools/`** suite for AI/human debugging (replaces older `tools/`):
  `ai_debug.py`, `edit_guard.py`, `mod_map.py`, `symbol_index.py`,
  `require_graph.py`, `runtime_hints.py`, `run_all.py`.

## 4.4.1

- First Dramaless/Potato-oriented 3D hook and WX PRESENT control.

## 4.4.0

- Session integration scaffolding; Weather FX remains weather authority
  (AUTO, fronts, battles, typed residuals, OPTIONS).

## 4.3.0

**The battle now says what the weather is doing to it.**

Chip damage announced itself every turn and a nullified move explained itself
when it failed, but the boosts and dampenings -- the effects that decide most
turns -- were invisible. A player could fight a whole battle in heavy rain
without being told why their Fire moves were doing half damage.

Two lines at most, at the top of the fight:

    It is raining!
    WATER moves grew stronger!
    FIRE moves weakened!

    A heavy rain is falling!
    WATER moves grew stronger!
    FIRE moves cannot be used!

Decisions worth recording, because each rules something out:

- **Game messages, not an overlay.** The battle already has a text queue with
  the right font, timing and pacing. A drawn panel would reinvent all three
  and still read as something bolted on.
- **Derived from the damage tables, never a second list.** Every line is
  generated from `POWER`, `POWER_AMPLIFIED` and `NULLIFIED` -- the same tables
  the damage hook reads. A hand-written list would drift the moment a weather
  is retuned, and the failure mode is the worst kind: the game confidently
  telling the player something no longer true.
- **A nullified type is said outright** ("cannot be used") rather than folded
  into "weakened". It is the strongest thing the sky does.
- **No side labels.** Rain boosts Water for BOTH sides, so "PLAYER: Water up /
  ENEMY: Water up" reads as asymmetry where there is none. Sides would only be
  named for an effect that genuinely differs between them, and Gen 1 weather
  has none.
- **Once per battle**, and silent when battle effects are off -- announcing
  boosts that are not being applied would be worse than saying nothing.

The typed storms use their chipType word rather than `label`: `label` is the
OPTIONS-row abbreviation, so a psystorm would have introduced itself as "The
PSY is swirling!".

Off with `battle.effects.announce = false`.

**A test-harness trap found on the way:** the new section called
`Battle.install()` when an earlier section already had. Installing twice
registers every handler a second time, so residual damage landed twice per
turn and the fraction assertions two sections later read half the HP they
should. The section is now placed after the one that installs, and does not
install again.


## 4.2.3

**Fix: the psystorm was chipping Psychic types -- the one thing it exists to
spare.**

Found by driving the battle layer against real ROM data rather than the test
stubs. The engine's Psychic type ID is `PSYCHIC_TYPE` while its display name
is `PSYCHIC` (`src/battle/TypeChart.lua`), and it is the ONLY one of the
fifteen Gen 1 types where the two differ. A battler's `curTypes` carries the
ID; every `chipType` in the catalogue is written the readable way. Compared
directly they never matched, so Alakazam took psystorm damage every turn.

Nothing errored, which is the whole problem: a comparison that is never true
looks exactly like a Pokemon that is simply not immune.

Fixed in the one place battler types are compared. The residual check was
doing its own inline loop rather than calling `hasType`, so the alias now
lives in `hasType` and the residual check goes through it -- one comparison
for the whole mod rather than fifteen chipTypes renamed to a form nobody
writing this catalogue would think of.

**No test covered it**, which is why it shipped. There is one now, written
with the ENGINE'S id rather than the readable name -- a test written with
`PSYCHIC` would have passed against the broken code just as the old inline
compare did. Mutation-checked.

Everything else in the battle layer was verified against real Yellow data at
the same time and is correct: rain/sun type power both directions, primal
rain and harsh sun nullifying the opposing type outright, Solar Beam halved
outside sun, Thunder never missing in rain, Blizzard never missing in hail
and snow, sandstorm sparing Rock/Ground, hail sparing Ice, and encounter
rolls returning a sane distribution.


## 4.2.2

**Fix: nothing drew on screen in any game. The engine now sandboxes
`love.system`, and reading it throws.**

The updated engine hands mods a `love` facade that ERRORS on `filesystem`,
`thread`, `system` and `event` (`src/mods/Sandbox.lua`). It errors on the
INDEX, which is the part that matters: the usual

    if love and love.system and love.system.getOS then

guards nothing, because reading the field is itself the throw. One such call
sat in the quality probe, reached on the FIRST pipeline update of the FIRST
frame -- and a pipeline whose update raises draws nothing at all. Hence a
blank screen everywhere rather than "weather is missing".

Seven call sites across three modules:

- `Quality.lua` asked `love.system.getOS` to pick a starting quality tier.
  There is no sanctioned replacement -- `mod.device:powerInfo()` answers
  battery state, not a platform name -- so the probe is gone and the default
  is simply the desktop one. Phones start on HIGH instead of MEDIUM now; that
  is a first-run default, not a cap, and AUTO already drops the tier from the
  frame rate, which was always the better signal.
- `Audio.lua` and `Backgrounds.lua` built `love.filesystem.newFileData` for
  every sound and battle backdrop. `love.data.newByteData` is not blocked and
  `newSource`/`newImageData` accept it just as happily, so the bytes still
  come from `mod:read` and only the wrapper changed. The real
  `newByteData` takes bytes ONLY -- there is no name argument where
  `newFileData` had one -- so the name is carried alongside.

**A grep-based regression guard now fails the suite if any shipped file
touches a sandboxed API**, naming the file and line. A behaviour test could
not catch this: the suite runs OUTSIDE the sandbox, so these calls never throw
there, and they had worked for years until the engine changed underneath them.
Mutation-checked -- reinstating the probe fails the suite.

The suite's `love` stub gained `data.newByteData` to match the real API.


## 4.2.1

**Fix: the weather froze on one type and never changed again.**

Reported as "weather is completely broken". It was not the new engine -- the
render path is unchanged there, `Pipelines.lua` is byte-identical and every
draw stage is still called. The mod's own suite was failing before the engine
was involved at all.

**The stuck sky.** A roused legendary bird held the weather for as long as the
player stayed on the map: the only thing that ended a rousing was LEAVING.
Because the encounter is spent after one claim, the storm then simply
persisted with nothing left to happen. A rousing now has a duration
(`legendary.minutes`, default 6), after which the bird is released and the map
is free to roll another.

Two mistakes were made fixing it, both worth recording:

- The tick was first placed in `resolveTarget`, which has no `dt` -- so it
  silently expired nothing. A timer handed a nil interval does not error, it
  just never runs down.
- Then the speed scale was applied to the COUNTDOWN rather than the DURATION.
  TEST speed is 0.02, so used that way it made a rousing fifty times LONGER.
  Ordinary spells apply it at arm time (`seconds * speedScale`); this now
  matches.

**PLAIN_FRONT drew nothing in battle.** It is the NORMAL member of the
type-storm family and was the only one of 28 pinned weathers with no `battle`
mapping and no `BATTLE_LOOK` entry, so it seeded no battle weather and
resolved no look. Wired like its siblings.

**Two tests were outdated rather than wrong:**

- `STORM` now carries `chipType = ELECTRIC`, so a thunderstorm draws out
  Electric in the grass. It answered nil when that assertion was written and
  no weather had a chipType.
- `activeWeather` now refuses FORCED pins -- ALWAYS, `config.force`, an
  OPTIONS ladder pin and DEBUG RAIN are cosmetic choices and must not rewrite
  the grass. The reroll tests set `State.id` by hand, which leaves `pinnedBy`
  at whatever the previous section left.

### Still failing, deliberately left for a decision

`...and NORMAL is a share you would actually notice` -- frozen weather is
**1.1%** of AUTO at NORMAL, against a threshold of 5%. The ratios are all
still correct (NORMAL is roughly twice RARE, OFTEN more again), so the bias
logic works; the absolute share collapsed because roughly eleven new
type-storms joined the pool at weight 2-3 each and diluted everything else.

That is the exact complaint the test was written to catch: snow, hail and
sandstorm near-invisible in AUTO. Fixing it means either lowering the
type-storms' weights or gating them behind the RARE WX setting instead of the
base pool -- a balance decision, not a bug fix, so it is left rather than
guessed at.


## 4.2.0

**Seasons, place banners, hard seasonal gates, and typed grass encounters.**

- **Four seasons** (SPRING / SUMMER / AUTUMN / WINTER) with HEMISPHERE
  (NORTH / SOUTH) and SEASON NOTE options.
- **Hard seasonal gates** on AUTO rolls: no snow/hail/blizzard in summer,
  no sun/heatwave/harsh sun in winter (hemisphere-aware).
- **Place + season banner** on game entry and map change (e.g. "Pallet
  Town" / "Summer").
- **Typed grass encounters**: every weather with a chipType leans wild
  spawns toward that type. Exotic fronts (Dragonstorm, Psystorm, …) may
  inject a dex species of the favoured type when the map table has none.
  Rain/sun/snow only reroll within the map's own table.

## 4.1.0

**Seasons (initial).**

- Four seasons, hemisphere option, season-change banner, soft AUTO weight
  leans. Superseded by the hard gates and encounter work in 4.2.0.

## 3.7.1

- **The opening roll now covers both Johto and Kanto.** It shuffled all 22
  regions and took six, which could put every one of them in Johto --
  roughly one run in fifty, and a certainty for somebody -- leaving a Gen 2
  player who takes the train to Kanto in a region where nothing had
  started. The roll is split per continent instead, so both halves of the
  world are weathered from the first frame whichever one the player is
  standing in. A continent with no regions contributes none, so this costs
  nothing where it does not apply.

## 3.7.0

**A fresh world no longer starts dry.** Prompted by a video of the mod
running on Gold for eight minutes with no precipitation in it: the night
grade and the fog were working, and nothing else ever arrived.

- **The fronts had no opening roll.** The global AUTO clock has never
  opened on CLEAR since 2.2.1, but the fronts -- which replaced it as the
  thing that actually decides the weather -- never got that rule. Every
  region started clear and rolled independently over the following ten
  minutes, so switching the mod on for the first time showed a dry world.
  Six regions now open with weather, chosen by shuffle so it is not always
  the same corner of the map.
- **Not all of them**: a world where every region is doing something is as
  unconvincing as one where none is, and clear skies somewhere are what
  make the weather elsewhere read as weather.
- Drift is skipped on that first roll, since every neighbour is still clear
  at that moment and inheriting from them would hand back exactly what the
  opening roll exists to avoid.
- The opening roll guarantees non-clear weather on its own terms rather
  than trusting the weighted picker's `exclude`: that picker can legitimately
  return CLEAR when every other weight has been zeroed by a config, and
  this is the one place where "anything but clear" is the requirement.
- A save that already carries fronts does not get an opening roll -- its
  weather is already real.
- Switching the legendary birds off mid-session now ends any live rousing,
  rather than leaving a bird pinning its weather with nothing able to clear it.
- README: CYCLE is named as the mode to use when showing the mod off.

## 3.6.0

**Battle backdrops should work on Gen 2 now.** `drawClassic` fills a
LITERAL 160x144, while `uiSize()` reports whatever the current layout is --
and the interception only matched the second. On any build where the two
disagreed the match failed, the substitution did nothing, and there was no
error to see: exactly the shape of "battle backgrounds do not work". Either
size is accepted now, since both are full-surface fills and nothing else in
the draw is.

**Puddles.** Rain now leaves a trace: the ground darkens as it soaks, and
stays wet for about two minutes after the shower passes.

- **Wetness is deliberately NOT a channel.** A channel belongs to a weather
  and eases toward that weather's value -- so it would be dragged to zero
  the moment the rain stopped, which is the one thing this must not do.
  Wetness belongs to the GROUND and outlives the weather: it fills in about
  twenty seconds of downpour and drains over two minutes.
- Puddles are anchored to the WORLD by the camera, like the ground
  splashes, so they sit still while the player walks past instead of
  swimming across the screen.
- Drawn as a darker sheen with one bright edge rather than a blue blob: on
  this palette that reads as ground gone wet, where water lying on top
  would read as a puddle sticker.
- `visuals.puddles = false` switches them off.

## 3.5.0

**Tornadoes now have a funnel.** They used to be a warp with a log line:
the screen changed and you were somewhere else, with nothing to say what
had happened. An event that moves the player against their will should
announce itself -- and the announcement is also the fairness, a couple of
seconds in which it is obvious what is coming.

- **The warp is the funnel's completion callback**, so the two cannot get
  out of step. Stopping the funnel does not warp anyone; a load hitch does
  not fast-forward it.
- **Not a weather type**, deliberately. A weather is a field over the whole
  sky, eased in over seconds and shared by every system; a funnel is one
  object, in one place, for two and a half seconds, with a beginning and an
  end. In the catalogue it would have meant a channel no other weather uses
  and an easing curve fighting a scripted timeline. It has its own pass and
  its own clock and owns nothing.
- Three things read as a tornado, none of them a picture of one: a column
  that leans and narrows toward the ground, debris on spirals that orbit
  faster the lower they are, and an arrival -- it grows from nothing while
  the sky closes in, so the warp lands on the fullest frame rather than at
  an arbitrary moment.
- Drawn last and outside the weather's own alpha: a tornado happens TO the
  frame rather than being weather in it, so it is not thinned by the
  BATTLES setting or the indoor rule.
- `tornado.funnelSeconds = 0` restores the instant warp.

## 3.4.0

**Weather now works on Gen 2 at all.** It never did, and the debug readout
had been saying so for several releases: `EVE 18:59/system in` -- the `in`
means the mod believed the player was INDOORS, in the middle of
Cherrygrove.

- `Map.isOutdoor` is `def.outdoor, else tileset == "OVERWORLD"`, and a Gen 2
  map has NEITHER. It carries `def.environment`, one of ROUTE, TOWN,
  INDOOR, CAVE, DUNGEON or GATE. So every Gen 2 map answered "not
  outdoor", the mod suppressed all precipitation everywhere, and Gold had
  no weather at all. `environment` is now checked first, with ROUTE and
  TOWN as the outdoor pair -- which is exactly what the engine's own Bike,
  Dig and door-sound checks use.

**The Pokegear map overlay now uses the gear's own data.**

- `Pokegear:region()` returns "johto" or "kanto" directly, following the
  player's landmark as `PokegearMap_CheckRegion` does. The field-name
  guessing was only ever a stand-in for not having the Gen 2 source.
- **Gen 2 landmarks carry PIXEL positions, not tile ones.** The landmark
  macro stores x+8/y+16 in OAM space, the extractor takes the offsets back
  off, and `Pokegear:drawMap` draws its own icons straight at `x, y`. This
  mod was converting tile coordinates that do not exist on that screen,
  which is why no marker ever landed on a town. It now reads each
  landmark's own position and drops a coloured marker there, falling back
  to the tile grid only where a landmark is unknown.

## 3.3.2

- **The `gear:` field on the debug readout is now always shown.** It was
  hidden when `pokegear_cards` was absent -- so a missing field meant
  either "the library is not installed" or "you are running a build without
  this readout", two very different answers that look identical on a photo.
  A diagnostic that omits itself is not a diagnostic.

## 3.3.1

**The forecast card was lying.** It reported the region's FRONT, but a
front is only the region's own sky -- a pinned OPTIONS rung, the ALWAYS
row, `config.force`, a location override, a psystorm or a roused bird all
outrank it. So the card said BLIZZ over Cherrygrove while Cherrygrove had a
clear sky, and the card was wrong rather than the weather.

- The header now reports **the sky the player will actually see**. A
  forecast that disagrees with the window is not a forecast.
- The row for the region underfoot is marked with `>`, so when it disagrees
  with the header it is visibly the one being overridden rather than
  looking like a bug.
- **A refused map overlay is now recorded.** If the library ignores the
  `map` host, or the map card is registered under another name, the overlay
  never draws and nothing said so. The result of `append` is kept, and the
  debug readout ends with `gear:` and the reason.

## 3.3.0

**The Pokegear card now looks like it belongs there.**

- **Half the glyphs were invisible.** The column used `* % # ~ +`, and the
  GSC font has none of them -- the MIST row in play had no glyph at all,
  just a gap. They are all letters now (R rain, T thunder, S snow, D dust,
  F fog, C clear, W wind, P psystorm), which the font certainly has, reads
  better on a four-colour map, and cannot silently vanish. A test now
  asserts every glyph is a character the font supports and that the legend
  only names glyphs something actually uses.
- **The list sits in the game's own framed box.** Every vanilla Pokegear
  card puts its content in one; without it this card was three separate
  white slabs with nothing tying them together. The header sits above the
  box, where the vanilla cards put their line of context, and the position
  line just below it.
- The frame call is guarded, so an older build of `pokegear_cards` without
  the `textbox` helper loses the border rather than the card.

## 3.2.1

- **Sandstorms and ashfall now blow their own desert wind.** Grit across a
  desert does not sound like wind through trees, and borrowing the ordinary
  loop would have been the same lie as a blizzard borrowing the rain.
  Matched by capability tag rather than by id, so ashfall gets it without
  being named and so will whatever sandy weather comes next.
- **A change of wind fades out before it fades in.** Swapping the source
  underneath would click, and cross-fading would need a second wind slot
  for a transition that already takes three seconds of visible weather. The
  dip is the storm turning over, which is what is happening.

## 3.2.0

**Wind, and with it a voice for most of the weathers that were silent.**

- **Wind is its own LAYER, not another bed.** A bed is chosen -- a weather
  has one or it has none -- and the two slots cross-fade between them. Wind
  is not like that: a gale and a downpour happen at once, and a blizzard is
  nothing but wind. So it plays alongside whatever bed is running, at a
  volume taken straight from the `gust` channel, which means it swells and
  drops with the same oscillator that leans the rain and drifts the snow.
- That gives **blizzards, sandstorms, ashfall, gales and the strong winds**
  a voice without misrepresenting them -- wind is what they actually sound
  like, where the rain loop would have been a lie. **Fog stays silent**,
  which is correct rather than a gap: fog is quiet.
- **Fixed an asset-loading rule that was about to bite.** Sound files were
  resolved as "thunder is .mp3, everything else is .ogg" -- true of the four
  files that existed when it was written, and wrong the moment a fifth
  arrived in a different format. Both extensions are tried now, once, and
  cached either way.

## 3.1.1

- **Zapdos's storm now looks and sounds like Zapdos's storm.** Its
  lightning is tinted yellow rather than the ordinary cool near-white, and
  it brings its own thunder (Pixabay, royalty-free).
- Both are optional fields on the bird entry, so Moltres and Articuno --
  which have neither -- behave exactly as before rather than needing empty
  values. The tint is a field on `Lightning` rather than a parameter, so
  the wash, the SOFT glow and the drawn bolt all read the same one without
  three call sites having to agree; the glow around a tinted bolt is pulled
  halfway to white, so a yellow strike still reads as light rather than as
  a painted line.

## 3.1.0

**The legendary birds.** A thunderstorm for Zapdos, ashfall for Moltres,
hail for Articuno -- a 5% chance on any outdoor map, and while one is
running the bird itself may turn up in the grass.

- **The sky is an ordinary weather, not a bespoke one.** A ZAPDOS_STORM
  would look exactly like a STORM and need its own catalogue entry, battle
  mapping and audio bed to draw the same rain. A rousing is a FLAG over an
  ordinary weather instead, so nothing in the draw path, the battle layer
  or the audio changes at all -- what makes it Zapdos's thunderstorm is
  that something is in it.
- **The encounter is the one substitution in the mod.** Everywhere else an
  encounter effect rerolls, so only species the map already contains can
  appear; that cannot work for a bird, because no route's table has one.
  It is fenced instead: 5% per map arrival, then a roll per encounter,
  **spent the first time it lands** so one storm cannot produce two. It
  hangs off `encounter.roll`, so the encounter RATE is untouched -- a bird
  replaces an encounter the map was already going to give you.
- **A rousing does not travel.** It ends when you leave the map: the bird
  belongs to that sky rather than following you around.
- Never indoors -- a cave is not where any of the three live.
- The level comes from the config (default 50), because the roll's own
  level would put a level 3 Zapdos on Route 1.

## 3.0.0

**Toggles for every weather type: ALWAYS SNOW, ALWAYS RAIN, and so on.**

- New **ALWAYS** row in the mod manager, listing every weather in the
  catalogue. It pins that weather everywhere, exactly as `force` in
  `config.lua` does -- but from the page a player can reach without a text
  editor, which is the case that has caught this mod out three times now
  (a `.modpkg` install has no editable config file).
- **One row rather than twenty switches**, because these are mutually
  exclusive by nature: "always snow" and "always rain" cannot both be true,
  and twenty independent toggles would let a player set exactly that and
  then wonder which one won. A single-select row cannot express the
  contradiction in the first place.
- The rungs are **built from the weather catalogue**, so a new weather type
  appears on the row with no second list to keep in step -- the same reason
  the OPTIONS ladder is built from `Types.PINNED`.
- It outranks a region's front and the AUTO clock, and yields to
  `config.force`, which is the more deliberate setting of the two.
- A stored value this build does not know reads as OFF rather than pinning
  something it cannot draw.

**Also fixed:** `mod.exports.version` had been hardcoded at `"2.0.0"` since
that release, so any companion mod asking this mod's version was told the
wrong one. It now reads `mod.manifest.version` -- one source of truth, and
it is the file the loader has already validated.

## 2.22.0

**A new weather: the PSYSTORM.** Violet cloud, hard wind and a great deal
of lightning, and it wears down anything that is not Psychic -- 1/16 max HP
per turn in battle, the same fraction sandstorm and hail use, so the rule a
player already knows holds here too.

It is the one weather that is not weather. It never rolls on the AUTO clock
and no front can drift it in; it is **summoned**:

- **Mewtwo's cave.** The innermost chamber is ALWAYS storming -- a chance
  there would mean standing in front of Mewtwo under a clear sky -- and the
  approach floors are a 70% chance, so walking in feels like walking toward
  something.
- **Mew or Mewtwo leading the party** calls it up on about 70% of maps,
  which is the version most players will actually see.

Rolled **once per arrival**, not per frame: a 70% chance evaluated every
frame is a certainty within a second, and per step would flicker. It
outranks a region's front -- the cave wins over the weather outside -- but
yields to `force`, a location override and a pinned rung. The front is only
overruled, never overwritten, so it resumes when you leave.

The violet is an ADDITIVE wash rather than a multiply like every other tint
in the pass: a psystorm's sky glows rather than darkens, and a multiply can
only take light away. Drawn after the precipitation so the rain glows too.
It is also the one weather that falls indoors without a location override,
because its home is a cave.

**Pokegear:** the map overlay now draws a LETTER per front rather than a
coloured square. The town map is a busy four-colour picture with orange
landmark squares already on it, and every marker read as the same shade in
play whatever weather it stood for.

**The forecast list is now scrollable and shows every region** -- up/down a
row, left/right a page, with a `1-7/22` position indicator. It listed six
fronts and hid the rest behind "+7 MORE", which answered "is anything
happening" but not "what is it doing at Blackthorn" -- and that is the
question a forecast exists for.

## 2.21.2

**Kanto's weather was being drawn on the Johto map.**

Reported with a photo of the map card: markers scattered in the sea and up
mountains. The Gen 2 map has a Johto page and a Kanto page, each with its
own coordinate space, and the overlay drew all 22 regions on whichever page
was showing -- so every Kanto marker landed somewhere arbitrary on Johto.

- Regions now carry a continent tag, and a page draws only its own.
- The displayed page is asked for first (several plausible field names --
  the library documents none, and the Gen 2 source is not available here to
  check) and falls back to the player's own continent, which is right
  whenever they have not paged away from where they are. An unrecognised
  shape draws nothing rather than guessing, because a wrong guess puts
  markers in the sea.

**Forecast card layout.** The header sat on row 3, which is where the strip
cursor sits, and the seventh list row ran into the footer -- which is what
put "7 MORE" and "SEE MAP CARD" on top of each other. The header moved to
row 4, the list is six rows, and the footer is on row 14.

## 2.21.1

**The Pokegear weather now overlays the real town map.**

Reported from play with a photo: the 2.21.0 card drew its own grid of
letters on an empty panel, in positions invented in `Fronts.REGIONS`. It
looked like what it was -- symbols floating in space that resembled Johto
only if you already knew the shape of Johto -- and the legend ran off the
right edge.

- **The engine already knows where every place is.**
  `game.data.field.townMap` maps each map id to its square, and
  `TownMap.markerXY` converts that to pixels (`x * 8 + 16, y * 8 + 8`). The
  weather is now an `append` overlay on the vanilla MAP card, painted at
  those coordinates over the actual drawn map, so every marker lands on the
  town the engine put there.
- Coloured by weather family rather than lettered -- blue rain, yellow
  storm, white snow, tan grit -- and **clear regions draw nothing**, since
  a dot on every town regardless would say nothing at all.
- **The region you are standing in is ringed**, so "where am I" is
  answerable without reading a header.
- The invented grid survives only as a fallback for a build with no town
  map data, where a rough map beats no map.
- The WEATHER strip card is now a readable forecast LIST rather than a
  drawn map: the panel is 20x14 characters, which is enough for words and
  not for geography. It lists only regions with weather worth naming,
  longest-running first, and says ALL CLEAR when there is none.
- Tests assert nothing is drawn off the panel -- the bug that put the
  legend half off-screen.

## 2.21.0

**Weather now belongs to a place instead of following you**, and there is a
WEATHER card on the Gen 2 Pokegear showing where the fronts are.

Until now there was ONE weather. Walk out of a blizzard and the blizzard
came with you, because a single `State.id` described "the weather" rather
than "the weather somewhere".

- The world is divided into **22 regions** -- a town and the routes around
  it -- across both Johto and Kanto, each running its own weather on its
  own clock. Snow over Mahogany keeps snowing over Mahogany after you
  leave, and is still there when you come back unless it has blown out.
- **Regions, not maps**, deliberately: per-map weather would change the sky
  every twenty steps and split a route into three climates. Weather systems
  are bigger than a screen. Matched by map-id prefix, so a map mod's
  `ROUTE_31_NORTH` lands in the region its name implies.
- **Fronts drift.** When a region's spell ends it is more likely to inherit
  a neighbour's weather than to roll blind -- which is what makes a front
  MOVE across the map instead of 22 regions blinking independently.
  Neighbours are computed from the map grid rather than typed out.
  `fronts.drift = 0` gives independent regions.
- Every region ticks whether or not the player is there: a front that only
  exists while watched is not a front, and the card shows skies over places
  you are not standing in.
- Fronts are saved as one packed string rather than a key per region --
  thirty keys that must be written in step is thirty chances to half-save.
- A front outranks the global AUTO clock and yields to everything the
  player or config asked for explicitly (`force`, a location override, a
  pinned rung). A map in no region -- every interior -- falls through to
  AUTO exactly as before.

**The Pokegear card** registers through `1Jamie/pokegear_cards`: the region
you are in and its weather, a glyph per region laid out on the panel grid,
and a legend. Read-only -- a card that could change the sky would be a
weather remote, not a forecast. It degrades to nothing when the library is
absent, disabled, not yet loaded, a different API version, or the game is
Gen 1.

## 2.20.0

**Fix: nothing was drawn on Gold. Weather ran, battle effects applied, the
options row worked -- and the screen stayed empty.**

Reported from play. The cause was in `Scene`, and it was two faults in the
same place, both of the same kind: this file identified the world by markers
only Gen 1 sets.

**1. It could not FIND the world.** `overworld()` scanned the state stack for
`isOverworld`, which only Gen 1's `OverworldState` carries
(`src/world/OverworldController.lua:31`); the `Game.overworld` fallback
demanded the same marker. Gold's world (`src/world/gen2/World.lua`) sets
neither, so this answered nil and `Scene.now.mapId` stayed empty. It now asks
`mod.world:overworld()` first -- the engine's own answer to "where is the live
world", `backed` on both generations, and resolved by each arm the way that
engine actually stores its world. The old scan is kept as a fallback for the
case where `mod.world` is not built yet.

**2. Even once found, the world was not VISIBLE.** `inspect()` walked the
same stack for the same marker to decide whether the world is on screen, and
returned outright when there was no readable stack -- which is what a Gold
boot looks like from here. So `visible` stayed `"hidden"` and every draw path
concluded there was nothing to draw over. Falling out of that walk means
nothing was found covering the world (a battle or an opaque menu returns
early), so it now finishes by asking whether a live world exists, and calls
that visible.

Gen 1 is untouched by both: there the scan finds the marker and returns
before either fallback is reached.

The first fault was the obvious one and fixing it alone changed nothing on
screen -- the map was found and the frame was still judged hidden. Both are
mutation-checked separately: reverting either fails the suite.

The new tests drive the real `Scene.sample()` against a Gold-shaped world (a
map, no marker), a Gen 1-shaped world, and no world at all. The existing
coverage in this area reimplemented Scene's outdoor rules rather than calling
it, which is why it passed throughout -- the bug was in the lookup, not the
judgement.


## 2.19.1

**The README was 858 lines. It is now 134, and it is accurate.**

The old one was a complete reference with no front door: someone who had just
installed the mod had to read past config schemas, compatibility internals
and test instructions to find out what the thing does. All of it is kept, in
`docs/REFERENCE.md`, and the new README covers what most people need --
install, what you see, what it does in battle, the options rows, and what to
do when something looks wrong.

**The generation labelling is corrected, which was the substantive fix.** The
battle table was introduced as "reference behaviour", which is too generous:
Gen 1 has no weather at all -- not one move or mechanic -- and Gen 2 has only
three weathers, with no hail, no fog and no primal skies. So most of what
this mod implements is Gen 3 through Gen 8 behaviour brought back. That is a
feature; calling it faithful was not. The reference now carries a table
naming the generation each effect comes from, and the README says plainly
that "Gen 1 accurate" is not what this is.

Also: troubleshooting now leads with the two symptoms actually reported from
play -- weather not reaching battle (WX RULES) and a terrain bonus that never
fires (the DEBUG HUD's `map:` field) -- rather than leaving them buried.


## 2.19.0

**The terrain bonuses were silently dead on Gold. Fixed with Johto rows read
out of the engine's own Gold manifest.**

The updated engine ships `tools/rom_manifest_gold.json` -- real Gold metadata,
368 maps, keyed to the same SHA-1 as the Gold ROM. Checking the mod's
configured map ids against it turned up the problem: **only 76 of Gen 1's 222
maps survive into Gold**, and neither Pokemon Tower (a Radio Tower by then)
nor Viridian Forest is among them. Eight of the ten bundled terrain rows
matched nothing on a Gold save. No error, no warning -- the same silent
failure that killed the Ghost bonuses once already under a misspelt id.

Johto rows now ship beside the Kanto ones, every id verified against that
manifest:

    ILEX_FOREST                       BUG, GRASS   (Johto's Viridian Forest)
    SPROUT_TOWER_1F / _2F / _3F       GHOST
    BURNED_TOWER_1F / _B1F            GHOST
    POWER_PLANT                       ELECTRIC     (already in both games)

Both sets ship together because the table is keyed by MAP ID: an id the
running game does not have simply never matches, so the Johto rows cost a
Kanto game nothing and vice versa.

**That broke the map-id checker, correctly, and it needed fixing too.** With
cross-generation ids bundled on purpose, the check started reporting six
Johto ids on every Kanto boot -- which is exactly how a useful warning turns
into noise people learn to ignore. It now exempts ids the MOD ships (gathered
from the defaults table itself, so adding a row cannot leave the exemption
behind) while still naming anything a PLAYER mistyped. Both directions are
mutation-checked: removing the exemption fails on the Johto ids, and widening
it to swallow everything fails on the player-typo case.


## 2.18.1

**A three-pass audit. One real coverage gap found and closed; no functional
bugs.**

Pass 1 ran everything: all 25 Lua files parse, the standalone suite three
times, the engine harness on both generations across fixtures, Red, Blue,
Yellow and the Gold-derived dataset, and the whole toolchain.

Pass 2 went after what the suites do not assert:

- 2000 battle start/turn/end cycles across every weather including nil, on
  both generations: no failures, heap delta 41K (gen 1) and 4K (gen 2), so
  nothing accumulates per battle.
- All 21 ladder levels ticked through the real pipeline update: no errors.
- The OPTIONS row's own `step` driven 22 times: all 21 weathers reachable,
  identical labels on both generations, which is the Gold options fix
  verified end to end rather than by unit test.
- A 50-round session -- ticks, battles, encounters, saves, map changes --
  with zero errors on both boots.
- Twelve hostile inputs (nil ctx, typeless move, typeless battler, HP already
  0, an unknown weather string, double battle-end, a junk row list): all
  handled on both generations.

Pass 3 mutation-tested six critical paths. Five were caught. **One was not:**
breaking `needsRuleset`'s Gen 2 branch changed nothing in either suite.

That gate matters. Gold has no ruleset dispatch, so no save can be on the
WEATHER ruleset -- if the requirement still applied there, a player who set
WX RULES to RULESET would get no battle weather at all and nothing would say
why. It hid because the default is ALWAYS, which returns before the Gen 2
branch is reached.

Two attempts at covering it were themselves vacuous and are worth recording:
an engine-harness test passed with the gate deleted because it set
`field.weather` by hand, which bypasses the seeding the gate actually
governs. The seeding path is only reachable where the module is, so
`Battle.gen2Boot` moved onto the table as a test seam and the assertion now
lives in the standalone suite, where it fails on the mutation as it should.


## 2.18.0

**AMPLIFIED is now a row in the in-game options menu.**

The house rule -- harsh sun and heavy rain hitting much harder, sandstorms
powering up ROCK and GROUND, hail powering up ICE -- could only be switched
on by editing `config.lua`, which meant most players could not reach it at
all.

`OPTIONS -> AMPLIFIED` is `AUTO / OFF / ON`. The row wins when it says
anything definite; `AUTO` (the default) defers to `config.lua`, so adding the
row did not take the file's answer away from anyone who had already set it.
Mutation-checked: making the effect read the file only fails two assertions.

`terrain` deliberately did NOT get a row. It only fires on named maps and
contradicts nothing, so it is a config decision rather than something to flip
mid-run; amplified changes how every primal sky and every sandstorm hits,
which is exactly the kind of thing a player wants to try and then turn off.


## 2.17.1

**Fix: no WEATHER row in OPTIONS on Gold, so there was no way to pick a sky.**

Reported from play. The pipelines themselves were never the problem -- both
`weather` and `daynight` register on a Gold boot, both run, and
`Pipelines.rows` builds their rows identically on either generation
(`render_pipelines` deliberately keeps the shared Gen 1 target because Gold
reads the merged table at that path).

What differs is who ASKS for those rows. Gen 1's options menu calls
`Pipelines.rows(game)` itself and splices the result in after TILT
(`src/ui/OptionsMenu.lua`). Gold's options menu never calls it
(`src/ui/gen2/OptionsMenu.lua`); it raises `ui.options.rows` and uses what
comes back. Nothing was broken -- the rows were simply never requested, so a
correctly-registered pipeline had no row and no way to be selected.

The mod now hands them over on that hook. Three properties, each with a test
and each mutation-checked:

- **Gen 2 only.** On Gen 1 the engine already splices these rows; adding them
  there too would show WEATHER and TIME twice.
- **Only this mod's two pipelines.** `Pipelines.rows` returns a row for every
  pipeline any mod registered, so appending the whole list would mean two
  mods applying this same fix each add the other's rows.
- **Idempotent.** If a later engine build starts splicing pipeline rows into
  Gold's options the way Gen 1 does, the ids are already in the incoming list
  and nothing is added -- so this cannot turn into a duplicate-row bug later.

A failure inside the wrapper returns the row list the chain gave it, so a bug
here costs the weather row and never the whole options menu.

Regression sweep: standalone 1039; Gen 1 boot 25-43 checks across fixtures,
Red, Blue, Yellow and the Gold-derived Gen 2 dataset; Gen 2 boot 33 and 42.
`gen2check --strict`, `validate --strict` and `lint` all clean.


## 2.17.0

**Gen 2 (Gold) compatibility, against the engine's own checker and adapter.**

The updated engine ships `docs/preparing-your-mod-for-gen2.md`, an adapter
(`src/mods/Gen2Compat.lua`) and `modkit gen2check`. Run against this mod, the
checker found one fatal problem and the Gen 2 boot found a second that a
static scan cannot see.

**1. The manifest claimed no Gen 2 game (`MK400`).** A mod that does not name
one is skipped entirely on a Gold boot -- not degraded, not partial, skipped.
`"games": ["gen1", "gen2"]` is now declared. Per the guide, that is a claim
that the mod HAS been run there, which is what the rest of this entry is.

**2. The `rulesets` registry has no Gen 2 home**, and this is the one that
mattered. Schemas states it plainly: "no Gen 2 ruleset dispatch exists". On
Gold the registration was taken, dropped and REPORTED -- a boot error on the
manager's list, making the mod look broken -- and, worse, `requireRuleset`
could never be satisfied there, so a player with WX RULES on `RULESET` would
have got no battle weather at all with nothing explaining why.

Now: the ruleset is not registered on a Gen 2 boot (an info line says so
instead of an error), and `needsRuleset()` answers false there, so every
battle effect applies without it. Nothing is lost -- the gate had nothing to
gate against on Gold.

**How the generation is detected, and why not the obvious ways.**
`GameVersion.get()` answers the CART, not the boot: a Gen 2 loader with Gen 1
data reports a Gen 1 version, so it is wrong in exactly the headless case
that tests it. The loader's own `generation` is a file-local. What is both
reachable and documented is the adapter's behaviour -- on a Gen 2 boot a
mod's require for `src.core.Game` returns a proxy, and the guide states
`pairs`, `next` and `rawget` see an EMPTY table on it "because the proxy
holds nothing of its own". An empty `Game` is the proxy, and the proxy exists
only on Gold. Anything unexpected reads as Gen 1, the behaviour this mod
already had.

**Everything else was already compatible.** Every engine member the mod
touches is `backed` in the adapter's coverage table -- `Game.stack`,
`Game.overworld`, `Game.data`, `Game.save`, `Map.isOutdoor`,
`BattleState.draw`. The mod reaches nothing `warned` or `absent`, uses no
version allow-list and no screen-id match, and does no upvalue surgery, so
`MK402` through `MK410` are all silent. `render_pipelines` keeps the shared
Gen 1 target on purpose, so the overlay needs no change.

The engine suite is now parameterised by generation (`WEATHER_FX_GEN=1|2`)
and asserts `mod.state == "loaded"`, not just an empty error list -- a gate
skip is deliberately not an error, so the error count alone passes for a mod
that never ran a line. Two loads in one process collide on the token
registry, hence the parameter rather than a second load.

Results: standalone 1039. Gen 1 boot 22-40 checks depending on dataset
(fixtures, Red, Blue, Yellow, and the Gen 2 dataset decoded from the Gold
ROM). Gen 2 boot 27 on Yellow data, 36 on Gen 2 data. Both halves of the fix
are mutation-checked: registering the ruleset on Gold anyway, or forcing the
generation test to answer Gen 1, each fail the suite.


## 2.16.0

**Actually run against a real Gen 2 dataset, not just checked for ids.**

The importer does not accept Gold/Silver/Crystal yet, so one was built: move
records decoded from the US Gold ROM (names 0x1B1574, move table 0x41AFF) and
species types from the base-stat table at 0x051B0B -- 251 moves and 249
species, all 18 types. The mod was then loaded against it through the real
engine harness.

Result: **39/39, no code changes needed.** Every weather effect behaves
correctly with Gen 2 content:

- A STEEL type takes no sandstorm chip damage; a DARK type does, correctly,
  since DARK has never had sandstorm immunity.
- DARK and STEEL moves (Crunch, Iron Tail) pass through the damage path
  untouched by rain, and a WATER move is still boosted -- so the new types
  neither break nor accidentally trigger anything.
- Solar Beam is still halved in rain with the Gen 2 record.

Nothing needed changing because the mod was already data-driven: every damage
table is keyed by type NAME, `hasType` walks whatever list a battler carries,
and the sandstorm immunity list comes from config. 18 types work exactly as 15
do.

A vacuous test caught while writing this: the STEEL check first used STEELIX,
which is STEEL/GROUND -- GROUND is immune on its own, so the assertion passed
even with STEEL deleted from the immunity list entirely. It now uses SKARMORY
(STEEL/FLYING), where only STEEL can produce the result, plus a PIDGEOT
control to prove the pass is STEEL's doing. Deleting STEEL now fails the
suite, as it should have from the start.

These tests activate only when the loaded dataset carries Gen 2 content, so
Gen 1 imports skip them: 21/21 on fixtures, 30/30 on each of Red, Blue and
Yellow, 39/39 on Gen 2.


## 2.15.5

**Gen 2 audit, read out of the Gold, Silver and Crystal ROMs directly.**

Gold/Silver/Crystal were checked against the mod rather than trusted to
memory: the move-name table was decoded from the US Gold ROM (0x1B1574, 251
names) and Crystal (0x1C9F29, identical), and the type-name table from Gold
at 0x0509E6. Findings:

- **STEEL and DARK are the exact spellings**, and STEEL is already in the
  `sandImmune` list, so a Steel type will not be chipped by a sandstorm the
  moment Gen 2 data exists. Nothing to change -- the list is read from config
  rather than hardcoded, and every type comparison in the mod is by name.
- **SOLARBEAM stays one word in Gen 2**, same as Gen 1. The mod's move table
  accepts both spellings anyway.
- **The three weather-SETTING moves arrive in Gen 2** -- RAIN_DANCE (240),
  SUNNY_DAY (241), SANDSTORM (201), all new. The mod already returns early
  from seeding when `battle.field.weather` is set, so a move-set sky is left
  alone rather than overwritten.
- **Weather Ball and the Hail MOVE are NOT in Gen 2** -- both are Gen 3.
  Neither appears in the Gold or Crystal move table. The mod implements
  neither, which is correct for Gen 2 as well as Gen 1.
- **No hardcoded type set anywhere.** The damage tables are keyed by type
  name, `hasType` walks whatever list the battler carries, and the residual
  immunity list comes from config. 18 types work exactly as 15 do.

New tests encode all of this. They run against whatever dataset is loaded --
skipping the Gen 2 half on a Gen 1 import, activating it on a Gen 2 one --
so a spelling that moves between now and the Gold/Silver release fails the
suite rather than silently disabling an effect.

### What could NOT be implemented, and why

**Morning Sun, Synthesis and Moonlight** (Gen 2 arrivals, indices 234-236)
vary their healing with the weather, and that is genuinely Gen 2-faithful
behaviour this mod does not have. It cannot be added from a mod hook: the
engine exposes fifty-odd hooks and not one of them touches move healing --
the same structural reason Solar Beam's charge turn cannot be skipped.
Implementing it needs either an engine hook that does not exist yet or a
`move_effects` patch, and neither is something to fake.

Their exact Gen 2 healing fractions were also not extractable: those live in
assembly, not in a data table, so nothing here is guessed at from memory.


## 2.15.4

**Verified against real game data from all three ROMs for the first time.**

Everything before this was checked against the ROM-free fixture set: 2 maps,
3 species, 4 moves, and those moves named `FIX_TACKLE` and `FIX_SCRATCH`.
Every id this mod matches on -- move ids, map ids, the species field the
encounter reroll reads -- was therefore an assumption. Red, Blue and Yellow
were imported (SHA-1 verified against the three canonical hashes in the
engine README) and the whole chain re-run against each.

Result: no id was wrong. Specifically confirmed against 223 maps, 151 species
and 165 moves:

- `SOLARBEAM` is the engine's spelling -- one word, no underscore. The mod
  also accepted `SOLAR_BEAM`, which does not exist in any of the three; it is
  kept only as a hedge for mods that add their own.
- `BLIZZARD` and `THUNDER` are real move ids, so the accuracy effects fire.
- All 18 map ids the mod ships with exist in Red, Blue AND Yellow. Yellow has
  223 maps to Red/Blue's 222 and the extra one changes nothing here.
- Species records carry a `.types` list, which is what the encounter reroll
  reads -- so that path is sound. Checked on real data: Pokemon Tower's grass
  is GASTLY and HAUNTER, both GHOST, and Route 12's is a real mix of
  GRASS/POISON and NORMAL/FLYING.
- The later-generation move ids in the accuracy table (`HURRICANE`, the three
  `-storm` moves) are absent from all three, as the code comments already
  said -- they are inert entries for mods that add those moves, not errors.
- The reroll was driven 3000 times through the engine's real `Encounter.roll`
  against Route 12's actual table with no error and a sane distribution.

The id checks are now permanent tests rather than a one-off audit. They run
against whatever dataset is loaded -- skipping on the fixture set, checking
everything on a real import -- and are mutation-checked with the exact wrong
spellings that caused earlier bugs: `SOLAR_BEAM` and `POKEMONTOWER_1F` both
fail the suite.

Engine harness: 21/21 on fixtures, 29/29 on each of Red, Blue and Yellow.


## 2.15.3

**A Kanto-Reforged compatibility audit. No behavioural bugs found; three
documentation defects fixed and the deferrals pinned by tests.**

What was verified, rather than assumed:

- **Load order is guaranteed, so detection at install time is sound.**
  `detectCapabilities` runs inside `Battle.install()`, at entry-chunk time,
  and asks `mod.find("Kanto-Reforged")` once. That would be a latent bug if
  load order were arbitrary -- a nil answered early would be a nil forever,
  and this mod would then apply Sand Veil and weather speed ON TOP of
  Reforged's. It is not arbitrary: `Kanto-Reforged` is in
  `optional_dependencies`, and the loader adds a real ordering edge for
  optional dependencies (`Loader:_order`), so Reforged is loaded first.
- **Both capabilities that gate something are pinned behaviourally.**
  `evasion` and `speed` are the only two of the four flags the code reads.
  Each now has a test asserting that with Reforged present the effect is NOT
  applied here, and all three deferral paths are mutation-checked: removing
  the `caps.evasion` guard, removing the `caps.speed` guard, or breaking
  detection outright each fail the suite.
- **`caps.weatherBall` and `caps.forms` are set and never read.** That is
  correct, not a bug -- neither Weather Ball nor Castform exists in Gen 1,
  this mod implements neither, and there is nothing to switch off. Recorded
  in the tests so a future version that starts implementing either cannot
  quietly double-apply it.
- **Seeding does not stamp on another mod's weather.** If something set
  `battle.field.weather` first, this mod returns rather than overwriting.
- The battle vocabulary written into `battle.field.weather` is the string
  set Reforged expects.

Documentation fixed in `config.lua`, which promised three things that are
not true:

- `solarBeam` was commented "charge skip in sun, half power otherwise". The
  charge skip is NOT implemented -- only the power change is. The module's
  own header says so; the config contradicted it.
- `weatherBall` and `forms` are inert toggles on their own: they control
  nothing in this mod, and with Reforged installed those features are
  Reforged's to configure. Both now say so instead of implying this mod
  implements them.


## 2.15.2

**Fix: weather never actually changed what appeared in the grass.**

The 2.13.0 feature -- fog drawing out Ghosts, sun drawing out Fire, snow
drawing out Ice -- was a complete no-op in a real game. It hung off
`encounter.species`, which is a TRANSFORM hook: its vanilla link is
`local function sameEncounter(enc) return enc end`, the identity function
(`OverworldController.lua:3485`). Calling it a second time returns the same
encounter it was handed, so the "reroll" rerolled nothing. The second result
could never be a different species from the first, the favoured type was
therefore never found, and the first roll was always returned. It cost an
extra chain call and changed nothing.

The reroll now hangs off `encounter.roll`, whose vanilla link is
`rollVanilla(encDef, ctx) -> Encounter.roll(encDef, ctx.rng)` and draws fresh
RNG on every call. Everything the design promised holds there and only there:
only species the map already contains, tables never bypassed, other mods'
tables respected, levels untouched.

**Encounter RATE is explicitly preserved.** A reroll only happens when the
first draw already produced an encounter, and a second draw that comes back
empty keeps the first. Weather changes WHAT you meet, never HOW OFTEN --
there is now an assertion pinning that, because rerolling a nil would have
quietly turned fog into an encounter-rate increase.

Why the tests did not catch it: the suite's chain stub returned a DIFFERENT
species on each call, modelling a rerolling continuation the engine does not
have. Four tests were repointed at the hook that is actually wrapped -- three
of them had become vacuous, since the stub invokes the vanilla link whether
or not a wrapper exists. The new coverage asserts against the engine's real
identity link, verbatim.

Audited at the same time, no changes needed:

- Every other hook this mod wraps was checked for the same fault -- calling a
  continuation twice when that continuation is an identity function.
  `world.tod` also has an identity link (`sameTod`) but calls it once, as a
  fallback, which is correct. The `battle.damage` and `battle.accuracy`
  wrappers mention `next_` several times but those are mutually exclusive
  early returns, not repeat calls.
- `encounter.fishing`'s link is a closure around `catchFrom`, which draws
  fresh each call, so the second cast is a genuine second cast. Note it is
  deliberately asymmetric with the grass: fishing improves the BITE RATE (a
  bite beats no bite), while grass keeps the rate fixed and changes only the
  species. Both are intended.
- `Encounters.typesOf` reads `require("src.core.Game").data.pokemon`. `Game`
  is a module-level singleton that `main.lua` calls `Game:load()` on, so
  `.data` is populated on the module table itself -- the path is correct.
- Tornado destinations are guarded against an empty list and cannot include
  the current map; Audio caches sources and records failures so a missing
  file is retried once rather than every frame.


## 2.15.1

**Carries over the three fixes from the 2.11.1 fork, which branched from
2.11.0 and so was not in 2.12.0's merge.**

- **A configured map id that is not a real map now says so.** A terrain bonus
  or location override keyed to a map that does not exist did nothing at all,
  silently -- no error, no warning, no way to tell it from one that simply had
  not come up yet. That is how `POKEMONTOWER_1F` (the engine calls it
  `POKEMON_TOWER_1F`) shipped with seven dead Ghost bonuses. The engine's map
  registry is now read on the first battle of a session and any configured id
  not in it is named in the log.

  A warning, never an error, and quiet when it cannot be sure: an unreadable
  or empty registry means "cannot say", and if NOT ONE configured id matches,
  the likelier explanation is a different dataset than that every entry is a
  typo. Stated cost: a config with exactly one entry and a typo in it gets
  nothing. The case it exists for -- one bad id among several good ones -- is
  still caught.

- **The OPTIONS -> WEATHER row in the README listed 13 weathers.** There are
  18; HEATWAVE, GALE, SLEET, THUNDERSNOW and ASHFALL were undocumented. The
  labels are now transcribed from `Types.lua` rather than typed from memory,
  so `TSNOW` reads as it actually appears on the row.

- **The test log stub now formats its arguments** instead of recording only
  the format string. A warning whose entire value is naming WHICH id is wrong
  is untestable otherwise -- found by writing a test that could not fail.

Checked while merging: all 29 place-name references in the modules 2.13.0 to
2.15.0 added (`Encounters`, `Tornado`, `Audio`, `Follower`) are real map ids.

Not carried over: the 2.11.1 fork also tried to make the engine harness
exercise the terrain ruleset gate. Three routes were attempted -- stubbing the
world global, ticking the weather pipeline through the registry, and both with
a raised ladder level -- and none moved `Scene.now.mapId`; damage stayed
vanilla with the gate deliberately deleted, so any assertion there would pass
either way. No assertion is better than one that cannot fail, so none was
added here either.


## 2.15.0

**Weather sound.**

- A looping bed under the rain, cross-faded when the weather turns, with
  the volume following the eased `rain` channel -- so a storm swells as it
  arrives and fades as it passes rather than snapping on and off.
- **Thunder fires from the strike itself**, not a timer: `Lightning.age`
  resets on each strike, so a fall in age IS a new strike. Reading the same
  value the flash is drawn from is what keeps the crack with the flash;
  a separate timer would drift apart from it within a minute.
- Two slots, never one, so a weather change fades one bed down while the
  other comes up. Swapping a single source would click exactly at the
  moment the player looks up.
- Muffled indoors rather than cut off -- hearing the storm you came in out
  of is most of the point -- quieter in battle, silent behind a menu.
- New `WEATHER SFX` row (`OFF / LOW / MEDIUM / HIGH`) and an `audio` block
  in `config.lua`.

**Only the rain weathers have sound.** Four beds arrived for nineteen
weathers, so snow, blizzards, hail, sleet, sandstorm, ashfall, strong winds
and fog are SILENT on purpose rather than borrowing the rain loop: a rain
bed under a blizzard tells the player something false about what is on
screen. Adding one later is a row in `Audio.BEDS` and a file.

It drives `love.audio` directly rather than the engine's audio registry,
which is built around tracks the game owns and selects; a weather bed plays
*under* whatever music is running and follows a channel value. The cost is
that the engine's volume slider does not reach it, hence its own row.

Credits: rain and storm loops from the Relic Castle weather tutorial pack;
thunder from Pixabay (royalty-free).

## 2.14.1

- Battle backdrop credits updated to **CDRX73, DerxwnaKapsyla, http404error
  and Game Freak**, in the README, the manifest, `config.lua`, the BATTLE
  ART help text and `lib/Backgrounds.lua`. Roles were not supplied, so the
  names are listed together rather than guessed at.

## 2.14.0

**Tornadoes -- OFF by default, and the row says post-game only.**

In a gale (or a sandstorm) a tornado can pick you up and set you down in a
town you have already visited. `TORNADOES` in the mod manager turns it on.

This is the only thing in the mod that moves the player, so it is built
with more suspicion than the rest:

- **Only where you have been.** Destinations come from `save.visited`, the
  engine's own record -- the same table the Town Map and Fly read. A
  tornado can therefore never show you somewhere the story has not, never
  skip a gate, and never strand you somewhere with no way home. This is
  why there is no curated destination list in the code: a hand-written list
  would have to guess at progression, and `save.visited` already knows.
- **Only outdoors, only in a gale**, and not at all until several places
  are known (`minVisited`, default 4) -- an early-game save is exactly who
  this is not for.
- **Always reversible.** Where you were is recorded before the warp, and
  `weather return` in the developer console puts you back. A feature that
  can move you should be able to unmove you.
- **The cooldown is long on purpose** (four minutes of gale, minimum). A
  tornado is an event; one every few minutes would be a fast-travel
  mechanic.

It can still ruin a playthrough in ways nothing here can prevent: being
moved mid-errand, away from the HM you set out with, or to the wrong side
of a gate you have not opened from that direction. "Where the player is
supposed to be right now" is a fact only the story knows. Hence off by
default, and hence the warning on the row rather than buried in a README.

## 2.13.0

**Weather reaches the grass and the water.**

- **Fog draws out Ghosts, sunshine draws out Fire, snow draws out Ice**, via
  the `encounter.species` hook.
- **Rain brings the fish up**, via `encounter.fishing`: a second cast, best
  of the two kept.
- Both are REROLLS, not substitutions. On an affected step the encounter is
  rolled again through the normal chain and the second roll kept only if it
  is the type the weather favours. So only species the map already contains
  can appear, Route 1 does not start producing Gastly, a map with no Ghost
  on its table is simply unaffected by fog with no per-map configuration,
  and a mod that rewrites the encounter tables is respected automatically
  because the reroll goes through the same chain. Levels are untouched.
- Which weather favours which type is read from the catalogue's capability
  tags, so a new fog or a new sun is covered without being named.
- Nothing happens indoors unless a location override says weather reaches
  inside -- a cave with no sky conjures no Ghosts.
- `encounters` in `config.lua` switches each half off and scales both.

These use documented, generation-agnostic hooks: the Gen 2 migration guide
names `encounter.species` as the route to take INSTEAD of engine surgery,
so this is the most portable code in the mod.

## 2.12.0

**Merged with the 2.11.0 fork, and the mod can now update itself.**

- The fork branched before 2.10.0, so four fixes were re-applied on top of
  its work: the glare gradient mesh (the band across the screen), follower
  chip damage, both `ash` bugs, cave sandstorms and indoor-override
  precipitation. The fork's WX RULES default, `terrain` house rule and
  readout reasons are the base.
- `"github": "MrKrisSatan/Weather-fx"` in the manifest, which is the key
  the launcher's updater and the "Other versions" list read.

### Gen 2 status: prepared, NOT claimed

`modkit gen2check` could not be run here (this checkout predates it), so
this is a read of the coverage table rather than a tool run:

- Of the engine modules this mod touches, `src.core.Game`,
  `src.battle.BattleState` and `src.world.Map` are served by the adapter.
  **`src.render.TextBox` and `src.render.Pipelines` are not** -- both are
  already `pcall`'d and degrade quietly, costing text-box clipping and
  DEBUG RAIN's ladder push on a Gold boot.
- **`"games"` is deliberately NOT set.** The guide is explicit that adding a
  game means "I have run this there", and a mod that claims one loads in
  full -- so a half-working mod shows the player a broken mod rather than a
  skipped one. Nobody has booted this on Gold yet. Add the key after that,
  not before.

## 2.11.0

**WX RULES now defaults to ALWAYS: a pinned sky reaches battles out of the
box, on any save.**

It defaulted to `RULESET`, on the reasoning that a mod should change nothing
until it is opted into. That reasoning failed the most common install there
is: add the mod to a save already in progress, pin a sky on the WEATHER row,
walk into grass, get a dry battle. Nothing broken, nothing said so, and the
setting that explained it was a different row (WX RULES) in a different menu
(the mod manager, not OPTIONS) under a name that does not obviously mean
"whether the sky is allowed into a fight".

Correct but indistinguishable from broken is the wrong default. `RULESET` is
still one row away for anyone who wants battles untouched until a
WEATHER-ruleset save, and `OFF` still disables battle weather entirely.

What this changes, stated plainly rather than buried: on an ordinary save,
battle weather effects -- chip damage, accuracy, type multipliers -- and the
`terrain` house rule now apply where they previously did not. That is a real
change to how battles play, and it is the change that was being asked for.
An indoor battle still inherits no sky, and weather a MOVE or ABILITY sets
was never gated by this row at all.

Also in this release:

- `rulesRow()`'s own fallback (used when the settings row cannot be read)
  moved to `always` in step with the row default. Left behind, the mod would
  have behaved one way with a readable settings store and another way
  without.
- The tests that encoded the old default were updated rather than deleted:
  each now sets the row to `RULESET` explicitly and still asserts the gate
  works, and a new case asserts the out-of-the-box path -- a pinned sky
  reaching a battle on a vanilla-ruleset save with nothing configured.
- The engine harness's "installed and unselected" comment was corrected. It
  passes headlessly whatever the default is (no weather is running there),
  so it was documented as what it is rather than left looking like evidence
  about a gate it does not exercise.


## 2.10.2

**The readout now says WHY a battle has no weather.**

Follow-up to the same report. With the menu pin fixed the overworld changed
and battles were still dry -- which was not a weather bug at all: WX RULES
sits on `RULESET` by default, and RULESET needs a game *started* on the
WEATHER ruleset. On an existing save the seed is skipped and the battle
stays vanilla, exactly as designed. `OPTIONS -> WX RULES -> ALWAYS` carries
the sky in on any save.

That design is deliberate and is NOT changed here -- installed-but-unselected
being byte-for-byte vanilla is a promise the engine harness asserts. What
was wrong is that `btl` printed a bare `-` and named no reason, so a
one-setting question was indistinguishable from a broken mod. It now reports
the gate that closed, in the same shape `art:behind!not-installed` already
used:

    btl -!needs-ruleset   RULESET, and this save is not on that ruleset
    btl -?needs-ruleset   same gate, armed but not yet tested (no battle up)
    btl -!wxrules-off     WX RULES is OFF
    btl -!indoors         an indoor battle inherits no sky
    btl -!seed-off        seedFromOverworld = false
    btl -!battle-off      battle.enabled = false

`!` is a gate that stopped this battle; `?` is one that is armed but
untested. Also: the WX RULES help text now leads with this symptom, and the
troubleshooting table carries a row per reason.


## 2.10.1

**Fix: a menu pin was silently overridden by a location override.**

Reported from play -- PRIML chosen on the OPTIONS row, and the battle was
not primal rain. The cause was not in the battle layer at all: every one of
the 18 pinned weathers maps, seeds and draws correctly (there is now a test
that walks all of them end to end). The cause was `WeatherState.choose`
reading `Config.locationFor` BEFORE the ladder rung, so any map carrying a
certainty override -- Lavender Town ships `FOG` -- took the sky away from
the menu. The overworld showed the map's weather, the battle inherited the
map's weather, and the row the player had just moved appeared to do nothing.

The rung is now read first when it names a weather. A location override is
a default for the unattended case ("Lavender Town is usually foggy"), not a
veto over an explicit choice. AUTO and CYCLE are not the player naming a
weather, so they fall through to the override exactly as before -- the
`pinnedBy` debug field still reads `location` on AUTO in Lavender Town.

New coverage:

- **EVERY weather reaches the battle** -- for each of the 18 pinned types:
  it seeds the battle string it maps to, that string resolves a look, and
  the battle's own eased channels come up off zero. Only CLEAR may map to
  no battle weather, asserted explicitly, because the first draft of this
  test could not tell "correctly seeds nothing" from "wrongly seeds
  nothing" and passed a mutation that removed HEAVY_RAIN's mapping.
- **a menu pin versus a location override** -- the regression itself, plus
  the AUTO case that must keep working.


## 2.10.0

**Two house rules from a separate weather mod, folded in behind their own
switches.**

- **TERRAIN** -- a per-map type bonus, on by default. Bug and Grass under
  the Viridian Forest canopy, Electric in the Power Plant, Ghost on every
  floor of the tower. `battle.terrain` in `config.lua` is the table; keys
  are map ids and are yours to add to, so unlike most of that file they
  are not typo-checked against a known list. Multipliers clamp to 0-4.
- **AMPLIFIED** -- a stronger primal sky, **off** by default. Harsh sun
  takes FIRE to x2.0 and heavy rain takes WATER to x2.0 (instead of the
  reference x1.5), a sandstorm powers up ROCK and GROUND, and hail powers
  up ICE. Ordinary sun and rain are untouched either way.

The two default differently on purpose, and the reason is worth stating
because it decided the design. `terrain` ADDS something the reference has
no opinion on and only fires on named maps, so nothing it does contradicts
anything this mod already promises. `amplified` CONTRADICTS reference
multipliers that this mod implements and *tests* -- "...but physical
damage is untouched" asserts a sandstorm does not power up ROCK, and
switching amplified on by default made that test fail. A house rule that
quietly stops the mod doing what its own suite says it does is opt-in, and
the test stays as it was rather than being rewritten to accommodate it.

Notes on the implementation:

- The amplified row **replaces** the reference row for that weather; it
  never multiplies with it. Stacking them would be the double-apply bug
  the Kanto-Reforged capability detection exists to avoid, arrived at from
  a different direction. There is a test asserting the 300 that stacking
  would produce does not happen.
- The damage hook's early-out changed shape. It used to return as soon as
  there was no weather; terrain is a property of the **map**, so it now
  asks whether there is anything at all to apply. A forest bonus that only
  worked while it happened to be raining would have been the bug here.
- `battle.terrain` is pulled out of the config before the type-checked
  merge, alongside `locations` and `tuning`, because its keys are map ids
  -- left in, every map a player added would have been reported as an
  unknown key and dropped.
- The debug readout gained `map:` and `terr:`. A terrain bonus that
  silently does nothing is almost always a map id that does not match the
  key in the config, and that was unanswerable without seeing the id the
  game actually uses.
- The bundled map ids are **verified** against `tools/rom_manifest.json`,
  the engine's own list of all 222 map ids. This caught a real bug before
  release: the tower floors were written `POKEMONTOWER_1F`, the engine
  calls them `POKEMON_TOWER_1F`, and all seven Ghost bonuses were silently
  dead. Ids a player adds are still unchecked at runtime and fail the same
  silent way, which is what that readout is for.

Fixed during a pre-release audit of the above (all three found by review, not
by a failing test -- the suite was green throughout):

- **Terrain ignored the mod-manager rules row.** `terrainScale` consulted
  only `Config.battleEffect("terrain")`, which answers "is this effect
  switched on" and does not fold in the manager row; every weather effect
  reaches that gate through `weatherFor`, which terrain never calls. Setting
  the row to OFF stopped the weather and left terrain running. It now asks
  `Battle.effectsEnabled()` directly.
- **Terrain ignored the ruleset gate**, which is the more serious of the
  two: it broke the promise that installed-but-unselected is byte-for-byte
  vanilla. Weather holds that promise for free (unselected means seeding is
  skipped, so `field.weather` stays nil), but terrain needs no weather, so a
  Viridian Forest battle on a vanilla ruleset was getting the BUG bonus. The
  map id is now stored at `battle.started` only when the same ruleset test
  seeding uses passes, so an unselected ruleset switches terrain off for the
  whole battle. Both are covered by mutation-checked assertions.
- **The debug readout ran off the edge.** `map:`/`terr:` grew the line from
  ~127 to ~162 characters, and it is drawn unwrapped -- pushing the newest
  fields, the ones worth reading, past the window edge. It now measures and
  wraps to a second line when it does not fit, and a map carrying more than
  three types is summarised rather than listed.
- Two example map ids in comments (`SEAFOAM_ISLANDS`) were not real map ids;
  a player copying them would have hit the same silent failure. Every
  map-id-shaped token in the mod is now checked against
  `tools/rom_manifest.json`.


## 2.9.2

**BEHIND now draws in colour mode, which is why it appeared to do nothing.**

- 2.9.0 stood down whenever `BattleState:colorMode()` was true, on the
  reasoning that the SGB/GBC path draws the field into a canvas that is
  then recoloured by zone, so a painted backdrop might come out tinted.
  That may be so -- but it meant BEHIND silently did nothing on any device
  running in colour, which is most of them. A guess about how something
  might look was overriding what the player could see for themselves, and
  "no backdrop" is a worse outcome than "a backdrop I can switch off".
- It draws now. `battleFieldArt = "mono"` in `config.lua` restores the old
  behaviour for anyone who looks at the result in colour and disagrees.
- The `art:` field on the debug readout names the reason whenever BEHIND
  is selected and not drawing, including this one.

That is the third bug in a row where the FEATURE worked and the SWITCH did
not: a config file a .modpkg install cannot open, a wrapper installed only
at startup, and now a stand-down nobody asked for. The pattern was mine to
spot sooner.

## 2.9.1

**Fixes BEHIND leaving the battle box white.** Two bugs, either of which
alone was enough.

- **The wrapper was installed only if BATTLE ART already read BEHIND at
  `game.ready`.** Switching the row mid-session did nothing until a
  restart, silently. It is now installed unconditionally -- the wrapper
  asks the setting on every draw, so installing it always is what makes the
  row take effect on the frame it is flipped.
- **AUTO stood down whenever StadiumBattleFX or a voxel diorama was
  INSTALLED**, which guessed from the wrong thing: those mods stage some
  battles and not others, so a classic 2D fight got a white box purely
  because a 3D mod existed on disk. The interception is already
  self-limiting -- if another mod owns the battle draw, the full-surface
  fill it looks for never arrives and it substitutes nothing -- so there
  was nothing to stand down from. `battleFieldArt = "off"` remains for a
  conflict this cannot predict.
- The debug readout now ends with `art:` -- `around`, `behind`, or
  `behind!<reason>` when BEHIND is selected but not drawing. That is the
  question the previous readout could not answer.

## 2.9.0

**Battle backdrops can now draw BEHIND the Pokemon, inside the white box.**

Set **BATTLE ART** to `BEHIND` in the mod manager. `AROUND` (the default)
keeps the previous letterbox-only behaviour.

- This is **the only part of weather_fx that patches engine internals**.
  There is no hook between the battle filling its field and drawing its
  sprites: `battle.overlay` runs at the end, `battleBg = "world"` exposes
  the voids only ("the battle screen itself is untouched: it keeps its
  white paper field in every mode" -- BattleState:82), and
  `render.compose` demands taking over the entire window composite.
- So the field fill is intercepted. Both draw paths do the same thing --
  set the paper colour, then `rectangle("fill", 0, 0, W, H)` across the
  whole surface -- and for the duration of one battle draw
  `love.graphics.rectangle` is replaced with a function that spots that
  call and draws the backdrop in its place. Everything else passes
  through, and the original is restored on every path including an error.
  Only the FIRST full-surface fill is replaced, so the screen-flash
  overlay later in the draw survives.
- **It stands down** for the nickname screen (which clears its field on
  purpose), for SGB colour mode (which recolours the field by zone and
  would map a painted backdrop as if it were Game Boy tiles), and when
  StadiumBattleFX or either voxel diorama is staging battles. All three
  are overridable via `battleFieldArt` in `config.lua`.
- The wrapper is exposed as `BattleField.wrap` so the test suite drives
  the real code rather than a replica of it.

If the engine changes that one line, this degrades to "no backdrop", not
to a broken battle -- but it is the one piece of the mod that can break on
an engine update.

## 2.8.0

**Battle weather effects can now be switched on from the mod manager.**

They have existed since 2.0.0 -- sandstorm and hail chip damage, fog
lowering accuracy, rain boosting WATER and damping FIRE, and about a dozen
more -- but carrying the overworld's sky into a battle required the
WEATHER ruleset, chosen when a new game starts, and the switch to release
that lived only in `config.lua`. A `.modpkg` install has no editable copy
of that file, so on a handheld the gameplay half could not be turned on at
all. That is the same mistake DEBUG RAIN made in 2.0.1.

- New **WX RULES** row in the mod manager: `OFF / RULESET / ALWAYS`.
  `ALWAYS` carries the overworld sky into every outdoor battle on an
  existing save; `RULESET` is the old default; `OFF` disables the lot.
- Either the row or the file may RELAX the gate, and neither can silently
  tighten the other -- so a `requireRuleset = false` in the file is not
  quietly re-imposed by an untouched menu row, and a player with no
  editable file can still turn the rules on.
- Weather set by a MOVE or ABILITY is still never gated: those battles
  already had weather, and the gate only decides whether the SKY joins in.

## 2.7.1

- Corrects the battle backdrop credit to **CDRX73** (Reddit). 2.7.0 spelled
  it CXRX73 throughout.

## 2.7.0

**Battle backdrops.** 23 painted scenes at 240x112, day and night
variants. **Art by CDRX73 (Reddit)** -- credited in the README and in
lib/Backgrounds.lua.

- Chosen by **weather first, map second**: a blizzard puts you on the snow
  field wherever you are, a sandstorm on the desert one, and otherwise a
  cave is a cave, the plateau is a mountain, Cinnabar is a beach and a
  route is tall grass. Weather is matched by the capability tags the
  catalogue already carries, so a new weather type is covered without
  being added to a second list.
- Night variants follow this mod's own clock, so they agree with the
  day/night grade rather than arguing with it. The base/"2" variants are
  picked by a stable hash of the map id, so a given map always looks the
  same without a table naming every map.
- **They draw in the LETTERBOX, around the battle screen -- not behind the
  Pokemon**, and that is a limit of the engine rather than a setting.
  There is no hook between the battle filling its field and drawing its
  sprites. `battleBg = "world"` looks like the seam and is not: the
  engine's own comment says it "changes what surrounds the battle and
  leaves the battle screen alone". `render.compose` would work but demands
  the mod take over the entire window composite -- SGB zones, palette
  pass, letterbox, GBC FX -- to place one image. `render.letterbox` is the
  documented hook for art behind the playfield, needs no engine internals,
  and cannot contend with StadiumBattleFX or the voxel mods.
  Drawing behind the sprites needs one new engine hook: a
  `battle.background` called after the field fill, the natural sibling of
  the `battle.overlay` that already exists.
- New `BATTLE ART` row in the mod manager, and `battleBackdrops` /
  `battleBackdropDim` in `config.lua`.
- **The mod now ships assets** (332 KB) for the first time. `modkit lint`
  still reports no ROM-derived content -- Gen 1 has no battle backgrounds
  at all, so none of this is derived from one.

## 2.6.1

- **Battle weather now fills a wide battle.** The engine ships a 304x144
  battle surface (`WideBattle.WIDTH/HEIGHT`), switched on by
  `save.options.battleLayout == "wide"`, and `BattleState:uiSize()` is its
  own answer for how big the surface is. This mod hardcoded 160x144, so a
  wide battle got weather across its left half only — a 4:3 box inside a
  widescreen fight. The field now follows `uiSize()` per frame and
  respawns across the new width, falling back to 160x144 for a battle that
  cannot answer.
- This is the likelier cause of the "only in 4:3 ratio in battle" report
  than the wide-battle mod detection added in 2.4.0. Both fixes stand; this
  one needs no companion mod installed.

## 2.6.0

**Fixes "only fog ever appears" in the overworld — a regression I shipped
in 2.3.1.**

- 2.3.1 required a map to BE the engine's `lastOutdoor` before it counted
  as having a sky. But `lastOutdoor` records the outdoor map you last
  **left**, not the one you are standing on: the engine sets it on a
  transition OFF an outdoor map (OverworldController:4013). So walking out
  of a house in Pallet Town and north to Route 1 left it saying
  PALLET_TOWN, every route read as indoors for anyone who had ever entered
  a building, and all precipitation was suppressed — while fog, veil and
  the grade kept drawing, because those survive indoors by design. Hence
  "only fog".
- The cave problem it was added for **did not exist**: Rock Tunnel, Mt Moon
  and Victory Road use the CAVERN tileset, which `Map.isOutdoor` already
  rejected. Working code was broken to fix nothing. Reverted to the tileset
  test alone, with a new `indoorMaps` list in `config.lua` for any map that
  genuinely needs naming.
- **New CYCLE rung on the WEATHER row**, between OFF/AUTO and the pinned
  weathers. It walks the catalogue in order instead of rolling dice,
  skipping clear skies entirely, so every weather gets its turn and
  something is always falling. AUTO SPEED controls how long each lasts.
  AUTO remains the realistic mode; CYCLE trades realism for variety.
- `Ladder.DEBUG_RUNG` is now found by searching the built ladder rather
  than by an offset into `Types.PINNED` — the automatic rungs ahead of the
  pinned list have changed twice now, and the offset silently pointed at
  the wrong weather each time.

## 2.5.1

**Three battle-effect bugs, found by checking the engine source instead of
trusting the test stub.** Every one of them passed against a hand-built
context and would have failed in game, because the stub was shaped the way
the engine's context was *assumed* to be.

- **Turn order was corrupted, not merely broken.**
  `TurnOrder.firstMover` returns a BOOLEAN — "does `a` go first" — and the
  engine assigns the hook's result straight into `pFirst`. This mod
  returned a battler table, which is always truthy, so the player would
  have moved first every single time a weather speed ability was in play.
  It never actually fired only because of the second bug below, so no save
  was affected; both halves are fixed together.
- **The weather speed abilities never fired at all.** `battle.turn_order`
  is given a context of `{ rng = self.rng }` and nothing else — no
  `battle` — so Chlorophyll, Swift Swim, Sand Rush and Slush Rush read a
  nil battle and returned early every time. The live battle is now tracked
  from the battle events, which is the only source that works for every
  hook.
- **Status moves took a point of damage.** `Damage.compute` returns 0 for a
  status move; the clamp that stops a scaled hit rounding down to zero was
  flooring that 0 up to 1, so a WATER-type status move under rain dealt
  one damage. Zero now stays zero.
- The damage hook reads `ctx.user`, which is the name the engine actually
  sends; `ctx.attacker` is still accepted for mods that re-dispatch.

Verified against the engine source as correct: `battle.field` exists in
vanilla, `BattleState:onFaint` exists, `Damage.compute` returns
`(damage, { crit, typeMult })` with effectiveness in tenths,
`accuracyRoll` returns a boolean, `mon.stats.hp` is max HP, `curTypes` and
`isPlayer` are real battler fields, and `battle.move_used` carries `user`.

## 2.5.0

**Five new weathers, and the rare ones actually turn up now.**

- New types: **SLEET** (rain, snow and a little ice together), **THUNDERSNOW**
  (a blizzard with lightning in it), **ASHFALL** (Cinnabar's volcano),
  **HEATWAVE** and **GALE** (hard slanting rain with debris blown through
  it). Nineteen weathers in all, all on the OPTIONS ladder.
- New **ash** channel and a fourth grain kind: grey, slow, near-vertical,
  and it settles rather than bouncing. Ash is not sand blown sideways.
- **RARE WX** row in the mod manager: `OFF / RARE / NORMAL / OFTEN`,
  default NORMAL. The built-in region bias suppressed snow, hail, sleet,
  sandstorm and ashfall to x0.2 and x0.25 away from the handful of maps
  that argue for them — tuned for plausibility, and the effect was that
  AUTO could run for hours without showing one. This scales the
  suppression rather than the weather, so the geography still shows
  through: the mountain pass keeps its snow bonus at every setting.
- **Per-weather switches in `config.lua`**: `weathers = { HAIL = false }`
  removes one absolutely, checked before any weighting. `tuning.<ID>.weight`
  multiplies how often AUTO picks it.
- Ashfall is biased toward Cinnabar Island, Route 21 and the Mansion.

## 2.4.0

**Battle weather fills a widescreen battle, and two more mods are supported.**

- The `battle.overlay` hook draws inside the engine's 160x144 battle canvas
  — the engine fills exactly that rectangle immediately before calling it.
  That is the right place normally, because it scales with the battle and
  passes through the palette handling. It is the wrong place when another
  mod has drawn a **wider** battle behind it, because then the overlay
  covers only the classic 4:3 box sitting in the middle of a larger scene.
  New `battleView` setting: `canvas`, `screen`, or `auto` (the default),
  which picks `screen` when a wide-battle mod is installed.
- **StadiumBattleFX** (`STADIUM_BATTLE_FX`) and **Dramaless Shape**
  (`DRAMALESS_SHAPE`) are detected and switch battle weather to the whole
  screen automatically, as does DRAMATIC_SHAPE with its 3D arenas.
- **DRAMALESS_SHAPE drives the day/night clock**, exactly as
  DRAMATIC_SHAPE does — it is a fork that keeps the same `exports.lib`
  seam and ships the same `lib/DayNight.lua`. The probe is shape-checked,
  so a fork that renames or drops the module costs a lighting nuance
  rather than a crash.
- New `lib/Interop.lua` holds every "is that other mod installed" question
  in one place, asked lazily and cached only on success, so the answers
  cannot drift apart and there is a single list to edit when a new fork
  appears.
- The battle's channel easing moved from `BattleDraw.draw` to
  `BattleDraw.tick`, which runs every battle frame whichever mode is
  drawing. Otherwise a widescreen battle would show weather frozen at
  whatever it was when the battle opened.
- A battle's weather comes from `battle.field.weather`, so the INDOORS
  rule no longer reaches it: a Rain Dance in a gym rains.

## 2.3.2

**Fixes weather on the battle screen indoors.**

- The battle overlay read the OVERWORLD's weather, so a battle fought in a
  gym showed whatever the sky outside was doing. It now reads
  `battle.field.weather` — the same authority every battle EFFECT already
  used — so the visuals and the damage multipliers can no longer disagree
  about what the sky is doing.
- The same mistake ran the other way too: a Rain Dance cast indoors used to
  show nothing, because the overworld was clear. It now rains, wherever the
  battle is.
- When the field matches what the overworld is doing, the overworld's own
  entry is used rather than a generic representative — so a battle fought
  in a thunderstorm keeps its lightning instead of flattening to plain
  heavy rain. A reverse lookup alone would have lost that.
- Weather arriving mid-battle eases in over about a second instead of
  appearing between two frames.

## 2.3.1

- **Caves and dungeons no longer get weather.** Indoor detection used
  `Map.isOutdoor`, which is really a question about the TILESET — so a cave
  laid out with outdoor tiles (Rock Tunnel, stretches of Victory Road)
  answered "outdoor" and rain fell inside it. A map now needs an outdoor
  tileset **and** to be the last outdoor map the player stood on, which is
  the engine's own `lastOutdoor` bookkeeping for door sounds and blackout
  recovery. The second signal can only ever remove a sky, never grant one,
  so a fresh save with no `lastOutdoor` yet still gets weather outside
  rather than rain indoors.
- **The readout shows whether you are under a sky and whether debug rain is
  on**: `WX L6 DEBUG HEAVY DBG | MORN 09:03/system in | ...`. Both absences
  cost real debugging time — "it is raining indoors" and "the mod does
  nothing" each have an answer that is now one glance away.

## 2.3.0

- **INTENSITY gains an AUTO setting.** Each family of effect — rain, snow,
  grains, haze, lightning — swells and eases on its own slow rhythm, so a
  downpour is not the same downpour for six minutes and a storm's strikes
  cluster and then go quiet. Five families on incommensurable periods, so
  they never line up for long: one shared oscillator would make everything
  breathe together and read as the brightness being turned up and down.
  The weather type, the scheduler, the save and the battle layer cannot
  tell the difference — only the final multiplier moves.
  - The **strike rate** is included, even though it is a rate rather than
    an amount and so is untouched by the fixed INTENSITY settings.
    Clustering strikes is the whole point.
  - The **grade channels are deliberately excluded** (gloom, warmth,
    glare). A full-screen multiply that pulses reads as a fault, not as
    weather.
  - Tunable via `autoIntensity = { min, max, seconds }` in `config.lua`.
- **Rain and hail now land all over the screen, not along the bottom
  edge.** This is a top-down game, so the whole screen is ground; bursting
  only at the bottom is what a side-on game would do and made the rain read
  as falling *behind* the world rather than onto it. Each drop picks its
  own landing depth at spawn, so splashes appear at every distance at once.
  `splashSpread` (0..1) controls how far up they reach; `0` restores the
  old bottom-edge behaviour.

## 2.2.1

**Fixes weather appearing to work only in debug mode.**

- Turning DEBUG RAIN off used to put the OPTIONS row back to **OFF**, on
  the reasoning that it should leave things as it found them. In practice
  that meant the only thing that ever switched weather on was debug mode,
  and switching debug off switched the whole mod off. It now hands the
  ladder to **AUTO** instead — someone who has just confirmed the mod
  works wants to play with weather, not to turn it off. A rung you set
  yourself is still never touched or undone.
- **The first AUTO spell after switching on is never CLEAR.** CLEAR
  carries the largest weight and runs for six to sixteen minutes, so the
  most likely first experience of enabling the mod was a long dry sky —
  indistinguishable from a mod that does not work. Every roll after the
  first is unweighted by this, so honest weather resumes immediately.

## 2.2.0

**The day/night grade is now its own feature with its own switch.**

- It used to be drawn inside the weather pass, so the engine's
  `Pipelines.eligible` gate on the WEATHER ladder switched it off too:
  turn weather off, lose the night. They are separate features and now
  have separate pipelines. New **TIME** row in OPTIONS:
  `OFF / AUTO / MORN / DAY / EVE / NITE`.
- Priority 6 puts it above the weather pipeline (5), and the stage fold
  runs in descending priority, so the grade composites *underneath* the
  rain — the hour is a property of the light in the world, not of the
  water in front of it.
- **Pinning a rung is the handheld-friendly proof it works**: set TIME to
  NITE and the screen goes blue immediately, whatever the real time is. No
  config file, no keyboard.
- **The clock keeps running at TIME = OFF**, so `world.tod` stays truthful
  for palette mods even when this mod draws nothing.
- **Morning and evening are visibly stronger.** At 09:00 the old blend sat
  around a 0.97 green and a 0.91 blue — under the noise floor of a
  handheld LCD, and indistinguishable from "not working". DAY stays
  exactly neutral, so noon still costs nothing.
- The readout no longer reports stale particle counts (`r847`) while the
  weather ladder is off. The pools are frozen, not emptied, and reporting
  their last values over a dry screen was a diagnostic telling a lie.

## 2.1.1

- **Weather now fills the screen.** The engine reports two rects and the
  present stage is handed neither: `gameWidth/gameHeight` from `render.hud`
  are the INTEGER-scaled 160x144 game rect, while the world is composited
  across the whole window through a separate non-integer UI fit
  (`Up = math.min(ph/uih, pw/uiw)`). Scissoring to the first put a dry
  160x144 box in the middle of a wet screen on any device where the two
  differ — which is most handhelds. The default is now the whole canvas;
  `coverage = "playfield"` restores the old behaviour for a windowed
  desktop with real letterbox bars.
- **Particle sizes are DPI-correct.** `ctx.scale` is `Sp`, framebuffer
  PIXELS per GB pixel, but the present canvas is in units — so drops were
  oversized by the DPI factor on a high-DPI panel. The scale is now
  derived from the playfield height in canvas units, which is
  self-consistent in whatever space the rect is in.
- **The config's `ENUMS` table is now actually enforced.** It had been
  declared since 2.0.0 and never consulted, so `coverage = "playfeild"` or
  `lightningMode = "strobe"` were stored verbatim and silently disabled the
  feature. They now fall back to the default and are reported by name. A
  test written to document the hole is what found it.

## 2.1.0

**Fixes the bug that made 2.0.1 and 2.0.2's DEBUG RAIN do nothing.**

- `debugRain` set an *internal* level of 1 and assumed that switched the
  mod on. It could never have: the engine gates every pipeline stage on
  `Pipelines.level(id) <= 0` **before** it calls `available()`, so an
  internal override pinned the weather, eased every channel and reported a
  healthy state on the readout while drawing precisely nothing — and
  `Draw.update` takes the same engine level, so the particle pools were
  never ticked either (`r0 s0 g0`). The same bug hid the day/night grade.
- New `lib/Ladder.lua` moves the engine's own ladder instead. DEBUG RAIN
  now genuinely sets the OPTIONS row to HEAVY, and puts it back to OFF
  when you turn it off — but never overwrites or undoes a rung you chose
  yourself. The debug path and the normal path are now the same path,
  which is the real fix.
- **The clock now defaults to the device's system clock** (`time.source =
  "system"`), which is what Gold/Silver/Crystal actually did: play at 9pm
  and it is night. Previously the default was `auto`, which fell back to
  an accelerated internal cycle when the voxel mod was absent — so the
  readout could say `Nite 00:56` at half past eight in the morning.

## 2.0.2

- **DEBUG RAIN is now a row on the mod-manager page**, next to DEBUG HUD.
  In 2.0.1 the switch existed only in `config.lua` — which a `.modpkg`
  install has no editable copy of, so the one setting meant for "is this
  mod working at all" was unreachable for exactly the people most likely
  to need it. Either source turns it on.
- **The readout now shows the raw ladder level and whether a config file
  was found**: `WX L0 OFF (row is OFF) | ... | cfg:NONE | ...`. "My edits
  do nothing" and "there is no file to edit" looked identical from the
  player's side; now they don't.

## 2.0.1

- **`debugRain = true`** in `config.lua`: heavy rain everywhere, indoors
  and out, diagnostic readout on, and the weather system switched on even
  if the OPTIONS row is on OFF. The only setting that overrides OFF, and
  deliberately so — a diagnostic silenced by the most likely reason the
  mod is not running is not a diagnostic.
- **The readout now names why nothing is happening.** `Wx OFF (row is
  OFF)`, and `Wx OFF (force ignored - row is OFF)` when a config `force`
  is set against an OFF ladder — previously it just said `Off`, which sent
  people hunting for a bug that was one menu row away.
- README gains a troubleshooting table mapping each readout to its cause.
- Suite grows to 362 checks, covering the force-at-OFF trap explicitly.

## 2.0.0

Renderer independence, a clock of its own, a config file, and a real
battle weather layer.

### Independence

- **No dependency on any renderer.** The whole-frame `present` stage runs
  on the finished composite, so the flat 2D renderer, TILT, the survey
  zoom, every colour mode and GBC FX all work. `worldPresent` is still
  declared, so a world pipeline (the Dramatic Shape diorama) still gets
  weather composited under the UI. Nothing on the draw path names a
  renderer.
- **Its own day/night clock** (`lib/TimeOfDay.lua`), with four sources:
  Dramatic Shape's when installed, the device's real clock, an
  accelerated cycle, or pinned. Version 1 borrowed that mod's clock, which
  meant no night without it.
- **Gold/Silver/Crystal-style day/night grade** over the overworld, with
  `MORN`/`DAY`/`EVE`/`NITE` phases. `DAY` is exactly neutral, so midday
  costs nothing. The mod also answers the engine's `world.tod` hook, so
  palette mods can key off the hour through `map.palette`.
- **Text-box clipping** on the flat renderer: precipitation is clipped
  above an open dialog box so it lands behind the text rather than on it.

### New weather

Seven new types, for fourteen in all: `SUNNY`, `HARSH_SUN`, `HEAVY_RAIN`
(primal), `HAIL`, `SANDSTORM`, `STRONG_WINDS`, alongside the existing
clear, light and heavy rain, thunderstorm, snow, blizzard, mist and fog.

- New channels: `hail`, `sand`, `debris`, `warm`, `glare`.
- A third particle pool, **grain**, shared by hail, sand and debris. Each
  grain carries its kind, rolled at spawn against the live channel mix, so
  a sandstorm turning to hail reads as the storm turning over rather than
  as one effect being swapped for another.
- The primal weathers and Strong Winds are marked `natural = false`: AUTO
  never rolls them, but the ladder and the config can still reach them.

### Configuration

- **`config.lua`**, a documented, editable Lua data file:
  - `force` — pin one weather everywhere.
  - `locations` — per-map overrides, with `chance` rolled once per arrival
    and an `indoors` flag. Ships with Lavender Town fog, Route 23 hail,
    Indigo Plateau snow, sea-route mist, Viridian Forest mist and Cinnabar
    sun. A hard override parks the AUTO clock instead of consuming it.
  - `bias` — softer per-map weighting on top of the built-in geography.
  - `tuning` — per-weather density, intensity, speed and duration.
  - `visuals` — every drawn layer, individually switchable.
  - `time`, `battle`, `quality`, `maxParticles`, `transitionSeconds`.
- A malformed config cannot break the mod: syntax errors, files that
  throw, non-table returns, typo'd keys (reported **by name**),
  out-of-range numbers (clamped) and unknown weather ids (dropped) all end
  with a usable config and a running mod.
- `weather <id>` console command, with `list` and `status`.

### Battle weather

- Battle weather now draws through the **`battle.overlay`** hook, inside
  the battle's own 160×144 canvas, so drops are the right size relative to
  the sprites and pass through the battle's own palette handling.
- **`battle.field.weather` is the single source of truth**, written in
  Kanto-Reforged's vocabulary (`SUNNY`/`RAINY`/`SANDSTORM`/`HAIL`/`SNOWY`,
  extended with `HARSH_SUN`/`HEAVY_RAIN`/`STRONG_WINDS`/`FOG`), so both
  mods drive one field instead of fighting over two.
- **Capability detection**: Weather Ball, Forecast/Castform, Sand Veil and
  the weather speed multipliers are deferred to Kanto-Reforged when it is
  installed, and provided by this mod when it is not. Nothing is applied
  twice in either case.
- Implemented: type power (FIRE/WATER under sun and rain), primal
  nullification with a message, accuracy (THUNDER, HURRICANE, BLIZZARD,
  fog), Solar Beam power, sandstorm and hail residual damage with type and
  ability immunities, ROCK special defence in a sandstorm, Strong Winds
  cutting super-effective hits on Flying types, Chlorophyll / Swift Swim /
  Sand Rush / Slush Rush speed, Sand Veil / Snow Cloak evasion, Ice Body /
  Rain Dish / Dry Skin healing and Dry Skin / Solar Power burn, Cloud Nine
  suppression, and the weather rocks and Utility Umbrella read from
  `mon.heldItem`.
- Seeding the overworld's weather into a battle stays behind the opt-in
  WEATHER ruleset by default; `battle.requireRuleset = false` releases it
  for existing saves. Effects on weather a move or ability set are never
  gated.
- Not implemented, and documented as such: Solar Beam's charge skip (move
  flow is not a hook), weather-based evolution.

### Fixes and internals

- The OFF path now reliably zeroes its channels via a `dirty` flag rather
  than an edge test that missed a mod started at level 0.
- Capabilities reset before detection, so a hot reload after removing a
  mod does not leave a capability latched on.
- Fog UVs wrap into 0..1, keeping precision after an hour of play.
- Both draw stages restore the previously bound canvas rather than
  unbinding.
- The standalone suite grew from 178 checks to **352**, and now covers the
  config loader, the clock, the grade, all three particle pools, both
  compositors and every battle effect in both interop directions.

## 1.0.0

First release.

- Eight weather types on a channel-eased state machine.
- One `render_pipelines` record declaring both `worldPresent` and
  `present`.
- AUTO weather clock with time-of-day, previous-weather and region
  weighting; the running spell persists in the mod's own save namespace.
- Optional day/night link to `DRAMATIC_SHAPE` through its published
  `exports.lib`.
- Quality tiers with an adaptive governor; one draw call for all
  precipitation; no allocation after warmup.
- `LIGHTNING = OFF / SOFT / FULL` as a photosensitivity setting.
- Opt-in `WEATHER` ruleset; vanilla by default.
- No shipped assets.
